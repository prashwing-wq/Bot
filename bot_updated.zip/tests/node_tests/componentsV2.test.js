/**
 * Test Suite: Components V2 Engine & Settings Persistence
 */
const assert = require('node:assert');
const {
  isComponentsV2Enabled,
  setComponentsV2Enabled,
  createV2Card,
  createV2Container,
  formatButtonPanel,
  createButtonRow,
  createSelectMenuRow
} = require('../../src/utils/componentsV2');
const { ButtonStyle } = require('discord.js');

console.log('[TEST] Running componentsV2.test.js...');

// 1. Default status for new guild is true
const testGuildId = '9999888877776666';
assert.strictEqual(isComponentsV2Enabled(testGuildId), true, 'Components V2 default should be true');

// 2. Toggle to disabled
setComponentsV2Enabled(testGuildId, false);
assert.strictEqual(isComponentsV2Enabled(testGuildId), false, 'Components V2 should now be disabled');

// 3. Toggle back to enabled
setComponentsV2Enabled(testGuildId, true);
assert.strictEqual(isComponentsV2Enabled(testGuildId), true, 'Components V2 should be re-enabled');
console.log('✅ Components V2 per-guild persistence verified.');

// 4. Create V2 Card with integrated buttons
const card = createV2Card({
  color: 0x00FF88,
  title: '⚡ Test V2 Card',
  description: 'Testing modular card layout',
  fields: [{ name: 'Field 1', value: 'Value 1', inline: true }],
  footerText: 'Test Footer',
  buttons: [
    { label: 'Action 1', emoji: '⭐' },
    { label: 'Action 2', emoji: '🚀' }
  ]
});

assert.strictEqual(card.data.title, '⚡ Test V2 Card');
assert.strictEqual(card.data.fields.length, 1);
assert.strictEqual(card.data.footer.text, 'Test Footer');
assert.ok(card.data.description.includes('Action 1'), 'Description must include in-embed button Action 1');
assert.ok(card.data.description.includes('Action 2'), 'Description must include in-embed button Action 2');
console.log('✅ createV2Card with integrated buttons verified.');

// 5. Test formatButtonPanel directly
const panelStr = formatButtonPanel([{ label: 'TestBtn', emoji: '✅' }], 'Controls');
assert.ok(panelStr.includes('TestBtn'), 'Panel must include TestBtn');
assert.ok(panelStr.includes('Components V2'), 'Panel must include Components V2 branding');
console.log('✅ formatButtonPanel verified.');

// 6. Test createV2Container (Type 17)
const container = createV2Container({
  title: 'Native Container',
  description: 'Container description',
  buttons: [{ customId: 'c_btn', label: 'Contained', emoji: '📦' }]
});
if (container) {
  assert.strictEqual(container.data ? container.data.type : container.toJSON().type, 17, 'Container must be Type 17');
  console.log('✅ createV2Container (Type 17) verified.');
}

// 5. Create Button Row
const buttonRow = createButtonRow([
  { customId: 'btn1', label: 'Primary', style: ButtonStyle.Primary, emoji: '🔥' },
  { customId: 'btn2', label: 'Danger', style: ButtonStyle.Danger }
]);
assert.strictEqual(buttonRow.components.length, 2);
assert.strictEqual(buttonRow.components[0].data.label, 'Primary');
assert.strictEqual(buttonRow.components[1].data.label, 'Danger');
console.log('✅ createButtonRow verified.');

// 6. Create Select Menu Row
const menuRow = createSelectMenuRow({
  customId: 'menu1',
  placeholder: 'Pick one',
  options: [{ label: 'Option A', value: 'a' }]
});
assert.strictEqual(menuRow.components[0].data.custom_id, 'menu1');
assert.strictEqual(menuRow.components[0].data.placeholder, 'Pick one');
console.log('✅ createSelectMenuRow verified.');

// 7. Test transformToV2Payload separating Select Menu ActionRows vs Button ActionRows
(async () => {
  const {
    transformToV2Payload,
    stripComponentsFromV2,
    safeExecuteWithFallback,
    isSelectMenuRow
  } = require('../../src/utils/patchComponentsV2');
  const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    MessageComponentInteraction
  } = require('discord.js');

  const embed = new EmbedBuilder().setTitle('Container Title').setDescription('Container description');
  const bRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_test').setLabel('Click Me').setStyle(ButtonStyle.Primary)
  );
  const sRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder().setCustomId('sel_test').setPlaceholder('Select option').addOptions([
      { label: 'Option 1', value: 'opt1' }
    ])
  );
  const uRow = new ActionRowBuilder().addComponents(
    new UserSelectMenuBuilder().setCustomId('user_sel_test')
  );

  // Verify select detection
  assert.strictEqual(isSelectMenuRow(bRow), false, 'Button row should not be select menu row');
  assert.strictEqual(isSelectMenuRow(sRow), true, 'StringSelect row should be select menu row');
  assert.strictEqual(isSelectMenuRow(uRow), true, 'UserSelect row should be select menu row');

  const v2Payload = transformToV2Payload({
    embeds: [embed],
    components: [bRow, sRow, uRow]
  }, null, false);

  assert.ok(v2Payload, 'Payload must be returned');
  assert.strictEqual(v2Payload.embeds, undefined, 'Embeds must be cleared in V2 payload');
  assert.ok(v2Payload.components.length >= 3, 'Must have container + select rows');

  // Check container: first component should be Type 17
  const mainContainer = v2Payload.components[0];
  const cJson = mainContainer.toJSON ? mainContainer.toJSON() : mainContainer;
  assert.strictEqual(cJson.type, 17, 'First top-level component must be Type 17 Container');

  // Container internal subcomponents: must contain button action row, but NO select menu rows!
  const containerSubComps = cJson.components || [];
  for (const sub of containerSubComps) {
    assert.ok(!isSelectMenuRow(sub), 'Container internal subcomponents must NEVER contain select menus');
  }

  // Select rows must be top-level alongside the container
  assert.strictEqual(isSelectMenuRow(v2Payload.components[1]), true, 'Top-level component 1 must be select row');
  assert.strictEqual(isSelectMenuRow(v2Payload.components[2]), true, 'Top-level component 2 must be select row');
  console.log('✅ transformToV2Payload Select Menu & Button separation verified.');

  // 8. Test stripComponentsFromV2
  const stripped = stripComponentsFromV2(v2Payload);
  assert.strictEqual(stripped.components.length, 1, 'Stripped V2 must only retain the Container');
  const strippedContainer = stripped.components[0];
  const scSub = strippedContainer.components || strippedContainer.data?.components || [];
  assert.ok(scSub.every(c => (c.type ?? c.data?.type) !== 1), 'Stripped container must contain no ActionRows');
  console.log('✅ stripComponentsFromV2 verified.');

  // 9. Test safeExecuteWithFallback when isTargetV2 is true and Discord API returns 50035
  const attempts = [];
  const mockOrigFn = async (payload) => {
    attempts.push(payload);
    if (attempts.length === 1) {
      const err = new Error('Invalid Form Body: components[0].components[1]: Invalid Component Type');
      err.code = 50035;
      throw err;
    }
    return { ok: true, payload };
  };

  const fallbackResult = await safeExecuteWithFallback(mockOrigFn, {}, {
    embeds: [embed],
    components: [bRow]
  }, null, true);

  assert.ok(fallbackResult, 'Fallback must succeed without infinite loop');
  assert.strictEqual(attempts.length, 2, 'Should retry exactly once with sanitized/stripped payload');
  const secondAttempt = attempts[1];
  assert.ok(secondAttempt, 'Second attempt must be passed to origFn');
  console.log('✅ safeExecuteWithFallback on isTargetV2 rejection verified.');

  // 10. Test Interaction.prototype.update on deferred interaction redirecting to editReply
  const { applyComponentsV2Hooks } = require('../../src/utils/patchComponentsV2');
  applyComponentsV2Hooks();

  let editReplyCalled = false;
  const mockInteraction = {
    deferred: true,
    replied: false,
    guildId: '123456',
    message: { flags: 32768, components: [{ type: 17 }] },
    editReply: async function(options) {
      editReplyCalled = true;
      return { ok: true, options };
    }
  };

  await MessageComponentInteraction.prototype.update.call(mockInteraction, {
    embeds: [embed]
  });

  assert.strictEqual(editReplyCalled, true, 'update on deferred interaction must call editReply');
  console.log('✅ Interaction.prototype.update on deferred interaction verified.');

  console.log('\n====================================================');
  console.log('🎉 componentsV2.test.js PASSED with 0 errors!');
  console.log('====================================================\n');
})();
