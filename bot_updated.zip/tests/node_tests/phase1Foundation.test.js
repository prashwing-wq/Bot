/**
 * Test Suite: Phase 1 Platform Foundation (§5.4, §6.2, §6.4, §6.8)
 * Tests:
 * 1. Unified Task Scheduler (scheduled_tasks table, armTimer, processDueTasks, handlers)
 * 2. Versioned DB Migrations (PRAGMA user_version, transactional migration runner)
 * 3. Modular Interaction Router (src/interactions/ registration and dispatch)
 * 4. Two-step confirmation helper (askConfirmation)
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const path = require('node:path');
const { getServerDb, getMasterDb, applyVersionedMigrations } = require('../../src/utils/serverDb');
const {
  initScheduler,
  registerHandler,
  scheduleTask,
  cancelTask,
  processDueTasks
} = require('../../src/utils/scheduler');
const { routeInteraction, _routes } = require('../../src/interactions');
const { askConfirmation } = require('../../src/utils/confirmAction');

async function runTests() {
  console.log('[TEST] Running phase1Foundation.test.js...');
  const testGid = '777666555444333';
  const sdb = getServerDb(testGid);
  const mdb = getMasterDb();

  // ─────────────────────────────────────────────────────────────
  // 1. Unified Task Scheduler Tests (§5.4)
  // ─────────────────────────────────────────────────────────────
  let executedTaskPayload = null;
  registerHandler('test_task', async (task, payload, client) => {
    executedTaskPayload = payload;
  });

  const now = Date.now();
  // Schedule a task due in the past
  const taskId = scheduleTask(testGid, 'test_task', now - 1000, { message: 'hello scheduler' });
  assert.ok(taskId > 0, 'scheduleTask must return valid task ID');

  const rowBefore = mdb.prepare('SELECT * FROM scheduled_tasks WHERE id = ?').get(taskId);
  assert.ok(rowBefore, 'Task must exist in master scheduled_tasks');
  assert.strictEqual(rowBefore.done, 0, 'Task must initially be marked done = 0');

  // Process due tasks
  await processDueTasks();

  const rowAfter = mdb.prepare('SELECT * FROM scheduled_tasks WHERE id = ?').get(taskId);
  assert.strictEqual(rowAfter.done, 1, 'Executed task must be marked done = 1');
  assert.ok(executedTaskPayload, 'Handler must have been called');
  assert.strictEqual(executedTaskPayload.message, 'hello scheduler');

  // Test cancelTask
  const cancelTaskId = scheduleTask(testGid, 'test_task', now + 500000, { foo: 'bar' });
  cancelTask(cancelTaskId);
  const canceledRow = mdb.prepare('SELECT * FROM scheduled_tasks WHERE id = ?').get(cancelTaskId);
  assert.strictEqual(canceledRow.done, 1, 'Cancelled task must be marked done = 1');
  console.log('✅ Unified Task Scheduler (§5.4) verified: schedule, dispatch, and cancel.');

  // ─────────────────────────────────────────────────────────────
  // 2. Versioned DB Migrations Tests (§6.4)
  // ─────────────────────────────────────────────────────────────
  sdb.exec('PRAGMA user_version = 0');
  let v0 = sdb.prepare('PRAGMA user_version').get().user_version;
  assert.strictEqual(Number(v0), 0);

  const testMigrations = [
    (db) => {
      db.exec('CREATE TABLE IF NOT EXISTS test_m1 (id INTEGER PRIMARY KEY)');
    },
    (db) => {
      db.exec('CREATE TABLE IF NOT EXISTS test_m2 (name TEXT)');
    }
  ];

  applyVersionedMigrations(sdb, testMigrations, 'test_guild');

  let v2 = sdb.prepare('PRAGMA user_version').get().user_version;
  assert.strictEqual(Number(v2), 2, 'user_version must match migrations length after execution');

  // Verify idempotency (running again doesn't re-run or throw)
  applyVersionedMigrations(sdb, testMigrations, 'test_guild');
  let v2Idempotent = sdb.prepare('PRAGMA user_version').get().user_version;
  assert.strictEqual(Number(v2Idempotent), 2, 'user_version must remain stable on re-execution');
  console.log('✅ Versioned DB Migrations (§6.4) verified: PRAGMA user_version tracking & idempotency.');

  // ─────────────────────────────────────────────────────────────
  // 3. Modular Interaction Router Tests (§6.2)
  // ─────────────────────────────────────────────────────────────
  assert.ok(_routes.has('np'), 'Router must have registered "np" module');
  assert.ok(_routes.has('op'), 'Router must have registered "op" module');
  assert.ok(_routes.has('wl'), 'Router must have registered "wl" module');
  assert.ok(_routes.has('an'), 'Router must have registered "an" module');
  assert.ok(_routes.has('panic'), 'Router must have registered "panic" module');
  assert.strictEqual(_routes.has('prem'), false, 'Router must not register purged "prem" module');

  // Test routeInteraction dispatch for np
  let replyContent = null;
  const dummyOwner = process.env.OWNER_IDS.split(',')[0].trim();
  const mockNpInteraction = {
    customId: 'np:btn_add',
    user: { id: dummyOwner, username: 'Owner' },
    guild: { id: testGid },
    reply: (payload) => { replyContent = payload; }
  };
  const routed = await routeInteraction(mockNpInteraction, {});
  assert.strictEqual(routed, true, 'routeInteraction must handle registered np prefix');
  assert.ok(replyContent && replyContent.content.includes('To grant No-Prefix authorization'));

  // Test unhandled interaction returns false to allow fallthrough
  const mockUnknownInteraction = { customId: 'unknown_prefix:foo' };
  const unhandled = await routeInteraction(mockUnknownInteraction, {});
  assert.strictEqual(unhandled, false, 'Unregistered prefixes must return false for graceful fallthrough');
  console.log('✅ Modular Interaction Router (§6.2) verified: auto-discovery and delegation.');

  // ─────────────────────────────────────────────────────────────
  // 4. Two-Step Destructive Action Confirmation Tests (§6.8)
  // ─────────────────────────────────────────────────────────────
  let confirmReply = null;
  const mockMsg = {
    author: { id: dummyOwner, username: 'TestOwner' },
    guild: { id: testGid },
    reply: (payload) => {
      confirmReply = payload;
      return null; // Headless non-interactive environment returns null promptMsg
    }
  };

  const confirmRes = await askConfirmation(mockMsg, {
    title: 'Test Confirmation',
    description: 'Testing 2-step prompt'
  });
  assert.ok(confirmReply && confirmReply.embeds, 'Confirmation prompt must send rich embed');
  assert.ok(confirmReply.components.length > 0, 'Confirmation prompt must send action row buttons');
  assert.strictEqual(confirmRes.confirmed, true, 'Headless test gracefully resolves confirmed');
  console.log('✅ Two-Step Destructive Action Confirmation (§6.8) verified.');

  console.log('✅ phase1Foundation.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ phase1Foundation test failed:', err);
  process.exit(1);
});
