/**
 * Test Suite: Owner Help Privacy & Invisibility to Regular Users
 * Verifies that owner commands are completely hidden from regular users,
 * and only accessible when a Bot Owner uses ownerhelp.
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const helpCmd = require('../../src/commands/utility/help');
const ownerHelpCmd = require('../../src/commands/owner/ownerhelp');
const { CATEGORIES } = require('../../src/utils/helpUi');

async function runTests() {
  console.log('[TEST] Running ownerHelpPrivacy.test.js...');

  // 1. Verify CATEGORIES public array excludes 'owner'
  assert.strictEqual(CATEGORIES.some(c => c.id === 'owner'), false, 'CATEGORIES must never include owner in public array');

  const regularUserId = '555544443333222211';
  const botOwnerId = process.env.OWNER_IDS.split(',')[0].trim();

  let repliedContent = '';
  let repliedEmbed = null;

  function createMockMessage(authorId, query = '') {
    repliedContent = '';
    repliedEmbed = null;
    return {
      author: { id: authorId, username: authorId === botOwnerId ? 'BotOwner' : 'RegularUser' },
      guild: { id: '999888777666555' },
      reply: async (payload) => {
        if (typeof payload === 'string') repliedContent = payload;
        else if (payload.content) repliedContent = payload.content;
        if (payload.embeds && payload.embeds.length > 0) repliedEmbed = payload.embeds[0];
        return { id: 'msg_1' };
      }
    };
  }

  const mockClient = {
    commands: new Map([
      ['help', helpCmd],
      ['ownerhelp', ownerHelpCmd],
      ['eval', { name: 'eval', ownerOnly: true, category: 'owner', description: 'Evaluate code' }]
    ]),
    aliases: new Map(),
    categories: new Map([
      ['owner', [{ name: 'eval', ownerOnly: true, category: 'owner', description: 'Evaluate code' }]]
    ]),
    config: { COLORS: { PRIMARY: 0x000001, DANGER: 0xed4245 } },
    user: { username: 'Celestia' }
  };

  // 2. Regular user runs !help owner -> Access Denied
  const regMsg = createMockMessage(regularUserId);
  await helpCmd.execute(regMsg, ['owner'], mockClient, '!');
  assert.ok(repliedContent.toLowerCase().includes('access denied'), 'Regular user querying owner category must receive Access Denied');
  assert.strictEqual(repliedEmbed, null, 'No owner command list may be sent to regular user');
  console.log('✅ Regular user querying owner help blocked with Access Denied.');

  // 3. Regular user runs !help eval (owner command) -> Access Denied
  const regCmdMsg = createMockMessage(regularUserId);
  await helpCmd.execute(regCmdMsg, ['eval'], mockClient, '!');
  assert.ok(repliedContent.toLowerCase().includes('access denied'), 'Regular user inspecting owner command must receive Access Denied');
  console.log('✅ Regular user inspecting owner command blocked.');

  // 4. Regular user runs !ownerhelp -> Access Denied
  const regOwnerHelpMsg = createMockMessage(regularUserId);
  await ownerHelpCmd.execute(regOwnerHelpMsg, [], mockClient, '!');
  assert.ok(repliedContent.toLowerCase().includes('access denied'), 'Regular user executing !ownerhelp must receive Access Denied');
  console.log('✅ Regular user executing !ownerhelp blocked.');

  // 5. Bot Owner runs !help owner -> Directed to ownerhelp
  const ownerMsg = createMockMessage(botOwnerId);
  await helpCmd.execute(ownerMsg, ['owner'], mockClient, '!');
  assert.ok(repliedContent.includes('ownerhelp'), 'Bot owner querying owner help is directed to ownerhelp');
  console.log('✅ Bot owner querying owner help directed to ownerhelp.');

  // 6. Bot Owner runs !ownerhelp -> Full suite displayed
  const ownerHelpMsg = createMockMessage(botOwnerId);
  await ownerHelpCmd.execute(ownerHelpMsg, [], mockClient, '!');
  assert.ok(repliedEmbed, 'Bot owner executing !ownerhelp must receive owner suite embed');
  assert.ok(repliedEmbed.data.title.includes('Bot Owner & Developer Commands'), 'Owner embed title verified');
  console.log('✅ Bot owner executing !ownerhelp received complete executive suite.');

  console.log('====================================================');
  console.log('🎉 ownerHelpPrivacy.test.js PASSED with 0 errors!');
  console.log('====================================================');
}

runTests().catch(err => {
  console.error('❌ ownerHelpPrivacy.test.js failed:', err);
  process.exit(1);
});
