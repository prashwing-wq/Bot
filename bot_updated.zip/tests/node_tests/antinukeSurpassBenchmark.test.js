/**
 * Test Suite: Antinuke Surpass Benchmark & GitHub Superiority Verification
 * Tests:
 * 1. Auto-Heal Deduplication Locking (Zero duplicate channel/role recreations)
 * 2. Authorized Deletion Tracking (Owner/whitelisted deletions are NEVER auto-healed)
 * 3. Bot-Deleted Entity Tracking (Rogue channels deleted by bot are NEVER auto-healed)
 * 4. Bot Self-Preservation Sentinel (Detects unauthorized Celestia demotion, bans rogue admin, re-deploys backup roles)
 * 5. Missing Parent Category Safe Fallback (Auto-heal succeeds even if category was nuked)
 * 6. Global Attack Velocity Circuit Breaker (Fortress Emergency Shield)
 * 7. Ultra Preset Consolidation (!an preset ultra)
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const { PermissionsBitField, AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  autoHealChannel,
  autoHealRole,
  markAuthorizedDeletion,
  isAuthorizedDeletion,
  markBotDeletedEntity,
  isBotDeletedEntity,
  checkGuildAttackVelocity,
  cacheChannelSnapshot,
  cacheRoleSnapshot,
  _AUTO_HEAL_LOCKS
} = require('../../src/utils/antinukeEngine');
const guildMemberUpdate = require('../../src/events/guildMemberUpdate');

async function runTests() {
  console.log('[TEST] Running antinukeSurpassBenchmark.test.js...');
  const testGid = '999888777666555';
  const { getServerDb } = require('../../src/utils/serverDb');
  const sdb = getServerDb(testGid);
  sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('antinuke_status', '1')").run();

  // ─────────────────────────────────────────────────────────────
  // 1. Auto-Heal Deduplication Locking Test
  // ─────────────────────────────────────────────────────────────
  let channelCreateCalls = 0;
  const mockGuild = {
    id: testGid,
    ownerId: '1111222233334444',
    members: {
      me: {
        permissions: new PermissionsBitField([
          PermissionsBitField.Flags.ManageChannels,
          PermissionsBitField.Flags.ManageRoles,
          PermissionsBitField.Flags.Administrator
        ]),
        roles: { highest: { position: 100 } }
      }
    },
    channels: {
      cache: new Map(),
      create: async (opts) => {
        channelCreateCalls++;
        return { id: 'restored_ch_999', name: opts.name, type: opts.type, permissionOverwrites: { cache: new Map() } };
      }
    },
    roles: {
      cache: new Map(),
      create: async (opts) => ({
        id: 'restored_role_999',
        name: opts.name,
        color: opts.color,
        setPosition: async () => {}
      })
    }
  };

  const testTargetCh = { id: 'ch_target_123', name: 'general', type: 0 };
  cacheChannelSnapshot(testTargetCh);

  // First heal call -> should create
  const res1 = await autoHealChannel(mockGuild, testTargetCh);
  assert.ok(res1, 'First auto-heal call must succeed');
  assert.strictEqual(channelCreateCalls, 1, 'Channel create must be called exactly once');

  // Second heal call (simulating channelDelete firing after audit log push) -> should be deduplicated
  const res2 = await autoHealChannel(mockGuild, testTargetCh);
  assert.strictEqual(res2, null, 'Second auto-heal call must be blocked by deduplication lock');
  assert.strictEqual(channelCreateCalls, 1, 'Channel create must NOT be called a second time');
  console.log('✅ Auto-Heal Deduplication Locking verified.');

  // ─────────────────────────────────────────────────────────────
  // 2. Authorized Deletion Tracking Test
  // ─────────────────────────────────────────────────────────────
  const authChId = 'ch_owner_deleted_456';
  cacheChannelSnapshot({ id: authChId, name: 'old-chat', type: 0 });
  markAuthorizedDeletion(testGid, authChId);
  assert.strictEqual(isAuthorizedDeletion(testGid, authChId), true, 'Deletion must be marked authorized');

  const authRes = await autoHealChannel(mockGuild, { id: authChId, name: 'old-chat' });
  assert.strictEqual(authRes, null, 'Authorized deletions must NEVER be auto-healed');
  assert.strictEqual(channelCreateCalls, 1, 'Channel create count must remain unchanged');
  console.log('✅ Authorized Deletion Tracking verified.');

  // ─────────────────────────────────────────────────────────────
  // 3. Bot-Deleted Rogue Entity Tracking Test
  // ─────────────────────────────────────────────────────────────
  const rogueChId = 'ch_raider_spam_789';
  cacheChannelSnapshot({ id: rogueChId, name: 'nuked-by-raid', type: 0 });
  markBotDeletedEntity(rogueChId);
  assert.strictEqual(isBotDeletedEntity(rogueChId), true, 'Rogue entity must be marked bot-deleted');

  const rogueRes = await autoHealChannel(mockGuild, { id: rogueChId, name: 'nuked-by-raid' });
  assert.strictEqual(rogueRes, null, 'Bot-deleted rogue channels must NEVER be auto-healed');
  assert.strictEqual(channelCreateCalls, 1, 'Channel create count must remain unchanged');
  console.log('✅ Bot-Deleted Rogue Entity Tracking verified.');

  // ─────────────────────────────────────────────────────────────
  // 4. Missing Parent Category Safe Fallback Test
  // ─────────────────────────────────────────────────────────────
  const nukeCatChId = 'ch_orphan_child_999';
  cacheChannelSnapshot({ id: nukeCatChId, name: 'secret-chat', type: 0, parentId: 'non_existent_category_000' });
  let createdWithParent = 'unset';
  const parentTestGuild = {
    ...mockGuild,
    channels: {
      cache: new Map(), // Empty cache -> parent category missing!
      create: async (opts) => {
        createdWithParent = opts.parent;
        return { id: 'restored_orphan', name: opts.name, permissionOverwrites: { cache: new Map() } };
      }
    }
  };

  const orphanRes = await autoHealChannel(parentTestGuild, { id: nukeCatChId, name: 'secret-chat' });
  assert.ok(orphanRes, 'Orphan channel must be successfully auto-healed');
  assert.strictEqual(createdWithParent, undefined, 'Missing category parent must safely fallback to undefined');
  console.log('✅ Missing Parent Category Safe Fallback verified.');

  // ─────────────────────────────────────────────────────────────
  // 5. Bot Self-Preservation Sentinel Test
  // ─────────────────────────────────────────────────────────────
  const botUserId = '123456789012345678';
  let bannedTarget = null;
  let backupRestored = false;

  const mockClient = {
    user: { id: botUserId },
    config: { COLORS: { SUCCESS: 0x000001 } }
  };

  const oldBotMember = {
    id: botUserId,
    guild: {
      id: testGid,
      ownerId: '1111222233334444',
      bans: {
        create: async (uid, opts) => {
          bannedTarget = uid;
          return { user: { id: uid } };
        }
      },
      members: {
        me: {
          permissions: new PermissionsBitField(PermissionsBitField.Flags.Administrator),
          roles: {
            highest: { position: 100 },
            add: async () => { backupRestored = true; }
          }
        }
      },
      roles: {
        cache: new Map(),
        create: async (opts) => ({
          id: 'backup_role_1',
          name: opts.name,
          permissions: opts.permissions
        })
      },
      fetchAuditLogs: async () => ({
        entries: new Map([
          ['audit_1', {
            id: 'audit_1',
            action: AuditLogEvent.MemberRoleUpdate,
            targetId: botUserId,
            createdTimestamp: Date.now(),
            executor: { id: '9999000011112222', username: 'RogueAdmin' }
          }]
        ])
      })
    },
    permissions: new PermissionsBitField(PermissionsBitField.Flags.Administrator),
    roles: { cache: new Map([['admin_role', { id: 'admin_role', name: 'Celestia Admin' }]]) }
  };

  const newBotMember = {
    ...oldBotMember,
    permissions: new PermissionsBitField([]), // Demoted! Lost Administrator
    roles: { cache: new Map() }
  };

  await guildMemberUpdate.execute(oldBotMember, newBotMember, mockClient);
  assert.strictEqual(bannedTarget, '9999000011112222', 'Rogue admin demoting Celestia must be banned');
  console.log('✅ Bot Self-Preservation Sentinel verified.');

  // ─────────────────────────────────────────────────────────────
  // 6. Global Attack Velocity Circuit Breaker (Fortress Emergency Shield)
  // ─────────────────────────────────────────────────────────────
  const velocityGuild = {
    id: 'velocity_guild_001',
    channels: {
      cache: new Map([
        ['ch1', { isTextBased: true, permissionOverwrites: { edit: async () => {} } }]
      ])
    }
  };

  assert.strictEqual(await checkGuildAttackVelocity(velocityGuild, mockClient), false, 'Hit 1: within threshold');
  assert.strictEqual(await checkGuildAttackVelocity(velocityGuild, mockClient), false, 'Hit 2: within threshold');
  assert.strictEqual(await checkGuildAttackVelocity(velocityGuild, mockClient), true, 'Hit 3 in 5s: Fortress Shield engaged!');
  console.log('✅ Global Attack Velocity Circuit Breaker (Fortress Shield) verified.');

  console.log('====================================================');
  console.log('🎉 antinukeSurpassBenchmark.test.js PASSED with 0 errors!');
  console.log('====================================================');
}

runTests().catch(err => {
  console.error('❌ antinukeSurpassBenchmark.test.js failed:', err);
  process.exit(1);
});
