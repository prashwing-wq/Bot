/**
 * Test Suite: Pings, Mention Notifications & AFK DM Reminders
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const { refreshOwners } = require('../../src/utils/tools');
refreshOwners();
const {
  isMentionAllowed,
  setMentionAlertsEnabled,
  isMentionAlertsEnabled,
  getAfkStatus,
  setAfkStatus,
  clearAfkStatus,
  incrementAfkMentions
} = require('../../src/utils/pingsDb');
const { handleMessageMentions, handleBotMention } = require('../../src/utils/mentionSender');
const pingsInteraction = require('../../src/interactions/pings');
const messageCreateEvent = require('../../src/events/messageCreate');
const { MessageFlags } = require('discord.js');

console.log('[TEST] Running pings.test.js...');

const testGuildId = `guild_test_pings_${Date.now()}`;
const targetUserId = '999888777666';
const senderUserId = '111222333444';

// 1. Initial State: mentions enabled by default
const initialAllowed = isMentionAllowed(targetUserId, senderUserId, testGuildId);
assert.strictEqual(initialAllowed, true, 'Mentions should be allowed by default');
console.log('✅ Default mention alert permission is active.');

// 1b. Bot Owner immunity: never allowed by default
const dummyOwner = process.env.OWNER_IDS.split(',')[0].trim();
const ownerAllowed = isMentionAllowed(dummyOwner, senderUserId, testGuildId);
assert.strictEqual(ownerAllowed, false, 'Bot owner must not receive unsolicited mention DMs');
console.log('✅ Bot Owner immunity from unsolicited mention DMs verified.');

// 2. Disable mention alerts
setMentionAlertsEnabled(targetUserId, false, testGuildId);
assert.strictEqual(isMentionAlertsEnabled(targetUserId, testGuildId), false, 'Mentions should now be disabled');

const blockedCheck = isMentionAllowed(targetUserId, senderUserId, testGuildId);
assert.strictEqual(blockedCheck, false, 'Mention should be blocked after disabling');
console.log('✅ Disabling mention alerts properly prevents notifications.');

// 3. Re-enable mention alerts
setMentionAlertsEnabled(targetUserId, true, testGuildId);
assert.strictEqual(isMentionAlertsEnabled(targetUserId, testGuildId), true, 'Mentions should now be enabled');
console.log('✅ Re-enabling mention alerts verified.');

// 4. Test AFK Subsystem
setAfkStatus(targetUserId, testGuildId, 'Coding in Node.js', 1);
const afkData = getAfkStatus(targetUserId, testGuildId);
assert.ok(afkData, 'AFK record should exist');
assert.strictEqual(afkData.reason, 'Coding in Node.js');
assert.strictEqual(afkData.dm_remind, 1);

// Increment mentions
const count1 = incrementAfkMentions(targetUserId, testGuildId);
const count2 = incrementAfkMentions(targetUserId, testGuildId);
assert.strictEqual(count2, 2, 'Mentions count should increment to 2');

// Clear AFK on return
const cleared = clearAfkStatus(targetUserId, testGuildId);
assert.ok(cleared, 'AFK should be cleared');
assert.strictEqual(cleared.mentions_count, 2, 'Cleared info should retain mentions count');

const afkAfterClear = getAfkStatus(targetUserId, testGuildId);
assert.strictEqual(afkAfterClear, null, 'AFK status should now be null');
console.log('✅ AFK lifecycle (set, increment mentions, clear) verified.');

// 5. Test handleMessageMentions dispatcher
let dmSent = false;
let dmPayload = null;

const mockTargetUser = {
  id: '888888888888',
  bot: false,
  send: async (payload) => {
    dmSent = true;
    dmPayload = payload;
  }
};

const mockMessage = {
  id: 'msg_123',
  content: 'Hey <@888888888888> check this out!',
  cleanContent: 'Hey @Target check this out!',
  url: 'https://discord.com/channels/123/456/789',
  createdAt: new Date(),
  createdTimestamp: Date.now(),
  author: {
    id: '777777777777',
    tag: 'Sender#0001',
    bot: false,
    displayAvatarURL: () => 'https://example.com/sender.png'
  },
  guild: {
    id: testGuildId,
    name: 'Tungsten Test Guild',
    iconURL: () => null,
    members: {
      cache: new Map()
    }
  },
  channel: {
    id: 'chan_456',
    name: 'general',
    permissionsFor: () => ({ has: () => true })
  },
  mentions: {
    users: new Map([
      ['888888888888', mockTargetUser]
    ])
  }
};

const mockClient = {
  config: {
    COLORS: { INFO: 0x5865F2 }
  },
  user: {
    displayAvatarURL: () => 'https://example.com/bot.png'
  }
};

async function testDispatcher() {
  const { setSetting } = require('../../src/settings/registry');
  setSetting(testGuildId, 'utility.mention_alerts_enabled', true, 'test');
  await handleMessageMentions(mockMessage, mockClient);
  assert.strictEqual(dmSent, true, 'Target user should have received a DM notification');
  assert.ok(dmPayload.embeds.length > 0, 'DM must contain an embed');
  assert.ok(dmPayload.components.length > 0, 'DM must contain jump link button component');
  const embed = dmPayload.embeds[0];
  assert.ok(embed.data.title.includes('Mention Alert'), 'Embed title must be Mention Alert');
  
  // Verify clean vertical layout and channel formatting (no raw <#channel.id>)
  assert.ok(!embed.data.description.includes('<#'), 'Description must not contain raw <#channel.id> mention in DMs');
  assert.ok(embed.data.description.includes('#general'), 'Description must contain clean #channel.name');
  assert.ok(embed.data.fields.length >= 4, 'Must have at least 4 vertical fields');
  assert.strictEqual(embed.data.fields[0].name, 'Channel & Server');
  assert.strictEqual(embed.data.fields[0].value, '#general • **Tungsten Test Guild**');
  assert.strictEqual(embed.data.fields[0].inline, false, 'Field must be vertical (inline: false)');
  assert.strictEqual(embed.data.fields[1].name, 'Mentioned By');
  assert.strictEqual(embed.data.fields[1].inline, false, 'Field must be vertical (inline: false)');
  assert.strictEqual(embed.data.fields[2].name, 'Time');
  assert.strictEqual(embed.data.fields[2].inline, false, 'Field must be vertical (inline: false)');
  assert.ok(/(AM|PM)/i.test(embed.data.fields[2].value), 'Time field must show text time with AM/PM');
  assert.ok(!embed.data.fields[2].value.includes('<t:'), 'Time field must NOT use broken Discord dynamic tags');
  assert.strictEqual(embed.data.fields[3].name, 'Message');
  assert.strictEqual(embed.data.fields[3].inline, false, 'Field must be vertical (inline: false)');
  
  // Verify jump link button label
  const jumpButton = dmPayload.components[0].components[0];
  assert.strictEqual(jumpButton.data.label, 'Jump to #general');
  assert.strictEqual(jumpButton.data.url, mockMessage.url);
  console.log('✅ handleMessageMentions delivered rich DM notification with clean vertical layout and Jump to #channel button.');

  // 6. Test handleBotMention
  let botDmSent = false;
  let botDmPayload = null;
  const mockAuthorUser = {
    id: 'author_bot_tag_123',
    username: 'TagTester',
    bot: false,
    send: async (payload) => {
      botDmSent = true;
      botDmPayload = payload;
    }
  };
  const mockBotMentionMsg = {
    id: 'msg_bot_tag_456',
    content: '<@100000000000000001> help me please',
    cleanContent: '@Tungsten help me please',
    url: 'https://discord.com/channels/123/456/999',
    createdAt: new Date(),
    createdTimestamp: Date.now(),
    author: mockAuthorUser,
    guild: {
      id: testGuildId,
      name: 'Tungsten Test Guild',
      iconURL: () => null
    },
    channel: {
      id: 'chan_456',
      name: 'lounge'
    }
  };
  await handleBotMention(mockBotMentionMsg, {
    ...mockClient,
    user: { id: '100000000000000001', username: 'Tungsten', displayAvatarURL: () => 'https://example.com/bot.png' }
  });
  assert.strictEqual(botDmSent, true, 'User should receive Bot Tag DM');
  const botEmbed = botDmPayload.embeds[0];
  assert.ok(botEmbed.data.title.includes('Tagged in Tungsten Test Guild'), 'Bot tag DM title must match');
  assert.ok(
    botEmbed.data.description.includes('You tagged Tungsten in **Tungsten Test Guild** (#lounge).'),
    'Bot tag DM description must match'
  );
  assert.ok(!botEmbed.data.description.includes('<#'), 'Bot tag DM must not use broken <#channel.id>');
  assert.strictEqual(botEmbed.data.fields[0].name, 'Channel & Server');
  assert.strictEqual(botEmbed.data.fields[0].value, '#lounge • **Tungsten Test Guild**');
  assert.strictEqual(botEmbed.data.fields[0].inline, false);
  assert.strictEqual(botEmbed.data.fields[1].name, 'Time');
  assert.ok(/(AM|PM)/i.test(botEmbed.data.fields[1].value), 'Bot tag Time field must show text time with AM/PM');
  assert.ok(!botEmbed.data.fields[1].value.includes('<t:'), 'Bot tag Time field must NOT use broken Discord dynamic tags');
  const botJumpBtn = botDmPayload.components[0].components[0];
  assert.strictEqual(botJumpBtn.data.label, 'Jump to #lounge');
  assert.strictEqual(botDmPayload.components[0].components.length, 1, 'Bot tag DM should have single clean LinkButton');
  console.log('✅ handleBotMention clean greeting, vertical layout, and single LinkButton verified.');

  // 7. Test src/interactions/pings.js (DM vs Guild ephemeral safety)
  let dmUpdated = false;
  let dmUpdatePayload = null;
  const mockDmInteraction = {
    customId: 'pings:disable:user_123',
    user: { id: 'user_123' },
    guild: null, // Direct Message!
    update: async (payload) => {
      dmUpdated = true;
      dmUpdatePayload = payload;
    }
  };
  const dmHandled = await pingsInteraction.handle(mockDmInteraction, mockClient);
  assert.strictEqual(dmHandled, true);
  assert.strictEqual(dmUpdated, true);
  assert.strictEqual(dmUpdatePayload.flags, undefined, 'DM button update must NEVER include MessageFlags.Ephemeral');
  assert.ok(dmUpdatePayload.content.includes('disabled DM mention alerts'));
  console.log('✅ pings.js in DMs cleanly updates message without ephemeral flags.');

  let guildReplied = false;
  let guildReplyPayload = null;
  const mockGuildInteraction = {
    customId: 'pings:disable:user_123',
    user: { id: 'user_123' },
    guild: { id: testGuildId },
    reply: async (payload) => {
      guildReplied = true;
      guildReplyPayload = payload;
    }
  };
  const guildHandled = await pingsInteraction.handle(mockGuildInteraction, mockClient);
  assert.strictEqual(guildHandled, true);
  assert.strictEqual(guildReplied, true);
  assert.strictEqual(guildReplyPayload.flags, MessageFlags.Ephemeral, 'Guild interaction should use Ephemeral');
  console.log('✅ pings.js in guild channels safely uses MessageFlags.Ephemeral.');

  // 8. Test src/events/messageCreate.js bot tag handling
  let channelReplySent = false;
  let channelReplyPayload = null;
  const mockBotUser = { id: '100000000000000001', username: 'Tungsten', displayAvatarURL: () => 'https://example.com/bot.png' };
  const mockStandaloneTagMsg = {
    id: 'msg_standalone_ping',
    content: '<@100000000000000001>',
    cleanContent: '@Tungsten',
    url: 'https://discord.com/channels/123/456/101',
    createdAt: new Date(),
    createdTimestamp: Date.now(),
    author: {
      id: 'author_standalone_777',
      username: 'Alice',
      displayName: 'Alice In Wonderland',
      bot: false,
      send: async () => {}
    },
    guild: {
      id: testGuildId,
      name: 'Tungsten Test Guild',
      iconURL: () => null
    },
    channel: {
      id: 'chan_456',
      name: 'general'
    },
    mentions: {
      users: new Map([['100000000000000001', mockBotUser]])
    },
    reply: async (payload) => {
      channelReplySent = true;
      channelReplyPayload = payload;
    }
  };

  const clientWithCommands = {
    ...mockClient,
    user: mockBotUser,
    commands: new Map(),
    aliases: new Map(),
    config: {
      DEFAULT_PREFIX: '!',
      COLORS: { PRIMARY: 0x5865F2, DANGER: 0xFF0000, SUCCESS: 0x00FF00, INFO: 0x5865F2 }
    }
  };

  await messageCreateEvent.execute(mockStandaloneTagMsg, clientWithCommands);
  assert.strictEqual(channelReplySent, true, 'Channel reply should be sent for standalone tag');
  assert.ok(channelReplyPayload.embeds.length > 0, 'Standalone tag must have embed');
  assert.ok(channelReplyPayload.components.length > 0, 'Standalone tag must have buttons');
  const tagEmbed = channelReplyPayload.embeds[0];
  assert.ok(tagEmbed.data.title.includes('Hello Alice In Wonderland!'));
  assert.ok(tagEmbed.data.description.includes('My command prefix in **Tungsten Test Guild** is `!`'));
  assert.strictEqual(channelReplyPayload.components[0].components[0].data.label, 'Command Hub');
  console.log('✅ messageCreate standalone bot tag delivers pristine channel reply with Command Hub button.');

  // 9. Test bot tagged with text or other users (no unhandled exceptions)
  let conversationalMsgReplied = false;
  const mockConversationalMsg = {
    id: 'msg_conv_tag',
    content: '<@100000000000000001> <@888888888888> what do you think of this?',
    cleanContent: '@Tungsten @Target what do you think of this?',
    url: 'https://discord.com/channels/123/456/102',
    createdAt: new Date(),
    createdTimestamp: Date.now(),
    author: {
      id: 'author_standalone_777',
      username: 'Alice',
      bot: false,
      send: async () => {}
    },
    guild: {
      id: testGuildId,
      name: 'Tungsten Test Guild',
      iconURL: () => null
    },
    channel: {
      id: 'chan_456',
      name: 'general',
      permissionsFor: () => ({ has: () => true })
    },
    mentions: {
      users: new Map([
        ['100000000000000001', mockBotUser],
        ['888888888888', mockTargetUser]
      ])
    },
    reply: async () => {
      conversationalMsgReplied = true;
    }
  };
  await messageCreateEvent.execute(mockConversationalMsg, clientWithCommands);
  console.log('✅ messageCreate bot tagged with other users/text executed cleanly without unhandled exceptions.');
}

testDispatcher().then(() => {
  console.log('✅ pings.test.js PASSED with 0 errors!\n');
}).catch(err => {
  console.error('❌ pings.test.js failed:', err);
  process.exit(1);
});
