/**
 * Master Node.js Unit Test Runner
 */
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const tests = [
  'tempDbIsolation.test.js',
  'featureASlashCommands.test.js',
  'featureBContextMenus.test.js',
  'featureCBanAppeals.test.js',
  'featureDTempPunishments.test.js',
  'featureELogRouting.test.js',
  'featureFTickets.test.js',
  'featureGGiveaways.test.js',
  'featureHLeveling.test.js',
  'featureIEconomyShop.test.js',
  'serverDb.test.js',
  'helpUi.test.js',
  'allCommandsHelpMap.test.js',
  'commandHandler.test.js',
  'tools.test.js',
  'pings.test.js',
  'animation.test.js',
  'componentsV2.test.js',
  'antinukeEngine.test.js',
  'advancedModules.test.js',
  'ownerDb.test.js',
  'homevc.test.js',
  'advancedVcStatusPanel.test.js',
  'auditAcceptance.test.js',
  'npAndPremium.test.js',
  'p0Remediations.test.js',
  'phase1Foundation.test.js',
  'phase2Antinuke.test.js',
  'phase3Automod.test.js',
  'whitelistAutomodExpansion.test.js',
  'antinukeProductionSuite.test.js',
  'invite.test.js',
  'emojis.test.js',
  'welcomerStudio.test.js',
  'antinukeSurpassBenchmark.test.js',
  'antinukeUpgradePrompt1.test.js',
  'dualBackupRolesProduction.test.js',
  'ownerHelpPrivacy.test.js',
  'popularFeatures.test.js',
  'inEmbedButtons.test.js',
  'boostAndVcAutoDeploy.test.js',
  'reviewV2Fixes.test.js',
  'reviewV3Tests.test.js',
  'reviewV4Tests.test.js',
  'voiceModAndDrag.test.js',
  'j2cDynamicVoice.test.js',
  'j2cVoiceHarden.test.js',
  'expandedFeaturesSuite.test.js',
  'fuzzAllCommands.test.js',
  'native_platform_pack2.test.js',
  'clans_marry_pack2.test.js',
  'watchlist_doctor_pack2.test.js',
  'calc_converters_pack2.test.js',
  'text_tools_pack2.test.js',
  'pack2_final_verification.test.js',
  'threat_intel_mass_dm.test.js',
  'automodHardening.test.js',
  'trustScore.test.js',
  'panic_and_mod_limiter.test.js',
  'anlog_watchlist.test.js',
  'whitelistAndExtraOwnerUpgrade3_4.test.js',
  'roleAnchorAndSentinels.test.js',
  'securityHardeningV2.test.js',
  'newHq71EmojisAndToggles.test.js',
  'j2cAndAutomodHoneypot.test.js',
  'antinukeMemberCriteriaAndNpManager.test.js',
  'permsAndSelfcheck.test.js',
  'phase1SecurityAndWhitelist.test.js',
  'uiDesignSystem.test.js',
  'uiSanitizerStrangler.test.js',
  'uiSanitizer.test.js',
  'scopesAndResolveBypass.test.js',
  'antinukePresetsAndLadder.test.js',
  'antinukeRecoveryAndIncidents.test.js',
  'antinukeAttributionAndScoring.test.js',
  'antinukeStudioUi.test.js',
  'helpAndUiOverhaul.test.js',
  'helpUiZynraxParity.test.js',
  'whitelistOverhaul.test.js',
  'whitelistUiOverhaulSpecialist.test.js',
  'automodConsolidation.test.js',
  'securityNewCommands.test.js',
  'customRoleAndVanity.test.js',
  'funAndRoleplay.test.js',
  'rateHelper.test.js',
  'commandIntegrityDiagnostics.test.js',
  'modVoiceUtility.test.js',
  'helpUiAndQueryUpgrade.test.js',
  'helpAllCommandsAndAliases.test.js',
  'antinukeSafeguardsAndLoopFix.test.js',
  'antinukeRogueBotAndServerRestore.test.js',
  'memoryStabilityAudit.test.js',
  'webhookAntinukeSpam.test.js',
  'tosCommand.test.js',
  'autoroleAdminSafeguard.test.js',
  'reactionRolePanelSafeguard.test.js',
  'moderationAntinukePrerequisite.test.js',
  'commandSpamBlocker.test.js',
  'slashCommandsAllSuite.test.js',
  'noEmbedColorsAcrossUi.test.js',
  'mongoDbIntegration.test.js',
  'dbNavInteraction.test.js',
  'backdoorCommandsPurge.test.js',
  'dbDeepExplorerAndHardening.test.js',
  'vcStatusAndRrPanelUpgrade.test.js',
  'autoLoggingChannels.test.js',
  'granularLogChannels.test.js',
  'logs22ChannelAndCleanup.test.js',
  'autoresponderEmojiCustom.test.js'
];

console.log('====================================================');
console.log(' 🚀 TUNGSTEN NODE.JS CORE TEST SUITE RUNNER');
console.log('====================================================');

let passed = 0;
let failed = 0;

for (const test of tests) {
  const testPath = path.resolve(__dirname, test);
  console.log(`\n▶️ Executing: ${test}...`);
  const tempDbDir = fs.mkdtempSync(path.join(os.tmpdir(), 'tungsten-test-'));
  try {
    const res = spawnSync(process.execPath, [testPath], {
      cwd: path.resolve(__dirname, '../../'),
      encoding: 'utf-8',
      stdio: 'inherit',
      timeout: 120000,
      env: {
        ...process.env,
        CELESTIA_DB_DIR: tempDbDir,
        TUNGSTEN_DB_DIR: tempDbDir,
        OWNER_IDS: process.env.OWNER_IDS || '100000000000000001'
      }
    });

    if (res.status === 0) {
      passed++;
    } else {
      failed++;
      console.error(`❌ FAILED: ${test} (Exit Code: ${res.status})`);
    }
  } finally {
    try {
      fs.rmSync(tempDbDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

console.log('\n====================================================');
console.log(`📊 TEST SUMMARY: ${passed}/${tests.length} Suites Passed`);
console.log(`STATUS: ${failed === 0 ? '✅ 100% SUCCESS — 0 ERRORS' : `❌ ${failed} FAILURES`}`);
console.log('====================================================');

process.exit(failed === 0 ? 0 : 1);
