/**
 * Advanced Modules Test Suite (Node.js)
 * Verifies Verification Gate, Reaction Roles, Sticky Notices, Custom Commands,
 * Ghostping Sentinel, Leveling & XP, Staff Duty, and Dual Backup Roles.
 */
const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { getServerDb, ensureServerDatabase, getServerDir } = require('../../src/utils/serverDb');
const { storeGhostpingCandidate, retrieveAndEvictGhostping } = require('../../src/utils/ghostpingCache');
const { formatPlaceholders } = require('../../src/utils/placeholders');
const { ensureDualBackupRoles } = require('../../src/utils/antinukeEngine');

async function runTests() {
  console.log('[TEST] Running advancedModules.test.js...');

  const TEST_GUILD_ID = '999888777111';
  const serverDir = getServerDir(TEST_GUILD_ID);
  if (fs.existsSync(serverDir)) {
    fs.rmSync(serverDir, { recursive: true, force: true });
  }

  ensureServerDatabase(TEST_GUILD_ID, 'AdvTestGuild', '100000000000000001', false);
  const sdb = getServerDb(TEST_GUILD_ID);

  // 1. Verification Gate Storage & Lookup
  sdb.prepare(`
    INSERT INTO verification_settings (guild_id, enabled, role_id, channel_id, mode)
    VALUES (?, 1, 'role_verified_123', 'ch_verify_456', 'button')
    ON CONFLICT(guild_id) DO UPDATE SET enabled = 1, role_id = excluded.role_id
  `).run(TEST_GUILD_ID);

  const vRow = sdb.prepare('SELECT * FROM verification_settings WHERE guild_id = ?').get(TEST_GUILD_ID);
  assert.strictEqual(vRow.enabled, 1);
  assert.strictEqual(vRow.role_id, 'role_verified_123');
  console.log('✅ Verification Gateway schema and persistence verified.');

  // 2. Reaction Roles Storage & Query
  sdb.prepare(`
    INSERT INTO reaction_roles (guild_id, message_id, channel_id, emoji, role_id)
    VALUES (?, 'msg_rr_1', 'ch_rr_1', '🎮:Gamer', 'role_gamer_999')
  `).run(TEST_GUILD_ID);

  const rrRows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(TEST_GUILD_ID);
  assert.strictEqual(rrRows.length, 1);
  assert.strictEqual(rrRows[0].role_id, 'role_gamer_999');
  console.log('✅ Reaction Roles schema and mapping verified.');

  // 3. Custom Commands & Placeholders
  sdb.prepare(`
    INSERT INTO custom_commands (guild_id, name, content, created_by, created_at)
    VALUES (?, 'testcmd', 'Hello {user.name} in {server.name}!', 'user_1', 1000)
  `).run(TEST_GUILD_ID);

  const ccRow = sdb.prepare('SELECT content FROM custom_commands WHERE guild_id = ? AND name = ?').get(TEST_GUILD_ID, 'testcmd');
  assert.strictEqual(ccRow.content, 'Hello {user.name} in {server.name}!');

  const mockMember = { user: { username: 'Ares', tag: 'Ares#0001' }, displayName: 'Ares' };
  const mockGuild = { name: 'Celestia Citadel', memberCount: 1500 };
  const replaced = formatPlaceholders(ccRow.content, mockMember, mockGuild);
  assert.strictEqual(replaced, 'Hello Ares in Celestia Citadel!');
  console.log('✅ Custom Commands storage and placeholder substitution verified.');

  // 4. Sticky Messages Storage & Rotation
  sdb.prepare(`
    INSERT INTO sticky_messages (channel_id, guild_id, content, last_message_id)
    VALUES ('ch_rules_01', ?, 'Welcome! Please adhere to the server rules.', 'msg_old_11')
  `).run(TEST_GUILD_ID);

  const stickyRow = sdb.prepare('SELECT * FROM sticky_messages WHERE channel_id = ?').get('ch_rules_01');
  assert.strictEqual(stickyRow.last_message_id, 'msg_old_11');

  sdb.prepare('UPDATE sticky_messages SET last_message_id = ? WHERE channel_id = ?').run('msg_new_22', 'ch_rules_01');
  const stickyUpdated = sdb.prepare('SELECT last_message_id FROM sticky_messages WHERE channel_id = ?').get('ch_rules_01');
  assert.strictEqual(stickyUpdated.last_message_id, 'msg_new_22');
  console.log('✅ Sticky Message persistence and pointer rotation verified.');

  // 5. Anti-Ghostping In-Memory Cache
  const mockMsg = {
    id: 'msg_ping_333',
    guild: { id: TEST_GUILD_ID },
    channel: { id: 'ch_general_1' },
    author: { id: 'user_spammer', bot: false, username: 'Spammer', tag: 'Spammer#1111' },
    mentions: {
      users: new Map([
        ['target_victim', { id: 'target_victim', bot: false, tag: 'Victim#2222', username: 'Victim' }]
      ])
    },
    content: 'Ghost ping <@target_victim> haha'
  };

  storeGhostpingCandidate(mockMsg);
  const evicted = retrieveAndEvictGhostping('msg_ping_333');
  assert.ok(evicted !== null);
  assert.strictEqual(evicted.authorId, 'user_spammer');
  assert.strictEqual(evicted.mentions.length, 1);
  assert.strictEqual(evicted.mentions[0].id, 'target_victim');

  // Verify eviction guarantees single interception
  const secondRetrieve = retrieveAndEvictGhostping('msg_ping_333');
  assert.strictEqual(secondRetrieve, null);
  console.log('✅ Anti-Ghostping candidate caching and atomic eviction verified.');

  // 6. Leveling & XP Calculations
  sdb.prepare(`
    INSERT INTO leveling_users (guild_id, user_id, xp, level, last_xp_time)
    VALUES (?, 'member_active', 100, 1, 500)
  `).run(TEST_GUILD_ID);

  const lvlRow = sdb.prepare('SELECT * FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(TEST_GUILD_ID, 'member_active');
  assert.strictEqual(lvlRow.level, 1);
  assert.strictEqual(lvlRow.xp, 100);

  // level formula test: level = floor(0.1 * sqrt(xp))
  // for xp = 400 => sqrt(400) = 20 => 0.1 * 20 = 2
  const calcLvl = Math.floor(0.1 * Math.sqrt(400));
  assert.strictEqual(calcLvl, 2);
  console.log('✅ Leveling & XP calculation formulas verified.');

  // 7. Staff Duty Shifts
  sdb.prepare(`
    INSERT INTO staff_duty (guild_id, user_id, on_duty, started_at)
    VALUES (?, 'mod_apollo', 1, 1000)
  `).run(TEST_GUILD_ID);

  const dutyRow = sdb.prepare('SELECT * FROM staff_duty WHERE guild_id = ? AND user_id = ?').get(TEST_GUILD_ID, 'mod_apollo');
  assert.strictEqual(dutyRow.on_duty, 1);
  assert.strictEqual(dutyRow.started_at, 1000);
  console.log('✅ Staff Duty shift logging verified.');

  // 8. Dual Backup Roles Safeguard
  const mockRoles = new Map();
  const mockGuildWithMe = {
    id: TEST_GUILD_ID,
    roles: {
      cache: {
        find: (fn) => Array.from(mockRoles.values()).find(fn)
      },
      create: async (data) => {
        const newRole = { id: `role_backup_${Date.now()}_${mockRoles.size}`, name: data.name, permissions: data.permissions };
        mockRoles.set(newRole.id, newRole);
        return newRole;
      }
    },
    members: {
      me: {
        permissions: { has: () => true },
        roles: {
          cache: new Map(),
          add: async (role) => {
            mockGuildWithMe.members.me.roles.cache.set(role.id, role);
          }
        }
      }
    }
  };

  // Enable opt-in dual backup roles for test
  sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('backup_roles_enabled', '1')").run();

  const backupResult = await ensureDualBackupRoles(mockGuildWithMe);
  assert.strictEqual(backupResult.success, true);
  assert.strictEqual(backupResult.roles.length, 2);
  assert.strictEqual(mockGuildWithMe.members.me.roles.cache.size, 2);

  // Check stored in server_settings
  const b1 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_1'").get();
  const b2 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_2'").get();
  assert.ok(b1 && b1.value);
  assert.ok(b2 && b2.value);
  console.log('✅ Dual Backup Roles Safeguard (Tier I & II) anchoring verified.');

  // Cleanup test database
  if (fs.existsSync(serverDir)) {
    fs.rmSync(serverDir, { recursive: true, force: true });
  }
  console.log('✅ advancedModules.test.js PASSED with 0 errors!\n');
}

if (require.main === module) {
  runTests()
    .then(() => process.exit(0))
    .catch(err => {
      console.error('❌ advancedModules.test.js failed:', err);
      process.exit(1);
    });
}

module.exports = { runTests };
