/**
 * Welcomer & Leave Studio Automated Unit Test Suite
 * Validates Components V2 Studio panels, Modal dialogues, Select menus,
 * Database synchronization, Subcommand execution, and Zero Default Emoji invariants.
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');

const {
  getWelcomeConfig,
  saveWelcomeConfig,
  buildWelcomeStudioPayload,
  buildWelcomePreviewCard,
  execute: executeWelcome
} = require('../../src/commands/welcomer/welcome');

const {
  getLeaveConfig,
  saveLeaveConfig,
  buildLeaveStudioPayload,
  buildLeavePreviewCard,
  execute: executeLeave
} = require('../../src/commands/welcomer/leave');

const welcomerInteraction = require('../../src/interactions/welcomer');

console.log('[TEST] Starting welcomerStudio.test.js...');

const testGuildId = '999888777666555444';
const mockGuild = {
  id: testGuildId,
  name: 'Celestia Citadel',
  memberCount: 1420,
  iconURL: () => 'https://cdn.discordapp.com/icons/celestia.png',
  channels: {
    cache: {
      get: (id) => (id === '111222333444555666' ? { id, name: 'welcome-hub', toString: () => `<#${id}>` } : null)
    }
  }
};

const mockMember = {
  id: '100000000000000001',
  user: {
    id: '100000000000000001',
    username: 'CelestiaAdmin',
    tag: 'CelestiaAdmin#0001',
    displayAvatarURL: () => 'https://cdn.discordapp.com/avatars/admin.png'
  },
  guild: mockGuild,
  permissions: {
    has: () => true
  },
  toString: () => '<@100000000000000001>'
};

// ─────────────────────────────────────────────────────────────
// 1. Welcome Database Schema & Persistence
// ─────────────────────────────────────────────────────────────
console.log('▶️ Testing Welcome Config persistence...');
const initWelcome = getWelcomeConfig(testGuildId);
assert.strictEqual(initWelcome.guild_id, testGuildId, 'guild_id matches');

saveWelcomeConfig(testGuildId, {
  status: 1,
  channel_id: '111222333444555666',
  cv2_title: 'Welcome to the Citadel of {server.name}!',
  cv2_description: 'Greetings {user.mention}! You are member #{memberCount}.',
  cv2_banner: 'https://cdn.discordapp.com/banners/welcome.png',
  cv2_thumbnail: 'avatar',
  dm_enabled: 1,
  dm_message: 'Welcome {user.name} to {server.name}!'
});

const updatedWelcome = getWelcomeConfig(testGuildId);
assert.strictEqual(updatedWelcome.status, 1, 'Welcome status is 1');
assert.strictEqual(updatedWelcome.channel_id, '111222333444555666', 'Channel ID persists');
assert.strictEqual(updatedWelcome.cv2_title, 'Welcome to the Citadel of {server.name}!', 'Title persists');
assert.strictEqual(updatedWelcome.cv2_banner, 'https://cdn.discordapp.com/banners/welcome.png', 'Banner persists');
assert.strictEqual(updatedWelcome.dm_enabled, 1, 'DM enabled persists');
console.log('✅ Welcome Config persistence verified.');

// ─────────────────────────────────────────────────────────────
// 2. Leave Database Schema & Persistence
// ─────────────────────────────────────────────────────────────
console.log('▶️ Testing Leave Config persistence...');
saveLeaveConfig(testGuildId, {
  status: true,
  channel_id: '111222333444555666',
  title: 'Farewell from {server.name}',
  message: '**{user.name}** left the server. Population: {memberCount}',
  banner: 'https://cdn.discordapp.com/banners/leave.png',
  thumbnail: 'server'
});

const updatedLeave = getLeaveConfig(testGuildId);
assert.strictEqual(updatedLeave.status, true, 'Leave status is true');
assert.strictEqual(updatedLeave.channel_id, '111222333444555666', 'Leave channel persists');
assert.strictEqual(updatedLeave.title, 'Farewell from {server.name}', 'Leave title persists');
assert.strictEqual(updatedLeave.banner, 'https://cdn.discordapp.com/banners/leave.png', 'Leave banner persists');
assert.strictEqual(updatedLeave.thumbnail, 'server', 'Leave thumbnail persists');
console.log('✅ Leave Config persistence verified.');

// ─────────────────────────────────────────────────────────────
// 3. Welcome Studio Payload Structure
// ─────────────────────────────────────────────────────────────
console.log('▶️ Testing Welcome Studio payload layout...');
const welcomePayload = buildWelcomeStudioPayload(mockGuild, updatedWelcome, '!', 'CelestiaAdmin');
assert.ok(welcomePayload.embeds && welcomePayload.embeds.length === 1, 'Has 1 card embed');
assert.ok(welcomePayload.components && welcomePayload.components.length === 4, 'Has exactly 4 ActionRows');

// Row 0: Channel Select
const row0 = welcomePayload.components[0].components[0];
assert.strictEqual(row0.data.custom_id, 'welcome:select_channel', 'Row 0 is ChannelSelectMenu');

// Row 1: Thumbnail Select
const row1 = welcomePayload.components[1].components[0];
assert.strictEqual(row1.data.custom_id, 'welcome:select_thumbnail', 'Row 1 is Thumbnail StringSelectMenu');
assert.strictEqual(row1.options.length, 4, '4 thumbnail options available (avatar, server, none, custom)');

// Row 2: Customization Buttons
const row2Buttons = welcomePayload.components[2].components.map(b => b.data.custom_id);
assert.deepStrictEqual(
  row2Buttons,
  ['welcome:edit_content', 'welcome:edit_media', 'welcome:edit_dm', 'welcome:preview'],
  'Row 2 customization buttons verified'
);

// Row 3: Control Buttons
const row3Buttons = welcomePayload.components[3].components.map(b => b.data.custom_id);
assert.deepStrictEqual(
  row3Buttons,
  ['welcome:toggle_status', 'welcome:toggle_dm', 'welcome:test', 'welcome:reset', 'cmd_dismiss'],
  'Row 3 control buttons verified'
);
console.log('✅ Welcome Studio payload layout verified.');

// ─────────────────────────────────────────────────────────────
// 4. Leave Studio Payload Structure
// ─────────────────────────────────────────────────────────────
console.log('▶️ Testing Leave Studio payload layout...');
const leavePayload = buildLeaveStudioPayload(mockGuild, updatedLeave, '!', 'CelestiaAdmin');
assert.ok(leavePayload.embeds && leavePayload.embeds.length === 1, 'Has 1 card embed');
assert.ok(leavePayload.components && leavePayload.components.length === 4, 'Has exactly 4 ActionRows');

const leaveRow0 = leavePayload.components[0].components[0];
assert.strictEqual(leaveRow0.data.custom_id, 'leave:select_channel', 'Row 0 is Leave ChannelSelectMenu');

const leaveRow1 = leavePayload.components[1].components[0];
assert.strictEqual(leaveRow1.data.custom_id, 'leave:select_thumbnail', 'Row 1 is Leave Thumbnail StringSelectMenu');

const leaveRow2Buttons = leavePayload.components[2].components.map(b => b.data.custom_id);
assert.deepStrictEqual(
  leaveRow2Buttons,
  ['leave:edit_content', 'leave:edit_media', 'leave:preview', 'leave:test'],
  'Row 2 leave customization buttons verified'
);

const leaveRow3Buttons = leavePayload.components[3].components.map(b => b.data.custom_id);
assert.deepStrictEqual(
  leaveRow3Buttons,
  ['leave:toggle_status', 'leave:reset', 'cmd_dismiss'],
  'Row 3 leave control buttons verified'
);
console.log('✅ Leave Studio payload layout verified.');

// ─────────────────────────────────────────────────────────────
// 5. Live Preview Card Builders
// ─────────────────────────────────────────────────────────────
console.log('▶️ Testing Preview Card Builders...');
const welcomeCard = buildWelcomePreviewCard(mockGuild, mockMember, updatedWelcome);
assert.strictEqual(welcomeCard.data.title, 'Welcome to the Citadel of Celestia Citadel!', 'Formatted welcome title');
assert.ok(welcomeCard.data.description.includes('Greetings <@100000000000000001>'), 'Formatted welcome mention');
assert.ok(welcomeCard.data.description.includes('1420'), 'Formatted welcome member count');
assert.strictEqual(welcomeCard.data.image.url, 'https://cdn.discordapp.com/banners/welcome.png', 'Banner image URL verified');
assert.strictEqual(welcomeCard.data.thumbnail.url, 'https://cdn.discordapp.com/avatars/admin.png', 'Thumbnail URL verified');

const leaveCard = buildLeavePreviewCard(mockGuild, mockMember, updatedLeave);
assert.strictEqual(leaveCard.data.title, 'Farewell from Celestia Citadel', 'Formatted leave title');
assert.ok(leaveCard.data.description.includes('CelestiaAdmin'), 'Formatted leave username');
assert.strictEqual(leaveCard.data.image.url, 'https://cdn.discordapp.com/banners/leave.png', 'Leave banner image URL verified');
assert.strictEqual(leaveCard.data.thumbnail.url, 'https://cdn.discordapp.com/icons/celestia.png', 'Leave server thumbnail URL verified');
console.log('✅ Preview Card Builders verified.');

// ─────────────────────────────────────────────────────────────
// 6. Subcommand Execution Handlers
// ─────────────────────────────────────────────────────────────
console.log('▶️ Testing Subcommand Execution Handlers...');
let repliedMsg = null;
const mockMsg = {
  guild: mockGuild,
  member: mockMember,
  author: mockMember.user,
  reply: (content) => { repliedMsg = content; return Promise.resolve(content); },
  attachments: { first: () => null }
};

// Test welcome subcommands
executeWelcome(mockMsg, ['title', 'New Welcome Title'], {}, '!');
let cfg = getWelcomeConfig(testGuildId);
assert.strictEqual(cfg.cv2_title, 'New Welcome Title', 'welcome title updated');

executeWelcome(mockMsg, ['message', 'New welcome description {user}'], {}, '!');
cfg = getWelcomeConfig(testGuildId);
assert.strictEqual(cfg.cv2_description, 'New welcome description {user}', 'welcome message updated');

executeWelcome(mockMsg, ['banner', 'https://example.com/newbanner.png'], {}, '!');
cfg = getWelcomeConfig(testGuildId);
assert.strictEqual(cfg.cv2_banner, 'https://example.com/newbanner.png', 'welcome banner updated');

executeWelcome(mockMsg, ['thumbnail', 'none'], {}, '!');
cfg = getWelcomeConfig(testGuildId);
assert.strictEqual(cfg.cv2_thumbnail, 'none', 'welcome thumbnail updated');

// Test leave subcommands
executeLeave(mockMsg, ['title', 'New Leave Title'], {}, '!');
let lcfg = getLeaveConfig(testGuildId);
assert.strictEqual(lcfg.title, 'New Leave Title', 'leave title updated');

executeLeave(mockMsg, ['message', 'Farewell {user.name}!'], {}, '!');
lcfg = getLeaveConfig(testGuildId);
assert.strictEqual(lcfg.message, 'Farewell {user.name}!', 'leave message updated');

executeLeave(mockMsg, ['banner', 'https://example.com/newleave.png'], {}, '!');
lcfg = getLeaveConfig(testGuildId);
assert.strictEqual(lcfg.banner, 'https://example.com/newleave.png', 'leave banner updated');
console.log('✅ Subcommand Execution Handlers verified.');

// ─────────────────────────────────────────────────────────────
// 7. Welcomer Interaction Router
// ─────────────────────────────────────────────────────────────
console.log('▶️ Testing Welcomer Interaction Router...');
assert.deepStrictEqual(welcomerInteraction.prefixes, ['welcome', 'leave'], 'Prefixes registered');

// Test modal submission for welcome content
let updatedPayload = null;
const mockModalInteraction = {
  customId: 'welcome:modal_content',
  guild: mockGuild,
  member: mockMember,
  user: mockMember.user,
  fields: {
    getTextInputValue: (field) => {
      if (field === 'cv2_title') return 'Modal Welcome Title';
      if (field === 'cv2_description') return 'Modal Welcome Description';
      return '';
    }
  },
  update: (p) => { updatedPayload = p; return Promise.resolve(p); }
};

(async () => {
  const handled = await welcomerInteraction.handle(mockModalInteraction, {});
  assert.strictEqual(handled, true, 'Interaction handled');
  const modalCfg = getWelcomeConfig(testGuildId);
  assert.strictEqual(modalCfg.cv2_title, 'Modal Welcome Title', 'Modal title persisted');
  assert.strictEqual(modalCfg.cv2_description, 'Modal Welcome Description', 'Modal description persisted');
  console.log('✅ Welcomer Interaction Router verified.');

  // ─────────────────────────────────────────────────────────────
  // 8. Zero Unicode Emoji Check
  // ─────────────────────────────────────────────────────────────
  console.log('▶️ Testing Zero Unicode Emojis in welcomer files...');
  const filesToCheck = [
    path.resolve(__dirname, '../../src/commands/welcomer/welcome.js'),
    path.resolve(__dirname, '../../src/commands/welcomer/leave.js'),
    path.resolve(__dirname, '../../src/interactions/welcomer.js')
  ];

  const rawUnicodeRegex = /[\u{1F300}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u;
  for (const f of filesToCheck) {
    const content = fs.readFileSync(f, 'utf8');
    const lines = content.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      // Skip comments that describe unicode removal
      if (line.includes('//') && (line.includes('unicode') || line.includes('emoji'))) continue;
      const match = line.match(rawUnicodeRegex);
      if (match) {
        assert.fail(`Raw unicode emoji found in ${path.basename(f)} line ${i + 1}: ${match[0]}`);
      }
    }
  }
  console.log('✅ Zero raw unicode emojis verified across welcomer files.');

  console.log('\n====================================================');
  console.log('🎉 welcomerStudio.test.js PASSED with 0 errors!');
  console.log('====================================================');
  process.exit(0);
})().catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
