/**
 * Test Suite: Phase 2 Antinuke 3.0 & Anti-Raid (§7.1, §7.2, §8, §25)
 * Tests:
 * 1. Permission-escalation detection & instant revert on roleUpdate (§7.1)
 * 2. Instant channel overwrite tampering revert on channelUpdate (§7.1)
 * 3. Gateway guildAuditLogEntryCreate push caching & zero-latency resolveAuditExecutor (§25)
 * 4. Bot-add protection audit verification & unattributed kick on guildMemberAdd (§7.2)
 * 5. Anti-Raid join-velocity detection and config suite (§8)
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const { PermissionsBitField, AuditLogEvent } = require('discord.js');
const { getServerDb } = require('../../src/utils/serverDb');
const {
  isAntinukeArmed,
  resolveAuditExecutor,
  recordAuditLogEntry,
  _AUDIT_LOG_PUSH_CACHE,
  checkRateLimitExceeded
} = require('../../src/utils/antinukeEngine');
const roleUpdate = require('../../src/events/roleUpdate');
const channelUpdate = require('../../src/events/channelUpdate');
const guildAuditLogEntryCreate = require('../../src/events/guildAuditLogEntryCreate');
const antiraidCmd = require('../../src/commands/security/antiraid');

async function runTests() {
  console.log('[TEST] Running phase2Antinuke.test.js...');
  const testGid = '888777666555444';
  const sdb = getServerDb(testGid);

  // Arm antinuke for test guild
  sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('antinuke_status', '1')").run();
  assert.strictEqual(isAntinukeArmed(testGid), true, 'Antinuke must be armed');

  // ─────────────────────────────────────────────────────────────
  // 1. Gateway guildAuditLogEntryCreate Push Caching (§25)
  // ─────────────────────────────────────────────────────────────
  const mockEntry = {
    id: '999111222333444',
    guildId: testGid,
    action: AuditLogEvent.RoleUpdate,
    targetId: '555444333222111',
    createdTimestamp: Date.now(),
    executor: { id: '444333222111000', username: 'Attacker' }
  };

  // Dispatch gateway event
  await guildAuditLogEntryCreate.execute(mockEntry, { id: testGid });
  assert.ok(_AUDIT_LOG_PUSH_CACHE.has(mockEntry.id), 'Push entry must be cached in memory');

  // Verify resolveAuditExecutor fast-path zero-latency resolution
  const mockGuild = {
    id: testGid,
    members: {
      me: {
        permissions: new PermissionsBitField(PermissionsBitField.Flags.ViewAuditLog),
        roles: { highest: { position: 100 } }
      }
    }
  };
  const resolvedExecutor = await resolveAuditExecutor(mockGuild, AuditLogEvent.RoleUpdate, { targetId: '555444333222111' });
  assert.ok(resolvedExecutor, 'Executor must be resolved via fast-path cache');
  assert.strictEqual(resolvedExecutor.id, '444333222111000');
  console.log('✅ Gateway guildAuditLogEntryCreate (§25) zero-latency push resolution verified.');

  // ─────────────────────────────────────────────────────────────
  // 2. Permission-escalation detection & instant revert (§7.1)
  // ─────────────────────────────────────────────────────────────
  let revertedPerms = null;
  const oldRole = {
    id: '555444333222111',
    name: 'MemberRole',
    guild: mockGuild,
    permissions: new PermissionsBitField(PermissionsBitField.Flags.SendMessages)
  };
  const newRole = {
    id: '555444333222111',
    name: 'MemberRole',
    guild: mockGuild,
    permissions: new PermissionsBitField([PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.Administrator]),
    setPermissions: async (perms, reason) => {
      revertedPerms = perms;
    }
  };

  // Mock punishment dependencies
  mockGuild.members.fetch = async (id) => ({
    id,
    roles: { highest: { position: 10 }, set: async () => true },
    kick: async () => true,
    bannable: true,
    moderatable: true
  });
  mockGuild.roles = { everyone: { id: testGid } };

  await roleUpdate.execute(oldRole, newRole, { config: { COLORS: { DANGER: 0xFF0000 } } });
  assert.ok(revertedPerms, 'Role permissions must be immediately reverted');
  assert.strictEqual(revertedPerms.has(PermissionsBitField.Flags.Administrator), false, 'Reverted permissions must not contain Administrator');
  console.log('✅ Permission-escalation detection & instant revert (§7.1) verified on roleUpdate.');

  // Zero-day @everyone check:
  let everyoneReverted = false;
  const oldEveryone = { id: testGid, guild: mockGuild, permissions: new PermissionsBitField(0n) };
  const newEveryone = {
    id: testGid,
    guild: mockGuild,
    permissions: new PermissionsBitField(PermissionsBitField.Flags.ManageChannels),
    setPermissions: async () => { everyoneReverted = true; }
  };
  await roleUpdate.execute(oldEveryone, newEveryone, { config: { COLORS: { DANGER: 0xFF0000 } } });
  assert.strictEqual(everyoneReverted, true, 'Dangerous permission added to @everyone must be instantly reverted');
  console.log('✅ Zero-day @everyone permission guard verified.');

  // ─────────────────────────────────────────────────────────────
  // 3. Channel Overwrite Tampering Immediate Revert (§7.1)
  // ─────────────────────────────────────────────────────────────
  let channelOverwritesReverted = false;
  const oldPo = new Map([
    ['role1', { id: 'role1', type: 0, allow: new PermissionsBitField(0n), deny: new PermissionsBitField(0n) }]
  ]);
  const newPo = new Map([
    ['role1', { id: 'role1', type: 0, allow: new PermissionsBitField(PermissionsBitField.Flags.MentionEveryone), deny: new PermissionsBitField(0n) }]
  ]);

  const oldChannel = {
    name: 'general',
    guild: mockGuild,
    permissionOverwrites: { cache: oldPo }
  };
  const newChannel = {
    id: 'chan999',
    name: 'general',
    guild: mockGuild,
    permissionOverwrites: {
      cache: newPo,
      set: async () => { channelOverwritesReverted = true; }
    }
  };

  // Push an audit log entry for this channel overwrite update
  recordAuditLogEntry({
    id: 'entry_chan_999',
    guildId: testGid,
    action: AuditLogEvent.ChannelOverwriteUpdate,
    targetId: 'chan999',
    createdTimestamp: Date.now(),
    executor: { id: '444333222111000', username: 'Attacker' }
  });

  await channelUpdate.execute(oldChannel, newChannel, { config: { COLORS: { DANGER: 0xFF0000 } } });
  assert.strictEqual(channelOverwritesReverted, true, 'Channel overwrites must be immediately restored to safe state');
  console.log('✅ Channel overwrite tampering immediate revert (§7.1) verified on channelUpdate.');

  // ─────────────────────────────────────────────────────────────
  // 4. Anti-Raid Join-Velocity & Config Suite (§8)
  // ─────────────────────────────────────────────────────────────
  // Test sliding-window rate limiter (limit = 8: trips on 8th event)
  const raidKey = 'test_guild_join';
  // Fire 7 allowed joins in window
  for (let i = 0; i < 7; i++) {
    assert.strictEqual(checkRateLimitExceeded(testGid, raidKey, 'raid', 8, 10000), false);
  }
  // 8th join trips limit (8)
  assert.strictEqual(checkRateLimitExceeded(testGid, raidKey, 'raid', 8, 10000), true);
  console.log('✅ Sliding-window join velocity detection (§8) verified.');

  // Test !antiraid CLI controls
  let antiraidReply = null;
  const mockMsg = {
    author: { id: process.env.OWNER_IDS.split(',')[0].trim(), username: 'Owner' },
    member: { permissions: new PermissionsBitField(PermissionsBitField.Flags.ManageGuild) },
    guild: { id: testGid },
    reply: (payload) => { antiraidReply = payload; }
  };

  await antiraidCmd.execute(mockMsg, ['limit', '12'], {}, '!');
  const raidSetting = sdb.prepare('SELECT join_limit, action FROM antiraid_settings WHERE guild_id = ?').get(testGid);
  assert.strictEqual(raidSetting.join_limit, 12, 'Join limit must be updated to 12');

  await antiraidCmd.execute(mockMsg, ['action', 'ban'], {}, '!');
  const raidAction = sdb.prepare('SELECT action FROM antiraid_settings WHERE guild_id = ?').get(testGid);
  assert.strictEqual(raidAction.action, 'ban', 'Action must be updated to ban');
  console.log('✅ Anti-Raid configuration suite verified (limit, action, enable).');

  console.log('✅ phase2Antinuke.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ phase2Antinuke test failed:', err);
  process.exit(1);
});
