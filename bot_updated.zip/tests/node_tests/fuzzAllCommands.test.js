/**
 * Celestia Full 1,730 Commands Fuzzer & Execution Test Suite
 * Automatically executes every registered command across all 17 categories
 * under multiple invocation vectors (0 arguments, sample arguments)
 * ensuring 100% operational execution resilience without unhandled crashes.
 */
const assert = require('node:assert');
const path = require('node:path');
const { Collection, PermissionsBitField, PermissionFlagsBits } = require('discord.js');
const { loadCommands } = require('../../src/handlers/commandHandler');
const { getServerDb } = require('../../src/utils/serverDb');

const TEST_GUILD_ID = '987654321098765432';
const TEST_USER_ID = process.env.OWNER_IDS ? process.env.OWNER_IDS.split(',')[0].trim() : '100000000000000001'; // Primary Bot Owner

async function runFuzzTests() {
  console.log('[TEST] Running fuzzAllCommands.test.js...');

  const mockChannel = {
    id: '111222333444555666',
    name: 'general-chat',
    isTextBased: () => true,
    isVoiceBased: () => false,
    permissionsFor: () => ({
      has: () => true
    }),
    send: async (payload) => ({
      id: 'mock_sent_id',
      ...payload,
      delete: async () => {},
      edit: async (p) => p
    }),
    messages: {
      fetch: async () => new Collection()
    }
  };

  const mockRole = {
    id: '222333444555666777',
    name: 'Administrator',
    position: 10,
    permissions: new PermissionsBitField(PermissionFlagsBits.Administrator),
    setPermissions: async (p) => p
  };

  const mockMember = {
    id: TEST_USER_ID,
    user: { id: TEST_USER_ID, username: 'MasterOwner', tag: 'MasterOwner#0001', bot: false },
    displayName: 'MasterOwner',
    permissions: new PermissionsBitField(PermissionFlagsBits.Administrator),
    roles: {
      cache: new Collection([[mockRole.id, mockRole]]),
      highest: mockRole,
      add: async () => {},
      remove: async () => {}
    },
    voice: {
      channel: null,
      channelId: null
    },
    bannable: false,
    kickable: false
  };

  const mockGuild = {
    id: TEST_GUILD_ID,
    name: 'Celestia Citadel',
    ownerId: TEST_USER_ID,
    memberCount: 42,
    channels: {
      cache: new Collection([[mockChannel.id, mockChannel]]),
      create: async (opts) => ({ id: 'mock_restored_id', ...opts })
    },
    roles: {
      cache: new Collection([[mockRole.id, mockRole]]),
      create: async (opts) => ({ id: 'mock_role_id', ...opts }),
      everyone: { id: TEST_GUILD_ID, permissions: new PermissionsBitField() }
    },
    members: {
      cache: new Collection([[TEST_USER_ID, mockMember]]),
      me: {
        id: '999999999999999999',
        user: { id: '999999999999999999', username: 'Celestia', tag: 'Celestia#0001' },
        displayName: 'Celestia',
        permissions: new PermissionsBitField(PermissionFlagsBits.Administrator),
        roles: {
          cache: new Collection([[mockRole.id, mockRole]]),
          highest: { position: 100 }
        },
        voice: {
          channel: null,
          channelId: null
        }
      },
      fetch: async (id) => mockMember
    },
    bans: {
      create: async () => {},
      remove: async () => {}
    },
    shard: {
      send: () => {}
    }
  };

  const mockClient = {
    commands: new Collection(),
    aliases: new Collection(),
    categories: new Collection(),
    cooldowns: new Collection(),
    config: require('../../src/config'),
    user: {
      id: '999999999999999999',
      tag: 'Celestia#0001',
      username: 'Celestia',
      displayAvatarURL: () => 'https://cdn.discordapp.com/embed/avatars/0.png'
    },
    ws: { ping: 25 },
    guilds: {
      cache: new Collection([[TEST_GUILD_ID, mockGuild]])
    },
    users: {
      cache: new Collection([[TEST_USER_ID, mockMember.user]]),
      fetch: async (id) => mockMember.user
    },
    rest: {
      put: async () => ({})
    }
  };

  // Pre-seed server DB for the test guild
  const sdb = getServerDb(TEST_GUILD_ID);

  // Load all commands
  const commandsDir = path.resolve(__dirname, '../../src/commands');
  loadCommands(mockClient, commandsDir);

  const totalCommands = mockClient.commands.size;
  console.log(`[Fuzzer] Auditing and fuzz-executing all ${totalCommands} commands...`);

  function createMockMessage(cmdName, args) {
    let lastReply = null;
    return {
      id: 'mock_msg_' + Date.now(),
      author: mockMember.user,
      member: mockMember,
      guild: mockGuild,
      channel: mockChannel,
      content: `!${cmdName} ${args.join(' ')}`.trim(),
      mentions: {
        channels: new Collection(),
        members: new Collection(),
        users: new Collection(),
        roles: new Collection()
      },
      reply: async (payload) => {
        lastReply = payload;
        return {
          id: 'mock_reply_id',
          ...payload,
          edit: async (p) => p,
          delete: async () => {},
          awaitMessageComponent: async () => { throw new Error('Timeout in fuzzer mock'); },
          createMessageComponentCollector: () => ({
            on: () => {},
            stop: () => {}
          })
        };
      },
      getLastReply: () => lastReply
    };
  }

  let testedCount = 0;
  let failedCommands = [];

  for (const [cmdName, command] of mockClient.commands.entries()) {
    // 1. Metadata check
    assert.ok(command.name, `Command '${cmdName}' missing name`);
    assert.strictEqual(typeof command.execute, 'function', `Command '${cmdName}' missing execute handler`);
    assert.ok(command.description, `Command '${cmdName}' missing description`);
    assert.ok(command.category, `Command '${cmdName}' missing category`);

    // 2. Execution with no arguments
    try {
      const msgNoArgs = createMockMessage(cmdName, []);
      await command.execute(msgNoArgs, [], mockClient, '!');
    } catch (err) {
      // If error is expected timeout from interactive collector, that is fine
      if (!err.message.includes('Timeout in fuzzer mock')) {
        failedCommands.push({ name: cmdName, args: 'none', error: err.message });
      }
    }

    // 3. Execution with sample arguments
    try {
      const msgWithArgs = createMockMessage(cmdName, ['test', '123']);
      await command.execute(msgWithArgs, ['test', '123'], mockClient, '!');
    } catch (err) {
      if (!err.message.includes('Timeout in fuzzer mock')) {
        failedCommands.push({ name: cmdName, args: 'test 123', error: err.message });
      }
    }

    testedCount++;
  }

  if (failedCommands.length > 0) {
    console.error(`❌ Fuzzer detected ${failedCommands.length} command execution failures:`);
    for (const f of failedCommands.slice(0, 10)) {
      console.error(`  - Command: !${f.name} (Args: ${f.args}) => Error: ${f.error}`);
    }
    assert.fail(`Total ${failedCommands.length} commands failed during execution audit.`);
  }

  console.log(`✅ All ${testedCount}/${totalCommands} commands executed safely with ZERO unhandled errors.`);
  console.log('✅ fuzzAllCommands.test.js PASSED with 0 errors!\n');
}

runFuzzTests().catch(err => {
  console.error('❌ fuzzAllCommands.test.js FAILED:', err);
  process.exit(1);
});
