/**
 * Test Suite: Command Handler & Directory Loader
 */
const assert = require('node:assert');
const path = require('node:path');
const { Collection } = require('discord.js');
const { loadCommands } = require('../../src/handlers/commandHandler');

console.log('[TEST] Running commandHandler.test.js...');

// Mock client collections
const mockClient = {
  commands: new Collection(),
  aliases: new Collection(),
  categories: new Collection()
};

const commandsDir = path.resolve(__dirname, '../../src/commands');

loadCommands(mockClient, commandsDir);

assert.ok(mockClient.commands.size >= 30, `Must contain at least 30 core commands (found ${mockClient.commands.size})`);
assert.ok(mockClient.categories.size >= 10, `Must contain active categories (found ${mockClient.categories.size})`);

console.log(`✅ Loaded ${mockClient.commands.size} commands across ${mockClient.categories.size} categories.`);

// Check essential commands exist
const requiredCommands = [
  'help', 'ping', 'stats', 'prefix', 'ban', 'kick', 'mute', 'unmute',
  'autorole', 'welcome', 'antinuke', 'emergency', 'ownerpanel', 'auditlog',
  'voice', 'vcstatus', 'sethomevc', 'leaderboard', 'automod', 'leave', 'slots', 'componentsv2',
  'rps', 'trivia', 'connect4', 'duty', 'profile', 'levels', 'modpanel', 'banpanel', 'invite', 'support',
  'addemoji', 'emojilist', 'deleteemoji', 'emojipack', 'emojiserver'
];

for (const cmdName of requiredCommands) {
  assert.ok(mockClient.commands.has(cmdName), `Expected command '${cmdName}' to be registered`);
  const cmd = mockClient.commands.get(cmdName);
  assert.strictEqual(typeof cmd.execute, 'function', `Command '${cmdName}' must have an execute function`);
  assert.ok(cmd.description, `Command '${cmdName}' must have a description`);
  assert.ok(cmd.category, `Command '${cmdName}' must have a category`);
}

console.log(`✅ All ${requiredCommands.length} essential commands verified with valid execute handlers.`);

// Verify category grouping integrity
for (const [catName, cmdList] of mockClient.categories.entries()) {
  assert.ok(Array.isArray(cmdList), `Category '${catName}' must be an array of commands`);
  assert.ok(cmdList.length > 0, `Category '${catName}' should contain commands`);
}

console.log('✅ Command-to-Category mappings verified.');
console.log('✅ commandHandler.test.js PASSED with 0 errors!\n');
