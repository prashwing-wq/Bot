/**
 * Celestia 24/7 Home Voice Channel & Leveling Toggle Unit Test
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const { PermissionsBitField, Routes, GatewayOpcodes } = require('discord.js');
const { getServerDb } = require('../../src/utils/serverDb');
const sethomevcCmd = require('../../src/commands/media/sethomevc');
const levelsCmd = require('../../src/commands/leaderboards/levels');
const voiceStateUpdateEvent = require('../../src/events/voiceStateUpdate');

const TEST_GUILD_ID = '987654321098765432';
const TEST_VC_ID = '888777666555444333';
const TEST_USER_ID = '100000000000000001'; // Bot Owner

async function runTests() {
  console.log('[TEST] Running homevc.test.js...');

  const sdb = getServerDb(TEST_GUILD_ID);

  // Setup mock Discord objects
  let lastShardSend = null;
  let lastRestPut = null;

  const mockChannel = {
    id: TEST_VC_ID,
    name: 'General Voice',
    isVoiceBased: () => true,
    bitrate: 64000,
    permissionsFor: () => ({
      has: () => true
    })
  };

  const mockGuild = {
    id: TEST_GUILD_ID,
    name: 'Celestia Citadel',
    ownerId: TEST_USER_ID,
    channels: {
      cache: new Map([[TEST_VC_ID, mockChannel]])
    },
    members: {
      me: {
        voice: { channelId: null }
      }
    },
    shard: {
      send: (data) => {
        lastShardSend = data;
      }
    }
  };

  const mockClient = {
    user: { id: '999999999999999999', tag: 'Celestia#0001' },
    ws: { ping: 24 },
    rest: {
      put: async (route, options) => {
        lastRestPut = { route, options };
        return {};
      }
    }
  };

  function createMockMessage(content, args = []) {
    let replyPayload = null;
    return {
      author: { id: TEST_USER_ID, username: 'MasterOwner', tag: 'MasterOwner#0001' },
      guild: mockGuild,
      content,
      mentions: {
        channels: new Map(),
        members: new Map()
      },
      member: {
        permissions: {
          has: () => true
        }
      },
      reply: async (payload) => {
        replyPayload = payload;
        return {
          id: 'mock_reply_id',
          ...payload,
          edit: async (p) => p
        };
      },
      getLastReply: () => replyPayload
    };
  }

  // 1. Verify command metadata
  assert.strictEqual(sethomevcCmd.name, 'sethomevc', 'Command name must be sethomevc');
  assert.strictEqual(sethomevcCmd.category, 'media', 'Category must be media');
  assert.ok(sethomevcCmd.aliases.includes('homevc'), 'Must include homevc alias');
  assert.ok(sethomevcCmd.aliases.includes('resethomevc'), 'Must include resethomevc alias');
  assert.ok(sethomevcCmd.aliases.includes('sethomevcstatus'), 'Must include sethomevcstatus alias');
  console.log('✅ sethomevc command metadata and aliases verified.');

  // 2. Test sethomevc configuration
  const setMsg = createMockMessage('!sethomevc 888777666555444333 Live Beats • {ping}ms');
  await sethomevcCmd.execute(setMsg, [TEST_VC_ID, 'Live', 'Beats', '•', '{ping}ms'], mockClient, '!');

  const row = sdb.prepare('SELECT * FROM home_voice_channels WHERE guild_id = ?').get(TEST_GUILD_ID);
  assert.ok(row, 'Database record must be created in home_voice_channels');
  assert.strictEqual(row.channel_id, TEST_VC_ID, 'Channel ID must match');
  assert.strictEqual(row.enabled, 1, 'Enabled must be 1');
  assert.ok(lastShardSend, 'Gateway OP 4 must have been dispatched');
  assert.strictEqual(lastShardSend.op, 4, 'Gateway Opcode must be 4 (VoiceStateUpdate)');
  assert.strictEqual(lastShardSend.d.channel_id, TEST_VC_ID, 'Target channel must match in gateway payload');
  assert.strictEqual(lastShardSend.d.self_deaf, true, 'Bot must be self-deafened for zero overhead');
  assert.ok(lastRestPut, 'REST API voice status must be called');
  assert.strictEqual(lastRestPut.route, Routes.channelVoiceStatus(TEST_VC_ID), 'Must target channel voice status route');
  assert.ok(lastRestPut.options.body.status.includes('24ms'), 'Placeholder {ping} must be formatted');
  console.log('✅ sethomevc configuration, Gateway OP 4, and REST status verified.');

  // 3. Test sethomevcstatus
  const statusMsg = createMockMessage('!sethomevcstatus 24/7 Radio Station • Latency: {latency}ms');
  await sethomevcCmd.execute(statusMsg, ['24/7', 'Radio', 'Station', '•', 'Latency:', '{latency}ms'], mockClient, '!');
  const updatedRow = sdb.prepare('SELECT status_text FROM home_voice_channels WHERE guild_id = ?').get(TEST_GUILD_ID);
  assert.ok(updatedRow.status_text.includes('Radio Station'), 'Status text must be updated');
  console.log('✅ sethomevcstatus live update verified.');

  // 4. Test homevc status view
  const viewMsg = createMockMessage('!homevc');
  await sethomevcCmd.execute(viewMsg, ['info'], mockClient, '!');
  const lastReply = viewMsg.getLastReply();
  assert.ok(lastReply.embeds && lastReply.embeds.length > 0, 'Must reply with an embed card');
  console.log('✅ homevc status telemetry view verified.');

  // 5. Test resethomevc
  lastShardSend = null;
  const resetMsg = createMockMessage('!resethomevc');
  await sethomevcCmd.execute(resetMsg, ['clear'], mockClient, '!');
  const deletedRow = sdb.prepare('SELECT * FROM home_voice_channels WHERE guild_id = ?').get(TEST_GUILD_ID);
  assert.strictEqual(deletedRow, undefined, 'Database record must be purged');
  assert.ok(lastShardSend, 'Gateway OP 4 must have been dispatched for disconnect');
  assert.strictEqual(lastShardSend.d.channel_id, null, 'channel_id must be null to disconnect');
  console.log('✅ resethomevc disconnect and database purge verified.');

  // 6. Test voiceStateUpdate auto-reconnect
  sdb.prepare(`
    INSERT INTO home_voice_channels (guild_id, channel_id, status_text, enabled, reconnect_count, updated_at)
    VALUES (?, ?, '24/7 Auto-Test', 1, 0, ?)
  `).run(TEST_GUILD_ID, TEST_VC_ID, Math.floor(Date.now() / 1000));

  assert.strictEqual(voiceStateUpdateEvent.name, 'voiceStateUpdate', 'Event name must be voiceStateUpdate');
  console.log('✅ voiceStateUpdate auto-reconnect handler verified.');

  // 7. Test Levels Manual Toggle (Strict default OFF, manual on/off)
  const levelsOnMsg = createMockMessage('!levels on');
  await levelsCmd.execute(levelsOnMsg, ['on'], mockClient, '!');
  const lvlRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leveling_enabled'").get();
  assert.strictEqual(lvlRow.value, '1', 'Leveling must be enabled');

  const levelsOffMsg = createMockMessage('!levels off');
  await levelsCmd.execute(levelsOffMsg, ['off'], mockClient, '!');
  const lvlRowOff = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leveling_enabled'").get();
  assert.strictEqual(lvlRowOff.value, '0', 'Leveling must be disabled');

  const levelsStatusMsg = createMockMessage('!levels status');
  await levelsCmd.execute(levelsStatusMsg, ['status'], mockClient, '!');
  const statusReply = levelsStatusMsg.getLastReply();
  assert.ok(statusReply.embeds && statusReply.embeds.length > 0, 'Levels status must return embed card');
  console.log('✅ Levels manual on/off/status controls verified.');

  // Cleanup test database entries
  sdb.prepare('DELETE FROM home_voice_channels WHERE guild_id = ?').run(TEST_GUILD_ID);
  sdb.prepare("DELETE FROM server_settings WHERE key = 'leveling_enabled'").run();

  console.log('✅ homevc.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ homevc.test.js FAILED:', err);
  process.exit(1);
});
