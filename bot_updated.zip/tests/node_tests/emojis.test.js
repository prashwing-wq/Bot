/**
 * Test Suite: Custom Emojis, Steal, and EmojiPack Suite Verification
 */
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');

const { BUILTIN_PACK, EMOJIS, resolveEmoji, ASSETS_DIR } = require('../../src/utils/emojis');
const addEmojiCmd = require('../../src/commands/utility/addemoji');
const emojiListCmd = require('../../src/commands/utility/emojilist');
const deleteEmojiCmd = require('../../src/commands/utility/deleteemoji');
const emojiPackCmd = require('../../src/commands/utility/emojipack');

async function runTests() {
  console.log('[TEST] Running emojis.test.js...');

  // 1. Verify BUILTIN_PACK and Local Assets
  assert.ok(BUILTIN_PACK.length >= 10, 'Must have at least 10 builtin emojis');
  const num1 = BUILTIN_PACK.find(e => e.name === 'custom_emoji_1');
  const num2 = BUILTIN_PACK.find(e => e.name === 'custom_emoji_2');
  const num3 = BUILTIN_PACK.find(e => e.name === 'custom_emoji_3');
  assert.ok(num1, 'custom_emoji_1 must exist');
  assert.ok(num2, 'custom_emoji_2 must exist');
  assert.ok(num3, 'custom_emoji_3 must exist');

  // Verify all local files exist and have > 0 bytes (when present in dev environment)
  let localAssetCount = 0;
  for (const item of BUILTIN_PACK) {
    if (item.localFile && fs.existsSync(item.localFile)) {
      const sz = fs.statSync(item.localFile).size;
      assert.ok(sz > 0, `Local asset ${item.localFile} must not be empty`);
      localAssetCount++;
    }
  }
  console.log(`✅ BUILTIN_PACK verified (${BUILTIN_PACK.length} emojis registered, ${localAssetCount} local assets verified).`);

  // 2. Verify resolveEmoji dynamic resolver
  const mockGuildWithEmoji = {
    emojis: {
      cache: [
        { name: 'custom_emoji_1', animated: true, toString: () => '<a:custom_emoji_1:999001>' },
        { name: 'celestia_shield', animated: false, toString: () => '<:celestia_shield:999002>' }
      ]
    }
  };

  const resolvedInGuild = resolveEmoji(mockGuildWithEmoji, 'custom_emoji_1');
  assert.strictEqual(resolvedInGuild, '<a:custom_emoji_1:999001>');

  const resolvedFallback = resolveEmoji(null, 'custom_emoji_1');
  assert.ok(resolvedFallback.includes('custom_emoji_1') || resolvedFallback.includes('terminal') || resolvedFallback === '1️⃣');

  const resolvedSemantic = resolveEmoji(null, 'SUCCESS');
  assert.ok(resolvedSemantic.includes('success') || resolvedSemantic.includes('celestia_tick') || resolvedSemantic.includes('check_pulse'));

  // Test unknown & edge cases
  assert.strictEqual(resolveEmoji(null, 'foobar_nonexistent'), null, 'Unknown emoji must resolve to null');
  assert.strictEqual(resolveEmoji(null, ''), null, 'Empty string must resolve to null');
  assert.strictEqual(resolveEmoji(null, null), null, 'Null must resolve to null');
  assert.strictEqual(resolveEmoji(null, 'loading'), EMOJIS.LOADING, 'Explicit loading must return EMOJIS.LOADING');
  assert.strictEqual(resolveEmoji(null, 'spinner'), EMOJIS.LOADING, 'Explicit spinner must return EMOJIS.LOADING');
  assert.strictEqual(resolveEmoji(null, 'refresh'), EMOJIS.REFRESH, 'Explicit refresh must return EMOJIS.REFRESH');
  console.log('✅ resolveEmoji dynamic resolution & fallback verified.');

  // 3. Verify addemoji / steal command
  assert.strictEqual(addEmojiCmd.name, 'addemoji');
  assert.ok(addEmojiCmd.aliases.includes('steal'));
  assert.ok(addEmojiCmd.aliases.includes('eadd'));
  assert.strictEqual(typeof addEmojiCmd.execute, 'function');
  console.log('✅ addemoji / steal command metadata verified.');

  // 4. Verify emojilist command
  assert.strictEqual(emojiListCmd.name, 'emojilist');
  assert.ok(emojiListCmd.aliases.includes('emojis'));
  assert.strictEqual(typeof emojiListCmd.execute, 'function');
  console.log('✅ emojilist command metadata verified.');

  // 5. Verify deleteemoji command
  assert.strictEqual(deleteEmojiCmd.name, 'deleteemoji');
  assert.ok(deleteEmojiCmd.aliases.includes('delemoji'));
  assert.strictEqual(typeof deleteEmojiCmd.execute, 'function');
  console.log('✅ deleteemoji command metadata verified.');

  // 6. Verify emojipack command
  assert.strictEqual(emojiPackCmd.name, 'emojipack');
  assert.ok(emojiPackCmd.aliases.includes('emojisetup'));
  assert.strictEqual(typeof emojiPackCmd.execute, 'function');

  // Test emojipack preview reply
  let packReply = null;
  const mockMsg = {
    guild: { name: 'Test Guild', premiumTier: 1, emojis: { cache: new Map() } },
    reply: (payload) => { packReply = payload; return Promise.resolve(); }
  };
  await emojiPackCmd.execute(mockMsg, ['list'], null, '!');
  assert.ok(packReply && packReply.embeds && packReply.embeds.length > 0);
  assert.ok(packReply.components && packReply.components.length > 0);
  console.log('✅ emojipack preview layout & components verified.');

  // 7. Verify Emoji Server Sync & replaceEmojis
  const { isEmojiServer, getEmojiServerNumber, syncEmojiServers, SERVER_PACKS } = require('../../src/utils/emojiSync');
  const { replaceEmojis } = require('../../src/utils/emojis');

  assert.strictEqual(isEmojiServer({ name: 'custom emoji 1', ownerId: '123' }), true);
  assert.strictEqual(isEmojiServer({ name: 'custom emoji 2', ownerId: '123' }), true);
  assert.strictEqual(isEmojiServer({ name: 'custom emoji 3', ownerId: '123' }), true);
  assert.strictEqual(isEmojiServer({ name: 'custom emoji 4', ownerId: '123' }), true);
  assert.strictEqual(getEmojiServerNumber({ name: 'custom emoji 1' }), 1);
  assert.strictEqual(getEmojiServerNumber({ name: 'custom emoji 2' }), 2);
  assert.strictEqual(getEmojiServerNumber({ name: 'custom emoji 3' }), 3);
  assert.strictEqual(getEmojiServerNumber({ name: 'custom emoji 4' }), 4);
  assert.ok(SERVER_PACKS[1].length >= 10, 'Server 1 pack must have >= 10 emojis');
  assert.ok(SERVER_PACKS[2].length >= 5, 'Server 2 pack must have >= 5 emojis');
  assert.ok(SERVER_PACKS[3].length >= 3, 'Server 3 pack must have >= 3 emojis');
  assert.ok(SERVER_PACKS[4].length >= 5, 'Server 4 pack must have >= 5 emojis');

  assert.strictEqual(isEmojiServer({ name: 'Celestia Emojis 1', ownerId: '123' }), true);
  const testOwner = process.env.OWNER_IDS ? process.env.OWNER_IDS.split(',')[0].trim() : '100000000000000001';
  assert.strictEqual(isEmojiServer({ name: 'General Chat', ownerId: testOwner }), true); // Owner guild
  assert.strictEqual(isEmojiServer({ name: 'Random Gaming', ownerId: '999' }), false);

  const mockClientWithEmojis = {
    celestiaEmojis: new Map([
      ['custom_emoji_1', '<a:custom_emoji_1:111222333>'],
      ['celestia_loading', '<a:loading:1272527164256030873>']
    ])
  };
  const formatted = replaceEmojis(mockClientWithEmojis, 'Step :custom_emoji_1: Loading :celestia_loading:');
  assert.strictEqual(formatted, 'Step <a:custom_emoji_1:111222333> Loading <a:loading:1272527164256030873>');

  // External custom emoji & unknown text preservation
  assert.strictEqual(replaceEmojis('Hello <:other:123> :world:'), 'Hello <:other:123> :world:');
  assert.strictEqual(
    replaceEmojis('Time <t:1700000000:R> at <t:1700000000> for <@123456789> and <#987654321>'),
    'Time <t:1700000000:R> at <t:1700000000> for <@123456789> and <#987654321>'
  );
  console.log('✅ isEmojiServer & replaceEmojis cross-server formatter verified.');

  // 8. Verify emojiserver command
  const emojiServerCmd = require('../../src/commands/owner/emojiserver');
  assert.strictEqual(emojiServerCmd.name, 'emojiserver');
  assert.ok(emojiServerCmd.aliases.includes('syncemojis'));
  assert.strictEqual(typeof emojiServerCmd.execute, 'function');
  console.log('✅ emojiserver command metadata verified.');

  // 9. Verify Custom Emoji 10, 11, 12 server integration & number parsing
  const { EMOJI_SERVER_IDS } = require('../../src/utils/emojis');
  assert.ok(EMOJI_SERVER_IDS.has('1568221270091497533'), 'Custom emoji 10 must be in EMOJI_SERVER_IDS');
  assert.ok(EMOJI_SERVER_IDS.has('1568221442422607942'), 'Custom emoji 11 must be in EMOJI_SERVER_IDS');
  assert.ok(EMOJI_SERVER_IDS.has('1568221697063129108'), 'Custom emoji 12 must be in EMOJI_SERVER_IDS');
  assert.strictEqual(isEmojiServer({ name: 'Custom emoji 10' }), true);
  assert.strictEqual(isEmojiServer({ name: 'Custom emoji 12' }), true);
  assert.strictEqual(getEmojiServerNumber({ name: 'Custom emoji 10' }), 10);
  assert.strictEqual(getEmojiServerNumber({ name: 'Custom emoji 12' }), 12);
  console.log('✅ Custom emoji 10, 11, 12 server bindings & parsing verified.');

  // 10. Verify Manifest Emojis Resolve via Fallback & Builtins via discordTag
  const manifest = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../src/data/new_emoji_manifest.json'), 'utf8'));
  for (const item of manifest) {
    const res = resolveEmoji(null, item.name);
    assert.ok(typeof res === 'string' && res.length > 0, `Emoji ${item.name} must resolve to a valid non-empty string`);
  }
  for (const item of BUILTIN_PACK) {
    const res = resolveEmoji(null, item.name);
    assert.strictEqual(res, item.discordTag, `Built-in emoji ${item.name} must resolve to its discordTag`);
  }
  console.log(`✅ 100% of ${manifest.length} manifest emojis and ${BUILTIN_PACK.length} builtin emojis resolved.`);

  // 11. Static Codebase Scan: Every tungsten_[a-z0-9_]+ (and legacy celestia_) token must be registered, fallback, alias, or known metric
  const knownNonEmojiTokens = new Set([
    'celestia_',
    'celestia_errors_total',
    'celestia_commands_total',
    'celestia_commands_executed_total',
    'celestia_db_query_duration_seconds',
    'celestia_uptime_seconds',
    'celestia_ws_ping_ms',
    'celestia_memory_heap_used_bytes',
    'celestia_memory_rss_bytes',
    'celestia_guilds_total',
    'celestia_users_total',
    'celestia_antinuke_triggers_total',
    'celestia_bot',
    'celestia_client',
    'celestia_node',
    'celestia_test',
    'celestia_test_temp',
    'celestia_backup',
    'celestia_secret_phrase',
    'tungsten_',
    'tungsten_errors_total',
    'tungsten_commands_total',
    'tungsten_commands_executed_total',
    'tungsten_db_query_duration_seconds',
    'tungsten_uptime_seconds',
    'tungsten_ws_ping_ms',
    'tungsten_memory_heap_used_bytes',
    'tungsten_memory_rss_bytes',
    'tungsten_guilds_total',
    'tungsten_users_total',
    'tungsten_antinuke_triggers_total',
    'tungsten_bot',
    'tungsten_client',
    'tungsten_node',
    'tungsten_test',
    'tungsten_test_temp',
    'tungsten_backup',
    'tungsten_secret_phrase'
  ]);
  const emojiPending = require('../../src/utils/emojiPending');
  const builtinNames = new Set(BUILTIN_PACK.map(e => e.name.toLowerCase()));

  function scanDir(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const ent of entries) {
      const fullPath = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        scanDir(fullPath);
      } else if (ent.isFile() && ent.name.endsWith('.js') && !ent.name.includes('emojis.js') && !ent.name.includes('emojiSync.js') && !ent.name.includes('emojiFallbacks.js')) {
        const content = fs.readFileSync(fullPath, 'utf8');
        const matches = (content.match(/tungsten_[a-z0-9_]+/g) || []).concat(content.match(/celestia_[a-z0-9_]+/g) || []);
        for (const token of matches) {
          const lower = token.toLowerCase();
          const isValid = builtinNames.has(lower) ||
            Boolean(emojiPending[lower]) ||
            knownNonEmojiTokens.has(lower) ||
            Boolean(resolveEmoji(null, lower)) ||
            lower.includes('metric') ||
            lower.includes('total') ||
            lower.includes('count') ||
            lower.includes('duration') ||
            lower.includes('bytes') ||
            lower.includes('seconds') ||
            lower.includes('ping_ms') ||
            lower === 'celestia_' ||
            lower === 'tungsten_';
          assert.ok(isValid, `Found unregistered/dangling emoji token in ${path.relative(__dirname, fullPath)}: "${token}"`);
        }
      }
    }
  }
  scanDir(path.resolve(__dirname, '../../src'));
  console.log('✅ Static codebase emoji token scan verified: 0 dangling tokens.');

  console.log('✅ emojis.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ emojis.test.js failed:', err);
  process.exit(1);
});
