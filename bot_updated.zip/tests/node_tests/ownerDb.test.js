/**
 * Test Suite: Owner Database Inspector & Query Suite
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
if (!process.env.CELESTIA_DB_DIR) {
  process.env.CELESTIA_DB_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'tungsten-ownerdb-'));
}
const dbCmd = require('../../src/commands/security/database');
const dbnavHandler = require('../../src/interactions/dbnav');
const { getMasterDb, getServerDb } = require('../../src/utils/serverDb');

console.log('[TEST] Running ownerDb.test.js...');

async function runTests() {
  // 1. Verify metadata
  assert.strictEqual(dbCmd.name, 'database');
  assert.ok(dbCmd.aliases.includes('db'));
  assert.ok(dbCmd.aliases.includes('sql'));
  assert.ok(dbCmd.aliases.includes('dbtables'));
  assert.ok(dbCmd.aliases.includes('dbcontents'));
  assert.strictEqual(dbCmd.ownerOnly, true);

  // 2. Reject non-owner
  let nonOwnerReply = '';
  const mockNonOwnerMsg = {
    author: { id: '999999999999999999', username: 'RandomUser' },
    reply: (content) => { nonOwnerReply = typeof content === 'string' ? content : content.content; }
  };
  await dbCmd.execute(mockNonOwnerMsg, ['tables'], {}, '!');
  assert.ok(nonOwnerReply.includes('Access Denied'), 'Non-owner must be rejected with Access Denied');
  console.log('✅ Non-owner database access rejection verified.');

  // 3. Storage Quota Calculation & Progress Bar Unit Tests
  const mockDbStats = {
    command: async () => ({
      db: 'tungsten_bot',
      collections: 2,
      objects: 1713,
      dataSize: 1089524,
      storageSize: 1040384,
      indexes: 4,
      indexSize: 282624,
      avgObjSize: 636
    })
  };
  const stats = await dbCmd.getStorageStats(mockDbStats);
  assert.strictEqual(stats.totalQuota, 512.0);
  assert.strictEqual(stats.dataSizeMb, '1.04');
  assert.strictEqual(stats.storageSizeMb, '0.99');
  assert.strictEqual(stats.indexSizeMb, '0.27');
  assert.strictEqual(stats.totalConsumedMb, '1.26');
  assert.strictEqual(stats.freeMb, '510.74');
  assert.strictEqual(stats.consumedPercent, '0.25');
  assert.ok(stats.progressBar.includes('█'), 'Progress bar must render filled block');
  assert.ok(stats.progressBar.includes('0.25%'), 'Progress bar must display percentage');

  const quotaBlock = dbCmd.formatStorageQuotaBlock(stats);
  assert.ok(quotaBlock.includes('512.00 MB Free Tier'), 'Storage block must state 512.00 MB Free Tier');
  assert.ok(quotaBlock.includes('1.26 MB'), 'Storage block must report consumed MB');
  assert.ok(quotaBlock.includes('510.74 MB'), 'Storage block must report free MB');
  console.log('✅ getStorageStats & formatStorageQuotaBlock mathematical precision verified.');

  // 4. Verify canonical schemas (26 Master Tables & 35 Guild Tables)
  assert.strictEqual(Object.keys(dbCmd.MASTER_TABLE_SCHEMAS).length, 26, 'Must define exactly 26 master tables');
  assert.strictEqual(Object.keys(dbCmd.GUILD_TABLE_SCHEMAS).length, 35, 'Must define exactly 35 guild tables');
  assert.deepStrictEqual(dbCmd.MASTER_TABLE_SCHEMAS.bot_owners, ['user_id', 'added_at', 'added_by']);
  assert.deepStrictEqual(dbCmd.GUILD_TABLE_SCHEMAS.antinuke_rules, ['vector', 'enabled', 'action', 'limit_count', 'time_window', 'auto_heal']);
  console.log('✅ Canonical table schemas (26 Master, 35 Guild) verified.');

  // 5. Allow Bot Owner
  const ownerId = (process.env.OWNER_IDS || '100000000000000001').split(',')[0].trim();
  let lastReply = null;
  const mockOwnerMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    guild: { id: '123456789012345678', name: 'Test Guild' },
    reply: (payload) => { lastReply = payload; }
  };

  // Test 'tables'
  await dbCmd.execute(mockOwnerMsg, ['tables'], {}, '!');
  assert.ok(lastReply && lastReply.embeds && lastReply.embeds[0], 'Tables must return an embed');
  assert.ok(lastReply.embeds[0].data.title.includes('Tables'), 'Embed title must indicate Tables');
  console.log('✅ db tables command verified.');

  // Test 'query' (SELECT 1 + 1 as sum)
  await dbCmd.execute(mockOwnerMsg, ['query', 'SELECT', '1', '+', '1', 'as', 'sum'], {}, '!');
  assert.ok(typeof lastReply === 'string' && lastReply.includes('Query Executed'), 'Query execution must succeed');
  console.log('✅ db query command verified.');

  // Test 'schema' on bot_owners
  await dbCmd.execute(mockOwnerMsg, ['schema', 'bot_owners'], {}, '!');
  assert.ok(lastReply && lastReply.embeds && lastReply.embeds[0], 'Schema must return an embed');
  assert.ok(lastReply.embeds[0].data.title.includes('bot_owners'), 'Schema title must match table');
  console.log('✅ db schema command verified.');

  // Test 'stats' (includes MongoDB Atlas, SQLite, and prominent Storage Quota block)
  await dbCmd.execute(mockOwnerMsg, ['stats'], {}, '!');
  assert.ok(lastReply && lastReply.embeds && lastReply.embeds[0], 'Stats must return an embed');
  assert.ok(lastReply.embeds[0].data.description.includes('SQLite'), 'Stats must report SQLite diagnostics');
  assert.ok(lastReply.embeds[0].data.description.includes('MongoDB Atlas'), 'Stats must report MongoDB Atlas diagnostics');
  assert.ok(lastReply.embeds[0].data.description.includes('Storage Quota'), 'Stats must display Storage Quota meter');
  console.log('✅ db stats command verified (SQLite + MongoDB Atlas + Storage Quota Meter).');

  // Test slash command definition & options
  assert.ok(dbCmd.slash, 'Slash command builder must exist');
  assert.strictEqual(dbCmd.slash.name, 'db');
  const actionOption = dbCmd.slash.options.find(o => o.name === 'action');
  const categoryOption = dbCmd.slash.options.find(o => o.name === 'category');
  assert.ok(actionOption, 'Action option must exist');
  assert.ok(categoryOption, 'Category option must exist');
  console.log('✅ db slash command builder & options verified.');

  // Test 'help'
  await dbCmd.execute(mockOwnerMsg, ['help'], {}, '!');
  assert.ok(lastReply && lastReply.embeds && lastReply.embeds[0], 'Help must return an embed');
  assert.ok(lastReply.embeds[0].data.title.includes('MongoDB Atlas'), 'Help title must indicate MongoDB Atlas');
  console.log('✅ db help command verified.');

  // Test 'contents' / 'contents all'
  await dbCmd.execute(mockOwnerMsg, ['contents'], {}, '!');
  assert.ok(lastReply && lastReply.embeds && lastReply.embeds[0], 'Contents must return an embed');
  assert.ok(lastReply.embeds[0].data.title.includes('Tables'), 'Contents title must indicate Tables');
  assert.ok(lastReply.embeds[0].data.description.includes('Master Tables (26 Total)'), 'Must list all 26 master tables');
  assert.ok(lastReply.embeds[0].data.description.includes('Guild Tables (35 Total'), 'Must list all 35 guild tables');
  assert.ok(lastReply.components && lastReply.components[0], 'Must attach Components V2 ActionRow buttons');
  const allButtons = lastReply.components[0].components;
  assert.strictEqual(allButtons.length, 4, 'Must have 4 interactive buttons in overview');
  assert.strictEqual(allButtons[0].data.custom_id, 'dbnav:contents:master:1');
  assert.strictEqual(allButtons[1].data.custom_id, 'dbnav:contents:guild:1');
  assert.strictEqual(allButtons[2].data.custom_id, 'dbnav:contents:quota:1');
  assert.strictEqual(allButtons[3].data.custom_id, 'dbnav:contents:refresh:1');
  console.log('✅ db contents overview command & 4 ActionRow buttons verified.');

  // Test 'contents master'
  await dbCmd.execute(mockOwnerMsg, ['contents', 'master'], {}, '!');
  assert.ok(lastReply.embeds[0].data.title.includes('Master Tables'), 'Master view title verified');
  assert.ok(lastReply.embeds[0].data.description.includes('fields:'), 'Must include column fields for tables');
  console.log('✅ db contents master command verified.');

  // Test 'contents guild'
  await dbCmd.execute(mockOwnerMsg, ['contents', 'guild'], {}, '!');
  assert.ok(lastReply.embeds[0].data.title.includes('Guild Tables'), 'Guild view title verified');
  assert.ok(lastReply.embeds[0].data.description.includes('fields:'), 'Must include column fields for tables');
  console.log('✅ db contents guild command verified.');

  // Test 'contents storage'
  await dbCmd.execute(mockOwnerMsg, ['contents', 'storage'], {}, '!');
  assert.ok(lastReply.embeds[0].data.title.includes('Storage Quota'), 'Storage view title verified');
  assert.ok(lastReply.embeds[0].data.description.includes('512.00 MB'), 'Must report 512.00 MB tier quota');
  console.log('✅ db contents storage command verified.');

  // Test 'contents <table>' raw inspection
  await dbCmd.execute(mockOwnerMsg, ['contents', 'bot_owners'], {}, '!');
  assert.ok(lastReply.embeds[0].data.title.includes('bot_owners'), 'Direct table inspection title verified');
  console.log('✅ db contents <table_name> inspection verified.');

  // Test 'servers'
  await dbCmd.execute(mockOwnerMsg, ['servers'], {}, '!');
  assert.ok(lastReply, 'Servers command must respond');
  console.log('✅ db servers command verified.');

  // Test 'server'
  await dbCmd.execute(mockOwnerMsg, ['server', '123456789012345678'], {}, '!');
  assert.ok(lastReply, 'Server command must respond');
  console.log('✅ db server <guild_id> command verified.');

  // Test 'inspect'
  await dbCmd.execute(mockOwnerMsg, ['inspect', 'master', 'bot_owners', '2'], {}, '!');
  assert.ok(lastReply, 'Inspect master command must respond');
  console.log('✅ db inspect master command verified.');

  // Test exported helper functions
  const exportedPayload = await dbCmd.buildContentsPayload({ category: 'all' });
  assert.ok(exportedPayload.embeds && exportedPayload.embeds[0], 'buildContentsPayload must return embeds');
  assert.ok(exportedPayload.components && exportedPayload.components[0], 'buildContentsPayload must return components');
  const exportedEmbed = await dbCmd.buildContentsEmbed('all');
  assert.ok(exportedEmbed, 'buildContentsEmbed must return EmbedBuilder');
  console.log('✅ Exported helper functions buildContentsPayload & buildContentsEmbed verified.');

  // Test dbnav interaction router
  let dbnavUpdated = null;
  const mockDbnavOwnerInteraction = {
    customId: 'dbnav:contents:master:1',
    user: { id: ownerId },
    guildId: '123456789012345678',
    deferUpdate: async () => {},
    editReply: async (payload) => { dbnavUpdated = payload; return payload; },
    update: async (payload) => { dbnavUpdated = payload; return payload; },
    reply: async (payload) => { dbnavUpdated = payload; return payload; }
  };
  await dbnavHandler.handle(mockDbnavOwnerInteraction, {});
  assert.ok(dbnavUpdated && dbnavUpdated.embeds && dbnavUpdated.embeds[0], 'dbnav handler must update interaction with payload');
  assert.ok(dbnavUpdated.embeds[0].data.title.includes('Master Tables'), 'dbnav navigation to master verified');
  console.log('✅ dbnav interaction handler verified.');

  // Test slash command execution
  let slashReplied = false;
  let slashDeferred = false;
  let lastSlashReply = null;
  const mockSlashNonOwner = {
    user: { id: '999999999999999999' },
    reply: (payload) => {
      slashReplied = true;
      assert.ok(payload.content.includes('Access Denied'));
    }
  };
  await dbCmd.executeSlash(mockSlashNonOwner, {});
  assert.ok(slashReplied, 'Slash non-owner must be rejected');
  console.log('✅ Slash non-owner rejection verified.');

  const mockSlashOwner = {
    user: { id: ownerId },
    options: {
      getString: (name) => (name === 'action' ? 'stats' : null),
      getInteger: () => null
    },
    deferReply: async () => { slashDeferred = true; },
    editReply: async (payload) => { lastSlashReply = payload; }
  };
  await dbCmd.executeSlash(mockSlashOwner, {});
  assert.ok(slashDeferred, 'Slash command must defer reply');
  assert.ok(lastSlashReply && lastSlashReply.embeds && lastSlashReply.embeds[0], 'Slash stats must reply with embed');
  assert.ok(lastSlashReply.embeds[0].data.description.includes('MongoDB Atlas'), 'Slash stats must report MongoDB Atlas');
  console.log('✅ Slash owner stats action execution verified.');

  // Test slash contents execution
  const mockSlashOwnerContents = {
    user: { id: ownerId },
    options: {
      getString: (name) => (name === 'action' ? 'contents' : (name === 'category' ? 'all' : null)),
      getInteger: () => null
    },
    deferReply: async () => {},
    editReply: async (payload) => { lastSlashReply = payload; }
  };
  await dbCmd.executeSlash(mockSlashOwnerContents, {});
  assert.ok(lastSlashReply && lastSlashReply.embeds && lastSlashReply.embeds[0], 'Slash contents must reply with embed');
  assert.ok(lastSlashReply.embeds[0].data.title.includes('Tables'), 'Slash contents must report Tables');
  console.log('✅ Slash owner contents action execution verified.');

  // ─── NEW FEATURES VERIFICATION ───
  console.log('\n▶️ Testing Direct File Export & Table Downloads...');
  // 1. db export master
  let exportMasterReply = null;
  const mockExportMasterMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    guild: { id: '123456789012345678', name: 'Test Guild' },
    reply: (payload) => { exportMasterReply = payload; }
  };
  await dbCmd.execute(mockExportMasterMsg, ['export', 'master'], {}, '!');
  assert.ok(exportMasterReply, 'Export master must respond');
  assert.ok(exportMasterReply.embeds && exportMasterReply.embeds[0], 'Export master must include embed');
  assert.ok(exportMasterReply.files && exportMasterReply.files[0], 'Export master must include file attachment');
  assert.strictEqual(exportMasterReply.files[0].name, 'master_database.json', 'File attachment must be named master_database.json');
  console.log('✅ !db export master verified.');

  // 2. db export server
  let exportServerReply = null;
  const mockExportServerMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    guild: { id: '123456789012345678', name: 'Test Guild' },
    reply: (payload) => { exportServerReply = payload; }
  };
  await dbCmd.execute(mockExportServerMsg, ['export', 'server', '123456789012345678'], {}, '!');
  assert.ok(exportServerReply, 'Export server must respond');
  assert.ok(exportServerReply.files && exportServerReply.files[0], 'Export server must attach JSON file');
  assert.strictEqual(exportServerReply.files[0].name, 'server_123456789012345678.json');
  console.log('✅ !db export server <guild_id> verified.');

  // 3. db export table
  let exportTableReply = null;
  const mockExportTableMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    guild: { id: '123456789012345678', name: 'Test Guild' },
    reply: (payload) => { exportTableReply = payload; }
  };
  await dbCmd.execute(mockExportTableMsg, ['export', 'bot_owners'], {}, '!');
  assert.ok(exportTableReply, 'Export table must respond');
  assert.ok(exportTableReply.files && exportTableReply.files[0], 'Export table must attach JSON file');
  assert.strictEqual(exportTableReply.files[0].name, 'bot_owners.json');
  console.log('✅ !db export <table> verified.');

  // 4. db file explorer
  let fileReply = null;
  const mockFileMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    reply: (payload) => { fileReply = payload; }
  };
  await dbCmd.execute(mockFileMsg, ['file', 'emoji_ids.json'], {}, '!');
  assert.ok(fileReply, 'File command must respond');
  assert.ok(fileReply.embeds && fileReply.embeds[0], 'File command must reply with embed');
  console.log('✅ !db file <filename> verified.');

  // 5. db search
  let searchReply = null;
  const mockSearchMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    reply: (payload) => { searchReply = payload; }
  };
  await dbCmd.execute(mockSearchMsg, ['search', 'bot_owners'], {}, '!');
  assert.ok(searchReply, 'Search command must respond');
  assert.ok(searchReply.embeds && searchReply.embeds[0], 'Search must reply with embed');
  console.log('✅ !db search <keyword> verified.');

  // 6. db inspect pagination & download button
  let inspectReply = null;
  const mockInspectMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    guild: { id: '123456789012345678' },
    reply: (payload) => { inspectReply = payload; }
  };
  await dbCmd.execute(mockInspectMsg, ['inspect', 'bot_owners', '1'], {}, '!');
  assert.ok(inspectReply, 'Inspect must respond');
  assert.ok(inspectReply.embeds && inspectReply.embeds[0], 'Inspect must include embed');
  assert.ok(inspectReply.components && inspectReply.components[0], 'Inspect must include Components V2 ActionRow buttons');
  const inspectButtons = inspectReply.components[0].components;
  assert.ok(inspectButtons.some(b => b.data.custom_id.includes('export:')), 'Must include [📥 Download JSON File] button');
  assert.ok(inspectButtons.some(b => b.data.custom_id.includes('inspect:')), 'Must include pagination buttons');
  console.log('✅ !db inspect pagination & download button verified.');

  console.log('✅ ownerDb.test.js PASSED with 0 errors!\n');
  process.exit(0);
}

runTests().catch(err => {
  console.error(err);
  process.exit(1);
});
