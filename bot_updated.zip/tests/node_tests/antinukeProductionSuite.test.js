/**
 * Test Suite: Antinuke Production Suite (Wick / Olympus / Zynrax Parity)
 * Tests:
 * 1. 16 Threat Vectors metadata and default thresholds (ANTINUKE_VECTORS)
 * 2. Per-vector rule persistence & updates (getAntinukeRule, setAntinukeRule)
 * 3. Vector-specific sliding-window rate limit evaluation (checkVectorRateLimit)
 * 4. Isolation Quarantine System (quarantineUser, unquarantineUser, isUserQuarantined)
 * 5. Disaster Recovery Server Snapshots (createServerSnapshot, restoreServerSnapshot, listServerSnapshots)
 * 6. Studio & Vector detail payload rendering
 */
const assert = require('node:assert');
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../src/utils/serverDb');
const {
  ANTINUKE_VECTORS,
  getAntinukeRule,
  setAntinukeRule,
  getAllAntinukeRules,
  checkVectorRateLimit,
  quarantineUser,
  unquarantineUser,
  isUserQuarantined,
  createServerSnapshot,
  restoreServerSnapshot,
  listServerSnapshots,
  deleteServerSnapshot
} = require('../../src/utils/antinukeEngine');
const {
  buildAntinukeStudioPayload,
  buildVectorDetailPayload
} = require('../../src/commands/security/antinuke');

async function runTests() {
  console.log('[TEST] Running antinukeProductionSuite.test.js...');
  const testGid = '666555444333222';
  const testUserId = '555444333222111';
  const sdb = getServerDb(testGid);

  // ─────────────────────────────────────────────────────────────
  // 1. 16 Threat Vectors Metadata Verification
  // ─────────────────────────────────────────────────────────────
  const expectedVectors = [
    'bot_add', 'channel_delete', 'channel_create', 'channel_update',
    'role_delete', 'role_create', 'role_update', 'ban',
    'kick', 'prune', 'webhook', 'emoji',
    'sticker', 'server_update', 'vanity', 'everyone_ping'
  ];

  assert.strictEqual(Object.keys(ANTINUKE_VECTORS).length, 16, 'Must define exactly 16 production threat vectors');
  for (const v of expectedVectors) {
    assert.ok(ANTINUKE_VECTORS[v], `Vector ${v} must be defined`);
    assert.ok(ANTINUKE_VECTORS[v].name, `Vector ${v} must have a name`);
    assert.ok(ANTINUKE_VECTORS[v].icon, `Vector ${v} must have an animated emoji icon`);
  }
  console.log('✅ 16 Production Threat Vectors metadata verified.');

  // ─────────────────────────────────────────────────────────────
  // 2. Per-Vector Rule Persistence & Retrieval
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM antinuke_rules WHERE guild_id = ?').run(testGid);

  // Default fallback check
  const defRule = getAntinukeRule(testGid, 'channel_delete');
  assert.strictEqual(defRule.action, 'ban');
  assert.strictEqual(defRule.limit_count, 1);
  assert.strictEqual(defRule.time_window, 10);
  assert.strictEqual(defRule.auto_heal, true);

  // Custom rule update
  const updated = setAntinukeRule(testGid, 'channel_delete', {
    action: 'quarantine',
    limit_count: 3,
    time_window: 20,
    auto_heal: false
  });
  assert.strictEqual(updated, true);

  const savedRule = getAntinukeRule(testGid, 'channel_delete');
  assert.strictEqual(savedRule.action, 'quarantine');
  assert.strictEqual(savedRule.limit_count, 3);
  assert.strictEqual(savedRule.time_window, 20);
  assert.strictEqual(savedRule.auto_heal, false);

  const allRules = getAllAntinukeRules(testGid);
  assert.strictEqual(Object.keys(allRules).length, 16);
  assert.strictEqual(allRules['channel_delete'].action, 'quarantine');
  console.log('✅ Per-vector rule configuration & persistence verified.');

  // ─────────────────────────────────────────────────────────────
  // 3. Vector-Specific Sliding-Window Rate Limit
  // ─────────────────────────────────────────────────────────────
  // channel_delete rule is now 3 in 20s (trips on 3rd action per standardized Nth semantics)
  assert.strictEqual(checkVectorRateLimit(testGid, testUserId, 'channel_delete'), false, 'Hit 1: within limit');
  assert.strictEqual(checkVectorRateLimit(testGid, testUserId, 'channel_delete'), false, 'Hit 2: within limit');
  assert.strictEqual(checkVectorRateLimit(testGid, testUserId, 'channel_delete'), true, 'Hit 3: rate limit exceeded');
  console.log('✅ Vector-specific sliding-window rate limit evaluation verified.');

  // ─────────────────────────────────────────────────────────────
  // 4. Isolation Quarantine System
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM quarantined_users WHERE guild_id = ?').run(testGid);

  let removedRoles = [];
  let addedRoles = [];
  let appliedTimeout = null;

  const mockGuild = {
    id: testGid,
    ownerId: '999999999999999',
    roles: {
      cache: new Map([
        ['role_admin', { id: 'role_admin', name: 'AdminRole', position: 10 }],
        ['role_mod', { id: 'role_mod', name: 'ModRole', position: 5 }],
        ['q_role', { id: 'q_role', name: 'Celestia Quarantined', position: 1 }]
      ])
    },
    channels: { cache: new Map() },
    members: {
      me: {
        roles: { highest: { position: 100 } },
        permissions: new PermissionsBitField([PermissionsBitField.Flags.ManageRoles])
      }
    }
  };

  const mockMember = {
    id: testUserId,
    guild: mockGuild,
    roles: {
      cache: new Map([
        ['role_admin', { id: 'role_admin', position: 10 }],
        ['role_mod', { id: 'role_mod', position: 5 }]
      ]),
      remove: async (roles) => { removedRoles = Array.isArray(roles) ? roles : [...roles.keys()]; },
      add: async (role) => { addedRoles.push(role.id || role); }
    },
    moderatable: true,
    isCommunicationDisabled: () => true,
    timeout: async (ms) => { appliedTimeout = ms; }
  };

  mockGuild.members.cache = new Map([[testUserId, mockMember]]);
  mockGuild.members.fetch = async () => mockMember;

  // Quarantine Member
  const qResult = await quarantineUser(mockGuild, testUserId, 'Test quarantine violation', { user: { id: 'bot_id' } });
  assert.strictEqual(qResult.success, true);
  assert.strictEqual(isUserQuarantined(testGid, testUserId), true);
  assert.strictEqual(removedRoles.length, 2, 'Must strip existing administrative roles');
  assert.ok(appliedTimeout > 0, 'Must apply 28-day timeout containment');

  // Unquarantine Member
  addedRoles = [];
  const uqResult = await unquarantineUser(mockGuild, testUserId, { user: { id: 'bot_id' } });
  assert.strictEqual(uqResult.success, true);
  assert.strictEqual(isUserQuarantined(testGid, testUserId), false);
  console.log('✅ Isolation Quarantine & Restoration System verified.');

  // ─────────────────────────────────────────────────────────────
  // 5. Disaster Recovery Server Snapshots
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM server_snapshots WHERE guild_id = ?').run(testGid);

  mockGuild.name = 'Celestia Test Server';
  mockGuild.channels.cache = new Map([
    ['ch_general', { id: 'ch_general', name: 'general', type: 0, position: 0 }],
    ['ch_announcements', { id: 'ch_announcements', name: 'announcements', type: 5, position: 1 }]
  ]);

  const snap = await createServerSnapshot(mockGuild, 'test_operator', 'Baseline Snapshot');
  assert.ok(snap && snap.id);
  assert.strictEqual(snap.channelsCount, 2);

  const snapList = listServerSnapshots(testGid);
  assert.strictEqual(snapList.length, 1);
  assert.strictEqual(snapList[0].name, 'Baseline Snapshot');

  let createdChannels = [];
  mockGuild.channels.create = async (opts) => {
    createdChannels.push(opts.name);
    return { name: opts.name };
  };

  // Simulate missing announcement channel during restoration
  mockGuild.channels.cache = new Map([
    ['ch_general', { id: 'ch_general', name: 'general', type: 0 }]
  ]);
  mockGuild.members.me.permissions = new PermissionsBitField([PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.ManageRoles]);

  const restoreRes = await restoreServerSnapshot(mockGuild, snap.id);
  assert.strictEqual(restoreRes.success, true);
  assert.ok(createdChannels.includes('announcements'), 'Must auto-recreate missing announcement channel');

  const delSnap = deleteServerSnapshot(testGid, snap.id);
  assert.strictEqual(delSnap, true);
  assert.strictEqual(listServerSnapshots(testGid).length, 0);
  console.log('✅ Disaster Recovery Snapshot Creation & Rollback verified.');

  // ─────────────────────────────────────────────────────────────
  // 6. Studio & Vector Detail Payload Rendering
  // ─────────────────────────────────────────────────────────────
  const studioPayload = buildAntinukeStudioPayload(mockGuild, '!');
  assert.ok(
    (studioPayload.components && studioPayload.components.length >= 1) ||
    (studioPayload.embeds && studioPayload.embeds.length === 1),
    'Studio payload must provide Components V2 container or embed'
  );

  const detailPayload = buildVectorDetailPayload(mockGuild, 'channel_delete', '!');
  assert.ok(
    (detailPayload.components && detailPayload.components.length >= 1) ||
    (detailPayload.embeds && detailPayload.embeds.length === 1),
    'Detail payload must provide Components V2 container or embed'
  );
  console.log('✅ Studio & Vector Detail Components V2 payloads verified.');

  console.log('🎉 All Antinuke Production Suite tests passed successfully!');
}

runTests().catch(err => {
  console.error('❌ Antinuke Production Suite Test Failed:', err);
  process.exit(1);
});
