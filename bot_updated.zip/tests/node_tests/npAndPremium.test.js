/**
 * Test Suite: NP & NP Manager Operations & Premium Purge Verification
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const path = require('node:path');
const { getMasterDb, getServerDb } = require('../../src/utils/serverDb');
const {
  isOwner,
  isNoPrefix,
  isNpManager,
  parseDuration
} = require('../../src/utils/tools');
const npCmd = require('../../src/commands/security/np');
const npManagerCmd = require('../../src/commands/security/npmanager');

async function runTests() {
  console.log('[TEST] Running npAndPremium.test.js (No-Prefix Suite & Premium Purge Verification)...');
  const mdb = getMasterDb();
  const ownerId = process.env.OWNER_IDS.split(',')[0].trim();
  const testGuildId = '999111222333444';
  const testStaffId = '123450000000000001';
  const testUserId = '123450000000000002';

  // ─────────────────────────────────────────────────────────────
  // 1. Duration Parser Tests
  // ─────────────────────────────────────────────────────────────
  const d1 = parseDuration('30d');
  assert.strictEqual(d1.days, 30);
  assert.strictEqual(d1.seconds, 30 * 86400);

  const d2 = parseDuration('lifetime');
  assert.strictEqual(d2.days, -1);
  assert.strictEqual(d2.seconds, -1);

  const d3 = parseDuration('1w');
  assert.strictEqual(d3.days, 7);
  assert.strictEqual(d3.seconds, 7 * 86400);

  const dInvalid = parseDuration('not_a_duration');
  assert.strictEqual(dInvalid, null);
  console.log('✅ parseDuration helper verified in tools.js.');

  // ─────────────────────────────────────────────────────────────
  // 2. NP Manager Operations
  // ─────────────────────────────────────────────────────────────
  assert.strictEqual(npCmd.name, 'noprefix');
  assert.ok(npCmd.aliases.includes('np'));
  assert.strictEqual(npManagerCmd.name, 'npmanager');
  assert.ok(npManagerCmd.aliases.includes('npm'));

  // A. Appoint NP Manager
  let replyContent = null;
  const mockOwnerMsg = {
    author: { id: ownerId, username: 'BossOwner' },
    guild: { id: testGuildId, name: 'Celestia HQ', ownerId },
    mentions: { users: { first: () => null } },
    reply: (payload) => { replyContent = payload; }
  };

  const mockClient = {
    guilds: { cache: new Map([[testGuildId, { id: testGuildId, name: 'Celestia HQ' }]]) },
    users: {
      fetch: async (id) => ({ id, username: `User_${id}`, send: async () => null })
    }
  };

  // Execute: !np manager add <testStaffId>
  await npCmd.execute(mockOwnerMsg, ['manager', 'add', testStaffId], mockClient, '!');
  assert.ok(replyContent && replyContent.embeds, 'Appoint manager must reply with embed');
  assert.strictEqual(isNpManager(testStaffId), true, 'User should now be verified NP Manager');
  assert.strictEqual(isNoPrefix(testStaffId, testGuildId), true, 'NP Manager automatically has No-Prefix');
  console.log('✅ NP Manager appointment verified.');

  // B. NP Manager Studio Panel
  await npCmd.execute(mockOwnerMsg, ['manager', 'panel'], mockClient, '!');
  assert.ok(replyContent.embeds[0].data.title.includes('NP Manager Studio'), 'Panel must open NP Manager Studio');
  assert.ok(replyContent.components[0].components.length >= 4, 'Must have studio action buttons');

  // Test standalone !npmanager list
  await npManagerCmd.execute(mockOwnerMsg, ['list'], mockClient, '!');
  assert.ok(replyContent.embeds[0].data.title.includes('NP Manager Studio'), 'Standalone command routed to manager studio');

  // ─────────────────────────────────────────────────────────────
  // 3. No-Prefix Grant, Check, and Revoke
  // ─────────────────────────────────────────────────────────────
  const mockManagerMsg = {
    author: { id: testStaffId, username: 'StaffManager' },
    guild: { id: testGuildId, name: 'Celestia HQ', ownerId },
    mentions: { users: { first: () => null } },
    reply: (payload) => { replyContent = payload; }
  };

  // Verify non-owner / NP manager is rejected under owner-only restriction
  await npCmd.execute(mockManagerMsg, ['add', testUserId, '30d'], mockClient, '!');
  assert.strictEqual(replyContent, 'This command can be executed only by Bot Owner.');

  // Bot Owner grants global no-prefix with 30d duration
  await npCmd.execute(mockOwnerMsg, ['add', testUserId, '30d'], mockClient, '!');
  assert.ok(replyContent.embeds[0].data.title.includes('Global No-Prefix Granted'));
  assert.strictEqual(isNoPrefix(testUserId, testGuildId), true, 'Target user must now have No-Prefix access');

  // Check user status
  await npCmd.execute(mockOwnerMsg, ['check', testUserId], mockClient, '!');
  assert.ok(replyContent.embeds[0].data.title.includes('No-Prefix Status'));
  assert.ok(replyContent.embeds[0].data.description.includes('Global No-Prefix Member'));

  // Verify non-owner / NP manager is rejected on remove
  await npCmd.execute(mockManagerMsg, ['remove', testUserId], mockClient, '!');
  assert.strictEqual(replyContent, 'This command can be executed only by Bot Owner.');

  // Bot Owner revokes no-prefix
  await npCmd.execute(mockOwnerMsg, ['remove', testUserId], mockClient, '!');
  assert.strictEqual(isNoPrefix(testUserId, testGuildId), false, 'Target user should no longer have No-Prefix');

  // Revoke NP Manager
  await npCmd.execute(mockOwnerMsg, ['manager', 'remove', testStaffId], mockClient, '!');
  assert.strictEqual(isNpManager(testStaffId), false, 'User should no longer be NP Manager');
  console.log('✅ Full No-Prefix grant, check, revoke lifecycle verified.');

  // ─────────────────────────────────────────────────────────────
  // 4. Verification that Premium Artifacts Are Permanently Purged
  // ─────────────────────────────────────────────────────────────
  assert.throws(() => require.resolve('../../src/commands/premium/premium'), {
    code: 'MODULE_NOT_FOUND'
  }, 'premium.js command must be permanently purged');

  assert.throws(() => require.resolve('../../src/commands/premium/premiummanager'), {
    code: 'MODULE_NOT_FOUND'
  }, 'premiummanager.js command must be permanently purged');

  assert.throws(() => require.resolve('../../src/interactions/premium'), {
    code: 'MODULE_NOT_FOUND'
  }, 'premium interaction router must be permanently purged');

  assert.throws(() => require.resolve('../../src/utils/premiumHelper'), {
    code: 'MODULE_NOT_FOUND'
  }, 'premiumHelper utility must be permanently purged');

  console.log('✅ Premium code purge verified (0 remaining references or modules).');

  // ─────────────────────────────────────────────────────────────
  // 5. Hub Payloads
  // ─────────────────────────────────────────────────────────────
  const hubPayload = npCmd.buildNpHubPayload(mockOwnerMsg.guild, mockOwnerMsg.author, '!');
  assert.ok(hubPayload.embeds[0].data.title.includes('No-Prefix Authorization Hub'));
  assert.ok(hubPayload.components[0].components.length === 5);

  console.log('✅ npAndPremium.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ npAndPremium test failed:', err);
  process.exit(1);
});
