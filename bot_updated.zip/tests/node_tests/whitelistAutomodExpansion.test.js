/**
 * Test Suite: Whitelist & Automod Multi-Domain Trust Expansion
 * Tests:
 * 1. Duration parsing (parseDuration)
 * 2. Time-limited whitelist & expiration evaluation (isImmune)
 * 3. Channel whitelisting & multi-scope resolution (isChannelWhitelisted)
 * 4. Whitelist audit logging
 * 5. Banned words engine with Leetspeak deobfuscation
 * 6. Allowed domains link filter
 * 7. Channel-level automod bypass
 * 8. Whitelist Studio payload rendering with 4 ActionRows
 */
const assert = require('node:assert');
const { getServerDb } = require('../../src/utils/serverDb');
const { isImmune, isChannelWhitelisted, clearImmunityCache } = require('../../src/utils/antinukeEngine');
const {
  isAutomodBypassed,
  checkBannedWords,
  checkUnauthorizedLinks,
  addBannedWord,
  getBannedWords,
  clearBannedWords,
  addAllowedDomain,
  getAllowedDomains,
  runAutomodCheck
} = require('../../src/utils/automodEngine');
const { parseDuration, buildWhitelistStudioPayload } = require('../../src/commands/security/whitelist');
const { setSetting } = require('../../src/settings/registry');

async function runTests() {
  console.log('[TEST] Running whitelistAutomodExpansion.test.js...');
  const testGid = '777666555444333';
  const testUserId = '123456789012345';
  const testChannelId = '987654321098765';
  const sdb = getServerDb(testGid);

  // ─────────────────────────────────────────────────────────────
  // 1. Duration Parsing (parseDuration)
  // ─────────────────────────────────────────────────────────────
  assert.strictEqual(parseDuration('30s'), 30);
  assert.strictEqual(parseDuration('15m'), 900);
  assert.strictEqual(parseDuration('2h'), 7200);
  assert.strictEqual(parseDuration('7d'), 604800);
  assert.strictEqual(parseDuration('invalid'), null);
  assert.strictEqual(parseDuration(''), null);
  assert.strictEqual(parseDuration(null), null);
  console.log('✅ parseDuration helper verified for s/m/h/d.');

  // ─────────────────────────────────────────────────────────────
  // 2. Time-Limited Whitelist & Expiration (isImmune)
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM whitelisted_users WHERE guild_id = ?').run(testGid);
  sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('whitelist', '[]')").run();
  clearImmunityCache(testGid);

  const nowSec = Math.floor(Date.now() / 1000);
  const futureExp = nowSec + 3600; // 1h in future
  const pastExp = nowSec - 60;    // 1m in past

  const mockGuild = { id: testGid, ownerId: '999999999999999' };

  // Future authorization
  sdb.prepare(`
    INSERT OR REPLACE INTO whitelisted_users (guild_id, user_id, action, expires_at, added_by)
    VALUES (?, ?, 'all', ?, 'admin')
  `).run(testGid, testUserId, futureExp);
  clearImmunityCache(testGid);

  assert.strictEqual(isImmune(mockGuild, testUserId, 'ban'), true, 'User with future expiration must be immune');

  // Expired authorization
  sdb.prepare(`
    INSERT OR REPLACE INTO whitelisted_users (guild_id, user_id, action, expires_at, added_by)
    VALUES (?, ?, 'all', ?, 'admin')
  `).run(testGid, testUserId, pastExp);
  clearImmunityCache(testGid);

  assert.strictEqual(isImmune(mockGuild, testUserId, 'ban'), false, 'User with expired authorization must NOT be immune');
  console.log('✅ Temporary user authorization and expiration logic verified.');

  // ─────────────────────────────────────────────────────────────
  // 3. Channel Whitelisting (isChannelWhitelisted)
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ?').run(testGid);
  clearImmunityCache(testGid);

  assert.strictEqual(isChannelWhitelisted(testGid, testChannelId, 'all'), false);

  sdb.prepare(`
    INSERT INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at)
    VALUES (?, ?, 'automod', 'admin', ?)
  `).run(testGid, testChannelId, nowSec);

  assert.strictEqual(isChannelWhitelisted(testGid, testChannelId, 'automod'), true, 'Channel must be whitelisted for automod scope');
  assert.strictEqual(isChannelWhitelisted(testGid, testChannelId, 'ban'), false, 'Channel should not be whitelisted for other unconfigured scopes');

  // Whitelist for 'all'
  sdb.prepare(`
    INSERT OR REPLACE INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at)
    VALUES (?, ?, 'all', 'admin', ?)
  `).run(testGid, testChannelId, nowSec);

  assert.strictEqual(isChannelWhitelisted(testGid, testChannelId, 'links'), true, 'Scope all must authorize links');
  assert.strictEqual(isChannelWhitelisted(testGid, testChannelId, 'spam'), true, 'Scope all must authorize spam');
  console.log('✅ Multi-scope channel whitelisting verified.');

  // ─────────────────────────────────────────────────────────────
  // 4. Whitelist Audit Logging
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM whitelist_audit_log WHERE guild_id = ?').run(testGid);
  sdb.prepare(`
    INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp)
    VALUES (?, 'user', ?, 'ban', 'admin_1', 'whitelist', ?)
  `).run(testGid, testUserId, nowSec);

  const auditEntry = sdb.prepare('SELECT * FROM whitelist_audit_log WHERE guild_id = ? AND target_id = ?').get(testGid, testUserId);
  assert.ok(auditEntry, 'Audit log entry must be recorded');
  assert.strictEqual(auditEntry.operation, 'whitelist');
  assert.strictEqual(auditEntry.action_scope, 'ban');
  console.log('✅ Whitelist audit logging verified.');

  // ─────────────────────────────────────────────────────────────
  // 5. Banned Words Engine with Leetspeak Deobfuscation
  // ─────────────────────────────────────────────────────────────
  clearBannedWords(testGid);
  addBannedWord(testGid, 'scamword', 'admin');
  const words = getBannedWords(testGid);
  assert.ok(words.some(w => w.word === 'scamword'), 'scamword must be in banned words list');

  assert.strictEqual(checkBannedWords('Clean message here', words), null);
  assert.strictEqual(checkBannedWords('Check out this scamword now', words), 'scamword');
  assert.strictEqual(checkBannedWords('Check out this $c@mw0rd now', words), 'scamword', 'Leetspeak $c@mw0rd must be matched');
  assert.strictEqual(checkBannedWords('Check out this s.c.a.m.w.o.r.d now', words), 'scamword', 'Punctuation obfuscated scamword must be matched');
  console.log('✅ Banned words engine with Leetspeak deobfuscation verified.');

  // ─────────────────────────────────────────────────────────────
  // 6. Allowed Domains Link Filter
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM automod_allowed_domains WHERE guild_id = ?').run(testGid);
  addAllowedDomain(testGid, 'github.com', 'admin');
  addAllowedDomain(testGid, 'celestia.bot', 'admin');

  const allowedDomains = getAllowedDomains(testGid);
  assert.ok(allowedDomains.some(d => d.domain === 'github.com'), 'github.com must be in allowed domains list');

  // Authorized link
  const safeHost = checkUnauthorizedLinks('Check our code at https://github.com/celestia/bot', allowedDomains);
  assert.strictEqual(safeHost, null, 'github.com must be allowed');

  // Unauthorized link
  const badHost = checkUnauthorizedLinks('Visit http://malicious-drop.top/nitro for rewards', allowedDomains);
  assert.strictEqual(badHost, 'malicious-drop.top', 'malicious-drop.top must be detected as unauthorized');
  console.log('✅ Allowed domains link filter verified.');

  // ─────────────────────────────────────────────────────────────
  // 7. Channel-Level Automod Bypass in runAutomodCheck
  // ─────────────────────────────────────────────────────────────
  setSetting(testGid, 'automod.link.enabled', true, 'test');
  const normalUser = { id: '777888999000111', bot: false };
  const mockMember = { id: normalUser.id, permissions: { has: () => false } };

  // Message in non-whitelisted channel -> BLOCKED
  const nonWlChannel = { id: '111222333444555', send: async () => null };
  const fakeMsgBlocked = {
    guild: mockGuild,
    author: normalUser,
    member: mockMember,
    content: 'Check out https://unauthorized-domain.com/free',
    channel: nonWlChannel,
    delete: async () => null
  };

  const isBlocked = await runAutomodCheck(fakeMsgBlocked, {});
  assert.strictEqual(isBlocked, true, 'Link in non-whitelisted channel must be intercepted');

  // Message in whitelisted channel (testChannelId is whitelisted for all) -> BYPASS
  const wlChannel = { id: testChannelId, send: async () => null };
  const fakeMsgBypassed = {
    guild: mockGuild,
    author: normalUser,
    member: mockMember,
    content: 'Check out https://unauthorized-domain.com/free',
    channel: wlChannel,
    delete: async () => null
  };

  const isBypassed = await runAutomodCheck(fakeMsgBypassed, {});
  assert.strictEqual(isBypassed, false, 'Link in whitelisted channel must bypass automod');
  console.log('✅ Channel-level Automod bypass pipeline verified.');

  // ─────────────────────────────────────────────────────────────
  // 8. Whitelist Studio Payload Rendering
  // ─────────────────────────────────────────────────────────────
  const studioPayload = buildWhitelistStudioPayload(mockGuild, sdb, '!', 'Operator');
  assert.ok(
    (studioPayload.components && studioPayload.components.length >= 1) ||
    (studioPayload.embeds && studioPayload.embeds.length === 1),
    'Studio payload must provide Components V2 container or embed'
  );
  console.log('✅ Whitelist Studio payload rendering verified.');

  // ─────────────────────────────────────────────────────────────
  // 9. Target Whitelist Interactive UI & Action Toggle Matrix
  // ─────────────────────────────────────────────────────────────
  const { buildTargetWhitelistPayload, toggleWhitelistAction, revokeWhitelistTarget } = require('../../src/utils/whitelistUi');

  // Test User Payload & Toggle
  sdb.prepare('DELETE FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').run(testGid, testUserId);
  const userPayload = buildTargetWhitelistPayload(mockGuild, sdb, 'user', testUserId, '!');
  assert.ok(
    (userPayload.components && userPayload.components.length >= 1) ||
    (userPayload.embeds && userPayload.embeds.length === 1),
    'User whitelist card must provide Components V2 container or embed'
  );
  
  // Toggle 'ban' on user (starts empty -> grants ban)
  toggleWhitelistAction(testGid, sdb, 'user', testUserId, 'ban', 'operator123');
  const userActions = sdb.prepare('SELECT action FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').all(testGid, testUserId).map(r => r.action);
  assert.ok(userActions.includes('ban'), 'User must have ban action granted');

  // Toggle 'ban' off user (grants -> revokes ban)
  toggleWhitelistAction(testGid, sdb, 'user', testUserId, 'ban', 'operator123');
  const userActionsAfter = sdb.prepare('SELECT action FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').all(testGid, testUserId).map(r => r.action);
  assert.ok(!userActionsAfter.includes('ban'), 'User must have ban action revoked');

  // Toggle 'all' on user
  toggleWhitelistAction(testGid, sdb, 'user', testUserId, 'all', 'operator123');
  const userActionsAll = sdb.prepare('SELECT action FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').all(testGid, testUserId).map(r => r.action);
  assert.ok(userActionsAll.includes('all'), 'User must have all actions granted');

  // When 'all' is active, toggling 'ban' expands all except ban
  toggleWhitelistAction(testGid, sdb, 'user', testUserId, 'ban', 'operator123');
  const userActionsWithoutBan = sdb.prepare('SELECT action FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').all(testGid, testUserId).map(r => r.action);
  assert.ok(!userActionsWithoutBan.includes('ban'), 'Ban action must be excluded');
  assert.ok(userActionsWithoutBan.includes('kick'), 'Kick action must be preserved');

  // Channel Payload & Toggle
  const chanPayload = buildTargetWhitelistPayload(mockGuild, sdb, 'channel', testChannelId, '!');
  assert.ok(
    (chanPayload.components && chanPayload.components.length >= 1) ||
    (chanPayload.embeds && chanPayload.embeds.length === 1),
    'Channel whitelist card must provide Components V2 container or embed'
  );

  // Extra Owner Payload
  const eoPayload = buildTargetWhitelistPayload(mockGuild, sdb, 'extraowner', '444555666777', '!');
  assert.ok(
    (eoPayload.components && eoPayload.components.length >= 1) ||
    (eoPayload.embeds && eoPayload.embeds.length === 1),
    'Extra owner card must provide Components V2 container or embed'
  );

  // Revoke Target
  revokeWhitelistTarget(testGid, sdb, 'user', testUserId, 'operator123');
  const remaining = sdb.prepare('SELECT 1 FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').get(testGid, testUserId);
  assert.strictEqual(remaining, undefined, 'User must be fully revoked');
  console.log('✅ Target Whitelist interactive buttons & Action Toggle Matrix verified.');

  console.log('🎉 All Whitelist & Automod Expansion tests passed successfully!');
}

runTests().catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
