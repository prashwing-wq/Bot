/**
 * Test Suite: Help UI & Category Selection
 */
const assert = require('node:assert');
const {
  CATEGORIES,
  buildHomeEmbed,
  buildCategoryEmbed,
  createHelpComponents
} = require('../../src/utils/helpUi');

console.log('[TEST] Running helpUi.test.js...');

async function runTests() {
  // 1. Verify Categories Structure
assert.ok(Array.isArray(CATEGORIES), 'CATEGORIES must be an array');
assert.ok(CATEGORIES.length >= 7, 'Must have at least 7 categories defined');

const ids = new Set();
for (const cat of CATEGORIES) {
  assert.ok(cat.id, 'Category must have an id');
  assert.ok(cat.label, 'Category must have a label');
  assert.ok(cat.emoji, 'Category must have an emoji');
  assert.ok(cat.description, 'Category must have a description');
  assert.ok(!ids.has(cat.id), `Duplicate category id found: ${cat.id}`);
  ids.add(cat.id);
}
console.log(`✅ Verified ${CATEGORIES.length} distinct categories.`);

// 2. Mock client and user
const mockClient = {
  commands: new Map([
    ['help', { name: 'help', description: 'Interactive help guide' }],
    ['ping', { name: 'ping', description: 'Bot latency' }],
    ['stats', { name: 'stats', description: 'Bot stats' }],
    ['ban', { name: 'ban', description: 'Ban a member' }],
    ['kick', { name: 'kick', description: 'Kick a member' }]
  ]),
  categories: new Map([
    ['utility', [
      { name: 'help', description: 'Interactive help guide' },
      { name: 'ping', description: 'Bot latency' },
      { name: 'stats', description: 'Bot stats' }
    ]],
    ['moderation', [
      { name: 'ban', description: 'Ban a member' },
      { name: 'kick', description: 'Kick a member' }
    ]]
  ]),
  config: {
    COLORS: {
      PRIMARY: 0x2b2d31,
      SUCCESS: 0x57f287,
      WARNING: 0xfee75c,
      DANGER: 0xed4245,
      INFO: 0x5865f2
    }
  },
  user: {
    username: 'Celestia'
  }
};

const mockUser = {
  username: 'TestUser',
  displayAvatarURL: () => 'https://example.com/avatar.png'
};

// 3. Test buildHomeEmbed
const homeEmbed = buildHomeEmbed(mockClient, '!', mockUser);
assert.strictEqual(homeEmbed.data.title, "Hey , I'm Tungsten™", 'Home embed title check');
assert.ok(homeEmbed.data.description.toLowerCase().includes('select') || homeEmbed.data.description.includes('Choose a Specific Module'), 'Home embed instructions check');
assert.ok(homeEmbed.data.description.length > 50, 'Home embed should contain clean overview');
assert.ok(!homeEmbed.data.description.includes('```ansi'), 'Home embed must not contain broken ANSI buttons panel');
console.log('✅ buildHomeEmbed created valid rich embed with clean card layout.');

// 4. Test buildCategoryEmbed
const modMeta = CATEGORIES.find(c => c.id === 'moderation');
const modCmds = mockClient.categories.get('moderation');
const catEmbed = buildCategoryEmbed(modMeta, modCmds, 0, mockClient, '!', mockUser);
assert.ok(catEmbed.data.title.includes('Moderation'), 'Category embed title check');
assert.ok(catEmbed.data.description.includes('ban'), 'Category embed contains command ban');
assert.ok(catEmbed.data.description.includes('kick'), 'Category embed contains command kick');
assert.ok(!catEmbed.data.description.includes('```ansi'), 'Category embed must not contain broken ANSI buttons panel');
console.log('✅ buildCategoryEmbed created clean card layout with pagination and native ActionRow delivery.');

// 5. Test createHelpComponents for Home view
const homeComponents = createHelpComponents('home', 0, 1, mockClient);
assert.strictEqual(homeComponents.length, 1, 'Home view must have 1 ActionRow (Dropdown)');
// Row 0 must be StringSelectMenu
const homeSelectMenu = homeComponents[0].components[0];
assert.strictEqual(homeSelectMenu.data.type, 3, 'Row 0 must be StringSelectMenu (type 3)');
assert.strictEqual(homeSelectMenu.data.custom_id, 'help:select_category');
assert.strictEqual(homeSelectMenu.options.length, 23, 'Select menu must have 23 options (1 Home + 22 Categories)');
assert.strictEqual(homeSelectMenu.options[0].data.value, 'home', 'First option in select menu must be Home');
assert.strictEqual(homeSelectMenu.options[0].data.label, 'Home', 'First option label must be Home');
assert.strictEqual(homeSelectMenu.options[0].data.description, 'Overview and Information', 'First option description check');
for (const opt of homeSelectMenu.options) {
  assert.ok(!opt.data.default, `Option ${opt.data.value} must not have default: true`);
}
console.log('✅ Home components: Row 0 dropdown verified (23 options, Home first, no default: true).');

// 6. Test createHelpComponents for Category view
const catComponents = createHelpComponents('moderation', 0, 2, mockClient);
assert.strictEqual(catComponents.length, 2, 'Category view has 2 ActionRows (Nav Buttons + Dropdown)');
const navRow = catComponents[0].components;
assert.strictEqual(navRow.length, 5, 'Row 0 has 5 navigation buttons');
assert.strictEqual(navRow[0].data.custom_id, 'help:cat_first:0');
assert.strictEqual(navRow[1].data.custom_id, 'help:cat_prev:0');
assert.strictEqual(navRow[2].data.custom_id, 'help:close');
assert.strictEqual(navRow[3].data.custom_id, 'help:cat_next:0');
assert.strictEqual(navRow[4].data.custom_id, 'help:cat_last:0');
assert.strictEqual(catComponents[1].components[0].data.custom_id, 'help:select_category');
console.log('✅ Category components: Dynamic navigation verified.');

// 7. Test Pagination Card (Page 1)
const multiCmds = [
  { name: 'c1', description: 'cmd 1' }, { name: 'c2', description: 'cmd 2' },
  { name: 'c3', description: 'cmd 3' }, { name: 'c4', description: 'cmd 4' },
  { name: 'c5', description: 'cmd 5' }, { name: 'c6', description: 'cmd 6' },
  { name: 'c7', description: 'cmd 7' }, { name: 'c8', description: 'cmd 8' },
  { name: 'c9', description: 'cmd 9' }, { name: 'c10', description: 'cmd 10' }
];
const { buildCommandEmbed, createCommandComponents, buildHomePayload, buildCategoryPayload, buildCommandPayload } = require('../../src/utils/helpUi');
const page1Embed = buildCategoryEmbed(modMeta, multiCmds, 1, mockClient, '!', mockUser);
assert.ok(!page1Embed.data.description.includes('```ansi'), 'Pagination page 1 must not contain broken ANSI buttons panel');
assert.ok(page1Embed.data.description.includes('c9'), 'Pagination page 1 must display commands');
console.log('✅ Pagination card clean description and slice boundaries verified.');

// 8. Test Command Guide View (buildCommandEmbed)
const cmdGuideEmbed = buildCommandEmbed({ name: 'ban', description: 'Ban a member', usage: '<@user> [reason]', category: 'moderation', cooldown: 5, aliases: ['b'] }, mockClient, '!', mockUser);
assert.ok(!cmdGuideEmbed.data.description.includes('```ansi'), 'Command guide embed must not contain broken ANSI buttons panel');
assert.ok(cmdGuideEmbed.data.description.includes('Ban a member'), 'Command guide must have description');
const cmdGuideComps = createCommandComponents();
assert.strictEqual(cmdGuideComps.length, 1, 'Command guide must have 1 ActionRow');
assert.strictEqual(cmdGuideComps[0].components[0].data.custom_id, 'help:home');
assert.strictEqual(cmdGuideComps[0].components[2].data.custom_id, 'help:close');
console.log('✅ Command guide view clean embed and ActionRows verified.');

// 9. Test Unified Payloads
const homePayload = buildHomePayload(mockClient, '!', mockUser);
assert.strictEqual(homePayload.embeds[0].data.title, "Hey , I'm Tungsten™", 'buildHomePayload title check');
assert.ok(!homePayload.embeds[0].data.description.includes('```ansi'), 'buildHomePayload must deliver clean rich embed without ANSI pseudo-panels');
assert.ok(homePayload.components.length >= 1, 'buildHomePayload includes components');

const catPayload = buildCategoryPayload(modMeta, modCmds, 0, mockClient, '!', mockUser);
assert.ok(catPayload.embeds[0].data.title.includes('Moderation'), 'buildCategoryPayload title check');
assert.ok(!catPayload.embeds[0].data.description.includes('```ansi'), 'buildCategoryPayload must deliver clean rich embed without ANSI pseudo-panels');
assert.ok(catPayload.components.length >= 1, 'buildCategoryPayload includes components');

const cmdPayload = buildCommandPayload({ name: 'ping', description: 'Latency' }, mockClient, '!', mockUser);
assert.ok(cmdPayload.embeds[0].data.title.includes('ping'), 'buildCommandPayload title check');
assert.ok(!cmdPayload.embeds[0].data.description.includes('```ansi'), 'buildCommandPayload must deliver clean rich embed without ANSI pseudo-panels');
assert.ok(cmdPayload.components.length >= 1, 'buildCommandPayload includes components');
console.log('✅ Unified payload builders verified across home, category, and command views.');

// 10. Test src/interactions/help.js Router
const helpRouter = require('../../src/interactions/help');
assert.strictEqual(helpRouter.prefix, 'help', 'Router must have prefix help');
assert.ok(Array.isArray(helpRouter.prefixes) && helpRouter.prefixes.includes('help'), 'Router must include help in prefixes');

let updatedPayload = null;
function createMockInteraction(customId, values = []) {
  updatedPayload = null;
  const mock = {
    customId,
    values,
    user: mockUser,
    guild: { id: '123456789' },
    message: { delete: async () => true },
    deferred: false,
    replied: false,
    deferUpdate: async () => { mock.deferred = true; return true; },
    update: async (payload) => { updatedPayload = payload; return true; },
    reply: async (payload) => { updatedPayload = payload; mock.replied = true; return true; },
    editReply: async (payload) => { updatedPayload = payload; return payload; },
    followUp: async (payload) => { updatedPayload = payload; return payload; }
  };
  return mock;
}

// 10a. help:home interaction
let mockInt = createMockInteraction('help:home');
let handled = await helpRouter.handle(mockInt, mockClient);
assert.strictEqual(handled, true);
assert.strictEqual(mockInt.deferred, true, 'help:home must call deferUpdate');
assert.strictEqual(updatedPayload.embeds[0].data.title, "Hey , I'm Tungsten™", 'help:home interaction title check');
assert.ok(!updatedPayload.embeds[0].data.description.includes('```ansi'), 'help:home interaction must deliver clean embed');
assert.ok(updatedPayload.components.length >= 1, 'help:home must return components');

// 10b. help:category_select interaction (moderation)
mockInt = createMockInteraction('help:category_select', ['moderation']);
handled = await helpRouter.handle(mockInt, mockClient);
assert.strictEqual(handled, true);
assert.strictEqual(mockInt.deferred, true, 'help:category_select must call deferUpdate immediately');
assert.ok(updatedPayload.embeds[0].data.title.includes('Moderation'), 'help:category_select title check');
assert.ok(!updatedPayload.embeds[0].data.description.includes('```ansi'), 'help:category_select must deliver clean embed');
assert.ok(updatedPayload.components.length >= 1, 'help:category_select must return components');

// 10c. help:select_category dropdown selecting 'home'
mockInt = createMockInteraction('help:select_category', ['home']);
handled = await helpRouter.handle(mockInt, mockClient);
assert.strictEqual(handled, true);
assert.strictEqual(mockInt.deferred, true, 'help:select_category home selection must call deferUpdate');
assert.strictEqual(updatedPayload.embeds[0].data.title, "Hey , I'm Tungsten™", 'help:select_category selecting home title check');
assert.ok(updatedPayload.components.length >= 1, 'help:select_category home selection must return components');

// 10c. help:cat_moderation shortcut interaction
mockInt = createMockInteraction('help:cat_moderation');
handled = await helpRouter.handle(mockInt, mockClient);
assert.strictEqual(handled, true);
assert.ok(updatedPayload.embeds[0].data.title.includes('Moderation'), 'help:cat_moderation title check');
assert.ok(!updatedPayload.embeds[0].data.description.includes('```ansi'), 'help:cat_moderation must deliver clean embed');

// 10d. help:next:moderation:0 pagination interaction
mockInt = createMockInteraction('help:next:moderation:0');
handled = await helpRouter.handle(mockInt, mockClient);
assert.strictEqual(handled, true);
assert.ok(updatedPayload.embeds[0].data.title.includes('Moderation'), 'help:next pagination title check');
assert.ok(!updatedPayload.embeds[0].data.description.includes('```ansi'), 'help:next pagination must deliver clean embed');

console.log('✅ src/interactions/help.js router execution and native ActionRow delivery verified.');

  // 11. Verify Owner category is completely hidden from public help UI
  assert.strictEqual(CATEGORIES.some(c => c.id === 'owner'), false, 'Owner category must NOT be in public CATEGORIES array');
  const dropdownOptions = homeComponents[0].components[0].options;
  assert.strictEqual(dropdownOptions.some(opt => opt.data.value === 'owner'), false, 'Owner category must NOT be in public help dropdown');
  console.log('✅ Owner help invisibility to standard users verified.');

  // 12. Verify Ping Command UI & Latency Telemetry format
  const pingCmd = require('../../src/commands/utility/ping');
  assert.strictEqual(pingCmd.name, 'ping');
  assert.deepStrictEqual(pingCmd.permissions, []);

  let pingSlashReply = null;
  const mockPingSlashInteraction = {
    guild: { id: 'test_guild_ping' },
    deferReply: async () => true,
    editReply: async (payload) => { pingSlashReply = payload; return payload; }
  };
  await pingCmd.executeSlash(mockPingSlashInteraction, mockClient);
  assert.ok(pingSlashReply && pingSlashReply.embeds && pingSlashReply.embeds[0], 'ping slash must reply with embed');
  const slashEmbed = pingSlashReply.embeds[0].data || pingSlashReply.embeds[0];
  assert.strictEqual(slashEmbed.title, 'Latency', 'Ping slash embed title must be Latency');
  assert.ok(slashEmbed.description.includes('**Network**'), 'Ping slash description must include Network header');
  assert.ok(slashEmbed.description.includes('**Engine**'), 'Ping slash description must include Engine header');
  assert.ok(!slashEmbed.description.includes('<a:celestia_'), 'Ping slash description must have 0 animated emojis');
  assert.ok(!slashEmbed.description.includes('OPTIMAL'), 'Ping slash description must not have ALL CAPS OPTIMAL');

  let pingPrefixReply = null;
  let pingPrefixEdit = null;
  const mockMsg = {
    guild: { id: 'test_guild_ping' },
    createdTimestamp: Date.now() - 50,
    reply: async (payload) => {
      pingPrefixReply = payload;
      return {
        edit: async (up) => { pingPrefixEdit = up; return up; }
      };
    }
  };
  await pingCmd.execute(mockMsg, [], mockClient);
  assert.ok(pingPrefixReply && pingPrefixReply.embeds && pingPrefixReply.embeds[0], 'ping prefix must reply with embed');
  const prefixEmbed = pingPrefixReply.embeds[0].data || pingPrefixReply.embeds[0];
  assert.strictEqual(prefixEmbed.title, 'Latency', 'Ping prefix embed title must be Latency');
  assert.ok(prefixEmbed.description.includes('**Network**'), 'Ping prefix description must include Network header');
  assert.ok(prefixEmbed.description.includes('**Engine**'), 'Ping prefix description must include Engine header');
  assert.ok(!prefixEmbed.description.includes('<a:celestia_'), 'Ping prefix description must have 0 animated emojis');
  console.log('✅ Ping latency command UI verified across slash and prefix execution.');

  console.log('✅ helpUi.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ helpUi.test.js failed:', err);
  process.exit(1);
});

