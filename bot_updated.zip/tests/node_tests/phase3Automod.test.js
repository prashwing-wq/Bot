/**
 * Test Suite: Phase 3 Automod 2.0 & Escalation Ladder (§9.1, §9.2)
 * Tests:
 * 1. Phishing & Malicious Nitro Scam Detection
 * 2. Proper Unicode Extended_Pictographic Emoji Regex (No false positives on standard CJK/symbols)
 * 3. Duplicate Message Spam Detection
 * 4. 5-Tier Escalation Ladder with Mod Case integration
 * 5. 24h Strike Decay
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const { getServerDb } = require('../../src/utils/serverDb');
const {
  runAutomodCheck,
  handleAutomodEscalation,
  PHISHING_REGEX,
  UNICODE_EMOJI_REGEX
} = require('../../src/utils/automodEngine');

async function runTests() {
  console.log('[TEST] Running phase3Automod.test.js...');
  const testGid = '999888111222333';
  const testUserId = '111222333444555';
  const sdb = getServerDb(testGid);

  // ─────────────────────────────────────────────────────────────
  // 1. Phishing & Scam Regex Tests (§9.1)
  // ─────────────────────────────────────────────────────────────
  assert.ok(PHISHING_REGEX.test('Claim your free nitro at https://discord-nitro.gift/claim'));
  assert.ok(PHISHING_REGEX.test('Steam card drop: https://steamcommunity-trade.top/gift'));
  assert.ok(PHISHING_REGEX.test('Get gift https://dlscord.gg/free-nitro'));
  assert.strictEqual(PHISHING_REGEX.test('Join our normal discord server at https://discord.gg/celestia'), false);
  console.log('✅ Phishing & Malicious scam patterns verified.');

  // ─────────────────────────────────────────────────────────────
  // 2. Unicode Extended Pictographic Emojis (§9.1)
  // ─────────────────────────────────────────────────────────────
  const textWithEmojis = 'Hello 😀 🎉 🚀 💎 🔥 👑';
  const matches = textWithEmojis.match(UNICODE_EMOJI_REGEX) || [];
  assert.strictEqual(matches.length, 6, 'Should extract exactly 6 pictorial emojis');

  const textWithPunctuation = 'Standard punctuation: $100, 2026, 【Test Bracket】, → Arrow, #hash, @test';
  const falseMatches = textWithPunctuation.match(UNICODE_EMOJI_REGEX) || [];
  assert.strictEqual(falseMatches.length, 0, 'Must NOT match standard punctuation, currency, or CJK symbols');
  console.log('✅ Unicode Extended_Pictographic regex verified without false positives.');

  // ─────────────────────────────────────────────────────────────
  // 3. 5-Tier Escalation Ladder & Mod Cases Integration (§9.2)
  // ─────────────────────────────────────────────────────────────
  sdb.prepare('DELETE FROM automod_strikes WHERE guild_id = ?').run(testGid);
  sdb.prepare('DELETE FROM mod_cases WHERE guild_id = ?').run(testGid);
  sdb.prepare('DELETE FROM member_warnings WHERE guild_id = ?').run(testGid);

  let timedOutMs = null;
  let kicked = false;

  const mockGuild = { id: testGid };
  const mockMember = {
    id: testUserId,
    guild: mockGuild,
    moderatable: true,
    kickable: true,
    timeout: async (ms) => { timedOutMs = ms; },
    kick: async () => { kicked = true; }
  };
  const mockClient = { user: { id: '1550436986320584714' } };

  // Strike 1: Delete + Notice
  const s1 = await handleAutomodEscalation(mockGuild, mockMember, 'Link spam', mockClient);
  assert.strictEqual(s1.strikes, 1);
  assert.strictEqual(s1.action, 'delete');

  // Strike 2: Formal Warning
  const s2 = await handleAutomodEscalation(mockGuild, mockMember, 'Invite spam', mockClient);
  assert.strictEqual(s2.strikes, 2);
  assert.strictEqual(s2.action, 'warn');
  const warnRow = sdb.prepare('SELECT * FROM member_warnings WHERE guild_id = ? AND user_id = ?').get(testGid, testUserId);
  assert.ok(warnRow, 'Formal warning must be logged in member_warnings table');
  const case2 = sdb.prepare('SELECT * FROM mod_cases WHERE guild_id = ? AND user_id = ? AND action = ?').get(testGid, testUserId, 'warn');
  assert.ok(case2, 'Mod case must be created for Strike 2 warn');

  // Strike 3: 10m Timeout
  const s3 = await handleAutomodEscalation(mockGuild, mockMember, 'Mass ping', mockClient);
  assert.strictEqual(s3.strikes, 3);
  assert.strictEqual(s3.action, 'timeout_10m');
  assert.strictEqual(timedOutMs, 600000, 'Must apply 10 minute (600,000ms) timeout');
  const case3 = sdb.prepare('SELECT * FROM mod_cases WHERE guild_id = ? AND user_id = ? AND action = ?').get(testGid, testUserId, 'timeout');
  assert.ok(case3, 'Mod case must be created for Strike 3 timeout');

  // Strike 4: 1h Timeout
  timedOutMs = null;
  const s4 = await handleAutomodEscalation(mockGuild, mockMember, 'Spam flood', mockClient);
  assert.strictEqual(s4.strikes, 4);
  assert.strictEqual(s4.action, 'timeout_1h');
  assert.strictEqual(timedOutMs, 3600000, 'Must apply 1 hour (3,600,000ms) timeout');

  // Strike 5: Kick
  const s5 = await handleAutomodEscalation(mockGuild, mockMember, 'Phishing', mockClient);
  assert.strictEqual(s5.strikes, 5);
  assert.strictEqual(s5.action, 'kick');
  assert.strictEqual(kicked, true, 'Member must be kicked on Strike 5');
  const case5 = sdb.prepare('SELECT * FROM mod_cases WHERE guild_id = ? AND user_id = ? AND action = ?').get(testGid, testUserId, 'kick');
  assert.ok(case5, 'Mod case must be created for Strike 5 kick');
  console.log('✅ 5-Tier Escalation ladder (§9.2) verified with member_warnings and mod_cases.');

  // ─────────────────────────────────────────────────────────────
  // 4. 24h Strike Decay Verification (§9.2)
  // ─────────────────────────────────────────────────────────────
  // Simulate last strike occurred 25 hours ago (> 86,400s)
  const twentyFiveHoursAgo = Math.floor(Date.now() / 1000) - (25 * 3600);
  sdb.prepare('UPDATE automod_strikes SET last_strike_at = ? WHERE guild_id = ? AND user_id = ?')
    .run(twentyFiveHoursAgo, testGid, testUserId);

  const decayedStrike = await handleAutomodEscalation(mockGuild, mockMember, 'New violation after decay', mockClient);
  assert.strictEqual(decayedStrike.strikes, 1, 'Strikes must reset to 1 after 24h decay window');
  assert.strictEqual(decayedStrike.action, 'delete');
  console.log('✅ 24-hour strike decay window verified.');

  console.log('✅ phase3Automod.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ phase3Automod test failed:', err);
  process.exit(1);
});
