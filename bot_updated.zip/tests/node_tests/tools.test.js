/**
 * Test Suite: Tools & Placeholders Utilities
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const {
  isOwner,
  isNoPrefix,
  createEmbed,
  getConfig,
  setPrefix,
  blacklistCheck,
  ignoreCheck
} = require('../../src/utils/tools');
const { formatPlaceholders } = require('../../src/utils/placeholders');

console.log('[TEST] Running tools.test.js...');

// 1. Test isOwner & isNoPrefix
const dummyOwner = process.env.OWNER_IDS.split(',')[0].trim();
assert.strictEqual(isOwner(dummyOwner), true, 'dummy owner must return true');
assert.strictEqual(isOwner('1327564898460242015'), false, 'Removed owner ID must return false');
assert.strictEqual(isOwner('1550436986320584714'), false, 'Removed owner ID must return false');
assert.strictEqual(isOwner('999999999999999999'), false, 'Random ID must return false');

assert.strictEqual(isNoPrefix(dummyOwner, 'test_guild'), true, 'dummy owner automatically has no-prefix rights');
assert.strictEqual(isNoPrefix('1327564898460242015', 'test_guild'), false, 'Removed owner ID has no-prefix = false');
assert.strictEqual(isNoPrefix('999999999999999999', 'test_guild'), false, 'Random ID has no-prefix = false');
console.log('✅ isOwner and isNoPrefix checks passed.');

// 2. Test createEmbed
const embed = createEmbed({
  title: 'Test Title',
  description: 'Test Description',
  footer: 'Custom Footer'
});
assert.strictEqual(embed.data.title, 'Test Title');
assert.strictEqual(embed.data.description, 'Test Description');
assert.strictEqual(embed.data.footer.text, 'Custom Footer');

// Test custom emoji stripping in title, author.name, footer.text
const emojiEmbed = createEmbed({
  title: '<a:tungsten_shield:1567242104923627574> Shield Sentinel',
  author: '<a:tungsten_bot:1567242104923627574> Tungsten Bot',
  footer: { text: '<a:tungsten_cross:1567242104923627574> Terminated' }
});
assert.strictEqual(emojiEmbed.data.title, 'Shield Sentinel', 'Must strip custom emoji from title');
assert.strictEqual(emojiEmbed.data.author.name, 'Tungsten Bot', 'Must strip custom emoji from author.name');
assert.strictEqual(emojiEmbed.data.footer.text, 'Terminated', 'Must strip custom emoji from footer.text');

console.log('✅ createEmbed builder passed (including custom emoji stripping in title/author/footer).');

// 3. Test getConfig and setPrefix
const testGuildId = 'test_guild_tools_' + Date.now();
const initialConfig = getConfig(testGuildId);
assert.strictEqual(initialConfig.prefix, '!', 'Default prefix must be !');

const updated = setPrefix(testGuildId, '?');
assert.strictEqual(updated, true, 'setPrefix should succeed');
const newConfig = getConfig(testGuildId);
assert.strictEqual(newConfig.prefix, '?', 'Prefix should now be ?');
console.log('✅ getConfig and setPrefix passed.');

// 4. Test blacklistCheck and ignoreCheck
assert.strictEqual(blacklistCheck(dummyOwner, testGuildId), true, 'Owner never blacklisted');
assert.strictEqual(ignoreCheck('test_channel_id', 'help'), true, 'Default un-ignored channel passes check');
console.log('✅ Blacklist and ignore filters passed.');

// 5. Test replacePlaceholders
const mockMember = {
  id: '123456789',
  user: {
    id: '123456789',
    username: 'TungstenFan',
    tag: 'TungstenFan#0001'
  },
  guild: {
    id: '987654321',
    name: 'Tungsten Realm',
    memberCount: 1500
  },
  toString: () => '<@123456789>'
};

const text = 'Welcome {user.mention} ({user.name}) to {server.name}! We now have {memberCount} members.';
const replaced = formatPlaceholders(text, mockMember, mockMember.guild);
assert.strictEqual(replaced, 'Welcome <@123456789> (TungstenFan) to Tungsten Realm! We now have 1500 members.');
console.log('✅ formatPlaceholders passed.');

console.log('✅ tools.test.js PASSED with 0 errors!\n');
