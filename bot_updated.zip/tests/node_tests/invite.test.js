/**
 * Test Suite: Invite Command Verification
 * Tests: prefix invocation, slash execution, Components V2 link buttons,
 * permissions bitfield, and direct command aliases.
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const inviteCmd = require('../../src/commands/utility/invite');

async function runTests() {
  console.log('[TEST] Running invite.test.js...');

  // 1. Metadata Verification
  assert.strictEqual(inviteCmd.name, 'invite');
  assert.ok(inviteCmd.aliases.includes('botinvite'));
  assert.ok(inviteCmd.aliases.includes('inv'));
  assert.ok(inviteCmd.aliases.includes('invite-bot'));
  assert.strictEqual(inviteCmd.category, 'utility');
  assert.strictEqual(typeof inviteCmd.execute, 'function');
  assert.strictEqual(typeof inviteCmd.executeSlash, 'function');
  console.log('✅ Invite command metadata & aliases verified.');

  const mockClient = {
    user: {
      id: '1550436986320584714',
      username: 'Celestia',
      displayAvatarURL: () => 'https://cdn.discordapp.com/avatars/1550436986320584714/abc.png'
    },
    config: {
      CLIENT_ID: '1550436986320584714'
    }
  };

  // 2. Prefix Execution
  let replyPayload = null;
  const dummyOwner = process.env.OWNER_IDS.split(',')[0].trim();
  const mockMsg = {
    author: { id: dummyOwner, username: 'Prashwin' },
    reply: (payload) => { replyPayload = payload; return Promise.resolve(); }
  };

  await inviteCmd.execute(mockMsg, [], mockClient, '!');
  assert.ok(replyPayload, 'Command must reply with payload');
  assert.ok(replyPayload.embeds && replyPayload.embeds.length > 0, 'Payload must have embed');

  const embedData = replyPayload.embeds[0].data || replyPayload.embeds[0];
  assert.ok(embedData.title.includes('Invite Celestia'), 'Title must invite Celestia');
  assert.ok(embedData.description.includes('permissions=8'), 'Must include Administrator permissions link');
  assert.ok(embedData.description.includes('permissions=1101088902263'), 'Must include Standard permissions link');

  // Verify Components V2 ActionRow buttons
  assert.ok(replyPayload.components && replyPayload.components.length > 0, 'Payload must have ActionRow');
  const buttons = replyPayload.components[0].components;
  assert.strictEqual(buttons.length, 3, 'Must have 3 link action buttons');
  assert.strictEqual(buttons[0].data.label, 'Invite (Administrator)');
  assert.ok(buttons[0].data.url.includes('permissions=8'));
  assert.strictEqual(buttons[1].data.label, 'Invite (Standard)');
  assert.ok(buttons[1].data.url.includes('permissions=1101088902263'));
  assert.strictEqual(buttons[2].data.label, 'Support Server');
  assert.strictEqual(buttons[2].data.url, 'https://discord.gg/tfDMjZS9YJ');
  console.log('✅ Prefix execution & Components V2 OAuth2 links verified.');

  // 3. Slash Execution
  let slashReply = null;
  const mockInteraction = {
    user: { id: dummyOwner, username: 'Prashwin' },
    reply: (payload) => { slashReply = payload; return Promise.resolve(); }
  };

  await inviteCmd.executeSlash(mockInteraction, mockClient);
  assert.ok(slashReply, 'Slash command must reply');
  assert.ok(slashReply.embeds && slashReply.components, 'Slash reply must contain embeds and buttons');
  console.log('✅ Slash command execution verified.');

  // 4. Dedicated Support Command Verification
  const supportCmd = require('../../src/commands/utility/support');
  assert.strictEqual(supportCmd.name, 'support');
  assert.ok(supportCmd.aliases.includes('supportserver'));
  assert.ok(supportCmd.aliases.includes('community'));

  let supportReply = null;
  const mockSupportMsg = {
    author: { id: dummyOwner, username: 'Prashwin' },
    reply: (payload) => { supportReply = payload; return Promise.resolve(); }
  };

  await supportCmd.execute(mockSupportMsg, [], mockClient, '!');
  assert.ok(supportReply && supportReply.embeds && supportReply.components, 'Support must reply with embed and components');
  const supportButtons = supportReply.components[0].components;
  assert.strictEqual(supportButtons[0].data.label, 'Join Support Server');
  assert.strictEqual(supportButtons[0].data.url, 'https://discord.gg/tfDMjZS9YJ');
  assert.strictEqual(supportButtons[1].data.label, 'Invite Celestia');
  console.log('✅ Dedicated Support command and Components V2 link verified.');

  console.log('✅ invite.test.js PASSED with 0 errors!\n');
}

runTests().catch(err => {
  console.error('❌ invite test failed:', err);
  process.exit(1);
});
