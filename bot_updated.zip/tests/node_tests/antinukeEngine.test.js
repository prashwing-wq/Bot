/**
 * Test Suite: Antinuke Engine & Zero-Bypass Sentinel
 */
process.env.OWNER_IDS = process.env.OWNER_IDS || '100000000000000001';
const assert = require('node:assert');
const {
  isAntinukeArmed,
  isImmune,
  clearImmunityCache,
  checkRateLimitExceeded
} = require('../../src/utils/antinukeEngine');
const { getServerDb } = require('../../src/utils/serverDb');

console.log('[TEST] Running antinukeEngine.test.js...');

const testGuildId = '9876543210987654';
const ownerId = '1111222233334444';
const extraOwnerId = '2222333344445555';
const whitelistedId = '3333444455556666';
const regularUserId = '4444555566667777';

const mockGuild = {
  id: testGuildId,
  ownerId: ownerId,
  client: { user: { id: '9999999999999999' } }
};

const sdb = getServerDb(testGuildId);

// 1. Arm Antinuke
sdb.prepare(`
  INSERT INTO server_settings (key, value)
  VALUES ('antinuke_status', '1')
  ON CONFLICT(key) DO UPDATE SET value = '1'
`).run();

assert.strictEqual(isAntinukeArmed(testGuildId), true, 'Antinuke must report as armed');
console.log('✅ isAntinukeArmed verified.');

// 2. Primary Owner is always immune
assert.strictEqual(isImmune(mockGuild, ownerId), true, 'Server Owner must be immune');

// 3. Bot Owner is NOT immune across third-party servers
const dummyOwner = process.env.OWNER_IDS.split(',')[0].trim();
assert.strictEqual(isImmune(mockGuild, dummyOwner), false, 'Bot Owner must NOT be immune without guild grant');

// 4. Regular user is NOT immune
clearImmunityCache(testGuildId);
assert.strictEqual(isImmune(mockGuild, regularUserId), false, 'Regular user must not be immune');

// 5. Extra Owner is immune
sdb.prepare(`
  INSERT OR IGNORE INTO extraowners (guild_id, owner_id, added_at)
  VALUES (?, ?, ?)
`).run(testGuildId, extraOwnerId, Math.floor(Date.now() / 1000));
clearImmunityCache(testGuildId);
assert.strictEqual(isImmune(mockGuild, extraOwnerId), true, 'Extra Owner must be immune');

// 6. Whitelisted User is immune for specific action
sdb.prepare(`
  INSERT OR IGNORE INTO whitelisted_users (guild_id, user_id, action)
  VALUES (?, ?, 'channel')
`).run(testGuildId, whitelistedId);
clearImmunityCache(testGuildId);
assert.strictEqual(isImmune(mockGuild, whitelistedId, 'channel'), true, 'Whitelisted user must be immune for channel action');
assert.strictEqual(isImmune(mockGuild, whitelistedId, 'role'), false, 'Whitelisted user for channel must not be immune for role action');
console.log('✅ Multi-vector trust hierarchy & action-specific whitelist verified.');

// 7. Rate Limiter checks (N actions in window trips on Nth action)
assert.strictEqual(checkRateLimitExceeded(testGuildId, regularUserId, 'channel_delete', 2, 5000), false, 'First action not exceeded');
assert.strictEqual(checkRateLimitExceeded(testGuildId, regularUserId, 'channel_delete', 2, 5000), true, 'Second action trips on limit 2');
console.log('✅ Sliding-window threat rate limiter verified.');

console.log('✅ antinukeEngine.test.js PASSED with 0 errors!\n');
