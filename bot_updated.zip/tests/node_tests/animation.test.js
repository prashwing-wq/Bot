/**
 * Test Suite: Animation & Cyber-Matrix Engine
 */
const assert = require('node:assert');
const {
  sleep,
  getAntinukeEnableFrames,
  getAntinukeDisableFrames,
  getPanicLockdownFrames,
  getNukeCountdownFrames
} = require('../../src/utils/animation');

console.log('[TEST] Running animation.test.js...');

// 1. Sleep helper
const start = Date.now();
sleep(50).then(() => {
  const elapsed = Date.now() - start;
  assert.ok(elapsed >= 40, 'sleep must wait at least specified duration');
});

// 2. Antinuke Enable Frames
const enableFrames = getAntinukeEnableFrames('TestGuild');
assert.strictEqual(enableFrames.length, 4, 'Antinuke enable must have 4 sequential cyber-stages');
for (const frame of enableFrames) {
  assert.ok(frame.data.title.includes('DEFENSE MATRIX'), 'Frame title must indicate defense matrix');
  assert.ok(frame.data.description.includes('```ansi'), 'Frame must contain ANSI color-coded progress telemetry');
}
console.log('✅ 4-stage Antinuke bootloader cyber-matrix verified.');

// 3. Antinuke Disable Frames
const disableFrames = getAntinukeDisableFrames('TestGuild');
assert.strictEqual(disableFrames.length, 3, 'Antinuke disable must have 3 sequential decoupling stages');
for (const frame of disableFrames) {
  assert.ok(frame.data.title.includes('DEFENSE MATRIX'), 'Frame title must indicate defense matrix');
  assert.ok(frame.data.description.includes('```ansi'), 'Frame must contain ANSI progress telemetry');
}
console.log('✅ 3-stage Antinuke decoupling disarm sequence verified.');

// 4. Panic Lockdown Frames
const panicFrames = getPanicLockdownFrames();
assert.ok(panicFrames.length >= 4, 'Panic lockdown must have multi-step isolation stages');
for (const frame of panicFrames) {
  assert.ok(frame.data.title.includes('EMERGENCY PANIC LOCKDOWN'), 'Panic frame title verified');
  assert.ok(frame.data.description.includes('```ansi'), 'Panic frame contains ANSI codeblock');
}
console.log('✅ Emergency panic lockdown frames verified.');

// 5. Nuke Countdown Frames
const nukeFrames = getNukeCountdownFrames('general');
assert.strictEqual(nukeFrames.length, 3, 'Nuke countdown must have 3 countdown frames');
assert.ok(nukeFrames[0].data.description.includes('3...'), 'First frame countdown 3');
assert.ok(nukeFrames[1].data.description.includes('2...'), 'Second frame countdown 2');
assert.ok(nukeFrames[2].data.description.includes('1...'), 'Third frame countdown 1');
console.log('✅ Channel nuke detonation countdown frames verified.');

console.log('✅ animation.test.js PASSED with 0 errors!\n');
