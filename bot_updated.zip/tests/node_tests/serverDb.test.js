/**
 * Server Database Unit Tests (Node.js)
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {
  ensureServerDatabase,
  getServerDb,
  getServerDir,
  getServerDbPath,
  serverFolderExists,
  syncServerDataFromMaster,
  initAllServerFoldersFromMaster
} = require('../../src/utils/serverDb');

async function run() {
  console.log('[TEST] Running serverDb.test.js...');
  const testGid = '999888777001';
  const serverDir = getServerDir(testGid);
  const dbPath = getServerDbPath(testGid);

  // Clean test artifact if exists
  if (fs.existsSync(serverDir)) {
    fs.rmSync(serverDir, { recursive: true, force: true });
  }

  // 1. Test directory provisioning
  const createdPath = ensureServerDatabase(testGid, 'Test Server Node', '123456789', false);
  assert.strictEqual(createdPath, dbPath, 'Created path must match server db path');
  assert.ok(fs.existsSync(serverDir), 'Server directory must exist');
  assert.ok(fs.existsSync(dbPath), 'server.db must exist');
  assert.ok(fs.existsSync(path.join(serverDir, 'metadata.json')), 'metadata.json must exist');

  // 2. Test ignoreIfExists=true
  const existingPath = ensureServerDatabase(testGid, 'Ignored Server', '999', true);
  assert.strictEqual(existingPath, dbPath, 'Must return existing db path');

  // 3. Test Autorole & Welcome read/write in dedicated server.db
  const sdb = getServerDb(testGid);
  sdb.prepare('INSERT OR REPLACE INTO autorole (guild_id, bots, humans) VALUES (?, ?, ?)')
    .run(testGid, JSON.stringify(['111', '222']), JSON.stringify(['333', '444']));

  const arRow = sdb.prepare('SELECT bots, humans FROM autorole WHERE guild_id = ?').get(testGid);
  assert.ok(arRow, 'Autorole row must be readable');
  assert.deepStrictEqual(JSON.parse(arRow.bots), ['111', '222'], 'Bots must match');
  assert.deepStrictEqual(JSON.parse(arRow.humans), ['333', '444'], 'Humans must match');

  sdb.prepare('INSERT OR REPLACE INTO welcome_panel (guild_id, status, channel_id, dm_message) VALUES (?, ?, ?, ?)')
    .run(testGid, 1, '555666777', 'Welcome to our server!');

  const wRow = sdb.prepare('SELECT status, channel_id, dm_message FROM welcome_panel WHERE guild_id = ?').get(testGid);
  assert.ok(wRow, 'Welcome row must be readable');
  assert.strictEqual(wRow.status, 1);
  assert.strictEqual(String(wRow.channel_id), '555666777');
  assert.strictEqual(wRow.dm_message, 'Welcome to our server!');

  // 4. Test 64-bit snowflake RangeError immunity in SQLite (Node 22+)
  sdb.exec('CREATE TABLE IF NOT EXISTS test_bigint_snowflake (id INTEGER PRIMARY KEY, note TEXT)');
  sdb.prepare('INSERT OR REPLACE INTO test_bigint_snowflake (id, note) VALUES (?, ?)').run('1562090786089074789', 'BigInt snowflake');
  const bigRow = sdb.prepare('SELECT id, note FROM test_bigint_snowflake WHERE id = ?').get('1562090786089074789');
  assert.ok(bigRow, '64-bit snowflake row must be read successfully without RangeError');
  assert.strictEqual(String(bigRow.id), '1562090786089074789', '64-bit snowflake matches string representation');

  // 5. Test Composite Indexes in server.db (Fix 1)
  console.log('Testing composite indexes...');
  const indexRows = sdb.prepare("SELECT name FROM sqlite_master WHERE type = 'index'").all();
  const indexNames = new Set(indexRows.map(r => r.name));
  const expectedIndexes = [
    'idx_whitelisted_users_guild_user',
    'idx_whitelisted_roles_guild_role',
    'idx_whitelisted_channels_guild_chan',
    'idx_extraowners_guild_owner',
    'idx_antinuke_rules_guild_vector',
    'idx_automod_strikes_guild_user',
    'idx_audit_logs_timestamp',
    'idx_audit_logs_actor',
    'idx_quarantined_users_guild_user'
  ];
  for (const idx of expectedIndexes) {
    assert.ok(indexNames.has(idx), `Expected composite index ${idx} must exist`);
  }
  console.log('✅ All 9 composite indexes verified.');

  // 6. Test extraowners schema (Fix 2: added_by and added_at)
  console.log('Testing extraowners schema...');
  const eoCols = sdb.prepare("PRAGMA table_info('extraowners')").all();
  const eoColNames = new Set(eoCols.map(c => c.name));
  assert.ok(eoColNames.has('added_by'), 'extraowners must have added_by column');
  assert.ok(eoColNames.has('added_at'), 'extraowners must have added_at column');
  
  // Test extraowners insertion & defaults
  const testOwnerId = '100000000000000010';
  const { addExtraOwner, getExtraOwners, removeExtraOwner } = require('../../src/utils/serverDb');
  addExtraOwner(testGid, testOwnerId, '100000000000000099');
  const eoList = getExtraOwners(testGid);
  const eoEntry = eoList.find(e => e.owner_id === testOwnerId);
  assert.ok(eoEntry, 'Inserted extraowner must exist');
  assert.strictEqual(eoEntry.added_by, '100000000000000099');
  assert.ok(eoEntry.added_at > 0);
  removeExtraOwner(testGid, testOwnerId);
  console.log('✅ extraowners schema and operations verified.');

  // 7. Test SQLite pragmas & WAL checkpointing (Fix 3)
  console.log('Testing SQLite pragmas & WAL checkpointing...');
  const { checkpoint } = require('../../src/utils/sqliteDb');
  assert.strictEqual(typeof checkpoint, 'function', 'checkpoint helper must be exported');
  checkpoint(sdb, 'PASSIVE');
  const journalModeRow = sdb.prepare('PRAGMA journal_mode').get();
  assert.strictEqual(String(journalModeRow.journal_mode).toLowerCase(), 'wal', 'journal_mode must be WAL');
  const syncRow = sdb.prepare('PRAGMA synchronous').get();
  assert.strictEqual(Number(syncRow.synchronous), 1, 'synchronous must be 1 (NORMAL)');
  const cacheRow = sdb.prepare('PRAGMA cache_size').get();
  assert.strictEqual(Number(cacheRow.cache_size), -32000, 'cache_size must be -32000');
  const walAutoRow = sdb.prepare('PRAGMA wal_autocheckpoint').get();
  assert.strictEqual(Number(walAutoRow.wal_autocheckpoint), 1000, 'wal_autocheckpoint must be 1000');
  console.log('✅ SQLite performance pragmas verified.');

  // 8. Test Audit Log Rotation (Fix 4: pruneAuditLogs)
  console.log('Testing audit log pruning...');
  const { pruneAuditLogs } = require('../../src/utils/serverDb');
  assert.strictEqual(typeof pruneAuditLogs, 'function', 'pruneAuditLogs must be exported');
  
  const nowSec = Math.floor(Date.now() / 1000);
  const oldLogSec = nowSec - (120 * 86400); // 120 days ago (older than 90d)
  const recentLogSec = nowSec - (10 * 86400); // 10 days ago (within 90d)
  
  sdb.prepare('INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp) VALUES (?, ?, ?, ?, ?)')
    .run('TEST_OLD_ACTION', '100000000000000001', '100000000000000002', 'Old log', oldLogSec);
  sdb.prepare('INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp) VALUES (?, ?, ?, ?, ?)')
    .run('TEST_RECENT_ACTION', '100000000000000001', '100000000000000002', 'Recent log', recentLogSec);
  
  const deletedCount = pruneAuditLogs(testGid, 90);
  assert.ok(deletedCount >= 1, 'At least 1 old audit log must be pruned');
  
  const remainingLogs = sdb.prepare('SELECT * FROM audit_logs WHERE action LIKE ?').all('TEST_%');
  assert.strictEqual(remainingLogs.length, 1, 'Only recent audit log should remain');
  assert.strictEqual(remainingLogs[0].action, 'TEST_RECENT_ACTION', 'Remaining log must be recent');
  console.log('✅ Audit log pruning verified.');

  // 9. Test Snowflake Validation (Fix 5: validateSnowflake)
  console.log('Testing snowflake validation...');
  const { validateSnowflake, addToWatchlist } = require('../../src/utils/serverDb');
  assert.strictEqual(typeof validateSnowflake, 'function', 'validateSnowflake must be exported');
  
  // Valid snowflakes
  assert.strictEqual(validateSnowflake('100000000000000001'), true);
  assert.strictEqual(validateSnowflake('999888777001'), true);
  assert.strictEqual(validateSnowflake(100000000000000001n), true);
  
  // Invalid snowflakes
  assert.strictEqual(validateSnowflake(''), false);
  assert.strictEqual(validateSnowflake(null), false);
  assert.strictEqual(validateSnowflake(undefined), false);
  assert.strictEqual(validateSnowflake('abc123456789'), false);
  assert.strictEqual(validateSnowflake('12345'), false);
  assert.strictEqual(validateSnowflake('1; DROP TABLE users;'), false);
  
  // Security DB write validation test
  assert.throws(() => {
    addToWatchlist(testGid, 'invalid_id_not_numeric', 'Test reason', '100000000000000099');
  }, /Invalid user snowflake ID/, 'addToWatchlist must reject invalid snowflake IDs');
  console.log('✅ validateSnowflake security validation verified.');

  // Cleanup test guild
  fs.rmSync(serverDir, { recursive: true, force: true });
  console.log('✅ serverDb.test.js PASSED with 0 errors!');
}

module.exports = { run };
if (require.main === module) run();
