/**
 * Tungsten Discord Client (Node.js)
 * High-performance Auto-sharding compatible Discord Client with dynamic command,
 * event, and dedicated per-server database architecture.
 */
const {
  Client,
  GatewayIntentBits,
  Partials,
  Collection
} = require('discord.js');
const { Agent } = require('undici');
const fs = require('fs');
const path = require('path');
const config = require('../config');
const { initAllServerFoldersFromMaster, ensureMasterDatabase, getMasterDbPath, getMasterDb, getServersBaseDir, getDbDir } = require('../utils/serverDb');
const { applyComponentsV2Hooks } = require('../utils/patchComponentsV2');
const { loadCommands } = require('../handlers/commandHandler');
const { loadEvents } = require('../handlers/eventHandler');

const restAgent = new Agent({
  keepAliveTimeout: 30000,
  keepAliveMaxTimeout: 60000,
  pipelining: 1,
  connections: 20,
  connect: { timeout: 10000 }
});

class TungstenClient extends Client {
  constructor(options = {}) {
    super({
      rest: {
        agent: restAgent,
        dispatcher: restAgent,
        timeout: 15000,
        ...(options.rest || {})
      },
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildScheduledEvents,
        GatewayIntentBits.AutoModerationConfiguration,
        GatewayIntentBits.AutoModerationExecution,
        GatewayIntentBits.GuildMessagePolls
      ],
      partials: [
        Partials.Channel,
        Partials.Message,
        Partials.User,
        Partials.GuildMember,
        Partials.Reaction
      ],
      allowedMentions: {
        parse: ['users', 'roles'],
        repliedUser: false
      },
      failIfNotExists: false,
      sweepers: {
        messages: {
          interval: 300,
          lifetime: 1800
        },
        users: {
          interval: 600,
          filter: () => user => user.id !== user.client.user?.id
        },
        threads: {
          interval: 600,
          lifetime: 3600
        }
      },
      ...options
    });

    this.commands = new Collection();
    this.aliases = new Collection();
    this.categories = new Collection();
    this.cooldowns = new Collection();
    this.slashCommands = [];
    this.config = config;
    if (this.rest && typeof this.rest.setAgent === 'function') {
      this.rest.setAgent(restAgent);
    }
    applyComponentsV2Hooks();
  }

  async init() {
    if (this._initialized) {
      return;
    }
    this._initialized = true;

    console.log('[Tungsten Node] Initializing bot subsystems...');

    // 0. Ensure master database is initialized
    ensureMasterDatabase();

    // 1. Safe Startup DB Snapshot (C4: VACUUM INTO for master and all server DBs)
    this._createStartupBackup();

    // 2. Discover & initialize dedicated per-server folders (Ignore if exists)
    try {
      const initialized = initAllServerFoldersFromMaster();
      console.log(`[Tungsten Node] Verified per-server database folders. Newly provisioned: ${initialized}`);
    } catch (e) {
      console.warn(`[Tungsten Node] Notice during server database initialization: ${e.message}`);
    }

    // 3. Load Commands and Events
    await loadCommands(this);
    await loadEvents(this);

    console.log(`[Tungsten Node] Registered ${this.commands.size} commands and ${this.aliases.size} aliases.`);
  }

  _createStartupBackup() {
    try {
      const { isMongoCloudMode } = require('../utils/serverDb');
      if (typeof isMongoCloudMode === 'function' && isMongoCloudMode()) {
        console.log('[Tungsten] Cloud Mode Active: Persistent backups managed by MongoDB Atlas. Skipping local disk backup.');
        return null;
      }

      const masterPath = getMasterDbPath();
      const backupsDir = path.join(getDbDir(), 'backups');
      if (!fs.existsSync(backupsDir)) {
        fs.mkdirSync(backupsDir, { recursive: true });
      }

      const d = new Date();
      const pad = n => String(n).padStart(2, '0');
      const timestampFolder = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}_${d.getTime()}`;
      const targetDir = path.join(backupsDir, timestampFolder);
      fs.mkdirSync(targetDir, { recursive: true });

      // Backup master DB via VACUUM INTO
      const masterName = path.basename(masterPath);
      try {
        const mdb = getMasterDb();
        const masterBackupPath = path.join(targetDir, masterName);
        mdb.exec(`VACUUM INTO '${masterBackupPath.replace(/'/g, "''")}';`);
      } catch (err) {
        if (fs.existsSync(masterPath)) {
          fs.copyFileSync(masterPath, path.join(targetDir, masterName));
        }
      }

      // Backup active guild DBs
      const serversBase = getServersBaseDir();
      if (fs.existsSync(serversBase)) {
        const guildDirs = fs.readdirSync(serversBase);
        for (const gid of guildDirs) {
          const sdbPath = path.join(serversBase, gid, 'server.db');
          if (fs.existsSync(sdbPath)) {
            const guildBackupPath = path.join(targetDir, `${gid}.db`);
            try {
              const { getServerDb } = require('../utils/serverDb');
              const sdb = getServerDb(gid);
              sdb.exec(`VACUUM INTO '${guildBackupPath.replace(/'/g, "''")}';`);
            } catch (e) {
              try { fs.copyFileSync(sdbPath, guildBackupPath); } catch (_) {}
            }
          }
        }
      }

      // Enforce retention (KEEP = 7 default)
      const keep = (this.config.BACKUP && this.config.BACKUP.KEEP) || 7;
      const allSets = fs.readdirSync(backupsDir)
        .map(f => {
          const full = path.join(backupsDir, f);
          try {
            return { name: f, full, stat: fs.statSync(full) };
          } catch (_) {
            return null;
          }
        })
        .filter(entry => entry && entry.stat.isDirectory())
        .sort((a, b) => b.stat.mtimeMs - a.stat.mtimeMs);

      if (allSets.length > keep) {
        for (let i = keep; i < allSets.length; i++) {
          try {
            fs.rmSync(allSets[i].full, { recursive: true, force: true });
          } catch (_) {}
        }
      }

      console.log(`[Tungsten Node] Verified full system backup snapshot saved to: ${targetDir} (Retention: ${keep})`);
      return targetDir;
    } catch (e) {
      console.warn(`[Tungsten Node] Notice creating startup backup: ${e.message}`);
      throw e;
    }
  }

  createBackup() {
    return this._createStartupBackup();
  }

  createStartupBackup() {
    return this._createStartupBackup();
  }

  async start(token = null) {
    await this.init();
    const botToken = token || this.config.TOKEN;
    if (!botToken) {
      console.error('[Tungsten Node] CRITICAL: No Discord token provided! Set DISCORD_TOKEN in .env or environment.');
      process.exit(1);
    }
    await this.login(botToken);
  }
}

module.exports = TungstenClient;
