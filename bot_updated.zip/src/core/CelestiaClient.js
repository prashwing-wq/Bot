/**
 * Backward-compatibility forwarder for CelestiaClient
 */
const TungstenClient = require('./TungstenClient');
module.exports = TungstenClient;
