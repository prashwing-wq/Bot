/**
 * Celestia / Tungsten MongoDB Atlas Cloud Hydrator & Persistence Engine
 * Enables 100% cloud-backed database operation with ZERO local SQLite files on disk.
 * Hydrates in-memory databases from MongoDB Atlas on boot and continuously mirrors writes.
 */
const { getMongoDb, initMongo, isMongoConnected } = require('./mongoClient');

let _writeQueue = [];
let _flushInterval = null;
let _isHydrated = false;

/**
 * Hydrates all in-memory SQLite tables directly from MongoDB Atlas.
 */
async function hydrateAllFromMongo(options = {}) {
  const logger = options.logger || console.log;
  const startTime = Date.now();

  let mongoDb = getMongoDb();
  if (!mongoDb) {
    const initRes = await initMongo();
    if (!initRes || !initRes.db) {
      throw new Error('Could not establish connection to MongoDB Atlas. Check MONGODB_URI in .env.');
    }
    mongoDb = initRes.db;
  }

  const { getMasterDb, getServerDb, registerGuild } = require('./serverDb');
  const masterDb = getMasterDb();

  const stats = {
    masterRowsHydrated: 0,
    guildRowsHydrated: 0,
    guildsHydrated: 0,
    durationMs: 0
  };

  logger('[MongoHydrator] Hydrating databases from MongoDB Atlas into memory...');

  // 1. Hydrate Master Database
  try {
    const masterDocs = await mongoDb.collection('master_records').find({}).toArray();
    for (const doc of masterDocs) {
      const tableName = doc.table;
      if (!tableName) continue;

      const cleanDoc = { ...doc };
      delete cleanDoc._id;
      delete cleanDoc.table;
      delete cleanDoc._synced_at;

      const cols = Object.keys(cleanDoc);
      if (cols.length === 0) continue;

      // Ensure table exists in memory (if dynamic or custom)
      try {
        const placeholders = cols.map(() => '?').join(', ');
        const vals = cols.map(c => typeof cleanDoc[c] === 'object' && cleanDoc[c] !== null ? JSON.stringify(cleanDoc[c]) : cleanDoc[c]);
        masterDb.prepare(`INSERT OR REPLACE INTO "${tableName}" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`).run(...vals);
        stats.masterRowsHydrated++;
      } catch (err) {
        // If table doesn't exist, create it with inferred text columns and retry
        try {
          const colDefs = cols.map(c => `"${c}" TEXT`).join(', ');
          masterDb.exec(`CREATE TABLE IF NOT EXISTS "${tableName}" (${colDefs});`);
          const placeholders = cols.map(() => '?').join(', ');
          const vals = cols.map(c => typeof cleanDoc[c] === 'object' && cleanDoc[c] !== null ? JSON.stringify(cleanDoc[c]) : cleanDoc[c]);
          masterDb.prepare(`INSERT OR REPLACE INTO "${tableName}" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`).run(...vals);
          stats.masterRowsHydrated++;
        } catch (_) {}
      }
    }
    logger(`[MongoHydrator] Master DB hydrated: ${stats.masterRowsHydrated} records.`);
  } catch (err) {
    logger(`[MongoHydrator Error] Hydrating master records: ${err.message}`);
  }

  // 2. Hydrate Guild Databases
  try {
    const guildDocs = await mongoDb.collection('guild_records').find({}).toArray();
    const guildsSeen = new Set();

    for (const doc of guildDocs) {
      const gid = doc.guild_id;
      const tableName = doc.table;
      if (!gid || !tableName) continue;

      guildsSeen.add(gid);
      const sdb = getServerDb(gid);

      const cleanDoc = { ...doc };
      delete cleanDoc._id;
      delete cleanDoc.table;
      delete cleanDoc._synced_at;

      const cols = Object.keys(cleanDoc);
      if (cols.length === 0) continue;

      try {
        const placeholders = cols.map(() => '?').join(', ');
        const vals = cols.map(c => typeof cleanDoc[c] === 'object' && cleanDoc[c] !== null ? JSON.stringify(cleanDoc[c]) : cleanDoc[c]);
        sdb.prepare(`INSERT OR REPLACE INTO "${tableName}" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`).run(...vals);
        stats.guildRowsHydrated++;
      } catch (err) {
        try {
          const colDefs = cols.map(c => `"${c}" TEXT`).join(', ');
          sdb.exec(`CREATE TABLE IF NOT EXISTS "${tableName}" (${colDefs});`);
          const placeholders = cols.map(() => '?').join(', ');
          const vals = cols.map(c => typeof cleanDoc[c] === 'object' && cleanDoc[c] !== null ? JSON.stringify(cleanDoc[c]) : cleanDoc[c]);
          sdb.prepare(`INSERT OR REPLACE INTO "${tableName}" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`).run(...vals);
          stats.guildRowsHydrated++;
        } catch (_) {}
      }
    }
    stats.guildsHydrated = guildsSeen.size;
    logger(`[MongoHydrator] Guild DBs hydrated: ${stats.guildRowsHydrated} records across ${stats.guildsHydrated} servers.`);
  } catch (err) {
    logger(`[MongoHydrator Error] Hydrating guild records: ${err.message}`);
  }

  _isHydrated = true;
  stats.durationMs = Date.now() - startTime;
  logger(`[MongoHydrator] Hydration complete in ${stats.durationMs}ms.`);
  return stats;
}

/**
 * Checks whether the memory databases have been hydrated from Atlas
 */
function isDatabasesHydrated() {
  return _isHydrated;
}

/**
 * Queues a record to be updated in MongoDB Atlas asynchronously
 */
function queueRecordUpsert(prefix, guildId, tableName, doc, customId) {
  _writeQueue.push({
    collName: prefix === 'guild' ? 'guild_records' : 'master_records',
    _id: customId,
    doc: {
      ...doc,
      _id: customId,
      table: tableName,
      ...(prefix === 'guild' && guildId ? { guild_id: String(guildId) } : {}),
      _synced_at: new Date()
    }
  });
}

/**
 * Flushes the real-time write queue to MongoDB Atlas
 */
async function flushWriteQueue() {
  if (_writeQueue.length === 0) return;
  const mongoDb = getMongoDb();
  if (!mongoDb) return;

  const currentBatch = _writeQueue.splice(0, _writeQueue.length);
  const byCollection = new Map();

  for (const item of currentBatch) {
    if (!byCollection.has(item.collName)) {
      byCollection.set(item.collName, []);
    }
    byCollection.get(item.collName).push({
      replaceOne: {
        filter: { _id: item._id },
        replacement: item.doc,
        upsert: true
      }
    });
  }

  for (const [collName, ops] of byCollection.entries()) {
    try {
      await mongoDb.collection(collName).bulkWrite(ops, { ordered: false });
    } catch (_) {}
  }
}

/**
 * Starts continuous real-time background flusher to MongoDB Atlas
 */
function startRealtimeMongoFlusher(intervalMs = 2000) {
  if (_flushInterval) return;
  _flushInterval = setInterval(async () => {
    try {
      await flushWriteQueue();
    } catch (_) {}
  }, intervalMs).unref();
}

/**
 * Stops real-time flusher and drains queue
 */
async function stopRealtimeMongoFlusher() {
  if (_flushInterval) {
    clearInterval(_flushInterval);
    _flushInterval = null;
  }
  await flushWriteQueue();
}

module.exports = {
  hydrateAllFromMongo,
  isDatabasesHydrated,
  queueRecordUpsert,
  flushWriteQueue,
  startRealtimeMongoFlusher,
  stopRealtimeMongoFlusher
};
