/**
 * Tungsten Moderation Logging Utility (modlog.js)
 * Records disciplinary actions into mod_cases table and relays formatted
 * incident reports to the server's designated audit log channel.
 */
const { createEmbed } = require('./tools');

/**
 * Atomically create a new moderation case with transactional isolation.
 * Prevents case-number race conditions under concurrent operations.
 * @param {string} guildId 
 * @param {object} sdb Per-server SQLite database handle
 * @param {object} data
 * @param {string} data.action
 * @param {string} data.targetId
 * @param {string} data.moderatorId
 * @param {string} [data.reason]
 * @param {number} [data.timestamp]
 * @returns {number} Created case number
 */
function createCase(guildId, sdb, { action, targetId, moderatorId, reason, timestamp }) {
  const now = timestamp || Math.floor(Date.now() / 1000);
  const insertCaseTx = sdb.transaction(() => {
    const caseRow = sdb.prepare('SELECT COALESCE(MAX(case_num), 0) + 1 AS next_case FROM mod_cases WHERE guild_id = ?').get(String(guildId));
    const nextNum = caseRow?.next_case || 1;
    sdb.prepare(`
      INSERT INTO mod_cases (guild_id, case_num, action, user_id, moderator_id, reason, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      String(guildId),
      nextNum,
      String(action).toLowerCase(),
      String(targetId),
      String(moderatorId),
      reason || 'No reason provided',
      now
    );
    return nextNum;
  });
  return insertCaseTx();
}

/**
 * Log a moderation action to mod_cases and broadcast to audit log channel if configured.
 * @param {import('discord.js').Guild} guild 
 * @param {object} sdb Per-server SQLite database handle
 * @param {object} options
 * @param {string} options.emoji
 * @param {string} options.action ('ban', 'kick', 'mute', 'unmute', 'warn', 'softban', 'purge', etc.)
 * @param {string} options.targetId Target user ID
 * @param {string} options.moderatorId Moderator user ID
 * @param {string} [options.reason] Disciplinary reason
 * @param {string} [options.extra] Additional metadata
 * @returns {Promise<number>} Created case number
 */
async function logAction(guild, sdb, { emoji = '🛡️', action, targetId, moderatorId, reason, extra = '' }) {
  let caseNum = 1;
  const now = Math.floor(Date.now() / 1000);

  // 1. Record into mod_cases with transactional isolation (Roadmap 2.6 / Review 2.4)
  try {
    caseNum = createCase(guild.id, sdb, {
      action,
      targetId,
      moderatorId,
      reason,
      timestamp: now
    });
  } catch (e) {
    // Non-fatal if mod_cases write fails
  }

  // 2. Dispatch embed to audit log channel (falling back to audit_log_channel if log_mod unset)
  try {
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'log_mod' OR key = 'audit_log_channel'").get();
    if (row && row.value) {
      const channel = guild.channels.cache.get(row.value);
      if (channel && channel.isTextBased()) {
        const fields = [
          { name: 'Target', value: `<@${targetId}> (\`${targetId}\`)`, inline: true },
          { name: 'Moderator', value: `<@${moderatorId}>`, inline: true },
          { name: 'Case #', value: `\`#${caseNum}\``, inline: true },
          { name: 'Reason', value: reason || 'No reason provided', inline: false }
        ];

        if (extra) {
          fields.push({ name: 'Details', value: extra, inline: false });
        }

        const embed = createEmbed({
          color: action.includes('ban') ? 0xED4245 : action.includes('warn') ? 0xFEE75C : 0x5865F2,
          title: `${emoji}  Moderation Action: ${action.toUpperCase()}`,
          fields,
          footer: { text: `User ID: ${targetId} • Tungsten Sentinel` }
        });

        await channel.send({ embeds: [embed] }).catch(() => null);
      }
    }
  } catch (e) {
    // Audit logging failure is non-fatal
  }

  return caseNum;
}

module.exports = {
  createCase,
  logAction
};
