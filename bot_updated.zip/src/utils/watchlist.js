/**
 * Watchlist Surveillance & Enhanced Threat Monitoring Engine (Node.js)
 * Manages flagged accounts under heightened zero-tolerance surveillance.
 */
const { getServerDb } = require('./serverDb');

/**
 * Ensures the watchlist schema exists with the expires_at column.
 * Safe to call idempotently across server databases.
 * @param {object} db Database instance
 */
function ensureWatchlistTable(db) {
  if (!db) return;
  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS watchlist (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        reason TEXT,
        added_by TEXT NOT NULL,
        added_at INTEGER NOT NULL,
        expires_at INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
      );
      CREATE INDEX IF NOT EXISTS idx_watchlist_guild_user ON watchlist(guild_id, user_id);
    `);
    try {
      db.exec('ALTER TABLE watchlist ADD COLUMN expires_at INTEGER DEFAULT 0;');
    } catch (_) {
      // Column already exists
    }
  } catch (err) {
    console.error('[Watchlist] Schema verification error:', err.message);
  }
}

/**
 * Checks whether a user is active on the guild's surveillance watchlist.
 * Expired entries are automatically pruned and evaluated as false.
 * @param {string} guildId Guild snowflake ID
 * @param {string} userId User snowflake ID
 * @returns {boolean} True if currently watchlisted
 */
function isWatchlisted(guildId, userId) {
  if (!guildId || !userId) return false;
  try {
    const db = getServerDb(String(guildId));
    ensureWatchlistTable(db);
    const now = Math.floor(Date.now() / 1000);
    const row = db.prepare('SELECT guild_id, user_id, expires_at FROM watchlist WHERE guild_id = ? AND user_id = ?')
      .get(String(guildId), String(userId));
    if (!row) return false;

    if (row.expires_at && row.expires_at > 0 && row.expires_at <= now) {
      // Auto-prune expired entry
      try {
        db.prepare('DELETE FROM watchlist WHERE guild_id = ? AND user_id = ?')
          .run(String(guildId), String(userId));
      } catch (_) {}
      return false;
    }

    return true;
  } catch (err) {
    console.error(`[Watchlist] Failed checking isWatchlisted for ${userId} in ${guildId}:`, err.message);
    return false;
  }
}

/**
 * Adds or updates a user on the surveillance watchlist.
 * @param {string} guildId
 * @param {string} userId
 * @param {string} [reason]
 * @param {string} [addedBy]
 * @param {number} [expiresAt] Unix timestamp in seconds (0 = permanent)
 * @returns {object} Watchlist entry record
 */
function addToWatchlist(guildId, userId, reason, addedBy, expiresAt = 0) {
  const gid = String(guildId);
  const uid = String(userId);
  const db = getServerDb(gid);
  ensureWatchlistTable(db);

  const now = Math.floor(Date.now() / 1000);
  const cleanReason = (reason && String(reason).trim()) || 'No reason provided';
  const cleanAddedBy = String(addedBy || 'system');
  const exp = typeof expiresAt === 'number' ? Math.floor(expiresAt) : (parseInt(expiresAt, 10) || 0);

  db.prepare(`
    INSERT INTO watchlist (guild_id, user_id, reason, added_by, added_at, expires_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET
      reason = excluded.reason,
      added_by = excluded.added_by,
      added_at = excluded.added_at,
      expires_at = excluded.expires_at
  `).run(gid, uid, cleanReason, cleanAddedBy, now, exp);

  return {
    guild_id: gid,
    user_id: uid,
    reason: cleanReason,
    added_by: cleanAddedBy,
    added_at: now,
    expires_at: exp
  };
}

/**
 * Removes a user from the surveillance watchlist.
 * @param {string} guildId
 * @param {string} userId
 * @returns {boolean} True if removed
 */
function removeFromWatchlist(guildId, userId) {
  const gid = String(guildId);
  const uid = String(userId);
  try {
    const db = getServerDb(gid);
    ensureWatchlistTable(db);
    const res = db.prepare('DELETE FROM watchlist WHERE guild_id = ? AND user_id = ?').run(gid, uid);
    return res.changes > 0;
  } catch (err) {
    console.error(`[Watchlist] Failed removing ${uid} from ${gid}:`, err.message);
    return false;
  }
}

/**
 * Retrieves all active watchlisted users for a guild. Expired records are pruned.
 * @param {string} guildId
 * @returns {Array<object>}
 */
function getWatchlist(guildId) {
  const gid = String(guildId);
  try {
    const db = getServerDb(gid);
    ensureWatchlistTable(db);
    const now = Math.floor(Date.now() / 1000);

    // Auto-prune expired records
    try {
      db.prepare('DELETE FROM watchlist WHERE guild_id = ? AND expires_at > 0 AND expires_at <= ?').run(gid, now);
    } catch (_) {}

    return db.prepare('SELECT guild_id, user_id, reason, added_by, added_at, expires_at FROM watchlist WHERE guild_id = ? ORDER BY added_at DESC').all(gid);
  } catch (err) {
    console.error(`[Watchlist] Failed retrieving watchlist for ${gid}:`, err.message);
    return [];
  }
}

/**
 * Retrieves a single watchlist record for a user. Expired records return null.
 * @param {string} guildId
 * @param {string} userId
 * @returns {object|null}
 */
function getWatchlistEntry(guildId, userId) {
  const gid = String(guildId);
  const uid = String(userId);
  try {
    const db = getServerDb(gid);
    ensureWatchlistTable(db);
    const now = Math.floor(Date.now() / 1000);

    const row = db.prepare('SELECT guild_id, user_id, reason, added_by, added_at, expires_at FROM watchlist WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (!row) return null;

    if (row.expires_at && row.expires_at > 0 && row.expires_at <= now) {
      try {
        db.prepare('DELETE FROM watchlist WHERE guild_id = ? AND user_id = ?').run(gid, uid);
      } catch (_) {}
      return null;
    }

    return row;
  } catch (err) {
    console.error(`[Watchlist] Failed retrieving watchlist entry for ${uid} in ${gid}:`, err.message);
    return null;
  }
}

module.exports = {
  ensureWatchlistTable,
  isWatchlisted,
  addToWatchlist,
  removeFromWatchlist,
  getWatchlist,
  getWatchlistEntry
};
