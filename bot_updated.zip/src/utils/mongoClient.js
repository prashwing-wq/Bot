/**
 * Celestia / Tungsten MongoDB Atlas Client Manager
 * Manages singleton MongoClient connection, pooling, health ping, and graceful shutdown.
 */
const { MongoClient, ServerApiVersion } = require('mongodb');

let _clientInstance = null;
let _isConnecting = false;
let _connectionPromise = null;
let _lastPingTime = 0;
let _lastPingResult = null;

const DEFAULT_DB_NAME = (process.env.MONGODB_DATABASE || 'tungsten_bot').trim();

/**
 * Normalizes MongoDB connection URI from environment
 */
function getMongoUri() {
  const uri = process.env.MONGODB_URI || '';
  return uri.trim().replace(/^["']|["']$/g, '');
}

/**
 * Initializes and connects the singleton MongoDB client.
 * Returns { client, db } or null if MONGODB_URI is absent.
 */
async function initMongo(options = {}) {
  const uri = getMongoUri();
  if (!uri) {
    return null;
  }

  if (_clientInstance) {
    try {
      const db = _clientInstance.db(options.dbName || DEFAULT_DB_NAME);
      return { client: _clientInstance, db };
    } catch (_) {}
  }

  if (_isConnecting && _connectionPromise) {
    return _connectionPromise;
  }

  _isConnecting = true;
  _connectionPromise = (async () => {
    try {
      const client = new MongoClient(uri, {
        serverApi: {
          version: ServerApiVersion.v1,
          strict: false,
          deprecationErrors: true,
        },
        maxPoolSize: 20,
        minPoolSize: 2,
        connectTimeoutMS: 10000,
        serverSelectionTimeoutMS: 10000,
        ...options.clientOptions,
      });

      await client.connect();
      _clientInstance = client;
      _isConnecting = false;

      const db = client.db(options.dbName || DEFAULT_DB_NAME);
      console.log(`[MongoDB] Connected successfully to MongoDB Atlas (Database: ${db.databaseName})`);
      return { client: _clientInstance, db };
    } catch (err) {
      _isConnecting = false;
      _connectionPromise = null;
      console.error(`[MongoDB Error] Failed to connect to MongoDB Atlas: ${err.message}`);
      throw err;
    }
  })();

  return _connectionPromise;
}

/**
 * Gets the singleton MongoClient if connected
 */
function getMongoClient() {
  return _clientInstance;
}

/**
 * Gets the designated database instance
 */
function getMongoDb(dbName = DEFAULT_DB_NAME) {
  if (!_clientInstance) {
    return null;
  }
  return _clientInstance.db(dbName);
}

/**
 * Checks whether MongoDB is actively connected
 */
function isMongoConnected() {
  return Boolean(_clientInstance);
}

/**
 * Performs a lightweight ping command against MongoDB Atlas
 */
async function pingMongo() {
  if (!_clientInstance) {
    return { ok: false, error: 'MongoDB client not connected' };
  }

  const now = Date.now();
  if (now - _lastPingTime < 5000 && _lastPingResult) {
    return _lastPingResult;
  }

  try {
    const start = Date.now();
    const admin = _clientInstance.db('admin');
    await admin.command({ ping: 1 });
    const latencyMs = Date.now() - start;

    _lastPingTime = now;
    _lastPingResult = { ok: true, latencyMs, timestamp: new Date().toISOString() };
    return _lastPingResult;
  } catch (err) {
    _lastPingResult = { ok: false, error: err.message, timestamp: new Date().toISOString() };
    return _lastPingResult;
  }
}

/**
 * Cleanly closes the MongoDB connection
 */
async function closeMongo() {
  if (_clientInstance) {
    try {
      await _clientInstance.close();
      console.log('[MongoDB] Connection closed cleanly.');
    } catch (e) {
      console.warn('[MongoDB] Notice closing connection:', e.message);
    } finally {
      _clientInstance = null;
      _isConnecting = false;
      _connectionPromise = null;
    }
  }
}

module.exports = {
  DEFAULT_DB_NAME,
  initMongo,
  getMongoClient,
  getMongoDb,
  isMongoConnected,
  pingMongo,
  closeMongo,
  getMongoUri
};
