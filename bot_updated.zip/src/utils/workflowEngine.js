/**
 * Tungsten Workflow Engine (Node.js)
 * Implements Slice 3.3 Event-Triggered Sequence Automation:
 * Triggers: member_join, member_leave, member_ban, keyword
 * Actions: send_message, add_role, remove_role, timeout
 *
 * SAFETY INVARIANT:
 * No workflow can execute ban or kick actions, nor grant Administrator permissions.
 * Explicitly enforced in both the validator and runtime dispatch sentinel.
 */
const { PermissionsBitField, PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('./serverDb');
const { formatPlaceholders } = require('./placeholders');
const { parseDuration } = require('./tools');

const VALID_TRIGGERS = ['member_join', 'member_leave', 'member_ban', 'keyword'];
const VALID_ACTIONS = ['send_message', 'add_role', 'remove_role', 'timeout'];

const FORBIDDEN_ACTION_KEYWORDS = [
  'ban',
  'kick',
  'admin',
  'administrator',
  'grant_admin',
  'guild_ban',
  'member_ban',
  'softban',
  'tempban',
  'kick_member',
  'ban_member',
  'op'
];

/**
 * Normalizes user-input or event trigger strings to canonical keys.
 */
function normalizeTrigger(trigger) {
  if (!trigger || typeof trigger !== 'string') return null;
  const clean = trigger.toLowerCase().trim().replace(/[- ]/g, '_');
  if (['member_join', 'memberjoin', 'join', 'on_join', 'user_join'].includes(clean)) return 'member_join';
  if (['member_leave', 'memberleave', 'leave', 'on_leave', 'user_leave', 'member_remove'].includes(clean)) return 'member_leave';
  if (['member_ban', 'memberban', 'ban', 'on_ban', 'user_ban', 'guild_ban_add'].includes(clean)) return 'member_ban';
  if (['keyword', 'message_keyword', 'word', 'message', 'msg_keyword'].includes(clean)) return 'keyword';
  return null;
}

/**
 * Normalizes action strings to canonical keys.
 */
function normalizeAction(action) {
  if (!action || typeof action !== 'string') return null;
  const clean = action.toLowerCase().trim().replace(/[- ]/g, '_');
  if (['send_message', 'message', 'msg', 'sendmessage', 'send_msg', 'reply'].includes(clean)) return 'send_message';
  if (['add_role', 'addrole', 'role_add', 'giverole', 'grant_role'].includes(clean)) return 'add_role';
  if (['remove_role', 'removerole', 'role_remove', 'takerole', 'revoke_role'].includes(clean)) return 'remove_role';
  if (['timeout', 'mute', 'tempmute', 'moderate'].includes(clean)) return 'timeout';
  return null;
}

/**
 * Ensures the guild_workflows table and indexes exist in the guild DB.
 */
function ensureWorkflowTable(sdb) {
  try {
    sdb.exec(`
      CREATE TABLE IF NOT EXISTS guild_workflows (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        name TEXT NOT NULL,
        trigger_type TEXT NOT NULL,
        trigger_config_json TEXT NOT NULL DEFAULT '{}',
        actions_json TEXT NOT NULL DEFAULT '[]',
        enabled INTEGER DEFAULT 1,
        run_count INTEGER DEFAULT 0
      );
      CREATE INDEX IF NOT EXISTS idx_guild_workflows ON guild_workflows(guild_id, trigger_type, enabled);
    `);
  } catch (_) {}
}

/**
 * Validates a workflow definition against business rules and hard security invariants.
 * Throws a descriptive Error if validation or safety checks fail.
 */
function validateWorkflow({ name, trigger_type, trigger_config = {}, actions = [], guild = null }) {
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    throw new Error('Workflow name is required (1-64 characters).');
  }
  const cleanName = name.trim();
  if (cleanName.length > 64) {
    throw new Error('Workflow name must be 64 characters or fewer.');
  }

  const normTrigger = normalizeTrigger(trigger_type);
  if (!normTrigger) {
    throw new Error(`Invalid trigger type "${trigger_type}". Supported triggers: ${VALID_TRIGGERS.join(', ')}`);
  }

  if (normTrigger === 'keyword') {
    if (!trigger_config || !trigger_config.keyword || typeof trigger_config.keyword !== 'string' || !trigger_config.keyword.trim()) {
      throw new Error('Keyword trigger requires a non-empty "keyword" in trigger_config.');
    }
    if (trigger_config.keyword.length > 200) {
      throw new Error('Keyword string must be 200 characters or fewer.');
    }
  }

  if (!Array.isArray(actions) || actions.length === 0) {
    throw new Error('Workflow must contain at least one action.');
  }
  if (actions.length > 10) {
    throw new Error('A workflow cannot exceed 10 actions.');
  }

  const validatedActions = [];

  for (const act of actions) {
    if (!act || typeof act !== 'object') {
      throw new Error('Each action definition must be an object.');
    }

    const rawType = String(act.type || '').toLowerCase().trim();

    // ─────────────────────────────────────────────────────────────
    // SAFETY INVARIANT: No workflow can ban, kick or grant Admin
    // ─────────────────────────────────────────────────────────────
    for (const forbidden of FORBIDDEN_ACTION_KEYWORDS) {
      if (rawType.includes(forbidden)) {
        throw new Error(`Safety violation: Workflows cannot execute "${act.type}" actions! Ban, kick, and administrator actions are permanently blocked.`);
      }
    }

    if (act.permissions || act.admin) {
      throw new Error('Safety violation: Workflows cannot modify administrative permissions.');
    }

    const normAction = normalizeAction(rawType);
    if (!normAction) {
      throw new Error(`Invalid action type "${act.type}". Valid actions: ${VALID_ACTIONS.join(', ')}`);
    }

    if (normAction === 'send_message') {
      const msg = act.message || act.content || act.text;
      if (!msg || typeof msg !== 'string' || !msg.trim()) {
        throw new Error('Action "send_message" requires a non-empty "message" string.');
      }
      if (msg.length > 2000) {
        throw new Error('Message text cannot exceed 2,000 characters.');
      }
      const channelId = act.channel_id || act.channel || null;
      validatedActions.push({
        type: 'send_message',
        channel_id: channelId ? String(channelId).replace(/[<#>]/g, '').trim() : null,
        message: msg.trim()
      });
    } else if (normAction === 'add_role') {
      const rawRoleId = act.role_id || act.role || act.target;
      const roleId = rawRoleId ? String(rawRoleId).replace(/[<@&>]/g, '').trim() : '';
      if (!roleId || !/^\d{17,20}$/.test(roleId)) {
        throw new Error('Action "add_role" requires a valid Discord Role ID.');
      }

      // Check role permissions for Administrator if guild context provided
      if (guild && guild.roles) {
        const role = guild.roles.cache ? guild.roles.cache.get(roleId) : null;
        if (role && role.permissions && role.permissions.has(PermissionFlagsBits.Administrator)) {
          throw new Error('Safety violation: Workflows cannot assign roles with Administrator permission!');
        }
      }

      validatedActions.push({
        type: 'add_role',
        role_id: roleId
      });
    } else if (normAction === 'remove_role') {
      const rawRoleId = act.role_id || act.role || act.target;
      const roleId = rawRoleId ? String(rawRoleId).replace(/[<@&>]/g, '').trim() : '';
      if (!roleId || !/^\d{17,20}$/.test(roleId)) {
        throw new Error('Action "remove_role" requires a valid Discord Role ID.');
      }
      validatedActions.push({
        type: 'remove_role',
        role_id: roleId
      });
    } else if (normAction === 'timeout') {
      const rawDur = act.duration || act.time || act.duration_seconds;
      let durationMs = 0;

      if (typeof rawDur === 'number') {
        durationMs = rawDur > 100000 ? rawDur : rawDur * 1000;
      } else if (typeof rawDur === 'string') {
        const parsed = parseDuration(rawDur);
        if (parsed && parsed.seconds > 0) {
          durationMs = parsed.seconds * 1000;
        } else {
          const numeric = parseInt(rawDur, 10);
          if (!isNaN(numeric) && numeric > 0) {
            durationMs = numeric * 1000;
          }
        }
      }

      if (!durationMs || durationMs < 1000) {
        throw new Error('Action "timeout" requires a duration of at least 1 second (e.g. "60s", "5m").');
      }

      // Max 28 days = 2419200 seconds = 2419200000 ms
      const MAX_TIMEOUT_MS = 28 * 24 * 60 * 60 * 1000;
      if (durationMs > MAX_TIMEOUT_MS) {
        throw new Error('Action "timeout" duration cannot exceed 28 days.');
      }

      validatedActions.push({
        type: 'timeout',
        duration_ms: durationMs,
        duration_raw: String(rawDur),
        reason: act.reason ? String(act.reason).slice(0, 500) : 'Tungsten Workflow Automation'
      });
    }
  }

  return {
    name: cleanName,
    trigger_type: normTrigger,
    trigger_config: trigger_config || {},
    actions: validatedActions
  };
}

/**
 * Returns all workflows configured for a guild.
 */
function getWorkflows(guildId) {
  if (!guildId) return [];
  const sdb = getServerDb(guildId);
  ensureWorkflowTable(sdb);

  const rows = sdb.prepare(`
    SELECT * FROM guild_workflows
    WHERE guild_id = ?
    ORDER BY id ASC
  `).all(guildId);

  return rows.map(r => ({
    id: r.id,
    guild_id: r.guild_id,
    name: r.name,
    trigger_type: r.trigger_type,
    trigger_config: JSON.parse(r.trigger_config_json || '{}'),
    actions: JSON.parse(r.actions_json || '[]'),
    enabled: Boolean(r.enabled),
    run_count: r.run_count || 0
  }));
}

/**
 * Returns a single workflow by ID.
 */
function getWorkflow(guildId, id) {
  if (!guildId || !id) return null;
  const sdb = getServerDb(guildId);
  ensureWorkflowTable(sdb);

  const row = sdb.prepare(`
    SELECT * FROM guild_workflows
    WHERE guild_id = ? AND id = ?
  `).get(guildId, id);

  if (!row) return null;

  return {
    id: row.id,
    guild_id: row.guild_id,
    name: row.name,
    trigger_type: row.trigger_type,
    trigger_config: JSON.parse(row.trigger_config_json || '{}'),
    actions: JSON.parse(row.actions_json || '[]'),
    enabled: Boolean(row.enabled),
    run_count: row.run_count || 0
  };
}

/**
 * Creates and registers a new workflow in the guild database.
 */
function createWorkflow(guildId, data, guild = null) {
  if (!guildId) throw new Error('Guild ID is required.');
  const sdb = getServerDb(guildId);
  ensureWorkflowTable(sdb);

  const validated = validateWorkflow({
    name: data.name,
    trigger_type: data.trigger_type,
    trigger_config: data.trigger_config,
    actions: data.actions,
    guild
  });

  const res = sdb.prepare(`
    INSERT INTO guild_workflows (guild_id, name, trigger_type, trigger_config_json, actions_json, enabled, run_count)
    VALUES (?, ?, ?, ?, ?, 1, 0)
  `).run(
    guildId,
    validated.name,
    validated.trigger_type,
    JSON.stringify(validated.trigger_config),
    JSON.stringify(validated.actions)
  );

  return {
    id: Number(res.lastInsertRowid),
    guild_id: guildId,
    name: validated.name,
    trigger_type: validated.trigger_type,
    trigger_config: validated.trigger_config,
    actions: validated.actions,
    enabled: true,
    run_count: 0
  };
}

/**
 * Toggles a workflow between enabled (1) and disabled (0).
 */
function toggleWorkflow(guildId, id) {
  if (!guildId || !id) return null;
  const sdb = getServerDb(guildId);
  ensureWorkflowTable(sdb);

  const existing = sdb.prepare('SELECT enabled FROM guild_workflows WHERE guild_id = ? AND id = ?').get(guildId, id);
  if (!existing) return null;

  const nextState = existing.enabled === 1 ? 0 : 1;
  sdb.prepare('UPDATE guild_workflows SET enabled = ? WHERE guild_id = ? AND id = ?').run(nextState, guildId, id);

  return getWorkflow(guildId, id);
}

/**
 * Deletes a workflow from the guild database.
 */
function deleteWorkflow(guildId, id) {
  if (!guildId || !id) return false;
  const sdb = getServerDb(guildId);
  ensureWorkflowTable(sdb);

  const res = sdb.prepare('DELETE FROM guild_workflows WHERE guild_id = ? AND id = ?').run(guildId, id);
  return res.changes > 0;
}

/**
 * Evaluates whether an incoming event matches a workflow's trigger configuration.
 */
function matchesTrigger(triggerType, config, context) {
  if (triggerType === 'keyword') {
    const msg = context.message;
    if (!msg || typeof msg.content !== 'string') return false;
    const targetWord = config.keyword;
    if (!targetWord) return false;

    const caseSensitive = Boolean(config.case_sensitive);
    const content = caseSensitive ? msg.content : msg.content.toLowerCase();
    const needle = caseSensitive ? targetWord : targetWord.toLowerCase();
    const matchType = config.match_type || 'contains';

    if (matchType === 'exact') {
      return content.trim() === needle.trim();
    } else if (matchType === 'startswith') {
      return content.trim().startsWith(needle.trim());
    } else {
      return content.includes(needle);
    }
  }

  // Event triggers: member_join, member_leave, member_ban
  if (config && config.user_type) {
    const isBot = Boolean(context.user?.bot || context.member?.user?.bot);
    if (config.user_type === 'human' && isBot) return false;
    if (config.user_type === 'bot' && !isBot) return false;
  }

  return true;
}

/**
 * Executes a single action safely with permission hierarchy guards and error trapping.
 */
async function executeAction(action, guild, context, workflow, client) {
  if (!action || typeof action !== 'object') return { success: false, error: 'Invalid action payload' };

  const actType = normalizeAction(action.type);

  // Hard safety invariant check: reject any banned action type
  for (const forbidden of FORBIDDEN_ACTION_KEYWORDS) {
    if (String(action.type).toLowerCase().includes(forbidden)) {
      console.warn(`[Workflow Security Invariant] Blocked forbidden action "${action.type}" in workflow #${workflow.id}`);
      return { success: false, error: 'Forbidden action blocked by safety sentinel' };
    }
  }

  try {
    // ─────────────────────────────────────────────────────────────
    // 1. Action: send_message
    // ─────────────────────────────────────────────────────────────
    if (actType === 'send_message') {
      let targetChannel = null;
      if (action.channel_id && guild.channels) {
        targetChannel = guild.channels.cache.get(action.channel_id) || await guild.channels.fetch(action.channel_id).catch(() => null);
      } else if (context.channel) {
        targetChannel = context.channel;
      }

      if (!targetChannel || typeof targetChannel.send !== 'function') {
        return { success: false, error: 'Target channel not accessible' };
      }

      const formatted = formatPlaceholders(action.message, context.member || { user: context.user }, guild);
      // S8: Strict allowedMentions to prevent role/everyone ping abuse
      await targetChannel.send({ content: formatted, allowedMentions: { parse: [] } });
      return { success: true };
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Action: add_role
    // ─────────────────────────────────────────────────────────────
    if (actType === 'add_role') {
      const member = context.member || (context.user && guild.members ? await guild.members.fetch(context.user.id).catch(() => null) : null);
      if (!member || typeof member.roles?.add !== 'function') {
        return { success: false, error: 'Target member not in guild' };
      }

      const role = guild.roles ? (guild.roles.cache.get(action.role_id) || await guild.roles.fetch(action.role_id).catch(() => null)) : null;
      if (!role) {
        return { success: false, error: 'Role not found' };
      }

      // CRITICAL: Refuse to grant Administrator role under any circumstance
      if (role.permissions && role.permissions.has(PermissionFlagsBits.Administrator)) {
        console.warn(`[Workflow Security] Blocked workflow #${workflow.id} from assigning Administrator role ${role.id}`);
        return { success: false, error: 'Safety block: Cannot grant Administrator role' };
      }

      // Bot hierarchy check
      const me = guild.members.me || (guild.members.fetchMe ? await guild.members.fetchMe().catch(() => null) : null);
      if (me && me.roles && me.roles.highest.position <= role.position) {
        return { success: false, error: 'Role position is higher than or equal to bot highest role' };
      }

      await member.roles.add(role.id, `Tungsten Workflow: ${workflow.name || 'Auto'}`);
      return { success: true };
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Action: remove_role
    // ─────────────────────────────────────────────────────────────
    if (actType === 'remove_role') {
      const member = context.member || (context.user && guild.members ? await guild.members.fetch(context.user.id).catch(() => null) : null);
      if (!member || typeof member.roles?.remove !== 'function') {
        return { success: false, error: 'Target member not in guild' };
      }

      const role = guild.roles ? (guild.roles.cache.get(action.role_id) || await guild.roles.fetch(action.role_id).catch(() => null)) : null;
      if (!role) {
        return { success: false, error: 'Role not found' };
      }

      // Bot hierarchy check
      const me = guild.members.me || (guild.members.fetchMe ? await guild.members.fetchMe().catch(() => null) : null);
      if (me && me.roles && me.roles.highest.position <= role.position) {
        return { success: false, error: 'Role position is higher than or equal to bot highest role' };
      }

      await member.roles.remove(role.id, `Tungsten Workflow: ${workflow.name || 'Auto'}`);
      return { success: true };
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Action: timeout
    // ─────────────────────────────────────────────────────────────
    if (actType === 'timeout') {
      const member = context.member || (context.user && guild.members ? await guild.members.fetch(context.user.id).catch(() => null) : null);
      if (!member || typeof member.timeout !== 'function') {
        return { success: false, error: 'Target member not moderatable' };
      }

      if (member.moderatable === false) {
        return { success: false, error: 'Member is not moderatable by bot' };
      }

      const durationMs = Math.min(Math.max(1000, Number(action.duration_ms || 60000)), 28 * 24 * 60 * 60 * 1000);
      const reason = action.reason || `Tungsten Workflow: ${workflow.name || 'Auto'}`;

      await member.timeout(durationMs, reason);
      return { success: true };
    }

    return { success: false, error: `Unhandled action type ${actType}` };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Dispatches active workflows matching an event trigger.
 * Safe non-blocking execution with run_count telemetry incrementation.
 */
async function executeWorkflows(guild, triggerType, context = {}, client = null) {
  if (!guild || !guild.id) return [];
  const sdb = getServerDb(guild.id);
  ensureWorkflowTable(sdb);

  const normTrigger = normalizeTrigger(triggerType);
  if (!normTrigger) return [];

  const workflows = sdb.prepare(`
    SELECT * FROM guild_workflows
    WHERE guild_id = ? AND trigger_type = ? AND enabled = 1
  `).all(guild.id, normTrigger);

  if (!workflows || workflows.length === 0) return [];

  const results = [];

  for (const row of workflows) {
    try {
      const triggerConfig = JSON.parse(row.trigger_config_json || '{}');
      const actions = JSON.parse(row.actions_json || '[]');

      if (!matchesTrigger(normTrigger, triggerConfig, context)) {
        continue;
      }

      let executedAny = false;
      const actionResults = [];

      for (const action of actions) {
        const res = await executeAction(action, guild, context, row, client);
        actionResults.push(res);
        if (res && res.success) {
          executedAny = true;
        }
      }

      if (executedAny) {
        sdb.prepare('UPDATE guild_workflows SET run_count = run_count + 1 WHERE guild_id = ? AND id = ?')
          .run(guild.id, row.id);
      }

      results.push({
        workflowId: row.id,
        name: row.name,
        executed: executedAny,
        actionResults
      });
    } catch (err) {
      console.warn(`[Workflow Engine] Error executing workflow #${row.id} in guild ${guild.id}:`, err.message);
    }
  }

  return results;
}

module.exports = {
  VALID_TRIGGERS,
  VALID_ACTIONS,
  FORBIDDEN_ACTION_KEYWORDS,
  normalizeTrigger,
  normalizeAction,
  ensureWorkflowTable,
  validateWorkflow,
  getWorkflows,
  getWorkflow,
  createWorkflow,
  toggleWorkflow,
  deleteWorkflow,
  executeAction,
  executeWorkflows
};
