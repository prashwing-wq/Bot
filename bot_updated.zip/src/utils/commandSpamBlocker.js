/**
 * Command Anti-Spam & Continuous Rate Limiter
 * Locks out spamming users across the server for 1 minute after 5 continuous command attempts.
 * Bot owners and server owners are completely exempt.
 */

const { isOwner } = require('./tools');

// Map of `${guildId}:${userId}` -> { timestamps: number[], blockedUntil: number }
const _spamBuckets = new Map();

/**
 * Generates the standardized warning message for a locked out user.
 * @param {number} [remainingSeconds=60]
 * @returns {string}
 */
function SPAM_LOCKOUT_MESSAGE(remainingSeconds) {
  const timeStr = (!remainingSeconds || remainingSeconds >= 60) ? '1 minute' : `${remainingSeconds}s`;
  return `<a:tungsten_warn:1567242784535085148> You are spamming commands! You cannot use bot commands for **${timeStr}** across this server.`;
}

/**
 * Evaluates whether a user is currently blocked or should be newly locked out.
 * @param {string} guildId
 * @param {string} userId
 * @param {string} [guildOwnerId]
 * @returns {{ blocked: boolean, remainingSeconds?: number, newlyBlocked?: boolean }}
 */
function checkCommandSpam(guildId, userId, guildOwnerId) {
  if (!guildId || !userId) {
    return { blocked: false };
  }

  // Bot owners are completely exempt
  if (isOwner(userId)) {
    return { blocked: false };
  }

  // Server owner is completely exempt
  const ownerIdStr = typeof guildOwnerId === 'object' && guildOwnerId !== null
    ? (guildOwnerId.ownerId || guildOwnerId.id)
    : guildOwnerId;

  if (ownerIdStr && String(ownerIdStr) === String(userId)) {
    return { blocked: false };
  }

  const key = `${guildId}:${userId}`;
  const now = Date.now();

  let entry = _spamBuckets.get(key);
  if (!entry) {
    entry = { timestamps: [], blockedUntil: 0 };
    _spamBuckets.set(key, entry);
  }

  // If currently blocked
  if (entry.blockedUntil && now < entry.blockedUntil) {
    const remainingSeconds = Math.max(1, Math.ceil((entry.blockedUntil - now) / 1000));
    return { blocked: true, remainingSeconds, newlyBlocked: false };
  }

  // If lockout expired
  if (entry.blockedUntil && now >= entry.blockedUntil) {
    entry.blockedUntil = 0;
    entry.timestamps = [];
  }

  // Continuous spam detection within 10,000 ms (10 seconds)
  entry.timestamps = (entry.timestamps || []).filter(t => now - t < 10000);
  entry.timestamps.push(now);

  // After 5th continuous invocation
  if (entry.timestamps.length > 5) {
    entry.blockedUntil = now + 60000;
    entry.timestamps = [];
    return { blocked: true, remainingSeconds: 60, newlyBlocked: true };
  }

  // Termux resource efficiency: periodically prune old entries if map grows
  if (_spamBuckets.size > 500) {
    const cutoff = now - 60000;
    for (const [k, v] of _spamBuckets.entries()) {
      if ((!v.blockedUntil || v.blockedUntil < now) && (!v.timestamps || v.timestamps.length === 0 || v.timestamps[v.timestamps.length - 1] < cutoff)) {
        _spamBuckets.delete(k);
      }
    }
  }

  return { blocked: false };
}

/**
 * Resets the spam record for a user, a guild, or all entries.
 * @param {string} [guildId]
 * @param {string} [userId]
 */
function resetCommandSpam(guildId, userId) {
  if (guildId && userId) {
    _spamBuckets.delete(`${guildId}:${userId}`);
  } else if (guildId) {
    for (const key of _spamBuckets.keys()) {
      if (key.startsWith(`${guildId}:`)) {
        _spamBuckets.delete(key);
      }
    }
  } else {
    _spamBuckets.clear();
  }
}

module.exports = {
  checkCommandSpam,
  resetCommandSpam,
  SPAM_LOCKOUT_MESSAGE
};
