/**
 * Tungsten Universal UI Emoji Sanitizer & Output Interceptor
 * Supports dual UI style modes via general.ui_style ('clean' | 'expressive'):
 * - 'clean' (default): subtle, restrained, professional. Keeps developer's
 *   static/unicode emojis and avoids unsolicited animated emoji injection.
 * - 'expressive': animated Tungsten emojis across embeds, messages, and interactive buttons.
 */
const {
  Message,
  TextChannel,
  DMChannel,
  NewsChannel,
  ThreadChannel,
  ButtonBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  EmbedBuilder,
  ContainerBuilder,
  BaseInteraction,
  CommandInteraction,
  ButtonInteraction,
  StringSelectMenuInteraction,
  MessageComponentInteraction,
  UserSelectMenuInteraction,
  RoleSelectMenuInteraction,
  ChannelSelectMenuInteraction,
  MentionableSelectMenuInteraction,
  ModalSubmitInteraction
} = require('discord.js');
const { AsyncLocalStorage } = require('node:async_hooks');
const emojisModule = require('./emojis');
const { EMOJIS, UNICODE_MAP, replaceEmojis, IDS, CANONICAL_ALIASES } = emojisModule;
const baseSanitizeUiPayload = emojisModule.sanitizeUiPayload;

// Prohibit embed colors across the UI so no vertical color bar/stripe appears
if (typeof EmbedBuilder !== 'undefined' && EmbedBuilder.prototype) {
  EmbedBuilder.prototype.setColor = function() {
    if (this.data) delete this.data.color;
    return this;
  };
}

// Prohibit container accent colors across the UI so no vertical accent stripe/border appears
if (typeof ContainerBuilder !== 'undefined' && ContainerBuilder.prototype) {
  ContainerBuilder.prototype.setAccentColor = function() {
    if (this.data) delete this.data.accent_color;
    delete this.accent_color;
    return this;
  };
}

const VALID_EMOJI_IDS = new Set(Object.values(IDS || {}));
const ID_TO_NAME = new Map();
if (IDS) {
  for (const [name, id] of Object.entries(IDS)) {
    ID_TO_NAME.set(id, name);
  }
}

/**
 * Safely resolves and heals an emoji for Discord Select Menu Options and Buttons.
 * - Extracts name and ID.
 * - Applies CANONICAL_ALIASES[name].
 * - If IDS[name] exists, ensures id = IDS[name].
 * - If the emoji ID is not in IDS and cannot be resolved, returns undefined
 *   so the invalid emoji is removed and Discord never rejects with error 50035!
 */
function healSelectMenuEmoji(emoji) {
  if (!emoji) return undefined;

  let name = null;
  let id = null;
  let animated = false;

  if (typeof emoji === 'string') {
    let str = emoji.trim();
    if (!str) return undefined;

    // Handle template strings ${EMOJIS.KEY}
    if (str.includes('${EMOJIS.') || str.startsWith('${')) {
      str = str.replace(/\${EMOJIS\.([A-Z0-9_]+)}/g, (_, k) => EMOJIS[k] || '').trim();
      if (!str) return undefined;
    }

    // Check custom emoji tag <a:name:id> or <:name:id>
    const m = str.match(/<a?:([a-zA-Z0-9_]+):([^>]+)>/);
    if (m) {
      name = m[1];
      id = m[2];
      animated = str.startsWith('<a:');
    } else {
      const rep = UNICODE_MAP[str] || (typeof replaceEmojis === 'function' ? replaceEmojis(null, str) : null);
      if (rep && typeof rep === 'string') {
        const rm = rep.match(/<a?:([a-zA-Z0-9_]+):([^>]+)>/);
        if (rm) {
          name = rm[1];
          id = rm[2];
          animated = rep.startsWith('<a:');
        }
      }
      if (!name) {
        if (IDS && (IDS[str] || IDS['tungsten_' + str] || IDS['celestia_' + str])) {
          name = IDS[str] ? str : (IDS['tungsten_' + str] ? 'tungsten_' + str : 'celestia_' + str);
        } else if (CANONICAL_ALIASES && (CANONICAL_ALIASES[str] || CANONICAL_ALIASES['tungsten_' + str] || CANONICAL_ALIASES['celestia_' + str])) {
          name = str;
        } else {
          // If ascii word with no ID and not in IDS, it's not a valid unicode emoji
          if (/^[a-zA-Z0-9_]+$/.test(str) || str.startsWith('<') || str.includes(':')) {
            return undefined;
          }
          // Pure unicode emoji (e.g. 🔥)
          return { name: str };
        }
      }
    }
  } else if (typeof emoji === 'object') {
    name = emoji.name || null;
    id = emoji.id || null;
    animated = emoji.animated !== false;

    // Handle template string in object name
    if (typeof name === 'string' && (name.includes('${EMOJIS.') || name.startsWith('${'))) {
      name = name.replace(/\${EMOJIS\.([A-Z0-9_]+)}/g, (_, k) => EMOJIS[k] || '').trim();
      const m = name.match(/<a?:([a-zA-Z0-9_]+):([^>]+)>/);
      if (m) {
        name = m[1];
        id = m[2];
        animated = true;
      }
    }

    // If name is in UNICODE_MAP
    if (name && (UNICODE_MAP[name] || !id)) {
      const rep = UNICODE_MAP[name] || (typeof replaceEmojis === 'function' ? replaceEmojis(null, name) : null);
      if (rep && typeof rep === 'string') {
        const rm = rep.match(/<a?:([a-zA-Z0-9_]+):([^>]+)>/);
        if (rm) {
          name = rm[1];
          id = rm[2];
          animated = rep.startsWith('<a:');
        }
      }
    }
  } else {
    return undefined;
  }

  // Apply CANONICAL_ALIASES
  if (name && CANONICAL_ALIASES) {
    if (CANONICAL_ALIASES[name]) {
      name = CANONICAL_ALIASES[name];
    } else if (name.startsWith('celestia_') || name.startsWith('tungsten_')) {
      const base = name.slice(9);
      if (CANONICAL_ALIASES[base]) {
        name = CANONICAL_ALIASES[base];
      }
    } else if (CANONICAL_ALIASES['tungsten_' + name]) {
      name = CANONICAL_ALIASES['tungsten_' + name];
    } else if (CANONICAL_ALIASES['celestia_' + name]) {
      name = CANONICAL_ALIASES['celestia_' + name];
    }
  }

  // Heal ID with IDS[name] BEFORE checking VALID_EMOJI_IDS
  if (name && IDS) {
    if (IDS[name]) {
      id = IDS[name];
      animated = true;
    } else if ((name.startsWith('celestia_') || name.startsWith('tungsten_')) && IDS[name.slice(9)]) {
      name = name.slice(9);
      id = IDS[name];
      animated = true;
    } else if (name.startsWith('tungsten_') && IDS['celestia_' + name.slice(9)]) {
      id = IDS['celestia_' + name.slice(9)];
      animated = true;
    } else if (IDS['tungsten_' + name]) {
      name = 'tungsten_' + name;
      id = IDS[name];
      animated = true;
    } else if (IDS['celestia_' + name]) {
      name = 'celestia_' + name;
      id = IDS[name];
      animated = true;
    }
  }

  // Validate custom emoji ID
  if (id) {
    const isValidId = (name && IDS && IDS[name] === id) || (VALID_EMOJI_IDS && VALID_EMOJI_IDS.has(id));
    if (!isValidId) {
      // Unknown or typo ID that is not in IDS!
      return undefined;
    }
    if (!name) {
      name = (ID_TO_NAME && ID_TO_NAME.has(id)) ? ID_TO_NAME.get(id) : 'tungsten_menu';
    }
    return { name, id, animated };
  }

  // If no ID, validate unicode emoji
  if (name) {
    if (/^[a-zA-Z0-9_]+$/.test(name) || name.startsWith('<') || name.includes(':')) {
      return undefined;
    }
    return { name };
  }

  return undefined;
}

const uiContextStorage = new AsyncLocalStorage();

/**
 * Extracts guildId from various Discord.js interaction/message/channel contexts.
 */
function resolveGuildId(context) {
  if (!context) return null;
  if (typeof context === 'string') return context;
  if (context.guildId) return context.guildId;
  if (context.guild && context.guild.id) return context.guild.id;
  if (context.channel && (context.channel.guildId || context.channel.guild?.id)) {
    return context.channel.guildId || context.channel.guild.id;
  }
  if (context.message && (context.message.guildId || context.message.guild?.id)) {
    return context.message.guildId || context.message.guild.id;
  }
  if (context.data && context.data.guild_id) return context.data.guild_id;
  if (context._guildId) return context._guildId;
  if (context.id && context.roles && context.channels) return context.id;
  return null;
}

/**
 * Resolves current UI style for a guild or active AsyncLocalStorage context.
 * Default is 'clean'.
 */
function getUiStyle(context) {
  let guildId = resolveGuildId(context);
  if (!guildId) {
    const store = uiContextStorage.getStore();
    if (store && store.guildId) {
      guildId = store.guildId;
    }
  }
  if (!guildId) return 'expressive';
  try {
    const { getSetting } = require('../settings/registry');
    return getSetting(guildId, 'general.ui_style') || 'expressive';
  } catch (e) {
    return 'expressive';
  }
}

/**
 * Cleans unresolved ${EMOJIS.KEY} template literals without injecting animated emojis in clean mode.
 */
function cleanTemplatePlaceholders(str) {
  if (typeof str !== 'string') return str;
  if (!str.includes('${EMOJIS.')) return str;
  let cleanEmojiForAnsi = null;
  try {
    cleanEmojiForAnsi = require('./componentsV2').cleanEmojiForAnsi;
  } catch (e) {}

  return str.replace(/\${EMOJIS\.([A-Z0-9_]+)}/g, (_, k) => {
    const rawVal = EMOJIS[k];
    if (!rawVal) return '';
    if (cleanEmojiForAnsi && rawVal.startsWith('<a:')) {
      return cleanEmojiForAnsi(rawVal).trim();
    }
    return rawVal;
  });
}

/**
 * Strips raw <a:tungsten_...:id> animated custom emojis.
 */
function stripRawCustomEmojis(str) {
  // Preserve bespoke custom animated emojis across all outputs
  return str;
}

/**
 * Universal UI payload sanitizer that guarantees 100% bespoke custom animated emojis
 * across all Discord output (messages, embeds, buttons, select menus).
 */
function scrubBrandingText(str) {
  if (typeof str !== 'string' || !str) return str;
  return str
    .replace(/celestial/gi, (m) => (m === m.toUpperCase() ? 'TUNGSTEN' : m[0] === m[0].toUpperCase() ? 'Tungsten' : 'tungsten'))
    .replace(/celestia/gi, (m) => (m === m.toUpperCase() ? 'TUNGSTEN' : m[0] === m[0].toUpperCase() ? 'Tungsten' : 'tungsten'));
}

function sanitizeUiPayload(clientOrGuild, payload) {
  if (!payload) return payload;
  const result = baseSanitizeUiPayload(clientOrGuild, payload);

  if (result && typeof result === 'object') {
    if (typeof result.content === 'string') {
      result.content = scrubBrandingText(result.content);
    }

    // 1. Clean custom emoji tags from Embed title, author.name, footer.text and ensure NO embed color is present across UI
    if (Array.isArray(result.embeds)) {
      for (const embed of result.embeds) {
        if (!embed) continue;
        const target = (typeof embed.setTitle === 'function' && embed.data) ? embed.data : embed;
        delete target.color;
        if (embed.data) delete embed.data.color;
        delete embed.color;
        if (target.data) delete target.data.color;
        if (typeof target.title === 'string') {
          if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(target.title)) {
            target.title = target.title.replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '').replace(/\s{2,}/g, ' ').trim();
          }
          target.title = scrubBrandingText(target.title);
        }
        if (typeof target.description === 'string') {
          target.description = scrubBrandingText(target.description);
        }
        if (typeof target.author?.name === 'string') {
          if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(target.author.name)) {
            target.author.name = target.author.name.replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '').replace(/\s{2,}/g, ' ').trim();
          }
          target.author.name = scrubBrandingText(target.author.name);
        }
        if (typeof target.footer?.text === 'string') {
          if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(target.footer.text)) {
            target.footer.text = target.footer.text.replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '').replace(/\s{2,}/g, ' ').trim();
          }
          target.footer.text = scrubBrandingText(target.footer.text);
        }
        if (Array.isArray(target.fields)) {
          for (const f of target.fields) {
            if (!f) continue;
            if (typeof f.name === 'string') f.name = scrubBrandingText(f.name);
            if (typeof f.value === 'string') f.value = scrubBrandingText(f.value);
          }
        }
      }
    }

    // 2. Clean custom emoji tags from select menu option descriptions & heal emojis & scrub branding
    function sanitizeComponentTree(comps) {
      if (!Array.isArray(comps)) return;
      for (const comp of comps) {
        if (!comp) continue;
        // Strip container accent colors across the UI so cards are strictly colorless
        delete comp.accent_color;
        if (comp.data) delete comp.data.accent_color;
        if (typeof comp.label === 'string') comp.label = scrubBrandingText(comp.label);
        if (typeof comp.data?.label === 'string') comp.data.label = scrubBrandingText(comp.data.label);

        const sub = comp.components || comp.data?.components;
        if (Array.isArray(sub)) {
          sanitizeComponentTree(sub);
        }
        const options = comp.options || comp.data?.options;
        if (Array.isArray(options)) {
          for (const opt of options) {
            if (!opt) continue;
            if (typeof opt.label === 'string') opt.label = scrubBrandingText(opt.label);
            if (typeof opt.data?.label === 'string') opt.data.label = scrubBrandingText(opt.data.label);
            // Clean description
            if (typeof opt.description === 'string') {
              if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(opt.description) || opt.description.includes('${EMOJIS.')) {
                opt.description = opt.description.replace(/\${EMOJIS\.[A-Z0-9_]+}/g, '').replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '').replace(/\s{2,}/g, ' ').trim();
              }
              opt.description = scrubBrandingText(opt.description);
              if (!opt.description) delete opt.description;
            }
            if (typeof opt.data?.description === 'string') {
              if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(opt.data.description) || opt.data.description.includes('${EMOJIS.')) {
                opt.data.description = opt.data.description.replace(/\${EMOJIS\.[A-Z0-9_]+}/g, '').replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '').replace(/\s{2,}/g, ' ').trim();
              }
              opt.data.description = scrubBrandingText(opt.data.description);
              if (!opt.data.description) delete opt.data.description;
            }
            // Heal emoji
            const em = opt.emoji !== undefined ? opt.emoji : opt.data?.emoji;
            if (em !== undefined) {
              const healed = healSelectMenuEmoji(em);
              if (healed) {
                if (opt.emoji !== undefined) opt.emoji = healed;
                if (opt.data?.emoji !== undefined) opt.data.emoji = healed;
              } else {
                delete opt.emoji;
                if (opt.data?.emoji) delete opt.data.emoji;
              }
            }
          }
        }

        // Heal button / single component emoji if present
        const compEmoji = comp.emoji !== undefined ? comp.emoji : comp.data?.emoji;
        if (compEmoji !== undefined) {
          const healed = healSelectMenuEmoji(compEmoji);
          if (healed) {
            if (comp.emoji !== undefined) comp.emoji = healed;
            if (comp.data?.emoji !== undefined) comp.data.emoji = healed;
            if (typeof comp.setEmoji === 'function') {
              try { comp.setEmoji(healed); } catch (e) {}
            }
          } else {
            delete comp.emoji;
            if (comp.data?.emoji) delete comp.data.emoji;
          }
        }
      }
    }

    if (Array.isArray(result.components)) {
      sanitizeComponentTree(result.components);
    }
  }

  return result;
}

// Ensure all consumers of emojis.sanitizeUiPayload use this style-aware implementation
emojisModule.sanitizeUiPayload = sanitizeUiPayload;

let _initialized = false;

function initUiSanitizer() {
  if (_initialized) return;
  _initialized = true;

  if (UNICODE_MAP && IDS) {
    for (const [char, tag] of Object.entries(UNICODE_MAP)) {
      const m = typeof tag === 'string' ? tag.match(/<a?:([a-zA-Z0-9_]+):(\d+)>/) : null;
      if (m) {
        let name = m[1];
        if (CANONICAL_ALIASES && CANONICAL_ALIASES[name]) name = CANONICAL_ALIASES[name];
        if (IDS[name] && m[2] !== IDS[name]) {
          UNICODE_MAP[char] = `<a:${name}:${IDS[name]}>`;
        }
      }
    }
  }

  // ─────────────────────────────────────────────────────────────
  // 1. ButtonBuilder.prototype.setEmoji
  // ─────────────────────────────────────────────────────────────
  if (ButtonBuilder && ButtonBuilder.prototype) {
    const _origSetEmoji = ButtonBuilder.prototype.setEmoji;
    ButtonBuilder.prototype.setEmoji = function(emoji) {
      if (typeof emoji === 'string') {
        let rep = UNICODE_MAP[emoji] || replaceEmojis(null, emoji);
        let m = (rep && typeof rep === 'string') ? rep.match(/<a?:([a-zA-Z0-9_]+):(\d+)>/) : null;
        if (!m && typeof emoji === 'string') {
          m = emoji.match(/<a?:([a-zA-Z0-9_]+):(\d+)>/);
        }
        if (m) {
          let name = m[1];
          let id = m[2];
          if (CANONICAL_ALIASES && CANONICAL_ALIASES[name]) name = CANONICAL_ALIASES[name];
          if (IDS && IDS[name] && id !== IDS[name]) {
            id = IDS[name];
          }
          return _origSetEmoji.call(this, { name, id, animated: true });
        }
        if (rep && rep.startsWith('<a:')) {
          return _origSetEmoji.call(this, rep);
        }
      } else if (emoji && typeof emoji === 'object' && emoji.name) {
        let name = emoji.name;
        let id = emoji.id;
        if (CANONICAL_ALIASES && CANONICAL_ALIASES[name]) name = CANONICAL_ALIASES[name];
        if (IDS && IDS[name] && id !== IDS[name]) {
          id = IDS[name];
        }
        const rep = UNICODE_MAP[name] || replaceEmojis(null, name);
        if (rep && rep.startsWith('<a:')) {
          const m = rep.match(/<a:([a-zA-Z0-9_]+):(\d+)>/);
          if (m) {
            let mName = m[1];
            let mId = m[2];
            if (CANONICAL_ALIASES && CANONICAL_ALIASES[mName]) mName = CANONICAL_ALIASES[mName];
            if (IDS && IDS[mName] && mId !== IDS[mName]) mId = IDS[mName];
            return _origSetEmoji.call(this, { name: mName, id: mId, animated: true });
          }
        }
        if (id) {
          return _origSetEmoji.call(this, { ...emoji, name, id, animated: emoji.animated !== false });
        }
      }
      return _origSetEmoji.call(this, emoji);
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 2. StringSelectMenuOptionBuilder.prototype.setEmoji & setDescription
  // ─────────────────────────────────────────────────────────────
  if (StringSelectMenuOptionBuilder && StringSelectMenuOptionBuilder.prototype) {
    const _origOptSetEmoji = StringSelectMenuOptionBuilder.prototype.setEmoji;
    StringSelectMenuOptionBuilder.prototype.setEmoji = function(emoji) {
      const healed = healSelectMenuEmoji(emoji);
      if (healed) {
        return _origOptSetEmoji.call(this, healed);
      }
      if (this.data) delete this.data.emoji;
      return this;
    };

    const _origOptSetDesc = StringSelectMenuOptionBuilder.prototype.setDescription;
    if (typeof _origOptSetDesc === 'function') {
      StringSelectMenuOptionBuilder.prototype.setDescription = function(description) {
        if (typeof description === 'string') {
          description = description
            .replace(/\${EMOJIS\.[A-Z0-9_]+}/g, '')
            .replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '')
            .replace(/\s{2,}/g, ' ')
            .trim();
          if (!description) {
            if (this.data) delete this.data.description;
            return this;
          }
        }
        return _origOptSetDesc.call(this, description);
      };
    }
  }

  // ─────────────────────────────────────────────────────────────
  // 3. StringSelectMenuBuilder.prototype.addOptions & setOptions
  // ─────────────────────────────────────────────────────────────
  if (StringSelectMenuBuilder && StringSelectMenuBuilder.prototype) {
    function sanitizeSelectMenuOptionsArgs(options) {
      const flattened = options.flat(Infinity);

      for (const opt of flattened) {
        if (!opt) continue;

        // 1. Process and heal opt.emoji / opt.data.emoji
        const rawEmoji = opt.emoji !== undefined ? opt.emoji : opt.data?.emoji;
        if (rawEmoji !== undefined) {
          const healed = healSelectMenuEmoji(rawEmoji);
          if (healed) {
            if (opt.emoji !== undefined) opt.emoji = healed;
            if (opt.data?.emoji !== undefined) opt.data.emoji = healed;
            if (typeof opt.setEmoji === 'function') {
              try { opt.setEmoji(healed); } catch (e) {}
            }
          } else {
            // Remove opt.emoji if not resolvable or invalid ID
            delete opt.emoji;
            if (opt.data?.emoji) delete opt.data.emoji;
          }
        }

        // 2. Process and sanitize opt.description / opt.data.description
        if (typeof opt.description === 'string') {
          let cleanDesc = opt.description
            .replace(/\${EMOJIS\.[A-Z0-9_]+}/g, '')
            .replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '')
            .replace(/\s{2,}/g, ' ')
            .trim();
          if (cleanDesc) {
            opt.description = cleanDesc;
          } else {
            delete opt.description;
          }
        }
        if (typeof opt.data?.description === 'string') {
          let cleanDesc = opt.data.description
            .replace(/\${EMOJIS\.[A-Z0-9_]+}/g, '')
            .replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '')
            .replace(/\s{2,}/g, ' ')
            .trim();
          if (cleanDesc) {
            opt.data.description = cleanDesc;
            if (typeof opt.setDescription === 'function') {
              try { opt.setDescription(cleanDesc); } catch (e) {}
            }
          } else {
            delete opt.data.description;
          }
        }
      }
    }

    const _origAddOptions = StringSelectMenuBuilder.prototype.addOptions;
    StringSelectMenuBuilder.prototype.addOptions = function(...options) {
      sanitizeSelectMenuOptionsArgs(options);
      return _origAddOptions.apply(this, options);
    };

    const _origSetOptions = StringSelectMenuBuilder.prototype.setOptions;
    if (typeof _origSetOptions === 'function') {
      StringSelectMenuBuilder.prototype.setOptions = function(...options) {
        sanitizeSelectMenuOptionsArgs(options);
        return _origSetOptions.apply(this, options);
      };
    }
  }

  // ─────────────────────────────────────────────────────────────
  // 4. Message.prototype.reply & Message.prototype.edit & Channel.prototype.send
  // ─────────────────────────────────────────────────────────────
  if (Message && Message.prototype) {
    if (typeof Message.prototype.reply === 'function' && !Message.prototype.reply.__uiSanitized) {
      const _origMsgReply = Message.prototype.reply;
      const wrapped = function(options) {
        const gid = resolveGuildId(this);
        return uiContextStorage.run({ guildId: gid }, () => {
          return _origMsgReply.call(this, sanitizeUiPayload(this, options));
        });
      };
      wrapped.__uiSanitized = true;
      Message.prototype.reply = wrapped;
    }

    if (typeof Message.prototype.edit === 'function' && !Message.prototype.edit.__uiSanitized) {
      const _origMsgEdit = Message.prototype.edit;
      const wrapped = function(options) {
        const gid = resolveGuildId(this);
        return uiContextStorage.run({ guildId: gid }, () => {
          return _origMsgEdit.call(this, sanitizeUiPayload(this, options));
        });
      };
      wrapped.__uiSanitized = true;
      Message.prototype.edit = wrapped;
    }
  }

  const channelClasses = [TextChannel, DMChannel, NewsChannel, ThreadChannel].filter(Boolean);
  for (const ChannelClass of channelClasses) {
    if (ChannelClass.prototype && typeof ChannelClass.prototype.send === 'function' && !ChannelClass.prototype.send.__uiSanitized) {
      const _origSend = ChannelClass.prototype.send;
      const wrapped = function(options) {
        const gid = resolveGuildId(this);
        return uiContextStorage.run({ guildId: gid }, () => {
          return _origSend.call(this, sanitizeUiPayload(this, options));
        });
      };
      wrapped.__uiSanitized = true;
      ChannelClass.prototype.send = wrapped;
    }
  }

  // ─────────────────────────────────────────────────────────────
  // 5. Interaction Reply, FollowUp, EditReply & Update
  // Only intercept classes that define the methods (CommandInteraction, ModalSubmitInteraction,
  // MessageComponentInteraction). Subclasses (ButtonInteraction, StringSelectMenuInteraction)
  // cleanly inherit without shadowing or double-interception.
  // ─────────────────────────────────────────────────────────────
  const interactionClasses = [
    CommandInteraction,
    ModalSubmitInteraction,
    MessageComponentInteraction
  ].filter(Boolean);

  for (const IntClass of interactionClasses) {
    if (!IntClass.prototype) continue;

    if (typeof IntClass.prototype.reply === 'function' && !IntClass.prototype.reply.__uiSanitized) {
      const _origReply = IntClass.prototype.reply;
      const wrapped = function(options) {
        const gid = resolveGuildId(this);
        return uiContextStorage.run({ guildId: gid }, () => {
          return _origReply.call(this, sanitizeUiPayload(this, options));
        });
      };
      wrapped.__uiSanitized = true;
      IntClass.prototype.reply = wrapped;
    }

    if (typeof IntClass.prototype.followUp === 'function' && !IntClass.prototype.followUp.__uiSanitized) {
      const _origFollowUp = IntClass.prototype.followUp;
      const wrapped = function(options) {
        const gid = resolveGuildId(this);
        return uiContextStorage.run({ guildId: gid }, () => {
          return _origFollowUp.call(this, sanitizeUiPayload(this, options));
        });
      };
      wrapped.__uiSanitized = true;
      IntClass.prototype.followUp = wrapped;
    }

    if (typeof IntClass.prototype.editReply === 'function' && !IntClass.prototype.editReply.__uiSanitized) {
      const _origEditReply = IntClass.prototype.editReply;
      const wrapped = function(options) {
        const gid = resolveGuildId(this);
        return uiContextStorage.run({ guildId: gid }, () => {
          return _origEditReply.call(this, sanitizeUiPayload(this, options));
        });
      };
      wrapped.__uiSanitized = true;
      IntClass.prototype.editReply = wrapped;
    }

    if (typeof IntClass.prototype.update === 'function' && !IntClass.prototype.update.__uiSanitized) {
      const _origUpdate = IntClass.prototype.update;
      const wrapped = function(options) {
        const gid = resolveGuildId(this);
        return uiContextStorage.run({ guildId: gid }, () => {
          return _origUpdate.call(this, sanitizeUiPayload(this, options));
        });
      };
      wrapped.__uiSanitized = true;
      IntClass.prototype.update = wrapped;
    }
  }
}

// Auto-initialize when required
initUiSanitizer();

module.exports = {
  initUiSanitizer,
  sanitizeUiPayload,
  getUiStyle,
  cleanTemplatePlaceholders,
  stripRawCustomEmojis,
  healSelectMenuEmoji
};
