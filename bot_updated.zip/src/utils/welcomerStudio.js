/**
 * Welcomer & Leave Studio Utilities
 * Provides shared constants, emojis, and references to Welcome and Leave builders.
 */
const {
  getWelcomeConfig,
  saveWelcomeConfig,
  buildWelcomeStudioPayload,
  buildWelcomePreviewCard
} = require('../commands/welcomer/welcome');

const {
  getLeaveConfig,
  saveLeaveConfig,
  buildLeaveStudioPayload,
  buildLeavePreviewCard
} = require('../commands/welcomer/leave');

const STUDIO_EMOJIS = {
  UI_TOGGLE_ON: '<a:tungsten_ui_toggle_on:1569329685110849576>',
  UI_TOGGLE_OFF: '<a:tungsten_ui_toggle_off:1569329677187678368>',
  WELCOMESCREEN: '<a:tungsten_welcomescreen:1569329748486787085>'
};

module.exports = {
  STUDIO_EMOJIS,
  getWelcomeConfig,
  saveWelcomeConfig,
  buildWelcomeStudioPayload,
  buildWelcomePreviewCard,
  getLeaveConfig,
  saveLeaveConfig,
  buildLeaveStudioPayload,
  buildLeavePreviewCard
};
