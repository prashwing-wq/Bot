/**
 * Tungsten Quests & Daily Challenges Engine (Node.js)
 * Implements deterministic daily quests (reset at UTC midnight), progress tracking,
 * automatic XP & coin rewards, and daily quest streaks.
 */
const crypto = require('crypto');
const { getServerDb } = require('./serverDb');
const { creditWallet } = require('./economy');

const QUEST_POOL = [
  {
    id: 'chat_10',
    type: 'chat',
    title: 'Chatterbox',
    desc: 'Send 10 messages in server chat',
    target: 10,
    rewardCoins: 300,
    rewardXp: 50
  },
  {
    id: 'chat_25',
    type: 'chat',
    title: 'Active Conversationalist',
    desc: 'Send 25 messages in server chat',
    target: 25,
    rewardCoins: 600,
    rewardXp: 100
  },
  {
    id: 'work_1',
    type: 'work',
    title: 'Honest Labor',
    desc: 'Complete 1 work shift with !work',
    target: 1,
    rewardCoins: 250,
    rewardXp: 40
  },
  {
    id: 'work_2',
    type: 'work',
    title: 'Hard Worker',
    desc: 'Complete 2 work shifts with !work',
    target: 2,
    rewardCoins: 450,
    rewardXp: 75
  },
  {
    id: 'beg_2',
    type: 'beg',
    title: 'Street Hustler',
    desc: 'Beg for coins 2 times with !beg',
    target: 2,
    rewardCoins: 200,
    rewardXp: 30
  },
  {
    id: 'fish_2',
    type: 'fish',
    title: "Angler's Luck",
    desc: 'Go fishing 2 times with !fish',
    target: 2,
    rewardCoins: 350,
    rewardXp: 60
  },
  {
    id: 'hunt_2',
    type: 'hunt',
    title: 'Wild Tracker',
    desc: 'Go hunting 2 times with !hunt',
    target: 2,
    rewardCoins: 350,
    rewardXp: 60
  },
  {
    id: 'daily_1',
    type: 'daily',
    title: 'Dedicated Daily',
    desc: 'Claim your daily stipend with !daily',
    target: 1,
    rewardCoins: 300,
    rewardXp: 50
  },
  {
    id: 'gamble_2',
    type: 'gamble',
    title: 'High Roller',
    desc: 'Play slots 2 times with !slots',
    target: 2,
    rewardCoins: 400,
    rewardXp: 70
  },
  {
    id: 'deposit_1',
    type: 'deposit',
    title: 'Prudent Banker',
    desc: 'Deposit coins into your bank vault with !deposit',
    target: 1,
    rewardCoins: 250,
    rewardXp: 40
  }
];

/**
 * Returns current UTC date string: YYYY-MM-DD
 */
function getUtcDateString(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

/**
 * Returns yesterday's UTC date string: YYYY-MM-DD
 */
function getYesterdayUtcDateString(d = new Date()) {
  const y = new Date(d.getTime() - (24 * 60 * 60 * 1000));
  return y.toISOString().slice(0, 10);
}

/**
 * Generates 3 deterministic daily quests for a given userId and date string.
 */
function generateDailyQuests(userId, dateStr = getUtcDateString()) {
  const hash = crypto.createHash('sha256').update(`${userId}:${dateStr}`).digest('hex');
  const pool = [...QUEST_POOL];
  const selected = [];

  for (let i = 0; i < 3; i++) {
    const chunk = hash.slice(i * 8, (i + 1) * 8);
    const num = parseInt(chunk, 16);
    const index = num % pool.length;
    const template = pool.splice(index, 1)[0];
    selected.push({
      id: template.id,
      type: template.type,
      title: template.title,
      desc: template.desc,
      target: template.target,
      progress: 0,
      completed: false,
      claimed: false,
      rewardCoins: template.rewardCoins,
      rewardXp: template.rewardXp
    });
  }

  return selected;
}

/**
 * Safely adds XP to a user in leveling_users.
 */
function addQuestXp(sdb, guildId, userId, amount) {
  if (amount <= 0) return;
  try {
    const row = sdb.prepare('SELECT xp, level FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(guildId, String(userId));
    const curXp = row ? (row.xp || 0) : 0;
    const curLevel = row ? (row.level || 0) : 0;
    const newXp = curXp + amount;
    const newLevel = Math.floor(0.1 * Math.sqrt(newXp));
    const now = Math.floor(Date.now() / 1000);

    sdb.prepare(`
      INSERT INTO leveling_users (guild_id, user_id, xp, level, last_xp_time)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET
        xp = excluded.xp,
        level = excluded.level,
        last_xp_time = excluded.last_xp_time
    `).run(guildId, String(userId), newXp, newLevel, now);

    return { newXp, newLevel, leveledUp: newLevel > curLevel };
  } catch (_) {}
}

/**
 * Gets or initializes a user's daily quests for a specific UTC date.
 */
function getUserQuests(guildId, userId, dateStr = getUtcDateString(), sdb) {
  const db = sdb || getServerDb(guildId);
  const uid = String(userId);

  try {
    const row = db.prepare('SELECT quests_json FROM user_quests WHERE guild_id = ? AND user_id = ? AND date = ?')
      .get(guildId, uid, dateStr);

    if (row && row.quests_json) {
      try {
        const parsed = JSON.parse(row.quests_json);
        if (Array.isArray(parsed) && parsed.length === 3) {
          return parsed;
        }
      } catch (_) {}
    }

    // Generate new deterministic daily quests
    const quests = generateDailyQuests(uid, dateStr);
    const json = JSON.stringify(quests);

    db.prepare(`
      INSERT INTO user_quests (guild_id, user_id, date, quests_json)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(guild_id, user_id, date) DO UPDATE SET
        quests_json = excluded.quests_json
    `).run(guildId, uid, dateStr, json);

    return quests;
  } catch (err) {
    return generateDailyQuests(uid, dateStr);
  }
}

/**
 * Retrieves quest streak details for a user.
 */
function getUserStreak(guildId, userId, sdb) {
  const db = sdb || getServerDb(guildId);
  try {
    const row = db.prepare('SELECT streak, last_completed FROM quest_streaks WHERE guild_id = ? AND user_id = ?')
      .get(guildId, String(userId));
    return {
      streak: row ? (row.streak || 0) : 0,
      last_completed: row ? (row.last_completed || null) : null
    };
  } catch (_) {
    return { streak: 0, last_completed: null };
  }
}

/**
 * Records progress towards a specific action type for a user's daily quests.
 */
function recordQuestProgress(guildId, userId, actionType, amount = 1, sdb) {
  if (!guildId || !userId || !actionType || amount <= 0) return null;
  const db = sdb || getServerDb(guildId);
  const uid = String(userId);
  const today = getUtcDateString();

  let quests = getUserQuests(guildId, uid, today, db);
  let changed = false;
  let newlyCompleted = [];

  for (const q of quests) {
    if (q.type === actionType && !q.completed) {
      q.progress = Math.min(q.target, (q.progress || 0) + amount);
      changed = true;
      if (q.progress >= q.target) {
        q.completed = true;
        q.claimed = true; // Auto-claim upon completion
        creditWallet(db, uid, q.rewardCoins);
        addQuestXp(db, guildId, uid, q.rewardXp);
        newlyCompleted.push(q);
      }
    }
  }

  let streakInfo = getUserStreak(guildId, uid, db);
  let streakUpdated = false;

  // Check if all daily quests are now completed
  if (quests.length > 0 && quests.every(q => q.completed)) {
    if (streakInfo.last_completed !== today) {
      const yesterday = getYesterdayUtcDateString();
      let newStreak = 1;
      if (streakInfo.last_completed === yesterday) {
        newStreak = (streakInfo.streak || 0) + 1;
      }

      // Bonus rewards for maintaining streak
      const streakBonusCoins = 500 + (newStreak * 100);
      const streakBonusXp = 100 + (newStreak * 25);
      creditWallet(db, uid, streakBonusCoins);
      addQuestXp(db, guildId, uid, streakBonusXp);

      db.prepare(`
        INSERT INTO quest_streaks (guild_id, user_id, streak, last_completed)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET
          streak = excluded.streak,
          last_completed = excluded.last_completed
      `).run(guildId, uid, newStreak, today);

      streakInfo = { streak: newStreak, last_completed: today, bonusCoins: streakBonusCoins, bonusXp: streakBonusXp };
      streakUpdated = true;
      changed = true;
    }
  }

  if (changed) {
    try {
      db.prepare('UPDATE user_quests SET quests_json = ? WHERE guild_id = ? AND user_id = ? AND date = ?')
        .run(JSON.stringify(quests), guildId, uid, today);
    } catch (_) {}
  }

  return {
    quests,
    newlyCompleted,
    streakInfo,
    streakUpdated
  };
}

/**
 * Claims any completed but unclaimed quests and handles streak advancement.
 */
function claimQuestRewards(guildId, userId, sdb) {
  const db = sdb || getServerDb(guildId);
  const uid = String(userId);
  const today = getUtcDateString();

  const quests = getUserQuests(guildId, uid, today, db);
  let claimedCoins = 0;
  let claimedXp = 0;
  let changed = false;

  for (const q of quests) {
    if (q.completed && !q.claimed) {
      q.claimed = true;
      creditWallet(db, uid, q.rewardCoins);
      addQuestXp(db, guildId, uid, q.rewardXp);
      claimedCoins += q.rewardCoins;
      claimedXp += q.rewardXp;
      changed = true;
    }
  }

  let streakInfo = getUserStreak(guildId, uid, db);
  let streakUpdated = false;

  if (quests.length > 0 && quests.every(q => q.completed)) {
    if (streakInfo.last_completed !== today) {
      const yesterday = getYesterdayUtcDateString();
      let newStreak = 1;
      if (streakInfo.last_completed === yesterday) {
        newStreak = (streakInfo.streak || 0) + 1;
      }
      const streakBonusCoins = 500 + (newStreak * 100);
      const streakBonusXp = 100 + (newStreak * 25);
      creditWallet(db, uid, streakBonusCoins);
      addQuestXp(db, guildId, uid, streakBonusXp);

      db.prepare(`
        INSERT INTO quest_streaks (guild_id, user_id, streak, last_completed)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET
          streak = excluded.streak,
          last_completed = excluded.last_completed
      `).run(guildId, uid, newStreak, today);

      claimedCoins += streakBonusCoins;
      claimedXp += streakBonusXp;
      streakInfo = { streak: newStreak, last_completed: today, bonusCoins: streakBonusCoins, bonusXp: streakBonusXp };
      streakUpdated = true;
      changed = true;
    }
  }

  if (changed) {
    try {
      db.prepare('UPDATE user_quests SET quests_json = ? WHERE guild_id = ? AND user_id = ? AND date = ?')
        .run(JSON.stringify(quests), guildId, uid, today);
    } catch (_) {}
  }

  return {
    quests,
    claimedCoins,
    claimedXp,
    streakInfo,
    streakUpdated
  };
}

/**
 * Visual progress bar rendering helper.
 */
function renderProgressBar(current, target, length = 10) {
  const cur = Math.max(0, current || 0);
  const tgt = Math.max(1, target || 1);
  const percent = Math.min(1, Math.max(0, cur / tgt));
  const filled = Math.round(length * percent);
  const empty = Math.max(0, length - filled);
  const bar = '█'.repeat(filled) + '░'.repeat(empty);
  return `\`[${bar}]\` ${cur}/${tgt} (${Math.round(percent * 100)}%)`;
}

module.exports = {
  QUEST_POOL,
  getUtcDateString,
  getYesterdayUtcDateString,
  generateDailyQuests,
  getUserQuests,
  getUserStreak,
  recordQuestProgress,
  claimQuestRewards,
  renderProgressBar,
  addQuestXp
};
