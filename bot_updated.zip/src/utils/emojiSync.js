/**
 * Tungsten Emoji Server Synchronization Engine
 * Automatically discovers dedicated emoji servers (Custom emoji, Tungsten emoji, etc.),
 * synchronizes bespoke animated emojis into their designated servers,
 * and provides global cross-server emoji resolution.
 */
const { BUILTIN_PACK, EMOJIS, UNICODE_MAP, resolveEmoji, replaceEmojis, EMOJI_SERVER_IDS } = require('./emojis');
const config = require('../config');

const SERVER_PACKS = {
  "1": [
    {
      "name": "tungsten_alarm",
      "label": "Alarm",
      "animated": true,
      "discordTag": "<a:tungsten_alarm:1567229471474585682>",
      "id": "1567229471474585682",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567229471474585682.gif"
    },
    {
      "name": "tungsten_ui_backup_db",
      "label": "Ui Backup Db",
      "animated": true,
      "discordTag": "<a:tungsten_ui_backup_db:1567243012629729341>",
      "id": "1567243012629729341",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243012629729341.gif"
    },
    {
      "name": "tungsten_ui_channel_tools",
      "label": "Ui Channel Tools",
      "animated": true,
      "discordTag": "<a:tungsten_ui_channel_tools:1567243046951854130>",
      "id": "1567243046951854130",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243046951854130.gif"
    },
    {
      "name": "tungsten_ui_check_rank",
      "label": "Ui Check Rank",
      "animated": true,
      "discordTag": "<a:tungsten_ui_check_rank:1567243080464335058>",
      "id": "1567243080464335058",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243080464335058.gif"
    },
    {
      "name": "tungsten_ui_complete_verify",
      "label": "Ui Complete Verify",
      "animated": true,
      "discordTag": "<a:tungsten_ui_complete_verify:1567243101477806101>",
      "id": "1567243101477806101",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243101477806101.gif"
    },
    {
      "name": "tungsten_ui_d10m",
      "label": "Ui D10m",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d10m:1567243132008136765>",
      "id": "1567243132008136765",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243132008136765.gif"
    },
    {
      "name": "tungsten_ui_d1d",
      "label": "Ui D1d",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d1d:1567243179269423157>",
      "id": "1567243179269423157",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243179269423157.gif"
    },
    {
      "name": "tungsten_ui_d1h",
      "label": "Ui D1h",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d1h:1567243251767971951>",
      "id": "1567243251767971951",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243251767971951.gif"
    },
    {
      "name": "tungsten_ui_d1w",
      "label": "Ui D1w",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d1w:1567243278917836991>",
      "id": "1567243278917836991",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243278917836991.gif"
    },
    {
      "name": "tungsten_ui_d5m",
      "label": "Ui D5m",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d5m:1567243350279725106>",
      "id": "1567243350279725106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243350279725106.gif"
    },
    {
      "name": "tungsten_ui_daily_usage",
      "label": "Ui Daily Usage",
      "animated": true,
      "discordTag": "<a:tungsten_ui_daily_usage:1567243371603296270>",
      "id": "1567243371603296270",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243371603296270.gif"
    },
    {
      "name": "tungsten_ui_disable_all",
      "label": "Ui Disable All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_disable_all:1567243443338485862>",
      "id": "1567243443338485862",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243443338485862.gif"
    },
    {
      "name": "tungsten_ui_disconnect",
      "label": "Ui Disconnect",
      "animated": true,
      "discordTag": "<a:tungsten_ui_disconnect:1567243506072682706>",
      "id": "1567243506072682706",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243506072682706.gif"
    },
    {
      "name": "tungsten_ui_dismiss",
      "label": "Ui Dismiss",
      "animated": true,
      "discordTag": "<a:tungsten_ui_dismiss:1567243549555036200>",
      "id": "1567243549555036200",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243549555036200.gif"
    },
    {
      "name": "tungsten_ui_dm_test",
      "label": "Ui Dm Test",
      "animated": true,
      "discordTag": "<a:tungsten_ui_dm_test:1567243572002951178>",
      "id": "1567243572002951178",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243572002951178.gif"
    },
    {
      "name": "tungsten_ui_edit_nick",
      "label": "Ui Edit Nick",
      "animated": true,
      "discordTag": "<a:tungsten_ui_edit_nick:1567243591686823967>",
      "id": "1567243591686823967",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243591686823967.gif"
    },
    {
      "name": "tungsten_ui_enable_all",
      "label": "Ui Enable All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_enable_all:1567243610716508202>",
      "id": "1567243610716508202",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243610716508202.gif"
    },
    {
      "name": "tungsten_ui_events",
      "label": "Ui Events",
      "animated": true,
      "discordTag": "<a:tungsten_ui_events:1567243642094092323>",
      "id": "1567243642094092323",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243642094092323.gif"
    },
    {
      "name": "tungsten_ui_forfeit",
      "label": "Ui Forfeit",
      "animated": true,
      "discordTag": "<a:tungsten_ui_forfeit:1567243664613314610>",
      "id": "1567243664613314610",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243664613314610.gif"
    },
    {
      "name": "tungsten_ui_hide",
      "label": "Ui Hide",
      "animated": true,
      "discordTag": "<a:tungsten_ui_hide:1567243688143487107>",
      "id": "1567243688143487107",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243688143487107.gif"
    },
    {
      "name": "tungsten_ui_hide_vc",
      "label": "Ui Hide Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_hide_vc:1567243710075371651>",
      "id": "1567243710075371651",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243710075371651.gif"
    },
    {
      "name": "tungsten_ui_install",
      "label": "Ui Install",
      "animated": true,
      "discordTag": "<a:tungsten_ui_install:1567243737363386509>",
      "id": "1567243737363386509",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243737363386509.gif"
    },
    {
      "name": "tungsten_ui_invite_admin",
      "label": "Ui Invite Admin",
      "animated": true,
      "discordTag": "<a:tungsten_ui_invite_admin:1567243760079741052>",
      "id": "1567243760079741052",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243760079741052.gif"
    },
    {
      "name": "tungsten_ui_invite_std",
      "label": "Ui Invite Std",
      "animated": true,
      "discordTag": "<a:tungsten_ui_invite_std:1567243779495305246>",
      "id": "1567243779495305246",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243779495305246.gif"
    },
    {
      "name": "tungsten_ui_join_support",
      "label": "Ui Join Support",
      "animated": true,
      "discordTag": "<a:tungsten_ui_join_support:1567243801343299704>",
      "id": "1567243801343299704",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243801343299704.gif"
    },
    {
      "name": "tungsten_ui_jump",
      "label": "Ui Jump",
      "animated": true,
      "discordTag": "<a:tungsten_ui_jump:1567243825028538530>",
      "id": "1567243825028538530",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243825028538530.gif"
    },
    {
      "name": "tungsten_ui_lb_history",
      "label": "Ui Lb History",
      "animated": true,
      "discordTag": "<a:tungsten_ui_lb_history:1567243859229147236>",
      "id": "1567243859229147236",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243859229147236.gif"
    },
    {
      "name": "tungsten_ui_leveling",
      "label": "Ui Leveling",
      "animated": true,
      "discordTag": "<a:tungsten_ui_leveling:1567243886294737016>",
      "id": "1567243886294737016",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243886294737016.gif"
    },
    {
      "name": "tungsten_ui_list",
      "label": "Ui List",
      "animated": true,
      "discordTag": "<a:tungsten_ui_list:1567243909707604059>",
      "id": "1567243909707604059",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243909707604059.gif"
    },
    {
      "name": "tungsten_ui_lock_vc",
      "label": "Ui Lock Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_lock_vc:1567243939503931611>",
      "id": "1567243939503931611",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243939503931611.gif"
    },
    {
      "name": "tungsten_ui_lockdown",
      "label": "Ui Lockdown",
      "animated": true,
      "discordTag": "<a:tungsten_ui_lockdown:1567243966150082580>",
      "id": "1567243966150082580",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243966150082580.gif"
    },
    {
      "name": "tungsten_ui_manage",
      "label": "Ui Manage",
      "animated": true,
      "discordTag": "<a:tungsten_ui_manage:1567243992435920926>",
      "id": "1567243992435920926",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243992435920926.gif"
    },
    {
      "name": "tungsten_ui_mute_all",
      "label": "Ui Mute All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_mute_all:1567244037264506951>",
      "id": "1567244037264506951",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244037264506951.gif"
    },
    {
      "name": "tungsten_ui_n1",
      "label": "Ui N1",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n1:1567244083447996537>",
      "id": "1567244083447996537",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244083447996537.gif"
    },
    {
      "name": "tungsten_ui_n2",
      "label": "Ui N2",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n2:1567244128704659548>",
      "id": "1567244128704659548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244128704659548.gif"
    },
    {
      "name": "tungsten_ui_n3",
      "label": "Ui N3",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n3:1567244152553603203>",
      "id": "1567244152553603203",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244152553603203.gif"
    },
    {
      "name": "tungsten_ui_n4",
      "label": "Ui N4",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n4:1567244239912575056>",
      "id": "1567244239912575056",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244239912575056.gif"
    },
    {
      "name": "tungsten_ui_n5",
      "label": "Ui N5",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n5:1567244324213755965>",
      "id": "1567244324213755965",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244324213755965.gif"
    },
    {
      "name": "tungsten_ui_n6",
      "label": "Ui N6",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n6:1567244344866639972>",
      "id": "1567244344866639972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244344866639972.gif"
    },
    {
      "name": "tungsten_ui_n7",
      "label": "Ui N7",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n7:1567244425057411202>",
      "id": "1567244425057411202",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244425057411202.gif"
    },
    {
      "name": "tungsten_ui_off",
      "label": "Ui Off",
      "animated": true,
      "discordTag": "<a:tungsten_ui_off:1567244478178402347>",
      "id": "1567244478178402347",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244478178402347.gif"
    },
    {
      "name": "tungsten_ui_on",
      "label": "Ui On",
      "animated": true,
      "discordTag": "<a:tungsten_ui_on:1567244543546630266>",
      "id": "1567244543546630266",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244543546630266.gif"
    },
    {
      "name": "tungsten_ui_open",
      "label": "Ui Open",
      "animated": true,
      "discordTag": "<a:tungsten_ui_open:1567244565159743488>",
      "id": "1567244565159743488",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244565159743488.gif"
    },
    {
      "name": "tungsten_ui_overview",
      "label": "Ui Overview",
      "animated": true,
      "discordTag": "<a:tungsten_ui_overview:1567244587137769573>",
      "id": "1567244587137769573",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244587137769573.gif"
    },
    {
      "name": "tungsten_ui_p10",
      "label": "Ui P10",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p10:1567244612081553568>",
      "id": "1567244612081553568",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244612081553568.gif"
    },
    {
      "name": "tungsten_ui_p100",
      "label": "Ui P100",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p100:1567244632121671763>",
      "id": "1567244632121671763",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244632121671763.gif"
    },
    {
      "name": "tungsten_ui_p25",
      "label": "Ui P25",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p25:1567244653416161343>",
      "id": "1567244653416161343",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244653416161343.gif"
    }
  ],
  "2": [
    {
      "name": "tungsten_ui_p50",
      "label": "Ui P50",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p50:1567244676057006090>",
      "id": "1567244676057006090",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244676057006090.gif"
    },
    {
      "name": "tungsten_ui_paper",
      "label": "Ui Paper",
      "animated": true,
      "discordTag": "<a:tungsten_ui_paper:1567244704989454378>",
      "id": "1567244704989454378",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244704989454378.gif"
    },
    {
      "name": "tungsten_ui_perks",
      "label": "Ui Perks",
      "animated": true,
      "discordTag": "<a:tungsten_ui_perks:1567244732160147549>",
      "id": "1567244732160147549",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244732160147549.gif"
    },
    {
      "name": "tungsten_ui_presets",
      "label": "Ui Presets",
      "animated": true,
      "discordTag": "<a:tungsten_ui_presets:1567244762405150832>",
      "id": "1567244762405150832",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244762405150832.gif"
    },
    {
      "name": "tungsten_ui_pulse",
      "label": "Ui Pulse",
      "animated": true,
      "discordTag": "<a:tungsten_ui_pulse:1567244779249729658>",
      "id": "1567244779249729658",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244779249729658.gif"
    },
    {
      "name": "tungsten_ui_purge_all",
      "label": "Ui Purge All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_purge_all:1567244800946606170>",
      "id": "1567244800946606170",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244800946606170.gif"
    },
    {
      "name": "tungsten_ui_purge_bots",
      "label": "Ui Purge Bots",
      "animated": true,
      "discordTag": "<a:tungsten_ui_purge_bots:1567244820274225244>",
      "id": "1567244820274225244",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244820274225244.gif"
    },
    {
      "name": "tungsten_ui_quickpunish",
      "label": "Ui Quickpunish",
      "animated": true,
      "discordTag": "<a:tungsten_ui_quickpunish:1567244834576801813>",
      "id": "1567244834576801813",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244834576801813.gif"
    },
    {
      "name": "tungsten_ui_quit",
      "label": "Ui Quit",
      "animated": true,
      "discordTag": "<a:tungsten_ui_quit:1567244850779258981>",
      "id": "1567244850779258981",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244850779258981.gif"
    },
    {
      "name": "tungsten_ui_rank",
      "label": "Ui Rank",
      "animated": true,
      "discordTag": "<a:tungsten_ui_rank:1567244880005038184>",
      "id": "1567244880005038184",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244880005038184.gif"
    },
    {
      "name": "tungsten_ui_redeem",
      "label": "Ui Redeem",
      "animated": true,
      "discordTag": "<a:tungsten_ui_redeem:1567244905896616090>",
      "id": "1567244905896616090",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244905896616090.gif"
    },
    {
      "name": "tungsten_ui_remove_timeout",
      "label": "Ui Remove Timeout",
      "animated": true,
      "discordTag": "<a:tungsten_ui_remove_timeout:1567244927346155600>",
      "id": "1567244927346155600",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244927346155600.gif"
    },
    {
      "name": "tungsten_ui_reset",
      "label": "Ui Reset",
      "animated": true,
      "discordTag": "<a:tungsten_ui_reset:1567244948041113621>",
      "id": "1567244948041113621",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244948041113621.gif"
    },
    {
      "name": "tungsten_ui_revoke",
      "label": "Ui Revoke",
      "animated": true,
      "discordTag": "<a:tungsten_ui_revoke:1567244971436679319>",
      "id": "1567244971436679319",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244971436679319.gif"
    },
    {
      "name": "tungsten_ui_rock",
      "label": "Ui Rock",
      "animated": true,
      "discordTag": "<a:tungsten_ui_rock:1567244992609517809>",
      "id": "1567244992609517809",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244992609517809.gif"
    },
    {
      "name": "tungsten_ui_role_add",
      "label": "Ui Role Add",
      "animated": true,
      "discordTag": "<a:tungsten_ui_role_add:1567245019587411968>",
      "id": "1567245019587411968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245019587411968.gif"
    },
    {
      "name": "tungsten_ui_role_remove",
      "label": "Ui Role Remove",
      "animated": true,
      "discordTag": "<a:tungsten_ui_role_remove:1567245052009255103>",
      "id": "1567245052009255103",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245052009255103.gif"
    },
    {
      "name": "tungsten_ui_roles_nick",
      "label": "Ui Roles Nick",
      "animated": true,
      "discordTag": "<a:tungsten_ui_roles_nick:1567245091091910751>",
      "id": "1567245091091910751",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245091091910751.gif"
    },
    {
      "name": "tungsten_ui_rules",
      "label": "Ui Rules",
      "animated": true,
      "discordTag": "<a:tungsten_ui_rules:1567245114655641680>",
      "id": "1567245114655641680",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245114655641680.gif"
    },
    {
      "name": "tungsten_ui_scissors",
      "label": "Ui Scissors",
      "animated": true,
      "discordTag": "<a:tungsten_ui_scissors:1567245155545780484>",
      "id": "1567245155545780484",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245155545780484.gif"
    },
    {
      "name": "tungsten_ui_score",
      "label": "Ui Score",
      "animated": true,
      "discordTag": "<a:tungsten_ui_score:1567245190027288709>",
      "id": "1567245190027288709",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245190027288709.gif"
    },
    {
      "name": "tungsten_ui_server_status",
      "label": "Ui Server Status",
      "animated": true,
      "discordTag": "<a:tungsten_ui_server_status:1567245256393625651>",
      "id": "1567245256393625651",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245256393625651.gif"
    },
    {
      "name": "tungsten_ui_telemetry",
      "label": "Ui Telemetry",
      "animated": true,
      "discordTag": "<a:tungsten_ui_telemetry:1567245337486434404>",
      "id": "1567245337486434404",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245337486434404.gif"
    },
    {
      "name": "tungsten_ui_test",
      "label": "Ui Test",
      "animated": true,
      "discordTag": "<a:tungsten_ui_test:1567245407510204466>",
      "id": "1567245407510204466",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245407510204466.gif"
    },
    {
      "name": "tungsten_ui_ticket_close",
      "label": "Ui Ticket Close",
      "animated": true,
      "discordTag": "<a:tungsten_ui_ticket_close:1567245485117284382>",
      "id": "1567245485117284382",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245485117284382.gif"
    },
    {
      "name": "tungsten_ui_ticket_open",
      "label": "Ui Ticket Open",
      "animated": true,
      "discordTag": "<a:tungsten_ui_ticket_open:1567245507699675276>",
      "id": "1567245507699675276",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245507699675276.gif"
    },
    {
      "name": "tungsten_ui_timeout",
      "label": "Ui Timeout",
      "animated": true,
      "discordTag": "<a:tungsten_ui_timeout:1567245550204493934>",
      "id": "1567245550204493934",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245550204493934.gif"
    },
    {
      "name": "tungsten_ui_unassign",
      "label": "Ui Unassign",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unassign:1567245588783829053>",
      "id": "1567245588783829053",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245588783829053.gif"
    },
    {
      "name": "tungsten_ui_undo",
      "label": "Ui Undo",
      "animated": true,
      "discordTag": "<a:tungsten_ui_undo:1567245669087846462>",
      "id": "1567245669087846462",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245669087846462.gif"
    },
    {
      "name": "tungsten_ui_unhide",
      "label": "Ui Unhide",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unhide:1567245749073354832>",
      "id": "1567245749073354832",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245749073354832.gif"
    },
    {
      "name": "tungsten_ui_unhide_vc",
      "label": "Ui Unhide Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unhide_vc:1567245826777161792>",
      "id": "1567245826777161792",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245826777161792.gif"
    },
    {
      "name": "tungsten_ui_unlock_vc",
      "label": "Ui Unlock Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unlock_vc:1567245856430620782>",
      "id": "1567245856430620782",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245856430620782.gif"
    },
    {
      "name": "tungsten_ui_unlockdown",
      "label": "Ui Unlockdown",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unlockdown:1567245990556209313>",
      "id": "1567245990556209313",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245990556209313.gif"
    },
    {
      "name": "tungsten_ui_unmute_all",
      "label": "Ui Unmute All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unmute_all:1567246118520365256>",
      "id": "1567246118520365256",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246118520365256.gif"
    },
    {
      "name": "tungsten_ui_user_add",
      "label": "Ui User Add",
      "animated": true,
      "discordTag": "<a:tungsten_ui_user_add:1567246155706929205>",
      "id": "1567246155706929205",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246155706929205.gif"
    },
    {
      "name": "tungsten_ui_user_remove",
      "label": "Ui User Remove",
      "animated": true,
      "discordTag": "<a:tungsten_ui_user_remove:1567246253467631616>",
      "id": "1567246253467631616",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246253467631616.gif"
    },
    {
      "name": "tungsten_ui_verbose",
      "label": "Ui Verbose",
      "animated": true,
      "discordTag": "<a:tungsten_ui_verbose:1567246309063397548>",
      "id": "1567246309063397548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246309063397548.gif"
    },
    {
      "name": "tungsten_ui_view_emojis",
      "label": "Ui View Emojis",
      "animated": true,
      "discordTag": "<a:tungsten_ui_view_emojis:1567246384980168774>",
      "id": "1567246384980168774",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246384980168774.gif"
    },
    {
      "name": "tungsten_ui_welcome_test",
      "label": "Ui Welcome Test",
      "animated": true,
      "discordTag": "<a:tungsten_ui_welcome_test:1567246433336299654>",
      "id": "1567246433336299654",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246433336299654.gif"
    },
    {
      "name": "tungsten_unlock",
      "label": "Unlock",
      "animated": true,
      "discordTag": "<a:tungsten_unlock:1567246515209117968>",
      "id": "1567246515209117968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246515209117968.gif"
    },
    {
      "name": "tungsten_user",
      "label": "User",
      "animated": true,
      "discordTag": "<a:tungsten_user:1567246556778995802>",
      "id": "1567246556778995802",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246556778995802.gif"
    },
    {
      "name": "tungsten_users",
      "label": "Users",
      "animated": true,
      "discordTag": "<a:tungsten_users:1567246628606185502>",
      "id": "1567246628606185502",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246628606185502.gif"
    },
    {
      "name": "tungsten_warn",
      "label": "Warn",
      "animated": true,
      "discordTag": "<a:tungsten_warn:1567246685082746940>",
      "id": "1567246685082746940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246685082746940.gif"
    },
    {
      "name": "tungsten_wave",
      "label": "Wave",
      "animated": true,
      "discordTag": "<a:tungsten_wave:1567246763822158004>",
      "id": "1567246763822158004",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246763822158004.gif"
    },
    {
      "name": "tungsten_wind",
      "label": "Wind",
      "animated": true,
      "discordTag": "<a:tungsten_wind:1567246820927602838>",
      "id": "1567246820927602838",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246820927602838.gif"
    },
    {
      "name": "tungsten_zzz",
      "label": "Zzz",
      "animated": true,
      "discordTag": "<a:tungsten_zzz:1567246871834132673>",
      "id": "1567246871834132673",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246871834132673.gif"
    }
  ],
  "3": [
    {
      "name": "tungsten_an_arm",
      "label": "An Arm",
      "animated": true,
      "discordTag": "<a:tungsten_an_arm:1567232430908244079>",
      "id": "1567232430908244079",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232430908244079.gif"
    },
    {
      "name": "tungsten_an_backup_roles",
      "label": "An Backup Roles",
      "animated": true,
      "discordTag": "<a:tungsten_an_backup_roles:1567232464970322071>",
      "id": "1567232464970322071",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232464970322071.gif"
    },
    {
      "name": "tungsten_an_ban",
      "label": "An Ban",
      "animated": true,
      "discordTag": "<a:tungsten_an_ban:1567232483743895684>",
      "id": "1567232483743895684",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232483743895684.gif"
    },
    {
      "name": "tungsten_an_bot",
      "label": "An Bot",
      "animated": true,
      "discordTag": "<a:tungsten_an_bot:1567232510893490216>",
      "id": "1567232510893490216",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232510893490216.gif"
    },
    {
      "name": "tungsten_an_caps",
      "label": "An Caps",
      "animated": true,
      "discordTag": "<a:tungsten_an_caps:1567232530988662824>",
      "id": "1567232530988662824",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232530988662824.gif"
    },
    {
      "name": "tungsten_an_channel_create",
      "label": "An Channel Create",
      "animated": true,
      "discordTag": "<a:tungsten_an_channel_create:1567232575855005736>",
      "id": "1567232575855005736",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232575855005736.gif"
    },
    {
      "name": "tungsten_an_channel_delete",
      "label": "An Channel Delete",
      "animated": true,
      "discordTag": "<a:tungsten_an_channel_delete:1567232594930696262>",
      "id": "1567232594930696262",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232594930696262.gif"
    },
    {
      "name": "tungsten_an_disarm",
      "label": "An Disarm",
      "animated": true,
      "discordTag": "<a:tungsten_an_disarm:1567232635237834762>",
      "id": "1567232635237834762",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232635237834762.gif"
    },
    {
      "name": "tungsten_an_everyone",
      "label": "An Everyone",
      "animated": true,
      "discordTag": "<a:tungsten_an_everyone:1567232659715793068>",
      "id": "1567232659715793068",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232659715793068.gif"
    },
    {
      "name": "tungsten_an_ghostping",
      "label": "An Ghostping",
      "animated": true,
      "discordTag": "<a:tungsten_an_ghostping:1567232680020672664>",
      "id": "1567232680020672664",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232680020672664.gif"
    },
    {
      "name": "tungsten_an_integrity",
      "label": "An Integrity",
      "animated": true,
      "discordTag": "<a:tungsten_an_integrity:1567232702690623490>",
      "id": "1567232702690623490",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232702690623490.gif"
    },
    {
      "name": "tungsten_an_invite",
      "label": "An Invite",
      "animated": true,
      "discordTag": "<a:tungsten_an_invite:1567232720126607421>",
      "id": "1567232720126607421",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232720126607421.gif"
    },
    {
      "name": "tungsten_an_join_flood",
      "label": "An Join Flood",
      "animated": true,
      "discordTag": "<a:tungsten_an_join_flood:1567232740041031831>",
      "id": "1567232740041031831",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232740041031831.gif"
    },
    {
      "name": "tungsten_an_kick",
      "label": "An Kick",
      "animated": true,
      "discordTag": "<a:tungsten_an_kick:1567232757330083940>",
      "id": "1567232757330083940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232757330083940.gif"
    },
    {
      "name": "tungsten_an_limits",
      "label": "An Limits",
      "animated": true,
      "discordTag": "<a:tungsten_an_limits:1567232774367092797>",
      "id": "1567232774367092797",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232774367092797.gif"
    },
    {
      "name": "tungsten_an_link",
      "label": "An Link",
      "animated": true,
      "discordTag": "<a:tungsten_an_link:1567232798299922585>",
      "id": "1567232798299922585",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232798299922585.gif"
    },
    {
      "name": "tungsten_an_lockdown",
      "label": "An Lockdown",
      "animated": true,
      "discordTag": "<a:tungsten_an_lockdown:1567232816406732850>",
      "id": "1567232816406732850",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232816406732850.gif"
    },
    {
      "name": "tungsten_an_lockdown_lift",
      "label": "An Lockdown Lift",
      "animated": true,
      "discordTag": "<a:tungsten_an_lockdown_lift:1567232833670488064>",
      "id": "1567232833670488064",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232833670488064.gif"
    },
    {
      "name": "tungsten_an_logs",
      "label": "An Logs",
      "animated": true,
      "discordTag": "<a:tungsten_an_logs:1567232852200923149>",
      "id": "1567232852200923149",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232852200923149.gif"
    },
    {
      "name": "tungsten_an_mention",
      "label": "An Mention",
      "animated": true,
      "discordTag": "<a:tungsten_an_mention:1567232877584715970>",
      "id": "1567232877584715970",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232877584715970.gif"
    },
    {
      "name": "tungsten_an_nsfw",
      "label": "An Nsfw",
      "animated": true,
      "discordTag": "<a:tungsten_an_nsfw:1567232895830196495>",
      "id": "1567232895830196495",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232895830196495.gif"
    },
    {
      "name": "tungsten_an_punish",
      "label": "An Punish",
      "animated": true,
      "discordTag": "<a:tungsten_an_punish:1567232919984939141>",
      "id": "1567232919984939141",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232919984939141.gif"
    },
    {
      "name": "tungsten_an_raid",
      "label": "An Raid",
      "animated": true,
      "discordTag": "<a:tungsten_an_raid:1567232943435292972>",
      "id": "1567232943435292972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232943435292972.gif"
    },
    {
      "name": "tungsten_an_role_create",
      "label": "An Role Create",
      "animated": true,
      "discordTag": "<a:tungsten_an_role_create:1567232961181384745>",
      "id": "1567232961181384745",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232961181384745.gif"
    },
    {
      "name": "tungsten_an_role_delete",
      "label": "An Role Delete",
      "animated": true,
      "discordTag": "<a:tungsten_an_role_delete:1567232979569483776>",
      "id": "1567232979569483776",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232979569483776.gif"
    },
    {
      "name": "tungsten_an_spam",
      "label": "An Spam",
      "animated": true,
      "discordTag": "<a:tungsten_an_spam:1567233007415197823>",
      "id": "1567233007415197823",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233007415197823.gif"
    },
    {
      "name": "tungsten_an_standard",
      "label": "An Standard",
      "animated": true,
      "discordTag": "<a:tungsten_an_standard:1567233029233967106>",
      "id": "1567233029233967106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233029233967106.gif"
    },
    {
      "name": "tungsten_an_strict",
      "label": "An Strict",
      "animated": true,
      "discordTag": "<a:tungsten_an_strict:1567233050260021398>",
      "id": "1567233050260021398",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233050260021398.gif"
    },
    {
      "name": "tungsten_an_ultra",
      "label": "An Ultra",
      "animated": true,
      "discordTag": "<a:tungsten_an_ultra:1567233073005731872>",
      "id": "1567233073005731872",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233073005731872.gif"
    },
    {
      "name": "tungsten_an_webhook",
      "label": "An Webhook",
      "animated": true,
      "discordTag": "<a:tungsten_an_webhook:1567233087388262422>",
      "id": "1567233087388262422",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233087388262422.gif"
    },
    {
      "name": "tungsten_anger",
      "label": "Anger",
      "animated": true,
      "discordTag": "<a:tungsten_anger:1567233100776218734>",
      "id": "1567233100776218734",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233100776218734.gif"
    },
    {
      "name": "tungsten_arrow_left",
      "label": "Arrow Left",
      "animated": true,
      "discordTag": "<a:tungsten_arrow_left:1567233111601844267>",
      "id": "1567233111601844267",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233111601844267.gif"
    },
    {
      "name": "tungsten_arrow_right",
      "label": "Arrow Right",
      "animated": true,
      "discordTag": "<a:tungsten_arrow_right:1567233126143361135>",
      "id": "1567233126143361135",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233126143361135.gif"
    },
    {
      "name": "tungsten_arrow_small",
      "label": "Arrow Small",
      "animated": true,
      "discordTag": "<a:tungsten_arrow_small:1567233140357988574>",
      "id": "1567233140357988574",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233140357988574.gif"
    },
    {
      "name": "tungsten_atm",
      "label": "Atm",
      "animated": true,
      "discordTag": "<a:tungsten_atm:1567233228350300292>",
      "id": "1567233228350300292",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233228350300292.gif"
    },
    {
      "name": "tungsten_bank",
      "label": "Bank",
      "animated": true,
      "discordTag": "<a:tungsten_bank:1567233290656677924>",
      "id": "1567233290656677924",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233290656677924.gif"
    },
    {
      "name": "tungsten_bell",
      "label": "Bell",
      "animated": true,
      "discordTag": "<a:tungsten_bell:1567233316925612173>",
      "id": "1567233316925612173",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233316925612173.gif"
    },
    {
      "name": "tungsten_bell_slash",
      "label": "Bell Slash",
      "animated": true,
      "discordTag": "<a:tungsten_bell_slash:1567233400996106260>",
      "id": "1567233400996106260",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233400996106260.gif"
    },
    {
      "name": "tungsten_bolt",
      "label": "Bolt",
      "animated": true,
      "discordTag": "<a:tungsten_bolt:1567233430570405968>",
      "id": "1567233430570405968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233430570405968.gif"
    },
    {
      "name": "tungsten_bomb",
      "label": "Bomb",
      "animated": true,
      "discordTag": "<a:tungsten_bomb:1567233448945385502>",
      "id": "1567233448945385502",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233448945385502.gif"
    },
    {
      "name": "tungsten_book",
      "label": "Book",
      "animated": true,
      "discordTag": "<a:tungsten_book:1567233482499948606>",
      "id": "1567233482499948606",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233482499948606.gif"
    },
    {
      "name": "tungsten_boot",
      "label": "Boot",
      "animated": true,
      "discordTag": "<a:tungsten_boot:1567233502418575501>",
      "id": "1567233502418575501",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233502418575501.gif"
    },
    {
      "name": "tungsten_bot",
      "label": "Bot",
      "animated": true,
      "discordTag": "<a:tungsten_bot:1567233522635247781>",
      "id": "1567233522635247781",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233522635247781.gif"
    },
    {
      "name": "tungsten_brain",
      "label": "Brain",
      "animated": true,
      "discordTag": "<a:tungsten_brain:1567233547272454144>",
      "id": "1567233547272454144",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233547272454144.gif"
    },
    {
      "name": "tungsten_briefcase",
      "label": "Briefcase",
      "animated": true,
      "discordTag": "<a:tungsten_briefcase:1567233568596295821>",
      "id": "1567233568596295821",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233568596295821.gif"
    },
    {
      "name": "tungsten_bullet",
      "label": "Bullet",
      "animated": true,
      "discordTag": "<a:tungsten_bullet:1567233589949497434>",
      "id": "1567233589949497434",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233589949497434.gif"
    }
  ],
  "4": [
    {
      "name": "tungsten_cabinet",
      "label": "Cabinet",
      "animated": true,
      "discordTag": "<a:tungsten_cabinet:1567233617489297548>",
      "id": "1567233617489297548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233617489297548.gif"
    },
    {
      "name": "tungsten_calendar",
      "label": "Calendar",
      "animated": true,
      "discordTag": "<a:tungsten_calendar:1567233642554458154>",
      "id": "1567233642554458154",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233642554458154.gif"
    },
    {
      "name": "tungsten_cash",
      "label": "Cash",
      "animated": true,
      "discordTag": "<a:tungsten_cash:1567233665082200267>",
      "id": "1567233665082200267",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233665082200267.gif"
    },
    {
      "name": "tungsten_castle",
      "label": "Castle",
      "animated": true,
      "discordTag": "<a:tungsten_castle:1567233687332982844>",
      "id": "1567233687332982844",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233687332982844.gif"
    },
    {
      "name": "tungsten_cat_automation",
      "label": "Cat Automation",
      "animated": true,
      "discordTag": "<a:tungsten_cat_automation:1567233718861435011>",
      "id": "1567233718861435011",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233718861435011.gif"
    },
    {
      "name": "tungsten_cat_backups",
      "label": "Cat Backups",
      "animated": true,
      "discordTag": "<a:tungsten_cat_backups:1567233747567251666>",
      "id": "1567233747567251666",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233747567251666.gif"
    },
    {
      "name": "tungsten_cat_channels",
      "label": "Cat Channels",
      "animated": true,
      "discordTag": "<a:tungsten_cat_channels:1567233777024110652>",
      "id": "1567233777024110652",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233777024110652.gif"
    },
    {
      "name": "tungsten_cat_economy",
      "label": "Cat Economy",
      "animated": true,
      "discordTag": "<a:tungsten_cat_economy:1567233807822618735>",
      "id": "1567233807822618735",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233807822618735.gif"
    },
    {
      "name": "tungsten_cat_fun",
      "label": "Cat Fun",
      "animated": true,
      "discordTag": "<a:tungsten_cat_fun:1567233835035402350>",
      "id": "1567233835035402350",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233835035402350.gif"
    },
    {
      "name": "tungsten_cat_giveaways",
      "label": "Cat Giveaways",
      "animated": true,
      "discordTag": "<a:tungsten_cat_giveaways:1567233867637588015>",
      "id": "1567233867637588015",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233867637588015.gif"
    },
    {
      "name": "tungsten_cat_leaderboards",
      "label": "Cat Leaderboards",
      "animated": true,
      "discordTag": "<a:tungsten_cat_leaderboards:1567233900366008430>",
      "id": "1567233900366008430",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233900366008430.gif"
    },
    {
      "name": "tungsten_cat_logging",
      "label": "Cat Logging",
      "animated": true,
      "discordTag": "<a:tungsten_cat_logging:1567233934490738860>",
      "id": "1567233934490738860",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233934490738860.gif"
    },
    {
      "name": "tungsten_cat_media",
      "label": "Cat Media",
      "animated": true,
      "discordTag": "<a:tungsten_cat_media:1567233959207764080>",
      "id": "1567233959207764080",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233959207764080.gif"
    },
    {
      "name": "tungsten_cat_moderation",
      "label": "Cat Moderation",
      "animated": true,
      "discordTag": "<a:tungsten_cat_moderation:1567233980523225148>",
      "id": "1567233980523225148",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233980523225148.gif"
    },
    {
      "name": "tungsten_cat_owner",
      "label": "Cat Owner",
      "animated": true,
      "discordTag": "<a:tungsten_cat_owner:1567234022927638649>",
      "id": "1567234022927638649",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234022927638649.gif"
    },
    {
      "name": "tungsten_cat_premium",
      "label": "Cat Premium",
      "animated": true,
      "discordTag": "<a:tungsten_cat_premium:1567234059510223029>",
      "id": "1567234059510223029",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234059510223029.gif"
    },
    {
      "name": "tungsten_cat_roles",
      "label": "Cat Roles",
      "animated": true,
      "discordTag": "<a:tungsten_cat_roles:1567234100975378512>",
      "id": "1567234100975378512",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234100975378512.gif"
    },
    {
      "name": "tungsten_cat_security",
      "label": "Cat Security",
      "animated": true,
      "discordTag": "<a:tungsten_cat_security:1567234156075683940>",
      "id": "1567234156075683940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234156075683940.gif"
    },
    {
      "name": "tungsten_cat_tickets",
      "label": "Cat Tickets",
      "animated": true,
      "discordTag": "<a:tungsten_cat_tickets:1567234238737031290>",
      "id": "1567234238737031290",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234238737031290.gif"
    },
    {
      "name": "tungsten_cat_utility",
      "label": "Cat Utility",
      "animated": true,
      "discordTag": "<a:tungsten_cat_utility:1567234274183217304>",
      "id": "1567234274183217304",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234274183217304.gif"
    },
    {
      "name": "tungsten_cat_welcomer",
      "label": "Cat Welcomer",
      "animated": true,
      "discordTag": "<a:tungsten_cat_welcomer:1567234301869822153>",
      "id": "1567234301869822153",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234301869822153.gif"
    },
    {
      "name": "tungsten_cat_whitelist",
      "label": "Cat Whitelist",
      "animated": true,
      "discordTag": "<a:tungsten_cat_whitelist:1567234327970848848>",
      "id": "1567234327970848848",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234327970848848.gif"
    },
    {
      "name": "tungsten_chart",
      "label": "Chart",
      "animated": true,
      "discordTag": "<a:tungsten_chart:1567234342701367357>",
      "id": "1567234342701367357",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234342701367357.gif"
    },
    {
      "name": "tungsten_chat",
      "label": "Chat",
      "animated": true,
      "discordTag": "<a:tungsten_chat:1567234399450177665>",
      "id": "1567234399450177665",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234399450177665.gif"
    },
    {
      "name": "tungsten_cherry",
      "label": "Cherry",
      "animated": true,
      "discordTag": "<a:tungsten_cherry:1567234489682362439>",
      "id": "1567234489682362439",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234489682362439.gif"
    },
    {
      "name": "tungsten_circle_green",
      "label": "Circle Green",
      "animated": true,
      "discordTag": "<a:tungsten_circle_green:1567234524512002088>",
      "id": "1567234524512002088",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234524512002088.gif"
    },
    {
      "name": "tungsten_circle_red",
      "label": "Circle Red",
      "animated": true,
      "discordTag": "<a:tungsten_circle_red:1567234546586353686>",
      "id": "1567234546586353686",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234546586353686.gif"
    },
    {
      "name": "tungsten_circle_white",
      "label": "Circle White",
      "animated": true,
      "discordTag": "<a:tungsten_circle_white:1567234561799233547>",
      "id": "1567234561799233547",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234561799233547.gif"
    },
    {
      "name": "tungsten_circle_yellow",
      "label": "Circle Yellow",
      "animated": true,
      "discordTag": "<a:tungsten_circle_yellow:1567234580690501693>",
      "id": "1567234580690501693",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234580690501693.gif"
    },
    {
      "name": "tungsten_clapper",
      "label": "Clapper",
      "animated": true,
      "discordTag": "<a:tungsten_clapper:1567234599262879815>",
      "id": "1567234599262879815",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234599262879815.gif"
    },
    {
      "name": "tungsten_clipboard",
      "label": "Clipboard",
      "animated": true,
      "discordTag": "<a:tungsten_clipboard:1567234610176204900>",
      "id": "1567234610176204900",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234610176204900.gif"
    },
    {
      "name": "tungsten_clock",
      "label": "Clock",
      "animated": true,
      "discordTag": "<a:tungsten_clock:1567234623216554118>",
      "id": "1567234623216554118",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234623216554118.gif"
    },
    {
      "name": "tungsten_close",
      "label": "Close",
      "animated": true,
      "discordTag": "<a:tungsten_close:1567234632905138206>",
      "id": "1567234632905138206",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234632905138206.gif"
    },
    {
      "name": "tungsten_cmd_8ball",
      "label": "Cmd 8ball",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_8ball:1567234645140181082>",
      "id": "1567234645140181082",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234645140181082.gif"
    },
    {
      "name": "tungsten_cmd_addemoji",
      "label": "Cmd Addemoji",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_addemoji:1567234657026707537>",
      "id": "1567234657026707537",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234657026707537.gif"
    },
    {
      "name": "tungsten_cmd_afk",
      "label": "Cmd Afk",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_afk:1567234668347260938>",
      "id": "1567234668347260938",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234668347260938.gif"
    },
    {
      "name": "tungsten_cmd_anaudit",
      "label": "Cmd Anaudit",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_anaudit:1567234683937497259>",
      "id": "1567234683937497259",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234683937497259.gif"
    },
    {
      "name": "tungsten_cmd_anmode",
      "label": "Cmd Anmode",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_anmode:1567234697556271327>",
      "id": "1567234697556271327",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234697556271327.gif"
    },
    {
      "name": "tungsten_cmd_antighostping",
      "label": "Cmd Antighostping",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_antighostping:1567234715549835435>",
      "id": "1567234715549835435",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234715549835435.gif"
    },
    {
      "name": "tungsten_cmd_antinuke",
      "label": "Cmd Antinuke",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_antinuke:1567234734726316142>",
      "id": "1567234734726316142",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234734726316142.gif"
    },
    {
      "name": "tungsten_cmd_antiraid",
      "label": "Cmd Antiraid",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_antiraid:1567234763755102373>",
      "id": "1567234763755102373",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234763755102373.gif"
    },
    {
      "name": "tungsten_cmd_auditlog",
      "label": "Cmd Auditlog",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_auditlog:1567234776841195712>",
      "id": "1567234776841195712",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234776841195712.gif"
    },
    {
      "name": "tungsten_cmd_automod",
      "label": "Cmd Automod",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_automod:1567234793022689290>",
      "id": "1567234793022689290",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234793022689290.gif"
    },
    {
      "name": "tungsten_cmd_autoreact",
      "label": "Cmd Autoreact",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_autoreact:1567234807379922944>",
      "id": "1567234807379922944",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234807379922944.gif"
    },
    {
      "name": "tungsten_cmd_autoresponder",
      "label": "Cmd Autoresponder",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_autoresponder:1567234819992330240>",
      "id": "1567234819992330240",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234819992330240.gif"
    },
    {
      "name": "tungsten_cmd_autorole",
      "label": "Cmd Autorole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_autorole:1567234834504482948>",
      "id": "1567234834504482948",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234834504482948.gif"
    },
    {
      "name": "tungsten_cmd_avatar",
      "label": "Cmd Avatar",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_avatar:1567234845363540139>",
      "id": "1567234845363540139",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234845363540139.gif"
    }
  ],
  "5": [
    {
      "name": "tungsten_cmd_backup",
      "label": "Cmd Backup",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_backup:1567234860119236649>",
      "id": "1567234860119236649",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234860119236649.gif"
    },
    {
      "name": "tungsten_cmd_balance",
      "label": "Cmd Balance",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_balance:1567234874736250981>",
      "id": "1567234874736250981",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234874736250981.gif"
    },
    {
      "name": "tungsten_cmd_ban",
      "label": "Cmd Ban",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ban:1567234887503585321>",
      "id": "1567234887503585321",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234887503585321.gif"
    },
    {
      "name": "tungsten_cmd_banpanel",
      "label": "Cmd Banpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_banpanel:1567234900233552055>",
      "id": "1567234900233552055",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234900233552055.gif"
    },
    {
      "name": "tungsten_cmd_botinfo",
      "label": "Cmd Botinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_botinfo:1567234914867224616>",
      "id": "1567234914867224616",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234914867224616.gif"
    },
    {
      "name": "tungsten_cmd_cases",
      "label": "Cmd Cases",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_cases:1567234927450390658>",
      "id": "1567234927450390658",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234927450390658.gif"
    },
    {
      "name": "tungsten_cmd_celmod",
      "label": "Cmd Celmod",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_celmod:1567234939886370929>",
      "id": "1567234939886370929",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234939886370929.gif"
    },
    {
      "name": "tungsten_cmd_channelinfo",
      "label": "Cmd Channelinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_channelinfo:1567234953803210806>",
      "id": "1567234953803210806",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234953803210806.gif"
    },
    {
      "name": "tungsten_cmd_cleanup",
      "label": "Cmd Cleanup",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_cleanup:1567234967203745988>",
      "id": "1567234967203745988",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234967203745988.gif"
    },
    {
      "name": "tungsten_cmd_clearwarns",
      "label": "Cmd Clearwarns",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_clearwarns:1567234980797612133>",
      "id": "1567234980797612133",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234980797612133.gif"
    },
    {
      "name": "tungsten_cmd_cm",
      "label": "Cmd Cm",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_cm:1567234994768715806>",
      "id": "1567234994768715806",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234994768715806.gif"
    },
    {
      "name": "tungsten_cmd_coinflip",
      "label": "Cmd Coinflip",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_coinflip:1567235008547258368>",
      "id": "1567235008547258368",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235008547258368.gif"
    },
    {
      "name": "tungsten_cmd_componentsv2",
      "label": "Cmd Componentsv2",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_componentsv2:1567235021910315069>",
      "id": "1567235021910315069",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235021910315069.gif"
    },
    {
      "name": "tungsten_cmd_connect4",
      "label": "Cmd Connect4",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_connect4:1567235052243517541>",
      "id": "1567235052243517541",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235052243517541.gif"
    },
    {
      "name": "tungsten_cmd_customcmd",
      "label": "Cmd Customcmd",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_customcmd:1567235065107452015>",
      "id": "1567235065107452015",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235065107452015.gif"
    },
    {
      "name": "tungsten_cmd_customrole",
      "label": "Cmd Customrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_customrole:1567235078654791690>",
      "id": "1567235078654791690",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235078654791690.gif"
    },
    {
      "name": "tungsten_cmd_daily",
      "label": "Cmd Daily",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_daily:1567235093611675650>",
      "id": "1567235093611675650",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235093611675650.gif"
    },
    {
      "name": "tungsten_cmd_database",
      "label": "Cmd Database",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_database:1567235125513687152>",
      "id": "1567235125513687152",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235125513687152.gif"
    },
    {
      "name": "tungsten_cmd_deleteemoji",
      "label": "Cmd Deleteemoji",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_deleteemoji:1567235155574267935>",
      "id": "1567235155574267935",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235155574267935.gif"
    },
    {
      "name": "tungsten_cmd_deposit",
      "label": "Cmd Deposit",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_deposit:1567235175472041994>",
      "id": "1567235175472041994",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235175472041994.gif"
    },
    {
      "name": "tungsten_cmd_duty",
      "label": "Cmd Duty",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_duty:1567235200541528074>",
      "id": "1567235200541528074",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235200541528074.gif"
    },
    {
      "name": "tungsten_cmd_emergency",
      "label": "Cmd Emergency",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emergency:1567235226504134656>",
      "id": "1567235226504134656",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235226504134656.gif"
    },
    {
      "name": "tungsten_cmd_emojilist",
      "label": "Cmd Emojilist",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emojilist:1567235260012298260>",
      "id": "1567235260012298260",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235260012298260.gif"
    },
    {
      "name": "tungsten_cmd_emojipack",
      "label": "Cmd Emojipack",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emojipack:1567235282489839766>",
      "id": "1567235282489839766",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235282489839766.gif"
    },
    {
      "name": "tungsten_cmd_emojiserver",
      "label": "Cmd Emojiserver",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emojiserver:1567235306711818290>",
      "id": "1567235306711818290",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235306711818290.gif"
    },
    {
      "name": "tungsten_cmd_extraowner",
      "label": "Cmd Extraowner",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_extraowner:1567235342850064407>",
      "id": "1567235342850064407",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235342850064407.gif"
    },
    {
      "name": "tungsten_cmd_gif",
      "label": "Cmd Gif",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_gif:1567235366665326693>",
      "id": "1567235366665326693",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235366665326693.gif"
    },
    {
      "name": "tungsten_cmd_giveaway",
      "label": "Cmd Giveaway",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_giveaway:1567235389226352785>",
      "id": "1567235389226352785",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235389226352785.gif"
    },
    {
      "name": "tungsten_cmd_giverole",
      "label": "Cmd Giverole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_giverole:1567235411615678545>",
      "id": "1567235411615678545",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235411615678545.gif"
    },
    {
      "name": "tungsten_cmd_help",
      "label": "Cmd Help",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_help:1567235431567724626>",
      "id": "1567235431567724626",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235431567724626.gif"
    },
    {
      "name": "tungsten_cmd_hide",
      "label": "Cmd Hide",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_hide:1567235456494731295>",
      "id": "1567235456494731295",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235456494731295.gif"
    },
    {
      "name": "tungsten_cmd_inrole",
      "label": "Cmd Inrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_inrole:1567235483904249897>",
      "id": "1567235483904249897",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235483904249897.gif"
    },
    {
      "name": "tungsten_cmd_investigate",
      "label": "Cmd Investigate",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_investigate:1567235510517375127>",
      "id": "1567235510517375127",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235510517375127.gif"
    },
    {
      "name": "tungsten_cmd_invite",
      "label": "Cmd Invite",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_invite:1567235535573885110>",
      "id": "1567235535573885110",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235535573885110.gif"
    },
    {
      "name": "tungsten_cmd_joke",
      "label": "Cmd Joke",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_joke:1567235558705598494>",
      "id": "1567235558705598494",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235558705598494.gif"
    },
    {
      "name": "tungsten_cmd_kick",
      "label": "Cmd Kick",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_kick:1567235578293129256>",
      "id": "1567235578293129256",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235578293129256.gif"
    },
    {
      "name": "tungsten_cmd_kickpanel",
      "label": "Cmd Kickpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_kickpanel:1567235599557984417>",
      "id": "1567235599557984417",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235599557984417.gif"
    },
    {
      "name": "tungsten_cmd_leaderboard",
      "label": "Cmd Leaderboard",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_leaderboard:1567235635331473509>",
      "id": "1567235635331473509",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235635331473509.gif"
    },
    {
      "name": "tungsten_cmd_leave",
      "label": "Cmd Leave",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_leave:1567235657783447573>",
      "id": "1567235657783447573",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235657783447573.gif"
    },
    {
      "name": "tungsten_cmd_levels",
      "label": "Cmd Levels",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_levels:1567235696920371301>",
      "id": "1567235696920371301",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235696920371301.gif"
    },
    {
      "name": "tungsten_cmd_lock",
      "label": "Cmd Lock",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_lock:1567235715983609857>",
      "id": "1567235715983609857",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235715983609857.gif"
    },
    {
      "name": "tungsten_cmd_lockpanel",
      "label": "Cmd Lockpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_lockpanel:1567235752344035459>",
      "id": "1567235752344035459",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235752344035459.gif"
    },
    {
      "name": "tungsten_cmd_membercount",
      "label": "Cmd Membercount",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_membercount:1567235784182857868>",
      "id": "1567235784182857868",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235784182857868.gif"
    },
    {
      "name": "tungsten_cmd_meme",
      "label": "Cmd Meme",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_meme:1567235815833337940>",
      "id": "1567235815833337940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235815833337940.gif"
    },
    {
      "name": "tungsten_cmd_modpanel",
      "label": "Cmd Modpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_modpanel:1567235859063906364>",
      "id": "1567235859063906364",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235859063906364.gif"
    },
    {
      "name": "tungsten_cmd_modrolepanel",
      "label": "Cmd Modrolepanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_modrolepanel:1567235913829056616>",
      "id": "1567235913829056616",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235913829056616.gif"
    },
    {
      "name": "tungsten_cmd_mute",
      "label": "Cmd Mute",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_mute:1567235956644253696>",
      "id": "1567235956644253696",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235956644253696.gif"
    }
  ],
  "6": [
    {
      "name": "tungsten_cmd_mutepanel",
      "label": "Cmd Mutepanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_mutepanel:1567235994359562391>",
      "id": "1567235994359562391",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235994359562391.gif"
    },
    {
      "name": "tungsten_cmd_nightmode",
      "label": "Cmd Nightmode",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_nightmode:1567236036550074390>",
      "id": "1567236036550074390",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236036550074390.gif"
    },
    {
      "name": "tungsten_cmd_noprefix",
      "label": "Cmd Noprefix",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_noprefix:1567236069643132972>",
      "id": "1567236069643132972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236069643132972.gif"
    },
    {
      "name": "tungsten_cmd_npmanager",
      "label": "Cmd Npmanager",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_npmanager:1567236115197591596>",
      "id": "1567236115197591596",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236115197591596.gif"
    },
    {
      "name": "tungsten_cmd_nuke",
      "label": "Cmd Nuke",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_nuke:1567236137746169887>",
      "id": "1567236137746169887",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236137746169887.gif"
    },
    {
      "name": "tungsten_cmd_ownerpanel",
      "label": "Cmd Ownerpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ownerpanel:1567236155634622514>",
      "id": "1567236155634622514",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236155634622514.gif"
    },
    {
      "name": "tungsten_cmd_panel",
      "label": "Cmd Panel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_panel:1567236187700338759>",
      "id": "1567236187700338759",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236187700338759.gif"
    },
    {
      "name": "tungsten_cmd_panic",
      "label": "Cmd Panic",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_panic:1567236213897822388>",
      "id": "1567236213897822388",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236213897822388.gif"
    },
    {
      "name": "tungsten_cmd_pay",
      "label": "Cmd Pay",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_pay:1567236244205867130>",
      "id": "1567236244205867130",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236244205867130.gif"
    },
    {
      "name": "tungsten_cmd_ping",
      "label": "Cmd Ping",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ping:1567236300271255715>",
      "id": "1567236300271255715",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236300271255715.gif"
    },
    {
      "name": "tungsten_cmd_pings",
      "label": "Cmd Pings",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_pings:1567236330038235206>",
      "id": "1567236330038235206",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236330038235206.gif"
    },
    {
      "name": "tungsten_cmd_prefix",
      "label": "Cmd Prefix",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_prefix:1567236353924792524>",
      "id": "1567236353924792524",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236353924792524.gif"
    },
    {
      "name": "tungsten_cmd_premium",
      "label": "Cmd Premium",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_premium:1567236385734139966>",
      "id": "1567236385734139966",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236385734139966.gif"
    },
    {
      "name": "tungsten_cmd_premiummanager",
      "label": "Cmd Premiummanager",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_premiummanager:1567236418634252458>",
      "id": "1567236418634252458",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236418634252458.gif"
    },
    {
      "name": "tungsten_cmd_profile",
      "label": "Cmd Profile",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_profile:1567236443917525154>",
      "id": "1567236443917525154",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236443917525154.gif"
    },
    {
      "name": "tungsten_cmd_purge",
      "label": "Cmd Purge",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_purge:1567236474280083516>",
      "id": "1567236474280083516",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236474280083516.gif"
    },
    {
      "name": "tungsten_cmd_purgepanel",
      "label": "Cmd Purgepanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_purgepanel:1567236525425430749>",
      "id": "1567236525425430749",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236525425430749.gif"
    },
    {
      "name": "tungsten_cmd_reactionrole",
      "label": "Cmd Reactionrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_reactionrole:1567236559248429167>",
      "id": "1567236559248429167",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236559248429167.gif"
    },
    {
      "name": "tungsten_cmd_removerole",
      "label": "Cmd Removerole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_removerole:1567236636641599548>",
      "id": "1567236636641599548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236636641599548.gif"
    },
    {
      "name": "tungsten_cmd_rob",
      "label": "Cmd Rob",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_rob:1567236704203571431>",
      "id": "1567236704203571431",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236704203571431.gif"
    },
    {
      "name": "tungsten_cmd_roleinfo",
      "label": "Cmd Roleinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_roleinfo:1567236816225046629>",
      "id": "1567236816225046629",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236816225046629.gif"
    },
    {
      "name": "tungsten_cmd_roll",
      "label": "Cmd Roll",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_roll:1567236993287725196>",
      "id": "1567236993287725196",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236993287725196.gif"
    },
    {
      "name": "tungsten_cmd_rps",
      "label": "Cmd Rps",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_rps:1567237016662577224>",
      "id": "1567237016662577224",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237016662577224.gif"
    },
    {
      "name": "tungsten_cmd_securityscore",
      "label": "Cmd Securityscore",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_securityscore:1567237039135400067>",
      "id": "1567237039135400067",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237039135400067.gif"
    },
    {
      "name": "tungsten_cmd_serverinfo",
      "label": "Cmd Serverinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_serverinfo:1567237069502287923>",
      "id": "1567237069502287923",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237069502287923.gif"
    },
    {
      "name": "tungsten_cmd_sethomevc",
      "label": "Cmd Sethomevc",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_sethomevc:1567237101341380720>",
      "id": "1567237101341380720",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237101341380720.gif"
    },
    {
      "name": "tungsten_cmd_ship",
      "label": "Cmd Ship",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ship:1567237143049539777>",
      "id": "1567237143049539777",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237143049539777.gif"
    },
    {
      "name": "tungsten_cmd_slots",
      "label": "Cmd Slots",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_slots:1567237210565120220>",
      "id": "1567237210565120220",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237210565120220.gif"
    },
    {
      "name": "tungsten_cmd_slowmode",
      "label": "Cmd Slowmode",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_slowmode:1567237253061804164>",
      "id": "1567237253061804164",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237253061804164.gif"
    },
    {
      "name": "tungsten_cmd_snipe",
      "label": "Cmd Snipe",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_snipe:1567237311106777210>",
      "id": "1567237311106777210",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237311106777210.gif"
    },
    {
      "name": "tungsten_cmd_softban",
      "label": "Cmd Softban",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_softban:1567237338374086719>",
      "id": "1567237338374086719",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237338374086719.gif"
    },
    {
      "name": "tungsten_cmd_stats",
      "label": "Cmd Stats",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_stats:1567237361664925757>",
      "id": "1567237361664925757",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237361664925757.gif"
    },
    {
      "name": "tungsten_cmd_stickymessage",
      "label": "Cmd Stickymessage",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_stickymessage:1567237387925454968>",
      "id": "1567237387925454968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237387925454968.gif"
    },
    {
      "name": "tungsten_cmd_support",
      "label": "Cmd Support",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_support:1567237424843591770>",
      "id": "1567237424843591770",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237424843591770.gif"
    },
    {
      "name": "tungsten_cmd_ticket",
      "label": "Cmd Ticket",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ticket:1567237476173619345>",
      "id": "1567237476173619345",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237476173619345.gif"
    },
    {
      "name": "tungsten_cmd_trivia",
      "label": "Cmd Trivia",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_trivia:1567237570192998610>",
      "id": "1567237570192998610",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237570192998610.gif"
    },
    {
      "name": "tungsten_cmd_unban",
      "label": "Cmd Unban",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unban:1567237654230208743>",
      "id": "1567237654230208743",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237654230208743.gif"
    },
    {
      "name": "tungsten_cmd_unhide",
      "label": "Cmd Unhide",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unhide:1567237716330946600>",
      "id": "1567237716330946600",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237716330946600.gif"
    },
    {
      "name": "tungsten_cmd_unlock",
      "label": "Cmd Unlock",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unlock:1567237734299467886>",
      "id": "1567237734299467886",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237734299467886.gif"
    },
    {
      "name": "tungsten_cmd_unmute",
      "label": "Cmd Unmute",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unmute:1567237746697961612>",
      "id": "1567237746697961612",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237746697961612.gif"
    },
    {
      "name": "tungsten_cmd_unwhitelist",
      "label": "Cmd Unwhitelist",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unwhitelist:1567237762376273990>",
      "id": "1567237762376273990",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237762376273990.gif"
    },
    {
      "name": "tungsten_cmd_uptime",
      "label": "Cmd Uptime",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_uptime:1567237782605398036>",
      "id": "1567237782605398036",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237782605398036.gif"
    },
    {
      "name": "tungsten_cmd_userinfo",
      "label": "Cmd Userinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_userinfo:1567237805266964481>",
      "id": "1567237805266964481",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237805266964481.gif"
    },
    {
      "name": "tungsten_cmd_vanityguard",
      "label": "Cmd Vanityguard",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_vanityguard:1567237826154602613>",
      "id": "1567237826154602613",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237826154602613.gif"
    },
    {
      "name": "tungsten_cmd_vcrole",
      "label": "Cmd Vcrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_vcrole:1567237847486832640>",
      "id": "1567237847486832640",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237847486832640.gif"
    },
    {
      "name": "tungsten_cmd_vcstatus",
      "label": "Cmd Vcstatus",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_vcstatus:1567237869133635628>",
      "id": "1567237869133635628",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237869133635628.gif"
    },
    {
      "name": "tungsten_cmd_voice",
      "label": "Cmd Voice",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_voice:1567237893590753360>",
      "id": "1567237893590753360",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237893590753360.gif"
    }
  ],
  "7": [
    {
      "name": "tungsten_cmd_voicemod",
      "label": "Cmd Voicemod",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_voicemod:1567237946053099530>",
      "id": "1567237946053099530",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237946053099530.gif"
    },
    {
      "name": "tungsten_cmd_warn",
      "label": "Cmd Warn",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_warn:1567238033705799771>",
      "id": "1567238033705799771",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238033705799771.gif"
    },
    {
      "name": "tungsten_cmd_warnings",
      "label": "Cmd Warnings",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_warnings:1567238062759739435>",
      "id": "1567238062759739435",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238062759739435.gif"
    },
    {
      "name": "tungsten_cmd_warnpanel",
      "label": "Cmd Warnpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_warnpanel:1567238091708702792>",
      "id": "1567238091708702792",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238091708702792.gif"
    },
    {
      "name": "tungsten_cmd_welcome",
      "label": "Cmd Welcome",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_welcome:1567238123807842346>",
      "id": "1567238123807842346",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238123807842346.gif"
    },
    {
      "name": "tungsten_cmd_whitelist",
      "label": "Cmd Whitelist",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_whitelist:1567238164991451146>",
      "id": "1567238164991451146",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238164991451146.gif"
    },
    {
      "name": "tungsten_cmd_whitelisted",
      "label": "Cmd Whitelisted",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_whitelisted:1567238207295455329>",
      "id": "1567238207295455329",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238207295455329.gif"
    },
    {
      "name": "tungsten_cmd_withdraw",
      "label": "Cmd Withdraw",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_withdraw:1567238237108310077>",
      "id": "1567238237108310077",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238237108310077.gif"
    },
    {
      "name": "tungsten_cmd_work",
      "label": "Cmd Work",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_work:1567238276161601567>",
      "id": "1567238276161601567",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238276161601567.gif"
    },
    {
      "name": "tungsten_coin",
      "label": "Coin",
      "animated": true,
      "discordTag": "<a:tungsten_coin:1567238316967985244>",
      "id": "1567238316967985244",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238316967985244.gif"
    },
    {
      "name": "tungsten_crown",
      "label": "Crown",
      "animated": true,
      "discordTag": "<a:tungsten_crown:1567238355463176334>",
      "id": "1567238355463176334",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238355463176334.gif"
    },
    {
      "name": "tungsten_crystal",
      "label": "Crystal",
      "animated": true,
      "discordTag": "<a:tungsten_crystal:1567238398400532571>",
      "id": "1567238398400532571",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238398400532571.gif"
    },
    {
      "name": "tungsten_dancer",
      "label": "Dancer",
      "animated": true,
      "discordTag": "<a:tungsten_dancer:1567238442092601424>",
      "id": "1567238442092601424",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238442092601424.gif"
    },
    {
      "name": "tungsten_database",
      "label": "Database",
      "animated": true,
      "discordTag": "<a:tungsten_database:1567238475684651168>",
      "id": "1567238475684651168",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238475684651168.gif"
    },
    {
      "name": "tungsten_diamond_small",
      "label": "Diamond Small",
      "animated": true,
      "discordTag": "<a:tungsten_diamond_small:1567238516855939283>",
      "id": "1567238516855939283",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238516855939283.gif"
    },
    {
      "name": "tungsten_dice",
      "label": "Dice",
      "animated": true,
      "discordTag": "<a:tungsten_dice:1567238580827328582>",
      "id": "1567238580827328582",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238580827328582.gif"
    },
    {
      "name": "tungsten_door",
      "label": "Door",
      "animated": true,
      "discordTag": "<a:tungsten_door:1567238621432643794>",
      "id": "1567238621432643794",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238621432643794.gif"
    },
    {
      "name": "tungsten_drama",
      "label": "Drama",
      "animated": true,
      "discordTag": "<a:tungsten_drama:1567238681557991474>",
      "id": "1567238681557991474",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238681557991474.gif"
    },
    {
      "name": "tungsten_eightball",
      "label": "Eightball",
      "animated": true,
      "discordTag": "<a:tungsten_eightball:1567238723995967638>",
      "id": "1567238723995967638",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238723995967638.gif"
    },
    {
      "name": "tungsten_error",
      "label": "Error",
      "animated": true,
      "discordTag": "<a:tungsten_error:1567238753284653106>",
      "id": "1567238753284653106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238753284653106.gif"
    },
    {
      "name": "tungsten_explosion",
      "label": "Explosion",
      "animated": true,
      "discordTag": "<a:tungsten_explosion:1567238834343911554>",
      "id": "1567238834343911554",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238834343911554.gif"
    },
    {
      "name": "tungsten_eye",
      "label": "Eye",
      "animated": true,
      "discordTag": "<a:tungsten_eye:1567238862042833088>",
      "id": "1567238862042833088",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238862042833088.gif"
    },
    {
      "name": "tungsten_eye_slash",
      "label": "Eye Slash",
      "animated": true,
      "discordTag": "<a:tungsten_eye_slash:1567238896612282430>",
      "id": "1567238896612282430",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238896612282430.gif"
    },
    {
      "name": "tungsten_eyes",
      "label": "Eyes",
      "animated": true,
      "discordTag": "<a:tungsten_eyes:1567238923913011254>",
      "id": "1567238923913011254",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238923913011254.gif"
    },
    {
      "name": "tungsten_face_angry",
      "label": "Face Angry",
      "animated": true,
      "discordTag": "<a:tungsten_face_angry:1567238949284618291>",
      "id": "1567238949284618291",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238949284618291.gif"
    },
    {
      "name": "tungsten_face_cool",
      "label": "Face Cool",
      "animated": true,
      "discordTag": "<a:tungsten_face_cool:1567238977264685118>",
      "id": "1567238977264685118",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238977264685118.gif"
    },
    {
      "name": "tungsten_face_crazy",
      "label": "Face Crazy",
      "animated": true,
      "discordTag": "<a:tungsten_face_crazy:1567239007463669832>",
      "id": "1567239007463669832",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239007463669832.gif"
    },
    {
      "name": "tungsten_face_cry",
      "label": "Face Cry",
      "animated": true,
      "discordTag": "<a:tungsten_face_cry:1567239031735980053>",
      "id": "1567239031735980053",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239031735980053.gif"
    },
    {
      "name": "tungsten_face_devil",
      "label": "Face Devil",
      "animated": true,
      "discordTag": "<a:tungsten_face_devil:1567239058327871564>",
      "id": "1567239058327871564",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239058327871564.gif"
    },
    {
      "name": "tungsten_face_flushed",
      "label": "Face Flushed",
      "animated": true,
      "discordTag": "<a:tungsten_face_flushed:1567239086484357130>",
      "id": "1567239086484357130",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239086484357130.gif"
    },
    {
      "name": "tungsten_face_grin",
      "label": "Face Grin",
      "animated": true,
      "discordTag": "<a:tungsten_face_grin:1567239115089514536>",
      "id": "1567239115089514536",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239115089514536.gif"
    },
    {
      "name": "tungsten_face_laugh",
      "label": "Face Laugh",
      "animated": true,
      "discordTag": "<a:tungsten_face_laugh:1567239143048613900>",
      "id": "1567239143048613900",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239143048613900.gif"
    },
    {
      "name": "tungsten_face_love",
      "label": "Face Love",
      "animated": true,
      "discordTag": "<a:tungsten_face_love:1567239175110140056>",
      "id": "1567239175110140056",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239175110140056.gif"
    },
    {
      "name": "tungsten_face_melting",
      "label": "Face Melting",
      "animated": true,
      "discordTag": "<a:tungsten_face_melting:1567239201269743827>",
      "id": "1567239201269743827",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239201269743827.gif"
    },
    {
      "name": "tungsten_face_pleading",
      "label": "Face Pleading",
      "animated": true,
      "discordTag": "<a:tungsten_face_pleading:1567239233788448939>",
      "id": "1567239233788448939",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239233788448939.gif"
    },
    {
      "name": "tungsten_face_scared",
      "label": "Face Scared",
      "animated": true,
      "discordTag": "<a:tungsten_face_scared:1567239267774763038>",
      "id": "1567239267774763038",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239267774763038.gif"
    },
    {
      "name": "tungsten_face_sleep",
      "label": "Face Sleep",
      "animated": true,
      "discordTag": "<a:tungsten_face_sleep:1567239295914213548>",
      "id": "1567239295914213548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239295914213548.gif"
    },
    {
      "name": "tungsten_face_smile",
      "label": "Face Smile",
      "animated": true,
      "discordTag": "<a:tungsten_face_smile:1567239325941375126>",
      "id": "1567239325941375126",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239325941375126.gif"
    },
    {
      "name": "tungsten_face_surprised",
      "label": "Face Surprised",
      "animated": true,
      "discordTag": "<a:tungsten_face_surprised:1567239358975582248>",
      "id": "1567239358975582248",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239358975582248.gif"
    },
    {
      "name": "tungsten_face_wink",
      "label": "Face Wink",
      "animated": true,
      "discordTag": "<a:tungsten_face_wink:1567239380244897846>",
      "id": "1567239380244897846",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239380244897846.gif"
    },
    {
      "name": "tungsten_fist",
      "label": "Fist",
      "animated": true,
      "discordTag": "<a:tungsten_fist:1567239431444897892>",
      "id": "1567239431444897892",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239431444897892.gif"
    },
    {
      "name": "tungsten_flag_chequered",
      "label": "Flag Chequered",
      "animated": true,
      "discordTag": "<a:tungsten_flag_chequered:1567239507135307972>",
      "id": "1567239507135307972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239507135307972.gif"
    },
    {
      "name": "tungsten_flag_white",
      "label": "Flag White",
      "animated": true,
      "discordTag": "<a:tungsten_flag_white:1567239547769589771>",
      "id": "1567239547769589771",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239547769589771.gif"
    },
    {
      "name": "tungsten_folder",
      "label": "Folder",
      "animated": true,
      "discordTag": "<a:tungsten_folder:1567239623145558046>",
      "id": "1567239623145558046",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239623145558046.gif"
    },
    {
      "name": "tungsten_folder_open",
      "label": "Folder Open",
      "animated": true,
      "discordTag": "<a:tungsten_folder_open:1567239652501495988>",
      "id": "1567239652501495988",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239652501495988.gif"
    },
    {
      "name": "tungsten_foot",
      "label": "Foot",
      "animated": true,
      "discordTag": "<a:tungsten_foot:1567239740942458880>",
      "id": "1567239740942458880",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239740942458880.gif"
    },
    {
      "name": "tungsten_frame",
      "label": "Frame",
      "animated": true,
      "discordTag": "<a:tungsten_frame:1567239867983863889>",
      "id": "1567239867983863889",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239867983863889.gif"
    }
  ],
  "8": [
    {
      "name": "tungsten_gamepad",
      "label": "Gamepad",
      "animated": true,
      "discordTag": "<a:tungsten_gamepad:1567239909985616063>",
      "id": "1567239909985616063",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239909985616063.gif"
    },
    {
      "name": "tungsten_gear",
      "label": "Gear",
      "animated": true,
      "discordTag": "<a:tungsten_gear:1567239932970406012>",
      "id": "1567239932970406012",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239932970406012.gif"
    },
    {
      "name": "tungsten_gem",
      "label": "Gem",
      "animated": true,
      "discordTag": "<a:tungsten_gem:1567239960837357759>",
      "id": "1567239960837357759",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239960837357759.gif"
    },
    {
      "name": "tungsten_gem_flower",
      "label": "Gem Flower",
      "animated": true,
      "discordTag": "<a:tungsten_gem_flower:1567239998779031595>",
      "id": "1567239998779031595",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239998779031595.gif"
    },
    {
      "name": "tungsten_ghost",
      "label": "Ghost",
      "animated": true,
      "discordTag": "<a:tungsten_ghost:1567240021692518512>",
      "id": "1567240021692518512",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240021692518512.gif"
    },
    {
      "name": "tungsten_gift",
      "label": "Gift",
      "animated": true,
      "discordTag": "<a:tungsten_gift:1567240042563244072>",
      "id": "1567240042563244072",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240042563244072.gif"
    },
    {
      "name": "tungsten_globe",
      "label": "Globe",
      "animated": true,
      "discordTag": "<a:tungsten_globe:1567240068253622433>",
      "id": "1567240068253622433",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240068253622433.gif"
    },
    {
      "name": "tungsten_grapes",
      "label": "Grapes",
      "animated": true,
      "discordTag": "<a:tungsten_grapes:1567240092739833866>",
      "id": "1567240092739833866",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240092739833866.gif"
    },
    {
      "name": "tungsten_gun",
      "label": "Gun",
      "animated": true,
      "discordTag": "<a:tungsten_gun:1567240119612874822>",
      "id": "1567240119612874822",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240119612874822.gif"
    },
    {
      "name": "tungsten_hammer",
      "label": "Hammer",
      "animated": true,
      "discordTag": "<a:tungsten_hammer:1567240140277944350>",
      "id": "1567240140277944350",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240140277944350.gif"
    },
    {
      "name": "tungsten_hands_up",
      "label": "Hands Up",
      "animated": true,
      "discordTag": "<a:tungsten_hands_up:1567240175594250302>",
      "id": "1567240175594250302",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240175594250302.gif"
    },
    {
      "name": "tungsten_handshake",
      "label": "Handshake",
      "animated": true,
      "discordTag": "<a:tungsten_handshake:1567240195646951494>",
      "id": "1567240195646951494",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240195646951494.gif"
    },
    {
      "name": "tungsten_headphones",
      "label": "Headphones",
      "animated": true,
      "discordTag": "<a:tungsten_headphones:1567240226789785730>",
      "id": "1567240226789785730",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240226789785730.gif"
    },
    {
      "name": "tungsten_heart",
      "label": "Heart",
      "animated": true,
      "discordTag": "<a:tungsten_heart:1567240255680155718>",
      "id": "1567240255680155718",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240255680155718.gif"
    },
    {
      "name": "tungsten_heart_broken",
      "label": "Heart Broken",
      "animated": true,
      "discordTag": "<a:tungsten_heart_broken:1567240285053001738>",
      "id": "1567240285053001738",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240285053001738.gif"
    },
    {
      "name": "tungsten_heart_orange",
      "label": "Heart Orange",
      "animated": true,
      "discordTag": "<a:tungsten_heart_orange:1567240324336582743>",
      "id": "1567240324336582743",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240324336582743.gif"
    },
    {
      "name": "tungsten_heart_sparkle",
      "label": "Heart Sparkle",
      "animated": true,
      "discordTag": "<a:tungsten_heart_sparkle:1567240386659885106>",
      "id": "1567240386659885106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240386659885106.gif"
    },
    {
      "name": "tungsten_heart_yellow",
      "label": "Heart Yellow",
      "animated": true,
      "discordTag": "<a:tungsten_heart_yellow:1567240422068068529>",
      "id": "1567240422068068529",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240422068068529.gif"
    },
    {
      "name": "tungsten_hearts",
      "label": "Hearts",
      "animated": true,
      "discordTag": "<a:tungsten_hearts:1567240511670976552>",
      "id": "1567240511670976552",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240511670976552.gif"
    },
    {
      "name": "tungsten_home",
      "label": "Home",
      "animated": true,
      "discordTag": "<a:tungsten_home:1567240545661620387>",
      "id": "1567240545661620387",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240545661620387.gif"
    },
    {
      "name": "tungsten_hourglass",
      "label": "Hourglass",
      "animated": true,
      "discordTag": "<a:tungsten_hourglass:1567240660702986281>",
      "id": "1567240660702986281",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240660702986281.gif"
    },
    {
      "name": "tungsten_id",
      "label": "Id",
      "animated": true,
      "discordTag": "<a:tungsten_id:1567240689048355008>",
      "id": "1567240689048355008",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240689048355008.gif"
    },
    {
      "name": "tungsten_inbox",
      "label": "Inbox",
      "animated": true,
      "discordTag": "<a:tungsten_inbox:1567240785219289108>",
      "id": "1567240785219289108",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240785219289108.gif"
    },
    {
      "name": "tungsten_infinity",
      "label": "Infinity",
      "animated": true,
      "discordTag": "<a:tungsten_infinity:1567240813895745626>",
      "id": "1567240813895745626",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240813895745626.gif"
    },
    {
      "name": "tungsten_info",
      "label": "Info",
      "animated": true,
      "discordTag": "<a:tungsten_info:1567240890748248084>",
      "id": "1567240890748248084",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240890748248084.gif"
    },
    {
      "name": "tungsten_key",
      "label": "Key",
      "animated": true,
      "discordTag": "<a:tungsten_key:1567240907684581492>",
      "id": "1567240907684581492",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240907684581492.gif"
    },
    {
      "name": "tungsten_keycap_ten",
      "label": "Keycap Ten",
      "animated": true,
      "discordTag": "<a:tungsten_keycap_ten:1567240934599688303>",
      "id": "1567240934599688303",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240934599688303.gif"
    },
    {
      "name": "tungsten_keylock",
      "label": "Keylock",
      "animated": true,
      "discordTag": "<a:tungsten_keylock:1567240958075084951>",
      "id": "1567240958075084951",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240958075084951.gif"
    },
    {
      "name": "tungsten_knife",
      "label": "Knife",
      "animated": true,
      "discordTag": "<a:tungsten_knife:1567240975758270495>",
      "id": "1567240975758270495",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240975758270495.gif"
    },
    {
      "name": "tungsten_lemon",
      "label": "Lemon",
      "animated": true,
      "discordTag": "<a:tungsten_lemon:1567240998231343184>",
      "id": "1567240998231343184",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240998231343184.gif"
    },
    {
      "name": "tungsten_link",
      "label": "Link",
      "animated": true,
      "discordTag": "<a:tungsten_link:1567241025813086210>",
      "id": "1567241025813086210",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241025813086210.gif"
    },
    {
      "name": "tungsten_loading",
      "label": "Loading",
      "animated": true,
      "discordTag": "<a:tungsten_loading:1567241050567876698>",
      "id": "1567241050567876698",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241050567876698.gif"
    },
    {
      "name": "tungsten_lock",
      "label": "Lock",
      "animated": true,
      "discordTag": "<a:tungsten_lock:1567241079030550668>",
      "id": "1567241079030550668",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241079030550668.gif"
    },
    {
      "name": "tungsten_mailbox",
      "label": "Mailbox",
      "animated": true,
      "discordTag": "<a:tungsten_mailbox:1567241098009509949>",
      "id": "1567241098009509949",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241098009509949.gif"
    },
    {
      "name": "tungsten_medal_bronze",
      "label": "Medal Bronze",
      "animated": true,
      "discordTag": "<a:tungsten_medal_bronze:1567241129030582403>",
      "id": "1567241129030582403",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241129030582403.gif"
    },
    {
      "name": "tungsten_medal_gold",
      "label": "Medal Gold",
      "animated": true,
      "discordTag": "<a:tungsten_medal_gold:1567241163453366472>",
      "id": "1567241163453366472",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241163453366472.gif"
    },
    {
      "name": "tungsten_medal_silver",
      "label": "Medal Silver",
      "animated": true,
      "discordTag": "<a:tungsten_medal_silver:1567241205409128649>",
      "id": "1567241205409128649",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241205409128649.gif"
    },
    {
      "name": "tungsten_memo",
      "label": "Memo",
      "animated": true,
      "discordTag": "<a:tungsten_memo:1567241226577780957>",
      "id": "1567241226577780957",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241226577780957.gif"
    },
    {
      "name": "tungsten_mic",
      "label": "Mic",
      "animated": true,
      "discordTag": "<a:tungsten_mic:1567241257862832189>",
      "id": "1567241257862832189",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241257862832189.gif"
    },
    {
      "name": "tungsten_minus",
      "label": "Minus",
      "animated": true,
      "discordTag": "<a:tungsten_minus:1567241276057849856>",
      "id": "1567241276057849856",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241276057849856.gif"
    },
    {
      "name": "tungsten_money_wings",
      "label": "Money Wings",
      "animated": true,
      "discordTag": "<a:tungsten_money_wings:1567241294408061024>",
      "id": "1567241294408061024",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241294408061024.gif"
    },
    {
      "name": "tungsten_moneybag",
      "label": "Moneybag",
      "animated": true,
      "discordTag": "<a:tungsten_moneybag:1567241334698541109>",
      "id": "1567241334698541109",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241334698541109.gif"
    },
    {
      "name": "tungsten_monitor",
      "label": "Monitor",
      "animated": true,
      "discordTag": "<a:tungsten_monitor:1567241360984121485>",
      "id": "1567241360984121485",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241360984121485.gif"
    },
    {
      "name": "tungsten_moon",
      "label": "Moon",
      "animated": true,
      "discordTag": "<a:tungsten_moon:1567241385021673674>",
      "id": "1567241385021673674",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241385021673674.gif"
    },
    {
      "name": "tungsten_music",
      "label": "Music",
      "animated": true,
      "discordTag": "<a:tungsten_music:1567241425328939110>",
      "id": "1567241425328939110",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241425328939110.gif"
    },
    {
      "name": "tungsten_mute",
      "label": "Mute",
      "animated": true,
      "discordTag": "<a:tungsten_mute:1567241451992121647>",
      "id": "1567241451992121647",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241451992121647.gif"
    },
    {
      "name": "tungsten_nametag",
      "label": "Nametag",
      "animated": true,
      "discordTag": "<a:tungsten_nametag:1567241539082526760>",
      "id": "1567241539082526760",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241539082526760.gif"
    }
  ],
  "9": [
    {
      "name": "tungsten_ninja",
      "label": "Ninja",
      "animated": true,
      "discordTag": "<a:tungsten_ninja:1567241598260093050>",
      "id": "1567241598260093050",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241598260093050.gif"
    },
    {
      "name": "tungsten_notepad",
      "label": "Notepad",
      "animated": true,
      "discordTag": "<a:tungsten_notepad:1567241681911152733>",
      "id": "1567241681911152733",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241681911152733.gif"
    },
    {
      "name": "tungsten_package",
      "label": "Package",
      "animated": true,
      "discordTag": "<a:tungsten_package:1567241719177543862>",
      "id": "1567241719177543862",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241719177543862.gif"
    },
    {
      "name": "tungsten_palette",
      "label": "Palette",
      "animated": true,
      "discordTag": "<a:tungsten_palette:1567241748613169344>",
      "id": "1567241748613169344",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241748613169344.gif"
    },
    {
      "name": "tungsten_party",
      "label": "Party",
      "animated": true,
      "discordTag": "<a:tungsten_party:1567241769593339988>",
      "id": "1567241769593339988",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241769593339988.gif"
    },
    {
      "name": "tungsten_person",
      "label": "Person",
      "animated": true,
      "discordTag": "<a:tungsten_person:1567241792150175834>",
      "id": "1567241792150175834",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241792150175834.gif"
    },
    {
      "name": "tungsten_pin",
      "label": "Pin",
      "animated": true,
      "discordTag": "<a:tungsten_pin:1567241810114379987>",
      "id": "1567241810114379987",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241810114379987.gif"
    },
    {
      "name": "tungsten_plane",
      "label": "Plane",
      "animated": true,
      "discordTag": "<a:tungsten_plane:1567241829538336884>",
      "id": "1567241829538336884",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241829538336884.gif"
    },
    {
      "name": "tungsten_plus",
      "label": "Plus",
      "animated": true,
      "discordTag": "<a:tungsten_plus:1567241846453833840>",
      "id": "1567241846453833840",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241846453833840.gif"
    },
    {
      "name": "tungsten_point",
      "label": "Point",
      "animated": true,
      "discordTag": "<a:tungsten_point:1567241861293408391>",
      "id": "1567241861293408391",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241861293408391.gif"
    },
    {
      "name": "tungsten_question",
      "label": "Question",
      "animated": true,
      "discordTag": "<a:tungsten_question:1567241882080116776>",
      "id": "1567241882080116776",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241882080116776.gif"
    },
    {
      "name": "tungsten_refresh",
      "label": "Refresh",
      "animated": true,
      "discordTag": "<a:tungsten_refresh:1567241907116187658>",
      "id": "1567241907116187658",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241907116187658.gif"
    },
    {
      "name": "tungsten_rice",
      "label": "Rice",
      "animated": true,
      "discordTag": "<a:tungsten_rice:1567241928603336724>",
      "id": "1567241928603336724",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241928603336724.gif"
    },
    {
      "name": "tungsten_ring",
      "label": "Ring",
      "animated": true,
      "discordTag": "<a:tungsten_ring:1567241949461618768>",
      "id": "1567241949461618768",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241949461618768.gif"
    },
    {
      "name": "tungsten_rocket",
      "label": "Rocket",
      "animated": true,
      "discordTag": "<a:tungsten_rocket:1567241971804798976>",
      "id": "1567241971804798976",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241971804798976.gif"
    },
    {
      "name": "tungsten_satellite",
      "label": "Satellite",
      "animated": true,
      "discordTag": "<a:tungsten_satellite:1567241994928005137>",
      "id": "1567241994928005137",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241994928005137.gif"
    },
    {
      "name": "tungsten_save",
      "label": "Save",
      "animated": true,
      "discordTag": "<a:tungsten_save:1567242015283085507>",
      "id": "1567242015283085507",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242015283085507.gif"
    },
    {
      "name": "tungsten_scales",
      "label": "Scales",
      "animated": true,
      "discordTag": "<a:tungsten_scales:1567242041098895521>",
      "id": "1567242041098895521",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242041098895521.gif"
    },
    {
      "name": "tungsten_scroll",
      "label": "Scroll",
      "animated": true,
      "discordTag": "<a:tungsten_scroll:1567242059708899381>",
      "id": "1567242059708899381",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242059708899381.gif"
    },
    {
      "name": "tungsten_search",
      "label": "Search",
      "animated": true,
      "discordTag": "<a:tungsten_search:1567242081167216771>",
      "id": "1567242081167216771",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242081167216771.gif"
    },
    {
      "name": "tungsten_shield",
      "label": "Shield",
      "animated": true,
      "discordTag": "<a:tungsten_shield:1567242104923627574>",
      "id": "1567242104923627574",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242104923627574.gif"
    },
    {
      "name": "tungsten_shrug",
      "label": "Shrug",
      "animated": true,
      "discordTag": "<a:tungsten_shrug:1567242138323001384>",
      "id": "1567242138323001384",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242138323001384.gif"
    },
    {
      "name": "tungsten_siren",
      "label": "Siren",
      "animated": true,
      "discordTag": "<a:tungsten_siren:1567242157725712555>",
      "id": "1567242157725712555",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242157725712555.gif"
    },
    {
      "name": "tungsten_skull",
      "label": "Skull",
      "animated": true,
      "discordTag": "<a:tungsten_skull:1567242182836883486>",
      "id": "1567242182836883486",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242182836883486.gif"
    },
    {
      "name": "tungsten_slots",
      "label": "Slots",
      "animated": true,
      "discordTag": "<a:tungsten_slots:1567242206266527956>",
      "id": "1567242206266527956",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242206266527956.gif"
    },
    {
      "name": "tungsten_sound",
      "label": "Sound",
      "animated": true,
      "discordTag": "<a:tungsten_sound:1567242242127568958>",
      "id": "1567242242127568958",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242242127568958.gif"
    },
    {
      "name": "tungsten_sparkle",
      "label": "Sparkle",
      "animated": true,
      "discordTag": "<a:tungsten_sparkle:1567242264311369839>",
      "id": "1567242264311369839",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242264311369839.gif"
    },
    {
      "name": "tungsten_star",
      "label": "Star",
      "animated": true,
      "discordTag": "<a:tungsten_star:1567242331785138238>",
      "id": "1567242331785138238",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242331785138238.gif"
    },
    {
      "name": "tungsten_stop",
      "label": "Stop",
      "animated": true,
      "discordTag": "<a:tungsten_stop:1567242365335511121>",
      "id": "1567242365335511121",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242365335511121.gif"
    },
    {
      "name": "tungsten_stopwatch",
      "label": "Stopwatch",
      "animated": true,
      "discordTag": "<a:tungsten_stopwatch:1567242453562687558>",
      "id": "1567242453562687558",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242453562687558.gif"
    },
    {
      "name": "tungsten_success",
      "label": "Success",
      "animated": true,
      "discordTag": "<a:tungsten_success:1567242523468890274>",
      "id": "1567242523468890274",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242523468890274.gif"
    },
    {
      "name": "tungsten_sun",
      "label": "Sun",
      "animated": true,
      "discordTag": "<a:tungsten_sun:1567242622701932604>",
      "id": "1567242622701932604",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242622701932604.gif"
    },
    {
      "name": "tungsten_sweep",
      "label": "Sweep",
      "animated": true,
      "discordTag": "<a:tungsten_sweep:1567242656281657414>",
      "id": "1567242656281657414",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242656281657414.gif"
    },
    {
      "name": "tungsten_swords",
      "label": "Swords",
      "animated": true,
      "discordTag": "<a:tungsten_swords:1567242677819277352>",
      "id": "1567242677819277352",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242677819277352.gif"
    },
    {
      "name": "tungsten_tag",
      "label": "Tag",
      "animated": true,
      "discordTag": "<a:tungsten_tag:1567242698904047691>",
      "id": "1567242698904047691",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242698904047691.gif"
    },
    {
      "name": "tungsten_target",
      "label": "Target",
      "animated": true,
      "discordTag": "<a:tungsten_target:1567242733997789205>",
      "id": "1567242733997789205",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242733997789205.gif"
    },
    {
      "name": "tungsten_terminal",
      "label": "Terminal",
      "animated": true,
      "discordTag": "<a:tungsten_terminal:1567242755040878664>",
      "id": "1567242755040878664",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242755040878664.gif"
    },
    {
      "name": "tungsten_tick",
      "label": "Tick",
      "animated": true,
      "discordTag": "<a:tungsten_tick:1567242779908636802>",
      "id": "1567242779908636802",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242779908636802.gif"
    },
    {
      "name": "tungsten_ticket",
      "label": "Ticket",
      "animated": true,
      "discordTag": "<a:tungsten_ticket:1567242811961770155>",
      "id": "1567242811961770155",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242811961770155.gif"
    },
    {
      "name": "tungsten_tools",
      "label": "Tools",
      "animated": true,
      "discordTag": "<a:tungsten_tools:1567242831834124431>",
      "id": "1567242831834124431",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242831834124431.gif"
    },
    {
      "name": "tungsten_tooth",
      "label": "Tooth",
      "animated": true,
      "discordTag": "<a:tungsten_tooth:1567242851480375296>",
      "id": "1567242851480375296",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242851480375296.gif"
    },
    {
      "name": "tungsten_top",
      "label": "Top",
      "animated": true,
      "discordTag": "<a:tungsten_top:1567242867846680718>",
      "id": "1567242867846680718",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242867846680718.gif"
    },
    {
      "name": "tungsten_trash",
      "label": "Trash",
      "animated": true,
      "discordTag": "<a:tungsten_trash:1567242891276062872>",
      "id": "1567242891276062872",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242891276062872.gif"
    },
    {
      "name": "tungsten_trophy",
      "label": "Trophy",
      "animated": true,
      "discordTag": "<a:tungsten_trophy:1567242918446501939>",
      "id": "1567242918446501939",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242918446501939.gif"
    },
    {
      "name": "tungsten_tv",
      "label": "Tv",
      "animated": true,
      "discordTag": "<a:tungsten_tv:1567242943197224960>",
      "id": "1567242943197224960",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242943197224960.gif"
    },
    {
      "name": "tungsten_ui_appoint",
      "label": "Ui Appoint",
      "animated": true,
      "discordTag": "<a:tungsten_ui_appoint:1567242963359375450>",
      "id": "1567242963359375450",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242963359375450.gif"
    },
    {
      "name": "tungsten_ui_assign",
      "label": "Ui Assign",
      "animated": true,
      "discordTag": "<a:tungsten_ui_assign:1567242984397742250>",
      "id": "1567242984397742250",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242984397742250.gif"
    }
  ],
  "10": [
    {
      "name": "tungsten_achievements",
      "label": "Achievements",
      "animated": true,
      "discordTag": "<a:tungsten_achievements:1569329206842757271>",
      "id": "1569329206842757271",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329206842757271.gif"
    },
    {
      "name": "tungsten_an_stage_abuse",
      "label": "An Stage Abuse",
      "animated": true,
      "discordTag": "<a:tungsten_an_stage_abuse:1569329214539173898>",
      "id": "1569329214539173898",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329214539173898.gif"
    },
    {
      "name": "tungsten_analytics",
      "label": "Analytics",
      "animated": true,
      "discordTag": "<a:tungsten_analytics:1569329222265208843>",
      "id": "1569329222265208843",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329222265208843.gif"
    },
    {
      "name": "tungsten_auction",
      "label": "Auction",
      "animated": true,
      "discordTag": "<a:tungsten_auction:1569329230435590194>",
      "id": "1569329230435590194",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329230435590194.gif"
    },
    {
      "name": "tungsten_autoslow",
      "label": "Autoslow",
      "animated": true,
      "discordTag": "<a:tungsten_autoslow:1569329238585118783>",
      "id": "1569329238585118783",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329238585118783.gif"
    },
    {
      "name": "tungsten_autothread",
      "label": "Autothread",
      "animated": true,
      "discordTag": "<a:tungsten_autothread:1569329247355539606>",
      "id": "1569329247355539606",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329247355539606.gif"
    },
    {
      "name": "tungsten_bans",
      "label": "Bans",
      "animated": true,
      "discordTag": "<a:tungsten_bans:1569329255693688853>",
      "id": "1569329255693688853",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329255693688853.gif"
    },
    {
      "name": "tungsten_calc",
      "label": "Calc",
      "animated": true,
      "discordTag": "<a:tungsten_calc:1569329263469924396>",
      "id": "1569329263469924396",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329263469924396.gif"
    },
    {
      "name": "tungsten_cat_clans",
      "label": "Cat Clans",
      "animated": true,
      "discordTag": "<a:tungsten_cat_clans:1569329279701884928>",
      "id": "1569329279701884928",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329279701884928.gif"
    },
    {
      "name": "tungsten_cat_modmail",
      "label": "Cat Modmail",
      "animated": true,
      "discordTag": "<a:tungsten_cat_modmail:1569329287692296213>",
      "id": "1569329287692296213",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329287692296213.gif"
    },
    {
      "name": "tungsten_cat_pets",
      "label": "Cat Pets",
      "animated": true,
      "discordTag": "<a:tungsten_cat_pets:1569329296542011563>",
      "id": "1569329296542011563",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329296542011563.gif"
    },
    {
      "name": "tungsten_cat_social",
      "label": "Cat Social",
      "animated": true,
      "discordTag": "<a:tungsten_cat_social:1569329304196747418>",
      "id": "1569329304196747418",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329304196747418.gif"
    },
    {
      "name": "tungsten_clan",
      "label": "Clan",
      "animated": true,
      "discordTag": "<a:tungsten_clan:1569329312774103142>",
      "id": "1569329312774103142",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329312774103142.gif"
    },
    {
      "name": "tungsten_convert",
      "label": "Convert",
      "animated": true,
      "discordTag": "<a:tungsten_convert:1569329320802000956>",
      "id": "1569329320802000956",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329320802000956.gif"
    },
    {
      "name": "tungsten_countdown",
      "label": "Countdown",
      "animated": true,
      "discordTag": "<a:tungsten_countdown:1569329328838152274>",
      "id": "1569329328838152274",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329328838152274.gif"
    },
    {
      "name": "tungsten_discordpoll",
      "label": "Discordpoll",
      "animated": true,
      "discordTag": "<a:tungsten_discordpoll:1569329347171590216>",
      "id": "1569329347171590216",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329347171590216.gif"
    },
    {
      "name": "tungsten_encode",
      "label": "Encode",
      "animated": true,
      "discordTag": "<a:tungsten_encode:1569329355111538820>",
      "id": "1569329355111538820",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329355111538820.gif"
    },
    {
      "name": "tungsten_event",
      "label": "Event",
      "animated": true,
      "discordTag": "<a:tungsten_event:1569329363038638090>",
      "id": "1569329363038638090",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329363038638090.gif"
    },
    {
      "name": "tungsten_evidence",
      "label": "Evidence",
      "animated": true,
      "discordTag": "<a:tungsten_evidence:1569329371850874921>",
      "id": "1569329371850874921",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329371850874921.gif"
    },
    {
      "name": "tungsten_farm",
      "label": "Farm",
      "animated": true,
      "discordTag": "<a:tungsten_farm:1569329379975364628>",
      "id": "1569329379975364628",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329379975364628.gif"
    },
    {
      "name": "tungsten_feed",
      "label": "Feed",
      "animated": true,
      "discordTag": "<a:tungsten_feed:1569329388053467276>",
      "id": "1569329388053467276",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329388053467276.gif"
    },
    {
      "name": "tungsten_forum",
      "label": "Forum",
      "animated": true,
      "discordTag": "<a:tungsten_forum:1569329396278370374>",
      "id": "1569329396278370374",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329396278370374.gif"
    },
    {
      "name": "tungsten_guildsettings",
      "label": "Guildsettings",
      "animated": true,
      "discordTag": "<a:tungsten_guildsettings:1569329404558184562>",
      "id": "1569329404558184562",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329404558184562.gif"
    },
    {
      "name": "tungsten_integrations",
      "label": "Integrations",
      "animated": true,
      "discordTag": "<a:tungsten_integrations:1569329413110239292>",
      "id": "1569329413110239292",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329413110239292.gif"
    },
    {
      "name": "tungsten_linkedroles",
      "label": "Linkedroles",
      "animated": true,
      "discordTag": "<a:tungsten_linkedroles:1569329421352046592>",
      "id": "1569329421352046592",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329421352046592.gif"
    },
    {
      "name": "tungsten_lockdown",
      "label": "Lockdown",
      "animated": true,
      "discordTag": "<a:tungsten_lockdown:1569329429174296697>",
      "id": "1569329429174296697",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329429174296697.gif"
    },
    {
      "name": "tungsten_macro",
      "label": "Macro",
      "animated": true,
      "discordTag": "<a:tungsten_macro:1569329438586310706>",
      "id": "1569329438586310706",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329438586310706.gif"
    },
    {
      "name": "tungsten_marriage",
      "label": "Marriage",
      "animated": true,
      "discordTag": "<a:tungsten_marriage:1569329446325063725>",
      "id": "1569329446325063725",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329446325063725.gif"
    },
    {
      "name": "tungsten_modmail",
      "label": "Modmail",
      "animated": true,
      "discordTag": "<a:tungsten_modmail:1569329454952611870>",
      "id": "1569329454952611870",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329454952611870.gif"
    },
    {
      "name": "tungsten_nativeautomod",
      "label": "Nativeautomod",
      "animated": true,
      "discordTag": "<a:tungsten_nativeautomod:1569329462921920542>",
      "id": "1569329462921920542",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329462921920542.gif"
    },
    {
      "name": "tungsten_npm",
      "label": "Npm",
      "animated": true,
      "discordTag": "<a:tungsten_npm:1569329471373320352>",
      "id": "1569329471373320352",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329471373320352.gif"
    },
    {
      "name": "tungsten_onboarding",
      "label": "Onboarding",
      "animated": true,
      "discordTag": "<a:tungsten_onboarding:1569329479325585481>",
      "id": "1569329479325585481",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329479325585481.gif"
    },
    {
      "name": "tungsten_override",
      "label": "Override",
      "animated": true,
      "discordTag": "<a:tungsten_override:1569329487794143305>",
      "id": "1569329487794143305",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329487794143305.gif"
    },
    {
      "name": "tungsten_panelbuilder",
      "label": "Panelbuilder",
      "animated": true,
      "discordTag": "<a:tungsten_panelbuilder:1569329495809200158>",
      "id": "1569329495809200158",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329495809200158.gif"
    }
  ],
  "11": [
    {
      "name": "tungsten_password",
      "label": "Password",
      "animated": true,
      "discordTag": "<a:tungsten_password:1569329504994852944>",
      "id": "1569329504994852944",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329504994852944.gif"
    },
    {
      "name": "tungsten_pet",
      "label": "Pet",
      "animated": true,
      "discordTag": "<a:tungsten_pet:1569329513408634920>",
      "id": "1569329513408634920",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329513408634920.gif"
    },
    {
      "name": "tungsten_pokemon",
      "label": "Pokemon",
      "animated": true,
      "discordTag": "<a:tungsten_pokemon:1569329520966635581>",
      "id": "1569329520966635581",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329520966635581.gif"
    },
    {
      "name": "tungsten_policy",
      "label": "Policy",
      "animated": true,
      "discordTag": "<a:tungsten_policy:1569329528851927131>",
      "id": "1569329528851927131",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329528851927131.gif"
    },
    {
      "name": "tungsten_presence",
      "label": "Presence",
      "animated": true,
      "discordTag": "<a:tungsten_presence:1569329536875888711>",
      "id": "1569329536875888711",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329536875888711.gif"
    },
    {
      "name": "tungsten_profile",
      "label": "Profile",
      "animated": true,
      "discordTag": "<a:tungsten_profile:1569329544819900416>",
      "id": "1569329544819900416",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329544819900416.gif"
    },
    {
      "name": "tungsten_quests",
      "label": "Quests",
      "animated": true,
      "discordTag": "<a:tungsten_quests:1569329552453533827>",
      "id": "1569329552453533827",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329552453533827.gif"
    },
    {
      "name": "tungsten_rep",
      "label": "Rep",
      "animated": true,
      "discordTag": "<a:tungsten_rep:1569329560917381213>",
      "id": "1569329560917381213",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329560917381213.gif"
    },
    {
      "name": "tungsten_serverdoctor",
      "label": "Serverdoctor",
      "animated": true,
      "discordTag": "<a:tungsten_serverdoctor:1569329568471457898>",
      "id": "1569329568471457898",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329568471457898.gif"
    },
    {
      "name": "tungsten_setup",
      "label": "Setup",
      "animated": true,
      "discordTag": "<a:tungsten_setup:1569329576490836098>",
      "id": "1569329576490836098",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329576490836098.gif"
    },
    {
      "name": "tungsten_snowflake",
      "label": "Snowflake",
      "animated": true,
      "discordTag": "<a:tungsten_snowflake:1569329585487614105>",
      "id": "1569329585487614105",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329585487614105.gif"
    },
    {
      "name": "tungsten_soundboard",
      "label": "Soundboard",
      "animated": true,
      "discordTag": "<a:tungsten_soundboard:1569329593561780354>",
      "id": "1569329593561780354",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329593561780354.gif"
    },
    {
      "name": "tungsten_stage",
      "label": "Stage",
      "animated": true,
      "discordTag": "<a:tungsten_stage:1569329601971224720>",
      "id": "1569329601971224720",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329601971224720.gif"
    },
    {
      "name": "tungsten_thread",
      "label": "Thread",
      "animated": true,
      "discordTag": "<a:tungsten_thread:1569329618928930846>",
      "id": "1569329618928930846",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329618928930846.gif"
    },
    {
      "name": "tungsten_tournament",
      "label": "Tournament",
      "animated": true,
      "discordTag": "<a:tungsten_tournament:1569329627057487993>",
      "id": "1569329627057487993",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329627057487993.gif"
    },
    {
      "name": "tungsten_trade",
      "label": "Trade",
      "animated": true,
      "discordTag": "<a:tungsten_trade:1569329634733072495>",
      "id": "1569329634733072495",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329634733072495.gif"
    },
    {
      "name": "tungsten_ui_bid",
      "label": "Ui Bid",
      "animated": true,
      "discordTag": "<a:tungsten_ui_bid:1569329642609836154>",
      "id": "1569329642609836154",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329642609836154.gif"
    },
    {
      "name": "tungsten_ui_bracket",
      "label": "Ui Bracket",
      "animated": true,
      "discordTag": "<a:tungsten_ui_bracket:1569329652714184704>",
      "id": "1569329652714184704",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329652714184704.gif"
    },
    {
      "name": "tungsten_ui_harvest",
      "label": "Ui Harvest",
      "animated": true,
      "discordTag": "<a:tungsten_ui_harvest:1569329661148930230>",
      "id": "1569329661148930230",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329661148930230.gif"
    },
    {
      "name": "tungsten_ui_plant",
      "label": "Ui Plant",
      "animated": true,
      "discordTag": "<a:tungsten_ui_plant:1569329669503717397>",
      "id": "1569329669503717397",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329669503717397.gif"
    },
    {
      "name": "tungsten_ui_toggle_off",
      "label": "Ui Toggle Off",
      "animated": true,
      "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
      "id": "1569329677187678368",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329677187678368.gif"
    },
    {
      "name": "tungsten_ui_toggle_on",
      "label": "Ui Toggle On",
      "animated": true,
      "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
      "id": "1569329685110849576",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329685110849576.gif"
    },
    {
      "name": "tungsten_ui_trade",
      "label": "Ui Trade",
      "animated": true,
      "discordTag": "<a:tungsten_ui_trade:1569329692899680408>",
      "id": "1569329692899680408",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329692899680408.gif"
    },
    {
      "name": "tungsten_ui_water",
      "label": "Ui Water",
      "animated": true,
      "discordTag": "<a:tungsten_ui_water:1569329701409915022>",
      "id": "1569329701409915022",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329701409915022.gif"
    },
    {
      "name": "tungsten_ui_wizard_back",
      "label": "Ui Wizard Back",
      "animated": true,
      "discordTag": "<a:tungsten_ui_wizard_back:1569329709613850625>",
      "id": "1569329709613850625",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329709613850625.gif"
    },
    {
      "name": "tungsten_ui_wizard_finish",
      "label": "Ui Wizard Finish",
      "animated": true,
      "discordTag": "<a:tungsten_ui_wizard_finish:1569329717243412595>",
      "id": "1569329717243412595",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329717243412595.gif"
    },
    {
      "name": "tungsten_ui_wizard_next",
      "label": "Ui Wizard Next",
      "animated": true,
      "discordTag": "<a:tungsten_ui_wizard_next:1569329725405536328>",
      "id": "1569329725405536328",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329725405536328.gif"
    },
    {
      "name": "tungsten_watchlist",
      "label": "Watchlist",
      "animated": true,
      "discordTag": "<a:tungsten_watchlist:1569329733303541801>",
      "id": "1569329733303541801",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329733303541801.gif"
    },
    {
      "name": "tungsten_webhook",
      "label": "Webhook",
      "animated": true,
      "discordTag": "<a:tungsten_webhook:1569329741150949488>",
      "id": "1569329741150949488",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329741150949488.gif"
    },
    {
      "name": "tungsten_welcomescreen",
      "label": "Welcomescreen",
      "animated": true,
      "discordTag": "<a:tungsten_welcomescreen:1569329748486787085>",
      "id": "1569329748486787085",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329748486787085.gif"
    },
    {
      "name": "tungsten_whois",
      "label": "Whois",
      "animated": true,
      "discordTag": "<a:tungsten_whois:1569329756657160402>",
      "id": "1569329756657160402",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329756657160402.gif"
    },
    {
      "name": "tungsten_wordcount",
      "label": "Wordcount",
      "animated": true,
      "discordTag": "<a:tungsten_wordcount:1569329764508893246>",
      "id": "1569329764508893246",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329764508893246.gif"
    },
    {
      "name": "tungsten_workflow",
      "label": "Workflow",
      "animated": true,
      "discordTag": "<a:tungsten_workflow:1569329772520018061>",
      "id": "1569329772520018061",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329772520018061.gif"
    },
    {
      "name": "tungsten_worldclock",
      "label": "Worldclock",
      "animated": true,
      "discordTag": "<a:tungsten_worldclock:1569329780229275668>",
      "id": "1569329780229275668",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329780229275668.gif"
    }
  ],
  "12": [],
  "13": [],
  "14": [],
  "15": [],
  "1566265776753610974": [
    {
      "name": "tungsten_alarm",
      "label": "Alarm",
      "animated": true,
      "discordTag": "<a:tungsten_alarm:1567229471474585682>",
      "id": "1567229471474585682",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567229471474585682.gif"
    },
    {
      "name": "tungsten_ui_backup_db",
      "label": "Ui Backup Db",
      "animated": true,
      "discordTag": "<a:tungsten_ui_backup_db:1567243012629729341>",
      "id": "1567243012629729341",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243012629729341.gif"
    },
    {
      "name": "tungsten_ui_channel_tools",
      "label": "Ui Channel Tools",
      "animated": true,
      "discordTag": "<a:tungsten_ui_channel_tools:1567243046951854130>",
      "id": "1567243046951854130",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243046951854130.gif"
    },
    {
      "name": "tungsten_ui_check_rank",
      "label": "Ui Check Rank",
      "animated": true,
      "discordTag": "<a:tungsten_ui_check_rank:1567243080464335058>",
      "id": "1567243080464335058",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243080464335058.gif"
    },
    {
      "name": "tungsten_ui_complete_verify",
      "label": "Ui Complete Verify",
      "animated": true,
      "discordTag": "<a:tungsten_ui_complete_verify:1567243101477806101>",
      "id": "1567243101477806101",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243101477806101.gif"
    },
    {
      "name": "tungsten_ui_d10m",
      "label": "Ui D10m",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d10m:1567243132008136765>",
      "id": "1567243132008136765",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243132008136765.gif"
    },
    {
      "name": "tungsten_ui_d1d",
      "label": "Ui D1d",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d1d:1567243179269423157>",
      "id": "1567243179269423157",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243179269423157.gif"
    },
    {
      "name": "tungsten_ui_d1h",
      "label": "Ui D1h",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d1h:1567243251767971951>",
      "id": "1567243251767971951",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243251767971951.gif"
    },
    {
      "name": "tungsten_ui_d1w",
      "label": "Ui D1w",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d1w:1567243278917836991>",
      "id": "1567243278917836991",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243278917836991.gif"
    },
    {
      "name": "tungsten_ui_d5m",
      "label": "Ui D5m",
      "animated": true,
      "discordTag": "<a:tungsten_ui_d5m:1567243350279725106>",
      "id": "1567243350279725106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243350279725106.gif"
    },
    {
      "name": "tungsten_ui_daily_usage",
      "label": "Ui Daily Usage",
      "animated": true,
      "discordTag": "<a:tungsten_ui_daily_usage:1567243371603296270>",
      "id": "1567243371603296270",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243371603296270.gif"
    },
    {
      "name": "tungsten_ui_disable_all",
      "label": "Ui Disable All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_disable_all:1567243443338485862>",
      "id": "1567243443338485862",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243443338485862.gif"
    },
    {
      "name": "tungsten_ui_disconnect",
      "label": "Ui Disconnect",
      "animated": true,
      "discordTag": "<a:tungsten_ui_disconnect:1567243506072682706>",
      "id": "1567243506072682706",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243506072682706.gif"
    },
    {
      "name": "tungsten_ui_dismiss",
      "label": "Ui Dismiss",
      "animated": true,
      "discordTag": "<a:tungsten_ui_dismiss:1567243549555036200>",
      "id": "1567243549555036200",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243549555036200.gif"
    },
    {
      "name": "tungsten_ui_dm_test",
      "label": "Ui Dm Test",
      "animated": true,
      "discordTag": "<a:tungsten_ui_dm_test:1567243572002951178>",
      "id": "1567243572002951178",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243572002951178.gif"
    },
    {
      "name": "tungsten_ui_edit_nick",
      "label": "Ui Edit Nick",
      "animated": true,
      "discordTag": "<a:tungsten_ui_edit_nick:1567243591686823967>",
      "id": "1567243591686823967",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243591686823967.gif"
    },
    {
      "name": "tungsten_ui_enable_all",
      "label": "Ui Enable All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_enable_all:1567243610716508202>",
      "id": "1567243610716508202",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243610716508202.gif"
    },
    {
      "name": "tungsten_ui_events",
      "label": "Ui Events",
      "animated": true,
      "discordTag": "<a:tungsten_ui_events:1567243642094092323>",
      "id": "1567243642094092323",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243642094092323.gif"
    },
    {
      "name": "tungsten_ui_forfeit",
      "label": "Ui Forfeit",
      "animated": true,
      "discordTag": "<a:tungsten_ui_forfeit:1567243664613314610>",
      "id": "1567243664613314610",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243664613314610.gif"
    },
    {
      "name": "tungsten_ui_hide",
      "label": "Ui Hide",
      "animated": true,
      "discordTag": "<a:tungsten_ui_hide:1567243688143487107>",
      "id": "1567243688143487107",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243688143487107.gif"
    },
    {
      "name": "tungsten_ui_hide_vc",
      "label": "Ui Hide Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_hide_vc:1567243710075371651>",
      "id": "1567243710075371651",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243710075371651.gif"
    },
    {
      "name": "tungsten_ui_install",
      "label": "Ui Install",
      "animated": true,
      "discordTag": "<a:tungsten_ui_install:1567243737363386509>",
      "id": "1567243737363386509",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243737363386509.gif"
    },
    {
      "name": "tungsten_ui_invite_admin",
      "label": "Ui Invite Admin",
      "animated": true,
      "discordTag": "<a:tungsten_ui_invite_admin:1567243760079741052>",
      "id": "1567243760079741052",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243760079741052.gif"
    },
    {
      "name": "tungsten_ui_invite_std",
      "label": "Ui Invite Std",
      "animated": true,
      "discordTag": "<a:tungsten_ui_invite_std:1567243779495305246>",
      "id": "1567243779495305246",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243779495305246.gif"
    },
    {
      "name": "tungsten_ui_join_support",
      "label": "Ui Join Support",
      "animated": true,
      "discordTag": "<a:tungsten_ui_join_support:1567243801343299704>",
      "id": "1567243801343299704",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243801343299704.gif"
    },
    {
      "name": "tungsten_ui_jump",
      "label": "Ui Jump",
      "animated": true,
      "discordTag": "<a:tungsten_ui_jump:1567243825028538530>",
      "id": "1567243825028538530",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243825028538530.gif"
    },
    {
      "name": "tungsten_ui_lb_history",
      "label": "Ui Lb History",
      "animated": true,
      "discordTag": "<a:tungsten_ui_lb_history:1567243859229147236>",
      "id": "1567243859229147236",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243859229147236.gif"
    },
    {
      "name": "tungsten_ui_leveling",
      "label": "Ui Leveling",
      "animated": true,
      "discordTag": "<a:tungsten_ui_leveling:1567243886294737016>",
      "id": "1567243886294737016",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243886294737016.gif"
    },
    {
      "name": "tungsten_ui_list",
      "label": "Ui List",
      "animated": true,
      "discordTag": "<a:tungsten_ui_list:1567243909707604059>",
      "id": "1567243909707604059",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243909707604059.gif"
    },
    {
      "name": "tungsten_ui_lock_vc",
      "label": "Ui Lock Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_lock_vc:1567243939503931611>",
      "id": "1567243939503931611",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243939503931611.gif"
    },
    {
      "name": "tungsten_ui_lockdown",
      "label": "Ui Lockdown",
      "animated": true,
      "discordTag": "<a:tungsten_ui_lockdown:1567243966150082580>",
      "id": "1567243966150082580",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243966150082580.gif"
    },
    {
      "name": "tungsten_ui_manage",
      "label": "Ui Manage",
      "animated": true,
      "discordTag": "<a:tungsten_ui_manage:1567243992435920926>",
      "id": "1567243992435920926",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567243992435920926.gif"
    },
    {
      "name": "tungsten_ui_mute_all",
      "label": "Ui Mute All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_mute_all:1567244037264506951>",
      "id": "1567244037264506951",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244037264506951.gif"
    },
    {
      "name": "tungsten_ui_n1",
      "label": "Ui N1",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n1:1567244083447996537>",
      "id": "1567244083447996537",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244083447996537.gif"
    },
    {
      "name": "tungsten_ui_n2",
      "label": "Ui N2",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n2:1567244128704659548>",
      "id": "1567244128704659548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244128704659548.gif"
    },
    {
      "name": "tungsten_ui_n3",
      "label": "Ui N3",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n3:1567244152553603203>",
      "id": "1567244152553603203",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244152553603203.gif"
    },
    {
      "name": "tungsten_ui_n4",
      "label": "Ui N4",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n4:1567244239912575056>",
      "id": "1567244239912575056",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244239912575056.gif"
    },
    {
      "name": "tungsten_ui_n5",
      "label": "Ui N5",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n5:1567244324213755965>",
      "id": "1567244324213755965",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244324213755965.gif"
    },
    {
      "name": "tungsten_ui_n6",
      "label": "Ui N6",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n6:1567244344866639972>",
      "id": "1567244344866639972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244344866639972.gif"
    },
    {
      "name": "tungsten_ui_n7",
      "label": "Ui N7",
      "animated": true,
      "discordTag": "<a:tungsten_ui_n7:1567244425057411202>",
      "id": "1567244425057411202",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244425057411202.gif"
    },
    {
      "name": "tungsten_ui_off",
      "label": "Ui Off",
      "animated": true,
      "discordTag": "<a:tungsten_ui_off:1567244478178402347>",
      "id": "1567244478178402347",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244478178402347.gif"
    },
    {
      "name": "tungsten_ui_on",
      "label": "Ui On",
      "animated": true,
      "discordTag": "<a:tungsten_ui_on:1567244543546630266>",
      "id": "1567244543546630266",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244543546630266.gif"
    },
    {
      "name": "tungsten_ui_open",
      "label": "Ui Open",
      "animated": true,
      "discordTag": "<a:tungsten_ui_open:1567244565159743488>",
      "id": "1567244565159743488",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244565159743488.gif"
    },
    {
      "name": "tungsten_ui_overview",
      "label": "Ui Overview",
      "animated": true,
      "discordTag": "<a:tungsten_ui_overview:1567244587137769573>",
      "id": "1567244587137769573",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244587137769573.gif"
    },
    {
      "name": "tungsten_ui_p10",
      "label": "Ui P10",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p10:1567244612081553568>",
      "id": "1567244612081553568",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244612081553568.gif"
    },
    {
      "name": "tungsten_ui_p100",
      "label": "Ui P100",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p100:1567244632121671763>",
      "id": "1567244632121671763",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244632121671763.gif"
    },
    {
      "name": "tungsten_ui_p25",
      "label": "Ui P25",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p25:1567244653416161343>",
      "id": "1567244653416161343",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244653416161343.gif"
    }
  ],
  "1563432162626113596": [
    {
      "name": "tungsten_an_arm",
      "label": "An Arm",
      "animated": true,
      "discordTag": "<a:tungsten_an_arm:1567232430908244079>",
      "id": "1567232430908244079",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232430908244079.gif"
    },
    {
      "name": "tungsten_an_backup_roles",
      "label": "An Backup Roles",
      "animated": true,
      "discordTag": "<a:tungsten_an_backup_roles:1567232464970322071>",
      "id": "1567232464970322071",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232464970322071.gif"
    },
    {
      "name": "tungsten_an_ban",
      "label": "An Ban",
      "animated": true,
      "discordTag": "<a:tungsten_an_ban:1567232483743895684>",
      "id": "1567232483743895684",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232483743895684.gif"
    },
    {
      "name": "tungsten_an_bot",
      "label": "An Bot",
      "animated": true,
      "discordTag": "<a:tungsten_an_bot:1567232510893490216>",
      "id": "1567232510893490216",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232510893490216.gif"
    },
    {
      "name": "tungsten_an_caps",
      "label": "An Caps",
      "animated": true,
      "discordTag": "<a:tungsten_an_caps:1567232530988662824>",
      "id": "1567232530988662824",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232530988662824.gif"
    },
    {
      "name": "tungsten_an_channel_create",
      "label": "An Channel Create",
      "animated": true,
      "discordTag": "<a:tungsten_an_channel_create:1567232575855005736>",
      "id": "1567232575855005736",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232575855005736.gif"
    },
    {
      "name": "tungsten_an_channel_delete",
      "label": "An Channel Delete",
      "animated": true,
      "discordTag": "<a:tungsten_an_channel_delete:1567232594930696262>",
      "id": "1567232594930696262",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232594930696262.gif"
    },
    {
      "name": "tungsten_an_disarm",
      "label": "An Disarm",
      "animated": true,
      "discordTag": "<a:tungsten_an_disarm:1567232635237834762>",
      "id": "1567232635237834762",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232635237834762.gif"
    },
    {
      "name": "tungsten_an_everyone",
      "label": "An Everyone",
      "animated": true,
      "discordTag": "<a:tungsten_an_everyone:1567232659715793068>",
      "id": "1567232659715793068",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232659715793068.gif"
    },
    {
      "name": "tungsten_an_ghostping",
      "label": "An Ghostping",
      "animated": true,
      "discordTag": "<a:tungsten_an_ghostping:1567232680020672664>",
      "id": "1567232680020672664",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232680020672664.gif"
    },
    {
      "name": "tungsten_an_integrity",
      "label": "An Integrity",
      "animated": true,
      "discordTag": "<a:tungsten_an_integrity:1567232702690623490>",
      "id": "1567232702690623490",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232702690623490.gif"
    },
    {
      "name": "tungsten_an_invite",
      "label": "An Invite",
      "animated": true,
      "discordTag": "<a:tungsten_an_invite:1567232720126607421>",
      "id": "1567232720126607421",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232720126607421.gif"
    },
    {
      "name": "tungsten_an_join_flood",
      "label": "An Join Flood",
      "animated": true,
      "discordTag": "<a:tungsten_an_join_flood:1567232740041031831>",
      "id": "1567232740041031831",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232740041031831.gif"
    },
    {
      "name": "tungsten_an_kick",
      "label": "An Kick",
      "animated": true,
      "discordTag": "<a:tungsten_an_kick:1567232757330083940>",
      "id": "1567232757330083940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232757330083940.gif"
    },
    {
      "name": "tungsten_an_limits",
      "label": "An Limits",
      "animated": true,
      "discordTag": "<a:tungsten_an_limits:1567232774367092797>",
      "id": "1567232774367092797",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232774367092797.gif"
    },
    {
      "name": "tungsten_an_link",
      "label": "An Link",
      "animated": true,
      "discordTag": "<a:tungsten_an_link:1567232798299922585>",
      "id": "1567232798299922585",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232798299922585.gif"
    },
    {
      "name": "tungsten_an_lockdown",
      "label": "An Lockdown",
      "animated": true,
      "discordTag": "<a:tungsten_an_lockdown:1567232816406732850>",
      "id": "1567232816406732850",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232816406732850.gif"
    },
    {
      "name": "tungsten_an_lockdown_lift",
      "label": "An Lockdown Lift",
      "animated": true,
      "discordTag": "<a:tungsten_an_lockdown_lift:1567232833670488064>",
      "id": "1567232833670488064",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232833670488064.gif"
    },
    {
      "name": "tungsten_an_logs",
      "label": "An Logs",
      "animated": true,
      "discordTag": "<a:tungsten_an_logs:1567232852200923149>",
      "id": "1567232852200923149",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232852200923149.gif"
    },
    {
      "name": "tungsten_an_mention",
      "label": "An Mention",
      "animated": true,
      "discordTag": "<a:tungsten_an_mention:1567232877584715970>",
      "id": "1567232877584715970",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232877584715970.gif"
    },
    {
      "name": "tungsten_an_nsfw",
      "label": "An Nsfw",
      "animated": true,
      "discordTag": "<a:tungsten_an_nsfw:1567232895830196495>",
      "id": "1567232895830196495",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232895830196495.gif"
    },
    {
      "name": "tungsten_an_punish",
      "label": "An Punish",
      "animated": true,
      "discordTag": "<a:tungsten_an_punish:1567232919984939141>",
      "id": "1567232919984939141",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232919984939141.gif"
    },
    {
      "name": "tungsten_an_raid",
      "label": "An Raid",
      "animated": true,
      "discordTag": "<a:tungsten_an_raid:1567232943435292972>",
      "id": "1567232943435292972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232943435292972.gif"
    },
    {
      "name": "tungsten_an_role_create",
      "label": "An Role Create",
      "animated": true,
      "discordTag": "<a:tungsten_an_role_create:1567232961181384745>",
      "id": "1567232961181384745",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232961181384745.gif"
    },
    {
      "name": "tungsten_an_role_delete",
      "label": "An Role Delete",
      "animated": true,
      "discordTag": "<a:tungsten_an_role_delete:1567232979569483776>",
      "id": "1567232979569483776",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567232979569483776.gif"
    },
    {
      "name": "tungsten_an_spam",
      "label": "An Spam",
      "animated": true,
      "discordTag": "<a:tungsten_an_spam:1567233007415197823>",
      "id": "1567233007415197823",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233007415197823.gif"
    },
    {
      "name": "tungsten_an_standard",
      "label": "An Standard",
      "animated": true,
      "discordTag": "<a:tungsten_an_standard:1567233029233967106>",
      "id": "1567233029233967106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233029233967106.gif"
    },
    {
      "name": "tungsten_an_strict",
      "label": "An Strict",
      "animated": true,
      "discordTag": "<a:tungsten_an_strict:1567233050260021398>",
      "id": "1567233050260021398",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233050260021398.gif"
    },
    {
      "name": "tungsten_an_ultra",
      "label": "An Ultra",
      "animated": true,
      "discordTag": "<a:tungsten_an_ultra:1567233073005731872>",
      "id": "1567233073005731872",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233073005731872.gif"
    },
    {
      "name": "tungsten_an_webhook",
      "label": "An Webhook",
      "animated": true,
      "discordTag": "<a:tungsten_an_webhook:1567233087388262422>",
      "id": "1567233087388262422",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233087388262422.gif"
    },
    {
      "name": "tungsten_anger",
      "label": "Anger",
      "animated": true,
      "discordTag": "<a:tungsten_anger:1567233100776218734>",
      "id": "1567233100776218734",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233100776218734.gif"
    },
    {
      "name": "tungsten_arrow_left",
      "label": "Arrow Left",
      "animated": true,
      "discordTag": "<a:tungsten_arrow_left:1567233111601844267>",
      "id": "1567233111601844267",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233111601844267.gif"
    },
    {
      "name": "tungsten_arrow_right",
      "label": "Arrow Right",
      "animated": true,
      "discordTag": "<a:tungsten_arrow_right:1567233126143361135>",
      "id": "1567233126143361135",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233126143361135.gif"
    },
    {
      "name": "tungsten_arrow_small",
      "label": "Arrow Small",
      "animated": true,
      "discordTag": "<a:tungsten_arrow_small:1567233140357988574>",
      "id": "1567233140357988574",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233140357988574.gif"
    },
    {
      "name": "tungsten_atm",
      "label": "Atm",
      "animated": true,
      "discordTag": "<a:tungsten_atm:1567233228350300292>",
      "id": "1567233228350300292",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233228350300292.gif"
    },
    {
      "name": "tungsten_bank",
      "label": "Bank",
      "animated": true,
      "discordTag": "<a:tungsten_bank:1567233290656677924>",
      "id": "1567233290656677924",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233290656677924.gif"
    },
    {
      "name": "tungsten_bell",
      "label": "Bell",
      "animated": true,
      "discordTag": "<a:tungsten_bell:1567233316925612173>",
      "id": "1567233316925612173",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233316925612173.gif"
    },
    {
      "name": "tungsten_bell_slash",
      "label": "Bell Slash",
      "animated": true,
      "discordTag": "<a:tungsten_bell_slash:1567233400996106260>",
      "id": "1567233400996106260",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233400996106260.gif"
    },
    {
      "name": "tungsten_bolt",
      "label": "Bolt",
      "animated": true,
      "discordTag": "<a:tungsten_bolt:1567233430570405968>",
      "id": "1567233430570405968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233430570405968.gif"
    },
    {
      "name": "tungsten_bomb",
      "label": "Bomb",
      "animated": true,
      "discordTag": "<a:tungsten_bomb:1567233448945385502>",
      "id": "1567233448945385502",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233448945385502.gif"
    },
    {
      "name": "tungsten_book",
      "label": "Book",
      "animated": true,
      "discordTag": "<a:tungsten_book:1567233482499948606>",
      "id": "1567233482499948606",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233482499948606.gif"
    },
    {
      "name": "tungsten_boot",
      "label": "Boot",
      "animated": true,
      "discordTag": "<a:tungsten_boot:1567233502418575501>",
      "id": "1567233502418575501",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233502418575501.gif"
    },
    {
      "name": "tungsten_bot",
      "label": "Bot",
      "animated": true,
      "discordTag": "<a:tungsten_bot:1567233522635247781>",
      "id": "1567233522635247781",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233522635247781.gif"
    },
    {
      "name": "tungsten_brain",
      "label": "Brain",
      "animated": true,
      "discordTag": "<a:tungsten_brain:1567233547272454144>",
      "id": "1567233547272454144",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233547272454144.gif"
    },
    {
      "name": "tungsten_briefcase",
      "label": "Briefcase",
      "animated": true,
      "discordTag": "<a:tungsten_briefcase:1567233568596295821>",
      "id": "1567233568596295821",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233568596295821.gif"
    },
    {
      "name": "tungsten_bullet",
      "label": "Bullet",
      "animated": true,
      "discordTag": "<a:tungsten_bullet:1567233589949497434>",
      "id": "1567233589949497434",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233589949497434.gif"
    }
  ],
  "1566282297177538562": [
    {
      "name": "tungsten_cabinet",
      "label": "Cabinet",
      "animated": true,
      "discordTag": "<a:tungsten_cabinet:1567233617489297548>",
      "id": "1567233617489297548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233617489297548.gif"
    },
    {
      "name": "tungsten_calendar",
      "label": "Calendar",
      "animated": true,
      "discordTag": "<a:tungsten_calendar:1567233642554458154>",
      "id": "1567233642554458154",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233642554458154.gif"
    },
    {
      "name": "tungsten_cash",
      "label": "Cash",
      "animated": true,
      "discordTag": "<a:tungsten_cash:1567233665082200267>",
      "id": "1567233665082200267",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233665082200267.gif"
    },
    {
      "name": "tungsten_castle",
      "label": "Castle",
      "animated": true,
      "discordTag": "<a:tungsten_castle:1567233687332982844>",
      "id": "1567233687332982844",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233687332982844.gif"
    },
    {
      "name": "tungsten_cat_automation",
      "label": "Cat Automation",
      "animated": true,
      "discordTag": "<a:tungsten_cat_automation:1567233718861435011>",
      "id": "1567233718861435011",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233718861435011.gif"
    },
    {
      "name": "tungsten_cat_backups",
      "label": "Cat Backups",
      "animated": true,
      "discordTag": "<a:tungsten_cat_backups:1567233747567251666>",
      "id": "1567233747567251666",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233747567251666.gif"
    },
    {
      "name": "tungsten_cat_channels",
      "label": "Cat Channels",
      "animated": true,
      "discordTag": "<a:tungsten_cat_channels:1567233777024110652>",
      "id": "1567233777024110652",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233777024110652.gif"
    },
    {
      "name": "tungsten_cat_economy",
      "label": "Cat Economy",
      "animated": true,
      "discordTag": "<a:tungsten_cat_economy:1567233807822618735>",
      "id": "1567233807822618735",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233807822618735.gif"
    },
    {
      "name": "tungsten_cat_fun",
      "label": "Cat Fun",
      "animated": true,
      "discordTag": "<a:tungsten_cat_fun:1567233835035402350>",
      "id": "1567233835035402350",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233835035402350.gif"
    },
    {
      "name": "tungsten_cat_giveaways",
      "label": "Cat Giveaways",
      "animated": true,
      "discordTag": "<a:tungsten_cat_giveaways:1567233867637588015>",
      "id": "1567233867637588015",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233867637588015.gif"
    },
    {
      "name": "tungsten_cat_leaderboards",
      "label": "Cat Leaderboards",
      "animated": true,
      "discordTag": "<a:tungsten_cat_leaderboards:1567233900366008430>",
      "id": "1567233900366008430",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233900366008430.gif"
    },
    {
      "name": "tungsten_cat_logging",
      "label": "Cat Logging",
      "animated": true,
      "discordTag": "<a:tungsten_cat_logging:1567233934490738860>",
      "id": "1567233934490738860",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233934490738860.gif"
    },
    {
      "name": "tungsten_cat_media",
      "label": "Cat Media",
      "animated": true,
      "discordTag": "<a:tungsten_cat_media:1567233959207764080>",
      "id": "1567233959207764080",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233959207764080.gif"
    },
    {
      "name": "tungsten_cat_moderation",
      "label": "Cat Moderation",
      "animated": true,
      "discordTag": "<a:tungsten_cat_moderation:1567233980523225148>",
      "id": "1567233980523225148",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567233980523225148.gif"
    },
    {
      "name": "tungsten_cat_owner",
      "label": "Cat Owner",
      "animated": true,
      "discordTag": "<a:tungsten_cat_owner:1567234022927638649>",
      "id": "1567234022927638649",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234022927638649.gif"
    },
    {
      "name": "tungsten_cat_premium",
      "label": "Cat Premium",
      "animated": true,
      "discordTag": "<a:tungsten_cat_premium:1567234059510223029>",
      "id": "1567234059510223029",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234059510223029.gif"
    },
    {
      "name": "tungsten_cat_roles",
      "label": "Cat Roles",
      "animated": true,
      "discordTag": "<a:tungsten_cat_roles:1567234100975378512>",
      "id": "1567234100975378512",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234100975378512.gif"
    },
    {
      "name": "tungsten_cat_security",
      "label": "Cat Security",
      "animated": true,
      "discordTag": "<a:tungsten_cat_security:1567234156075683940>",
      "id": "1567234156075683940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234156075683940.gif"
    },
    {
      "name": "tungsten_cat_tickets",
      "label": "Cat Tickets",
      "animated": true,
      "discordTag": "<a:tungsten_cat_tickets:1567234238737031290>",
      "id": "1567234238737031290",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234238737031290.gif"
    },
    {
      "name": "tungsten_cat_utility",
      "label": "Cat Utility",
      "animated": true,
      "discordTag": "<a:tungsten_cat_utility:1567234274183217304>",
      "id": "1567234274183217304",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234274183217304.gif"
    },
    {
      "name": "tungsten_cat_welcomer",
      "label": "Cat Welcomer",
      "animated": true,
      "discordTag": "<a:tungsten_cat_welcomer:1567234301869822153>",
      "id": "1567234301869822153",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234301869822153.gif"
    },
    {
      "name": "tungsten_cat_whitelist",
      "label": "Cat Whitelist",
      "animated": true,
      "discordTag": "<a:tungsten_cat_whitelist:1567234327970848848>",
      "id": "1567234327970848848",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234327970848848.gif"
    },
    {
      "name": "tungsten_chart",
      "label": "Chart",
      "animated": true,
      "discordTag": "<a:tungsten_chart:1567234342701367357>",
      "id": "1567234342701367357",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234342701367357.gif"
    },
    {
      "name": "tungsten_chat",
      "label": "Chat",
      "animated": true,
      "discordTag": "<a:tungsten_chat:1567234399450177665>",
      "id": "1567234399450177665",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234399450177665.gif"
    },
    {
      "name": "tungsten_cherry",
      "label": "Cherry",
      "animated": true,
      "discordTag": "<a:tungsten_cherry:1567234489682362439>",
      "id": "1567234489682362439",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234489682362439.gif"
    },
    {
      "name": "tungsten_circle_green",
      "label": "Circle Green",
      "animated": true,
      "discordTag": "<a:tungsten_circle_green:1567234524512002088>",
      "id": "1567234524512002088",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234524512002088.gif"
    },
    {
      "name": "tungsten_circle_red",
      "label": "Circle Red",
      "animated": true,
      "discordTag": "<a:tungsten_circle_red:1567234546586353686>",
      "id": "1567234546586353686",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234546586353686.gif"
    },
    {
      "name": "tungsten_circle_white",
      "label": "Circle White",
      "animated": true,
      "discordTag": "<a:tungsten_circle_white:1567234561799233547>",
      "id": "1567234561799233547",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234561799233547.gif"
    },
    {
      "name": "tungsten_circle_yellow",
      "label": "Circle Yellow",
      "animated": true,
      "discordTag": "<a:tungsten_circle_yellow:1567234580690501693>",
      "id": "1567234580690501693",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234580690501693.gif"
    },
    {
      "name": "tungsten_clapper",
      "label": "Clapper",
      "animated": true,
      "discordTag": "<a:tungsten_clapper:1567234599262879815>",
      "id": "1567234599262879815",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234599262879815.gif"
    },
    {
      "name": "tungsten_clipboard",
      "label": "Clipboard",
      "animated": true,
      "discordTag": "<a:tungsten_clipboard:1567234610176204900>",
      "id": "1567234610176204900",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234610176204900.gif"
    },
    {
      "name": "tungsten_clock",
      "label": "Clock",
      "animated": true,
      "discordTag": "<a:tungsten_clock:1567234623216554118>",
      "id": "1567234623216554118",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234623216554118.gif"
    },
    {
      "name": "tungsten_close",
      "label": "Close",
      "animated": true,
      "discordTag": "<a:tungsten_close:1567234632905138206>",
      "id": "1567234632905138206",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234632905138206.gif"
    },
    {
      "name": "tungsten_cmd_8ball",
      "label": "Cmd 8ball",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_8ball:1567234645140181082>",
      "id": "1567234645140181082",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234645140181082.gif"
    },
    {
      "name": "tungsten_cmd_addemoji",
      "label": "Cmd Addemoji",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_addemoji:1567234657026707537>",
      "id": "1567234657026707537",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234657026707537.gif"
    },
    {
      "name": "tungsten_cmd_afk",
      "label": "Cmd Afk",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_afk:1567234668347260938>",
      "id": "1567234668347260938",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234668347260938.gif"
    },
    {
      "name": "tungsten_cmd_anaudit",
      "label": "Cmd Anaudit",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_anaudit:1567234683937497259>",
      "id": "1567234683937497259",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234683937497259.gif"
    },
    {
      "name": "tungsten_cmd_anmode",
      "label": "Cmd Anmode",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_anmode:1567234697556271327>",
      "id": "1567234697556271327",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234697556271327.gif"
    },
    {
      "name": "tungsten_cmd_antighostping",
      "label": "Cmd Antighostping",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_antighostping:1567234715549835435>",
      "id": "1567234715549835435",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234715549835435.gif"
    },
    {
      "name": "tungsten_cmd_antinuke",
      "label": "Cmd Antinuke",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_antinuke:1567234734726316142>",
      "id": "1567234734726316142",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234734726316142.gif"
    },
    {
      "name": "tungsten_cmd_antiraid",
      "label": "Cmd Antiraid",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_antiraid:1567234763755102373>",
      "id": "1567234763755102373",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234763755102373.gif"
    },
    {
      "name": "tungsten_cmd_auditlog",
      "label": "Cmd Auditlog",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_auditlog:1567234776841195712>",
      "id": "1567234776841195712",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234776841195712.gif"
    },
    {
      "name": "tungsten_cmd_automod",
      "label": "Cmd Automod",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_automod:1567234793022689290>",
      "id": "1567234793022689290",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234793022689290.gif"
    },
    {
      "name": "tungsten_cmd_autoreact",
      "label": "Cmd Autoreact",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_autoreact:1567234807379922944>",
      "id": "1567234807379922944",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234807379922944.gif"
    },
    {
      "name": "tungsten_cmd_autoresponder",
      "label": "Cmd Autoresponder",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_autoresponder:1567234819992330240>",
      "id": "1567234819992330240",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234819992330240.gif"
    },
    {
      "name": "tungsten_cmd_autorole",
      "label": "Cmd Autorole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_autorole:1567234834504482948>",
      "id": "1567234834504482948",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234834504482948.gif"
    },
    {
      "name": "tungsten_cmd_avatar",
      "label": "Cmd Avatar",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_avatar:1567234845363540139>",
      "id": "1567234845363540139",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234845363540139.gif"
    }
  ],
  "1567213617215049854": [
    {
      "name": "tungsten_cmd_backup",
      "label": "Cmd Backup",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_backup:1567234860119236649>",
      "id": "1567234860119236649",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234860119236649.gif"
    },
    {
      "name": "tungsten_cmd_balance",
      "label": "Cmd Balance",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_balance:1567234874736250981>",
      "id": "1567234874736250981",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234874736250981.gif"
    },
    {
      "name": "tungsten_cmd_ban",
      "label": "Cmd Ban",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ban:1567234887503585321>",
      "id": "1567234887503585321",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234887503585321.gif"
    },
    {
      "name": "tungsten_cmd_banpanel",
      "label": "Cmd Banpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_banpanel:1567234900233552055>",
      "id": "1567234900233552055",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234900233552055.gif"
    },
    {
      "name": "tungsten_cmd_botinfo",
      "label": "Cmd Botinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_botinfo:1567234914867224616>",
      "id": "1567234914867224616",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234914867224616.gif"
    },
    {
      "name": "tungsten_cmd_cases",
      "label": "Cmd Cases",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_cases:1567234927450390658>",
      "id": "1567234927450390658",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234927450390658.gif"
    },
    {
      "name": "tungsten_cmd_celmod",
      "label": "Cmd Celmod",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_celmod:1567234939886370929>",
      "id": "1567234939886370929",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234939886370929.gif"
    },
    {
      "name": "tungsten_cmd_channelinfo",
      "label": "Cmd Channelinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_channelinfo:1567234953803210806>",
      "id": "1567234953803210806",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234953803210806.gif"
    },
    {
      "name": "tungsten_cmd_cleanup",
      "label": "Cmd Cleanup",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_cleanup:1567234967203745988>",
      "id": "1567234967203745988",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234967203745988.gif"
    },
    {
      "name": "tungsten_cmd_clearwarns",
      "label": "Cmd Clearwarns",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_clearwarns:1567234980797612133>",
      "id": "1567234980797612133",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234980797612133.gif"
    },
    {
      "name": "tungsten_cmd_cm",
      "label": "Cmd Cm",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_cm:1567234994768715806>",
      "id": "1567234994768715806",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567234994768715806.gif"
    },
    {
      "name": "tungsten_cmd_coinflip",
      "label": "Cmd Coinflip",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_coinflip:1567235008547258368>",
      "id": "1567235008547258368",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235008547258368.gif"
    },
    {
      "name": "tungsten_cmd_componentsv2",
      "label": "Cmd Componentsv2",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_componentsv2:1567235021910315069>",
      "id": "1567235021910315069",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235021910315069.gif"
    },
    {
      "name": "tungsten_cmd_connect4",
      "label": "Cmd Connect4",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_connect4:1567235052243517541>",
      "id": "1567235052243517541",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235052243517541.gif"
    },
    {
      "name": "tungsten_cmd_customcmd",
      "label": "Cmd Customcmd",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_customcmd:1567235065107452015>",
      "id": "1567235065107452015",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235065107452015.gif"
    },
    {
      "name": "tungsten_cmd_customrole",
      "label": "Cmd Customrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_customrole:1567235078654791690>",
      "id": "1567235078654791690",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235078654791690.gif"
    },
    {
      "name": "tungsten_cmd_daily",
      "label": "Cmd Daily",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_daily:1567235093611675650>",
      "id": "1567235093611675650",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235093611675650.gif"
    },
    {
      "name": "tungsten_cmd_database",
      "label": "Cmd Database",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_database:1567235125513687152>",
      "id": "1567235125513687152",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235125513687152.gif"
    },
    {
      "name": "tungsten_cmd_deleteemoji",
      "label": "Cmd Deleteemoji",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_deleteemoji:1567235155574267935>",
      "id": "1567235155574267935",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235155574267935.gif"
    },
    {
      "name": "tungsten_cmd_deposit",
      "label": "Cmd Deposit",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_deposit:1567235175472041994>",
      "id": "1567235175472041994",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235175472041994.gif"
    },
    {
      "name": "tungsten_cmd_duty",
      "label": "Cmd Duty",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_duty:1567235200541528074>",
      "id": "1567235200541528074",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235200541528074.gif"
    },
    {
      "name": "tungsten_cmd_emergency",
      "label": "Cmd Emergency",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emergency:1567235226504134656>",
      "id": "1567235226504134656",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235226504134656.gif"
    },
    {
      "name": "tungsten_cmd_emojilist",
      "label": "Cmd Emojilist",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emojilist:1567235260012298260>",
      "id": "1567235260012298260",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235260012298260.gif"
    },
    {
      "name": "tungsten_cmd_emojipack",
      "label": "Cmd Emojipack",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emojipack:1567235282489839766>",
      "id": "1567235282489839766",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235282489839766.gif"
    },
    {
      "name": "tungsten_cmd_emojiserver",
      "label": "Cmd Emojiserver",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_emojiserver:1567235306711818290>",
      "id": "1567235306711818290",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235306711818290.gif"
    },
    {
      "name": "tungsten_cmd_extraowner",
      "label": "Cmd Extraowner",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_extraowner:1567235342850064407>",
      "id": "1567235342850064407",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235342850064407.gif"
    },
    {
      "name": "tungsten_cmd_gif",
      "label": "Cmd Gif",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_gif:1567235366665326693>",
      "id": "1567235366665326693",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235366665326693.gif"
    },
    {
      "name": "tungsten_cmd_giveaway",
      "label": "Cmd Giveaway",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_giveaway:1567235389226352785>",
      "id": "1567235389226352785",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235389226352785.gif"
    },
    {
      "name": "tungsten_cmd_giverole",
      "label": "Cmd Giverole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_giverole:1567235411615678545>",
      "id": "1567235411615678545",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235411615678545.gif"
    },
    {
      "name": "tungsten_cmd_help",
      "label": "Cmd Help",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_help:1567235431567724626>",
      "id": "1567235431567724626",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235431567724626.gif"
    },
    {
      "name": "tungsten_cmd_hide",
      "label": "Cmd Hide",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_hide:1567235456494731295>",
      "id": "1567235456494731295",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235456494731295.gif"
    },
    {
      "name": "tungsten_cmd_inrole",
      "label": "Cmd Inrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_inrole:1567235483904249897>",
      "id": "1567235483904249897",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235483904249897.gif"
    },
    {
      "name": "tungsten_cmd_investigate",
      "label": "Cmd Investigate",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_investigate:1567235510517375127>",
      "id": "1567235510517375127",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235510517375127.gif"
    },
    {
      "name": "tungsten_cmd_invite",
      "label": "Cmd Invite",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_invite:1567235535573885110>",
      "id": "1567235535573885110",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235535573885110.gif"
    },
    {
      "name": "tungsten_cmd_joke",
      "label": "Cmd Joke",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_joke:1567235558705598494>",
      "id": "1567235558705598494",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235558705598494.gif"
    },
    {
      "name": "tungsten_cmd_kick",
      "label": "Cmd Kick",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_kick:1567235578293129256>",
      "id": "1567235578293129256",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235578293129256.gif"
    },
    {
      "name": "tungsten_cmd_kickpanel",
      "label": "Cmd Kickpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_kickpanel:1567235599557984417>",
      "id": "1567235599557984417",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235599557984417.gif"
    },
    {
      "name": "tungsten_cmd_leaderboard",
      "label": "Cmd Leaderboard",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_leaderboard:1567235635331473509>",
      "id": "1567235635331473509",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235635331473509.gif"
    },
    {
      "name": "tungsten_cmd_leave",
      "label": "Cmd Leave",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_leave:1567235657783447573>",
      "id": "1567235657783447573",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235657783447573.gif"
    },
    {
      "name": "tungsten_cmd_levels",
      "label": "Cmd Levels",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_levels:1567235696920371301>",
      "id": "1567235696920371301",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235696920371301.gif"
    },
    {
      "name": "tungsten_cmd_lock",
      "label": "Cmd Lock",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_lock:1567235715983609857>",
      "id": "1567235715983609857",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235715983609857.gif"
    },
    {
      "name": "tungsten_cmd_lockpanel",
      "label": "Cmd Lockpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_lockpanel:1567235752344035459>",
      "id": "1567235752344035459",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235752344035459.gif"
    },
    {
      "name": "tungsten_cmd_membercount",
      "label": "Cmd Membercount",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_membercount:1567235784182857868>",
      "id": "1567235784182857868",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235784182857868.gif"
    },
    {
      "name": "tungsten_cmd_meme",
      "label": "Cmd Meme",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_meme:1567235815833337940>",
      "id": "1567235815833337940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235815833337940.gif"
    },
    {
      "name": "tungsten_cmd_modpanel",
      "label": "Cmd Modpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_modpanel:1567235859063906364>",
      "id": "1567235859063906364",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235859063906364.gif"
    },
    {
      "name": "tungsten_cmd_modrolepanel",
      "label": "Cmd Modrolepanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_modrolepanel:1567235913829056616>",
      "id": "1567235913829056616",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235913829056616.gif"
    },
    {
      "name": "tungsten_cmd_mute",
      "label": "Cmd Mute",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_mute:1567235956644253696>",
      "id": "1567235956644253696",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235956644253696.gif"
    }
  ],
  "1566764668779761906": [
    {
      "name": "tungsten_cmd_mutepanel",
      "label": "Cmd Mutepanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_mutepanel:1567235994359562391>",
      "id": "1567235994359562391",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567235994359562391.gif"
    },
    {
      "name": "tungsten_cmd_nightmode",
      "label": "Cmd Nightmode",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_nightmode:1567236036550074390>",
      "id": "1567236036550074390",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236036550074390.gif"
    },
    {
      "name": "tungsten_cmd_noprefix",
      "label": "Cmd Noprefix",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_noprefix:1567236069643132972>",
      "id": "1567236069643132972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236069643132972.gif"
    },
    {
      "name": "tungsten_cmd_npmanager",
      "label": "Cmd Npmanager",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_npmanager:1567236115197591596>",
      "id": "1567236115197591596",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236115197591596.gif"
    },
    {
      "name": "tungsten_cmd_nuke",
      "label": "Cmd Nuke",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_nuke:1567236137746169887>",
      "id": "1567236137746169887",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236137746169887.gif"
    },
    {
      "name": "tungsten_cmd_ownerpanel",
      "label": "Cmd Ownerpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ownerpanel:1567236155634622514>",
      "id": "1567236155634622514",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236155634622514.gif"
    },
    {
      "name": "tungsten_cmd_panel",
      "label": "Cmd Panel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_panel:1567236187700338759>",
      "id": "1567236187700338759",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236187700338759.gif"
    },
    {
      "name": "tungsten_cmd_panic",
      "label": "Cmd Panic",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_panic:1567236213897822388>",
      "id": "1567236213897822388",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236213897822388.gif"
    },
    {
      "name": "tungsten_cmd_pay",
      "label": "Cmd Pay",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_pay:1567236244205867130>",
      "id": "1567236244205867130",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236244205867130.gif"
    },
    {
      "name": "tungsten_cmd_ping",
      "label": "Cmd Ping",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ping:1567236300271255715>",
      "id": "1567236300271255715",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236300271255715.gif"
    },
    {
      "name": "tungsten_cmd_pings",
      "label": "Cmd Pings",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_pings:1567236330038235206>",
      "id": "1567236330038235206",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236330038235206.gif"
    },
    {
      "name": "tungsten_cmd_prefix",
      "label": "Cmd Prefix",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_prefix:1567236353924792524>",
      "id": "1567236353924792524",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236353924792524.gif"
    },
    {
      "name": "tungsten_cmd_premium",
      "label": "Cmd Premium",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_premium:1567236385734139966>",
      "id": "1567236385734139966",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236385734139966.gif"
    },
    {
      "name": "tungsten_cmd_premiummanager",
      "label": "Cmd Premiummanager",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_premiummanager:1567236418634252458>",
      "id": "1567236418634252458",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236418634252458.gif"
    },
    {
      "name": "tungsten_cmd_profile",
      "label": "Cmd Profile",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_profile:1567236443917525154>",
      "id": "1567236443917525154",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236443917525154.gif"
    },
    {
      "name": "tungsten_cmd_purge",
      "label": "Cmd Purge",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_purge:1567236474280083516>",
      "id": "1567236474280083516",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236474280083516.gif"
    },
    {
      "name": "tungsten_cmd_purgepanel",
      "label": "Cmd Purgepanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_purgepanel:1567236525425430749>",
      "id": "1567236525425430749",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236525425430749.gif"
    },
    {
      "name": "tungsten_cmd_reactionrole",
      "label": "Cmd Reactionrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_reactionrole:1567236559248429167>",
      "id": "1567236559248429167",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236559248429167.gif"
    },
    {
      "name": "tungsten_cmd_removerole",
      "label": "Cmd Removerole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_removerole:1567236636641599548>",
      "id": "1567236636641599548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236636641599548.gif"
    },
    {
      "name": "tungsten_cmd_rob",
      "label": "Cmd Rob",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_rob:1567236704203571431>",
      "id": "1567236704203571431",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236704203571431.gif"
    },
    {
      "name": "tungsten_cmd_roleinfo",
      "label": "Cmd Roleinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_roleinfo:1567236816225046629>",
      "id": "1567236816225046629",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236816225046629.gif"
    },
    {
      "name": "tungsten_cmd_roll",
      "label": "Cmd Roll",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_roll:1567236993287725196>",
      "id": "1567236993287725196",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567236993287725196.gif"
    },
    {
      "name": "tungsten_cmd_rps",
      "label": "Cmd Rps",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_rps:1567237016662577224>",
      "id": "1567237016662577224",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237016662577224.gif"
    },
    {
      "name": "tungsten_cmd_securityscore",
      "label": "Cmd Securityscore",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_securityscore:1567237039135400067>",
      "id": "1567237039135400067",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237039135400067.gif"
    },
    {
      "name": "tungsten_cmd_serverinfo",
      "label": "Cmd Serverinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_serverinfo:1567237069502287923>",
      "id": "1567237069502287923",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237069502287923.gif"
    },
    {
      "name": "tungsten_cmd_sethomevc",
      "label": "Cmd Sethomevc",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_sethomevc:1567237101341380720>",
      "id": "1567237101341380720",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237101341380720.gif"
    },
    {
      "name": "tungsten_cmd_ship",
      "label": "Cmd Ship",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ship:1567237143049539777>",
      "id": "1567237143049539777",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237143049539777.gif"
    },
    {
      "name": "tungsten_cmd_slots",
      "label": "Cmd Slots",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_slots:1567237210565120220>",
      "id": "1567237210565120220",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237210565120220.gif"
    },
    {
      "name": "tungsten_cmd_slowmode",
      "label": "Cmd Slowmode",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_slowmode:1567237253061804164>",
      "id": "1567237253061804164",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237253061804164.gif"
    },
    {
      "name": "tungsten_cmd_snipe",
      "label": "Cmd Snipe",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_snipe:1567237311106777210>",
      "id": "1567237311106777210",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237311106777210.gif"
    },
    {
      "name": "tungsten_cmd_softban",
      "label": "Cmd Softban",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_softban:1567237338374086719>",
      "id": "1567237338374086719",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237338374086719.gif"
    },
    {
      "name": "tungsten_cmd_stats",
      "label": "Cmd Stats",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_stats:1567237361664925757>",
      "id": "1567237361664925757",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237361664925757.gif"
    },
    {
      "name": "tungsten_cmd_stickymessage",
      "label": "Cmd Stickymessage",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_stickymessage:1567237387925454968>",
      "id": "1567237387925454968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237387925454968.gif"
    },
    {
      "name": "tungsten_cmd_support",
      "label": "Cmd Support",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_support:1567237424843591770>",
      "id": "1567237424843591770",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237424843591770.gif"
    },
    {
      "name": "tungsten_cmd_ticket",
      "label": "Cmd Ticket",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_ticket:1567237476173619345>",
      "id": "1567237476173619345",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237476173619345.gif"
    },
    {
      "name": "tungsten_cmd_trivia",
      "label": "Cmd Trivia",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_trivia:1567237570192998610>",
      "id": "1567237570192998610",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237570192998610.gif"
    },
    {
      "name": "tungsten_cmd_unban",
      "label": "Cmd Unban",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unban:1567237654230208743>",
      "id": "1567237654230208743",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237654230208743.gif"
    },
    {
      "name": "tungsten_cmd_unhide",
      "label": "Cmd Unhide",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unhide:1567237716330946600>",
      "id": "1567237716330946600",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237716330946600.gif"
    },
    {
      "name": "tungsten_cmd_unlock",
      "label": "Cmd Unlock",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unlock:1567237734299467886>",
      "id": "1567237734299467886",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237734299467886.gif"
    },
    {
      "name": "tungsten_cmd_unmute",
      "label": "Cmd Unmute",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unmute:1567237746697961612>",
      "id": "1567237746697961612",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237746697961612.gif"
    },
    {
      "name": "tungsten_cmd_unwhitelist",
      "label": "Cmd Unwhitelist",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_unwhitelist:1567237762376273990>",
      "id": "1567237762376273990",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237762376273990.gif"
    },
    {
      "name": "tungsten_cmd_uptime",
      "label": "Cmd Uptime",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_uptime:1567237782605398036>",
      "id": "1567237782605398036",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237782605398036.gif"
    },
    {
      "name": "tungsten_cmd_userinfo",
      "label": "Cmd Userinfo",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_userinfo:1567237805266964481>",
      "id": "1567237805266964481",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237805266964481.gif"
    },
    {
      "name": "tungsten_cmd_vanityguard",
      "label": "Cmd Vanityguard",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_vanityguard:1567237826154602613>",
      "id": "1567237826154602613",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237826154602613.gif"
    },
    {
      "name": "tungsten_cmd_vcrole",
      "label": "Cmd Vcrole",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_vcrole:1567237847486832640>",
      "id": "1567237847486832640",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237847486832640.gif"
    },
    {
      "name": "tungsten_cmd_vcstatus",
      "label": "Cmd Vcstatus",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_vcstatus:1567237869133635628>",
      "id": "1567237869133635628",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237869133635628.gif"
    },
    {
      "name": "tungsten_cmd_voice",
      "label": "Cmd Voice",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_voice:1567237893590753360>",
      "id": "1567237893590753360",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237893590753360.gif"
    }
  ],
  "1567216768018022540": [
    {
      "name": "tungsten_cmd_voicemod",
      "label": "Cmd Voicemod",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_voicemod:1567237946053099530>",
      "id": "1567237946053099530",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567237946053099530.gif"
    },
    {
      "name": "tungsten_cmd_warn",
      "label": "Cmd Warn",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_warn:1567238033705799771>",
      "id": "1567238033705799771",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238033705799771.gif"
    },
    {
      "name": "tungsten_cmd_warnings",
      "label": "Cmd Warnings",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_warnings:1567238062759739435>",
      "id": "1567238062759739435",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238062759739435.gif"
    },
    {
      "name": "tungsten_cmd_warnpanel",
      "label": "Cmd Warnpanel",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_warnpanel:1567238091708702792>",
      "id": "1567238091708702792",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238091708702792.gif"
    },
    {
      "name": "tungsten_cmd_welcome",
      "label": "Cmd Welcome",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_welcome:1567238123807842346>",
      "id": "1567238123807842346",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238123807842346.gif"
    },
    {
      "name": "tungsten_cmd_whitelist",
      "label": "Cmd Whitelist",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_whitelist:1567238164991451146>",
      "id": "1567238164991451146",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238164991451146.gif"
    },
    {
      "name": "tungsten_cmd_whitelisted",
      "label": "Cmd Whitelisted",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_whitelisted:1567238207295455329>",
      "id": "1567238207295455329",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238207295455329.gif"
    },
    {
      "name": "tungsten_cmd_withdraw",
      "label": "Cmd Withdraw",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_withdraw:1567238237108310077>",
      "id": "1567238237108310077",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238237108310077.gif"
    },
    {
      "name": "tungsten_cmd_work",
      "label": "Cmd Work",
      "animated": true,
      "discordTag": "<a:tungsten_cmd_work:1567238276161601567>",
      "id": "1567238276161601567",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238276161601567.gif"
    },
    {
      "name": "tungsten_coin",
      "label": "Coin",
      "animated": true,
      "discordTag": "<a:tungsten_coin:1567238316967985244>",
      "id": "1567238316967985244",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238316967985244.gif"
    },
    {
      "name": "tungsten_crown",
      "label": "Crown",
      "animated": true,
      "discordTag": "<a:tungsten_crown:1567238355463176334>",
      "id": "1567238355463176334",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238355463176334.gif"
    },
    {
      "name": "tungsten_crystal",
      "label": "Crystal",
      "animated": true,
      "discordTag": "<a:tungsten_crystal:1567238398400532571>",
      "id": "1567238398400532571",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238398400532571.gif"
    },
    {
      "name": "tungsten_dancer",
      "label": "Dancer",
      "animated": true,
      "discordTag": "<a:tungsten_dancer:1567238442092601424>",
      "id": "1567238442092601424",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238442092601424.gif"
    },
    {
      "name": "tungsten_database",
      "label": "Database",
      "animated": true,
      "discordTag": "<a:tungsten_database:1567238475684651168>",
      "id": "1567238475684651168",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238475684651168.gif"
    },
    {
      "name": "tungsten_diamond_small",
      "label": "Diamond Small",
      "animated": true,
      "discordTag": "<a:tungsten_diamond_small:1567238516855939283>",
      "id": "1567238516855939283",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238516855939283.gif"
    },
    {
      "name": "tungsten_dice",
      "label": "Dice",
      "animated": true,
      "discordTag": "<a:tungsten_dice:1567238580827328582>",
      "id": "1567238580827328582",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238580827328582.gif"
    },
    {
      "name": "tungsten_door",
      "label": "Door",
      "animated": true,
      "discordTag": "<a:tungsten_door:1567238621432643794>",
      "id": "1567238621432643794",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238621432643794.gif"
    },
    {
      "name": "tungsten_drama",
      "label": "Drama",
      "animated": true,
      "discordTag": "<a:tungsten_drama:1567238681557991474>",
      "id": "1567238681557991474",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238681557991474.gif"
    },
    {
      "name": "tungsten_eightball",
      "label": "Eightball",
      "animated": true,
      "discordTag": "<a:tungsten_eightball:1567238723995967638>",
      "id": "1567238723995967638",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238723995967638.gif"
    },
    {
      "name": "tungsten_error",
      "label": "Error",
      "animated": true,
      "discordTag": "<a:tungsten_error:1567238753284653106>",
      "id": "1567238753284653106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238753284653106.gif"
    },
    {
      "name": "tungsten_explosion",
      "label": "Explosion",
      "animated": true,
      "discordTag": "<a:tungsten_explosion:1567238834343911554>",
      "id": "1567238834343911554",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238834343911554.gif"
    },
    {
      "name": "tungsten_eye",
      "label": "Eye",
      "animated": true,
      "discordTag": "<a:tungsten_eye:1567238862042833088>",
      "id": "1567238862042833088",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238862042833088.gif"
    },
    {
      "name": "tungsten_eye_slash",
      "label": "Eye Slash",
      "animated": true,
      "discordTag": "<a:tungsten_eye_slash:1567238896612282430>",
      "id": "1567238896612282430",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238896612282430.gif"
    },
    {
      "name": "tungsten_eyes",
      "label": "Eyes",
      "animated": true,
      "discordTag": "<a:tungsten_eyes:1567238923913011254>",
      "id": "1567238923913011254",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238923913011254.gif"
    },
    {
      "name": "tungsten_face_angry",
      "label": "Face Angry",
      "animated": true,
      "discordTag": "<a:tungsten_face_angry:1567238949284618291>",
      "id": "1567238949284618291",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238949284618291.gif"
    },
    {
      "name": "tungsten_face_cool",
      "label": "Face Cool",
      "animated": true,
      "discordTag": "<a:tungsten_face_cool:1567238977264685118>",
      "id": "1567238977264685118",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567238977264685118.gif"
    },
    {
      "name": "tungsten_face_crazy",
      "label": "Face Crazy",
      "animated": true,
      "discordTag": "<a:tungsten_face_crazy:1567239007463669832>",
      "id": "1567239007463669832",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239007463669832.gif"
    },
    {
      "name": "tungsten_face_cry",
      "label": "Face Cry",
      "animated": true,
      "discordTag": "<a:tungsten_face_cry:1567239031735980053>",
      "id": "1567239031735980053",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239031735980053.gif"
    },
    {
      "name": "tungsten_face_devil",
      "label": "Face Devil",
      "animated": true,
      "discordTag": "<a:tungsten_face_devil:1567239058327871564>",
      "id": "1567239058327871564",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239058327871564.gif"
    },
    {
      "name": "tungsten_face_flushed",
      "label": "Face Flushed",
      "animated": true,
      "discordTag": "<a:tungsten_face_flushed:1567239086484357130>",
      "id": "1567239086484357130",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239086484357130.gif"
    },
    {
      "name": "tungsten_face_grin",
      "label": "Face Grin",
      "animated": true,
      "discordTag": "<a:tungsten_face_grin:1567239115089514536>",
      "id": "1567239115089514536",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239115089514536.gif"
    },
    {
      "name": "tungsten_face_laugh",
      "label": "Face Laugh",
      "animated": true,
      "discordTag": "<a:tungsten_face_laugh:1567239143048613900>",
      "id": "1567239143048613900",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239143048613900.gif"
    },
    {
      "name": "tungsten_face_love",
      "label": "Face Love",
      "animated": true,
      "discordTag": "<a:tungsten_face_love:1567239175110140056>",
      "id": "1567239175110140056",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239175110140056.gif"
    },
    {
      "name": "tungsten_face_melting",
      "label": "Face Melting",
      "animated": true,
      "discordTag": "<a:tungsten_face_melting:1567239201269743827>",
      "id": "1567239201269743827",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239201269743827.gif"
    },
    {
      "name": "tungsten_face_pleading",
      "label": "Face Pleading",
      "animated": true,
      "discordTag": "<a:tungsten_face_pleading:1567239233788448939>",
      "id": "1567239233788448939",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239233788448939.gif"
    },
    {
      "name": "tungsten_face_scared",
      "label": "Face Scared",
      "animated": true,
      "discordTag": "<a:tungsten_face_scared:1567239267774763038>",
      "id": "1567239267774763038",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239267774763038.gif"
    },
    {
      "name": "tungsten_face_sleep",
      "label": "Face Sleep",
      "animated": true,
      "discordTag": "<a:tungsten_face_sleep:1567239295914213548>",
      "id": "1567239295914213548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239295914213548.gif"
    },
    {
      "name": "tungsten_face_smile",
      "label": "Face Smile",
      "animated": true,
      "discordTag": "<a:tungsten_face_smile:1567239325941375126>",
      "id": "1567239325941375126",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239325941375126.gif"
    },
    {
      "name": "tungsten_face_surprised",
      "label": "Face Surprised",
      "animated": true,
      "discordTag": "<a:tungsten_face_surprised:1567239358975582248>",
      "id": "1567239358975582248",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239358975582248.gif"
    },
    {
      "name": "tungsten_face_wink",
      "label": "Face Wink",
      "animated": true,
      "discordTag": "<a:tungsten_face_wink:1567239380244897846>",
      "id": "1567239380244897846",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239380244897846.gif"
    },
    {
      "name": "tungsten_fist",
      "label": "Fist",
      "animated": true,
      "discordTag": "<a:tungsten_fist:1567239431444897892>",
      "id": "1567239431444897892",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239431444897892.gif"
    },
    {
      "name": "tungsten_flag_chequered",
      "label": "Flag Chequered",
      "animated": true,
      "discordTag": "<a:tungsten_flag_chequered:1567239507135307972>",
      "id": "1567239507135307972",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239507135307972.gif"
    },
    {
      "name": "tungsten_flag_white",
      "label": "Flag White",
      "animated": true,
      "discordTag": "<a:tungsten_flag_white:1567239547769589771>",
      "id": "1567239547769589771",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239547769589771.gif"
    },
    {
      "name": "tungsten_folder",
      "label": "Folder",
      "animated": true,
      "discordTag": "<a:tungsten_folder:1567239623145558046>",
      "id": "1567239623145558046",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239623145558046.gif"
    },
    {
      "name": "tungsten_folder_open",
      "label": "Folder Open",
      "animated": true,
      "discordTag": "<a:tungsten_folder_open:1567239652501495988>",
      "id": "1567239652501495988",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239652501495988.gif"
    },
    {
      "name": "tungsten_foot",
      "label": "Foot",
      "animated": true,
      "discordTag": "<a:tungsten_foot:1567239740942458880>",
      "id": "1567239740942458880",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239740942458880.gif"
    },
    {
      "name": "tungsten_frame",
      "label": "Frame",
      "animated": true,
      "discordTag": "<a:tungsten_frame:1567239867983863889>",
      "id": "1567239867983863889",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239867983863889.gif"
    }
  ],
  "1567217022444773561": [
    {
      "name": "tungsten_gamepad",
      "label": "Gamepad",
      "animated": true,
      "discordTag": "<a:tungsten_gamepad:1567239909985616063>",
      "id": "1567239909985616063",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239909985616063.gif"
    },
    {
      "name": "tungsten_gear",
      "label": "Gear",
      "animated": true,
      "discordTag": "<a:tungsten_gear:1567239932970406012>",
      "id": "1567239932970406012",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239932970406012.gif"
    },
    {
      "name": "tungsten_gem",
      "label": "Gem",
      "animated": true,
      "discordTag": "<a:tungsten_gem:1567239960837357759>",
      "id": "1567239960837357759",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239960837357759.gif"
    },
    {
      "name": "tungsten_gem_flower",
      "label": "Gem Flower",
      "animated": true,
      "discordTag": "<a:tungsten_gem_flower:1567239998779031595>",
      "id": "1567239998779031595",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567239998779031595.gif"
    },
    {
      "name": "tungsten_ghost",
      "label": "Ghost",
      "animated": true,
      "discordTag": "<a:tungsten_ghost:1567240021692518512>",
      "id": "1567240021692518512",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240021692518512.gif"
    },
    {
      "name": "tungsten_gift",
      "label": "Gift",
      "animated": true,
      "discordTag": "<a:tungsten_gift:1567240042563244072>",
      "id": "1567240042563244072",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240042563244072.gif"
    },
    {
      "name": "tungsten_globe",
      "label": "Globe",
      "animated": true,
      "discordTag": "<a:tungsten_globe:1567240068253622433>",
      "id": "1567240068253622433",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240068253622433.gif"
    },
    {
      "name": "tungsten_grapes",
      "label": "Grapes",
      "animated": true,
      "discordTag": "<a:tungsten_grapes:1567240092739833866>",
      "id": "1567240092739833866",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240092739833866.gif"
    },
    {
      "name": "tungsten_gun",
      "label": "Gun",
      "animated": true,
      "discordTag": "<a:tungsten_gun:1567240119612874822>",
      "id": "1567240119612874822",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240119612874822.gif"
    },
    {
      "name": "tungsten_hammer",
      "label": "Hammer",
      "animated": true,
      "discordTag": "<a:tungsten_hammer:1567240140277944350>",
      "id": "1567240140277944350",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240140277944350.gif"
    },
    {
      "name": "tungsten_hands_up",
      "label": "Hands Up",
      "animated": true,
      "discordTag": "<a:tungsten_hands_up:1567240175594250302>",
      "id": "1567240175594250302",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240175594250302.gif"
    },
    {
      "name": "tungsten_handshake",
      "label": "Handshake",
      "animated": true,
      "discordTag": "<a:tungsten_handshake:1567240195646951494>",
      "id": "1567240195646951494",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240195646951494.gif"
    },
    {
      "name": "tungsten_headphones",
      "label": "Headphones",
      "animated": true,
      "discordTag": "<a:tungsten_headphones:1567240226789785730>",
      "id": "1567240226789785730",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240226789785730.gif"
    },
    {
      "name": "tungsten_heart",
      "label": "Heart",
      "animated": true,
      "discordTag": "<a:tungsten_heart:1567240255680155718>",
      "id": "1567240255680155718",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240255680155718.gif"
    },
    {
      "name": "tungsten_heart_broken",
      "label": "Heart Broken",
      "animated": true,
      "discordTag": "<a:tungsten_heart_broken:1567240285053001738>",
      "id": "1567240285053001738",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240285053001738.gif"
    },
    {
      "name": "tungsten_heart_orange",
      "label": "Heart Orange",
      "animated": true,
      "discordTag": "<a:tungsten_heart_orange:1567240324336582743>",
      "id": "1567240324336582743",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240324336582743.gif"
    },
    {
      "name": "tungsten_heart_sparkle",
      "label": "Heart Sparkle",
      "animated": true,
      "discordTag": "<a:tungsten_heart_sparkle:1567240386659885106>",
      "id": "1567240386659885106",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240386659885106.gif"
    },
    {
      "name": "tungsten_heart_yellow",
      "label": "Heart Yellow",
      "animated": true,
      "discordTag": "<a:tungsten_heart_yellow:1567240422068068529>",
      "id": "1567240422068068529",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240422068068529.gif"
    },
    {
      "name": "tungsten_hearts",
      "label": "Hearts",
      "animated": true,
      "discordTag": "<a:tungsten_hearts:1567240511670976552>",
      "id": "1567240511670976552",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240511670976552.gif"
    },
    {
      "name": "tungsten_home",
      "label": "Home",
      "animated": true,
      "discordTag": "<a:tungsten_home:1567240545661620387>",
      "id": "1567240545661620387",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240545661620387.gif"
    },
    {
      "name": "tungsten_hourglass",
      "label": "Hourglass",
      "animated": true,
      "discordTag": "<a:tungsten_hourglass:1567240660702986281>",
      "id": "1567240660702986281",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240660702986281.gif"
    },
    {
      "name": "tungsten_id",
      "label": "Id",
      "animated": true,
      "discordTag": "<a:tungsten_id:1567240689048355008>",
      "id": "1567240689048355008",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240689048355008.gif"
    },
    {
      "name": "tungsten_inbox",
      "label": "Inbox",
      "animated": true,
      "discordTag": "<a:tungsten_inbox:1567240785219289108>",
      "id": "1567240785219289108",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240785219289108.gif"
    },
    {
      "name": "tungsten_infinity",
      "label": "Infinity",
      "animated": true,
      "discordTag": "<a:tungsten_infinity:1567240813895745626>",
      "id": "1567240813895745626",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240813895745626.gif"
    },
    {
      "name": "tungsten_info",
      "label": "Info",
      "animated": true,
      "discordTag": "<a:tungsten_info:1567240890748248084>",
      "id": "1567240890748248084",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240890748248084.gif"
    },
    {
      "name": "tungsten_key",
      "label": "Key",
      "animated": true,
      "discordTag": "<a:tungsten_key:1567240907684581492>",
      "id": "1567240907684581492",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240907684581492.gif"
    },
    {
      "name": "tungsten_keycap_ten",
      "label": "Keycap Ten",
      "animated": true,
      "discordTag": "<a:tungsten_keycap_ten:1567240934599688303>",
      "id": "1567240934599688303",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240934599688303.gif"
    },
    {
      "name": "tungsten_keylock",
      "label": "Keylock",
      "animated": true,
      "discordTag": "<a:tungsten_keylock:1567240958075084951>",
      "id": "1567240958075084951",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240958075084951.gif"
    },
    {
      "name": "tungsten_knife",
      "label": "Knife",
      "animated": true,
      "discordTag": "<a:tungsten_knife:1567240975758270495>",
      "id": "1567240975758270495",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240975758270495.gif"
    },
    {
      "name": "tungsten_lemon",
      "label": "Lemon",
      "animated": true,
      "discordTag": "<a:tungsten_lemon:1567240998231343184>",
      "id": "1567240998231343184",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567240998231343184.gif"
    },
    {
      "name": "tungsten_link",
      "label": "Link",
      "animated": true,
      "discordTag": "<a:tungsten_link:1567241025813086210>",
      "id": "1567241025813086210",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241025813086210.gif"
    },
    {
      "name": "tungsten_loading",
      "label": "Loading",
      "animated": true,
      "discordTag": "<a:tungsten_loading:1567241050567876698>",
      "id": "1567241050567876698",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241050567876698.gif"
    },
    {
      "name": "tungsten_lock",
      "label": "Lock",
      "animated": true,
      "discordTag": "<a:tungsten_lock:1567241079030550668>",
      "id": "1567241079030550668",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241079030550668.gif"
    },
    {
      "name": "tungsten_mailbox",
      "label": "Mailbox",
      "animated": true,
      "discordTag": "<a:tungsten_mailbox:1567241098009509949>",
      "id": "1567241098009509949",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241098009509949.gif"
    },
    {
      "name": "tungsten_medal_bronze",
      "label": "Medal Bronze",
      "animated": true,
      "discordTag": "<a:tungsten_medal_bronze:1567241129030582403>",
      "id": "1567241129030582403",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241129030582403.gif"
    },
    {
      "name": "tungsten_medal_gold",
      "label": "Medal Gold",
      "animated": true,
      "discordTag": "<a:tungsten_medal_gold:1567241163453366472>",
      "id": "1567241163453366472",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241163453366472.gif"
    },
    {
      "name": "tungsten_medal_silver",
      "label": "Medal Silver",
      "animated": true,
      "discordTag": "<a:tungsten_medal_silver:1567241205409128649>",
      "id": "1567241205409128649",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241205409128649.gif"
    },
    {
      "name": "tungsten_memo",
      "label": "Memo",
      "animated": true,
      "discordTag": "<a:tungsten_memo:1567241226577780957>",
      "id": "1567241226577780957",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241226577780957.gif"
    },
    {
      "name": "tungsten_mic",
      "label": "Mic",
      "animated": true,
      "discordTag": "<a:tungsten_mic:1567241257862832189>",
      "id": "1567241257862832189",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241257862832189.gif"
    },
    {
      "name": "tungsten_minus",
      "label": "Minus",
      "animated": true,
      "discordTag": "<a:tungsten_minus:1567241276057849856>",
      "id": "1567241276057849856",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241276057849856.gif"
    },
    {
      "name": "tungsten_money_wings",
      "label": "Money Wings",
      "animated": true,
      "discordTag": "<a:tungsten_money_wings:1567241294408061024>",
      "id": "1567241294408061024",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241294408061024.gif"
    },
    {
      "name": "tungsten_moneybag",
      "label": "Moneybag",
      "animated": true,
      "discordTag": "<a:tungsten_moneybag:1567241334698541109>",
      "id": "1567241334698541109",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241334698541109.gif"
    },
    {
      "name": "tungsten_monitor",
      "label": "Monitor",
      "animated": true,
      "discordTag": "<a:tungsten_monitor:1567241360984121485>",
      "id": "1567241360984121485",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241360984121485.gif"
    },
    {
      "name": "tungsten_moon",
      "label": "Moon",
      "animated": true,
      "discordTag": "<a:tungsten_moon:1567241385021673674>",
      "id": "1567241385021673674",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241385021673674.gif"
    },
    {
      "name": "tungsten_music",
      "label": "Music",
      "animated": true,
      "discordTag": "<a:tungsten_music:1567241425328939110>",
      "id": "1567241425328939110",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241425328939110.gif"
    },
    {
      "name": "tungsten_mute",
      "label": "Mute",
      "animated": true,
      "discordTag": "<a:tungsten_mute:1567241451992121647>",
      "id": "1567241451992121647",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241451992121647.gif"
    },
    {
      "name": "tungsten_nametag",
      "label": "Nametag",
      "animated": true,
      "discordTag": "<a:tungsten_nametag:1567241539082526760>",
      "id": "1567241539082526760",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241539082526760.gif"
    }
  ],
  "1567217408312344680": [
    {
      "name": "tungsten_ninja",
      "label": "Ninja",
      "animated": true,
      "discordTag": "<a:tungsten_ninja:1567241598260093050>",
      "id": "1567241598260093050",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241598260093050.gif"
    },
    {
      "name": "tungsten_notepad",
      "label": "Notepad",
      "animated": true,
      "discordTag": "<a:tungsten_notepad:1567241681911152733>",
      "id": "1567241681911152733",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241681911152733.gif"
    },
    {
      "name": "tungsten_package",
      "label": "Package",
      "animated": true,
      "discordTag": "<a:tungsten_package:1567241719177543862>",
      "id": "1567241719177543862",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241719177543862.gif"
    },
    {
      "name": "tungsten_palette",
      "label": "Palette",
      "animated": true,
      "discordTag": "<a:tungsten_palette:1567241748613169344>",
      "id": "1567241748613169344",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241748613169344.gif"
    },
    {
      "name": "tungsten_party",
      "label": "Party",
      "animated": true,
      "discordTag": "<a:tungsten_party:1567241769593339988>",
      "id": "1567241769593339988",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241769593339988.gif"
    },
    {
      "name": "tungsten_person",
      "label": "Person",
      "animated": true,
      "discordTag": "<a:tungsten_person:1567241792150175834>",
      "id": "1567241792150175834",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241792150175834.gif"
    },
    {
      "name": "tungsten_pin",
      "label": "Pin",
      "animated": true,
      "discordTag": "<a:tungsten_pin:1567241810114379987>",
      "id": "1567241810114379987",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241810114379987.gif"
    },
    {
      "name": "tungsten_plane",
      "label": "Plane",
      "animated": true,
      "discordTag": "<a:tungsten_plane:1567241829538336884>",
      "id": "1567241829538336884",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241829538336884.gif"
    },
    {
      "name": "tungsten_plus",
      "label": "Plus",
      "animated": true,
      "discordTag": "<a:tungsten_plus:1567241846453833840>",
      "id": "1567241846453833840",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241846453833840.gif"
    },
    {
      "name": "tungsten_point",
      "label": "Point",
      "animated": true,
      "discordTag": "<a:tungsten_point:1567241861293408391>",
      "id": "1567241861293408391",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241861293408391.gif"
    },
    {
      "name": "tungsten_question",
      "label": "Question",
      "animated": true,
      "discordTag": "<a:tungsten_question:1567241882080116776>",
      "id": "1567241882080116776",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241882080116776.gif"
    },
    {
      "name": "tungsten_refresh",
      "label": "Refresh",
      "animated": true,
      "discordTag": "<a:tungsten_refresh:1567241907116187658>",
      "id": "1567241907116187658",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241907116187658.gif"
    },
    {
      "name": "tungsten_rice",
      "label": "Rice",
      "animated": true,
      "discordTag": "<a:tungsten_rice:1567241928603336724>",
      "id": "1567241928603336724",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241928603336724.gif"
    },
    {
      "name": "tungsten_ring",
      "label": "Ring",
      "animated": true,
      "discordTag": "<a:tungsten_ring:1567241949461618768>",
      "id": "1567241949461618768",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241949461618768.gif"
    },
    {
      "name": "tungsten_rocket",
      "label": "Rocket",
      "animated": true,
      "discordTag": "<a:tungsten_rocket:1567241971804798976>",
      "id": "1567241971804798976",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241971804798976.gif"
    },
    {
      "name": "tungsten_satellite",
      "label": "Satellite",
      "animated": true,
      "discordTag": "<a:tungsten_satellite:1567241994928005137>",
      "id": "1567241994928005137",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567241994928005137.gif"
    },
    {
      "name": "tungsten_save",
      "label": "Save",
      "animated": true,
      "discordTag": "<a:tungsten_save:1567242015283085507>",
      "id": "1567242015283085507",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242015283085507.gif"
    },
    {
      "name": "tungsten_scales",
      "label": "Scales",
      "animated": true,
      "discordTag": "<a:tungsten_scales:1567242041098895521>",
      "id": "1567242041098895521",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242041098895521.gif"
    },
    {
      "name": "tungsten_scroll",
      "label": "Scroll",
      "animated": true,
      "discordTag": "<a:tungsten_scroll:1567242059708899381>",
      "id": "1567242059708899381",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242059708899381.gif"
    },
    {
      "name": "tungsten_search",
      "label": "Search",
      "animated": true,
      "discordTag": "<a:tungsten_search:1567242081167216771>",
      "id": "1567242081167216771",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242081167216771.gif"
    },
    {
      "name": "tungsten_shield",
      "label": "Shield",
      "animated": true,
      "discordTag": "<a:tungsten_shield:1567242104923627574>",
      "id": "1567242104923627574",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242104923627574.gif"
    },
    {
      "name": "tungsten_shrug",
      "label": "Shrug",
      "animated": true,
      "discordTag": "<a:tungsten_shrug:1567242138323001384>",
      "id": "1567242138323001384",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242138323001384.gif"
    },
    {
      "name": "tungsten_siren",
      "label": "Siren",
      "animated": true,
      "discordTag": "<a:tungsten_siren:1567242157725712555>",
      "id": "1567242157725712555",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242157725712555.gif"
    },
    {
      "name": "tungsten_skull",
      "label": "Skull",
      "animated": true,
      "discordTag": "<a:tungsten_skull:1567242182836883486>",
      "id": "1567242182836883486",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242182836883486.gif"
    },
    {
      "name": "tungsten_slots",
      "label": "Slots",
      "animated": true,
      "discordTag": "<a:tungsten_slots:1567242206266527956>",
      "id": "1567242206266527956",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242206266527956.gif"
    },
    {
      "name": "tungsten_sound",
      "label": "Sound",
      "animated": true,
      "discordTag": "<a:tungsten_sound:1567242242127568958>",
      "id": "1567242242127568958",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242242127568958.gif"
    },
    {
      "name": "tungsten_sparkle",
      "label": "Sparkle",
      "animated": true,
      "discordTag": "<a:tungsten_sparkle:1567242264311369839>",
      "id": "1567242264311369839",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242264311369839.gif"
    },
    {
      "name": "tungsten_star",
      "label": "Star",
      "animated": true,
      "discordTag": "<a:tungsten_star:1567242331785138238>",
      "id": "1567242331785138238",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242331785138238.gif"
    },
    {
      "name": "tungsten_stop",
      "label": "Stop",
      "animated": true,
      "discordTag": "<a:tungsten_stop:1567242365335511121>",
      "id": "1567242365335511121",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242365335511121.gif"
    },
    {
      "name": "tungsten_stopwatch",
      "label": "Stopwatch",
      "animated": true,
      "discordTag": "<a:tungsten_stopwatch:1567242453562687558>",
      "id": "1567242453562687558",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242453562687558.gif"
    },
    {
      "name": "tungsten_success",
      "label": "Success",
      "animated": true,
      "discordTag": "<a:tungsten_success:1567242523468890274>",
      "id": "1567242523468890274",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242523468890274.gif"
    },
    {
      "name": "tungsten_sun",
      "label": "Sun",
      "animated": true,
      "discordTag": "<a:tungsten_sun:1567242622701932604>",
      "id": "1567242622701932604",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242622701932604.gif"
    },
    {
      "name": "tungsten_sweep",
      "label": "Sweep",
      "animated": true,
      "discordTag": "<a:tungsten_sweep:1567242656281657414>",
      "id": "1567242656281657414",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242656281657414.gif"
    },
    {
      "name": "tungsten_swords",
      "label": "Swords",
      "animated": true,
      "discordTag": "<a:tungsten_swords:1567242677819277352>",
      "id": "1567242677819277352",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242677819277352.gif"
    },
    {
      "name": "tungsten_tag",
      "label": "Tag",
      "animated": true,
      "discordTag": "<a:tungsten_tag:1567242698904047691>",
      "id": "1567242698904047691",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242698904047691.gif"
    },
    {
      "name": "tungsten_target",
      "label": "Target",
      "animated": true,
      "discordTag": "<a:tungsten_target:1567242733997789205>",
      "id": "1567242733997789205",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242733997789205.gif"
    },
    {
      "name": "tungsten_terminal",
      "label": "Terminal",
      "animated": true,
      "discordTag": "<a:tungsten_terminal:1567242755040878664>",
      "id": "1567242755040878664",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242755040878664.gif"
    },
    {
      "name": "tungsten_tick",
      "label": "Tick",
      "animated": true,
      "discordTag": "<a:tungsten_tick:1567242779908636802>",
      "id": "1567242779908636802",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242779908636802.gif"
    },
    {
      "name": "tungsten_ticket",
      "label": "Ticket",
      "animated": true,
      "discordTag": "<a:tungsten_ticket:1567242811961770155>",
      "id": "1567242811961770155",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242811961770155.gif"
    },
    {
      "name": "tungsten_tools",
      "label": "Tools",
      "animated": true,
      "discordTag": "<a:tungsten_tools:1567242831834124431>",
      "id": "1567242831834124431",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242831834124431.gif"
    },
    {
      "name": "tungsten_tooth",
      "label": "Tooth",
      "animated": true,
      "discordTag": "<a:tungsten_tooth:1567242851480375296>",
      "id": "1567242851480375296",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242851480375296.gif"
    },
    {
      "name": "tungsten_top",
      "label": "Top",
      "animated": true,
      "discordTag": "<a:tungsten_top:1567242867846680718>",
      "id": "1567242867846680718",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242867846680718.gif"
    },
    {
      "name": "tungsten_trash",
      "label": "Trash",
      "animated": true,
      "discordTag": "<a:tungsten_trash:1567242891276062872>",
      "id": "1567242891276062872",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242891276062872.gif"
    },
    {
      "name": "tungsten_trophy",
      "label": "Trophy",
      "animated": true,
      "discordTag": "<a:tungsten_trophy:1567242918446501939>",
      "id": "1567242918446501939",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242918446501939.gif"
    },
    {
      "name": "tungsten_tv",
      "label": "Tv",
      "animated": true,
      "discordTag": "<a:tungsten_tv:1567242943197224960>",
      "id": "1567242943197224960",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242943197224960.gif"
    },
    {
      "name": "tungsten_ui_appoint",
      "label": "Ui Appoint",
      "animated": true,
      "discordTag": "<a:tungsten_ui_appoint:1567242963359375450>",
      "id": "1567242963359375450",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242963359375450.gif"
    },
    {
      "name": "tungsten_ui_assign",
      "label": "Ui Assign",
      "animated": true,
      "discordTag": "<a:tungsten_ui_assign:1567242984397742250>",
      "id": "1567242984397742250",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567242984397742250.gif"
    }
  ],
  "1566266030794346528": [
    {
      "name": "tungsten_ui_p50",
      "label": "Ui P50",
      "animated": true,
      "discordTag": "<a:tungsten_ui_p50:1567244676057006090>",
      "id": "1567244676057006090",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244676057006090.gif"
    },
    {
      "name": "tungsten_ui_paper",
      "label": "Ui Paper",
      "animated": true,
      "discordTag": "<a:tungsten_ui_paper:1567244704989454378>",
      "id": "1567244704989454378",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244704989454378.gif"
    },
    {
      "name": "tungsten_ui_perks",
      "label": "Ui Perks",
      "animated": true,
      "discordTag": "<a:tungsten_ui_perks:1567244732160147549>",
      "id": "1567244732160147549",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244732160147549.gif"
    },
    {
      "name": "tungsten_ui_presets",
      "label": "Ui Presets",
      "animated": true,
      "discordTag": "<a:tungsten_ui_presets:1567244762405150832>",
      "id": "1567244762405150832",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244762405150832.gif"
    },
    {
      "name": "tungsten_ui_pulse",
      "label": "Ui Pulse",
      "animated": true,
      "discordTag": "<a:tungsten_ui_pulse:1567244779249729658>",
      "id": "1567244779249729658",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244779249729658.gif"
    },
    {
      "name": "tungsten_ui_purge_all",
      "label": "Ui Purge All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_purge_all:1567244800946606170>",
      "id": "1567244800946606170",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244800946606170.gif"
    },
    {
      "name": "tungsten_ui_purge_bots",
      "label": "Ui Purge Bots",
      "animated": true,
      "discordTag": "<a:tungsten_ui_purge_bots:1567244820274225244>",
      "id": "1567244820274225244",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244820274225244.gif"
    },
    {
      "name": "tungsten_ui_quickpunish",
      "label": "Ui Quickpunish",
      "animated": true,
      "discordTag": "<a:tungsten_ui_quickpunish:1567244834576801813>",
      "id": "1567244834576801813",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244834576801813.gif"
    },
    {
      "name": "tungsten_ui_quit",
      "label": "Ui Quit",
      "animated": true,
      "discordTag": "<a:tungsten_ui_quit:1567244850779258981>",
      "id": "1567244850779258981",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244850779258981.gif"
    },
    {
      "name": "tungsten_ui_rank",
      "label": "Ui Rank",
      "animated": true,
      "discordTag": "<a:tungsten_ui_rank:1567244880005038184>",
      "id": "1567244880005038184",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244880005038184.gif"
    },
    {
      "name": "tungsten_ui_redeem",
      "label": "Ui Redeem",
      "animated": true,
      "discordTag": "<a:tungsten_ui_redeem:1567244905896616090>",
      "id": "1567244905896616090",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244905896616090.gif"
    },
    {
      "name": "tungsten_ui_remove_timeout",
      "label": "Ui Remove Timeout",
      "animated": true,
      "discordTag": "<a:tungsten_ui_remove_timeout:1567244927346155600>",
      "id": "1567244927346155600",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244927346155600.gif"
    },
    {
      "name": "tungsten_ui_reset",
      "label": "Ui Reset",
      "animated": true,
      "discordTag": "<a:tungsten_ui_reset:1567244948041113621>",
      "id": "1567244948041113621",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244948041113621.gif"
    },
    {
      "name": "tungsten_ui_revoke",
      "label": "Ui Revoke",
      "animated": true,
      "discordTag": "<a:tungsten_ui_revoke:1567244971436679319>",
      "id": "1567244971436679319",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244971436679319.gif"
    },
    {
      "name": "tungsten_ui_rock",
      "label": "Ui Rock",
      "animated": true,
      "discordTag": "<a:tungsten_ui_rock:1567244992609517809>",
      "id": "1567244992609517809",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567244992609517809.gif"
    },
    {
      "name": "tungsten_ui_role_add",
      "label": "Ui Role Add",
      "animated": true,
      "discordTag": "<a:tungsten_ui_role_add:1567245019587411968>",
      "id": "1567245019587411968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245019587411968.gif"
    },
    {
      "name": "tungsten_ui_role_remove",
      "label": "Ui Role Remove",
      "animated": true,
      "discordTag": "<a:tungsten_ui_role_remove:1567245052009255103>",
      "id": "1567245052009255103",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245052009255103.gif"
    },
    {
      "name": "tungsten_ui_roles_nick",
      "label": "Ui Roles Nick",
      "animated": true,
      "discordTag": "<a:tungsten_ui_roles_nick:1567245091091910751>",
      "id": "1567245091091910751",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245091091910751.gif"
    },
    {
      "name": "tungsten_ui_rules",
      "label": "Ui Rules",
      "animated": true,
      "discordTag": "<a:tungsten_ui_rules:1567245114655641680>",
      "id": "1567245114655641680",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245114655641680.gif"
    },
    {
      "name": "tungsten_ui_scissors",
      "label": "Ui Scissors",
      "animated": true,
      "discordTag": "<a:tungsten_ui_scissors:1567245155545780484>",
      "id": "1567245155545780484",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245155545780484.gif"
    },
    {
      "name": "tungsten_ui_score",
      "label": "Ui Score",
      "animated": true,
      "discordTag": "<a:tungsten_ui_score:1567245190027288709>",
      "id": "1567245190027288709",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245190027288709.gif"
    },
    {
      "name": "tungsten_ui_server_status",
      "label": "Ui Server Status",
      "animated": true,
      "discordTag": "<a:tungsten_ui_server_status:1567245256393625651>",
      "id": "1567245256393625651",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245256393625651.gif"
    },
    {
      "name": "tungsten_ui_telemetry",
      "label": "Ui Telemetry",
      "animated": true,
      "discordTag": "<a:tungsten_ui_telemetry:1567245337486434404>",
      "id": "1567245337486434404",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245337486434404.gif"
    },
    {
      "name": "tungsten_ui_test",
      "label": "Ui Test",
      "animated": true,
      "discordTag": "<a:tungsten_ui_test:1567245407510204466>",
      "id": "1567245407510204466",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245407510204466.gif"
    },
    {
      "name": "tungsten_ui_ticket_close",
      "label": "Ui Ticket Close",
      "animated": true,
      "discordTag": "<a:tungsten_ui_ticket_close:1567245485117284382>",
      "id": "1567245485117284382",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245485117284382.gif"
    },
    {
      "name": "tungsten_ui_ticket_open",
      "label": "Ui Ticket Open",
      "animated": true,
      "discordTag": "<a:tungsten_ui_ticket_open:1567245507699675276>",
      "id": "1567245507699675276",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245507699675276.gif"
    },
    {
      "name": "tungsten_ui_timeout",
      "label": "Ui Timeout",
      "animated": true,
      "discordTag": "<a:tungsten_ui_timeout:1567245550204493934>",
      "id": "1567245550204493934",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245550204493934.gif"
    },
    {
      "name": "tungsten_ui_unassign",
      "label": "Ui Unassign",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unassign:1567245588783829053>",
      "id": "1567245588783829053",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245588783829053.gif"
    },
    {
      "name": "tungsten_ui_undo",
      "label": "Ui Undo",
      "animated": true,
      "discordTag": "<a:tungsten_ui_undo:1567245669087846462>",
      "id": "1567245669087846462",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245669087846462.gif"
    },
    {
      "name": "tungsten_ui_unhide",
      "label": "Ui Unhide",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unhide:1567245749073354832>",
      "id": "1567245749073354832",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245749073354832.gif"
    },
    {
      "name": "tungsten_ui_unhide_vc",
      "label": "Ui Unhide Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unhide_vc:1567245826777161792>",
      "id": "1567245826777161792",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245826777161792.gif"
    },
    {
      "name": "tungsten_ui_unlock_vc",
      "label": "Ui Unlock Vc",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unlock_vc:1567245856430620782>",
      "id": "1567245856430620782",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245856430620782.gif"
    },
    {
      "name": "tungsten_ui_unlockdown",
      "label": "Ui Unlockdown",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unlockdown:1567245990556209313>",
      "id": "1567245990556209313",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567245990556209313.gif"
    },
    {
      "name": "tungsten_ui_unmute_all",
      "label": "Ui Unmute All",
      "animated": true,
      "discordTag": "<a:tungsten_ui_unmute_all:1567246118520365256>",
      "id": "1567246118520365256",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246118520365256.gif"
    },
    {
      "name": "tungsten_ui_user_add",
      "label": "Ui User Add",
      "animated": true,
      "discordTag": "<a:tungsten_ui_user_add:1567246155706929205>",
      "id": "1567246155706929205",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246155706929205.gif"
    },
    {
      "name": "tungsten_ui_user_remove",
      "label": "Ui User Remove",
      "animated": true,
      "discordTag": "<a:tungsten_ui_user_remove:1567246253467631616>",
      "id": "1567246253467631616",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246253467631616.gif"
    },
    {
      "name": "tungsten_ui_verbose",
      "label": "Ui Verbose",
      "animated": true,
      "discordTag": "<a:tungsten_ui_verbose:1567246309063397548>",
      "id": "1567246309063397548",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246309063397548.gif"
    },
    {
      "name": "tungsten_ui_view_emojis",
      "label": "Ui View Emojis",
      "animated": true,
      "discordTag": "<a:tungsten_ui_view_emojis:1567246384980168774>",
      "id": "1567246384980168774",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246384980168774.gif"
    },
    {
      "name": "tungsten_ui_welcome_test",
      "label": "Ui Welcome Test",
      "animated": true,
      "discordTag": "<a:tungsten_ui_welcome_test:1567246433336299654>",
      "id": "1567246433336299654",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246433336299654.gif"
    },
    {
      "name": "tungsten_unlock",
      "label": "Unlock",
      "animated": true,
      "discordTag": "<a:tungsten_unlock:1567246515209117968>",
      "id": "1567246515209117968",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246515209117968.gif"
    },
    {
      "name": "tungsten_user",
      "label": "User",
      "animated": true,
      "discordTag": "<a:tungsten_user:1567246556778995802>",
      "id": "1567246556778995802",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246556778995802.gif"
    },
    {
      "name": "tungsten_users",
      "label": "Users",
      "animated": true,
      "discordTag": "<a:tungsten_users:1567246628606185502>",
      "id": "1567246628606185502",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246628606185502.gif"
    },
    {
      "name": "tungsten_warn",
      "label": "Warn",
      "animated": true,
      "discordTag": "<a:tungsten_warn:1567246685082746940>",
      "id": "1567246685082746940",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246685082746940.gif"
    },
    {
      "name": "tungsten_wave",
      "label": "Wave",
      "animated": true,
      "discordTag": "<a:tungsten_wave:1567246763822158004>",
      "id": "1567246763822158004",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246763822158004.gif"
    },
    {
      "name": "tungsten_wind",
      "label": "Wind",
      "animated": true,
      "discordTag": "<a:tungsten_wind:1567246820927602838>",
      "id": "1567246820927602838",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246820927602838.gif"
    },
    {
      "name": "tungsten_zzz",
      "label": "Zzz",
      "animated": true,
      "discordTag": "<a:tungsten_zzz:1567246871834132673>",
      "id": "1567246871834132673",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1567246871834132673.gif"
    }
  ],
  "1568221270091497533": [
    {
      "name": "tungsten_achievements",
      "label": "Achievements",
      "animated": true,
      "discordTag": "<a:tungsten_achievements:1569329206842757271>",
      "id": "1569329206842757271",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329206842757271.gif"
    },
    {
      "name": "tungsten_an_stage_abuse",
      "label": "An Stage Abuse",
      "animated": true,
      "discordTag": "<a:tungsten_an_stage_abuse:1569329214539173898>",
      "id": "1569329214539173898",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329214539173898.gif"
    },
    {
      "name": "tungsten_analytics",
      "label": "Analytics",
      "animated": true,
      "discordTag": "<a:tungsten_analytics:1569329222265208843>",
      "id": "1569329222265208843",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329222265208843.gif"
    },
    {
      "name": "tungsten_auction",
      "label": "Auction",
      "animated": true,
      "discordTag": "<a:tungsten_auction:1569329230435590194>",
      "id": "1569329230435590194",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329230435590194.gif"
    },
    {
      "name": "tungsten_autoslow",
      "label": "Autoslow",
      "animated": true,
      "discordTag": "<a:tungsten_autoslow:1569329238585118783>",
      "id": "1569329238585118783",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329238585118783.gif"
    },
    {
      "name": "tungsten_autothread",
      "label": "Autothread",
      "animated": true,
      "discordTag": "<a:tungsten_autothread:1569329247355539606>",
      "id": "1569329247355539606",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329247355539606.gif"
    },
    {
      "name": "tungsten_bans",
      "label": "Bans",
      "animated": true,
      "discordTag": "<a:tungsten_bans:1569329255693688853>",
      "id": "1569329255693688853",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329255693688853.gif"
    },
    {
      "name": "tungsten_calc",
      "label": "Calc",
      "animated": true,
      "discordTag": "<a:tungsten_calc:1569329263469924396>",
      "id": "1569329263469924396",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329263469924396.gif"
    },
    {
      "name": "tungsten_cat_clans",
      "label": "Cat Clans",
      "animated": true,
      "discordTag": "<a:tungsten_cat_clans:1569329279701884928>",
      "id": "1569329279701884928",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329279701884928.gif"
    },
    {
      "name": "tungsten_cat_modmail",
      "label": "Cat Modmail",
      "animated": true,
      "discordTag": "<a:tungsten_cat_modmail:1569329287692296213>",
      "id": "1569329287692296213",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329287692296213.gif"
    },
    {
      "name": "tungsten_cat_pets",
      "label": "Cat Pets",
      "animated": true,
      "discordTag": "<a:tungsten_cat_pets:1569329296542011563>",
      "id": "1569329296542011563",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329296542011563.gif"
    },
    {
      "name": "tungsten_cat_social",
      "label": "Cat Social",
      "animated": true,
      "discordTag": "<a:tungsten_cat_social:1569329304196747418>",
      "id": "1569329304196747418",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329304196747418.gif"
    },
    {
      "name": "tungsten_clan",
      "label": "Clan",
      "animated": true,
      "discordTag": "<a:tungsten_clan:1569329312774103142>",
      "id": "1569329312774103142",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329312774103142.gif"
    },
    {
      "name": "tungsten_convert",
      "label": "Convert",
      "animated": true,
      "discordTag": "<a:tungsten_convert:1569329320802000956>",
      "id": "1569329320802000956",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329320802000956.gif"
    },
    {
      "name": "tungsten_countdown",
      "label": "Countdown",
      "animated": true,
      "discordTag": "<a:tungsten_countdown:1569329328838152274>",
      "id": "1569329328838152274",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329328838152274.gif"
    },
    {
      "name": "tungsten_discordpoll",
      "label": "Discordpoll",
      "animated": true,
      "discordTag": "<a:tungsten_discordpoll:1569329347171590216>",
      "id": "1569329347171590216",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329347171590216.gif"
    },
    {
      "name": "tungsten_encode",
      "label": "Encode",
      "animated": true,
      "discordTag": "<a:tungsten_encode:1569329355111538820>",
      "id": "1569329355111538820",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329355111538820.gif"
    },
    {
      "name": "tungsten_event",
      "label": "Event",
      "animated": true,
      "discordTag": "<a:tungsten_event:1569329363038638090>",
      "id": "1569329363038638090",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329363038638090.gif"
    },
    {
      "name": "tungsten_evidence",
      "label": "Evidence",
      "animated": true,
      "discordTag": "<a:tungsten_evidence:1569329371850874921>",
      "id": "1569329371850874921",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329371850874921.gif"
    },
    {
      "name": "tungsten_farm",
      "label": "Farm",
      "animated": true,
      "discordTag": "<a:tungsten_farm:1569329379975364628>",
      "id": "1569329379975364628",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329379975364628.gif"
    },
    {
      "name": "tungsten_feed",
      "label": "Feed",
      "animated": true,
      "discordTag": "<a:tungsten_feed:1569329388053467276>",
      "id": "1569329388053467276",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329388053467276.gif"
    },
    {
      "name": "tungsten_forum",
      "label": "Forum",
      "animated": true,
      "discordTag": "<a:tungsten_forum:1569329396278370374>",
      "id": "1569329396278370374",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329396278370374.gif"
    },
    {
      "name": "tungsten_guildsettings",
      "label": "Guildsettings",
      "animated": true,
      "discordTag": "<a:tungsten_guildsettings:1569329404558184562>",
      "id": "1569329404558184562",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329404558184562.gif"
    },
    {
      "name": "tungsten_integrations",
      "label": "Integrations",
      "animated": true,
      "discordTag": "<a:tungsten_integrations:1569329413110239292>",
      "id": "1569329413110239292",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329413110239292.gif"
    },
    {
      "name": "tungsten_linkedroles",
      "label": "Linkedroles",
      "animated": true,
      "discordTag": "<a:tungsten_linkedroles:1569329421352046592>",
      "id": "1569329421352046592",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329421352046592.gif"
    },
    {
      "name": "tungsten_lockdown",
      "label": "Lockdown",
      "animated": true,
      "discordTag": "<a:tungsten_lockdown:1569329429174296697>",
      "id": "1569329429174296697",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329429174296697.gif"
    },
    {
      "name": "tungsten_macro",
      "label": "Macro",
      "animated": true,
      "discordTag": "<a:tungsten_macro:1569329438586310706>",
      "id": "1569329438586310706",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329438586310706.gif"
    },
    {
      "name": "tungsten_marriage",
      "label": "Marriage",
      "animated": true,
      "discordTag": "<a:tungsten_marriage:1569329446325063725>",
      "id": "1569329446325063725",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329446325063725.gif"
    },
    {
      "name": "tungsten_modmail",
      "label": "Modmail",
      "animated": true,
      "discordTag": "<a:tungsten_modmail:1569329454952611870>",
      "id": "1569329454952611870",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329454952611870.gif"
    },
    {
      "name": "tungsten_nativeautomod",
      "label": "Nativeautomod",
      "animated": true,
      "discordTag": "<a:tungsten_nativeautomod:1569329462921920542>",
      "id": "1569329462921920542",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329462921920542.gif"
    },
    {
      "name": "tungsten_npm",
      "label": "Npm",
      "animated": true,
      "discordTag": "<a:tungsten_npm:1569329471373320352>",
      "id": "1569329471373320352",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329471373320352.gif"
    },
    {
      "name": "tungsten_onboarding",
      "label": "Onboarding",
      "animated": true,
      "discordTag": "<a:tungsten_onboarding:1569329479325585481>",
      "id": "1569329479325585481",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329479325585481.gif"
    },
    {
      "name": "tungsten_override",
      "label": "Override",
      "animated": true,
      "discordTag": "<a:tungsten_override:1569329487794143305>",
      "id": "1569329487794143305",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329487794143305.gif"
    },
    {
      "name": "tungsten_panelbuilder",
      "label": "Panelbuilder",
      "animated": true,
      "discordTag": "<a:tungsten_panelbuilder:1569329495809200158>",
      "id": "1569329495809200158",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329495809200158.gif"
    }
  ],
  "1568221442422607942": [
    {
      "name": "tungsten_password",
      "label": "Password",
      "animated": true,
      "discordTag": "<a:tungsten_password:1569329504994852944>",
      "id": "1569329504994852944",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329504994852944.gif"
    },
    {
      "name": "tungsten_pet",
      "label": "Pet",
      "animated": true,
      "discordTag": "<a:tungsten_pet:1569329513408634920>",
      "id": "1569329513408634920",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329513408634920.gif"
    },
    {
      "name": "tungsten_pokemon",
      "label": "Pokemon",
      "animated": true,
      "discordTag": "<a:tungsten_pokemon:1569329520966635581>",
      "id": "1569329520966635581",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329520966635581.gif"
    },
    {
      "name": "tungsten_policy",
      "label": "Policy",
      "animated": true,
      "discordTag": "<a:tungsten_policy:1569329528851927131>",
      "id": "1569329528851927131",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329528851927131.gif"
    },
    {
      "name": "tungsten_presence",
      "label": "Presence",
      "animated": true,
      "discordTag": "<a:tungsten_presence:1569329536875888711>",
      "id": "1569329536875888711",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329536875888711.gif"
    },
    {
      "name": "tungsten_profile",
      "label": "Profile",
      "animated": true,
      "discordTag": "<a:tungsten_profile:1569329544819900416>",
      "id": "1569329544819900416",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329544819900416.gif"
    },
    {
      "name": "tungsten_quests",
      "label": "Quests",
      "animated": true,
      "discordTag": "<a:tungsten_quests:1569329552453533827>",
      "id": "1569329552453533827",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329552453533827.gif"
    },
    {
      "name": "tungsten_rep",
      "label": "Rep",
      "animated": true,
      "discordTag": "<a:tungsten_rep:1569329560917381213>",
      "id": "1569329560917381213",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329560917381213.gif"
    },
    {
      "name": "tungsten_serverdoctor",
      "label": "Serverdoctor",
      "animated": true,
      "discordTag": "<a:tungsten_serverdoctor:1569329568471457898>",
      "id": "1569329568471457898",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329568471457898.gif"
    },
    {
      "name": "tungsten_setup",
      "label": "Setup",
      "animated": true,
      "discordTag": "<a:tungsten_setup:1569329576490836098>",
      "id": "1569329576490836098",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329576490836098.gif"
    },
    {
      "name": "tungsten_snowflake",
      "label": "Snowflake",
      "animated": true,
      "discordTag": "<a:tungsten_snowflake:1569329585487614105>",
      "id": "1569329585487614105",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329585487614105.gif"
    },
    {
      "name": "tungsten_soundboard",
      "label": "Soundboard",
      "animated": true,
      "discordTag": "<a:tungsten_soundboard:1569329593561780354>",
      "id": "1569329593561780354",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329593561780354.gif"
    },
    {
      "name": "tungsten_stage",
      "label": "Stage",
      "animated": true,
      "discordTag": "<a:tungsten_stage:1569329601971224720>",
      "id": "1569329601971224720",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329601971224720.gif"
    },
    {
      "name": "tungsten_thread",
      "label": "Thread",
      "animated": true,
      "discordTag": "<a:tungsten_thread:1569329618928930846>",
      "id": "1569329618928930846",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329618928930846.gif"
    },
    {
      "name": "tungsten_tournament",
      "label": "Tournament",
      "animated": true,
      "discordTag": "<a:tungsten_tournament:1569329627057487993>",
      "id": "1569329627057487993",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329627057487993.gif"
    },
    {
      "name": "tungsten_trade",
      "label": "Trade",
      "animated": true,
      "discordTag": "<a:tungsten_trade:1569329634733072495>",
      "id": "1569329634733072495",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329634733072495.gif"
    },
    {
      "name": "tungsten_ui_bid",
      "label": "Ui Bid",
      "animated": true,
      "discordTag": "<a:tungsten_ui_bid:1569329642609836154>",
      "id": "1569329642609836154",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329642609836154.gif"
    },
    {
      "name": "tungsten_ui_bracket",
      "label": "Ui Bracket",
      "animated": true,
      "discordTag": "<a:tungsten_ui_bracket:1569329652714184704>",
      "id": "1569329652714184704",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329652714184704.gif"
    },
    {
      "name": "tungsten_ui_harvest",
      "label": "Ui Harvest",
      "animated": true,
      "discordTag": "<a:tungsten_ui_harvest:1569329661148930230>",
      "id": "1569329661148930230",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329661148930230.gif"
    },
    {
      "name": "tungsten_ui_plant",
      "label": "Ui Plant",
      "animated": true,
      "discordTag": "<a:tungsten_ui_plant:1569329669503717397>",
      "id": "1569329669503717397",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329669503717397.gif"
    },
    {
      "name": "tungsten_ui_toggle_off",
      "label": "Ui Toggle Off",
      "animated": true,
      "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
      "id": "1569329677187678368",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329677187678368.gif"
    },
    {
      "name": "tungsten_ui_toggle_on",
      "label": "Ui Toggle On",
      "animated": true,
      "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
      "id": "1569329685110849576",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329685110849576.gif"
    },
    {
      "name": "tungsten_ui_trade",
      "label": "Ui Trade",
      "animated": true,
      "discordTag": "<a:tungsten_ui_trade:1569329692899680408>",
      "id": "1569329692899680408",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329692899680408.gif"
    },
    {
      "name": "tungsten_ui_water",
      "label": "Ui Water",
      "animated": true,
      "discordTag": "<a:tungsten_ui_water:1569329701409915022>",
      "id": "1569329701409915022",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329701409915022.gif"
    },
    {
      "name": "tungsten_ui_wizard_back",
      "label": "Ui Wizard Back",
      "animated": true,
      "discordTag": "<a:tungsten_ui_wizard_back:1569329709613850625>",
      "id": "1569329709613850625",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329709613850625.gif"
    },
    {
      "name": "tungsten_ui_wizard_finish",
      "label": "Ui Wizard Finish",
      "animated": true,
      "discordTag": "<a:tungsten_ui_wizard_finish:1569329717243412595>",
      "id": "1569329717243412595",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329717243412595.gif"
    },
    {
      "name": "tungsten_ui_wizard_next",
      "label": "Ui Wizard Next",
      "animated": true,
      "discordTag": "<a:tungsten_ui_wizard_next:1569329725405536328>",
      "id": "1569329725405536328",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329725405536328.gif"
    },
    {
      "name": "tungsten_watchlist",
      "label": "Watchlist",
      "animated": true,
      "discordTag": "<a:tungsten_watchlist:1569329733303541801>",
      "id": "1569329733303541801",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329733303541801.gif"
    },
    {
      "name": "tungsten_webhook",
      "label": "Webhook",
      "animated": true,
      "discordTag": "<a:tungsten_webhook:1569329741150949488>",
      "id": "1569329741150949488",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329741150949488.gif"
    },
    {
      "name": "tungsten_welcomescreen",
      "label": "Welcomescreen",
      "animated": true,
      "discordTag": "<a:tungsten_welcomescreen:1569329748486787085>",
      "id": "1569329748486787085",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329748486787085.gif"
    },
    {
      "name": "tungsten_whois",
      "label": "Whois",
      "animated": true,
      "discordTag": "<a:tungsten_whois:1569329756657160402>",
      "id": "1569329756657160402",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329756657160402.gif"
    },
    {
      "name": "tungsten_wordcount",
      "label": "Wordcount",
      "animated": true,
      "discordTag": "<a:tungsten_wordcount:1569329764508893246>",
      "id": "1569329764508893246",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329764508893246.gif"
    },
    {
      "name": "tungsten_workflow",
      "label": "Workflow",
      "animated": true,
      "discordTag": "<a:tungsten_workflow:1569329772520018061>",
      "id": "1569329772520018061",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329772520018061.gif"
    },
    {
      "name": "tungsten_worldclock",
      "label": "Worldclock",
      "animated": true,
      "discordTag": "<a:tungsten_worldclock:1569329780229275668>",
      "id": "1569329780229275668",
      "remoteUrl": "https://cdn.discordapp.com/emojis/1569329780229275668.gif"
    }
  ]
};

function isEmojiServer(guild) {
  if (!guild) return false;
  if (typeof guild === 'string') return EMOJI_SERVER_IDS.has(guild);
  if (guild.id && EMOJI_SERVER_IDS.has(String(guild.id))) return true;

  const name = (guild.name || '').toLowerCase().trim();
  const ownerId = guild.ownerId || '';

  if (name.includes('custom emoji') || /custom\s*emoji\s*[0-9]+/i.test(name)) {
    return true;
  }

  const isOwnerGuild = (config.OWNER_IDS && config.OWNER_IDS.includes(ownerId)) || (process.env.OWNER_IDS && process.env.OWNER_IDS.includes(ownerId)) || ownerId === '100000000000000001';
  const isNameMatch = name.includes('emoji') || name.includes('emote') || name.includes('asset') || name.includes('tungsten') || name.includes('celestia');

  return isNameMatch || isOwnerGuild;
}

function getEmojiServerNumber(guild) {
  if (!guild || !guild.name) return null;
  const match = guild.name.toLowerCase().match(/custom\s*emoji\s*([0-9]+)/i);
  return match ? parseInt(match[1], 10) : null;
}

async function syncEmojisToServer(guild) {
  if (!guild) return { synced: 0, failed: 0 };
  const pack = SERVER_PACKS[guild.id] || [];
  if (pack.length === 0) return { synced: 0, failed: 0 };

  let synced = 0;
  let failed = 0;
  const existing = await guild.emojis.fetch().catch(() => new Map());

  for (const target of pack) {
    const exists = existing.find(e => e.name === target.name);
    if (!exists) {
      failed++;
    } else {
      synced++;
    }
  }

  return { synced, failed };
}

async function syncEmojiServers(client) {
  if (!client || !client.guilds) return { uploaded: 0, indexed: 0, servers: 0, needMoreServers: false };

  if (!client.tungstenEmojis) {
    client.tungstenEmojis = new Map();
  }
  client.celestiaEmojis = client.tungstenEmojis;

  for (const guild of client.guilds.cache.values()) {
    for (const emoji of guild.emojis.cache.values()) {
      const nameLower = emoji.name.toLowerCase();
      client.tungstenEmojis.set(nameLower, emoji);
      if (nameLower.startsWith('tungsten_')) {
        client.tungstenEmojis.set('celestia_' + nameLower.slice(9), emoji);
      } else if (nameLower.startsWith('celestia_')) {
        client.tungstenEmojis.set('tungsten_' + nameLower.slice(9), emoji);
      }
    }
  }

  let totalIndexed = client.tungstenEmojis.size;
  let serversCount = client.guilds.cache.filter(isEmojiServer).size;

  console.log(`[Ready] Emoji Server Sync: 0 uploaded, ${totalIndexed} live custom emojis indexed across ${serversCount} emoji server(s).`);
  return { uploaded: 0, indexed: totalIndexed, servers: serversCount, needMoreServers: false };
}

const syncAllEmojiServers = syncEmojiServers;

module.exports = {
  SERVER_PACKS,
  isEmojiServer,
  getEmojiServerNumber,
  syncEmojisToServer,
  syncEmojiServers,
  syncAllEmojiServers,
  EMOJI_SERVER_IDS
};
