/**
 * Ghostping In-Memory Cache (Node.js)
 * High-speed sliding cache that captures messages with mentions
 * and exposes ghostpings in real-time when deleted.
 */

const _GHOSTPING_CACHE = new Map();
const CACHE_LIFETIME_MS = 60000; // 60 seconds retention

function storeGhostpingCandidate(message) {
  if (!message || !message.guild || !message.mentions?.users?.size) return;
  if (message.author.bot) return;

  const mentionList = [];
  message.mentions.users.forEach(u => {
    if (u.id !== message.author.id && !u.bot) {
      mentionList.push({ id: u.id, tag: u.username });
    }
  });

  if (mentionList.length === 0) return;

  _GHOSTPING_CACHE.set(message.id, {
    guildId: message.guild.id,
    channelId: message.channel.id,
    authorId: message.author.id,
    authorTag: message.author.username,
    authorAvatar: message.author.displayAvatarURL ? message.author.displayAvatarURL() : null,
    content: message.content || '[No text content]',
    mentions: mentionList,
    createdAt: Date.now()
  });

  // Self-cleaning eviction after 60 seconds (unref prevents blocking process exit)
  const timer = setTimeout(() => {
    _GHOSTPING_CACHE.delete(message.id);
  }, CACHE_LIFETIME_MS);
  if (timer.unref) timer.unref();
}

function retrieveAndEvictGhostping(messageId) {
  const data = _GHOSTPING_CACHE.get(messageId);
  if (data) {
    _GHOSTPING_CACHE.delete(messageId);
    return data;
  }
  return null;
}

module.exports = {
  storeGhostpingCandidate,
  retrieveAndEvictGhostping
};
