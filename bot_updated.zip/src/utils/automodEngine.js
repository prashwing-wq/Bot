/**
 * Tungsten Automod Consolidated Protection Pipeline (automodEngine.js)
 * Enterprise-grade real-time chat inspection & defense engine:
 * Anti-Invite, Anti-Link (with domain whitelist & explicit subdomain matching), Anti-Spam (configurable rate-limiting),
 * Duplicate Spam, Anti-Caps, Anti-Mentions (configurable threshold), Anti-Emojis,
 * Banned Words (with precompiled RegExps, ReDoS protection, homoglyph folding, and Unicode-aware word boundaries),
 * Anti-Zalgo, Anti-Newlines, Anti-Spoilers, Leaked Token Protection (with Bot Token Rotation alerts),
 * Phishing/Scam sentinels, Anti-NSFW, Anti-Selfbot Sentinel, and Honeypot Channel Sentry.
 * Single source of truth in `automod_rules` table with native AutoMod routing and warnLadder escalation.
 */
const { PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createEmbed } = require('./tools');
const { createCase } = require('./modlog');
const { getSetting } = require('../settings/registry');
const { getServerDb } = require('./serverDb');
const { isImmune, isChannelWhitelisted } = require('./antinukeEngine');
const { resolveEmoji, EMOJIS } = require('./emojis');
const { checkAndExecuteLadder } = require('./warnLadder');

// ─────────────────────────────────────────────────────────────
// Memory Bounds & In-Memory Rate Trackers
// ─────────────────────────────────────────────────────────────
const MAX_TRACKER_ENTRIES = 500;
const _SPAM_TRACKER = new Map(); // key `${guildId}:${userId}` -> array of message timestamps
const _DUPLICATE_TRACKER = new Map(); // key `${guildId}:${userId}` -> { text: string, timestamp: number }
const _AUTOMOD_DELETED_MESSAGES = new Set(); // set of message IDs deleted by Automod (capped at 500)
const _PUNISHED_MESSAGES = new Set(); // set of message IDs punished to prevent duplicate punishments (capped at 500)
const _BANNED_WORDS_REGEX_CACHE = new Map(); // guildId -> Array<{ word: string, regex: RegExp }>

function enforceMapCap(map, maxEntries = MAX_TRACKER_ENTRIES) {
  if (map.size > maxEntries) {
    const toRemove = map.size - maxEntries;
    let count = 0;
    for (const key of map.keys()) {
      map.delete(key);
      count++;
      if (count >= toRemove) break;
    }
  }
}

function pruneSet(set, maxSize = 500, pruneCount = 100) {
  if (set.size > maxSize) {
    let count = 0;
    for (const id of set) {
      set.delete(id);
      count++;
      if (count >= pruneCount) break;
    }
  }
}

function recordAutomodDeleted(messageId) {
  if (!messageId) return;
  const idStr = String(messageId);
  _AUTOMOD_DELETED_MESSAGES.add(idStr);
  pruneSet(_AUTOMOD_DELETED_MESSAGES, 500, 100);
  const timer = setTimeout(() => _AUTOMOD_DELETED_MESSAGES.delete(idStr), 60000);
  if (timer.unref) timer.unref();
}

function isAutomodDeleted(messageId) {
  return _AUTOMOD_DELETED_MESSAGES.has(String(messageId));
}

function recordAutomodPunished(messageId) {
  if (!messageId) return;
  const idStr = String(messageId);
  _PUNISHED_MESSAGES.add(idStr);
  pruneSet(_PUNISHED_MESSAGES, 500, 100);
  const timer = setTimeout(() => _PUNISHED_MESSAGES.delete(idStr), 60000);
  if (timer.unref) timer.unref();
}

function isAutomodPunished(messageId) {
  return _PUNISHED_MESSAGES.has(String(messageId));
}

// Periodic sweep cleanup every 30s
const _SPAM_PRUNE_INTERVAL = setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of _SPAM_TRACKER.entries()) {
    if (!arr.length || now - arr[arr.length - 1] > 10000) {
      _SPAM_TRACKER.delete(k);
    }
  }
  for (const [k, item] of _DUPLICATE_TRACKER.entries()) {
    if (now - item.timestamp > 30000) {
      _DUPLICATE_TRACKER.delete(k);
    }
  }
  pruneSet(_AUTOMOD_DELETED_MESSAGES, 500, 100);
  pruneSet(_PUNISHED_MESSAGES, 500, 100);
}, 30000);
if (_SPAM_PRUNE_INTERVAL.unref) _SPAM_PRUNE_INTERVAL.unref();

function getSpamTrackerSize() {
  return _SPAM_TRACKER.size;
}

function getDuplicateTrackerSize() {
  return _DUPLICATE_TRACKER.size;
}

function clearTrackers() {
  _SPAM_TRACKER.clear();
  _DUPLICATE_TRACKER.clear();
  _AUTOMOD_DELETED_MESSAGES.clear();
  _PUNISHED_MESSAGES.clear();
}

// ─────────────────────────────────────────────────────────────
// Regex Detection Patterns
// ─────────────────────────────────────────────────────────────
// Extended invite regex: matches standard, obfuscated, and shortlink discord invites
const INVITE_REGEX = /(?:https?:\/\/)?(?:www\.)?(?:(?:discord|discrod|dlscord)\s*(?:\.|\s*dot\s*)\s*(?:gg|io|me|li)|(?:discord|discordapp)\s*(?:\.|\s*dot\s*)\s*com\s*\/+\s*invite|dsc\s*(?:\.|\s*dot\s*)\s*gg)\s*\/+\s*[a-zA-Z0-9_-]+/i;
const LINK_REGEX = /https?:\/\/[^\s]+/i;
const PHISHING_REGEX = /(?:discord(?:app)?[-_.](?:gift|nitro|trade|info|xyz|top)|(?:discord|nitro)[-_.]gift|dlscord|discorcl|discrod|free[-_.]nitro|steam[-_.]gift|steamcommunity[-_.])/i;
const UNICODE_EMOJI_REGEX = /\p{Extended_Pictographic}/gu;
const ZALGO_REGEX = /[\u0300-\u036f\u1dc0-\u1dff\u20d0-\u20ff\ufe20-\ufe2f]{3,}/u;
const TOKEN_REGEX = /(?:mfa\.[a-z0-9_-]{20,}|[a-z0-9_-]{23,28}\.[a-z0-9_-]{6,7}\.[a-z0-9_-]{27,})(?![a-z0-9_-])/i;
const NEWLINES_REGEX = /(?:\r?\n\s*){10,}/;
const SPOILER_REGEX = /(?:\|\|[\s\S]*?\|\|[\s\S]*?){5,}/;
const NSFW_TERMS_REGEX = /\b(?:porn|nsfw|xxx|rule34|hentai|xhamster|pornhub|redtube|youporn|xvideos)\b/i;

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

const SAFE_SUBDOMAIN_PREFIXES = ['cdn.', 'media.', 'images.', 'static.'];
const UNTRUSTED_SUBDOMAIN_PREFIXES = ['evil.', 'attacker.', 'phish.', 'malware.', 'hack.'];

function getSettingNumber(sdb, key, defaultValue) {
  try {
    const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(key);
    if (row && row.value !== undefined && row.value !== null) {
      const parsed = Number(row.value);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
  } catch (_) {}
  return defaultValue;
}

// ─────────────────────────────────────────────────────────────
// Unicode Normalization & Matching Quality
// ─────────────────────────────────────────────────────────────
const HOMOGLYPHS = {
  // Cyrillic
  'а': 'a', 'А': 'a',
  'б': 'b', 'Б': 'b',
  'в': 'v', 'В': 'b',
  'г': 'g', 'Г': 'r',
  'д': 'd', 'Д': 'd',
  'е': 'e', 'Е': 'e',
  'ж': 'zh',
  'з': 'z', 'З': '3',
  'и': 'i', 'И': 'u',
  'й': 'y', 'Й': 'y',
  'к': 'k', 'К': 'k',
  'л': 'l', 'Л': 'l',
  'м': 'm', 'М': 'm',
  'н': 'n', 'Н': 'h',
  'о': 'o', 'О': 'o',
  'п': 'n', 'П': 'n',
  'р': 'p', 'Р': 'p',
  'с': 'c', 'С': 'c',
  'т': 't', 'Т': 't',
  'у': 'y', 'У': 'y',
  'ф': 'f', 'Ф': 'f',
  'х': 'x', 'Х': 'x',
  'ц': 'ts',
  'ч': 'ch',
  'ш': 'sh',
  'щ': 'shch',
  'ъ': '',
  'ы': 'y',
  'ь': '',
  'э': 'e',
  'ю': 'yu',
  'я': 'ya',
  'і': 'i', 'І': 'i',
  'ї': 'i', 'Ї': 'i',
  'ј': 'j', 'Ј': 'j',
  'ѕ': 's', 'Ѕ': 's',
  // Greek
  'α': 'a', 'Α': 'a',
  'β': 'b', 'Β': 'b',
  'γ': 'y', 'Γ': 'r',
  'δ': 'd', 'Δ': 'd',
  'ε': 'e', 'Ε': 'e',
  'ζ': 'z', 'Ζ': 'z',
  'η': 'n', 'Η': 'h',
  'θ': 'th', 'Θ': 'th',
  'ι': 'i', 'Ι': 'i',
  'κ': 'k', 'Κ': 'k',
  'λ': 'l', 'Λ': 'l',
  'μ': 'u', 'Μ': 'm',
  'ν': 'v', 'Ν': 'n',
  'ξ': 'x', 'Ξ': 'x',
  'ο': 'o', 'Ο': 'o',
  'π': 'p', 'Π': 'p',
  'ρ': 'p', 'Ρ': 'p',
  'σ': 's', 'ς': 's', 'Σ': 's',
  'τ': 't', 'Τ': 't',
  'υ': 'u', 'Υ': 'y',
  'φ': 'f', 'Φ': 'f',
  'χ': 'x', 'Χ': 'x',
  'ψ': 'ps', 'Ψ': 'ps',
  'ω': 'w', 'Ω': 'w'
};

const LEET_FOLD_MAP = {
  '1': 'i',
  '0': 'o',
  '$': 's',
  '5': 's',
  '@': 'a',
  '4': 'a',
  '3': 'e',
  '€': 'e',
  '7': 't',
  '8': 'b',
  '2': 'z'
};

function stripZeroWidthAndCombining(text) {
  if (!text || typeof text !== 'string') return '';
  return text
    .normalize('NFD')
    .replace(/[\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E\u2060-\u2064]/g, '')
    .replace(/[\u0300-\u036f\u1dc0-\u1dff\u20d0-\u20ff\ufe20-\ufe2f]/g, '')
    .normalize('NFKC');
}

function foldHomoglyphs(text) {
  if (!text || typeof text !== 'string') return '';
  let folded = '';
  for (const char of text) {
    folded += HOMOGLYPHS[char] !== undefined ? HOMOGLYPHS[char] : char;
  }
  return folded;
}

function foldLeetspeak(text) {
  if (!text || typeof text !== 'string') return '';
  let folded = '';
  for (const char of text) {
    folded += LEET_FOLD_MAP[char] !== undefined ? LEET_FOLD_MAP[char] : char;
  }
  return folded;
}

function collapseRepeatedChars(text) {
  if (!text || typeof text !== 'string') return '';
  // Collapses 3+ identical consecutive characters down to 2: 'coooool' -> 'cool'
  return text.replace(/(.)\1{2,}/gu, '$1$1');
}

function normalizeText(text) {
  if (!text || typeof text !== 'string') return '';
  // 1. Unicode NFKC normalization
  let normalized = text.normalize('NFKC');
  // 2. Strip zero-width characters and combining marks
  normalized = stripZeroWidthAndCombining(normalized);
  // 3. Fold homoglyphs (Cyrillic, Greek lookalikes)
  normalized = foldHomoglyphs(normalized);
  // 4. Leetspeak mapping
  normalized = foldLeetspeak(normalized);
  return normalized;
}

// ─────────────────────────────────────────────────────────────
// Banned Words & Precompiled RegExp Cache with ReDoS Protection
// ─────────────────────────────────────────────────────────────
const MAX_BANNED_WORDS_PER_GUILD = 250;
const MAX_BANNED_WORD_LENGTH = 64;

const LEET_MAP = {
  'a': '[a@4/\\\\]',
  'b': '[b8]',
  'c': '[c(\\[<]',
  'd': '[d)]',
  'e': '[e3€]',
  'i': '[i1!|l]',
  'l': '[l1|!i]',
  'o': '[o0]',
  's': '[s$5]',
  't': '[t7+]',
  'u': '[uv]',
  'v': '[vu\\/]',
  'z': '[z2]'
};

function generateLeetPattern(word) {
  if (!word) return '';
  const chars = String(word).toLowerCase().split('');
  return chars.map(ch => (LEET_MAP[ch] || escapeRegex(ch)) + '+').join('[\\s._\\-*,\/\\\\+]*');
}

function generateLeetVariants(word) {
  if (!word || typeof word !== 'string') return [];
  const clean = word.toLowerCase();
  const variants = new Set([clean]);

  const map = {
    'a': ['@', '4'],
    'e': ['3'],
    'i': ['1', '!'],
    'o': ['0'],
    's': ['$', '5'],
    't': ['7']
  };

  let v1 = clean;
  for (const [k, arr] of Object.entries(map)) {
    v1 = v1.replaceAll(k, arr[0]);
  }
  variants.add(v1);
  variants.add(clean.split('').join('.'));
  variants.add(clean.split('').join(' '));

  return Array.from(variants);
}

function compileWordRegex(rawWord) {
  if (!rawWord || typeof rawWord !== 'string') return null;
  const word = rawWord.trim().toLowerCase();
  if (word.length === 0 || word.length > MAX_BANNED_WORD_LENGTH) return null;

  const pattern = generateLeetPattern(word);
  if (!pattern) return null;

  try {
    // Unicode-aware word boundary lookarounds with u and i flags
    return new RegExp(`(?<![\\p{L}\\p{N}])${pattern}(?![\\p{L}\\p{N}])`, 'iu');
  } catch (e) {
    try {
      return new RegExp(`(?:^|[^\\p{L}\\p{N}])${pattern}(?:[^\\p{L}\\p{N}]|$)`, 'iu');
    } catch (_) {
      return null;
    }
  }
}

function invalidateBannedWordsCache(guildId) {
  if (!guildId) return;
  _BANNED_WORDS_REGEX_CACHE.delete(String(guildId));
}

function getPrecompiledBannedWordRegexes(guildId, wordsList = null) {
  const gid = guildId ? String(guildId) : null;
  if (gid && _BANNED_WORDS_REGEX_CACHE.has(gid)) {
    return _BANNED_WORDS_REGEX_CACHE.get(gid);
  }

  const list = wordsList || (gid ? getBannedWords(gid) : []);
  if (!Array.isArray(list) || list.length === 0) {
    if (gid) _BANNED_WORDS_REGEX_CACHE.set(gid, []);
    return [];
  }

  const cappedList = list.slice(0, MAX_BANNED_WORDS_PER_GUILD);
  const compiled = [];

  for (const item of cappedList) {
    const rawWord = typeof item === 'string' ? item : item?.word;
    const regex = compileWordRegex(rawWord);
    if (regex) {
      compiled.push({ word: rawWord, regex });
    }
  }

  if (gid) {
    _BANNED_WORDS_REGEX_CACHE.set(gid, compiled);
  }
  return compiled;
}

function addBannedWord(guildId, word, addedBy = 'system', isWildcard = 1) {
  if (!guildId || !word) return false;
  const cleanWord = String(word).trim().toLowerCase();
  if (cleanWord.length === 0 || cleanWord.length > MAX_BANNED_WORD_LENGTH) return false;

  const gid = String(guildId);
  const sdb = getServerDb(gid);

  // Cap word count
  const existing = sdb.prepare('SELECT COUNT(*) as cnt FROM automod_banned_words WHERE guild_id = ?').get(gid);
  if (existing && existing.cnt >= MAX_BANNED_WORDS_PER_GUILD) {
    return false;
  }

  // ReDoS validation: ensure compiled regex does not hang
  const compiled = compileWordRegex(cleanWord);
  if (!compiled) return false;

  const testStart = Date.now();
  compiled.test('testing security word boundary performance verification');
  if (Date.now() - testStart > 100) {
    return false; // Reject pathological pattern
  }

  sdb.prepare(`
    INSERT INTO automod_banned_words (guild_id, word, added_by, added_at, is_wildcard)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, word) DO UPDATE SET is_wildcard = excluded.is_wildcard
  `).run(gid, cleanWord, String(addedBy), Math.floor(Date.now() / 1000), isWildcard ? 1 : 0);

  invalidateBannedWordsCache(gid);
  return true;
}

function removeBannedWord(guildId, word) {
  if (!guildId || !word) return false;
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const res = sdb.prepare('DELETE FROM automod_banned_words WHERE guild_id = ? AND word = ?')
    .run(gid, String(word).trim().toLowerCase());
  invalidateBannedWordsCache(gid);
  return res.changes > 0;
}

function getBannedWords(guildId) {
  if (!guildId) return [];
  const sdb = getServerDb(String(guildId));
  return sdb.prepare('SELECT word, added_by, added_at, is_wildcard FROM automod_banned_words WHERE guild_id = ?')
    .all(String(guildId));
}

function clearBannedWords(guildId) {
  if (!guildId) return false;
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const res = sdb.prepare('DELETE FROM automod_banned_words WHERE guild_id = ?').run(gid);
  invalidateBannedWordsCache(gid);
  return res.changes > 0;
}

function checkBannedWords(content, wordsList = null, guildId = null) {
  if (!content) return null;

  const normalized = normalizeText(content);
  const collapsed = collapseRepeatedChars(normalized);

  let compiledList;
  if (guildId || !wordsList) {
    compiledList = getPrecompiledBannedWordRegexes(guildId, wordsList);
  } else {
    compiledList = (wordsList || []).map(item => {
      const rawWord = typeof item === 'string' ? item : item?.word;
      return { word: rawWord, regex: compileWordRegex(rawWord) };
    }).filter(x => x.regex);
  }

  if (!compiledList || compiledList.length === 0) return null;

  const startTime = Date.now();
  const MAX_CHECK_TIME_MS = 50;

  for (const { word, regex } of compiledList) {
    if (Date.now() - startTime > MAX_CHECK_TIME_MS) {
      console.warn('[Automod] checkBannedWords exceeded ReDoS timeout threshold; aborting loop');
      break;
    }
    if (regex.test(content) || regex.test(normalized) || regex.test(collapsed)) {
      return word;
    }
  }

  return null;
}

// ─────────────────────────────────────────────────────────────
// Hardened URLs & Invites Matching
// ─────────────────────────────────────────────────────────────
function extractUrlsAndDomains(content) {
  if (!content || typeof content !== 'string') return [];
  const results = new Set();

  // 1. Markdown masked links: [text](url)
  const mdRegex = /\[([^\]]+)\]\(([^)\s]+)\)/gi;
  let mdMatch;
  while ((mdMatch = mdRegex.exec(content)) !== null) {
    if (mdMatch[2]) results.add(mdMatch[2].trim());
  }

  // 2. Obfuscated and standard invites
  const inviteRegex = /(?:https?:\/\/)?(?:(?:discord|discrod|dlscord)\s*(?:\.|\s*dot\s*)\s*(?:gg|io|me|li)|(?:discord|discordapp)\s*(?:\.|\s*dot\s*)\s*com\s*\/+\s*invite|dsc\s*(?:\.|\s*dot\s*)\s*gg)\s*\/+\s*[a-zA-Z0-9_-]+/gi;
  const inviteMatches = content.match(inviteRegex) || [];
  for (const m of inviteMatches) {
    results.add(m.replace(/\s+/g, '').replace(/dot/gi, '.'));
  }

  // 3. HTTP / HTTPS URLs
  const httpRegex = /https?:\/\/[^\s\)>]+/gi;
  const httpMatches = content.match(httpRegex) || [];
  for (const m of httpMatches) results.add(m);

  // 4. Punycode domains (xn--...)
  const punycodeRegex = /(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)*xn--[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s\)>]*)?/gi;
  const punyMatches = content.match(punycodeRegex) || [];
  for (const m of punyMatches) results.add(m);

  // 5. Schemeless domains with known web TLDs
  const tlds = 'com|org|net|io|gg|xyz|top|info|me|co|dev|app|link|site|online|store|club|vip|live|cc|tv|ru|cn|to|is|ly|gl|edu|gov|biz';
  const schemelessRegex = new RegExp(`(?:^|[\\s\\[\\(\\<])([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\\.(?:${tlds})(?:\\/[^\\s\\)>]*)?)`, 'gi');
  let sm;
  while ((sm = schemelessRegex.exec(content)) !== null) {
    if (sm[1]) results.add(sm[1].trim());
  }

  return Array.from(results);
}

function addAllowedDomain(guildId, domain, addedBy = 'system') {
  if (!guildId || !domain) return false;
  const sdb = getServerDb(String(guildId));
  const clean = String(domain).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  sdb.prepare(`
    INSERT INTO automod_allowed_domains (guild_id, domain, added_by, added_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(guild_id, domain) DO NOTHING
  `).run(String(guildId), clean, String(addedBy), Math.floor(Date.now() / 1000));
  return true;
}

function removeAllowedDomain(guildId, domain) {
  if (!guildId || !domain) return false;
  const sdb = getServerDb(String(guildId));
  const clean = String(domain).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  const res = sdb.prepare('DELETE FROM automod_allowed_domains WHERE guild_id = ? AND domain = ?')
    .run(String(guildId), clean);
  return res.changes > 0;
}

function getAllowedDomains(guildId) {
  if (!guildId) return [];
  const sdb = getServerDb(String(guildId));
  return sdb.prepare('SELECT domain, added_by, added_at FROM automod_allowed_domains WHERE guild_id = ?')
    .all(String(guildId));
}

function checkUnauthorizedLinks(content, allowedDomains = [], options = {}) {
  const extracted = extractUrlsAndDomains(content);
  if (extracted.length === 0) return null;

  const allowedSet = new Set(
    (allowedDomains || [])
      .map(d => (typeof d === 'string' ? d : d?.domain || '').toLowerCase().trim())
      .filter(Boolean)
  );
  allowedSet.add('discord.com');
  allowedSet.add('discord.gg');
  allowedSet.add('discordapp.com');
  allowedSet.add('tenor.com');
  allowedSet.add('giphy.com');

  for (const item of extracted) {
    let urlStr = item;
    if (!urlStr.startsWith('http://') && !urlStr.startsWith('https://')) {
      urlStr = 'https://' + urlStr;
    }

    try {
      const parsed = new URL(urlStr);
      const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
      let isAllowed = false;

      for (const dom of allowedSet) {
        const cleanDom = dom.startsWith('*.') ? dom.slice(2) : dom;
        if (host === cleanDom) {
          isAllowed = true;
          break;
        }
        if (host.endsWith('.' + cleanDom)) {
          const prefix = host.slice(0, host.length - cleanDom.length);
          // Block known untrusted prefixes for test backward-compatibility unless wildcard explicitly configured
          const isUntrustedPrefix = UNTRUSTED_SUBDOMAIN_PREFIXES.some(u => prefix.startsWith(u));
          if (isUntrustedPrefix && !dom.startsWith('*.') && !options.allowAllSubdomains) {
            isAllowed = false;
            break;
          }
          // Explicit subdomain matching: allows *.example.com like docs.example.com
          isAllowed = true;
          break;
        }
      }

      if (!isAllowed) {
        return host || item;
      }
    } catch (e) {
      return item;
    }
  }
  return null;
}

// ─────────────────────────────────────────────────────────────
// Unified Rule Source (automod_rules table single source of truth)
// ─────────────────────────────────────────────────────────────
const DEFAULT_RULES = {
  anti_invite: { filter_type: 'anti_invite', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_link: { filter_type: 'anti_link', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_spam: { filter_type: 'anti_spam', enabled: false, limit_count: 5, time_window: 5, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_caps: { filter_type: 'anti_caps', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_mention: { filter_type: 'anti_mention', enabled: false, limit_count: 5, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_emoji: { filter_type: 'anti_emoji', enabled: false, limit_count: 6, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_zalgo: { filter_type: 'anti_zalgo', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_newlines: { filter_type: 'anti_newlines', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_spoiler: { filter_type: 'anti_spoiler', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_token: { filter_type: 'anti_token', enabled: true, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 2, exemptions: '[]' },
  anti_scam: { filter_type: 'anti_scam', enabled: true, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 2, exemptions: '[]' },
  anti_nsfw: { filter_type: 'anti_nsfw', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  banned_words: { filter_type: 'banned_words', enabled: true, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' },
  anti_selfbot: { filter_type: 'anti_selfbot', enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 2, exemptions: '[]' },
  honeypot: { filter_type: 'honeypot', enabled: false, limit_count: 1, time_window: 0, action: 'timeout_1h', strike_weight: 3, exemptions: '[]' }
};

const LEGACY_KEY_MAP = {
  anti_invite: 'automod_anti_invite',
  anti_link: 'automod_anti_link',
  anti_spam: 'automod_anti_spam',
  anti_caps: 'automod_anti_caps',
  anti_mention: 'automod_anti_mention',
  anti_emoji: 'automod_anti_emoji',
  anti_zalgo: 'automod_anti_zalgo',
  anti_newlines: 'automod_anti_newlines',
  anti_spoiler: 'automod_anti_spoiler',
  anti_token: 'automod_anti_token',
  anti_scam: 'automod_anti_scam',
  anti_nsfw: 'automod_anti_nsfw',
  banned_words: 'automod_banned_words_enabled',
  anti_selfbot: 'automod_selfbot'
};

function getAutomodRule(guildId, filterType) {
  if (!guildId || !filterType) return null;
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const fType = String(filterType).toLowerCase();

  try {
    const row = sdb.prepare(`
      SELECT rule_id, guild_id, filter_type, enabled, limit_count, time_window, action, strike_weight, exemptions, log_channel
      FROM automod_rules
      WHERE guild_id = ? AND (filter_type = ? OR rule_id = ? OR rule_name = ?)
    `).get(gid, fType, fType, fType);

    if (row) {
      let exemptions = [];
      try {
        exemptions = typeof row.exemptions === 'string' ? JSON.parse(row.exemptions) : (row.exemptions || []);
      } catch (_) {}
      return {
        rule_id: row.rule_id || fType,
        guild_id: gid,
        filter_type: row.filter_type || fType,
        enabled: Boolean(row.enabled),
        limit_count: Number(row.limit_count || 0),
        time_window: Number(row.time_window || 0),
        action: row.action || 'escalate',
        strike_weight: Number(row.strike_weight ?? 1),
        exemptions,
        log_channel: row.log_channel || null
      };
    }
  } catch (_) {}

  // Fallback to legacy server_settings or defaults
  const def = DEFAULT_RULES[fType] || { filter_type: fType, enabled: false, limit_count: 1, time_window: 10, action: 'escalate', strike_weight: 1, exemptions: '[]' };
  let enabledVal = def.enabled;
  const legacyKey = LEGACY_KEY_MAP[fType];
  if (legacyKey) {
    try {
      const sRow = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(legacyKey);
      if (sRow && sRow.value !== undefined && sRow.value !== null) {
        enabledVal = (sRow.value === '1' || sRow.value === 'true' || sRow.value === 1);
      }
    } catch (_) {}
  }

  return {
    rule_id: fType,
    guild_id: gid,
    filter_type: fType,
    enabled: Boolean(enabledVal),
    limit_count: def.limit_count,
    time_window: def.time_window,
    action: def.action,
    strike_weight: def.strike_weight,
    exemptions: [],
    log_channel: null
  };
}

function setAutomodRule(guildId, ruleData) {
  if (!guildId || !ruleData || !ruleData.filter_type) return false;
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const fType = String(ruleData.filter_type).toLowerCase();
  const ruleId = String(ruleData.rule_id || fType);
  const enabled = ruleData.enabled ? 1 : 0;
  const limitCount = Number(ruleData.limit_count || 0);
  const timeWindow = Number(ruleData.time_window || 0);
  const action = String(ruleData.action || 'escalate');
  const strikeWeight = Number(ruleData.strike_weight ?? 1);
  const exemptions = typeof ruleData.exemptions === 'string'
    ? ruleData.exemptions
    : JSON.stringify(ruleData.exemptions || []);
  const logChannel = ruleData.log_channel ? String(ruleData.log_channel) : null;

  sdb.prepare(`
    INSERT INTO automod_rules (rule_id, guild_id, filter_type, enabled, limit_count, time_window, action, strike_weight, exemptions, log_channel, rule_name)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, filter_type) DO UPDATE SET
      rule_id = excluded.rule_id,
      enabled = excluded.enabled,
      limit_count = excluded.limit_count,
      time_window = excluded.time_window,
      action = excluded.action,
      strike_weight = excluded.strike_weight,
      exemptions = excluded.exemptions,
      log_channel = excluded.log_channel,
      rule_name = excluded.rule_name
  `).run(ruleId, gid, fType, enabled, limitCount, timeWindow, action, strikeWeight, exemptions, logChannel, fType);

  // Sync to legacy server_settings for backward compatibility
  const legacyKey = LEGACY_KEY_MAP[fType];
  if (legacyKey) {
    try {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES (?, ?, strftime('%s', 'now'))")
        .run(legacyKey, String(enabled));
    } catch (_) {}
  }

  return true;
}

function getAllAutomodRules(guildId) {
  if (!guildId) return {};
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const result = {};

  for (const [k] of Object.entries(DEFAULT_RULES)) {
    result[k] = getAutomodRule(gid, k);
  }

  try {
    const rows = sdb.prepare(`
      SELECT rule_id, guild_id, filter_type, enabled, limit_count, time_window, action, strike_weight, exemptions, log_channel
      FROM automod_rules
      WHERE guild_id = ?
    `).all(gid);

    for (const row of rows) {
      if (row.filter_type) {
        let exemptions = [];
        try {
          exemptions = typeof row.exemptions === 'string' ? JSON.parse(row.exemptions) : (row.exemptions || []);
        } catch (_) {}
        result[row.filter_type] = {
          rule_id: row.rule_id || row.filter_type,
          guild_id: gid,
          filter_type: row.filter_type,
          enabled: Boolean(row.enabled),
          limit_count: Number(row.limit_count || 0),
          time_window: Number(row.time_window || 0),
          action: row.action || 'escalate',
          strike_weight: Number(row.strike_weight ?? 1),
          exemptions,
          log_channel: row.log_channel || null
        };
      }
    }
  } catch (_) {}

  return result;
}

function isFilterEnabled(guildId, filterType) {
  const rule = getAutomodRule(guildId, filterType);
  if (rule?.enabled) return true;
  try {
    const { getSetting } = require('../settings/registry');
    const cleanType = String(filterType).toLowerCase().replace(/^anti_/, '');
    const regVal = getSetting(guildId, `automod.${cleanType}.enabled`);
    if (regVal === true) return true;
  } catch (_) {}
  return Boolean(rule?.enabled);
}

function getRuleConfig(guildId, filterType) {
  return getAutomodRule(guildId, filterType);
}

// ─────────────────────────────────────────────────────────────
// Whitelist & Bypass Resolver (Configurable Admin Bypass)
// ─────────────────────────────────────────────────────────────
function setAutomodBypass(guildId, targetType, targetId, filterKey = 'all', addedBy = 'system') {
  if (!guildId || !targetType || !targetId) return false;
  const sdb = getServerDb(String(guildId));
  sdb.prepare(`
    INSERT INTO automod_bypasses (guild_id, target_type, target_id, filter_key, added_by, added_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, target_type, target_id, filter_key) DO NOTHING
  `).run(String(guildId), targetType, String(targetId), filterKey, String(addedBy), Math.floor(Date.now() / 1000));
  return true;
}

function removeAutomodBypass(guildId, targetType, targetId, filterKey = 'all') {
  if (!guildId || !targetType || !targetId) return false;
  const sdb = getServerDb(String(guildId));
  const res = sdb.prepare(`
    DELETE FROM automod_bypasses
    WHERE guild_id = ? AND target_type = ? AND target_id = ? AND (filter_key = ? OR ? = 'all')
  `).run(String(guildId), targetType, String(targetId), filterKey, filterKey);
  return res.changes > 0;
}

function getAutomodBypasses(guildId) {
  if (!guildId) return [];
  const sdb = getServerDb(String(guildId));
  return sdb.prepare('SELECT target_type, target_id, filter_key, added_by, added_at FROM automod_bypasses WHERE guild_id = ?')
    .all(String(guildId));
}

function isAutomodBypassed(guild, member, channel, filterKey = 'all', authorId = null) {
  if (!guild) return true;
  const resolvedAuthorId = authorId || member?.id || member?.user?.id;
  const guildId = guild.id;

  // 1. Primary Server Owner
  if (resolvedAuthorId) {
    if (guild.ownerId && resolvedAuthorId === guild.ownerId) return true;
  }

  // 2. Antinuke Immunity & Master Whitelist
  if (resolvedAuthorId) {
    if (isImmune(guild, resolvedAuthorId, 'automod') || isImmune(guild, resolvedAuthorId, filterKey)) return true;
  }

  // 3. Channel Whitelist
  const chId = channel?.id;
  if (chId && (isChannelWhitelisted(guildId, chId, 'automod') || isChannelWhitelisted(guildId, chId, filterKey))) {
    return true;
  }

  // 4. Staff administrator permissions (Configurable via automod_admin_bypass; default ON)
  if (member?.permissions?.has) {
    const isAdmin = member.permissions.has(PermissionsBitField.Flags.Administrator);
    if (isAdmin) {
      try {
        const sdb = getServerDb(guildId);
        const adminBypassRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_admin_bypass'").get();
        if (adminBypassRow) {
          const v = String(adminBypassRow.value).toLowerCase().trim();
          if (v === '0' || v === 'false' || v === 'off') {
            // Admin bypass explicitly disabled: compromised admin accounts can be monitored/filtered
          } else {
            return true;
          }
        } else {
          return true; // Default ON
        }
      } catch (_) {
        return true;
      }
    }
  }

  // 5. Automod Bypasses Table
  try {
    const sdb = getServerDb(guildId);
    if (chId) {
      const chBypass = sdb.prepare(`
        SELECT 1 FROM automod_bypasses
        WHERE guild_id = ? AND target_type = 'channel' AND target_id = ? AND (filter_key = 'all' OR filter_key = ?)
      `).get(guildId, chId, filterKey);
      if (chBypass) return true;
    }

    if (resolvedAuthorId) {
      const userBypass = sdb.prepare(`
        SELECT 1 FROM automod_bypasses
        WHERE guild_id = ? AND target_type = 'user' AND target_id = ? AND (filter_key = 'all' OR filter_key = ?)
      `).get(guildId, resolvedAuthorId, filterKey);
      if (userBypass) return true;
    }

    if (member?.roles?.cache?.size > 0) {
      const roleIds = [...member.roles.cache.keys()];
      const placeholders = roleIds.map(() => '?').join(',');
      const roleBypass = sdb.prepare(`
        SELECT 1 FROM automod_bypasses
        WHERE guild_id = ? AND target_type = 'role' AND target_id IN (${placeholders}) AND (filter_key = 'all' OR filter_key = ?)
      `).get(guildId, ...roleIds, filterKey);
      if (roleBypass) return true;
    }
  } catch (e) {}

  return false;
}

// ─────────────────────────────────────────────────────────────
// Native AutoMod Deduplication Routing
// ─────────────────────────────────────────────────────────────
function isNativeAutomodActive(guild, filterType) {
  if (!guild) return false;
  try {
    const sdb = getServerDb(guild.id);
    const nativeRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_native_routing' OR key = 'use_native_automod'").get();
    if (nativeRow && (nativeRow.value === '1' || nativeRow.value === 'true')) {
      if (['keyword', 'banned_words', 'mention', 'anti_mention', 'regex'].includes(filterType)) {
        return true;
      }
    }
    // Check guild native rules cache if available
    if (guild.autoModerationRules?.cache?.size > 0) {
      for (const rule of guild.autoModerationRules.cache.values()) {
        if (!rule.enabled) continue;
        if ((filterType === 'banned_words' || filterType === 'keyword') && rule.triggerType === 1) return true;
        if ((filterType === 'anti_mention' || filterType === 'mention') && rule.triggerType === 5) return true;
      }
    }
  } catch (_) {}
  return false;
}

// ─────────────────────────────────────────────────────────────
// Escalation Ladder & Incident Dispatch (Connected to warnLadder)
// ─────────────────────────────────────────────────────────────
async function handleAutomodEscalation(guild, member, violation, client, authorId = null) {
  const targetUserId = member?.id || member?.user?.id || authorId;
  if (!targetUserId) {
    return { strikes: 1, action: 'delete', penaltyText: 'Warning notice issued' };
  }

  const sdb = getServerDb(guild.id);
  const nowSec = Math.floor(Date.now() / 1000);

  // Custom strike decay hours
  const decayRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_strike_decay'").get();
  const decayHours = decayRow && !isNaN(decayRow.value) ? Number(decayRow.value) : 24;
  const decaySec = decayHours * 3600;

  let strikes = 0;
  const strikeRow = sdb.prepare('SELECT strikes, last_strike_at FROM automod_strikes WHERE guild_id = ? AND user_id = ?')
    .get(guild.id, targetUserId);

  if (strikeRow) {
    if (nowSec - strikeRow.last_strike_at > decaySec) {
      // Decay window elapsed: reset strikes in DB to 0 first, so new strike becomes 1
      sdb.prepare('UPDATE automod_strikes SET strikes = 0 WHERE guild_id = ? AND user_id = ?')
        .run(guild.id, targetUserId);
      strikes = 1;
    } else {
      strikes = (strikeRow.strikes || 0) + 1;
    }
    sdb.prepare('UPDATE automod_strikes SET strikes = ?, last_strike_at = ? WHERE guild_id = ? AND user_id = ?')
      .run(strikes, nowSec, guild.id, targetUserId);
  } else {
    strikes = 1;
    sdb.prepare('INSERT INTO automod_strikes (guild_id, user_id, strikes, last_strike_at) VALUES (?, ?, 1, ?)')
      .run(guild.id, targetUserId, nowSec);
  }

  const botId = client?.user?.id || 'system';

  // Check configured Automod Action Policy
  const actRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_action'").get();
  const configuredAction = (actRow?.value || 'escalation').toLowerCase();

  let action = 'delete';
  let penaltyText = 'Warning notice issued';

  if (configuredAction === 'warn') {
    action = 'warn';
    penaltyText = 'Formal Automod Warning Recorded';
    sdb.prepare('INSERT INTO member_warnings (guild_id, user_id, moderator_id, reason, timestamp) VALUES (?, ?, ?, ?, ?)')
      .run(guild.id, targetUserId, botId, `[Automod] ${violation}`, nowSec);
    createCase(guild.id, sdb, {
      action: 'warn',
      targetId: targetUserId,
      moderatorId: botId,
      reason: `[Automod] ${violation}`,
      timestamp: nowSec
    });
  } else if (configuredAction === 'ban') {
    action = 'ban';
    penaltyText = 'Permanent Server Ban';
    if (member?.bannable && typeof member.ban === 'function') {
      await member.ban({ reason: `[Automod Ban Policy] ${violation}` }).catch(() => null);
    }
    createCase(guild.id, sdb, {
      action: 'ban',
      targetId: targetUserId,
      moderatorId: botId,
      reason: `[Automod Ban Policy] ${violation}`,
      timestamp: nowSec
    });
  } else if (configuredAction === 'kick') {
    action = 'kick';
    penaltyText = 'Server Kick Penalty';
    if (member?.kickable && typeof member.kick === 'function') {
      await member.kick(`[Automod Kick Policy] ${violation}`).catch(() => null);
    }
    createCase(guild.id, sdb, {
      action: 'kick',
      targetId: targetUserId,
      moderatorId: botId,
      reason: `[Automod Kick Policy] ${violation}`,
      timestamp: nowSec
    });
  } else if (configuredAction.startsWith('timeout') || configuredAction === 'mute') {
    let durMs = 600000;
    if (configuredAction === 'timeout_1m') durMs = 60000;
    else if (configuredAction === 'timeout_5m') durMs = 300000;
    else if (configuredAction === 'timeout_10m') durMs = 600000;
    else if (configuredAction === 'timeout_1h') durMs = 3600000;
    else if (configuredAction === 'timeout_24h') durMs = 86400000;
    else {
      const durRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_timeout_duration'").get();
      if (durRow?.value && !isNaN(durRow.value)) durMs = Number(durRow.value) * 1000;
    }

    action = 'timeout';
    penaltyText = `${Math.round(durMs / 60000)}-Minute Quarantine Timeout`;
    if (member?.moderatable && typeof member.timeout === 'function') {
      await member.timeout(durMs, `[Automod Timeout Policy] ${violation}`).catch(() => null);
    }
    createCase(guild.id, sdb, {
      action: 'timeout',
      targetId: targetUserId,
      moderatorId: botId,
      reason: `[Automod Timeout Policy] ${violation}`,
      timestamp: nowSec
    });
  } else {
    // 5. Warning & Escalation: Connect strikes to warnLadder.js
    let ladderExecuted = false;
    if (member) {
      try {
        const ladderRes = await checkAndExecuteLadder(guild, member, strikes, client);
        if (ladderRes && ladderRes.success) {
          ladderExecuted = true;
          action = ladderRes.action;
          penaltyText = `Warn Ladder: ${ladderRes.action.toUpperCase()} (${ladderRes.durationStr})`;
        }
      } catch (_) {}
    }

    if (!ladderExecuted) {
      // Default 5-tier escalation ladder
      if (strikes === 2) {
        action = 'warn';
        penaltyText = 'Formal Automod Warning Recorded';
        sdb.prepare('INSERT INTO member_warnings (guild_id, user_id, moderator_id, reason, timestamp) VALUES (?, ?, ?, ?, ?)')
          .run(guild.id, targetUserId, botId, `[Automod] ${violation} (Strike 2)`, nowSec);
        createCase(guild.id, sdb, {
          action: 'warn',
          targetId: targetUserId,
          moderatorId: botId,
          reason: `[Automod] ${violation} (Strike 2)`,
          timestamp: nowSec
        });
      } else if (strikes === 3) {
        action = 'timeout_10m';
        penaltyText = '10-Minute Quarantine Timeout';
        if (member?.moderatable && typeof member.timeout === 'function') {
          await member.timeout(600000, `[Automod Escalation] ${violation} (Strike 3)`).catch(() => null);
        }
        createCase(guild.id, sdb, {
          action: 'timeout',
          targetId: targetUserId,
          moderatorId: botId,
          reason: `[Automod 10m Timeout] ${violation} (Strike 3)`,
          timestamp: nowSec
        });
      } else if (strikes === 4) {
        action = 'timeout_1h';
        penaltyText = '1-Hour Quarantine Timeout';
        if (member?.moderatable && typeof member.timeout === 'function') {
          await member.timeout(3600000, `[Automod Escalation] ${violation} (Strike 4)`).catch(() => null);
        }
        createCase(guild.id, sdb, {
          action: 'timeout',
          targetId: targetUserId,
          moderatorId: botId,
          reason: `[Automod 1h Timeout] ${violation} (Strike 4)`,
          timestamp: nowSec
        });
      } else if (strikes === 5) {
        action = 'kick';
        penaltyText = 'Server Kick Penalty';
        if (member?.kickable && typeof member.kick === 'function') {
          await member.kick(`[Automod Escalation] ${violation} (Strike 5)`).catch(() => null);
        }
        createCase(guild.id, sdb, {
          action: 'kick',
          targetId: targetUserId,
          moderatorId: botId,
          reason: `[Automod Kick] ${violation} (Strike 5)`,
          timestamp: nowSec
        });
      } else if (strikes >= 6) {
        action = 'ban';
        penaltyText = 'Permanent Server Ban';
        if (member?.bannable && typeof member.ban === 'function') {
          await member.ban({ reason: `[Automod Escalation] ${violation} (Strike ${strikes})` }).catch(() => null);
        }
        createCase(guild.id, sdb, {
          action: 'ban',
          targetId: targetUserId,
          moderatorId: botId,
          reason: `[Automod Ban] ${violation} (Strike ${strikes})`,
          timestamp: nowSec
        });
      }
    }
  }

  return { strikes, action, penaltyText };
}

async function dispatchAutomodLog(guild, member, channel, violation, escalation, content, client, activeFilterKey = null) {
  try {
    const sdb = getServerDb(guild.id);
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_log_channel'").get();
    const logChannelId = row?.value || getSetting(guild.id, 'automod.log_channel');
    if (!logChannelId) return;

    const logChan = guild.channels?.cache?.get(logChannelId) || await client.channels.fetch(logChannelId).catch(() => null);
    if (!logChan || typeof logChan.send !== 'function') return;

    const authorId = member?.id || member?.user?.id || 'Unknown';
    const authorTag = member?.user?.tag || member?.displayName || 'User';

    const sirenEmoji = resolveEmoji(client, 'siren') || '<a:tungsten_siren:1567242157725712555>';
    const warnEmoji = resolveEmoji(client, 'warn') || '<a:tungsten_warn:1567246685082746940>';
    const isTokenLeak = activeFilterKey === 'anti_token' || violation.toLowerCase().includes('token');

    // Keep original unnormalized text for audit logs (redact tokens)
    let snippet = isTokenLeak
      ? '[TOKEN CONTENT REDACTED FOR SECURITY]'
      : (content || '*[No content]*').replace(/`/g, "'");
    if (snippet.length > 250) snippet = snippet.slice(0, 250) + '...';

    const chName = channel?.name || 'unknown';
    const chId = channel?.id || '0';
    const penaltyStr = typeof escalation === 'string' ? escalation : escalation?.penaltyText;
    const strikesCount = typeof escalation === 'object' ? escalation?.strikes : 1;

    let description =
      `> Deep packet inspection captured an unauthorized chat transmission.\n\n` +
      `• **Offender:** <@${authorId}> (\`${authorId}\`)\n` +
      `• **Channel:** <#${chId}> (\`#${chName}\`)\n` +
      `• **Violation:** \`${violation}\`\n` +
      `• **Applied Penalty:** \`${penaltyStr}\` (Strike **${strikesCount}**)\n` +
      `• **Content Snippet:**\n\`\`\`fix\n${snippet}\n\`\`\``;

    if (isTokenLeak) {
      description =
        `> ${sirenEmoji} **BOT TOKEN ROTATION ALERT — COMPROMISED CREDENTIALS**\n` +
        `> A Discord authorization token pattern was detected and intercepted. If this token belongs to an active bot or application, it must be invalidated and rotated immediately via the Discord Developer Portal.\n\n` +
        `• **Offender:** <@${authorId}> (\`${authorId}\`)\n` +
        `• **Channel:** <#${chId}> (\`#${chName}\`)\n` +
        `• **Violation:** \`${violation}\`\n` +
        `• **Applied Penalty:** \`${penaltyStr}\` (Strike **${strikesCount}**)\n` +
        `• **Rotation Notice:** ${warnEmoji} \`CRITICAL: Immediate bot token revocation & rotation advised at discord.com/developers/applications\`\n` +
        `• **Content Snippet:**\n\`\`\`fix\n${snippet}\n\`\`\``;
    }

    const embed = createEmbed({
      color: isTokenLeak ? 0xFF0000 : 0xED4245,
      title: `${sirenEmoji}  Automod Interception Incident`,
      description,
      footer: { text: `Tungsten Automod 2.0 Incident Telemetry • Target: ${authorTag}` },
      timestamp: true
    });

    const actionRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`am:pardon:${authorId}`)
        .setLabel('Pardon Strike')
        .setStyle(ButtonStyle.Success)
        .setEmoji('<a:tungsten_success:1567242523468890274>'),
      new ButtonBuilder()
        .setCustomId(`am:timeout:${authorId}`)
        .setLabel('Timeout 24h')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('<a:tungsten_warn:1567246685082746940>'),
      new ButtonBuilder()
        .setCustomId(`am:ban:${authorId}`)
        .setLabel('Ban Member')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('<a:tungsten_close:1567234632905138206>')
    );

    await logChan.send({ embeds: [embed], components: [actionRow] }).catch(() => null);
  } catch (e) {
    console.warn('[Automod Engine] Failed to dispatch incident log:', e.message);
  }
}

// ─────────────────────────────────────────────────────────────
// Master Message Inspection Pipeline (Single Punishment Deduplication)
// ─────────────────────────────────────────────────────────────
async function runAutomodCheck(message, client) {
  if (!message || !message.guild || !message.author || message.author.bot) return false;
  const authorId = message.author.id;
  const guildId = message.guild.id;

  // Single-message deduplication: prevent duplicate punishment on a single message
  if (message.id) {
    if (isAutomodDeleted(message.id) || isAutomodPunished(message.id)) {
      return false;
    }
  }

  // Master bypass check
  if (isAutomodBypassed(message.guild, message.member, message.channel, 'all', authorId)) {
    return false;
  }

  const sdb = getServerDb(guildId);

  // 0. Honeypot Channel Sentry Enforcement
  try {
    const hpRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_channel'").get();
    if (hpRow?.value && message.channel.id === hpRow.value) {
      if (!isAutomodBypassed(message.guild, message.member, message.channel, 'honeypot', authorId)) {
        if (message.id) {
          recordAutomodDeleted(message.id);
          recordAutomodPunished(message.id);
        }
        try {
          if (message.deletable !== false && typeof message.delete === 'function') {
            await message.delete().catch(() => null);
          }
        } catch (_) {}

        const hpActRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_action'").get();
        const hpAction = (hpActRow?.value || 'timeout_1h').toLowerCase();

        let actionDesc = 'Timed out (1h)';
        if (message.member && message.member.moderatable) {
          if (hpAction === 'ban') {
            await message.member.ban({ reason: 'Tungsten Honeypot: Unauthorized channel message' }).catch(() => null);
            actionDesc = 'Banned from server';
          } else if (hpAction === 'kick') {
            await message.member.kick('Tungsten Honeypot: Unauthorized channel message').catch(() => null);
            actionDesc = 'Kicked from server';
          } else if (hpAction === 'strip') {
            const rolesArr = typeof message.member.roles.cache.filter === 'function'
              ? message.member.roles.cache.filter(r => r.id !== message.guild.id && !r.managed && (r.position === undefined || r.position < (message.guild.members.me?.roles.highest.position || 999)))
              : [...message.member.roles.cache.values()].filter(r => r.id !== message.guild.id && !r.managed);
            if (rolesArr.length > 0 || rolesArr.size > 0) {
              await message.member.roles.remove(rolesArr, 'Tungsten Honeypot: Role strip penalty').catch(() => null);
            }
            actionDesc = 'Roles stripped';
          } else if (hpAction === 'timeout_24h' || hpAction === 'timeout_1d') {
            await message.member.timeout(24 * 60 * 60 * 1000, 'Tungsten Honeypot: Unauthorized channel message').catch(() => null);
            actionDesc = 'Timed out for 24 hours';
          } else if (hpAction === 'timeout_10m') {
            await message.member.timeout(10 * 60 * 1000, 'Tungsten Honeypot: Unauthorized channel message').catch(() => null);
            actionDesc = 'Timed out for 10 minutes';
          } else {
            await message.member.timeout(60 * 60 * 1000, 'Tungsten Honeypot: Unauthorized channel message').catch(() => null);
            actionDesc = 'Timed out for 1 hour';
          }
        }

        await dispatchAutomodLog(
          message.guild,
          message.author,
          message.channel,
          'Honeypot Channel Trigger',
          actionDesc,
          message.content?.slice(0, 500) || '<attachment/empty>',
          client
        );

        const alertNotice = await message.channel.send({
          content: `<a:tungsten_warn:1567246685082746940> <@${authorId}>, speaking in the restricted honeypot channel is prohibited. Action: \`${actionDesc}\`.`
        }).catch(() => null);
        if (alertNotice) setTimeout(() => alertNotice.delete().catch(() => null), 6000);

        return true;
      }
    }
  } catch (_) {}

  const rawContent = message.content || '';
  const normalizedContent = normalizeText(rawContent);

  // Deep scan composite: concatenate message text, embed contents, and attachment filenames
  const scanParts = [rawContent, normalizedContent];
  if (Array.isArray(message.embeds) && message.embeds.length > 0) {
    for (const emb of message.embeds) {
      if (!emb) continue;
      if (emb.title) scanParts.push(emb.title);
      if (emb.description) scanParts.push(emb.description);
      if (emb.url) scanParts.push(emb.url);
      if (Array.isArray(emb.fields)) {
        for (const f of emb.fields) {
          if (f?.name) scanParts.push(f.name);
          if (f?.value) scanParts.push(f.value);
        }
      }
      if (emb.footer?.text) scanParts.push(emb.footer.text);
      if (emb.author?.name) scanParts.push(emb.author.name);
    }
  }

  if (message.attachments) {
    const attachNames = (typeof message.attachments.map === 'function'
      ? message.attachments.map(a => a?.name || '')
      : Array.isArray(message.attachments)
        ? message.attachments.map(a => a?.name || '')
        : []
    ).filter(Boolean);
    if (attachNames.length > 0) {
      scanParts.push(...attachNames);
    }
  }

  const fullScanContent = scanParts.join(' ');
  let violation = null;
  let activeFilterKey = null;

  // 1. Leaked Token Protection (Critical Security Guard & Rotation Alert)
  if (!violation && TOKEN_REGEX.test(fullScanContent)) {
    violation = 'Leaked Discord API authorization token';
    activeFilterKey = 'anti_token';

    if (client?.token && fullScanContent.includes(client.token)) {
      console.error(`[CRITICAL SECURITY ALERT] Tungsten Bot Token leak detected in guild ${guildId} by user ${authorId}! Token intercepted and message purged.`);
    }
  }

  // 2. Phishing & Malicious Scam Filter
  if (!violation && PHISHING_REGEX.test(fullScanContent)) {
    violation = 'Malicious phishing / fake Nitro gift link';
    activeFilterKey = 'anti_scam';
  }

  // 3. Custom Server Banned Words (Native AutoMod Deduplication Routing)
  if (!violation && fullScanContent.length > 0) {
    const isWordsEnabled = isFilterEnabled(guildId, 'banned_words');
    const isRoutedToNative = isNativeAutomodActive(message.guild, 'banned_words');

    if (isWordsEnabled && !isRoutedToNative && !isAutomodBypassed(message.guild, message.member, message.channel, 'banned_words')) {
      const matchedWord = checkBannedWords(fullScanContent, null, guildId);
      if (matchedWord) {
        violation = `Prohibited keyword: ||${matchedWord}||`;
        activeFilterKey = 'banned_words';
      }
    }
  }

  // 4. Anti-Spam Rate Limiter (Velocity tracking with size bounds)
  const isSpamEnabled = isFilterEnabled(guildId, 'anti_spam');
  const spamConfigRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_spam_limit' OR key = 'automod_spam_window'").get();
  if (!violation && (isSpamEnabled || Boolean(spamConfigRow)) && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_spam')) {
    const spamLimit = getSettingNumber(sdb, 'automod_spam_limit', 5);
    const rawSpamWindow = getSettingNumber(sdb, 'automod_spam_window', 5000);
    const spamWindow = rawSpamWindow < 100 ? rawSpamWindow * 1000 : rawSpamWindow;

    const spamKey = `${guildId}:${authorId}`;
    const now = Date.now();
    let timestamps = _SPAM_TRACKER.get(spamKey) || [];
    timestamps = timestamps.filter(t => now - t < spamWindow);
    timestamps.push(now);
    _SPAM_TRACKER.set(spamKey, timestamps);
    enforceMapCap(_SPAM_TRACKER, MAX_TRACKER_ENTRIES);

    if (timestamps.length >= spamLimit) {
      violation = 'High-frequency message spamming';
      activeFilterKey = 'anti_spam';
    }
  }

  // 5. Repeated Duplicate Message Spam (Bounded tracker)
  if (!violation && rawContent.length >= 10 && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_spam')) {
    const rawDupWindow = getSettingNumber(sdb, 'automod_dup_window', 10000);
    const dupWindow = rawDupWindow < 100 ? rawDupWindow * 1000 : rawDupWindow;

    const dupKey = `${guildId}:${authorId}`;
    const now = Date.now();
    const cleanText = rawContent.toLowerCase().replace(/\s+/g, '');
    const prev = _DUPLICATE_TRACKER.get(dupKey);

    if (prev && prev.text === cleanText && now - prev.timestamp < dupWindow) {
      violation = 'Repeated duplicate message spam';
      activeFilterKey = 'anti_spam';
    } else {
      _DUPLICATE_TRACKER.set(dupKey, { text: cleanText, timestamp: now });
      enforceMapCap(_DUPLICATE_TRACKER, MAX_TRACKER_ENTRIES);
    }
  }

  // 6. Anti-Invite
  if (!violation) {
    const isInviteEnabled = isFilterEnabled(guildId, 'anti_invite');
    if (isInviteEnabled && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_invite')) {
      if (INVITE_REGEX.test(fullScanContent)) {
        violation = 'Posting unauthorized Discord invite links';
        activeFilterKey = 'anti_invite';
      }
    }
  }

  // 7. Anti-Link (with domain allowlist & explicit subdomain matching)
  if (!violation) {
    const isLinkEnabled = isFilterEnabled(guildId, 'anti_link');
    if (isLinkEnabled && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_link')) {
      const allowedDomains = getAllowedDomains(guildId);
      const unauthorizedHost = checkUnauthorizedLinks(fullScanContent, allowedDomains);
      if (unauthorizedHost) {
        violation = `Posting unauthorized external link (${unauthorizedHost})`;
        activeFilterKey = 'anti_link';
      }
    }
  }

  // 8. Anti-Caps (>= 8 letters and >= 70% uppercase)
  if (!violation && rawContent.length >= 8) {
    const isCapsEnabled = isFilterEnabled(guildId, 'anti_caps');
    if (isCapsEnabled && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_caps')) {
      const letters = rawContent.replace(/[^a-zA-Z]/g, '');
      if (letters.length >= 8) {
        const uppers = rawContent.replace(/[^A-Z]/g, '').length;
        if (uppers / letters.length >= 0.7) {
          violation = 'Excessive uppercase / caps lock spam';
          activeFilterKey = 'anti_caps';
        }
      }
    }
  }

  // 9. Anti-Mention Spam (Native AutoMod Deduplication Routing)
  if (!violation) {
    const isMentionEnabled = isFilterEnabled(guildId, 'anti_mention');
    const isRoutedToNative = isNativeAutomodActive(message.guild, 'anti_mention');
    const mentionThresholdRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_mention_threshold'").get();
    const isMentionActive = isMentionEnabled || Boolean(mentionThresholdRow);

    if (isMentionActive && !isRoutedToNative && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_mention')) {
      const userMentions = message.mentions?.users?.size || 0;
      const roleMentions = message.mentions?.roles?.size || 0;
      const everyoneScore = rawContent.includes('@everyone') ? 5 : (rawContent.includes('@here') ? 3 : 0);
      const totalScore = userMentions + (roleMentions * 2) + everyoneScore;

      const mentionLimit = getSettingNumber(sdb, 'automod_mention_threshold', 5);
      if (totalScore > mentionLimit) {
        violation = 'Mass ping / mention spam violation';
        activeFilterKey = 'anti_mention';
      }
    }
  }

  // 10. Anti-Emoji Spam (> 6 custom or unicode Extended_Pictographic emojis)
  if (!violation && isFilterEnabled(guildId, 'anti_emoji') && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_emoji')) {
    const customEmojis = (rawContent.match(/<a?:\w+:\d+>/g) || []).length;
    const unicodeEmojis = (rawContent.match(UNICODE_EMOJI_REGEX) || []).length;
    if (customEmojis + unicodeEmojis > 6) {
      violation = 'Excessive emoji spam violation';
      activeFilterKey = 'anti_emoji';
    }
  }

  // 11. Anti-Zalgo / Glitch Text Flood
  if (!violation && isFilterEnabled(guildId, 'anti_zalgo') && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_zalgo')) {
    if (ZALGO_REGEX.test(rawContent)) {
      violation = 'Malicious combining diacritics / zalgo glitch text flood';
      activeFilterKey = 'anti_zalgo';
    }
  }

  // 12. Anti-Newlines / Line break flood
  if (!violation && isFilterEnabled(guildId, 'anti_newlines') && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_newlines')) {
    if (NEWLINES_REGEX.test(rawContent)) {
      violation = 'Excessive newline / blank line chat flood';
      activeFilterKey = 'anti_newlines';
    }
  }

  // 13. Anti-Spoiler spam
  if (!violation && isFilterEnabled(guildId, 'anti_spoiler') && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_spoiler')) {
    if (SPOILER_REGEX.test(rawContent)) {
      violation = 'Excessive spoiler tag abuse';
      activeFilterKey = 'anti_spoiler';
    }
  }

  // 14. Anti-NSFW Content
  if (!violation) {
    const isNsfwEnabled = isFilterEnabled(guildId, 'anti_nsfw');
    if (isNsfwEnabled && !message.channel.nsfw && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_nsfw')) {
      if (NSFW_TERMS_REGEX.test(fullScanContent)) {
        violation = 'Explicit / NSFW content posted in non-NSFW channel';
        activeFilterKey = 'anti_nsfw';
      }
    }
  }

  // 15. Anti-Selfbot / Unauthorized Userbot Detection
  if (!violation) {
    const isSelfbotEnabled = isFilterEnabled(guildId, 'anti_selfbot');
    const selfbotRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_selfbot'").get();
    const selfbotConfigured = selfbotRow ? (selfbotRow.value === '1' || selfbotRow.value === 'true' || selfbotRow.value === 1) : false;

    if ((isSelfbotEnabled || selfbotConfigured) && !isAutomodBypassed(message.guild, message.member, message.channel, 'anti_selfbot')) {
      const hasSelfbotEmbed = Array.isArray(message.embeds) && message.embeds.some(e => {
        if (!e) return false;
        if (e.type === 'rich') return true;
        return Boolean(e.title && e.description && !e.provider && !e.url && !e.video);
      });

      if (hasSelfbotEmbed && !message.author.bot && !message.webhookId) {
        violation = 'Unauthorized selfbot / automated user account activity detected';
        activeFilterKey = 'anti_selfbot';
      }
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Intercept & Execute Penalty (Single Punishment Execution)
  // ─────────────────────────────────────────────────────────────
  if (violation) {
    try {
      if (message.id) {
        recordAutomodDeleted(message.id);
        recordAutomodPunished(message.id);
      }

      if (message.deletable !== false && typeof message.delete === 'function') {
        await message.delete().catch(() => null);
      }

      // Execute escalation ladder connected to warnLadder
      const escalation = await handleAutomodEscalation(message.guild, message.member, violation, client, authorId);

      // Record in automod_logs
      try {
        const channelId = message.channel?.id || '0';
        sdb.prepare(`
          INSERT INTO automod_logs (guild_id, user_id, channel_id, violation, action_taken, content_snippet, timestamp)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(guildId, authorId, channelId, violation, escalation.action, (rawContent || '').slice(0, 200), Math.floor(Date.now() / 1000));
      } catch (e) {}

      // Dispatch to incident log channel
      await dispatchAutomodLog(message.guild, message.member, message.channel, violation, escalation, rawContent, client, activeFilterKey);

      if (typeof message.channel?.send === 'function') {
        const warnEmoji = resolveEmoji(client, 'warn') || '<a:tungsten_warn:1567246685082746940>';
        const shieldEmoji = resolveEmoji(client, 'shield') || '<a:tungsten_shield:1567242104923627574>';
        const sirenEmoji = resolveEmoji(client, 'siren') || '<a:tungsten_siren:1567242157725712555>';

        let noticeMsg = `${warnEmoji} <@${authorId}>, message intercepted by **Tungsten Automod**: *${violation}*.\n`;
        if (activeFilterKey === 'anti_token') {
          noticeMsg += `-# ${sirenEmoji} **SECURITY NOTICE:** \`Token detected and redacted. Invalidate compromised credentials immediately!\`\n`;
        }
        noticeMsg += `-# ${shieldEmoji} **Penalty:** \`${escalation.penaltyText}\` • **Strike:** \`${escalation.strikes}\``;

        const warnNotice = await message.channel.send({
          content: noticeMsg
        }).catch(() => null);

        if (warnNotice && typeof warnNotice.delete === 'function') {
          setTimeout(() => warnNotice.delete().catch(() => null), 5000);
        }
      }
      return true;
    } catch (e) {}
  }

  return false;
}

// Helper to inspect arbitrary text (nicknames, usernames, thread titles)
function checkAutomodText(text, guild, client = null, options = {}) {
  if (!text || typeof text !== 'string' || !guild) return null;
  const gid = guild.id;
  const normalized = normalizeText(text);

  if (TOKEN_REGEX.test(text) || TOKEN_REGEX.test(normalized)) {
    return { violation: 'Leaked Discord API authorization token', filterType: 'anti_token' };
  }

  if (PHISHING_REGEX.test(text) || PHISHING_REGEX.test(normalized)) {
    return { violation: 'Malicious phishing / scam link', filterType: 'anti_scam' };
  }

  if (isFilterEnabled(gid, 'banned_words')) {
    const matched = checkBannedWords(text, null, gid);
    if (matched) {
      return { violation: `Prohibited keyword: ||${matched}||`, filterType: 'banned_words' };
    }
  }

  if (isFilterEnabled(gid, 'anti_invite')) {
    if (INVITE_REGEX.test(text) || INVITE_REGEX.test(normalized)) {
      return { violation: 'Posting unauthorized Discord invite links', filterType: 'anti_invite' };
    }
  }

  if (isFilterEnabled(gid, 'anti_link')) {
    const allowed = getAllowedDomains(gid);
    const unauth = checkUnauthorizedLinks(text, allowed);
    if (unauth) {
      return { violation: `Posting unauthorized external link (${unauth})`, filterType: 'anti_link' };
    }
  }

  return null;
}

module.exports = {
  runAutomodCheck,
  isAutomodDeleted,
  recordAutomodDeleted,
  isAutomodPunished,
  recordAutomodPunished,
  handleAutomodEscalation,
  isAutomodBypassed,
  checkBannedWords,
  checkUnauthorizedLinks,
  extractUrlsAndDomains,
  addBannedWord,
  removeBannedWord,
  getBannedWords,
  clearBannedWords,
  compileWordRegex,
  getPrecompiledBannedWordRegexes,
  invalidateBannedWordsCache,
  normalizeText,
  collapseRepeatedChars,
  stripZeroWidthAndCombining,
  foldHomoglyphs,
  foldLeetspeak,
  addAllowedDomain,
  removeAllowedDomain,
  getAllowedDomains,
  setAutomodBypass,
  removeAutomodBypass,
  getAutomodBypasses,
  dispatchAutomodLog,
  generateLeetVariants,
  generateLeetPattern,
  getAutomodRule,
  setAutomodRule,
  getAllAutomodRules,
  isFilterEnabled,
  getRuleConfig,
  checkAutomodText,
  isNativeAutomodActive,
  getSpamTrackerSize,
  getDuplicateTrackerSize,
  clearTrackers,
  SAFE_SUBDOMAIN_PREFIXES,
  UNTRUSTED_SUBDOMAIN_PREFIXES,
  PHISHING_REGEX,
  UNICODE_EMOJI_REGEX,
  INVITE_REGEX,
  LINK_REGEX,
  ZALGO_REGEX,
  TOKEN_REGEX,
  NEWLINES_REGEX,
  SPOILER_REGEX,
  DEFAULT_RULES,
  LEGACY_KEY_MAP
};
