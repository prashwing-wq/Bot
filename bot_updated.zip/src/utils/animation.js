/**
 * Tungsten Animation & Visual Matrix Engine (Node.js)
 * High-speed, smooth, multi-stage cyber telemetry and terminal animations.
 * 100% Bespoke Animated Emojis (Zero Default Unicode Emojis).
 */
const { EmbedBuilder } = require('discord.js');
const config = require('../config');

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Executes a sequential animated edit flow over a target message or interaction.
 */
async function animateSequence(target, frames, options = {}) {
  const {
    intervalMs = 600,
    finalEmbed = null,
    finalComponents = []
  } = options;

  let msg = target;
  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    try {
      const payload = {
        embeds: [frame.embed || frame],
        components: frame.components || []
      };

      const isInteraction = 'deferred' in target || (typeof target.isRepliable === 'function' && target.isRepliable());
      if (i === 0 && isInteraction) {
        // Interaction initial reply
        if (!target.deferred && !target.replied) {
          msg = await target.reply({ ...payload, fetchReply: true });
        } else {
          msg = await target.editReply(payload);
        }
      } else if (msg.edit) {
        await msg.edit(payload);
      }
    } catch (e) {
      // If editing fails (e.g. rate limit / network), skip forward
    }

    if (i < frames.length - 1) {
      await sleep(intervalMs);
    }
  }

  // Apply final payload if supplied
  if (finalEmbed && msg && msg.edit) {
    try {
      await msg.edit({
        embeds: [finalEmbed],
        components: finalComponents
      });
    } catch (e) {}
  }

  return msg;
}

/**
 * Builds the 4-stage cyber-matrix arming sequence for Antinuke.
 * Uses bespoke animated loading spinner for engaging multi-step transitions.
 */
function getAntinukeEnableFrames(guildName = 'Server', botAvatar = null) {
  const frames = [];

  // Stage 1: Bootloader
  const embed1 = new EmbedBuilder()
    .setColor(0x007AFF)
    .setTitle('<a:tungsten_loading:1567241050567876698>  TUNGSTEN ZERO-BYPASS DEFENSE MATRIX')
    .setDescription(
      '```ansi\n' +
      '\u001b[1;34m[SYS-CORE]\u001b[0m Initializing Hyperion Bootloader...\n' +
      '\u001b[1;36m[PROGRESS]\u001b[0m [▰▰▱▱▱▱▱▱▱▱] 20%\n' +
      '```\n' +
      '<a:tungsten_loading:1567241050567876698> **Stage 1/4 • Authenticating Security Environment**\n' +
      '▸ `[SYS]` Probing Server Hierarchy & Highest Roles...\n' +
      '▸ `[MEM]` Locating Tungsten Security Roles: Tier I - II...\n' +
      '▸ `[INIT]` Threat Defense Engine Calibrating...'
    )
    .setFooter({ text: 'Zero-Bypass Hyperion Sentinel • Initializing...' });
  if (botAvatar) embed1.setThumbnail(botAvatar);
  frames.push(embed1);

  // Stage 2: Binding Safeguards & Reusing Backup Roles
  const embed2 = new EmbedBuilder()
    .setColor(0x5856D6)
    .setTitle('<a:tungsten_loading:1567241050567876698>  TUNGSTEN ZERO-BYPASS DEFENSE MATRIX')
    .setDescription(
      '```ansi\n' +
      '\u001b[1;35m[SAFEGUARD]\u001b[0m Binding Administrator Fail-Safes...\n' +
      '\u001b[1;36m[PROGRESS]\u001b[0m [▰▰▰▰▱▱▱▱▱▱] 45%\n' +
      '```\n' +
      '<a:tungsten_loading:1567241050567876698> **Stage 2/4 • Linking Backup Safeguards**\n' +
      '▸ `[OK]` **2 Existing Backup Roles Reused** *(Zero Duplicates)*\n' +
      '▸ `[OK]` Role Hierarchy Confirmed Below Tungsten Top Role\n' +
      '▸ `[SYNC]` Dual-Layer Anti-Prune Anchors Injected...'
    )
    .setFooter({ text: 'Zero-Bypass Hyperion Sentinel • Linking Backup Safeguards...' });
  if (botAvatar) embed2.setThumbnail(botAvatar);
  frames.push(embed2);

  // Stage 3: Multi-Depth Audit Interceptors
  const embed3 = new EmbedBuilder()
    .setColor(0xAF52DE)
    .setTitle('<a:tungsten_loading:1567241050567876698>  TUNGSTEN ZERO-BYPASS DEFENSE MATRIX')
    .setDescription(
      '```ansi\n' +
      '\u001b[1;33m[SENTINEL]\u001b[0m Arming Deep Audit Interceptors...\n' +
      '\u001b[1;36m[PROGRESS]\u001b[0m [▰▰▰▰▰▰▰▱▱▱] 75%\n' +
      '```\n' +
      '<a:tungsten_loading:1567241050567876698> **Stage 3/4 • Arming Multi-Depth Threat Sentinels**\n' +
      '▸ `[OK]` Multi-Depth Audit Log Interceptors Armed\n' +
      '▸ `[OK]` Mass-Action Rate Limiters & Quarantine Vault Ready\n' +
      '▸ `[LOCK]` Synchronizing 16 Threat Vectors into Memory...'
    )
    .setFooter({ text: 'Zero-Bypass Hyperion Sentinel • Arming Multi-Depth Sentinels...' });
  if (botAvatar) embed3.setThumbnail(botAvatar);
  frames.push(embed3);

  // Stage 4: Armed & Operational
  const embed4 = new EmbedBuilder()
    .setColor(0x00FF88)
    .setTitle('<a:tungsten_shield:1567242104923627574>  TUNGSTEN ZERO-BYPASS DEFENSE MATRIX')
    .setDescription(
      '```ansi\n' +
      '\u001b[1;32m[ACTIVE]\u001b[0m Hyperion Core Online — Zero-Bypass Shield Locked [100%]\n' +
      '```\n' +
      '<a:tungsten_success:1567242523468890274> **Stage 4/4 • Tungsten Antinuke Fully Armed & Active**\n' +
      '▸ `[SHIELD]` Antinuke is actively monitoring all server events\n' +
      '▸ `[LIMITS]` Rate limit thresholds activated across 16 sentinels\n' +
      '▸ `[PUNISH]` Auto-quarantine & instant demotion active'
    )
    .setFooter({ text: 'Zero-Bypass Hyperion Sentinel • Active & Protected' });
  if (botAvatar) embed4.setThumbnail(botAvatar);
  frames.push(embed4);

  return frames;
}

/**
 * Builds the 3-stage disarming sequence for Antinuke.
 * Uses animated loading spinner during disarming transitions.
 */
function getAntinukeDisableFrames(guildName = 'Server', botAvatar = null) {
  const frames = [];

  const embed1 = new EmbedBuilder()
    .setColor(0xFF9500)
    .setTitle('<a:tungsten_loading:1567241050567876698>  TUNGSTEN DEFENSE MATRIX — DISARMING')
    .setDescription(
      '```ansi\n' +
      '\u001b[1;33m[DISARM]\u001b[0m Decoupling Hyperion Sentinel Matrix...\n' +
      '\u001b[1;36m[PROGRESS]\u001b[0m [▰▰▰▱▱▱▱▱▱▱] 35%\n' +
      '```\n' +
      '<a:tungsten_loading:1567241050567876698> **Stage 1/3 • Decoupling Interceptors**\n' +
      '▸ `[HALT]` Pausing real-time audit log stream...'
    )
    .setFooter({ text: 'Disarming Sentinel...' });
  frames.push(embed1);

  const embed2 = new EmbedBuilder()
    .setColor(0xFF3B30)
    .setTitle('<a:tungsten_loading:1567241050567876698>  TUNGSTEN DEFENSE MATRIX — DISARMING')
    .setDescription(
      '```ansi\n' +
      '\u001b[1;31m[CACHE]\u001b[0m Preserving Backup Roles & Guild Snapshot...\n' +
      '\u001b[1;36m[PROGRESS]\u001b[0m [▰▰▰▰▰▰▰▱▱▱] 70%\n' +
      '```\n' +
      '<a:tungsten_loading:1567241050567876698> **Stage 2/3 • Caching Security State**\n' +
      '▸ `[SAVE]` 2 Backup Roles preserved in memory\n' +
      '▸ `[ZERO-LOSS]` Whitelist & channel configurations preserved'
    )
    .setFooter({ text: 'Preserving Safe State...' });
  frames.push(embed2);

  const embed3 = new EmbedBuilder()
    .setColor(0x555555)
    .setTitle('<a:tungsten_close:1567234632905138206>  TUNGSTEN DEFENSE MATRIX — DISARMED')
    .setDescription(
      '```ansi\n' +
      '\u001b[1;30m[OFFLINE]\u001b[0m Antinuke Disarmed. Server in Normal Mode [100%]\n' +
      '```\n' +
      '<a:tungsten_error:1567238753284653106> **Stage 3/3 • Antinuke is currently Inactive**\n' +
      '▸ `[WARN]` Server actions are no longer monitored by Tungsten\n' +
      '▸ `[RE-ARM]` Type `!antinuke enable` or click Arm below to re-activate'
    )
    .setFooter({ text: 'Antinuke Inactive • Server Unprotected' });
  frames.push(embed3);

  return frames;
}

/**
 * Emergency Panic Lockdown Frames.
 */
function getPanicLockdownFrames() {
  const steps = [
    { title: 'Initiating Panic Lockdown...', progress: '20%' },
    { title: 'Saving Role Permissions & Hierarchy...', progress: '40%' },
    { title: 'Stripping Dangerous Administrator Permissions...', progress: '65%' },
    { title: 'Locking and Hiding Public Channels...', progress: '85%' },
    { title: 'Lockdown Complete. Server in Quarantine Matrix.', progress: '100%' }
  ];

  return steps.map((s, idx) => {
    const isDone = idx === steps.length - 1;
    const icon = isDone ? '<a:tungsten_shield:1567242104923627574>' : '<a:tungsten_loading:1567241050567876698>';
    return new EmbedBuilder()
      .setColor(0xFF0033)
      .setTitle('<a:tungsten_siren:1567242157725712555>  EMERGENCY PANIC LOCKDOWN')
      .setDescription(
        '```ansi\n' +
        `\u001b[1;31m[LOCKDOWN]\u001b[0m ${s.title}\n` +
        `\u001b[1;36m[PROGRESS]\u001b[0m ${s.progress}\n` +
        '```\n' +
        `${icon} **Step ${idx + 1}/${steps.length} • Security Isolation**\n` +
        '▸ `[STATUS]` Emergency countermeasures active\n' +
        '▸ `[ACCESS]` Only Bot Owners and Server Owner can bypass\n' +
        '-# Use `!panic unlock` to restore server permissions.'
      )
      .setFooter({ text: `Emergency Protocol • Step ${idx + 1}/${steps.length}` });
  });
}

/**
 * Emergency Panic Unlock / Restoration Frames.
 */
function getPanicUnlockFrames() {
  const steps = [
    { title: 'Verifying Security Environment...', progress: '35%' },
    { title: 'Re-enabling Channel Send Permissions...', progress: '70%' },
    { title: 'Server Normalcy Restored.', progress: '100%' }
  ];

  return steps.map((s, idx) => {
    const isDone = idx === steps.length - 1;
    const icon = isDone ? '<a:tungsten_success:1567242523468890274>' : '<a:tungsten_loading:1567241050567876698>';
    return new EmbedBuilder()
      .setColor(0x00FF88)
      .setTitle('<a:tungsten_unlock:1567246515209117968>  DISENGAGING PANIC LOCKDOWN')
      .setDescription(
        '```ansi\n' +
        `\u001b[1;32m[RESTORE]\u001b[0m ${s.title}\n` +
        `\u001b[1;36m[PROGRESS]\u001b[0m ${s.progress}\n` +
        '```\n' +
        `${icon} **Step ${idx + 1}/${steps.length} • Restoration**\n` +
        '▸ `[STATUS]` Rebuilding channel permission overwrites\n' +
        '▸ `[CHAT]` Restoring public member communications...'
      )
      .setFooter({ text: `Recovery Protocol • Step ${idx + 1}/${steps.length}` });
  });
}

/**
 * Vulnerability & Security Audit Scanner Frames.
 */
function getSecurityScanFrames(guildName = 'Server') {
  const steps = [
    { text: 'Probing Role Hierarchy & Admin Flags...', progress: '[▰▰▰▱▱▱▱▱▱▱] 30%' },
    { text: 'Scanning External Bots, Integrations & Webhooks...', progress: '[▰▰▰▰▰▰▱▱▱▱] 65%' },
    { text: 'Auditing Verification Levels & Antinuke Sentinels...', progress: '[▰▰▰▰▰▰▰▰▰▱] 90%' }
  ];

  return steps.map((s, idx) => {
    return new EmbedBuilder()
      .setColor(0x000001)
      .setTitle(`<a:tungsten_loading:1567241050567876698>  VULNERABILITY AUDIT • ${guildName}`)
      .setDescription(
        '```ansi\n' +
        `\u001b[1;34m[SCANNER]\u001b[0m ${s.text}\n` +
        `\u001b[1;36m[PROGRESS]\u001b[0m ${s.progress}\n` +
        '```\n' +
        '<a:tungsten_loading:1567241050567876698> Analyzing server security sentinels...\n' +
        '▸ `[CORE]` Analyzing 7 server security vectors\n' +
        '▸ `[VAULT]` Cross-referencing against Tungsten benchmark standards...'
      )
      .setFooter({ text: `Security Audit • Phase ${idx + 1}/${steps.length}` });
  });
}

/**
 * Nuke countdown frames.
 */
function getNukeCountdownFrames(channelName = 'channel') {
  return [
    new EmbedBuilder()
      .setColor(0xFF3B30)
      .setTitle('<a:tungsten_siren:1567242157725712555>  CHANNEL DETONATION INITIATED')
      .setDescription(
        '```ansi\n' +
        `\u001b[1;31m[DETONATION]\u001b[0m Cloning #${channelName}...\n` +
        '\u001b[1;33m[COUNTDOWN]\u001b[0m 3...\n' +
        '```\n' +
        '▸ Preserving channel position, permissions, and topic...'
      ),
    new EmbedBuilder()
      .setColor(0xFF3B30)
      .setTitle('<a:tungsten_siren:1567242157725712555>  CHANNEL DETONATION INITIATED')
      .setDescription(
        '```ansi\n' +
        `\u001b[1;31m[DETONATION]\u001b[0m Purging message history...\n` +
        '\u001b[1;33m[COUNTDOWN]\u001b[0m 2...\n' +
        '```\n' +
        '▸ Duplicating overrides and channel category binding...'
      ),
    new EmbedBuilder()
      .setColor(0xFF3B30)
      .setTitle('<a:tungsten_siren:1567242157725712555>  CHANNEL DETONATION INITIATED')
      .setDescription(
        '```ansi\n' +
        `\u001b[1;31m[DETONATION]\u001b[0m Rebuilding fresh clone...\n` +
        '\u001b[1;33m[COUNTDOWN]\u001b[0m 1...\n' +
        '```\n' +
        '▸ Detonating old channel now!'
      )
  ];
}

module.exports = {
  sleep,
  animateSequence,
  getAntinukeEnableFrames,
  getAntinukeDisableFrames,
  getPanicLockdownFrames,
  getPanicUnlockFrames,
  getSecurityScanFrames,
  getNukeCountdownFrames
};
