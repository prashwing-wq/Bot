/**
 * Tungsten Animated Emoji Suite — Fallback mapping for pending emojis
 * before custom animated art is uploaded.
 */
const emojiFallbacks = require("../data/emojiFallbacks");

module.exports = emojiFallbacks;
