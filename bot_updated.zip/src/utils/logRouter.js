/**
 * Tungsten Log Router Utility (Node.js)
 * Routes specific audit and telemetry event types to dedicated log channels:
 * - Standard categories: log_messages, log_members, log_voice, log_server, log_mod
 * - 22 Granular categories with parent fallbacks and master audit fallback.
 */
const { getServerDb } = require('./serverDb');

const LOG_TYPES = {
  // Standard Categories
  log_messages: 'Message Events (Edits, Deletions, Purges)',
  log_members: 'Member Events (Lifecycle, Roles, Nicknames)',
  log_voice: 'Voice Events (State, Mutes, Deafen, Transitions)',
  log_server: 'Server Events (Channels, Roles, Emojis, Threads)',
  log_mod: 'Moderation Actions & Case Sentinel',

  // 22 Granular Channels
  log_bans: 'Ban & Unban Sentinel',
  log_timeouts: 'Member Timeout & Communication Restraints',
  log_nicknames: 'Member Nickname & Display Updates',
  log_channels: 'Channel Structure & Hierarchy Logs',
  log_roles: 'Role & Permission Logs',
  log_emojis: 'Custom Emoji Logs',
  log_guildupdate: 'Server Configuration & Feature Logs',
  log_security: 'Antinuke & Threat Security Logs',
  log_bots: 'Bot Addition & Permission Logs',
  log_webhooks: 'Webhook Management & Spam Logs',
  log_secure_wl: 'Security Whitelist & Trust Logs',
  log_memberjoin: 'Member Join & Leave Lifecycle Logs',
  log_invites: 'Invite Link & Attribution Logs',
  log_manual: 'Manual Staff Audit Logs & Mod Notes',
  log_tickets: 'Ticket Transcripts & Resolution Logs',
  log_quarantine: 'Threat Quarantine & Isolation Logs',
  log_threads: 'Thread & Forum Lifecycle Logs',
  log_stickers: 'Custom Sticker Logs',
  log_scheduled_events: 'Scheduled Guild Event Logs'
};

const LOG_PARENT_FALLBACKS = {
  log_bans: 'log_mod',
  log_timeouts: 'log_mod',
  log_manual: 'log_mod',
  log_nicknames: 'log_members',
  log_memberjoin: 'log_members',
  log_bots: 'log_members',
  log_channels: 'log_server',
  log_roles: 'log_server',
  log_emojis: 'log_server',
  log_stickers: 'log_server',
  log_threads: 'log_server',
  log_guildupdate: 'log_server',
  log_scheduled_events: 'log_server',
  log_webhooks: 'log_server',
  log_invites: 'log_server',
  log_security: 'audit_log_channel',
  log_secure_wl: 'log_security',
  log_quarantine: 'log_security',
  log_tickets: 'audit_log_channel'
};

/**
 * Resolve the target log channel for a specific log type.
 * Evaluates explicit disables ('off', 'disabled'), direct route settings,
 * hierarchical parent fallbacks, and root audit fallback.
 *
 * @param {import('discord.js').Guild} guild
 * @param {string} type
 * @param {object} [sdb=null]
 * @returns {import('discord.js').GuildBasedChannel|null}
 */
function getLogChannel(guild, type, sdb = null) {
  if (!guild) return null;
  const db = sdb || getServerDb(guild.id);

  // 1. Check specific route setting
  const row = db.prepare('SELECT value FROM server_settings WHERE key = ?').get(type);
  const val = row?.value;

  if (val === 'off' || val === 'disabled') {
    return null;
  }

  if (val) {
    const ch = guild.channels?.cache?.get(val);
    if (ch && (!ch.isTextBased || (typeof ch.isTextBased === 'function' && ch.isTextBased()))) {
      return ch;
    }
  }

  // 2. If unset, check LOG_PARENT_FALLBACKS[type] hierarchy
  let currentKey = type;
  const visited = new Set([type]);
  while (LOG_PARENT_FALLBACKS[currentKey]) {
    const parentKey = LOG_PARENT_FALLBACKS[currentKey];
    if (visited.has(parentKey)) break;
    visited.add(parentKey);

    const parentRow = db.prepare('SELECT value FROM server_settings WHERE key = ?').get(parentKey);
    const parentVal = parentRow?.value;

    if (parentVal === 'off' || parentVal === 'disabled') {
      return null;
    }

    if (parentVal) {
      const parentCh = guild.channels?.cache?.get(parentVal);
      if (parentCh && (!parentCh.isTextBased || (typeof parentCh.isTextBased === 'function' && parentCh.isTextBased()))) {
        return parentCh;
      }
    }

    currentKey = parentKey;
  }

  // 3. Root Fallback to audit_log_channel or logging.mod.channel
  const fallbackRow = db.prepare(
    "SELECT value FROM server_settings WHERE key = 'audit_log_channel' OR key = 'logging.mod.channel'"
  ).get();
  const fallbackVal = fallbackRow?.value;

  if (fallbackVal === 'off' || fallbackVal === 'disabled') {
    return null;
  }

  if (fallbackVal) {
    const fallbackCh = guild.channels?.cache?.get(fallbackVal);
    if (fallbackCh && (!fallbackCh.isTextBased || (typeof fallbackCh.isTextBased === 'function' && fallbackCh.isTextBased()))) {
      return fallbackCh;
    }
  }

  return null;
}

/**
 * Retrieve all log routing settings for a guild.
 *
 * @param {string} guildId
 * @param {object} [sdb=null]
 * @returns {Record<string, string|null>}
 */
function getAllLogSettings(guildId, sdb = null) {
  const db = sdb || getServerDb(guildId);
  const allKeys = [
    'audit_log_channel',
    'log_messages',
    'log_members',
    'log_voice',
    'log_server',
    'log_mod',
    'log_bans',
    'log_timeouts',
    'log_nicknames',
    'log_channels',
    'log_roles',
    'log_emojis',
    'log_guildupdate',
    'log_security',
    'log_bots',
    'log_webhooks',
    'log_secure_wl',
    'log_memberjoin',
    'log_invites',
    'log_manual',
    'log_tickets',
    'log_quarantine',
    'log_threads',
    'log_stickers',
    'log_scheduled_events'
  ];

  const placeholders = allKeys.map(() => '?').join(',');
  const rows = db.prepare(`SELECT key, value FROM server_settings WHERE key IN (${placeholders})`).all(...allKeys);

  const map = {};
  for (const k of allKeys) {
    map[k] = null;
  }

  for (const r of rows) {
    if (r.value) map[r.key] = r.value;
  }
  return map;
}

module.exports = {
  LOG_TYPES,
  LOG_PARENT_FALLBACKS,
  getLogChannel,
  getAllLogSettings
};
