/**
 * Tungsten Atomic Economy Engine (Node.js)
 * Implements atomic balance operations, race-condition immunity, and constraint-safe transfers.
 */
const { getServerDb } = require('./serverDb');

function getBalance(db, userId) {
  const row = db.prepare('SELECT wallet, bank FROM economy_users WHERE user_id = ?').get(String(userId));
  return {
    wallet: row ? (row.wallet || 0) : 0,
    bank: row ? (row.bank || 0) : 0
  };
}

function debitWallet(db, userId, amount) {
  if (amount <= 0) return true;
  const res = db.prepare(`
    UPDATE economy_users
    SET wallet = wallet - ?
    WHERE user_id = ? AND wallet >= ?
  `).run(amount, String(userId), amount);
  return res.changes === 1;
}

function creditWallet(db, userId, amount) {
  if (amount <= 0) return true;
  db.prepare(`
    INSERT INTO economy_users (user_id, wallet, bank)
    VALUES (?, ?, 0)
    ON CONFLICT(user_id) DO UPDATE SET wallet = wallet + ?
  `).run(String(userId), amount, amount);
  return true;
}

function debitBank(db, userId, amount) {
  if (amount <= 0) return true;
  const res = db.prepare(`
    UPDATE economy_users
    SET bank = bank - ?
    WHERE user_id = ? AND bank >= ?
  `).run(amount, String(userId), amount);
  return res.changes === 1;
}

function creditBank(db, userId, amount) {
  if (amount <= 0) return true;
  db.prepare(`
    INSERT INTO economy_users (user_id, wallet, bank)
    VALUES (?, 0, ?)
    ON CONFLICT(user_id) DO UPDATE SET bank = bank + ?
  `).run(String(userId), amount, amount);
  return true;
}

/**
 * Atomic transfer between two accounts inside a single transaction.
 */
function transfer(db, fromUserId, toUserId, amount) {
  if (amount <= 0) return { success: false, reason: 'Invalid amount' };
  const tx = db.transaction((from, to, amt) => {
    db.prepare(`
      INSERT OR IGNORE INTO economy_users (user_id, wallet, bank)
      VALUES (?, 0, 0)
    `).run(String(to));

    const debited = debitWallet(db, from, amt);
    if (!debited) {
      return { success: false, reason: 'Insufficient funds' };
    }

    creditWallet(db, to, amt);
    return { success: true };
  });

  return tx(fromUserId, toUserId, amount);
}

/**
 * Atomic deposit: wallet -> bank
 */
function deposit(db, userId, amount) {
  if (amount <= 0) return { success: false, reason: 'Invalid amount' };
  const tx = db.transaction((uid, amt) => {
    const debited = debitWallet(db, uid, amt);
    if (!debited) return { success: false, reason: 'Insufficient funds' };
    creditBank(db, uid, amt);
    return { success: true };
  });
  return tx(userId, amount);
}

/**
 * Atomic withdraw: bank -> wallet
 */
function withdraw(db, userId, amount) {
  if (amount <= 0) return { success: false, reason: 'Invalid amount' };
  const tx = db.transaction((uid, amt) => {
    const debited = debitBank(db, uid, amt);
    if (!debited) return { success: false, reason: 'Insufficient bank funds' };
    creditWallet(db, uid, amt);
    return { success: true };
  });
  return tx(userId, amount);
}

const MAX_BET = 50000;

function ensureDefaultShopItems(db) {
  try {
    db.prepare(`
      INSERT OR IGNORE INTO economy_shop_items (item_id, name, description, price, type, role_id, max_per_user)
      VALUES ('padlock', 'Security Padlock', 'Protects your wallet from 1 robbery attempt. Breaks when triggered.', 500, 'consumable', NULL, 5)
    `).run();
  } catch (_) {}
}

/**
 * Atomic robbery calculation, padlock protection, and balance exchange.
 */
function attemptRob(db, authorId, targetId, guildId = null) {
  const tx = db.transaction((thief, victim, gid) => {
    const victimBal = getBalance(db, victim).wallet;
    if (victimBal < 50) {
      return { success: false, reason: 'Target has less than $50 in their wallet. Not worth robbing!' };
    }

    const now = Math.floor(Date.now() / 1000);
    db.prepare(`
      INSERT INTO economy_users (user_id, wallet, bank, last_rob)
      VALUES (?, 0, 0, ?)
      ON CONFLICT(user_id) DO UPDATE SET last_rob = excluded.last_rob
    `).run(String(thief), now);

    // 1. Rob-protection Padlock check
    try {
      const padlockQuery = gid
        ? db.prepare("SELECT quantity FROM economy_inventory WHERE guild_id = ? AND user_id = ? AND item_id = 'padlock' AND quantity > 0").get(gid, victim)
        : db.prepare("SELECT quantity FROM economy_inventory WHERE user_id = ? AND item_id = 'padlock' AND quantity > 0").get(victim);

      if (padlockQuery && padlockQuery.quantity > 0) {
        if (gid) {
          db.prepare("UPDATE economy_inventory SET quantity = quantity - 1 WHERE guild_id = ? AND user_id = ? AND item_id = 'padlock'").run(gid, victim);
          db.prepare("DELETE FROM economy_inventory WHERE guild_id = ? AND user_id = ? AND item_id = 'padlock' AND quantity <= 0").run(gid, victim);
        } else {
          db.prepare("UPDATE economy_inventory SET quantity = quantity - 1 WHERE user_id = ? AND item_id = 'padlock'").run(victim);
          db.prepare("DELETE FROM economy_inventory WHERE user_id = ? AND item_id = 'padlock' AND quantity <= 0").run(victim);
        }

        const penalty = Math.max(50, Math.floor(getBalance(db, thief).wallet * 0.15));
        debitWallet(db, thief, penalty);
        return {
          success: false,
          padlock: true,
          penalty,
          reason: `🔒 <@${victim}> was protected by a **Security Padlock**! The padlock broke and triggered the alarm. You paid a fine of **$${penalty.toLocaleString()}**.`
        };
      }
    } catch (_) {}

    const successChance = Math.random();
    if (successChance > 0.45) {
      // Failed robbery: thief pays a penalty
      const penalty = Math.max(25, Math.floor(getBalance(db, thief).wallet * 0.25));
      debitWallet(db, thief, penalty);
      return {
        success: false,
        caught: true,
        penalty,
        reason: `Caught by security! You paid a fine of **$${penalty.toLocaleString()}**.`
      };
    }

    // Successful robbery: steal up to 40% of victim balance, strictly capped at victim's wallet
    const maxSteal = Math.floor(victimBal * 0.40);
    const stolen = Math.max(1, Math.min(victimBal, Math.floor(Math.random() * maxSteal) + 10));

    const debited = debitWallet(db, victim, stolen);
    if (!debited) {
      return { success: false, reason: 'Robbery interrupted. Target funds changed.' };
    }

    creditWallet(db, thief, stolen);
    return {
      success: true,
      stolen,
      reason: `Successfully snatched **$${stolen.toLocaleString()}**!`
    };
  });

  return tx(authorId, targetId, guildId);
}

/**
 * Atomic item purchase inside a transaction.
 */
function buyItem(db, guildId, userId, itemId, quantity = 1) {
  if (quantity <= 0) return { success: false, reason: 'Quantity must be at least 1.' };
  ensureDefaultShopItems(db);

  const tx = db.transaction((gid, uid, iid, qty) => {
    const item = db.prepare('SELECT * FROM economy_shop_items WHERE item_id = ?').get(iid);
    if (!item) return { success: false, reason: `Item \`${iid}\` is not available in the shop.` };

    const totalCost = item.price * qty;
    const userBal = getBalance(db, uid).wallet;
    if (userBal < totalCost) {
      return {
        success: false,
        reason: `Insufficient wallet funds. Total cost is **$${totalCost.toLocaleString()}**, but you only have **$${userBal.toLocaleString()}**.`
      };
    }

    const curInv = db.prepare('SELECT quantity FROM economy_inventory WHERE guild_id = ? AND user_id = ? AND item_id = ?').get(gid, uid, iid);
    const curQty = curInv ? curInv.quantity : 0;
    if (item.max_per_user && (curQty + qty > item.max_per_user)) {
      return {
        success: false,
        reason: `You can only own up to **${item.max_per_user}** of **${item.name}** (you currently have ${curQty}).`
      };
    }

    const debited = debitWallet(db, uid, totalCost);
    if (!debited) {
      return { success: false, reason: 'Transaction failed: wallet funds changed.' };
    }

    const now = Math.floor(Date.now() / 1000);
    db.prepare(`
      INSERT INTO economy_inventory (guild_id, user_id, item_id, quantity, updated_at)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, user_id, item_id) DO UPDATE SET
        quantity = quantity + excluded.quantity,
        updated_at = excluded.updated_at
    `).run(gid, uid, iid, qty, now);

    return {
      success: true,
      item,
      quantity: qty,
      totalCost,
      remainingWallet: getBalance(db, uid).wallet
    };
  });

  return tx(guildId, userId, itemId, quantity);
}

function getInventory(db, guildId, userId) {
  return db.prepare(`
    SELECT i.item_id, i.quantity, i.updated_at, s.name, s.description, s.price, s.type, s.role_id
    FROM economy_inventory i
    LEFT JOIN economy_shop_items s ON i.item_id = s.item_id
    WHERE i.guild_id = ? AND i.user_id = ? AND i.quantity > 0
    ORDER BY i.updated_at DESC
  `).all(guildId, userId);
}

/**
 * Atomic slots game execution inside a single transaction.
 */
function playSlots(db, userId, bet) {
  if (bet <= 0) return { success: false, reason: 'Invalid bet amount.' };
  if (bet > MAX_BET) return { success: false, reason: `The maximum allowed bet on slots is **$${MAX_BET.toLocaleString()}**.` };

  const tx = db.transaction((uid, amt) => {
    const curBal = getBalance(db, uid).wallet;
    if (curBal < amt) {
      return {
        success: false,
        reason: `Insufficient funds. Your wallet has **$${curBal.toLocaleString()}**, but you attempted to bet **$${amt.toLocaleString()}**.`
      };
    }

    const debited = debitWallet(db, uid, amt);
    if (!debited) {
      return { success: false, reason: 'Could not process bet. Your wallet balance has changed.' };
    }

    const icons = ['🍒', '🍋', '🍇', '💎', '7️⃣'];
    const r1 = icons[Math.floor(Math.random() * icons.length)];
    const r2 = icons[Math.floor(Math.random() * icons.length)];
    const r3 = icons[Math.floor(Math.random() * icons.length)];

    let winnings = 0;
    let resultText = '';
    let mult = 0;

    if (r1 === r2 && r2 === r3) {
      mult = r1 === '7️⃣' ? 20 : (r1 === '💎' ? 10 : 5);
      winnings = amt * mult;
      creditWallet(db, uid, winnings);
      resultText = `🎉 **JACKPOT!** You matched three ${r1} and won **+$${(winnings - amt).toLocaleString()}** (${mult}x)!`;
    } else if (r1 === r2 || r2 === r3 || r1 === r3) {
      creditWallet(db, uid, amt);
      winnings = amt;
      resultText = `✨ **PUSH!** You matched two icons and got your **$${amt.toLocaleString()}** bet refunded!`;
    } else {
      winnings = 0;
      resultText = `💸 No matches. You lost **-$${amt.toLocaleString()}**. Better luck next spin!`;
    }

    const finalBal = getBalance(db, uid).wallet;
    return {
      success: true,
      r1,
      r2,
      r3,
      winnings,
      resultText,
      finalBal,
      mult
    };
  });

  return tx(userId, bet);
}

/**
 * Atomic coinflip game execution inside a single transaction.
 */
function playCoinflip(db, userId, bet, choice) {
  if (bet <= 0) return { success: false, reason: 'Invalid bet amount.' };
  if (bet > MAX_BET) return { success: false, reason: `The maximum allowed bet on coinflip is **$${MAX_BET.toLocaleString()}**.` };

  const tx = db.transaction((uid, amt, chosen) => {
    const curBal = getBalance(db, uid).wallet;
    if (curBal < amt) {
      return {
        success: false,
        reason: `Insufficient funds. Your wallet has **$${curBal.toLocaleString()}**, but you attempted to bet **$${amt.toLocaleString()}**.`
      };
    }

    const debited = debitWallet(db, uid, amt);
    if (!debited) {
      return { success: false, reason: 'Could not process bet. Your wallet funds have changed.' };
    }

    const isHeads = Math.random() < 0.5;
    const outcome = isHeads ? 'heads' : 'tails';
    const outcomeDisplay = isHeads ? 'Heads' : 'Tails';
    const won = outcome === chosen;

    if (won) {
      creditWallet(db, uid, amt * 2);
    }

    const finalBal = getBalance(db, uid).wallet;
    return {
      success: true,
      outcome,
      outcomeDisplay,
      won,
      finalBal
    };
  });

  return tx(userId, bet, choice);
}

module.exports = {
  MAX_BET,
  getBalance,
  debitWallet,
  creditWallet,
  debitBank,
  creditBank,
  transfer,
  deposit,
  withdraw,
  attemptRob,
  buyItem,
  getInventory,
  ensureDefaultShopItems,
  playSlots,
  playCoinflip
};
