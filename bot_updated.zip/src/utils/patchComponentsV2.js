/**
 * Tungsten Universal Discord Components V2 Engine & Global Hook (Node.js)
 * Automatically converts all prefix command replies and channel sends
 * into Discord Components V2 Type 17 Containers with interactive action rows and buttons
 * placed DIRECTLY INSIDE the container card.
 *
 * CRITICAL RELIABILITY INVARIANTS:
 * 1. Never mutate caller's options in place.
 * 2. Never inject MessageFlags.IsComponentsV2 on Ephemeral messages or plain-text interaction updates.
 * 3. Never intercept Interaction.prototype.update (interaction updates must preserve exact UI states).
 * 4. In MessagePayload.prototype.resolveBody, unconditionally delete this.body.content when IsComponentsV2
 *    is set (Discord API 50035: "The content field cannot be used when using MessageFlags.IS_COMPONENTS_V2").
 */
const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  Message,
  MessagePayload,
  BaseGuildTextChannel,
  BaseGuildVoiceChannel,
  ThreadChannel,
  DMChannel,
  User,
  GuildMember,
  CommandInteraction,
  MessageComponentInteraction,
  ModalSubmitInteraction,
  ButtonInteraction,
  StringSelectMenuInteraction,
  UserSelectMenuInteraction,
  RoleSelectMenuInteraction,
  ChannelSelectMenuInteraction,
  MentionableSelectMenuInteraction,
  BaseInteraction
} = require('discord.js');
const { isComponentsV2Enabled } = require('./componentsV2');
const config = require('../config');

/**
 * Checks whether a component instance or data object is a Discord Select Menu (Types 3, 5, 6, 7, 8).
 */
function isSelectMenuComponent(comp) {
  if (!comp) return false;
  const type = comp.type ?? comp.data?.type;
  if ([3, 5, 6, 7, 8].includes(type)) return true;
  if (typeof type === 'string' && (type.toUpperCase().includes('SELECT') || type === 'STRING_SELECT' || type === 'USER_SELECT' || type === 'ROLE_SELECT' || type === 'MENTIONABLE_SELECT' || type === 'CHANNEL_SELECT')) return true;
  const cName = comp.constructor?.name || '';
  if (cName.includes('SelectMenu') || cName.includes('Select')) return true;
  return false;
}

/**
 * Checks whether an ActionRow contains any Select Menus (Types 3, 5, 6, 7, 8)
 * or is itself a Select Menu component passed as a top-level component.
 */
function isSelectMenuRow(row) {
  if (!row) return false;
  if (isSelectMenuComponent(row)) return true;
  const comps = row.components || row.data?.components || [];
  return comps.some(c => isSelectMenuComponent(c));
}

/**
 * Transforms a Discord Embed (or EmbedBuilder) and components into a native
 * Discord Components V2 Type 17 Container.
 * All action rows and buttons are embedded directly INSIDE the container card.
 */
function embedToContainer(embed, components = [], content = null, guildId = null) {
  const container = new ContainerBuilder();
  const raw = embed instanceof EmbedBuilder ? embed.toJSON() : (embed || {});

  // Determine ui_style
  let uiStyle = 'expressive';
  try {
    const { getSetting } = require('../settings/registry');
    if (guildId) {
      uiStyle = getSetting(guildId, 'general.ui_style') || 'expressive';
    }
  } catch (e) {}

  // Container accent colors are eliminated across the UI so cards are strictly colorless
  if (container.data) delete container.data.accent_color;
  delete container.accent_color;

  const isHelpPayload = Boolean(
    (raw.title && String(raw.title).includes("Hey , I'm Tungsten™")) ||
    (raw.description && String(raw.description).includes("Hey , I'm Tungsten™")) ||
    (content && String(content).includes("Hey , I'm Tungsten™")) ||
    (raw.title && String(raw.title).toLowerCase().includes('tungsten command center')) ||
    (raw.description && String(raw.description).toLowerCase().includes('tungsten command center'))
  );

  const stripRawCustomEmojis = (str) => {
    return str; // Preserve 100% bespoke custom animated emojis everywhere
  };

  // 1. Build Consolidated Text (Header + Fields + Footer)
  const textSections = [];

  if (content && String(content).trim()) {
    let contentText = String(content).trim();
    if (contentText) {
      textSections.push(contentText);
    }
  }

  if (raw.author && raw.author.name && String(raw.author.name).trim()) {
    let authorName = String(raw.author.name).trim();
    if (authorName) {
      if (raw.author.url) {
        textSections.push(`[**${authorName}**](${raw.author.url})`);
      } else {
        textSections.push(`**${authorName}**`);
      }
    }
  }

  if (raw.title && String(raw.title).trim()) {
    let titleText = String(raw.title).trim();
    if (titleText) {
      if (raw.url) {
        textSections.push(`## [${titleText}](${raw.url})`);
      } else {
        textSections.push(`## ${titleText}`);
      }
    }
  }

  if (raw.description && String(raw.description).trim()) {
    let cleanDesc = String(raw.description)
      .replace(/(?:\r?\n\r?\n|\r?\n|^)\*\*Components V2 •[^\n]*\r?\n```(?:ansi)?[\s\S]*?```(?:\r?\n-# [^\n]*)?/g, '')
      .replace(/(?:\r?\n\r?\n|\r?\n|^)\*\*Components V2 •[^\n]*\*\*(?:\r?\n```(?:ansi)?[\s\S]*?```)?(?:\r?\n-# [^\n]*)?/g, '')
      .replace(/\n\n\*\*Components V2 •[^\n]+\n```ansi[\s\S]*?```\n-# All interactive buttons are integrated directly into this card\./g, '')
      .replace(/\n\n\*\*Components V2 •[^\n]+\n```ansi[\s\S]*?```/g, '')
      .trim();

    if (cleanDesc) {
      textSections.push(cleanDesc);
    }
  }

  // 2. Append Fields into text
  if (raw.fields && raw.fields.length > 0) {
    const validFields = raw.fields.filter(f => f && f.name && f.value && String(f.name).trim() && String(f.value).trim());
    if (validFields.length > 0) {
      const formattedFields = [];
      for (const f of validFields) {
        let name = String(f.name).trim();
        let value = String(f.value).trim();
        const isCompact = Boolean(f.inline || (!value.includes('\n') && value.length < 80));
        if (isCompact) {
          formattedFields.push(`**${name}:** ${value}`);
        } else {
          formattedFields.push(`### ${name}\n${value}`);
        }
      }
      const fieldsText = formattedFields.join('\n\n').trim();
      if (fieldsText) {
        textSections.push(fieldsText);
      }
    }
  }

  // 3. Append Footer & Timestamp into text
  const footerParts = [];
  if (raw.footer && raw.footer.text) {
    let footerText = String(raw.footer.text).trim();
    if (footerText) {
      footerParts.push(footerText);
    }
  }
  if (raw.timestamp) {
    const ts = Math.floor(new Date(raw.timestamp).getTime() / 1000);
    footerParts.push(`<t:${ts}:R>`);
  }
  if (footerParts.length > 0) {
    textSections.push(`-# ${footerParts.join(' • ')}`);
  }

  const fullText = textSections.join('\n\n').trim();

  // If thumbnail exists, wrap text in a Section with a Thumbnail accessory
  if (raw.thumbnail && raw.thumbnail.url && typeof raw.thumbnail.url === 'string' && raw.thumbnail.url.startsWith('http') && fullText) {
    try {
      const section = new SectionBuilder();
      section.addTextDisplayComponents(new TextDisplayBuilder().setContent(fullText.slice(0, 2000)));
      section.setThumbnailAccessory(new ThumbnailBuilder().setURL(raw.thumbnail.url));
      container.addSectionComponents(section);
    } catch (e) {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(fullText.slice(0, 2000)));
    }
  } else if (fullText) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(fullText.slice(0, 2000)));
  }

  // If text exceeded 2,000 characters, append remainder as a secondary text display
  if (fullText.length > 2000) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(fullText.slice(2000, 4000)));
  }

  // 4. Image Attachment (via Discord Components V2 MediaGallery)
  if (raw.image && raw.image.url && typeof raw.image.url === 'string' && raw.image.url.startsWith('http')) {
    try {
      const gallery = new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(raw.image.url)
      );
      container.addMediaGalleryComponents(gallery);
    } catch (e) {}
  }

  // 5. ActionRows (Buttons only) placed DIRECTLY INSIDE the Container card
  // Select Menus violate Discord API restrictions if placed inside a Container and are excluded here
  if (components && components.length > 0) {
    const validRows = components.filter(r => !isSelectMenuRow(r)).slice(0, 5);
    if (validRows.length > 0) {
      container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
      for (const row of validRows) {
        container.addActionRowComponents(row);
      }
    }
  }

  return container;
}

function countComponents(options) {
  if (!options || !options.components || !Array.isArray(options.components)) return 0;
  let count = 0;
  function traverse(item) {
    if (!item) return;
    count++;
    const raw = typeof item.toJSON === 'function' ? item.toJSON() : item;
    if (Array.isArray(raw.components)) {
      raw.components.forEach(traverse);
    }
    if (raw.accessory) {
      count++;
    }
  }
  options.components.forEach(traverse);
  return count;
}

function containerToEmbedFallback(options) {
  if (!options || !options.components || !Array.isArray(options.components)) return options;
  const container = options.components.find(c => c && (c instanceof ContainerBuilder || c.type === 17 || c.data?.type === 17));
  if (!container) return options;

  const rawContainer = typeof container.toJSON === 'function' ? container.toJSON() : container;
  const rawComps = rawContainer.components || [];

  const textLines = [];
  const extractedButtons = [];
  const actionRows = [];

  for (const comp of rawComps) {
    if (!comp) continue;
    const type = comp.type ?? comp.data?.type;
    // Type 10: TextDisplay
    if (type === 10) {
      const text = comp.content || comp.data?.content;
      if (text) textLines.push(text);
    }
    // Type 9: Section
    else if (type === 9) {
      const innerComps = comp.components || comp.data?.components || [];
      for (const inner of innerComps) {
        if (inner.content) textLines.push(inner.content);
      }
      const acc = comp.accessory || comp.data?.accessory;
      if (acc) {
        extractedButtons.push(acc instanceof ButtonBuilder ? acc : new ButtonBuilder(acc));
      }
    }
    // Type 1: ActionRow
    else if (type === 1) {
      actionRows.push(comp instanceof ActionRowBuilder ? comp : new ActionRowBuilder(comp));
    }
  }

  // Also include any top-level action rows outside the container
  for (const c of options.components) {
    if (c !== container && (c instanceof ActionRowBuilder || c.type === 1 || c.data?.type === 1)) {
      actionRows.push(c instanceof ActionRowBuilder ? c : new ActionRowBuilder(c));
    }
  }

  // Pack extracted buttons into ActionRows of max 5 buttons if room permits (< 5 total rows)
  if (extractedButtons.length > 0 && actionRows.length < 5) {
    for (let i = 0; i < extractedButtons.length && actionRows.length < 5; i += 5) {
      const slice = extractedButtons.slice(i, i + 5);
      actionRows.push(new ActionRowBuilder().addComponents(slice));
    }
  }

  const embed = new EmbedBuilder();
  const fullDesc = textLines.join('\n\n').trim();
  if (fullDesc) {
    embed.setDescription(fullDesc.slice(0, 4096));
  } else {
    embed.setDescription('Tungsten Security Panel');
  }

  // Deduplicate custom_ids across actionRows to prevent COMPONENT_CUSTOM_ID_DUPLICATED
  const seenIds = new Set();
  const cleanRows = [];
  for (const row of actionRows.slice(0, 5)) {
    const rowComps = row.components || row.data?.components || [];
    const uniqueComps = [];
    for (const comp of rowComps) {
      const id = comp.customId || comp.data?.custom_id;
      if (id) {
        if (seenIds.has(id)) continue;
        seenIds.add(id);
      }
      uniqueComps.push(comp);
    }
    if (uniqueComps.length > 0) {
      cleanRows.push(new ActionRowBuilder().addComponents(uniqueComps));
    }
  }

  const fallback = {
    ...options,
    embeds: [embed],
    components: cleanRows
  };
  delete fallback.flags;
  delete fallback.useComponentsV2;
  return fallback;
}

/**
 * Traverses a component tree and ensures all custom_ids are strictly unique.
 * Appends a randomized unique suffix to any duplicate custom_ids to prevent COMPONENT_CUSTOM_ID_DUPLICATED.
 */
function sanitizeDuplicateCustomIds(options) {
  if (!options || !options.components || !Array.isArray(options.components)) return options;
  const seenIds = new Set();

  function visit(comp) {
    if (!comp) return;
    const cid = comp.customId || comp.data?.custom_id || (comp.toJSON && comp.toJSON().custom_id);
    if (cid) {
      if (seenIds.has(cid)) {
        const uniqueId = `${cid}_d${Math.floor(Math.random() * 9000 + 1000)}`;
        if (typeof comp.setCustomId === 'function') {
          comp.setCustomId(uniqueId);
        } else if (comp.data) {
          comp.data.custom_id = uniqueId;
        } else {
          comp.custom_id = uniqueId;
        }
      } else {
        seenIds.add(cid);
      }
    }
    const inner = comp.components || comp.data?.components;
    if (Array.isArray(inner)) {
      inner.forEach(visit);
    }
    if (comp.accessory) visit(comp.accessory);
    if (comp.data?.accessory) visit(comp.data.accessory);
  }

  options.components.forEach(visit);
  return options;
}

/**
 * Transforms an outgoing send/reply/edit options object into a Discord Components V2 payload.
 * Pure function: never mutates inputOptions.
 */
function transformToV2Payload(inputOptions, guildId = null, isTargetV2 = false) {
  if (!inputOptions) {
    return inputOptions;
  }

  // If already a MessagePayload instance, avoid corrupting
  if (inputOptions instanceof MessagePayload) {
    return inputOptions;
  }

  // Always clone options to prevent mutating caller's state
  let options = typeof inputOptions === 'string'
    ? { content: inputOptions }
    : { ...inputOptions };

  // Detect ephemeral messages
  const isEphemeral = Boolean(
    options.ephemeral === true ||
    (options.flags && (options.flags & MessageFlags.Ephemeral) !== 0)
  );

  // Check if Components V2 is enabled for this guild (defaults to true)
  if (guildId && !isComponentsV2Enabled(guildId)) {
    return inputOptions;
  }

  const existingComponents = options.components ? [...options.components] : [];

  // Containers (Type 17) and IsComponentsV2 flags MUST NEVER be used on Ephemeral messages
  if (!isEphemeral) {
    // 3. If already contains a Container (Type 17), ensure no legacy content/embeds are sent
    const hasContainer = existingComponents.some(c => {
      if (!c) return false;
      if (c instanceof ContainerBuilder) return true;
      if (c.type === 17 || c.data?.type === 17) return true;
      return false;
    });

    if (hasContainer) {
      const newOptions = {
        ...options,
        flags: (options.flags || 0) | MessageFlags.IsComponentsV2
      };
      delete newOptions.content;
      delete newOptions.embeds;
      delete newOptions.embed;
      if (countComponents(newOptions) > 40) {
        return containerToEmbedFallback(newOptions);
      }
      return sanitizeDuplicateCustomIds(newOptions);
    }
  }

  const hasFiles = (options.files && options.files.length > 0);
  const embeds = options.embeds ? [...options.embeds] : (options.embed ? [options.embed] : []);

  // 4b. If target IS a Components V2 message, and only content is being sent (e.g. dismissal message),
  // wrap it in a Container so Discord API doesn't reject content with IS_COMPONENTS_V2.
  if (!isEphemeral && isTargetV2 && embeds.length === 0 && options.content) {
    const container = new ContainerBuilder();
    if (container.data) delete container.data.accent_color;
    delete container.accent_color;
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(String(options.content).slice(0, 2000)));
    if (String(options.content).length > 2000) {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(String(options.content).slice(2000, 4000)));
    }
    const newOptions = {
      ...options,
      components: [container, ...existingComponents].slice(0, 5),
      flags: (options.flags || 0) | MessageFlags.IsComponentsV2
    };
    delete newOptions.content;
    delete newOptions.embeds;
    delete newOptions.embed;
    return newOptions;
  }

  // 5. Transform Embeds into Components V2 Type 17 Container
  // (Never for ephemeral messages or messages with file attachments to preserve 100% Discord API stability)
  if (!isEphemeral && !hasFiles && embeds.length > 0 && options.useComponentsV2 !== false) {
    const buttonRows = [];
    const selectRows = [];

    for (const row of existingComponents) {
      if (!row) continue;
      if (isSelectMenuRow(row)) {
        const isActionRow = row instanceof ActionRowBuilder ||
          row.type === 1 ||
          row.data?.type === 1 ||
          (Array.isArray(row.components) && row.components.length > 0 && !isSelectMenuComponent(row));
        if (isActionRow) {
          selectRows.push(row);
        } else {
          selectRows.push(new ActionRowBuilder().addComponents(row));
        }
      } else {
        buttonRows.push(row);
      }
    }

    const containers = [];
    for (let i = 0; i < embeds.length; i++) {
      const isLast = (i === embeds.length - 1);
      const isFirst = (i === 0);
      const leadContent = isFirst ? options.content : null;
      // Button action rows are housed directly inside the container card
      const compsForContainer = isLast ? buttonRows.slice(0, 5) : [];

      const container = embedToContainer(embeds[i], compsForContainer, leadContent, guildId);
      containers.push(container);
    }

    // Select Menu ActionRows MUST be placed as top-level components alongside the container
    const allComponents = [...containers, ...selectRows].slice(0, 5);

    const newOptions = {
      ...options,
      components: allComponents,
      flags: (options.flags || 0) | MessageFlags.IsComponentsV2
    };
    delete newOptions.content;
    delete newOptions.embeds;
    delete newOptions.embed;

    if (countComponents(newOptions) > 40) {
      return containerToEmbedFallback(newOptions);
    }
    return sanitizeDuplicateCustomIds(newOptions);
  }

  // 6. Clean stale or broken button panels from embeds and preserve native Discord ActionRows
  const { stripButtonPanel } = require('./componentsV2');

  const extractedButtons = [];
  for (const row of existingComponents) {
    if (!row) continue;
    const comps = row.components || row.data?.components || [];
    for (const c of comps) {
      const type = c.type ?? c.data?.type;
      if (type === 2 || type === 'BUTTON' || (c.constructor && c.constructor.name && c.constructor.name.includes('Button'))) {
        extractedButtons.push(c);
      }
    }
  }

  if (embeds.length > 0) {
    let modified = false;
    const updatedEmbeds = embeds.map(em => {
      const isBuilder = em instanceof EmbedBuilder;
      const raw = isBuilder ? em.toJSON() : (em || {});
      const desc = String(raw.description || '');
      if (desc.includes('Components V2 •') || desc.includes('```ansi')) {
        modified = true;
        const cleaned = stripButtonPanel(desc);
        if (isBuilder) {
          const clone = EmbedBuilder.from(em);
          clone.setDescription(cleaned || null);
          return clone;
        } else {
          return { ...raw, description: cleaned || null };
        }
      }
      return em;
    });

    if (modified) {
      const newOptions = {
        ...options,
        embeds: updatedEmbeds
      };
      delete newOptions.embed;
      return newOptions;
    }
  }

  // Case C: Plain text message with interactive buttons -> wrap text and buttons in a sleek Components V2 Container
  if (embeds.length === 0 && extractedButtons.length > 0 && options.content && !hasFiles) {
    if (!isEphemeral && options.useComponentsV2 !== false) {
      const container = new ContainerBuilder();
      if (container.data) delete container.data.accent_color;
      delete container.accent_color;
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(String(options.content).slice(0, 2000)));
      if (String(options.content).length > 2000) {
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(String(options.content).slice(2000, 4000)));
      }
      container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
      for (const row of existingComponents.slice(0, 5)) {
        container.addActionRowComponents(row);
      }
      const newOptions = {
        ...options,
        components: [container],
        flags: (options.flags || 0) | MessageFlags.IsComponentsV2
      };
      delete newOptions.content;
      delete newOptions.embeds;
      delete newOptions.embed;
      return newOptions;
    }

    const card = new EmbedBuilder()
      .setDescription(String(options.content));

    const newOptions = {
      ...options,
      embeds: [card]
    };
    delete newOptions.content;
    delete newOptions.embed;
    return newOptions;
  }

  return inputOptions;
}

/**
 * Helper to strip broken component emojis if Discord API returns COMPONENT_INVALID_EMOJI.
 */
function stripInvalidComponentEmojis(options) {
  if (!options || typeof options !== 'object') return options;
  const clone = { ...options };
  if (!clone.components || !Array.isArray(clone.components)) return clone;

  function stripComponent(comp) {
    if (!comp || typeof comp !== 'object') return comp;
    const c = typeof comp.toJSON === 'function' ? comp.toJSON() : { ...comp };
    delete c.emoji;
    if (c.data && typeof c.data === 'object') {
      delete c.data.emoji;
    }
    if (comp.data && typeof comp.data === 'object') {
      delete comp.data.emoji;
    }
    if (typeof comp.emoji !== 'undefined') {
      delete comp.emoji;
    }

    if (c.options && Array.isArray(c.options)) {
      c.options = c.options.map(opt => {
        if (!opt || typeof opt !== 'object') return opt;
        const o = typeof opt.toJSON === 'function' ? opt.toJSON() : { ...opt };
        delete o.emoji;
        if (o.data && typeof o.data === 'object') delete o.data.emoji;
        if (opt.data && typeof opt.data === 'object') delete opt.data.emoji;
        if (typeof opt.emoji !== 'undefined') delete opt.emoji;
        return o;
      });
    }

    if (c.components && Array.isArray(c.components)) {
      c.components = c.components.map(stripComponent);
    }
    if (c.data?.components && Array.isArray(c.data.components)) {
      c.data.components = c.data.components.map(stripComponent);
    }
    if (c.accessory && typeof c.accessory === 'object') {
      c.accessory = stripComponent(c.accessory);
    }
    if (c.data?.accessory && typeof c.data.accessory === 'object') {
      c.data.accessory = stripComponent(c.data.accessory);
    }
    if (comp.accessory && typeof comp.accessory === 'object') {
      delete comp.accessory.emoji;
      if (comp.accessory.data) delete comp.accessory.data.emoji;
    }
    return c;
  }

  clone.components = clone.components.map(stripComponent);
  return clone;
}

/**
 * Strips interactive ActionRows from Containers and drops standalone action rows
 * to yield a minimal, clean Type 17 Container payload that satisfies Discord API constraints.
 */
function stripComponentsFromV2(v2Payload) {
  if (!v2Payload || typeof v2Payload !== 'object') return v2Payload;
  const clone = { ...v2Payload };
  if (!clone.components || !Array.isArray(clone.components)) return clone;

  clone.components = clone.components.map(comp => {
    if (!comp || typeof comp !== 'object') return comp;
    const raw = typeof comp.toJSON === 'function' ? comp.toJSON() : { ...comp };
    const type = raw.type ?? raw.data?.type;
    if (type === 17) {
      const subComps = raw.components || raw.data?.components || [];
      const safeSubComps = subComps.filter(sc => {
        const t = sc?.type ?? sc?.data?.type;
        return t === 10 || t === 9 || t === 14;
      });
      if (raw.data) {
        return { ...raw, data: { ...raw.data, components: safeSubComps } };
      }
      return { ...raw, components: safeSubComps };
    }
    return comp;
  }).filter(c => {
    const t = c?.type ?? c?.data?.type;
    return t === 17;
  });

  return clone;
}

/**
 * Safe invocation wrapper that falls back cleanly to the original payload
 * if Discord REST API returns any 400 or 50035 error.
 */
async function safeExecuteWithFallback(origFn, context, origOptions, guildId, isTargetV2 = false) {
  let sanitizedOptions = origOptions;
  try {
    const { sanitizeUiPayload } = require('./uiSanitizer');
    sanitizedOptions = sanitizeUiPayload(context || guildId, origOptions);
  } catch (err) {}

  let effectiveOptions = sanitizedOptions;
  if (context?.ephemeral === true && typeof effectiveOptions === 'object' && effectiveOptions !== null && !effectiveOptions.ephemeral) {
    effectiveOptions = { ...effectiveOptions, ephemeral: true };
  }

  let v2Options;
  try {
    v2Options = transformToV2Payload(effectiveOptions, guildId, isTargetV2);
  } catch (err) {
    v2Options = effectiveOptions;
  }

  // If no change was made, execute directly
  if (v2Options === sanitizedOptions) {
    try {
      return await origFn.call(context, sanitizedOptions);
    } catch (apiError) {
      const code = apiError?.code || apiError?.rawError?.code;
      if (code === 10062 || code === 40060) {
        return null;
      }
      if (code === 50035 || code === 50006 || apiError?.status === 400) {
        const cleanOptions = containerToEmbedFallback(sanitizedOptions) || stripInvalidComponentEmojis(sanitizedOptions);
        return await origFn.call(context, cleanOptions);
      }
      throw apiError;
    }
  }

  try {
    return await origFn.call(context, v2Options);
  } catch (apiError) {
    const code = apiError?.code || apiError?.rawError?.code;
    const status = apiError?.status;
    if (code === 10062 || code === 40060) {
      return null;
    }
    if (code === 50035 || code === 50006 || status === 400) {
      console.warn(`[ComponentsV2 Fallback] Reverting payload due to Discord API (${code || status}): ${apiError.message}`);

      try {
        if (code === 50035 && String(apiError.message || '').includes('COMPONENT_INVALID_EMOJI')) {
          const cleanV2 = stripInvalidComponentEmojis(v2Options);
          try {
            return await origFn.call(context, cleanV2);
          } catch (retryErr) {}
        }
        if (code === 50035 && String(apiError.message || '').includes('COMPONENT_CUSTOM_ID_DUPLICATED')) {
          const cleanDups = sanitizeDuplicateCustomIds(v2Options);
          try {
            return await origFn.call(context, cleanDups);
          } catch (retryErr) {}
        }
        const fallbackPayload = containerToEmbedFallback(v2Options) || containerToEmbedFallback(sanitizedOptions) || stripInvalidComponentEmojis(sanitizedOptions);
        return await origFn.call(context, fallbackPayload);
      } catch (fallbackError) {
        const fallbackCode = fallbackError?.code || fallbackError?.rawError?.code;
        if (fallbackCode === 10062 || fallbackCode === 40060) {
          return null;
        }
        throw fallbackError;
      }
    }
    throw apiError;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Install Prototype Hooks Across Discord.js Message and Channel Classes
// ─────────────────────────────────────────────────────────────────────────────

let _HOOKS_APPLIED = false;

function applyComponentsV2Hooks() {
  if (_HOOKS_APPLIED) return;
  _HOOKS_APPLIED = true;

  // 0. Patch MessagePayload.prototype.resolveBody to strip content and embeds
  // when MessageFlags.IsComponentsV2 (32768) or Container (Type 17) is present.
  // This completely eliminates Discord Error 50035 (The 'content' field cannot be used with IS_COMPONENTS_V2).
  if (MessagePayload?.prototype?.resolveBody) {
    const origResolveBody = MessagePayload.prototype.resolveBody;
    MessagePayload.prototype.resolveBody = function () {
      const res = origResolveBody.apply(this, arguments);
      if (this.body) {
        const isWebhook = Boolean(this.isWebhook || this.target?.constructor?.name === 'InteractionWebhook');
        const flags = this.body.flags || 0;
        const comps = this.body.components || [];
        const hasV2 = (flags & MessageFlags.IsComponentsV2) !== 0 ||
          comps.some(c => c && (c.type === 17 || c.data?.type === 17));
        if (hasV2) {
          if ((flags & MessageFlags.Ephemeral) === 0) {
            this.body.flags = (this.body.flags || 0) | MessageFlags.IsComponentsV2;
          }
          delete this.body.content;
          delete this.body.embeds;
        }
      }
      return res;
    };
  }

  // 1. Message.prototype.reply (Prefix commands sent to channels)
  if (Message?.prototype?.reply && !Message.prototype.reply.__v2Hooked) {
    const origReply = Message.prototype.reply;
    const wrapped = function (options) {
      const guildId = this.guildId || this.guild?.id || null;
      let opt = options;
      if (typeof opt === 'object' && opt !== null && opt.failIfNotExists === undefined) {
        opt = { ...opt, failIfNotExists: false };
      }
      return safeExecuteWithFallback(origReply, this, opt, guildId, false).catch(err => {
        const code = err?.code || err?.rawError?.code;
        const msg = String(err?.message || '');
        if (code === 50035 && (msg.includes('MESSAGE_REFERENCE_UNKNOWN_MESSAGE') || msg.includes('message_reference'))) {
          if (this.channel && typeof this.channel.send === 'function') {
            return this.channel.send(opt);
          }
        }
        throw err;
      });
    };
    wrapped.__v2Hooked = true;
    Message.prototype.reply = wrapped;
  }

  // 2. Message.prototype.edit
  if (Message?.prototype?.edit && !Message.prototype.edit.__v2Hooked) {
    const origEdit = Message.prototype.edit;
    const wrapped = function (options) {
      const guildId = this.guildId || this.guild?.id || null;
      const flagBits = typeof this.flags?.bitfield === 'number'
        ? this.flags.bitfield
        : (typeof this.flags === 'number' ? this.flags : 0);
      const isTargetV2 = Boolean(
        (flagBits & MessageFlags.IsComponentsV2) !== 0 ||
        (this.components && this.components.some(c => c && (c.type === 17 || c.data?.type === 17)))
      );
      return safeExecuteWithFallback(origEdit, this, options, guildId, isTargetV2);
    };
    wrapped.__v2Hooked = true;
    Message.prototype.edit = wrapped;
  }

  // 3. Channel Send Methods & User DMs (Text, Voice, Thread, DM, User, GuildMember)
  const sendClasses = [
    BaseGuildTextChannel,
    BaseGuildVoiceChannel,
    ThreadChannel,
    DMChannel,
    User,
    GuildMember
  ].filter(Boolean);

  for (const cls of sendClasses) {
    if (cls?.prototype?.send && !cls.prototype.send.__v2Hooked) {
      const origSend = cls.prototype.send;
      const wrapped = function (options) {
        const guildId = this.guildId || this.guild?.id || null;
        return safeExecuteWithFallback(origSend, this, options, guildId, false);
      };
      wrapped.__v2Hooked = true;
      cls.prototype.send = wrapped;
    }
  }

  // Ensure sub-interaction classes do not hold conflicting own properties that shadow MessageComponentInteraction
  for (const SubClass of [ButtonInteraction, StringSelectMenuInteraction].filter(Boolean)) {
    if (Object.prototype.hasOwnProperty.call(SubClass.prototype, 'update')) {
      delete SubClass.prototype.update;
    }
    if (Object.prototype.hasOwnProperty.call(SubClass.prototype, 'editReply')) {
      delete SubClass.prototype.editReply;
    }
    if (Object.prototype.hasOwnProperty.call(SubClass.prototype, 'reply')) {
      delete SubClass.prototype.reply;
    }
    if (Object.prototype.hasOwnProperty.call(SubClass.prototype, 'followUp')) {
      delete SubClass.prototype.followUp;
    }
  }

  // 4. Interaction classes covering reply, editReply, followUp, and update
  const interactionClasses = [
    CommandInteraction,
    MessageComponentInteraction,
    ModalSubmitInteraction
  ].filter(Boolean);

  for (const cls of interactionClasses) {
    // reply
    if (cls?.prototype?.reply && !cls.prototype.reply.__v2Hooked) {
      const origReply = cls.prototype.reply;
      const wrapped = function (options) {
        const guildId = this.guildId || this.guild?.id || null;
        return safeExecuteWithFallback(origReply, this, options, guildId, false);
      };
      wrapped.__v2Hooked = true;
      cls.prototype.reply = wrapped;
    }

    // editReply
    if (cls?.prototype?.editReply && !cls.prototype.editReply.__v2Hooked) {
      const origEditReply = cls.prototype.editReply;
      const wrapped = function (options) {
        const guildId = this.guildId || this.guild?.id || null;
        const flagBits = typeof this.message?.flags?.bitfield === 'number'
          ? this.message.flags.bitfield
          : (typeof this.message?.flags === 'number' ? this.message.flags : 0);
        const isTargetV2 = Boolean(
          (flagBits & MessageFlags.IsComponentsV2) !== 0 ||
          (this.message?.components && this.message.components.some(c => c && (c.type === 17 || c.data?.type === 17)))
        );
        return safeExecuteWithFallback(origEditReply, this, options, guildId, isTargetV2);
      };
      wrapped.__v2Hooked = true;
      cls.prototype.editReply = wrapped;
    }

    // followUp
    if (cls?.prototype?.followUp && !cls.prototype.followUp.__v2Hooked) {
      const origFollowUp = cls.prototype.followUp;
      const wrapped = function (options) {
        const guildId = this.guildId || this.guild?.id || null;
        return safeExecuteWithFallback(origFollowUp, this, options, guildId, false);
      };
      wrapped.__v2Hooked = true;
      cls.prototype.followUp = wrapped;
    }

    // update (MessageComponentInteraction & ModalSubmitInteraction)
    if (cls?.prototype?.update && !cls.prototype.update.__v2Hooked) {
      const origUpdate = cls.prototype.update;
      const wrapped = function (options) {
        if (this.deferred || this.replied) {
          return this.editReply(options);
        }
        const guildId = this.guildId || this.guild?.id || null;
        const flagBits = typeof this.message?.flags?.bitfield === 'number'
          ? this.message.flags.bitfield
          : (typeof this.message?.flags === 'number' ? this.message.flags : 0);
        const isTargetV2 = Boolean(
          (flagBits & MessageFlags.IsComponentsV2) !== 0 ||
          (this.message?.components && this.message.components.some(c => c && (c.type === 17 || c.data?.type === 17)))
        );
        return safeExecuteWithFallback(origUpdate, this, options, guildId, isTargetV2);
      };
      wrapped.__v2Hooked = true;
      cls.prototype.update = wrapped;
    }
  }

  console.log('[ComponentsV2] Master Universal Container Dispatcher active.');
}

module.exports = {
  embedToContainer,
  transformToV2Payload,
  applyComponentsV2Hooks,
  safeExecuteWithFallback,
  stripInvalidComponentEmojis,
  stripComponentsFromV2,
  isSelectMenuComponent,
  isSelectMenuRow,
  containerToEmbedFallback,
  countComponents
};
