/**
 * Tungsten Automated Warning Escalation Ladder (Node.js)
 * Executes dynamic, cumulative moderation actions (timeout, kick, ban)
 * when members reach designated warning thresholds.
 */
const { getServerDb } = require('./serverDb');
const { isModuleEnabled } = require('./modulesHelper');
const { createCase } = require('./modlog');

function parseLadderDuration(str) {
  if (!str) return 0;
  if (typeof str === 'number') return Math.max(0, Math.floor(str));
  const s = String(str).trim().toLowerCase();
  const match = s.match(/^(\d+)\s*([smhdwy])?$/);
  if (!match) return 0;

  const value = parseInt(match[1], 10);
  const unit = match[2] || 's';

  switch (unit) {
    case 's': return value;
    case 'm': return value * 60;
    case 'h': return value * 3600;
    case 'd': return value * 86400;
    case 'w': return value * 604800;
    case 'y': return value * 31536000;
    default: return value;
  }
}

function formatDuration(seconds) {
  if (!seconds || seconds <= 0) return 'Permanent / Instant';
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;

  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  if (m > 0) parts.push(`${m}m`);
  if (s > 0 && parts.length === 0) parts.push(`${s}s`);
  return parts.join(' ') || `${seconds}s`;
}

function getLadderRules(guildId) {
  if (!guildId) return [];
  const sdb = getServerDb(guildId);
  return sdb.prepare('SELECT * FROM warn_ladder WHERE guild_id = ? ORDER BY warn_count ASC').all(String(guildId));
}

function setLadderRule(guildId, warnCount, action, durationSeconds = 0) {
  if (!guildId || !warnCount || !action) return false;
  const sdb = getServerDb(guildId);
  const dur = typeof durationSeconds === 'string' ? parseLadderDuration(durationSeconds) : Number(durationSeconds || 0);
  sdb.prepare(`
    INSERT INTO warn_ladder (guild_id, warn_count, action, duration)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(guild_id, warn_count) DO UPDATE SET
      action = excluded.action,
      duration = excluded.duration
  `).run(String(guildId), Number(warnCount), String(action).toLowerCase().trim(), dur);
  return true;
}

function removeLadderRule(guildId, warnCount) {
  if (!guildId) return false;
  const sdb = getServerDb(guildId);
  const res = sdb.prepare('DELETE FROM warn_ladder WHERE guild_id = ? AND warn_count = ?').run(String(guildId), Number(warnCount));
  return res.changes > 0;
}

function resetLadder(guildId) {
  if (!guildId) return false;
  const sdb = getServerDb(guildId);
  sdb.prepare('DELETE FROM warn_ladder WHERE guild_id = ?').run(String(guildId));
  return true;
}

async function checkAndExecuteLadder(guild, member, totalWarns, client, moderator = null) {
  if (!guild || !member || !isModuleEnabled(guild.id, 'warnladder')) {
    return null;
  }

  const sdb = getServerDb(guild.id);
  const rule = sdb.prepare('SELECT * FROM warn_ladder WHERE guild_id = ? AND warn_count = ?').get(String(guild.id), Number(totalWarns));
  if (!rule) return null;

  const action = String(rule.action).toLowerCase().trim();
  const duration = rule.duration || 0;
  const reason = `[Warn Ladder Escalation] Reached ${totalWarns} server warnings`;

  let executed = false;
  let failureReason = null;

  try {
    if (action === 'mute' || action === 'timeout') {
      const ms = Math.max(10000, duration > 0 ? duration * 1000 : 10 * 60 * 1000);
      if (typeof member.timeout === 'function') {
        try {
          await member.timeout(ms, reason);
          executed = true;
        } catch (e) {
          failureReason = e.message;
        }
      }
    } else if (action === 'kick') {
      if (typeof member.kick === 'function') {
        try {
          await member.kick(reason);
          executed = true;
        } catch (e) {
          failureReason = e.message;
        }
      }
    } else if (action === 'ban') {
      if (guild.members && typeof guild.members.ban === 'function') {
        try {
          await guild.members.ban(member.id, { reason });
          executed = true;
        } catch (e) {
          failureReason = e.message;
        }
      }
    } else if (action === 'softban') {
      if (guild.members && typeof guild.members.ban === 'function') {
        try {
          await guild.members.ban(member.id, { reason, deleteMessageSeconds: 86400 });
          if (typeof guild.members.unban === 'function') {
            await guild.members.unban(member.id, `Softban unban: ${reason}`).catch(() => null);
          }
          executed = true;
        } catch (e) {
          failureReason = e.message;
        }
      }
    }

    if (executed) {
      // Record mod_case entry with transactional isolation
      try {
        createCase(guild.id, sdb, {
          action: `ladder_${action}`,
          targetId: member.id,
          moderatorId: moderator ? String(moderator.id) : (client?.user?.id ? String(client.user.id) : '0'),
          reason,
          timestamp: Math.floor(Date.now() / 1000)
        });
      } catch (_) {}
    }

    return {
      triggered: true,
      success: executed,
      failureReason,
      action,
      duration,
      durationStr: formatDuration(duration),
      warnCount: totalWarns
    };
  } catch (err) {
    console.error(`[WarnLadder] Error executing escalation for user ${member.id}:`, err);
    return {
      triggered: true,
      success: false,
      failureReason: err.message,
      action,
      duration,
      durationStr: formatDuration(duration),
      warnCount: totalWarns
    };
  }
}

module.exports = {
  parseLadderDuration,
  formatDuration,
  getLadderRules,
  setLadderRule,
  removeLadderRule,
  resetLadder,
  checkAndExecuteLadder
};
