/**
 * Tungsten Interactive Category Selection Help UI (Node.js / Discord Components V2)
 * Brand-aligned Help System featuring 22 operational modules with bespoke animated branding,
 * Type 17 Container architecture, and interactive StringSelectMenu navigation.
 */
const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags
} = require('discord.js');
const config = require('../config');
const { sentenceCase } = require('../ui/copy');

const CATEGORIES = [
  {
    "id": "antinuke",
    "label": "Antinuke",
    "value": "antinuke",
    "description": "Get All Antinuke Commands",
    "emoji": "<a:tungsten_shield:1567242104923627574>",
    "sections": [
      {
        "title": "Antinuke",
        "commands": [
          "security",
          "antinuke",
          "an",
          "antinuke limit",
          "antinuke punishment",
          "antinuke config",
          "antinuke reset",
          "anpanel",
          "anmode",
          "antimode",
          "defmode",
          "whitelist",
          "wl",
          "whitelist add",
          "whitelist remove",
          "whitelist show",
          "whitelist reset",
          "whitelisted",
          "wlist",
          "unwhitelist",
          "unwl",
          "anaudit",
          "secscan",
          "panic",
          "emergency",
          "serverdoctor",
          "doctor",
          "antiraid",
          "nightmode",
          "quarantine",
          "jail",
          "unquarantine",
          "unjail",
          "vanityguard",
          "vanity",
          "verification",
          "verify",
          "selfcheck",
          "auditcheck",
          "securityscore",
          "secscore"
        ]
      },
      {
        "title": "MainRole",
        "commands": [
          "mainrole add",
          "mainrole remove",
          "mainrole list",
          "mainrole reset"
        ]
      }
    ]
  },
  {
    "id": "automod",
    "label": "AutoMod",
    "value": "automod",
    "description": "Get All Automod Commands",
    "emoji": "<a:tungsten_policy:1569329528851927131>",
    "sections": [
      {
        "title": "AutoMod",
        "commands": [
          "automod",
          "am",
          "automod enable",
          "automod disable",
          "automod punishment",
          "automod config",
          "automod logging",
          "automod ignore",
          "automod ignore channel",
          "automod ignore role",
          "automod ignore show",
          "automod ignore reset",
          "automod unignore",
          "automod unignore channel",
          "automod unignore role",
          "nativeautomod",
          "nam",
          "nativeam",
          "discordautomod",
          "fastrules",
          "quickrules"
        ]
      },
      {
        "title": "Filters",
        "commands": [
          "antilink",
          "anti-link",
          "antiinvite",
          "anti-invite",
          "antispam",
          "anti-spam",
          "anticaps",
          "anti-caps",
          "antiemojispam",
          "antiemoji",
          "antighostping",
          "antighost",
          "antigif",
          "nogif",
          "antimassmention",
          "antimention",
          "antinsfw",
          "anti-nsfw",
          "antibadwords",
          "badwords"
        ]
      },
      {
        "title": "Antibot",
        "commands": [
          "antibot",
          "antibot add",
          "antibot remove",
          "antibot whitelist add",
          "antibot whitelist remove",
          "antibot config",
          "antibot reset"
        ]
      }
    ]
  },
  {
    "id": "automations",
    "label": "Automations",
    "value": "automations",
    "description": "Get All Automations Commands",
    "emoji": "<a:tungsten_gear:1567239932970406012>",
    "sections": [
      {
        "title": "AutoRole",
        "commands": [
          "autorole",
          "ar",
          "autorole bots add",
          "autorole bots remove",
          "autorole bots",
          "autorole config",
          "autorole humans add",
          "autorole humans remove",
          "autorole humans",
          "autorole reset all",
          "autorole reset bots",
          "autorole reset humans"
        ]
      },
      {
        "title": "Automation Rules",
        "commands": [
          "stickymessage",
          "sticky",
          "tag",
          "tags",
          "t",
          "customcmd",
          "cc",
          "ccmd",
          "workflow",
          "wf"
        ]
      }
    ]
  },
  {
    "id": "autoresponder",
    "label": "Autoresponder",
    "value": "autoresponder",
    "description": "Get All Autoresponder Commands",
    "emoji": "<a:tungsten_chat:1567234399450177665>",
    "sections": [
      {
        "title": "Autoresponder",
        "commands": [
          "autoresponder",
          "autoresponder create",
          "autoresponder delete",
          "autoresponder edit",
          "autoresponder config"
        ]
      },
      {
        "title": "Autoreact",
        "commands": [
          "react",
          "autoreact",
          "react add",
          "react remove",
          "react list",
          "react reset",
          "reactrule"
        ]
      }
    ]
  },
  {
    "id": "customrole",
    "label": "CustomRole",
    "value": "customrole",
    "description": "Get All CustomRole Commands",
    "emoji": "<a:tungsten_cmd_customrole:1567235078654791690>",
    "sections": [
      {
        "title": "CustomRole Setup",
        "commands": [
          "setup",
          "setup create",
          "setup delete",
          "setup list",
          "setup staff",
          "setup girl",
          "setup friend",
          "setup vip",
          "setup guest",
          "setup config",
          "setup reset",
          "customrole",
          "cr",
          "crole",
          "specialrole"
        ]
      },
      {
        "title": "Role Shortcuts",
        "commands": [
          "staff",
          "girl",
          "friend",
          "vip",
          "guest"
        ]
      }
    ]
  },
  {
    "id": "fun",
    "label": "Fun",
    "value": "fun",
    "description": "Get All Fun Commands",
    "emoji": "<a:tungsten_party:1567241769593339988>",
    "sections": [
      {
        "title": "Fun",
        "commands": [
          "howgay",
          "gay",
          "lesbian",
          "cute",
          "intelligence",
          "iq",
          "chutiya",
          "horny",
          "tharki",
          "gif",
          "weather",
          "fakeban",
          "fban",
          "image",
          "img",
          "8ball",
          "truth",
          "dare",
          "coinflip",
          "flip",
          "cf",
          "roll",
          "dice",
          "rps",
          "connect4",
          "c4",
          "joke",
          "meme",
          "trivia",
          "quiz",
          "clans",
          "clan",
          "marry",
          "marriage",
          "divorce",
          "couples",
          "couple",
          "ship",
          "love"
        ]
      },
      {
        "title": "Roleplay",
        "commands": [
          "roleplay",
          "rp",
          "act",
          "hug",
          "kiss",
          "pat",
          "headpat",
          "cuddle",
          "slap",
          "tickle",
          "spank",
          "kill",
          "poke",
          "highfive",
          "hfive",
          "bite",
          "bonk",
          "punch",
          "stare",
          "wave",
          "smug",
          "yeet",
          "dance",
          "handhold",
          "holdhands",
          "cry",
          "lappillow",
          "happy"
        ]
      }
    ]
  },
  {
    "id": "general",
    "label": "General",
    "value": "general",
    "description": "Get All General Commands",
    "emoji": "<a:tungsten_globe:1567240068253622433>",
    "sections": [
      {
        "title": "General",
        "commands": [
          "status",
          "afk",
          "avatar",
          "av",
          "pfp",
          "banner",
          "userbanner",
          "serverbanner",
          "servericon",
          "icon",
          "membercount",
          "mc",
          "poll",
          "urban",
          "users",
          "botprofile",
          "bp",
          "profile",
          "rep",
          "reputation",
          "giverep",
          "noprefix",
          "np",
          "np list",
          "np check"
        ]
      },
      {
        "title": "Directory Lists",
        "commands": [
          "list boosters",
          "list inrole",
          "list emojis",
          "list bots",
          "list admins",
          "list invoice",
          "list early",
          "list roles",
          "inrole",
          "membersinrole"
        ]
      }
    ]
  },
  {
    "id": "giveaway",
    "label": "Giveaway",
    "value": "giveaway",
    "description": "Get all giveaway commands",
    "emoji": "<a:tungsten_cmd_giveaway:1567235389226352785>",
    "sections": [
      {
        "title": "Giveaway",
        "commands": [
          "giveaway",
          "gstart",
          "gend",
          "greroll",
          "glist",
          "gstaff role",
          "gstaff reset",
          "gconfig",
          "gembed set",
          "gembed reset",
          "gaway"
        ]
      }
    ]
  },
  {
    "id": "leaderboard",
    "label": "Leaderboard",
    "value": "leaderboard",
    "description": "Get All Leaderboard Commands",
    "emoji": "<a:tungsten_trophy:1567242918446501939>",
    "sections": [
      {
        "title": "VoiceLeaderboard",
        "commands": [
          "vclb",
          "voicelb",
          "voicelb on",
          "voicelb off",
          "vcstats",
          "voiceleaderboard",
          "dailyvoice",
          "weeklyvoice",
          "addvctime",
          "reducevctime",
          "clearvoice",
          "resetvoice",
          "resetmyvoice",
          "setvoicerole",
          "voicerole"
        ]
      },
      {
        "title": "MessageLeaderboard",
        "commands": [
          "msglb",
          "msglb on",
          "msglb off",
          "msgstats",
          "leaderboard messages",
          "leaderboard dailymessages",
          "leaderboard weeklymessages",
          "addmessages",
          "removemessages",
          "clearmsgs",
          "resetmymessages",
          "blacklistchannel",
          "unblacklistchannel",
          "blacklistedchannels",
          "blacklistcategory",
          "unblacklistcategory",
          "blacklistedcategories",
          "setmessagerole",
          "unsetmessagerole",
          "viewmessageroles"
        ]
      },
      {
        "title": "InviteLeaderboard",
        "commands": [
          "invitelb",
          "invitelb on",
          "invitelb off",
          "invites",
          "inv",
          "inviter",
          "invited",
          "inviteinfo",
          "inviteleaderboard total",
          "inviteleaderboard regular",
          "inviteleaderboard fake",
          "inviteleaderboard left",
          "addinvites",
          "removeinvites",
          "clearinvites",
          "resetmyinvites",
          "setaltthreshold",
          "unsetaltthreshold",
          "setinviterole",
          "unsetinviterole",
          "viewinviteroles"
        ]
      },
      {
        "title": "Leveling",
        "commands": [
          "levels",
          "rank",
          "level",
          "xp",
          "levelup",
          "levelrole",
          "levelroles",
          "lvlrole",
          "noxp",
          "ignorexp",
          "xpmulti",
          "xpmultiplier"
        ]
      },
      {
        "title": "LiveLeaderboard",
        "commands": [
          "createlivelb",
          "deletelivelb",
          "showlivelbs"
        ]
      },
      {
        "title": "TopLeaderboard",
        "commands": [
          "top messages",
          "top voice",
          "top invites",
          "top"
        ]
      }
    ]
  },
  {
    "id": "logging",
    "label": "Logging",
    "value": "logging",
    "description": "Get All Logging Commands",
    "emoji": "<a:tungsten_scroll:1567242059708899381>",
    "sections": [
      {
        "title": "Logging",
        "commands": [
          "logging",
          "logs",
          "logging setup",
          "logging auto",
          "logging config",
          "logging enable",
          "logging disable",
          "logging reset",
          "auditlog",
          "modlog",
          "logchannel",
          "logrouter",
          "logsettings",
          "anlog",
          "anlogs"
        ]
      }
    ]
  },
  {
    "id": "moderation",
    "label": "Moderation",
    "value": "moderation",
    "description": "Get All Moderation Commands",
    "emoji": "<a:tungsten_hammer:1567240140277944350>",
    "sections": [
      {
        "title": "Moderation Actions",
        "commands": [
          "ban",
          "b",
          "unban",
          "ub",
          "unbanall",
          "kick",
          "k",
          "mute",
          "m",
          "unmute",
          "um",
          "unmuteall",
          "softban",
          "tempban",
          "tban",
          "warn",
          "w",
          "warnings",
          "warns",
          "clearwarns",
          "warnladder",
          "ladder",
          "lock",
          "lockall",
          "unlock",
          "unlockall",
          "hide",
          "hideall",
          "unhide",
          "unhideall",
          "nick",
          "nuke",
          "clone",
          "snipe",
          "slowmode",
          "sm",
          "unslowmode",
          "enlarge",
          "steal",
          "cleanup",
          "clean",
          "smartpurge",
          "clearv2",
          "modpanel",
          "mpanel",
          "moderationpanel",
          "banpanel",
          "kickpanel",
          "mutepanel",
          "warnpanel",
          "lockpanel",
          "modrolepanel",
          "purgepanel",
          "tungmod",
          "tungstenmod",
          "cases",
          "cm",
          "duty",
          "investigate",
          "macro",
          "override",
          "policy",
          "watchlist",
          "vcban",
          "vcdeafen",
          "vckick",
          "vcmute",
          "vcunmute",
          "vdrag"
        ]
      },
      {
        "title": "Roles Management",
        "commands": [
          "role",
          "role create",
          "role delete",
          "role rename",
          "role all",
          "role humans",
          "role bots",
          "role unverified",
          "removerole",
          "rrole all",
          "rrole humans",
          "rrole bots",
          "giverole",
          "addrole",
          "roleadd",
          "roleall",
          "massrole",
          "temprole",
          "trole",
          "roleicon",
          "setroleicon"
        ]
      },
      {
        "title": "Purge",
        "commands": [
          "purge",
          "del",
          "clear",
          "prune",
          "purge embeds",
          "purge files",
          "purge images",
          "purge bot",
          "purge emoji",
          "purge contains",
          "purge reactions",
          "purge user"
        ]
      },
      {
        "title": "Jail",
        "commands": [
          "jail",
          "jail add",
          "jail remove",
          "jail setup",
          "jail list",
          "jail config",
          "jail reset"
        ]
      }
    ]
  },
  {
    "id": "permit",
    "label": "Permit",
    "value": "permit",
    "description": "Get All Permit Commands",
    "emoji": "<a:tungsten_cat_whitelist:1567234327970848848>",
    "sections": [
      {
        "title": "Permit",
        "commands": [
          "extraowner",
          "extraown",
          "extraowner add",
          "extraowner view",
          "extraowner reset"
        ]
      },
      {
        "title": "Ignore",
        "commands": [
          "ignore",
          "ignore command add",
          "ignore command remove",
          "ignore command show",
          "ignore channel add",
          "ignore channel remove",
          "ignore channel show",
          "ignore user add",
          "ignore user remove",
          "ignore user show",
          "ignore bypass add",
          "ignore bypass show",
          "ignore bypass remove"
        ]
      }
    ]
  },
  {
    "id": "reactionroles",
    "label": "ReactionRoles",
    "value": "reactionroles",
    "description": "Get All ReactionRoles Commands",
    "emoji": "<a:tungsten_sparkle:1567242264311369839>",
    "sections": [
      {
        "title": "ReactionRoles",
        "commands": [
          "reactionroles",
          "reactionrole",
          "rr",
          "reactionrole add",
          "reactionrole remove",
          "reactionrole list",
          "reactionrole reset"
        ]
      }
    ]
  },
  {
    "id": "ticket",
    "label": "Ticket",
    "value": "ticket",
    "description": "Get All Ticket Commands",
    "emoji": "<a:tungsten_ticket:1567242811961770155>",
    "sections": [
      {
        "title": "Ticket",
        "commands": [
          "ticket",
          "tickets",
          "ticket setup",
          "ticket panel",
          "ticket staff",
          "ticket setcategory",
          "ticket transcript",
          "ticket adduser",
          "ticket removeuser",
          "ticket close",
          "ticket delete",
          "ticket config",
          "ticket reset",
          "ticket edit"
        ]
      }
    ]
  },
  {
    "id": "utility",
    "label": "Utility",
    "value": "utility",
    "description": "Get All Utility Commands",
    "emoji": "<a:tungsten_bolt:1567233430570405968>",
    "sections": [
      {
        "title": "Core Utility",
        "commands": [
          "help",
          "h",
          "botinfo",
          "bi",
          "stats",
          "uptime",
          "invite",
          "serverinfo",
          "si",
          "userinfo",
          "ui",
          "roleinfo",
          "ri",
          "boostcount",
          "boost",
          "boosts",
          "joined-at",
          "ping",
          "p",
          "pong",
          "github",
          "vcinfo",
          "channelinfo",
          "ci",
          "badges",
          "banner",
          "reminder",
          "remind",
          "remindme",
          "permissions",
          "perms",
          "botperms",
          "myperms",
          "userperms",
          "timer",
          "prime",
          "setupi",
          "makeqr",
          "qr",
          "showupi",
          "upi",
          "calc",
          "math",
          "convert",
          "base",
          "encode",
          "decode",
          "hash",
          "diff",
          "case",
          "lorem",
          "wordcount",
          "wc",
          "pings",
          "mentionalert",
          "starboard",
          "star",
          "suggest",
          "suggestion",
          "suggestapprove",
          "suggestdeny",
          "suggestchannel",
          "suggestconfig",
          "template",
          "webhook",
          "wh",
          "discordpoll",
          "dpoll",
          "discordevent",
          "event",
          "componentsv2",
          "v2",
          "cv2",
          "modules",
          "module",
          "panel",
          "settings",
          "config",
          "prefix",
          "setprefix",
          "embedcolor",
          "accent",
          "color",
          "emojilist",
          "emojipack",
          "emojizip",
          "addemoji",
          "deleteemoji",
          "delsticker",
          "support",
          "tos",
          "apply",
          "appsetup"
        ]
      },
      {
        "title": "Media Suite",
        "commands": [
          "media",
          "media setup",
          "media remove",
          "media config",
          "media bypass",
          "media bypass add",
          "media bypass remove",
          "media bypass show"
        ]
      }
    ]
  },
  {
    "id": "vanityroles",
    "label": "Vanityroles",
    "value": "vanityroles",
    "description": "Get All Vanityroles Commands",
    "emoji": "<a:tungsten_cmd_vanityguard:1567237826154602613>",
    "sections": [
      {
        "title": "Vanityroles",
        "commands": [
          "vanityroles",
          "vanityroles setup",
          "vanityroles reset",
          "vanityroles config"
        ]
      }
    ]
  },
  {
    "id": "voice",
    "label": "Voice",
    "value": "voice",
    "description": "Get All Voice Commands",
    "emoji": "<a:tungsten_cmd_voice:1567237893590753360>",
    "sections": [
      {
        "title": "Voice Moderation",
        "commands": [
          "voice",
          "vcmod",
          "voicemod",
          "vcban",
          "vckick",
          "vkick",
          "vcmute",
          "vmute",
          "vcunmute",
          "vunmute",
          "vcdeafen",
          "vdeafen",
          "vdrag",
          "vcmove",
          "voice kick",
          "voice kickall",
          "voice mute",
          "voice muteall",
          "voice unmute",
          "voice unmuteall",
          "voice deafen",
          "voice deafenall",
          "voice undeafen",
          "voice undeafenall",
          "voice move",
          "voice moveall",
          "voice pull",
          "voice pullall",
          "voice lock",
          "voice unlock",
          "voice private",
          "voice unprivate"
        ]
      },
      {
        "title": "Voice Channels & Extras",
        "commands": [
          "homevc",
          "sethomevc",
          "resethomevc",
          "setvcstatus",
          "vcstatus",
          "vcstatuspanel",
          "soundboard",
          "stage",
          "vcrole add",
          "vcrole remove",
          "vcrole config",
          "forum",
          "thread"
        ]
      }
    ]
  },
  {
    "id": "voicemaster",
    "label": "VoiceMaster",
    "value": "voicemaster",
    "description": "Get Voice Master Setup Commands",
    "emoji": "<a:tungsten_sound:1567242242127568958>",
    "sections": [
      {
        "title": "VoiceMaster",
        "commands": [
          "voicemaster",
          "vm",
          "j2c",
          "jointocreate",
          "j2cpanel",
          "dynamicvc",
          "j2chub",
          "voicemaster setup",
          "voicemaster buttons",
          "voicemaster config",
          "voicemaster reset"
        ]
      }
    ]
  },
  {
    "id": "welcomer",
    "label": "Welcomer",
    "value": "welcomer",
    "description": "Get All Welcomer Commands",
    "emoji": "<a:tungsten_wave:1567246763822158004>",
    "sections": [
      {
        "title": "Welcomer",
        "commands": [
          "welcome",
          "welcomer",
          "greet",
          "greet setup",
          "greet reset",
          "greet channel",
          "greet edit",
          "greet test",
          "greet config",
          "greet autodeletete",
          "leave",
          "farewell"
        ]
      }
    ]
  },
  {
    "id": "custommod",
    "label": "Custom Moderation",
    "value": "custommod",
    "description": "Advanced server policies, macros, duty & custom mod",
    "emoji": "<a:tungsten_shield:1567242104923627574>",
    "sections": [
      {
        "title": "Custom Moderation",
        "commands": [
          "cm",
          "cmpanel",
          "cmsetup",
          "macro",
          "macrolist",
          "macrocreate",
          "macrodelete",
          "macrorun",
          "policy",
          "policies",
          "modpolicy",
          "override",
          "cmdoverride",
          "watchlist",
          "duty",
          "investigate",
          "cases"
        ]
      }
    ]
  },
  {
    "id": "backups",
    "label": "Backups",
    "value": "backups",
    "description": "Server templates, snapshots & recovery",
    "emoji": "<a:tungsten_save:1567242015283085507>",
    "sections": [
      {
        "title": "Backups",
        "commands": [
          "backup",
          "backup create",
          "backup load",
          "backup info",
          "backup list",
          "backup delete"
        ]
      }
    ]
  },
  {
    "id": "economy",
    "label": "Economy",
    "value": "economy",
    "description": "Virtual economy, jobs, shop, inventory & quests",
    "emoji": "<a:tungsten_coin:1567238316967985244>",
    "sections": [
      {
        "title": "Economy",
        "commands": [
          "balance",
          "bal",
          "daily",
          "monthly",
          "beg",
          "work",
          "crime",
          "rob",
          "deposit",
          "dep",
          "withdraw",
          "with",
          "pay",
          "shop",
          "buy",
          "inventory",
          "inv",
          "jobs",
          "quests",
          "realestate",
          "stocks",
          "crypto",
          "slots",
          "fish",
          "hunt",
          "bankupgrade",
          "loan",
          "achievements",
          "badge"
        ]
      }
    ]
  }
];

const OWNER_CATEGORY = {
  id: 'owner',
  emoji: '<a:tungsten_crown:1567238355463176334>',
  label: 'Owner & Dev',
  description: 'Bot developer and owner administration'
};

function getBotAvatar(client) {
  if (client?.user && typeof client.user.displayAvatarURL === 'function') {
    try {
      const u = client.user.displayAvatarURL({ extension: 'png', size: 256 });
      if (typeof u === 'string' && u.startsWith('http')) return u;
    } catch (_) {}
  }
  return null;
}

function getCategoryDisplayEmoji(client, catId) {
  if (catId === 'owner') return OWNER_CATEGORY.emoji;
  const cat = CATEGORIES.find(c => c.id === catId || c.value === catId);
  if (cat && cat.emoji) return cat.emoji;
  return '<a:tungsten_bolt:1567233430570405968>';
}

function resolveCategoryCommands(client, catId) {
  const rawId = String(catId || '').toLowerCase().trim();
  const cat = CATEGORIES.find(c => c.id === rawId || c.value === rawId || c.label.toLowerCase() === rawId);
  if (!cat) return [];

  const seen = new Set();
  const cmds = [];

  const addCmd = (cmd) => {
    if (!cmd || !cmd.name) return;
    const nameLower = cmd.name.toLowerCase();
    if (seen.has(nameLower)) return;
    if (cmd.ownerOnly || cmd.category === 'owner') return;
    seen.add(nameLower);
    cmds.push(cmd);
  };

  if (Array.isArray(cat.sections)) {
    for (const sec of cat.sections) {
      if (!Array.isArray(sec.commands)) continue;
      for (const cmdStr of sec.commands) {
        const baseName = cmdStr.split(' ')[0].toLowerCase();
        const cmd = client?.commands?.get?.(baseName) || client?.commands?.get?.(client?.aliases?.get?.(baseName));
        if (cmd) {
          addCmd(cmd);
        } else {
          addCmd({ name: baseName, description: `${sec.title} command` });
        }
      }
    }
  }

  if (client?.categories) {
    const list = client.categories.get(cat.id) || client.categories.get(rawId) || [];
    for (const cmd of list) {
      addCmd(cmd);
    }
  }

  cmds.sort((a, b) => a.name.localeCompare(b.name));
  return cmds;
}

function buildHomeEmbed(client, prefix = '!', author = null, guildId = null) {
  const totalCommands = client?.commands ? client.commands.size : 0;
  const clientId = client?.user?.id || config.CLIENT_ID || '1344234547906969671';
  const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${clientId}&scope=bot%20applications.commands&permissions=8`;
  const botAvatar = getBotAvatar(client);

  const moduleLines = CATEGORIES.map(cat => `  ${cat.emoji} » ${cat.label}`).join('\n');

  const desc =
`A powerful multipurpose bot with Fastest Antinuke

• My Prefix is \`${prefix}\`
• Total Commands: ${totalCommands}
• Choose a Specific Module of your Desire
${moduleLines}

<a:tungsten_link:1567241025813086210> **Links**
[Invite Me](${inviteUrl}) | [Support Server](https://discord.gg/tfDMjZS9YJ) | [Website](https://discord.gg/tfDMjZS9YJ)`;

  const embed = new EmbedBuilder()
    .setTitle("Hey , I'm Tungsten™")
    .setAuthor({
      name: 'A powerful multipurpose bot with Fastest Antinuke',
      iconURL: botAvatar || undefined
    })
    .setDescription(desc)
    .setFooter({
      text: 'Powered By Tungsten Development™ | Designed By Tungsten Team',
      iconURL: botAvatar || undefined
    });

  if (botAvatar) {
    embed.setThumbnail(botAvatar);
  }

  return embed;
}

function normalizeCategoryArgs(arg1, arg2, arg3, arg4, arg5, arg6) {
  let cat = null;
  let catIndex = 0;
  let page = 0;
  let client = null;
  let prefix = '!';
  let author = null;
  let cmds = null;

  // Case 1: arg1 is a number (catIndex)
  if (typeof arg1 === 'number') {
    catIndex = Math.max(0, Math.min(CATEGORIES.length - 1, arg1));
    page = catIndex;
    cat = CATEGORIES[catIndex];
    client = arg2 || null;
    prefix = typeof arg3 === 'string' ? arg3 : '!';
    author = arg4 || null;
  }
  // Case 2: arg1 is client, arg2 is categoryId (string or number)
  else if (arg1 && (arg1.commands || arg1.categories || arg1.user) && (typeof arg2 === 'string' || typeof arg2 === 'number')) {
    client = arg1;
    if (typeof arg2 === 'number') {
      catIndex = Math.max(0, Math.min(CATEGORIES.length - 1, arg2));
      cat = CATEGORIES[catIndex];
    } else {
      const rawId = String(arg2).toLowerCase().trim();
      catIndex = CATEGORIES.findIndex(c => c.id === rawId || c.value === rawId || c.label.toLowerCase() === rawId);
      if (catIndex < 0) catIndex = 0;
      cat = CATEGORIES[catIndex];
    }
    page = typeof arg3 === 'number' ? arg3 : catIndex;
    prefix = typeof arg3 === 'string' ? arg3 : (typeof arg4 === 'string' ? arg4 : '!');
    author = arg4?.user ? arg4 : (arg5 || null);
  }
  // Case 3: arg1 is category string (e.g. 'antinuke')
  else if (typeof arg1 === 'string') {
    const rawId = arg1.toLowerCase().trim();
    catIndex = CATEGORIES.findIndex(c => c.id === rawId || c.value === rawId || c.label.toLowerCase() === rawId);
    if (catIndex < 0) catIndex = 0;
    cat = CATEGORIES[catIndex];
    cmds = Array.isArray(arg2) ? arg2 : null;
    page = typeof arg3 === 'number' ? arg3 : catIndex;
    client = arg4 || null;
    prefix = typeof arg5 === 'string' ? arg5 : '!';
    author = arg6 || null;
  }
  // Case 4: arg1 is category object (e.g. catMeta)
  else if (arg1 && typeof arg1 === 'object') {
    const rawId = String(arg1.id || arg1.value || arg1.label || '').toLowerCase().trim();
    const foundIdx = CATEGORIES.findIndex(c => c.id === rawId || c.value === rawId || c.label.toLowerCase() === rawId);
    if (foundIdx >= 0) {
      catIndex = foundIdx;
      cat = CATEGORIES[catIndex];
    } else {
      cat = arg1;
      catIndex = 0;
    }
    if (typeof arg2 === 'number') {
      catIndex = arg2;
      page = arg2;
      cmds = null;
      client = arg3 || null;
      prefix = typeof arg4 === 'string' ? arg4 : '!';
      author = arg5 || null;
    } else if (arg2 === null && typeof arg3 === 'number') {
      catIndex = arg3;
      page = arg3;
      cmds = null;
      client = arg4 || null;
      prefix = typeof arg5 === 'string' ? arg5 : '!';
      author = arg6 || null;
    } else {
      cmds = Array.isArray(arg2) ? arg2 : null;
      page = typeof arg3 === 'number' ? arg3 : catIndex;
      client = arg4 || null;
      prefix = typeof arg5 === 'string' ? arg5 : '!';
      author = arg6 || null;
    }
  }

  if (!cat) {
    catIndex = 0;
    page = 0;
    cat = CATEGORIES[0];
  }

  return { cat, catIndex, page, cmds, client, prefix, author };
}

function safeTruncateDescription(text, maxLength = 4096) {
  if (!text || text.length <= maxLength) return text;
  let truncated = text.slice(0, maxLength - 3);
  const lastComma = truncated.lastIndexOf(',');
  if (lastComma > maxLength - 100) {
    truncated = truncated.slice(0, lastComma);
  }
  const backtickCount = (truncated.match(/`/g) || []).length;
  if (backtickCount % 2 !== 0) {
    truncated += '`';
  }
  return truncated + '...';
}

function buildCategoryEmbed(arg1, arg2, arg3, arg4, arg5, arg6) {
  const { cat, catIndex, page, cmds, client, author } = normalizeCategoryArgs(arg1, arg2, arg3, arg4, arg5, arg6);
  const botAvatar = getBotAvatar(client);

  let body = '';
  const isCustomCmdList = Array.isArray(cmds) && cmds.length > 0 &&
    !cat?.sections?.some(s => s.commands.some(cmdStr => cmdStr.split(' ')[0].toLowerCase() === (cmds[0]?.name || '').toLowerCase()));

  if (isCustomCmdList) {
    const pageSize = 8;
    const start = (typeof page === 'number' ? page : 0) * pageSize;
    const slice = cmds.slice(start, start + pageSize);
    const cmdList = slice.map(c => typeof c === 'string' ? `\`${c}\`` : `\`${c.name}\``).join(', ');
    body = cmdList;
  } else if (Array.isArray(cat?.sections) && cat.sections.length > 0) {
    const listedCmds = new Set();
    cat.sections.forEach(sec => {
      if (Array.isArray(sec.commands)) {
        sec.commands.forEach(c => listedCmds.add(c.split(' ')[0].toLowerCase()));
      }
    });

    const extraCmds = [];
    if (client?.categories) {
      const registered = client.categories.get(cat.id) || client.categories.get(cat.value) || [];
      for (const cmd of registered) {
        if (!cmd || !cmd.name) continue;
        if (cmd.ownerOnly || cmd.category === 'owner') continue;
        const nameLower = cmd.name.toLowerCase();
        if (!listedCmds.has(nameLower)) {
          listedCmds.add(nameLower);
          extraCmds.push(nameLower);
        }
      }
    }

    const sectionsText = cat.sections.map(sec => {
      const cmdList = Array.isArray(sec.commands)
        ? sec.commands.map(c => `\`${c}\``).join(', ')
        : '';
      return `**${sec.title}**\n${cmdList}`;
    });

    if (extraCmds.length > 0) {
      extraCmds.sort();
      sectionsText.push(`**More Commands**\n${extraCmds.map(c => `\`${c}\``).join(', ')}`);
    }

    body = sectionsText.join('\n\n');
  } else if (Array.isArray(cmds) && cmds.length > 0) {
    const cmdList = cmds.map(c => typeof c === 'string' ? `\`${c}\`` : `\`${c.name}\``).join(', ');
    body = cmdList;
  } else {
    body = '*No commands available in this module.*';
  }

  const prefixHeader = cat?.emoji ? `${cat.emoji} **${cat.label}**\n\n` : '';
  let description = `${prefixHeader}${body}`;
  description = safeTruncateDescription(description, 4096);

  let authorIcon = null;
  if (author && typeof author.displayAvatarURL === 'function') {
    try {
      const u = author.displayAvatarURL({ extension: 'png', size: 128 });
      if (typeof u === 'string' && u.startsWith('http')) authorIcon = u;
    } catch (_) {}
  } else if (author && typeof author.avatarURL === 'function') {
    try {
      const u = author.avatarURL({ extension: 'png', size: 128 });
      if (typeof u === 'string' && u.startsWith('http')) authorIcon = u;
    } catch (_) {}
  }

  const embed = new EmbedBuilder()
    .setTitle(cat?.label || 'Commands')
    .setDescription(description)
    .setFooter({
      text: `Requested by ${author?.username || author?.user?.username || 'User'} | Page ${catIndex + 1} / ${CATEGORIES.length}`,
      iconURL: authorIcon || undefined
    });

  if (botAvatar) {
    embed.setThumbnail(botAvatar);
  }

  return embed;
}

function createCategoryNavRow(catIndex) {
  const isFirst = catIndex <= 0;
  const isLast = catIndex >= CATEGORIES.length - 1;

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`help:cat_first:${catIndex}`)
      .setLabel('<<')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(isFirst),
    new ButtonBuilder()
      .setCustomId(`help:cat_prev:${catIndex}`)
      .setLabel('<')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(isFirst),
    new ButtonBuilder()
      .setCustomId('help:close')
      .setEmoji('<a:tungsten_trash:1567242891276062872>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`help:cat_next:${catIndex}`)
      .setLabel('>')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(isLast),
    new ButtonBuilder()
      .setCustomId(`help:cat_last:${catIndex}`)
      .setLabel('>>')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(isLast)
  );

  return row;
}

function createSelectMenu(currentCategory = null, catIndex = -1) {
  const options = [
    {
      label: 'Home',
      value: 'home',
      description: 'Overview and Information',
      emoji: '<a:tungsten_home:1567240545661620387>'
    },
    ...CATEGORIES.map(cat => ({
      label: cat.label,
      value: cat.value || cat.id,
      description: cat.description,
      emoji: cat.emoji
    }))
  ];

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('help:select_category')
    .setPlaceholder('❯ Select Module From Here')
    .addOptions(options);

  return new ActionRowBuilder().addComponents(selectMenu);
}

function createHelpComponents(currentCategory = 'home', currentPage = 0, totalPages = 1, client = null) {
  if (currentCategory === 'home') {
    const selectRow = createSelectMenu('home', -1);
    return [selectRow];
  }

  let catIndex = 0;
  if (typeof currentPage === 'number' && currentPage >= 0 && currentPage < CATEGORIES.length) {
    catIndex = currentPage;
  } else if (typeof currentCategory === 'string') {
    const foundIdx = CATEGORIES.findIndex(c => c.id === currentCategory.toLowerCase() || c.value === currentCategory.toLowerCase());
    if (foundIdx >= 0) catIndex = foundIdx;
  } else if (currentCategory && currentCategory.id) {
    const foundIdx = CATEGORIES.findIndex(c => c.id === currentCategory.id.toLowerCase() || c.value === currentCategory.id.toLowerCase());
    if (foundIdx >= 0) catIndex = foundIdx;
  }

  const navRow = createCategoryNavRow(catIndex);
  const selectRow = createSelectMenu(CATEGORIES[catIndex].id, catIndex);

  return [navRow, selectRow];
}

function buildCommandEmbed(cmd, client = null, prefix = '!', author = null) {
  const cleanName = cmd?.name ? cmd.name.replace(/_/g, ' ') : 'Command';
  const sig = `${prefix}${cleanName}${cmd?.usage ? ` ${cmd.usage}` : ''}`;
  const desc = cmd?.description ? sentenceCase(cmd.description) : 'No description provided.';
  const botAvatar = getBotAvatar(client);

  const embed = new EmbedBuilder()
    .setTitle(cleanName)
    .setDescription(`> ${desc}\n\n**Syntax**\n\`${sig}\``)
    .addFields([
      {
        name: 'Category',
        value: `\`${Array.isArray(cmd?.category) ? cmd.category.join(', ') : (cmd?.category || 'Utility')}\``,
        inline: true
      },
      {
        name: 'Cooldown',
        value: `\`${cmd?.cooldown || 3}s\``,
        inline: true
      },
      {
        name: 'Slash Ready',
        value: cmd?.slash ? '`Yes`' : '`No`',
        inline: true
      },
      {
        name: 'Required Permissions',
        value: cmd?.permissions && cmd.permissions.length > 0 ? cmd.permissions.map(p => `\`${p}\``).join(', ') : '`None`',
        inline: true
      },
      {
        name: 'Bot Permissions',
        value: cmd?.botPermissions && cmd.botPermissions.length > 0 ? cmd.botPermissions.map(p => `\`${p}\``).join(', ') : '`None`',
        inline: true
      },
      {
        name: 'Aliases',
        value: cmd?.aliases && cmd.aliases.length > 0 ? cmd.aliases.map(a => `\`${a}\``).join(' ') : '`None`',
        inline: false
      }
    ])
    .setFooter({
      text: 'Powered By Tungsten Development™ | Designed By Tungsten Team',
      iconURL: botAvatar || undefined
    });

  if (botAvatar) {
    embed.setThumbnail(botAvatar);
  }

  return embed;
}

function createCommandComponents() {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('help:home')
      .setLabel('Home')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_home:1567240545661620387>'),
    new ButtonBuilder()
      .setLabel('Support Server')
      .setStyle(ButtonStyle.Link)
      .setURL(config.LINKS?.SUPPORT || config.SUPPORT_SERVER || 'https://discord.gg/tfDMjZS9YJ'),
    new ButtonBuilder()
      .setCustomId('help:close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );
  return [row];
}

function buildHomePayload(client, prefix = '!', author = null, guildId = null) {
  const embed = buildHomeEmbed(client, prefix, author, guildId);
  const rows = createHelpComponents('home', 0, 1, client);

  return {
    embeds: [embed],
    components: rows
  };
}

function buildCategoryPayload(arg1, arg2, arg3, arg4, arg5, arg6) {
  const { cat, catIndex, client, prefix, author } = normalizeCategoryArgs(arg1, arg2, arg3, arg4, arg5, arg6);
  const embed = buildCategoryEmbed(cat, catIndex, client, prefix, author);
  const rows = createHelpComponents(cat.id, catIndex, CATEGORIES.length, client);

  return {
    embeds: [embed],
    components: rows
  };
}

function buildCommandPayload(cmd, client = null, prefix = '!', author = null) {
  const embed = buildCommandEmbed(cmd, client, prefix, author);
  const components = createCommandComponents();

  return {
    embeds: [embed],
    components
  };
}

let allCommandsHelpMap = null;
try {
  allCommandsHelpMap = require('./allCommandsHelpMap.json');
} catch (_) {}

module.exports = {
  CATEGORIES,
  allCommandsHelpMap,
  OWNER_CATEGORY,
  resolveCategoryCommands,
  getCategoryDisplayEmoji,
  buildHomeEmbed,
  buildCategoryEmbed,
  createSelectMenu,
  createCategorySelectMenu: createSelectMenu,
  createCategoryNavRow,
  createHelpComponents,
  buildCommandEmbed,
  createCommandComponents,
  buildHomePayload,
  buildCategoryPayload,
  buildCommandPayload
};
