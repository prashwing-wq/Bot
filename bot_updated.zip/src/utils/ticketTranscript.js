/**
 * Ticket Transcript & Lifecycle Manager (Node.js)
 * Implements HTML and text transcript generation, delivery to ticket log channel & DM,
 * and graceful channel removal.
 */
const { AttachmentBuilder } = require('discord.js');
const { getServerDb } = require('./serverDb');
const { createEmbed } = require('./tools');
const { markAuthorizedDeletion, markBotDeletedEntity } = require('./antinukeEngine');
const { EMOJIS } = require('./emojis');

const DEFAULT_CATEGORIES = [
  {
    id: 'general',
    name: 'General Support',
    emoji: EMOJIS.CHAT,
    description: 'Assistance with server features, roles, or inquiries',
    questions: [
      { id: 'q1', label: 'What do you need assistance with?', placeholder: 'Describe your issue or question...', required: true },
      { id: 'q2', label: 'Any additional details or context?', placeholder: 'Provide any helpful context...', required: false }
    ]
  },
  {
    id: 'billing',
    name: 'Billing & Store',
    emoji: EMOJIS.COIN,
    description: 'Inquiries regarding transactions, shop, or rewards',
    questions: [
      { id: 'q1', label: 'What is your transaction or store inquiry?', placeholder: 'Describe your billing question...', required: true },
      { id: 'q2', label: 'Transaction ID or receipt (if applicable)', placeholder: 'Paste transaction or reference ID...', required: false }
    ]
  },
  {
    id: 'report',
    name: 'Report User / Violation',
    emoji: EMOJIS.SIREN,
    description: 'Report rule violations, harassment, or exploits',
    questions: [
      { id: 'q1', label: 'User being reported (Name or ID)', placeholder: 'Username or user snowflake ID...', required: true },
      { id: 'q2', label: 'What rule did they violate?', placeholder: 'Describe the violation in detail...', required: true },
      { id: 'q3', label: 'Evidence or message link', placeholder: 'Links to messages, screenshots, or proofs...', required: false }
    ]
  }
];

function getTicketCategories(guildId, sdb = null) {
  const db = sdb || getServerDb(guildId);
  try {
    const rows = db.prepare('SELECT * FROM server_ticket_categories WHERE guild_id = ?').all(guildId);
    if (rows && rows.length > 0) {
      return rows.map(r => ({
        id: r.category_id,
        name: r.name,
        emoji: EMOJIS.TICKET,
        staff_role_id: r.staff_role_id,
        questions: r.questions ? JSON.parse(r.questions) : DEFAULT_CATEGORIES[0].questions
      }));
    }
  } catch (_) {}
  return DEFAULT_CATEGORIES;
}

function generateTranscriptText(guild, channel, ticketRow, messages, closerUser, reason) {
  const dateStr = new Date().toISOString();
  let text = `==================================================================\n`;
  text += `                 TUNGSTEN SUPPORT TICKET TRANSCRIPT\n`;
  text += `==================================================================\n`;
  text += `Server:           ${guild.name} (${guild.id})\n`;
  text += `Channel:          #${channel.name} (${channel.id})\n`;
  text += `Ticket Creator:   ${ticketRow?.user_id || 'Unknown'}\n`;
  text += `Category:         ${ticketRow?.category || 'General Support'}\n`;
  text += `Claimed By:       ${ticketRow?.claimed_by ? `${ticketRow.claimed_by}` : 'Unclaimed'}\n`;
  text += `Closed By:        ${closerUser ? `${closerUser.tag || closerUser.username} (${closerUser.id})` : 'Staff'}\n`;
  text += `Closed At:        ${dateStr}\n`;
  text += `Reason:           ${reason || 'Ticket resolved'}\n`;
  text += `Total Messages:   ${messages?.size || 0}\n`;
  text += `==================================================================\n\n`;

  if (messages && messages.size > 0) {
    const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    for (const m of sorted) {
      const time = m.createdAt ? m.createdAt.toISOString() : 'Unknown Time';
      const authorTag = m.author ? `${m.author.tag || m.author.username} (${m.author.id})` : 'Unknown User';
      const content = m.content || '[No text content / embed or attachment]';
      text += `[${time}] ${authorTag}: ${content}\n`;
    }
  } else {
    text += `[No message payload retrieved]\n`;
  }

  return text;
}

function generateTranscriptHtml(guild, channel, ticketRow, messages, closerUser, reason) {
  const dateStr = new Date().toISOString();
  let html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ticket Transcript - #${channel.name}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #202225; color: #dcddde; margin: 0; padding: 24px; }
    .header { background: #2f3136; border-radius: 8px; padding: 20px; margin-bottom: 24px; border-left: 4px solid #5865f2; }
    .title { font-size: 20px; font-weight: bold; color: #ffffff; margin-bottom: 8px; }
    .meta { font-size: 13px; color: #b9bbbe; line-height: 1.6; }
    .meta strong { color: #ffffff; }
    .message { display: flex; margin-bottom: 16px; padding: 4px 8px; border-radius: 4px; }
    .message:hover { background: #282b30; }
    .avatar { width: 40px; height: 40px; border-radius: 50%; background: #5865f2; margin-right: 14px; display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; flex-shrink: 0; }
    .content { flex-grow: 1; }
    .author-line { margin-bottom: 4px; }
    .author-name { font-weight: 600; color: #ffffff; margin-right: 8px; font-size: 14px; }
    .timestamp { font-size: 11px; color: #72767d; }
    .body { font-size: 14px; line-height: 1.4; word-break: break-word; }
  </style>
</head>
<body>
  <div class="header">
    <div class="title">🎫 Ticket Transcript: #${channel.name}</div>
    <div class="meta">
      <strong>Server:</strong> ${guild.name} (${guild.id})<br>
      <strong>Ticket Creator:</strong> &lt;@${ticketRow?.user_id || 'Unknown'}&gt;<br>
      <strong>Category:</strong> ${ticketRow?.category || 'General Support'}<br>
      <strong>Claimed By:</strong> ${ticketRow?.claimed_by ? `&lt;@${ticketRow.claimed_by}&gt;` : 'Unclaimed'}<br>
      <strong>Closed By:</strong> ${closerUser ? closerUser.tag || closerUser.username : 'Staff'}<br>
      <strong>Closed At:</strong> ${dateStr}<br>
      <strong>Reason:</strong> ${reason || 'Ticket resolved'}
    </div>
  </div>
  <div class="messages">
`;

  if (messages && messages.size > 0) {
    const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    for (const m of sorted) {
      const initial = (m.author?.username || 'U')[0].toUpperCase();
      const authorTag = m.author ? (m.author.tag || m.author.username) : 'Unknown User';
      const time = m.createdAt ? m.createdAt.toLocaleString() : 'Unknown';
      const cleanContent = (m.content || '[No text content / embed or attachment]').replace(/</g, '&lt;').replace(/>/g, '&gt;');

      html += `    <div class="message">
      <div class="avatar">${initial}</div>
      <div class="content">
        <div class="author-line">
          <span class="author-name">${authorTag}</span>
          <span class="timestamp">${time}</span>
        </div>
        <div class="body">${cleanContent}</div>
      </div>
    </div>\n`;
    }
  }

  html += `  </div>
</body>
</html>`;
  return html;
}

async function closeTicketWithTranscript({ guild, channel, closerUser, reason, client, sdb = null }) {
  const db = sdb || getServerDb(guild.id);
  const ticketRow = db.prepare('SELECT * FROM server_tickets WHERE channel_id = ?').get(channel.id);

  // Fetch messages for transcript
  let messages = new Map();
  try {
    messages = await channel.messages.fetch({ limit: 100 }).catch(() => new Map());
  } catch (_) {}

  const textTranscript = generateTranscriptText(guild, channel, ticketRow, messages, closerUser, reason);
  const htmlTranscript = generateTranscriptHtml(guild, channel, ticketRow, messages, closerUser, reason);

  const textFile = new AttachmentBuilder(Buffer.from(textTranscript, 'utf-8'), {
    name: `transcript-${channel.name || channel.id}.txt`
  });
  const htmlFile = new AttachmentBuilder(Buffer.from(htmlTranscript, 'utf-8'), {
    name: `transcript-${channel.name || channel.id}.html`
  });

  // 1. Send to ticket log channel
  try {
    const logRow = db.prepare(
      "SELECT value FROM server_settings WHERE key = 'ticket_log_channel' OR key = 'tickets.log.channel' OR key = 'log_mod' OR key = 'audit_log_channel'"
    ).get();

    if (logRow && logRow.value) {
      const logChannel = guild.channels.cache.get(logRow.value) || (await guild.channels.fetch(logRow.value).catch(() => null));
      if (logChannel && logChannel.isTextBased()) {
        const embed = createEmbed({
          color: 0xed4245,
          title: '📄 Support Ticket Closed & Archived',
          description:
            `• **Channel:** \`#${channel.name}\` (\`${channel.id}\`)\n` +
            `• **Creator:** <@${ticketRow?.user_id || 'Unknown'}> (\`${ticketRow?.user_id || 'Unknown'}\`)\n` +
            `• **Category:** \`${ticketRow?.category || 'General Support'}\`\n` +
            `• **Closed By:** <@${closerUser?.id || 'Unknown'}> (\`${closerUser?.tag || closerUser?.username || 'Staff'}\`)\n` +
            `• **Reason:** ${reason || 'Resolved'}\n` +
            `• **Messages:** \`${messages.size}\``,
          footerText: 'Tungsten Ticket Transcripts'
        });

        await logChannel.send({ embeds: [embed], files: [htmlFile, textFile] }).catch(() => null);
      }
    }
  } catch (_) {}

  // 2. DM the ticket owner
  if (ticketRow?.user_id) {
    try {
      const ownerUser = await client.users.fetch(ticketRow.user_id).catch(() => null);
      if (ownerUser) {
        const dmEmbed = createEmbed({
          color: 0x5865f2,
          title: `📄 Ticket Closed • ${guild.name}`,
          description:
            `Your support ticket **#${channel.name}** in **${guild.name}** has been closed.\n\n` +
            `• **Closed By:** ${closerUser ? closerUser.tag || closerUser.username : 'Staff'}\n` +
            `• **Reason:** ${reason || 'Ticket resolved'}\n\n` +
            `A full transcript of the ticket conversation is attached below for your records.`
        });
        await ownerUser.send({ embeds: [dmEmbed], files: [textFile] }).catch(() => null);
      }
    } catch (_) {}
  }

  // 3. Mark ticket closed in database
  db.prepare("UPDATE server_tickets SET status = 'closed', closed_at = ? WHERE channel_id = ?").run(
    Date.now(),
    channel.id
  );

  // 4. Delete the channel
  try {
    if (channel.guild?.id) {
      markAuthorizedDeletion(channel.guild.id, channel.id);
    }
    markBotDeletedEntity(channel.id);
    await channel.delete(`Ticket closed by ${closerUser?.tag || closerUser?.username || 'Staff'}`);
  } catch (_) {}

  return { success: true };
}

module.exports = {
  DEFAULT_CATEGORIES,
  getTicketCategories,
  generateTranscriptText,
  generateTranscriptHtml,
  closeTicketWithTranscript
};
