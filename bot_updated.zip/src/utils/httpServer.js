/**
 * Tungsten Health Probe & Prometheus Metrics Server (Node.js)
 * Listens on PORT / SERVER_PORT to provide /healthz, /readyz, and /metrics for container hosting.
 */
const http = require('node:http');

let _commandsTotal = 0;
let _errorsTotal = 0;
let _antinukeTriggersTotal = 0;

function incrementCommandCount() { _commandsTotal++; }
function incrementErrorCount() { _errorsTotal++; }
function incrementAntinukeTriggerCount() { _antinukeTriggersTotal++; }

function startHealthServer(client, customPort = null) {
  const port = customPort || process.env.SERVER_PORT || process.env.PORT || 8099;

  const server = http.createServer((req, res) => {
    const url = req.url.split('?')[0];

    if (url === '/healthz' || url === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      let mongoStatus = 'disabled';
      try {
        const { isMongoConnected } = require('./mongoClient');
        if (isMongoConnected()) mongoStatus = 'connected';
      } catch (_) {}
      return res.end(JSON.stringify({
        status: 'ok',
        uptime: Math.floor(process.uptime()),
        mongodb: mongoStatus
      }));
    }

    if (url === '/readyz' || url === '/ready') {
      const isReady = Boolean(client && client.isReady && client.isReady());
      res.writeHead(isReady ? 200 : 503, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({
        ready: isReady,
        guilds: client?.guilds?.cache?.size || 0,
        ping: Math.round(client?.ws?.ping || 0)
      }));
    }

    if (url === '/metrics') {
      const mem = process.memoryUsage();
      const ping = Math.round(client?.ws?.ping || 0);
      const guilds = client?.guilds?.cache?.size || 0;
      const users = client?.users?.cache?.size || 0;
      const uptime = Math.floor(process.uptime());

      let mongoConnected = 0;
      try {
        const { isMongoConnected } = require('./mongoClient');
        if (isMongoConnected()) mongoConnected = 1;
      } catch (_) {}

      const lines = [
        '# HELP mongodb_connected Whether MongoDB Atlas client is connected (1=yes, 0=no).',
        '# TYPE mongodb_connected gauge',
        `mongodb_connected ${mongoConnected}`,
        '# HELP tungsten_uptime_seconds Process uptime in seconds.',
        '# TYPE tungsten_uptime_seconds counter',
        `tungsten_uptime_seconds ${uptime}`,
        '# HELP tungsten_ws_ping_ms Discord WebSocket ping in milliseconds.',
        '# TYPE tungsten_ws_ping_ms gauge',
        `tungsten_ws_ping_ms ${ping}`,
        '# HELP tungsten_guilds_total Total cached guilds.',
        '# TYPE tungsten_guilds_total gauge',
        `tungsten_guilds_total ${guilds}`,
        '# HELP tungsten_users_total Total cached users.',
        '# TYPE tungsten_users_total gauge',
        `tungsten_users_total ${users}`,
        '# HELP tungsten_memory_rss_bytes Resident set size memory in bytes.',
        '# TYPE tungsten_memory_rss_bytes gauge',
        `tungsten_memory_rss_bytes ${mem.rss}`,
        '# HELP tungsten_memory_heap_used_bytes Heap memory used in bytes.',
        '# TYPE tungsten_memory_heap_used_bytes gauge',
        `tungsten_memory_heap_used_bytes ${mem.heapUsed}`,
        '# HELP tungsten_commands_executed_total Total commands executed.',
        '# TYPE tungsten_commands_executed_total counter',
        `tungsten_commands_executed_total ${_commandsTotal}`,
        '# HELP tungsten_errors_total Total runtime errors caught.',
        '# TYPE tungsten_errors_total counter',
        `tungsten_errors_total ${_errorsTotal}`,
        '# HELP tungsten_antinuke_triggers_total Total antinuke rate-limit/violation triggers.',
        '# TYPE tungsten_antinuke_triggers_total counter',
        `tungsten_antinuke_triggers_total ${_antinukeTriggersTotal}`
      ];
      res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
      return res.end(lines.join('\n') + '\n');
    }

    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found\n');
  });

  server.on('error', (err) => {
    console.warn(`[Health Server] Notice on port ${port}: ${err.message}`);
  });

  server.listen(port, () => {
    console.log(`[Health Server] Telemetry service listening on port ${port} (/healthz, /readyz, /metrics)`);
  });

  return server;
}

module.exports = {
  startHealthServer,
  incrementCommandCount,
  incrementErrorCount,
  incrementAntinukeTriggerCount
};
