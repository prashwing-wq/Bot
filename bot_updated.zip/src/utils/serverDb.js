/**
 * Tungsten Dedicated Per-Server Database Manager (Node.js)
 * Creates and maintains an isolated, independent database directory and database file
 * for every server (guild) Tungsten joins or manages.
 *
 * Folder Architecture:
 * db/servers/<guild_id>/
 *   ├── server.db       (Dedicated SQLite database in WAL mode)
 *   └── metadata.json   (Server metadata, sync status, and configuration details)
 */
const fs = require('fs');
const path = require('path');
try {
  require('dotenv').config({ path: path.resolve(__dirname, '..', '..', '.env') });
} catch (_) {}
const { openDatabase } = require('./sqliteDb');
const config = require('../config');

const ROOT_DIR = path.resolve(__dirname, '..', '..');
const DB_DIR = (process.env.TUNGSTEN_DB_DIR || process.env.CELESTIA_DB_DIR) ? path.resolve(process.env.TUNGSTEN_DB_DIR || process.env.CELESTIA_DB_DIR) : path.join(ROOT_DIR, 'db');
const SERVERS_BASE_DIR = path.join(DB_DIR, 'servers');
const MASTER_DB_PATH = path.join(DB_DIR, 'tungsten.db');
const LEGACY_MASTER_DB_PATH = path.join(DB_DIR, 'tungsten.db');

const _DB_CACHE = new Map();
const _HANDLE_TIMESTAMPS = new Map();
const _INITIALIZED_SERVERS = new Set();
let _MASTER_DB_INSTANCE = null;
let _MASTER_DB_INITIALIZED = false;
let LRU_MAX_CONNECTIONS = 250;

function isMongoCloudMode() {
  const uri = process.env.MONGODB_URI ? process.env.MONGODB_URI.trim() : '';
  return Boolean(uri && !process.env.CELESTIA_DB_DIR && !process.env.TUNGSTEN_DB_DIR);
}

function getAllCachedGuildDbs() {
  return _DB_CACHE;
}

function getServerDir(guildId) {
  return path.join(SERVERS_BASE_DIR, String(guildId));
}

function getServerDbPath(guildId) {
  if (isMongoCloudMode()) {
    return ':memory:';
  }
  return path.join(getServerDir(guildId), 'server.db');
}

function serverFolderExists(guildId) {
  const gid = String(guildId);
  if (isMongoCloudMode()) {
    return _DB_CACHE.has(gid) || _INITIALIZED_SERVERS.has(gid);
  }
  try {
    return fs.existsSync(getServerDir(gid)) && fs.statSync(getServerDir(gid)).isDirectory();
  } catch (e) {
    return false;
  }
}

/**
 * Validates whether an ID conforms to a valid Discord snowflake or test ID format.
 * Pure numeric string between 10 and 21 digits.
 * @param {string|number|bigint} id
 * @returns {boolean}
 */
function validateSnowflake(id) {
  if (id === null || id === undefined) return false;
  const str = String(id).trim();
  return /^\d{10,21}$/.test(str);
}

/**
 * C1 Idempotent Schema Migration for Snowflake IDs
 * Converts INTEGER columns holding Discord Snowflake IDs to TEXT to prevent ERR_OUT_OF_RANGE on Node 22+.
 */
function migrateSnowflakeColumnsToText(db) {
  const migrations = [
    {
      table: 'server_info',
      checkCol: 'guild_id',
      newSchema: `CREATE TABLE server_info_new (
        guild_id TEXT PRIMARY KEY,
        name TEXT,
        owner_id TEXT,
        created_at REAL,
        updated_at REAL
      );`,
      copySql: `INSERT OR IGNORE INTO server_info_new (guild_id, name, owner_id, created_at, updated_at)
        SELECT CAST(guild_id AS TEXT), name, CAST(owner_id AS TEXT), created_at, updated_at FROM server_info;`
    },
    {
      table: 'channel_settings',
      checkCol: 'channel_id',
      newSchema: `CREATE TABLE channel_settings_new (
        channel_id TEXT PRIMARY KEY,
        type TEXT,
        settings_json TEXT NOT NULL,
        updated_at REAL DEFAULT (strftime('%s', 'now'))
      );`,
      copySql: `INSERT OR IGNORE INTO channel_settings_new (channel_id, type, settings_json, updated_at)
        SELECT CAST(channel_id AS TEXT), type, settings_json, updated_at FROM channel_settings;`
    },
    {
      table: 'role_settings',
      checkCol: 'role_id',
      newSchema: `CREATE TABLE role_settings_new (
        role_id TEXT PRIMARY KEY,
        type TEXT,
        settings_json TEXT NOT NULL,
        updated_at REAL DEFAULT (strftime('%s', 'now'))
      );`,
      copySql: `INSERT OR IGNORE INTO role_settings_new (role_id, type, settings_json, updated_at)
        SELECT CAST(role_id AS TEXT), type, settings_json, updated_at FROM role_settings;`
    },
    {
      table: 'audit_logs',
      checkCol: 'actor_id',
      newSchema: `CREATE TABLE audit_logs_new (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        actor_id TEXT,
        target_id TEXT,
        details TEXT,
        timestamp REAL DEFAULT (strftime('%s', 'now'))
      );`,
      copySql: `INSERT OR IGNORE INTO audit_logs_new (log_id, action, actor_id, target_id, details, timestamp)
        SELECT log_id, action, CAST(actor_id AS TEXT), CAST(target_id AS TEXT), details, timestamp FROM audit_logs;`
    },
    {
      table: 'autorole',
      checkCol: 'guild_id',
      newSchema: `CREATE TABLE autorole_new (
        guild_id TEXT PRIMARY KEY,
        bots TEXT,
        humans TEXT
      );`,
      copySql: `INSERT OR IGNORE INTO autorole_new (guild_id, bots, humans)
        SELECT CAST(guild_id AS TEXT), bots, humans FROM autorole;`
    },
    {
      table: 'welcome_panel',
      checkCol: 'guild_id',
      newSchema: `CREATE TABLE welcome_panel_new (
        guild_id TEXT PRIMARY KEY,
        status INTEGER DEFAULT 0,
        channel_id TEXT DEFAULT '0',
        format TEXT DEFAULT 'Components V2',
        dm_enabled INTEGER DEFAULT 0,
        dm_message TEXT DEFAULT 'Default greeting',
        ping_mode TEXT DEFAULT 'NONE',
        auto_delete INTEGER DEFAULT 0,
        action_buttons INTEGER DEFAULT 0,
        cv2_title TEXT DEFAULT 'Default',
        cv2_description TEXT DEFAULT 'Default',
        cv2_thumbnail TEXT DEFAULT '{user.avatar}',
        cv2_banner TEXT DEFAULT 'None'
      );`,
      copySql: `INSERT OR IGNORE INTO welcome_panel_new (guild_id, status, channel_id, format, dm_enabled, dm_message, ping_mode, auto_delete, action_buttons, cv2_title, cv2_description, cv2_thumbnail, cv2_banner)
        SELECT CAST(guild_id AS TEXT), status, CAST(channel_id AS TEXT), format, dm_enabled, dm_message, ping_mode, auto_delete, action_buttons, cv2_title, cv2_description, cv2_thumbnail, cv2_banner FROM welcome_panel;`
    },
    {
      table: 'xk_onboarding_config',
      checkCol: 'guild_id',
      newSchema: `CREATE TABLE xk_onboarding_config_new (
        guild_id TEXT PRIMARY KEY,
        welcomedm_enabled INTEGER DEFAULT 0,
        welcomedm_text TEXT DEFAULT '',
        byemsg_enabled INTEGER DEFAULT 0,
        byemsg_text TEXT DEFAULT '',
        goodbye_channel_id TEXT DEFAULT '0',
        banner_url TEXT DEFAULT '',
        verify_question TEXT DEFAULT '',
        verify_answer TEXT DEFAULT '',
        newbie_role_id TEXT DEFAULT '0',
        newbie_period_seconds INTEGER DEFAULT 86400,
        intro_channel_id TEXT DEFAULT '0'
      );`,
      copySql: `INSERT OR IGNORE INTO xk_onboarding_config_new (guild_id, welcomedm_enabled, welcomedm_text, byemsg_enabled, byemsg_text, goodbye_channel_id, banner_url, verify_question, verify_answer, newbie_role_id, newbie_period_seconds, intro_channel_id)
        SELECT CAST(guild_id AS TEXT), welcomedm_enabled, welcomedm_text, byemsg_enabled, byemsg_text, CAST(goodbye_channel_id AS TEXT), banner_url, verify_question, verify_answer, CAST(newbie_role_id AS TEXT), newbie_period_seconds, CAST(intro_channel_id AS TEXT) FROM xk_onboarding_config;`
    },
    {
      table: 'economy_users',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE economy_users_new (
        user_id TEXT PRIMARY KEY,
        wallet INTEGER DEFAULT 0 CHECK (wallet >= 0),
        bank INTEGER DEFAULT 0 CHECK (bank >= 0),
        last_daily INTEGER DEFAULT 0
      );`,
      copySql: `INSERT OR IGNORE INTO economy_users_new (user_id, wallet, bank, last_daily)
        SELECT CAST(user_id AS TEXT), wallet, bank, last_daily FROM economy_users;`
    },
    {
      table: 'leveling_users',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE leveling_users_new (
        user_id TEXT PRIMARY KEY,
        xp INTEGER DEFAULT 0,
        level INTEGER DEFAULT 0,
        last_message_at INTEGER DEFAULT 0
      );`,
      copySql: `INSERT OR IGNORE INTO leveling_users_new (user_id, xp, level, last_message_at)
        SELECT CAST(user_id AS TEXT), xp, level, last_message_at FROM leveling_users;`
    },
    {
      table: 'user_settings',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE user_settings_new (
        user_id TEXT PRIMARY KEY,
        enabled INTEGER DEFAULT 1
      );`,
      copySql: `INSERT OR IGNORE INTO user_settings_new (user_id, enabled)
        SELECT CAST(user_id AS TEXT), enabled FROM user_settings;`
    },
    {
      table: 'user_afk',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE user_afk_new (
        user_id TEXT NOT NULL,
        guild_id TEXT NOT NULL,
        reason TEXT DEFAULT 'AFK',
        afk_time INTEGER NOT NULL,
        mentions_count INTEGER DEFAULT 0,
        dm_remind INTEGER DEFAULT 1,
        PRIMARY KEY (user_id, guild_id)
      );`,
      copySql: `INSERT OR IGNORE INTO user_afk_new (user_id, guild_id, reason, afk_time, mentions_count, dm_remind)
        SELECT CAST(user_id AS TEXT), CAST(guild_id AS TEXT), reason, afk_time, mentions_count, dm_remind FROM user_afk;`
    },
    {
      table: 'extraowners',
      checkCol: 'owner_id',
      newSchema: `CREATE TABLE extraowners_new (
        guild_id TEXT NOT NULL,
        owner_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, owner_id)
      );`,
      copySql: `INSERT OR IGNORE INTO extraowners_new (guild_id, owner_id)
        SELECT CAST(guild_id AS TEXT), CAST(owner_id AS TEXT) FROM extraowners;`
    },
    {
      table: 'whitelisted_users',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE whitelisted_users_new (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        actions_json TEXT DEFAULT '[]',
        PRIMARY KEY (guild_id, user_id)
      );`,
      copySql: `INSERT OR IGNORE INTO whitelisted_users_new (guild_id, user_id, actions_json)
        SELECT CAST(guild_id AS TEXT), CAST(user_id AS TEXT), actions_json FROM whitelisted_users;`
    },
    {
      table: 'whitelisted_roles',
      checkCol: 'role_id',
      newSchema: `CREATE TABLE whitelisted_roles_new (
        guild_id TEXT NOT NULL,
        role_id TEXT NOT NULL,
        actions_json TEXT DEFAULT '[]',
        PRIMARY KEY (guild_id, role_id)
      );`,
      copySql: `INSERT OR IGNORE INTO whitelisted_roles_new (guild_id, role_id, actions_json)
        SELECT CAST(guild_id AS TEXT), CAST(role_id AS TEXT), actions_json FROM whitelisted_roles;`
    },
    {
      table: 'home_voice_channels',
      checkCol: 'channel_id',
      newSchema: `CREATE TABLE home_voice_channels_new (
        guild_id TEXT PRIMARY KEY,
        channel_id TEXT NOT NULL,
        enabled INTEGER DEFAULT 1,
        status_text TEXT DEFAULT '',
        updated_at INTEGER NOT NULL
      );`,
      copySql: `INSERT OR IGNORE INTO home_voice_channels_new (guild_id, channel_id, enabled, status_text, updated_at)
        SELECT CAST(guild_id AS TEXT), CAST(channel_id AS TEXT), enabled, status_text, updated_at FROM home_voice_channels;`
    },
    {
      table: 'voice_rooms',
      checkCol: 'room_id',
      newSchema: `CREATE TABLE voice_rooms_new (
        room_id TEXT PRIMARY KEY,
        guild_id TEXT NOT NULL,
        owner_id TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        user_limit INTEGER DEFAULT 0,
        is_locked INTEGER DEFAULT 0,
        is_hidden INTEGER DEFAULT 0
      );`,
      copySql: `INSERT OR IGNORE INTO voice_rooms_new (room_id, guild_id, owner_id, created_at, user_limit, is_locked, is_hidden)
        SELECT CAST(room_id AS TEXT), CAST(guild_id AS TEXT), CAST(owner_id AS TEXT), created_at, user_limit, is_locked, is_hidden FROM voice_rooms;`
    },
    {
      table: 'bot_owners',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE bot_owners_new (
        user_id TEXT PRIMARY KEY,
        added_at INTEGER NOT NULL,
        added_by TEXT NOT NULL
      );`,
      copySql: `INSERT OR IGNORE INTO bot_owners_new (user_id, added_at, added_by)
        SELECT CAST(user_id AS TEXT), added_at, added_by FROM bot_owners;`
    },
    {
      table: 'blacklist_users',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE blacklist_users_new (
        user_id TEXT PRIMARY KEY,
        reason TEXT,
        added_at INTEGER NOT NULL,
        added_by TEXT NOT NULL
      );`,
      copySql: `INSERT OR IGNORE INTO blacklist_users_new (user_id, reason, added_at, added_by)
        SELECT CAST(user_id AS TEXT), reason, added_at, added_by FROM blacklist_users;`
    },
    {
      table: 'blacklist_guilds',
      checkCol: 'guild_id',
      newSchema: `CREATE TABLE blacklist_guilds_new (
        guild_id TEXT PRIMARY KEY,
        reason TEXT,
        added_at INTEGER NOT NULL,
        added_by TEXT NOT NULL
      );`,
      copySql: `INSERT OR IGNORE INTO blacklist_guilds_new (guild_id, reason, added_at, added_by)
        SELECT CAST(guild_id AS TEXT), reason, added_at, added_by FROM blacklist_guilds;`
    },
    {
      table: 'prefix',
      checkCol: 'guild_id',
      newSchema: `CREATE TABLE prefix_new (
        guild_id TEXT PRIMARY KEY,
        prefix TEXT NOT NULL
      );`,
      copySql: `INSERT OR IGNORE INTO prefix_new (guild_id, prefix)
        SELECT CAST(guild_id AS TEXT), prefix FROM prefix;`
    },
    {
      table: 'blacklist',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE blacklist_new (
        user_id TEXT PRIMARY KEY
      );`,
      copySql: `INSERT OR IGNORE INTO blacklist_new (user_id)
        SELECT CAST(user_id AS TEXT) FROM blacklist;`
    },
    {
      table: 'guild_blacklist',
      checkCol: 'guild_id',
      newSchema: `CREATE TABLE guild_blacklist_new (
        guild_id TEXT PRIMARY KEY
      );`,
      copySql: `INSERT OR IGNORE INTO guild_blacklist_new (guild_id)
        SELECT CAST(guild_id AS TEXT) FROM guild_blacklist;`
    },
    {
      table: 'ignore',
      checkCol: 'channel_id',
      newSchema: `CREATE TABLE ignore_new (
        channel_id TEXT PRIMARY KEY,
        added_at INTEGER DEFAULT (strftime('%s', 'now'))
      );`,
      copySql: `INSERT OR IGNORE INTO ignore_new (channel_id, added_at)
        SELECT CAST(channel_id AS TEXT), added_at FROM ignore;`
    },
    {
      table: 'np_managers',
      checkCol: 'user_id',
      newSchema: `CREATE TABLE np_managers_new (
        user_id TEXT PRIMARY KEY,
        added_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
        added_by TEXT NOT NULL DEFAULT 'system'
      );`,
      copySql: `INSERT OR IGNORE INTO np_managers_new (user_id)
        SELECT CAST(user_id AS TEXT) FROM np_managers;`
    }
  ];

  for (const m of migrations) {
    try {
      const info = db.prepare(`PRAGMA table_info("${m.table}")`).all();
      if (!info || info.length === 0) continue;
      const col = info.find(c => c.name === m.checkCol);
      if (col && (col.type.toUpperCase() === 'INTEGER' || col.type.toUpperCase() !== 'TEXT')) {
        db.exec(`
          ${m.newSchema}
          ${m.copySql}
          DROP TABLE "${m.table}";
          ALTER TABLE "${m.table}_new" RENAME TO "${m.table}";
        `);
      }
    } catch (e) {
      // Ignore migration error if already migrated or table empty
    }
  }
}

/**
 * Executes ordered migrations tracked by SQLite PRAGMA user_version inside transactions.
 */
function applyVersionedMigrations(db, migrations = [], dbName = 'database') {
  let currentVersion = 0;
  try {
    const row = db.prepare('PRAGMA user_version').get();
    if (row && typeof row.user_version !== 'undefined') {
      currentVersion = Number(row.user_version);
    }
  } catch (e) {}

  if (currentVersion < migrations.length) {
    for (let i = currentVersion; i < migrations.length; i++) {
      const targetVersion = i + 1;
      const migration = migrations[i];
      try {
        const tx = db.transaction(() => {
          if (typeof migration === 'function') {
            migration(db);
          } else if (typeof migration === 'string' && migration.trim()) {
            db.exec(migration);
          }
          db.exec(`PRAGMA user_version = ${targetVersion}`);
        });
        tx();
      } catch (mErr) {
        console.error(`[DB Migration] Failed to apply migration v${targetVersion} to ${dbName}:`, mErr);
        throw mErr;
      }
    }
  }
}

const MASTER_MIGRATIONS = [
  (db) => {
    // v1: Core master schema verification
  },
  (db) => {
    // v2: Task scheduler queue & index
    db.exec(`
      CREATE TABLE IF NOT EXISTS scheduled_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT,
        kind TEXT NOT NULL,
        run_at INTEGER NOT NULL,
        payload TEXT NOT NULL,
        done INTEGER DEFAULT 0
      );
      CREATE INDEX IF NOT EXISTS idx_tasks_due ON scheduled_tasks(done, run_at);
    `);
  },
  (db) => {
    // v3: Snowflake column text enforcement
    migrateSnowflakeColumnsToText(db);
  },
  (db) => {
    // v4: Drop legacy purged premium tables (Review #4 / 2.4)
    db.exec(`
      DROP TABLE IF EXISTS premium_guilds;
      DROP TABLE IF EXISTS premium_keys;
      DROP TABLE IF EXISTS premium_managers;
      DROP TABLE IF EXISTS premium_managers_new;
    `);
  },
  (db) => {
    // v5: Slice 4.1 Master user_profiles schema
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS user_profiles (
          user_id TEXT PRIMARY KEY,
          bio TEXT DEFAULT 'No bio set.',
          accent_color TEXT DEFAULT '#5865F2',
          created_at INTEGER DEFAULT (strftime('%s', 'now'))
        );
      `);
      try { db.exec("ALTER TABLE user_profiles ADD COLUMN accent_color TEXT DEFAULT '#5865F2';"); } catch (e) {}
      try { db.exec("ALTER TABLE user_profiles ADD COLUMN created_at INTEGER DEFAULT (strftime('%s', 'now'));"); } catch (e) {}
    } catch (e) {}
  }
];

const GUILD_MIGRATIONS = [
  (db) => {
    // v1: Core guild tables
  },
  (db) => {
    // v2: Economy constraints
    try {
      db.exec(`CREATE TABLE IF NOT EXISTS economy_users (
        user_id TEXT PRIMARY KEY,
        wallet INTEGER DEFAULT 0 CHECK (wallet >= 0),
        bank INTEGER DEFAULT 0 CHECK (bank >= 0)
      );`);
    } catch (e) {}
  },
  (db) => {
    // v3: Snowflake column text enforcement
    migrateSnowflakeColumnsToText(db);
  },
  (db) => {
    // v4: Extended features (voice activity, templates, applications, expanded economy)
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS voice_activity (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          total_seconds INTEGER DEFAULT 0,
          daily_seconds INTEGER DEFAULT 0,
          weekly_seconds INTEGER DEFAULT 0,
          monthly_seconds INTEGER DEFAULT 0,
          last_joined INTEGER DEFAULT 0,
          updated_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS voice_roles (
          guild_id TEXT NOT NULL,
          required_seconds INTEGER NOT NULL,
          role_id TEXT NOT NULL,
          PRIMARY KEY (guild_id, required_seconds)
        );
        CREATE TABLE IF NOT EXISTS server_templates (
          id TEXT PRIMARY KEY,
          guild_id TEXT NOT NULL,
          creator_id TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          data_json TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS applications_config (
          guild_id TEXT PRIMARY KEY,
          channel_id TEXT,
          log_channel_id TEXT,
          questions_json TEXT,
          enabled INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS applications_submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          answers_json TEXT NOT NULL,
          status TEXT DEFAULT 'pending',
          reviewer_id TEXT,
          reason TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS eco_user_stocks (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          symbol TEXT NOT NULL,
          shares INTEGER DEFAULT 0,
          avg_buy_price REAL DEFAULT 0,
          PRIMARY KEY (guild_id, user_id, symbol)
        );
        CREATE TABLE IF NOT EXISTS eco_properties (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          property_id TEXT NOT NULL,
          purchased_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, user_id, property_id)
        );
        CREATE TABLE IF NOT EXISTS eco_jobs (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          job_id TEXT NOT NULL,
          salary INTEGER NOT NULL,
          level INTEGER DEFAULT 1,
          last_worked INTEGER DEFAULT 0,
          PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS eco_loans (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          amount INTEGER NOT NULL,
          due_date INTEGER NOT NULL,
          interest_rate REAL NOT NULL,
          PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS eco_user_stats (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          bank_capacity INTEGER DEFAULT 50000,
          fish_count INTEGER DEFAULT 0,
          hunt_count INTEGER DEFAULT 0,
          crime_count INTEGER DEFAULT 0,
          jail_until INTEGER DEFAULT 0,
          PRIMARY KEY (guild_id, user_id)
        );
      `);
    } catch (e) {}
  },
  (db) => {
    // v5: Economy extra columns (last_beg, last_monthly)
    try {
      db.exec('ALTER TABLE economy_users ADD COLUMN last_beg INTEGER DEFAULT 0;');
    } catch (e) {}
    try {
      db.exec('ALTER TABLE economy_users ADD COLUMN last_monthly INTEGER DEFAULT 0;');
    } catch (e) {}
  },
  (db) => {
    // v6: Moderation policies and macros
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS moderation_policies (
          guild_id TEXT,
          name TEXT,
          config_json TEXT,
          created_by TEXT,
          created_at INTEGER,
          PRIMARY KEY (guild_id, name)
        );
        CREATE TABLE IF NOT EXISTS mod_macros (
          guild_id TEXT,
          name TEXT,
          steps_json TEXT,
          required_permission TEXT,
          created_by TEXT,
          created_at INTEGER,
          PRIMARY KEY (guild_id, name)
        );
        CREATE INDEX IF NOT EXISTS idx_mod_policies_guild ON moderation_policies (guild_id);
        CREATE INDEX IF NOT EXISTS idx_mod_macros_guild ON mod_macros (guild_id);
      `);
    } catch (e) {}
  },
  (db) => {
    // v7: Automation Pack 2 (Tags, Custom Commands v2, Workflow Engine)
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS guild_tags (
          guild_id TEXT NOT NULL,
          name TEXT NOT NULL,
          aliases_json TEXT DEFAULT '[]',
          content TEXT NOT NULL,
          author_id TEXT NOT NULL,
          uses INTEGER DEFAULT 0,
          created_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, name)
        );
        CREATE INDEX IF NOT EXISTS idx_guild_tags ON guild_tags(guild_id, name);

        CREATE TABLE IF NOT EXISTS guild_workflows (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id TEXT NOT NULL,
          name TEXT NOT NULL,
          trigger_type TEXT NOT NULL,
          trigger_config_json TEXT NOT NULL DEFAULT '{}',
          actions_json TEXT NOT NULL DEFAULT '[]',
          enabled INTEGER DEFAULT 1,
          run_count INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_guild_workflows ON guild_workflows(guild_id, trigger_type, enabled);
      `);
    } catch (e) {}

    try { db.exec("ALTER TABLE custom_commands ADD COLUMN trigger_type TEXT DEFAULT 'exact';"); } catch (e) {}
    try { db.exec("ALTER TABLE custom_commands ADD COLUMN response_type TEXT DEFAULT 'text';"); } catch (e) {}
    try { db.exec("ALTER TABLE custom_commands ADD COLUMN response_data TEXT DEFAULT NULL;"); } catch (e) {}
    try { db.exec("ALTER TABLE custom_commands ADD COLUMN uses INTEGER DEFAULT 0;"); } catch (e) {}
    try { db.exec("ALTER TABLE custom_commands ADD COLUMN last_used INTEGER DEFAULT 0;"); } catch (e) {}
  },
  (db) => {
    // v8: Slice 4.3 (Achievements & Badges) and Slice 4.4 (Quests & Daily Challenges)
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS user_achievements (
          user_id TEXT NOT NULL,
          guild_id TEXT NOT NULL,
          badge_id TEXT NOT NULL,
          earned_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, user_id, badge_id)
        );
        CREATE INDEX IF NOT EXISTS idx_user_achievements_uid ON user_achievements(guild_id, user_id);
        CREATE INDEX IF NOT EXISTS idx_user_achievements_bid ON user_achievements(guild_id, badge_id);

        CREATE TABLE IF NOT EXISTS guild_badges (
          guild_id TEXT NOT NULL,
          badge_id TEXT NOT NULL,
          name TEXT NOT NULL,
          emoji TEXT NOT NULL,
          description TEXT,
          PRIMARY KEY (guild_id, badge_id)
        );

        CREATE TABLE IF NOT EXISTS user_quests (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          date TEXT NOT NULL,
          quests_json TEXT NOT NULL,
          PRIMARY KEY (guild_id, user_id, date)
        );
        CREATE INDEX IF NOT EXISTS idx_user_quests_user ON user_quests(guild_id, user_id);

        CREATE TABLE IF NOT EXISTS quest_streaks (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          streak INTEGER DEFAULT 0,
          last_completed TEXT,
          PRIMARY KEY (guild_id, user_id)
        );
      `);
    } catch (e) {}
  },
  (db) => {
    // v9: Slice 4.5 (Clans & Groups) and Slice 4.6 (Marriage & Social Relationships)
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS clans (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id TEXT NOT NULL,
          name TEXT NOT NULL,
          tag TEXT NOT NULL,
          leader_id TEXT NOT NULL,
          description TEXT,
          xp INTEGER DEFAULT 0,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_clans_guild ON clans(guild_id);
        CREATE INDEX IF NOT EXISTS idx_clans_leader ON clans(guild_id, leader_id);

        CREATE TABLE IF NOT EXISTS clan_members (
          clan_id INTEGER NOT NULL,
          user_id TEXT NOT NULL,
          joined_at INTEGER NOT NULL,
          PRIMARY KEY (clan_id, user_id)
        );
        CREATE INDEX IF NOT EXISTS idx_clan_members_user ON clan_members(user_id);

        CREATE TABLE IF NOT EXISTS clan_wars (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id TEXT NOT NULL,
          challenger_id INTEGER NOT NULL,
          defender_id INTEGER NOT NULL,
          started_at INTEGER NOT NULL,
          ends_at INTEGER NOT NULL,
          result_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_clan_wars_guild ON clan_wars(guild_id);
        CREATE INDEX IF NOT EXISTS idx_clan_wars_active ON clan_wars(guild_id, ends_at);

        CREATE TABLE IF NOT EXISTS marriages (
          guild_id TEXT NOT NULL,
          user1_id TEXT NOT NULL,
          user2_id TEXT NOT NULL,
          married_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, user1_id, user2_id)
        );
        CREATE INDEX IF NOT EXISTS idx_marriages_u1 ON marriages(guild_id, user1_id);
        CREATE INDEX IF NOT EXISTS idx_marriages_u2 ON marriages(guild_id, user2_id);

        CREATE TABLE IF NOT EXISTS divorce_cooldowns (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          until INTEGER NOT NULL,
          PRIMARY KEY (guild_id, user_id)
        );
      `);
    } catch (e) {}
  },
  (db) => {
    // v10: Moderation Watchlist Surveillance
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS watchlist (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          reason TEXT,
          added_by TEXT NOT NULL,
          added_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, user_id)
        );
        CREATE INDEX IF NOT EXISTS idx_watchlist_guild_user ON watchlist(guild_id, user_id);
      `);
    } catch (e) {}
  },
  (db) => {
    // v11: Slice 6.3 Command Overrides
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS command_overrides (
          guild_id TEXT NOT NULL,
          command TEXT NOT NULL,
          type TEXT NOT NULL,
          target_type TEXT NOT NULL,
          target_id TEXT NOT NULL,
          created_at INTEGER DEFAULT (strftime('%s', 'now')),
          PRIMARY KEY (guild_id, command, target_type, target_id)
        );
        CREATE INDEX IF NOT EXISTS idx_cmd_overrides_lookup ON command_overrides(guild_id, command);
      `);
    } catch (e) {}
  },
  (db) => {
    // v12: Reputation System (Slice 4.2)
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS reputation (
          guild_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          score INTEGER DEFAULT 0,
          PRIMARY KEY (guild_id, user_id)
        );
        CREATE INDEX IF NOT EXISTS idx_reputation_guild_score ON reputation(guild_id, score DESC);

        CREATE TABLE IF NOT EXISTS rep_given (
          guild_id TEXT NOT NULL,
          giver_id TEXT NOT NULL,
          receiver_id TEXT NOT NULL,
          given_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, giver_id, receiver_id)
        );
        CREATE INDEX IF NOT EXISTS idx_rep_given_time ON rep_given(guild_id, giver_id, receiver_id, given_at);
      `);
    } catch (e) {}
  },
  (db) => {
    // v13: Database Hardening (Composite indexes & extraowners metadata)
    try {
      db.exec("ALTER TABLE extraowners ADD COLUMN added_by TEXT DEFAULT 'unknown';");
    } catch (e) {}
    try {
      db.exec("ALTER TABLE extraowners ADD COLUMN added_at INTEGER DEFAULT 0;");
    } catch (e) {}

    try {
      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_whitelisted_users_guild_user ON whitelisted_users (guild_id, user_id);
        CREATE INDEX IF NOT EXISTS idx_whitelisted_roles_guild_role ON whitelisted_roles (guild_id, role_id);
        CREATE INDEX IF NOT EXISTS idx_whitelisted_channels_guild_chan ON whitelisted_channels (guild_id, channel_id);
        CREATE INDEX IF NOT EXISTS idx_extraowners_guild_owner ON extraowners (guild_id, owner_id);
        CREATE INDEX IF NOT EXISTS idx_antinuke_rules_guild_vector ON antinuke_rules (guild_id, vector);
        CREATE INDEX IF NOT EXISTS idx_automod_strikes_guild_user ON automod_strikes (guild_id, user_id);
        CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs (timestamp);
        CREATE INDEX IF NOT EXISTS idx_audit_logs_actor ON audit_logs (actor_id);
        CREATE INDEX IF NOT EXISTS idx_quarantined_users_guild_user ON quarantined_users (guild_id, user_id);
      `);
    } catch (e) {}
  },
  (db) => {
    // v14: One-time migration of legacy server_settings.whitelist into whitelisted_users
    try {
      const row = db.prepare("SELECT value FROM server_settings WHERE key = 'whitelist'").get();
      if (row && row.value) {
        let arr = [];
        try { arr = typeof row.value === 'string' ? JSON.parse(row.value) : row.value; } catch (_) {}
        if (Array.isArray(arr) && arr.length > 0) {
          const guildRow = db.prepare("SELECT guild_id FROM server_info LIMIT 1").get();
          const gid = guildRow?.guild_id || '';
          if (gid) {
            const now = Math.floor(Date.now() / 1000);
            for (const uid of arr) {
              if (uid && typeof uid === 'string') {
                const exists = db.prepare("SELECT 1 FROM whitelisted_users WHERE guild_id = ? AND user_id = ?").get(gid, uid);
                if (!exists) {
                  db.prepare("INSERT INTO whitelisted_users (guild_id, user_id, action, added_by) VALUES (?, ?, 'all', 'legacy_import')").run(gid, uid);
                  db.prepare("INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, 'user', ?, 'all', 'legacy_import', 'legacy_migration', ?)").run(gid, uid, now);
                }
              }
            }
          }
        }
      }
    } catch (e) {}
  },
  (db) => {
    // Migration: antinuke incidents schema expansion for audit_logs
    try {
      const cols = db.prepare("PRAGMA table_info(audit_logs)").all().map(c => c.name);
      if (!cols.includes('guild_id')) db.exec("ALTER TABLE audit_logs ADD COLUMN guild_id TEXT");
      if (!cols.includes('user_id')) db.exec("ALTER TABLE audit_logs ADD COLUMN user_id TEXT");
      if (!cols.includes('reason')) db.exec("ALTER TABLE audit_logs ADD COLUMN reason TEXT");
      if (!cols.includes('created_at')) db.exec("ALTER TABLE audit_logs ADD COLUMN created_at REAL DEFAULT (strftime('%s', 'now'))");
    } catch (e) {}
  },
  (db) => {
    // v16: Automod Consolidation - Unified automod_rules schema
    try {
      const cols = db.prepare("PRAGMA table_info(automod_rules)").all().map(c => c.name);
      if (!cols.includes('rule_id')) db.exec("ALTER TABLE automod_rules ADD COLUMN rule_id TEXT");
      if (!cols.includes('filter_type')) db.exec("ALTER TABLE automod_rules ADD COLUMN filter_type TEXT");
      if (!cols.includes('limit_count')) db.exec("ALTER TABLE automod_rules ADD COLUMN limit_count INTEGER DEFAULT 0");
      if (!cols.includes('time_window')) db.exec("ALTER TABLE automod_rules ADD COLUMN time_window INTEGER DEFAULT 0");
      if (!cols.includes('strike_weight')) db.exec("ALTER TABLE automod_rules ADD COLUMN strike_weight INTEGER DEFAULT 1");
      if (!cols.includes('exemptions')) db.exec("ALTER TABLE automod_rules ADD COLUMN exemptions TEXT DEFAULT '[]'");
      if (!cols.includes('log_channel')) db.exec("ALTER TABLE automod_rules ADD COLUMN log_channel TEXT");

      db.exec(`
        UPDATE automod_rules
        SET rule_id = COALESCE(rule_id, rule_name),
            filter_type = COALESCE(filter_type, rule_name)
        WHERE rule_id IS NULL OR filter_type IS NULL;
        CREATE INDEX IF NOT EXISTS idx_automod_rules_guild_filter ON automod_rules (guild_id, filter_type);
        CREATE INDEX IF NOT EXISTS idx_automod_rules_guild_rule ON automod_rules (guild_id, rule_id);
      `);
    } catch (e) {}
  },
  (db) => {
    // v17: Jail system and Media-only channels
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS jail_config (
          guild_id TEXT PRIMARY KEY,
          role_id TEXT,
          channel_id TEXT
        );
        CREATE TABLE IF NOT EXISTS jailed_users (
          guild_id TEXT,
          user_id TEXT PRIMARY KEY,
          saved_roles TEXT,
          jailed_at INTEGER,
          reason TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_jailed_users_guild ON jailed_users (guild_id);

        CREATE TABLE IF NOT EXISTS media_channels (
          guild_id TEXT,
          channel_id TEXT,
          added_by TEXT,
          added_at INTEGER,
          PRIMARY KEY (guild_id, channel_id)
        );
        CREATE INDEX IF NOT EXISTS idx_media_channels_guild ON media_channels (guild_id);

        CREATE TABLE IF NOT EXISTS media_bypass_roles (
          guild_id TEXT,
          role_id TEXT,
          added_by TEXT,
          added_at INTEGER,
          PRIMARY KEY (guild_id, role_id)
        );
        CREATE INDEX IF NOT EXISTS idx_media_bypass_roles_guild ON media_bypass_roles (guild_id);
      `);
    } catch (e) {}
  },
  (db) => {
    // v18: Antinuke channel & role snapshots persistence and baseline server identity
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS channel_snapshots (
          guild_id TEXT NOT NULL,
          channel_id TEXT NOT NULL,
          data TEXT NOT NULL,
          updated_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, channel_id)
        );
        CREATE INDEX IF NOT EXISTS idx_channel_snapshots_guild ON channel_snapshots (guild_id);

        CREATE TABLE IF NOT EXISTS role_snapshots (
          guild_id TEXT NOT NULL,
          role_id TEXT NOT NULL,
          data TEXT NOT NULL,
          updated_at INTEGER NOT NULL,
          PRIMARY KEY (guild_id, role_id)
        );
        CREATE INDEX IF NOT EXISTS idx_role_snapshots_guild ON role_snapshots (guild_id);

        CREATE TABLE IF NOT EXISTS server_baseline_identity (
          guild_id TEXT PRIMARY KEY,
          name TEXT,
          icon_url TEXT,
          icon_base64 TEXT,
          banner_url TEXT,
          banner_base64 TEXT,
          verification_level INTEGER,
          updated_at INTEGER NOT NULL
        );
      `);
    } catch (e) {}
  }
];

function ensureServerDatabase(guildId, guildName = '', ownerId = '0', ignoreIfExists = true) {
  const gid = String(guildId);
  if (!gid || gid === 'undefined' || gid === 'null') return '';
  // Ghost folder guard: only permit numeric snowflakes (or isolated test suites)
  if (!validateSnowflake(gid) && !gid.includes('test')) {
    return '';
  }
  const inCloud = isMongoCloudMode();
  const serverDir = getServerDir(gid);
  const dbPath = getServerDbPath(gid);
  const metaPath = path.join(serverDir, 'metadata.json');

  if (_INITIALIZED_SERVERS.has(gid) && serverFolderExists(gid)) {
    return dbPath;
  }

  if (!inCloud && !fs.existsSync(serverDir)) {
    fs.mkdirSync(serverDir, { recursive: true });
  }

  // Reuse cached connection handle if available
  let db;
  let closeAfterInit = false;
  if (_DB_CACHE.has(gid)) {
    db = _DB_CACHE.get(gid);
  } else {
    db = openDatabase(inCloud ? ':memory:' : dbPath);
    _DB_CACHE.set(gid, db);
    _HANDLE_TIMESTAMPS.set(gid, Date.now());
  }

  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS server_info (
        guild_id TEXT PRIMARY KEY,
        name TEXT,
        owner_id TEXT,
        created_at REAL,
        updated_at REAL
      );

      CREATE TABLE IF NOT EXISTS server_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at REAL DEFAULT (strftime('%s', 'now'))
      );

      CREATE TABLE IF NOT EXISTS settings_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT,
        key TEXT NOT NULL,
        old_val TEXT,
        new_val TEXT,
        actor_id TEXT NOT NULL,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS channel_settings (
        channel_id TEXT PRIMARY KEY,
        type TEXT,
        settings_json TEXT NOT NULL,
        updated_at REAL DEFAULT (strftime('%s', 'now'))
      );

      CREATE TABLE IF NOT EXISTS role_settings (
        role_id TEXT PRIMARY KEY,
        type TEXT,
        settings_json TEXT NOT NULL,
        updated_at REAL DEFAULT (strftime('%s', 'now'))
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT,
        user_id TEXT,
        action TEXT NOT NULL,
        actor_id TEXT,
        target_id TEXT,
        reason TEXT,
        details TEXT,
        created_at REAL DEFAULT (strftime('%s', 'now')),
        timestamp REAL DEFAULT (strftime('%s', 'now'))
      );

      CREATE TABLE IF NOT EXISTS autorole (
        guild_id TEXT PRIMARY KEY,
        bots TEXT,
        humans TEXT
      );

      CREATE TABLE IF NOT EXISTS user_settings (
        user_id TEXT PRIMARY KEY,
        enabled INTEGER DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS blocked_senders (
        user_id TEXT NOT NULL,
        sender_id TEXT NOT NULL,
        PRIMARY KEY (user_id, sender_id)
      );

      CREATE TABLE IF NOT EXISTS blocked_guilds (
        user_id TEXT NOT NULL,
        guild_id TEXT NOT NULL,
        PRIMARY KEY (user_id, guild_id)
      );

      CREATE TABLE IF NOT EXISTS welcome_panel (
        guild_id TEXT PRIMARY KEY,
        status INTEGER DEFAULT 0,
        channel_id TEXT DEFAULT '0',
        format TEXT DEFAULT 'Components V2',
        dm_enabled INTEGER DEFAULT 0,
        dm_message TEXT DEFAULT 'Default greeting',
        ping_mode TEXT DEFAULT 'NONE',
        auto_delete INTEGER DEFAULT 0,
        action_buttons INTEGER DEFAULT 0,
        cv2_title TEXT DEFAULT 'Default',
        cv2_description TEXT DEFAULT 'Default',
        cv2_thumbnail TEXT DEFAULT '{user.avatar}',
        cv2_banner TEXT DEFAULT 'None'
      );

      CREATE TABLE IF NOT EXISTS xk_onboarding_config (
        guild_id TEXT PRIMARY KEY,
        welcomedm_enabled INTEGER DEFAULT 0,
        welcomedm_text TEXT DEFAULT '',
        byemsg_enabled INTEGER DEFAULT 0,
        byemsg_text TEXT DEFAULT '',
        goodbye_channel_id TEXT DEFAULT '0',
        banner_url TEXT DEFAULT '',
        verify_question TEXT DEFAULT '',
        verify_answer TEXT DEFAULT '',
        newbie_role_id TEXT DEFAULT '0',
        newbie_period_seconds INTEGER DEFAULT 86400,
        intro_channel_id TEXT DEFAULT '0'
      );

      CREATE TABLE IF NOT EXISTS economy_users (
        user_id TEXT PRIMARY KEY,
        wallet INTEGER DEFAULT 0 CHECK (wallet >= 0),
        bank INTEGER DEFAULT 0 CHECK (bank >= 0),
        last_daily INTEGER DEFAULT 0,
        last_beg INTEGER DEFAULT 0,
        last_monthly INTEGER DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS member_warnings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        moderator_id TEXT NOT NULL,
        reason TEXT,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS server_giveaways (
        message_id TEXT PRIMARY KEY,
        channel_id TEXT NOT NULL,
        prize TEXT NOT NULL,
        winners_count INTEGER NOT NULL,
        ends_at INTEGER NOT NULL,
        host_id TEXT NOT NULL,
        ended INTEGER DEFAULT 0,
        required_role_id TEXT DEFAULT NULL,
        min_level INTEGER DEFAULT 0,
        min_server_age INTEGER DEFAULT 0,
        paused INTEGER DEFAULT 0,
        pause_remaining_ms INTEGER DEFAULT NULL
      );

      CREATE TABLE IF NOT EXISTS server_giveaway_entries (
        message_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        entered_at INTEGER NOT NULL,
        PRIMARY KEY (message_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS leveling_roles (
        guild_id TEXT NOT NULL,
        level INTEGER NOT NULL,
        role_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, level)
      );

      CREATE TABLE IF NOT EXISTS leveling_ignored (
        guild_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        type TEXT NOT NULL,
        PRIMARY KEY (guild_id, target_id)
      );

      CREATE TABLE IF NOT EXISTS leveling_multipliers (
        guild_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        type TEXT NOT NULL,
        multiplier REAL NOT NULL,
        PRIMARY KEY (guild_id, target_id)
      );

      CREATE TABLE IF NOT EXISTS economy_shop_items (
        item_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        price INTEGER NOT NULL,
        type TEXT NOT NULL,
        role_id TEXT DEFAULT NULL,
        max_per_user INTEGER DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS economy_inventory (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        item_id TEXT NOT NULL,
        quantity INTEGER DEFAULT 1,
        updated_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, user_id, item_id)
      );

      CREATE TABLE IF NOT EXISTS server_tickets (
        channel_id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        guild_id TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        status TEXT DEFAULT 'open',
        category TEXT DEFAULT 'general',
        claimed_by TEXT DEFAULT NULL,
        last_activity INTEGER DEFAULT 0,
        closed_at INTEGER DEFAULT NULL
      );

      CREATE TABLE IF NOT EXISTS server_ticket_categories (
        guild_id TEXT NOT NULL,
        category_id TEXT NOT NULL,
        name TEXT NOT NULL,
        staff_role_id TEXT,
        questions TEXT,
        PRIMARY KEY (guild_id, category_id)
      );

      CREATE TABLE IF NOT EXISTS server_backups (
        backup_id TEXT PRIMARY KEY,
        guild_id TEXT NOT NULL,
        name TEXT NOT NULL,
        creator_id TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        snapshot_json TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS autoresponders (
        guild_id TEXT NOT NULL,
        trigger_word TEXT NOT NULL,
        response_text TEXT NOT NULL,
        creator_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, trigger_word)
      );

      CREATE TABLE IF NOT EXISTS autoreactions (
        guild_id TEXT NOT NULL,
        trigger_word TEXT NOT NULL,
        emoji TEXT NOT NULL,
        PRIMARY KEY (guild_id, trigger_word)
      );

      CREATE TABLE IF NOT EXISTS user_settings (
        user_id TEXT PRIMARY KEY,
        enabled INTEGER DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS blocked_senders (
        user_id TEXT NOT NULL,
        sender_id TEXT NOT NULL,
        PRIMARY KEY (user_id, sender_id)
      );

      CREATE TABLE IF NOT EXISTS blocked_guilds (
        user_id TEXT NOT NULL,
        guild_id TEXT NOT NULL,
        PRIMARY KEY (user_id, guild_id)
      );

      CREATE TABLE IF NOT EXISTS user_afk (
        user_id TEXT NOT NULL,
        guild_id TEXT NOT NULL,
        reason TEXT DEFAULT 'AFK',
        afk_time INTEGER NOT NULL,
        mentions_count INTEGER DEFAULT 0,
        dm_remind INTEGER DEFAULT 1,
        PRIMARY KEY (user_id, guild_id)
      );

      CREATE TABLE IF NOT EXISTS extraowners (
        guild_id TEXT NOT NULL,
        owner_id TEXT NOT NULL,
        added_by TEXT DEFAULT 'unknown',
        added_at INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, owner_id)
      );

      CREATE TABLE IF NOT EXISTS guild_noprefix_access (
        guild_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        is_role INTEGER DEFAULT 0,
        added_by TEXT NOT NULL,
        added_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, target_id)
      );

      CREATE TABLE IF NOT EXISTS whitelisted_users (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        action TEXT DEFAULT 'all',
        expires_at INTEGER DEFAULT NULL,
        added_by TEXT DEFAULT NULL,
        PRIMARY KEY (guild_id, user_id, action)
      );

      CREATE TABLE IF NOT EXISTS whitelisted_roles (
        guild_id TEXT NOT NULL,
        role_id TEXT NOT NULL,
        action TEXT DEFAULT 'all',
        expires_at INTEGER DEFAULT NULL,
        added_by TEXT DEFAULT NULL,
        PRIMARY KEY (guild_id, role_id, action)
      );

      CREATE TABLE IF NOT EXISTS whitelisted_channels (
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        scope TEXT DEFAULT 'all',
        added_by TEXT,
        added_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, channel_id, scope)
      );

      CREATE TABLE IF NOT EXISTS whitelist_audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        target_type TEXT NOT NULL,
        target_id TEXT NOT NULL,
        action_scope TEXT NOT NULL,
        operator_id TEXT NOT NULL,
        operation TEXT NOT NULL,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS cm_settings (
        guild_id TEXT PRIMARY KEY,
        category_id TEXT,
        timezone TEXT DEFAULT 'UTC'
      );

      CREATE TABLE IF NOT EXISTS cm_channels (
        guild_id TEXT NOT NULL,
        action TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, action)
      );

      CREATE TABLE IF NOT EXISTS cm_mappings (
        guild_id TEXT NOT NULL,
        action TEXT NOT NULL,
        target_type TEXT NOT NULL,
        target_id TEXT NOT NULL,
        daily_limit INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, action)
      );

      CREATE TABLE IF NOT EXISTS cm_usage (
        guild_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        action TEXT NOT NULL,
        usage_date TEXT NOT NULL,
        count INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, target_id, action, usage_date)
      );

      CREATE TABLE IF NOT EXISTS cm_filters (
        guild_id TEXT NOT NULL,
        word TEXT NOT NULL,
        added_by TEXT NOT NULL,
        added_at REAL NOT NULL,
        PRIMARY KEY (guild_id, word)
      );

      CREATE TABLE IF NOT EXISTS cm_autodelete_users (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        added_by TEXT NOT NULL,
        added_at REAL NOT NULL,
        reason TEXT,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS cm_defend (
        guild_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        enabled INTEGER DEFAULT 1,
        updated_by TEXT NOT NULL,
        updated_at REAL NOT NULL,
        PRIMARY KEY (guild_id, target_id)
      );

      CREATE TABLE IF NOT EXISTS antinuke_rules (
        guild_id TEXT NOT NULL,
        vector TEXT NOT NULL,
        enabled INTEGER DEFAULT 1,
        action TEXT DEFAULT 'ban',
        limit_count INTEGER DEFAULT 1,
        time_window INTEGER DEFAULT 10,
        auto_heal INTEGER DEFAULT 1,
        PRIMARY KEY (guild_id, vector)
      );

      CREATE TABLE IF NOT EXISTS server_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        name TEXT,
        created_by TEXT,
        created_at INTEGER NOT NULL,
        channels_data TEXT NOT NULL,
        roles_data TEXT NOT NULL,
        server_data TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS quarantined_users (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        quarantined_at INTEGER NOT NULL,
        quarantined_by TEXT NOT NULL,
        original_roles TEXT NOT NULL,
        reason TEXT,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS vanity_guard (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER DEFAULT 1,
        vanity_code TEXT,
        action TEXT DEFAULT 'ban',
        log_channel TEXT
      );

      CREATE TABLE IF NOT EXISTS nightmode (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER DEFAULT 0,
        start_time TEXT,
        end_time TEXT
      );

      CREATE TABLE IF NOT EXISTS sniped_messages (
        channel_id TEXT PRIMARY KEY,
        content TEXT,
        author_id TEXT,
        author_tag TEXT,
        timestamp INTEGER NOT NULL,
        attachments TEXT
      );

      CREATE TABLE IF NOT EXISTS verification_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER DEFAULT 0,
        role_id TEXT,
        channel_id TEXT,
        mode TEXT DEFAULT 'button',
        code TEXT
      );

      CREATE TABLE IF NOT EXISTS reaction_roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        emoji TEXT NOT NULL,
        role_id TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sticky_messages (
        channel_id TEXT PRIMARY KEY,
        guild_id TEXT NOT NULL,
        content TEXT NOT NULL,
        last_message_id TEXT
      );

      CREATE TABLE IF NOT EXISTS custom_commands (
        guild_id TEXT NOT NULL,
        name TEXT NOT NULL,
        content TEXT NOT NULL,
        created_by TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, name)
      );

      CREATE TABLE IF NOT EXISTS guild_tags (
        guild_id TEXT NOT NULL,
        name TEXT NOT NULL,
        aliases_json TEXT DEFAULT '[]',
        content TEXT NOT NULL,
        author_id TEXT NOT NULL,
        uses INTEGER DEFAULT 0,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, name)
      );
      CREATE INDEX IF NOT EXISTS idx_guild_tags ON guild_tags(guild_id, name);

      CREATE TABLE IF NOT EXISTS mod_cases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        case_num INTEGER NOT NULL,
        action TEXT NOT NULL,
        user_id TEXT NOT NULL,
        moderator_id TEXT NOT NULL,
        reason TEXT,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS staff_duty (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        on_duty INTEGER DEFAULT 0,
        started_at INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS user_profiles (
        user_id TEXT PRIMARY KEY,
        bio TEXT DEFAULT 'No bio set.',
        color TEXT DEFAULT '#5865F2',
        rep INTEGER DEFAULT 0,
        last_rep INTEGER DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS leveling_users (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        xp INTEGER DEFAULT 0,
        level INTEGER DEFAULT 0,
        last_xp_time INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS antiraid_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER DEFAULT 1,
        join_limit INTEGER DEFAULT 8,
        window_seconds INTEGER DEFAULT 10,
        action TEXT DEFAULT 'kick'
      );

      CREATE TABLE IF NOT EXISTS home_voice_channels (
        guild_id TEXT PRIMARY KEY,
        channel_id TEXT NOT NULL,
        status_text TEXT DEFAULT '24/7 Tungsten Node • Ping: {ping}ms',
        enabled INTEGER DEFAULT 1,
        reconnect_count INTEGER DEFAULT 0,
        updated_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS voice_rooms (
        channel_id TEXT PRIMARY KEY,
        owner_id TEXT NOT NULL,
        guild_id TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS auto_voice_panels (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS automod_strikes (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        strikes INTEGER DEFAULT 0,
        last_strike_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS automod_banned_words (
        guild_id TEXT NOT NULL,
        word TEXT NOT NULL,
        added_by TEXT,
        added_at INTEGER NOT NULL,
        is_wildcard INTEGER DEFAULT 1,
        PRIMARY KEY (guild_id, word)
      );

      CREATE TABLE IF NOT EXISTS automod_allowed_domains (
        guild_id TEXT NOT NULL,
        domain TEXT NOT NULL,
        added_by TEXT,
        added_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, domain)
      );

      CREATE TABLE IF NOT EXISTS automod_bypasses (
        guild_id TEXT NOT NULL,
        target_type TEXT NOT NULL,
        target_id TEXT NOT NULL,
        filter_key TEXT DEFAULT 'all',
        added_by TEXT,
        added_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, target_type, target_id, filter_key)
      );

      CREATE TABLE IF NOT EXISTS automod_rules (
        rule_id TEXT,
        guild_id TEXT NOT NULL,
        filter_type TEXT NOT NULL,
        enabled INTEGER DEFAULT 0,
        limit_count INTEGER DEFAULT 0,
        time_window INTEGER DEFAULT 0,
        action TEXT DEFAULT 'escalate',
        strike_weight INTEGER DEFAULT 1,
        exemptions TEXT DEFAULT '[]',
        log_channel TEXT,
        rule_name TEXT,
        threshold_val INTEGER DEFAULT 0,
        extra_config TEXT,
        PRIMARY KEY (guild_id, filter_type)
      );

      CREATE TABLE IF NOT EXISTS automod_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        violation TEXT NOT NULL,
        action_taken TEXT NOT NULL,
        content_snippet TEXT,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS suggestions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        author_id TEXT NOT NULL,
        author_tag TEXT,
        content TEXT NOT NULL,
        status TEXT DEFAULT 'PENDING',
        upvotes INTEGER DEFAULT 0,
        downvotes INTEGER DEFAULT 0,
        reason TEXT,
        reviewed_by TEXT,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS suggestion_votes (
        guild_id TEXT NOT NULL,
        suggestion_id INTEGER NOT NULL,
        user_id TEXT NOT NULL,
        vote_type TEXT NOT NULL,
        timestamp INTEGER NOT NULL,
        PRIMARY KEY (guild_id, suggestion_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS starboard_messages (
        guild_id TEXT NOT NULL,
        orig_message_id TEXT NOT NULL,
        orig_channel_id TEXT NOT NULL,
        star_message_id TEXT NOT NULL,
        star_channel_id TEXT NOT NULL,
        author_id TEXT NOT NULL,
        star_count INTEGER NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, orig_message_id)
      );

      CREATE TABLE IF NOT EXISTS warn_ladder (
        guild_id TEXT NOT NULL,
        warn_count INTEGER NOT NULL,
        action TEXT NOT NULL,
        duration INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, warn_count)
      );

      CREATE TABLE IF NOT EXISTS guild_modules (
        guild_id TEXT NOT NULL,
        module_name TEXT NOT NULL,
        enabled INTEGER DEFAULT 1,
        updated_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, module_name)
      );

      CREATE TABLE IF NOT EXISTS polls (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        author_id TEXT NOT NULL,
        question TEXT NOT NULL,
        options_json TEXT NOT NULL,
        status TEXT DEFAULT 'OPEN',
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS poll_votes (
        guild_id TEXT NOT NULL,
        poll_id INTEGER NOT NULL,
        user_id TEXT NOT NULL,
        option_index INTEGER NOT NULL,
        timestamp INTEGER NOT NULL,
        PRIMARY KEY (guild_id, poll_id, user_id)
      );

      -- Hot Query Performance Indexes (Roadmap 2.6)
      CREATE INDEX IF NOT EXISTS idx_mod_cases_guild_user ON mod_cases (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_mod_cases_guild_case ON mod_cases (guild_id, case_num);
      CREATE INDEX IF NOT EXISTS idx_member_warnings_guild_user ON member_warnings (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_leveling_users_xp ON leveling_users (guild_id, xp DESC);
      CREATE INDEX IF NOT EXISTS idx_automod_logs_timestamp ON automod_logs (guild_id, timestamp);
      CREATE INDEX IF NOT EXISTS idx_sniped_messages_channel ON sniped_messages (channel_id);
      CREATE INDEX IF NOT EXISTS idx_suggestion_votes_sug ON suggestion_votes (suggestion_id);
      CREATE INDEX IF NOT EXISTS idx_poll_votes_poll ON poll_votes (poll_id);
      CREATE INDEX IF NOT EXISTS idx_whitelisted_users_lookup ON whitelisted_users (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_whitelisted_roles_lookup ON whitelisted_roles (guild_id, role_id);
      CREATE INDEX IF NOT EXISTS idx_whitelisted_channels_lookup ON whitelisted_channels (guild_id, channel_id);
      CREATE INDEX IF NOT EXISTS idx_extraowners_lookup ON extraowners (guild_id, owner_id);
      CREATE INDEX IF NOT EXISTS idx_auto_voice_panels ON auto_voice_panels (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_whitelisted_users_guild_user ON whitelisted_users (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_whitelisted_roles_guild_role ON whitelisted_roles (guild_id, role_id);
      CREATE INDEX IF NOT EXISTS idx_whitelisted_channels_guild_chan ON whitelisted_channels (guild_id, channel_id);
      CREATE INDEX IF NOT EXISTS idx_extraowners_guild_owner ON extraowners (guild_id, owner_id);
      CREATE INDEX IF NOT EXISTS idx_antinuke_rules_guild_vector ON antinuke_rules (guild_id, vector);
      CREATE INDEX IF NOT EXISTS idx_automod_strikes_guild_user ON automod_strikes (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs (timestamp);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_actor ON audit_logs (actor_id);
      CREATE INDEX IF NOT EXISTS idx_quarantined_users_guild_user ON quarantined_users (guild_id, user_id);

      CREATE TABLE IF NOT EXISTS voice_activity (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        total_seconds INTEGER DEFAULT 0,
        daily_seconds INTEGER DEFAULT 0,
        weekly_seconds INTEGER DEFAULT 0,
        monthly_seconds INTEGER DEFAULT 0,
        last_joined INTEGER DEFAULT 0,
        updated_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS voice_roles (
        guild_id TEXT NOT NULL,
        required_seconds INTEGER NOT NULL,
        role_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, required_seconds)
      );

      CREATE TABLE IF NOT EXISTS server_templates (
        id TEXT PRIMARY KEY,
        guild_id TEXT NOT NULL,
        creator_id TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        data_json TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS applications_config (
        guild_id TEXT PRIMARY KEY,
        channel_id TEXT,
        log_channel_id TEXT,
        questions_json TEXT,
        enabled INTEGER DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS applications_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        answers_json TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        reviewer_id TEXT,
        reason TEXT,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS eco_user_stocks (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        symbol TEXT NOT NULL,
        shares INTEGER DEFAULT 0,
        avg_buy_price REAL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id, symbol)
      );

      CREATE TABLE IF NOT EXISTS eco_properties (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        property_id TEXT NOT NULL,
        purchased_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, user_id, property_id)
      );

      CREATE TABLE IF NOT EXISTS eco_jobs (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        job_id TEXT NOT NULL,
        salary INTEGER NOT NULL,
        level INTEGER DEFAULT 1,
        last_worked INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS eco_loans (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        amount INTEGER NOT NULL,
        due_date INTEGER NOT NULL,
        interest_rate REAL NOT NULL,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS eco_user_stats (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        bank_capacity INTEGER DEFAULT 50000,
        fish_count INTEGER DEFAULT 0,
        hunt_count INTEGER DEFAULT 0,
        crime_count INTEGER DEFAULT 0,
        jail_until INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS moderation_policies (
        guild_id TEXT,
        name TEXT,
        config_json TEXT,
        created_by TEXT,
        created_at INTEGER,
        PRIMARY KEY (guild_id, name)
      );

      CREATE TABLE IF NOT EXISTS mod_macros (
        guild_id TEXT,
        name TEXT,
        steps_json TEXT,
        required_permission TEXT,
        created_by TEXT,
        created_at INTEGER,
        PRIMARY KEY (guild_id, name)
      );

      CREATE INDEX IF NOT EXISTS idx_voice_activity_user ON voice_activity (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_voice_activity_total ON voice_activity (guild_id, total_seconds DESC);
      CREATE INDEX IF NOT EXISTS idx_eco_stocks_user ON eco_user_stocks (guild_id, user_id);
      CREATE INDEX IF NOT EXISTS idx_app_submissions_guild ON applications_submissions (guild_id, status);
      CREATE INDEX IF NOT EXISTS idx_mod_policies_guild ON moderation_policies (guild_id);
      CREATE INDEX IF NOT EXISTS idx_mod_macros_guild ON mod_macros (guild_id);

      CREATE TABLE IF NOT EXISTS watchlist (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        reason TEXT,
        added_by TEXT NOT NULL,
        added_at INTEGER NOT NULL,
        PRIMARY KEY (guild_id, user_id)
      );
      CREATE INDEX IF NOT EXISTS idx_watchlist_guild_user ON watchlist (guild_id, user_id);

      CREATE TABLE IF NOT EXISTS command_overrides (
        guild_id TEXT NOT NULL,
        command TEXT NOT NULL,
        type TEXT NOT NULL,
        target_type TEXT NOT NULL,
        target_id TEXT NOT NULL,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        PRIMARY KEY (guild_id, command, target_type, target_id)
      );
      CREATE INDEX IF NOT EXISTS idx_cmd_overrides_lookup ON command_overrides (guild_id, command);

      CREATE TABLE IF NOT EXISTS custom_setup_roles (
        guild_id TEXT NOT NULL,
        role_key TEXT NOT NULL,
        role_id TEXT NOT NULL,
        PRIMARY KEY (guild_id, role_key)
      );
      CREATE INDEX IF NOT EXISTS idx_custom_setup_roles_guild ON custom_setup_roles (guild_id);

      CREATE TABLE IF NOT EXISTS vanity_roles (
        guild_id TEXT PRIMARY KEY,
        vanity_string TEXT,
        role_id TEXT,
        channel_id TEXT
      );
    `);

    // Ensure columns for existing schemas (idempotent)
    try { db.exec("ALTER TABLE whitelisted_users ADD COLUMN expires_at INTEGER DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE whitelisted_users ADD COLUMN added_by TEXT DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE whitelisted_roles ADD COLUMN expires_at INTEGER DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE whitelisted_roles ADD COLUMN added_by TEXT DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE extraowners ADD COLUMN added_by TEXT DEFAULT 'unknown'"); } catch (e) {}
    try { db.exec("ALTER TABLE extraowners ADD COLUMN added_at INTEGER DEFAULT 0"); } catch (e) {}
    try { db.exec("ALTER TABLE server_tickets ADD COLUMN category TEXT DEFAULT 'general'"); } catch (e) {}
    try { db.exec("ALTER TABLE server_tickets ADD COLUMN claimed_by TEXT DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE server_tickets ADD COLUMN last_activity INTEGER DEFAULT 0"); } catch (e) {}
    try { db.exec("ALTER TABLE server_tickets ADD COLUMN closed_at INTEGER DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE server_giveaways ADD COLUMN required_role_id TEXT DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE server_giveaways ADD COLUMN min_level INTEGER DEFAULT 0"); } catch (e) {}
    try { db.exec("ALTER TABLE server_giveaways ADD COLUMN min_server_age INTEGER DEFAULT 0"); } catch (e) {}
    try { db.exec("ALTER TABLE server_giveaways ADD COLUMN paused INTEGER DEFAULT 0"); } catch (e) {}
    try { db.exec("ALTER TABLE server_giveaways ADD COLUMN pause_remaining_ms INTEGER DEFAULT NULL"); } catch (e) {}
    try { db.exec("ALTER TABLE economy_users ADD COLUMN last_rob INTEGER DEFAULT 0"); } catch (e) {}

    // Run C1 Snowflake migration if necessary
    migrateSnowflakeColumnsToText(db);

    // Apply versioned migrations (PRAGMA user_version)
    applyVersionedMigrations(db, GUILD_MIGRATIONS, `guild_${gid}`);

    // Strictly ensure chat leveling is disabled by default (requires manual !levels on activation)
    try {
      db.prepare("INSERT OR IGNORE INTO server_settings (key, value) VALUES ('leveling_enabled', '0')").run();
    } catch (e) {}

    if (guildName || (ownerId && ownerId !== '0')) {
      const now = Date.now() / 1000;
      db.prepare(`
        INSERT INTO server_info (guild_id, name, owner_id, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
          name = CASE WHEN excluded.name != '' THEN excluded.name ELSE server_info.name END,
          owner_id = CASE WHEN excluded.owner_id != '0' AND excluded.owner_id != '' THEN excluded.owner_id ELSE server_info.owner_id END,
          updated_at = excluded.updated_at;
      `).run(gid, guildName, String(ownerId), now, now);
    }
  } catch (err) {
    console.warn(`[ServerDB] Schema initialization note for ${gid}: ${err.message}`);
  }

  // Update metadata.json (skip disk writes in cloud mode)
  if (!inCloud) {
    let meta = {};
    if (fs.existsSync(metaPath)) {
      try {
        meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
      } catch (e) {
        meta = {};
      }
    }
    meta.guild_id = gid;
    if (guildName) meta.guild_name = guildName;
    if (ownerId && ownerId !== '0') meta.owner_id = String(ownerId);
    meta.database_path = path.relative(ROOT_DIR, dbPath);
    meta.last_updated = Date.now() / 1000;
    if (!meta.created_at) meta.created_at = Date.now() / 1000;

    try {
      fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2), 'utf8');
    } catch (e) {}
  }

  _INITIALIZED_SERVERS.add(gid);
  return dbPath;
}

/**
 * C2 Get or open a cached SQLite database handle.
 * Avoids closing open connections abruptly on eviction.
 */
function getServerDb(guildId) {
  const gid = String(guildId);
  ensureServerDatabase(gid, '', '0', true);

  if (_DB_CACHE.has(gid)) {
    _HANDLE_TIMESTAMPS.set(gid, Date.now());
    return _DB_CACHE.get(gid);
  }

  const inCloud = isMongoCloudMode();

  // Idle connection reaper: close handles untouched for > 15 minutes if size > LRU_MAX_CONNECTIONS
  // Never close in-memory databases in cloud mode
  if (!inCloud && _DB_CACHE.size >= LRU_MAX_CONNECTIONS) {
    const now = Date.now();
    for (const [cachedGid, ts] of _HANDLE_TIMESTAMPS.entries()) {
      if (now - ts > 15 * 60 * 1000) {
        const idleDb = _DB_CACHE.get(cachedGid);
        if (idleDb) {
          try {
            idleDb.exec('PRAGMA wal_checkpoint(PASSIVE)');
            idleDb.close();
          } catch (e) {}
          _DB_CACHE.delete(cachedGid);
          _HANDLE_TIMESTAMPS.delete(cachedGid);
        }
      }
    }
  }

  const dbPath = inCloud ? ':memory:' : getServerDbPath(gid);
  const db = openDatabase(dbPath);
  _DB_CACHE.set(gid, db);
  _HANDLE_TIMESTAMPS.set(gid, Date.now());
  return db;
}

/**
 * C3 Master Database Initialization
 */
function ensureMasterDatabase() {
  const inCloud = isMongoCloudMode();
  if (inCloud) {
    if (!_MASTER_DB_INSTANCE) {
      _MASTER_DB_INSTANCE = openDatabase(':memory:');
    }
  } else {
    const masterDir = path.dirname(MASTER_DB_PATH);
    if (!fs.existsSync(masterDir)) {
      fs.mkdirSync(masterDir, { recursive: true });
    }

    // Automatic Migration from legacy tungsten.db to tungsten.db if tungsten.db does not exist
    if (!fs.existsSync(MASTER_DB_PATH) && fs.existsSync(LEGACY_MASTER_DB_PATH)) {
      try {
        fs.copyFileSync(LEGACY_MASTER_DB_PATH, MASTER_DB_PATH);
        if (fs.existsSync(LEGACY_MASTER_DB_PATH + '-wal')) {
          try { fs.copyFileSync(LEGACY_MASTER_DB_PATH + '-wal', MASTER_DB_PATH + '-wal'); } catch (_) {}
        }
        if (fs.existsSync(LEGACY_MASTER_DB_PATH + '-shm')) {
          try { fs.copyFileSync(LEGACY_MASTER_DB_PATH + '-shm', MASTER_DB_PATH + '-shm'); } catch (_) {}
        }
        console.log('[Database Migration] Successfully migrated tungsten.db to tungsten.db');
      } catch (err) {
        console.error('[Database Migration Error] Failed to copy tungsten.db to tungsten.db:', err);
      }
    }

    if (!_MASTER_DB_INSTANCE) {
      _MASTER_DB_INSTANCE = openDatabase(MASTER_DB_PATH);
    }
  }

  const db = _MASTER_DB_INSTANCE;
  db.exec(`
    CREATE TABLE IF NOT EXISTS bot_owners (
      user_id TEXT PRIMARY KEY,
      added_at INTEGER NOT NULL,
      added_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS blacklist_users (
      user_id TEXT PRIMARY KEY,
      reason TEXT,
      added_at INTEGER NOT NULL,
      added_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS blacklist_guilds (
      guild_id TEXT PRIMARY KEY,
      reason TEXT,
      added_at INTEGER NOT NULL,
      added_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS global_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS command_overrides (
      scope TEXT NOT NULL,
      id TEXT NOT NULL,
      command TEXT NOT NULL,
      enabled INTEGER DEFAULT 1,
      cooldown INTEGER DEFAULT 0,
      allowed_channels TEXT,
      allowed_roles TEXT,
      PRIMARY KEY (scope, id, command)
    );

    CREATE TABLE IF NOT EXISTS settings_audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      key TEXT NOT NULL,
      old_val TEXT,
      new_val TEXT,
      actor_id TEXT NOT NULL,
      timestamp INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS prefix (
      guild_id TEXT PRIMARY KEY,
      prefix TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS blacklist (
      user_id TEXT PRIMARY KEY
    );

    CREATE TABLE IF NOT EXISTS guild_blacklist (
      guild_id TEXT PRIMARY KEY
    );

    CREATE TABLE IF NOT EXISTS ignore (
      channel_id TEXT PRIMARY KEY,
      added_at INTEGER DEFAULT (strftime('%s', 'now'))
    );

    CREATE TABLE IF NOT EXISTS noprefix_users (
      user_id TEXT PRIMARY KEY,
      added_at INTEGER NOT NULL,
      added_by TEXT NOT NULL,
      expires_at INTEGER DEFAULT -1
    );

    CREATE TABLE IF NOT EXISTS np_managers (
      user_id TEXT PRIMARY KEY,
      added_at INTEGER NOT NULL,
      added_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS scheduled_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      kind TEXT NOT NULL,
      run_at INTEGER NOT NULL,
      payload TEXT NOT NULL,
      done INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_tasks_due ON scheduled_tasks(done, run_at);
  `);

  try { db.exec("DROP INDEX IF EXISTS idx_np_users_lookup"); } catch (e) {}
  try { db.exec("ALTER TABLE noprefix_users ADD COLUMN expires_at INTEGER DEFAULT -1"); } catch (e) {}
  try { db.exec("ALTER TABLE np_managers ADD COLUMN added_at INTEGER DEFAULT (strftime('%s', 'now'))"); } catch (e) {}
  try { db.exec("ALTER TABLE np_managers ADD COLUMN added_by TEXT DEFAULT 'system'"); } catch (e) {}
  try { db.exec("ALTER TABLE scheduled_tasks ADD COLUMN retries INTEGER DEFAULT 0"); } catch (e) {}

  migrateSnowflakeColumnsToText(db);

  // Apply master versioned migrations (PRAGMA user_version)
  applyVersionedMigrations(db, MASTER_MIGRATIONS, 'master.db');

  // Seed bot_owners: keep strictly snovv.vvhite (1348196008202600489)
  try {
    db.prepare("DELETE FROM bot_owners WHERE user_id != '1348196008202600489'").run();
    const stmt = db.prepare('INSERT OR IGNORE INTO bot_owners (user_id, added_at, added_by) VALUES (?, ?, ?)');
    const now = Math.floor(Date.now() / 1000);
    stmt.run('1348196008202600489', now, 'system_seed');
  } catch (e) {}

  _MASTER_DB_INITIALIZED = true;
  return db;
}

function getMasterDb() {
  if (!_MASTER_DB_INSTANCE || !_MASTER_DB_INITIALIZED) {
    return ensureMasterDatabase();
  }
  return _MASTER_DB_INSTANCE;
}

function syncResolvedOwners(ownerIds) {
  // snovv.vvhite (1348196008202600489) is permanently locked as sole bot owner
  if (!Array.isArray(ownerIds) || ownerIds.length === 0) return;
  const db = getMasterDb();
  const now = Math.floor(Date.now() / 1000);
  const stmt = db.prepare('INSERT OR IGNORE INTO bot_owners (user_id, added_at, added_by) VALUES (?, ?, ?)');
  for (const id of ownerIds) {
    const sId = String(id);
    if (sId === '1348196008202600489') {
      try {
        stmt.run(sId, now, 'discord_app_owner');
      } catch (e) {}
    }
  }
}

function syncServerDataFromMaster(guildId) {
  const gid = String(guildId);
  if (!isMongoCloudMode() && !fs.existsSync(MASTER_DB_PATH)) return false;

  ensureServerDatabase(gid, '', '0', false);
  const serverDb = getServerDb(gid);
  const masterDb = getMasterDb();

  try {
    // 1. Sync autorole
    try {
      const row = masterDb.prepare('SELECT bots, humans FROM autorole WHERE guild_id = ?').get(gid);
      if (row) {
        serverDb.prepare('INSERT OR REPLACE INTO autorole (guild_id, bots, humans) VALUES (?, ?, ?)')
          .run(gid, row.bots, row.humans);
      }
    } catch (e) {}

    // 2. Sync welcome_panel
    try {
      const row = masterDb.prepare('SELECT * FROM welcome_panel WHERE guild_id = ?').get(gid);
      if (row) {
        const cols = Object.keys(row);
        const placeholders = cols.map(() => '?').join(', ');
        const colsStr = cols.join(', ');
        const vals = cols.map(c => row[c]);
        serverDb.prepare(`INSERT OR REPLACE INTO welcome_panel (${colsStr}) VALUES (${placeholders})`).run(...vals);
      }
    } catch (e) {}

    return true;
  } catch (e) {
    return false;
  }
}

function syncServerDataToMaster(guildId) {
  const gid = String(guildId);
  const serverDbPath = getServerDbPath(gid);
  if (!isMongoCloudMode() && (!fs.existsSync(serverDbPath) || !fs.existsSync(MASTER_DB_PATH))) return false;

  const serverDb = getServerDb(gid);
  const masterDb = getMasterDb();

  try {
    // 1. Sync autorole
    try {
      const row = serverDb.prepare('SELECT bots, humans FROM autorole WHERE guild_id = ?').get(gid);
      if (row) {
        masterDb.prepare('INSERT OR REPLACE INTO autorole (guild_id, bots, humans) VALUES (?, ?, ?)')
          .run(gid, row.bots, row.humans);
      }
    } catch (e) {}

    // 2. Sync welcome_panel
    try {
      const row = serverDb.prepare('SELECT * FROM welcome_panel WHERE guild_id = ?').get(gid);
      if (row) {
        const cols = Object.keys(row);
        const placeholders = cols.map(() => '?').join(', ');
        const colsStr = cols.join(', ');
        const vals = cols.map(c => row[c]);
        masterDb.prepare(`INSERT OR REPLACE INTO welcome_panel (${colsStr}) VALUES (${placeholders})`).run(...vals);
      }
    } catch (e) {}

    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Retrieves the custom embed accent color for a guild.
 * If user set a custom hex (e.g. via !embedcolor or !accent), returns that integer.
 * Otherwise returns pure stealth black: 0x000001.
 */
function getGuildAccent(guildId) {
  if (!guildId) return config.COLORS?.PRIMARY || 0x000000;
  try {
    const sdb = getServerDb(guildId);
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'accent_color'").get();
    if (row && row.value) {
      let val = row.value.trim().replace(/^#/, '').replace(/^0x/, '');
      const parsed = parseInt(val, 16);
      if (!isNaN(parsed) && parsed >= 0 && parsed <= 0xFFFFFF) {
        return parsed;
      }
    }
  } catch (e) {}
  return config.COLORS?.PRIMARY || 0x000001;
}

/**
 * Sets a custom embed accent color for a guild.
 */
function setGuildAccent(guildId, hexColor) {
  if (!guildId) return false;
  const sdb = getServerDb(guildId);
  if (!hexColor || hexColor === 'reset' || hexColor === 'default' || hexColor === 'black') {
    sdb.prepare("DELETE FROM server_settings WHERE key = 'accent_color'").run();
    syncServerDataToMaster(guildId);
    return 0x000001;
  }
  let clean = String(hexColor).trim().replace(/^#/, '').replace(/^0x/, '');
  const parsed = parseInt(clean, 16);
  if (isNaN(parsed) || parsed < 0 || parsed > 0xFFFFFF) {
    throw new Error('Invalid hexadecimal color. Example: #00FF88, #FF0055, or #000001');
  }
  const formatted = '#' + clean.padStart(6, '0').toUpperCase();
  sdb.prepare(`
    INSERT INTO server_settings (key, value) VALUES ('accent_color', ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(formatted);
  syncServerDataToMaster(guildId);
  return parsed;
}

function initAllServerFoldersFromMaster(activeGuilds = null) {
  ensureMasterDatabase();
  const masterDb = getMasterDb();
  const guildIds = new Set();

  try {
    const tables = masterDb.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()
      .map(r => r.name)
      .filter(n => !n.startsWith('sqlite_'));

    for (const t of tables) {
      try {
        const cols = masterDb.prepare(`PRAGMA table_info("${t}")`).all().map(c => c.name);
        if (cols.includes('guild_id')) {
          const rows = masterDb.prepare(`SELECT DISTINCT guild_id FROM "${t}" WHERE guild_id IS NOT NULL`).all();
          for (const r of rows) {
            const gid = String(r.guild_id || '');
            // Only valid Discord snowflake IDs (17-20 digits) are real servers
            if (/^\d{17,20}$/.test(gid)) {
              if (!activeGuilds || activeGuilds.has(gid)) {
                guildIds.add(gid);
              }
            }
          }
        }
      } catch (e) {}
    }
  } catch (e) {}

  let createdCount = 0;
  for (const gid of guildIds) {
    if (serverFolderExists(gid)) {
      _INITIALIZED_SERVERS.add(gid);
      continue;
    }
    ensureServerDatabase(gid, '', '0', false);
    syncServerDataFromMaster(gid);
    createdCount++;
  }

  return createdCount;
}

async function registerGuild(guild) {
  if (!guild || !guild.id) return '';
  const gid = String(guild.id);
  const name = guild.name || '';
  const ownerId = guild.ownerId ? String(guild.ownerId) : '0';

  if (serverFolderExists(gid)) {
    // M3: Refresh existing guild name and owner
    try {
      const sdb = getServerDb(gid);
      const now = Date.now() / 1000;
      sdb.prepare(`
        UPDATE server_info
        SET name = CASE WHEN ? != '' THEN ? ELSE name END,
            owner_id = CASE WHEN ? != '0' AND ? != '' THEN ? ELSE owner_id END,
            updated_at = ?
        WHERE guild_id = ?
      `).run(name, name, ownerId, ownerId, ownerId, now, gid);
    } catch (e) {}
    return getServerDbPath(gid);
  }

  const dbPath = ensureServerDatabase(gid, name, ownerId, false);
  syncServerDataFromMaster(gid);
  return dbPath;
}

function closeServerDb(guildId) {
  const gid = String(guildId);
  if (_DB_CACHE.has(gid)) {
    const db = _DB_CACHE.get(gid);
    try {
      db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
      db.close();
    } catch (e) {}
    _DB_CACHE.delete(gid);
    _HANDLE_TIMESTAMPS.delete(gid);
  }
  _INITIALIZED_SERVERS.delete(gid);
}

/**
 * Prunes orphaned, non-snowflake, or ghost server directories from db/servers/.
 * Ensures only servers the bot is currently in have database directories.
 */
function prunePhantomServerFolders(client = null) {
  if (isMongoCloudMode()) return 0;
  if (!fs.existsSync(SERVERS_BASE_DIR)) return 0;
  let pruned = 0;
  try {
    const entries = fs.readdirSync(SERVERS_BASE_DIR);
    const activeGuildIds = client?.guilds?.cache && client.guilds.cache.size > 0
      ? new Set(client.guilds.cache.keys())
      : null;

    for (const entry of entries) {
      const fullPath = path.join(SERVERS_BASE_DIR, entry);
      // If not a numeric snowflake ID (17-20 digits), prune immediately
      if (!/^\d{17,20}$/.test(entry)) {
        try {
          closeServerDb(entry);
          fs.rmSync(fullPath, { recursive: true, force: true });
          pruned++;
          continue;
        } catch (e) {}
      }

      // If active guild cache is provided, prune servers the bot has left
      if (activeGuildIds && !activeGuildIds.has(entry)) {
        try {
          closeServerDb(entry);
          fs.rmSync(fullPath, { recursive: true, force: true });
          pruned++;
        } catch (e) {}
      }
    }
  } catch (e) {}
  return pruned;
}

/**
 * Audit Log Rotation & Pruning Helper
 */
function pruneAuditLogs(guildId, maxAgeDays = 90) {
  const gid = String(guildId);
  if (!gid || (!validateSnowflake(gid) && !gid.includes('test'))) return 0;
  const db = getServerDb(gid);
  if (!db) return 0;

  const days = (typeof maxAgeDays === 'number' && maxAgeDays > 0) ? maxAgeDays : 90;
  const cutoffSeconds = Math.floor(Date.now() / 1000) - (days * 86400);

  try {
    const result = db.prepare(`
      DELETE FROM audit_logs 
      WHERE (timestamp <= 10000000000 AND timestamp < ?) 
         OR (timestamp > 10000000000 AND timestamp < ?)
    `).run(cutoffSeconds, cutoffSeconds * 1000);
    return result ? (result.changes || 0) : 0;
  } catch (err) {
    console.error(`[ServerDB] Failed to prune audit logs for guild ${gid}:`, err);
    return 0;
  }
}

/**
 * Moderation Watchlist Surveillance Helpers
 */
function addToWatchlist(guildId, userId, reason, addedBy) {
  const gid = String(guildId);
  const uid = String(userId);
  if (!validateSnowflake(gid) && !gid.includes('test')) {
    throw new Error(`[ServerDB] Invalid guild snowflake ID: ${guildId}`);
  }
  if (!validateSnowflake(uid) && !uid.includes('test')) {
    throw new Error(`[ServerDB] Invalid user snowflake ID: ${userId}`);
  }
  const db = getServerDb(gid);
  if (!db) throw new Error(`[ServerDB] Database unavailable for guild: ${gid}`);
  const now = Math.floor(Date.now() / 1000);
  const cleanReason = (reason && String(reason).trim()) || 'No reason provided';
  db.prepare(`
    INSERT INTO watchlist (guild_id, user_id, reason, added_by, added_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET
      reason = excluded.reason,
      added_by = excluded.added_by,
      added_at = excluded.added_at
  `).run(gid, uid, cleanReason, String(addedBy), now);
  return { guild_id: gid, user_id: uid, reason: cleanReason, added_by: String(addedBy), added_at: now };
}

function removeFromWatchlist(guildId, userId) {
  const gid = String(guildId);
  const uid = String(userId);
  if (!validateSnowflake(gid) && !gid.includes('test')) return false;
  if (!validateSnowflake(uid) && !uid.includes('test')) return false;
  const db = getServerDb(gid);
  if (!db) return false;
  const res = db.prepare('DELETE FROM watchlist WHERE guild_id = ? AND user_id = ?').run(gid, uid);
  return res.changes > 0;
}

function getWatchlist(guildId) {
  const gid = String(guildId);
  if (!validateSnowflake(gid) && !gid.includes('test')) return [];
  const db = getServerDb(gid);
  if (!db) return [];
  return db.prepare('SELECT guild_id, user_id, reason, added_by, added_at FROM watchlist WHERE guild_id = ? ORDER BY added_at DESC').all(gid);
}

function getWatchlistEntry(guildId, userId) {
  const gid = String(guildId);
  const uid = String(userId);
  if (!validateSnowflake(gid) && !gid.includes('test')) return null;
  if (!validateSnowflake(uid) && !uid.includes('test')) return null;
  const db = getServerDb(gid);
  if (!db) return null;
  return db.prepare('SELECT guild_id, user_id, reason, added_by, added_at FROM watchlist WHERE guild_id = ? AND user_id = ?').get(gid, uid) || null;
}

function isWatchlisted(guildId, userId) {
  const entry = getWatchlistEntry(guildId, userId);
  return Boolean(entry);
}

/**
 * Extra Owners Security Storage Helpers
 */
function addExtraOwner(guildId, ownerId, addedBy = 'unknown') {
  const gid = String(guildId);
  const oid = String(ownerId);
  if (!validateSnowflake(gid) && !gid.includes('test')) {
    throw new Error(`[ServerDB] Invalid guild snowflake ID: ${guildId}`);
  }
  if (!validateSnowflake(oid) && !oid.includes('test')) {
    throw new Error(`[ServerDB] Invalid owner snowflake ID: ${ownerId}`);
  }
  const db = getServerDb(gid);
  if (!db) return false;
  const now = Math.floor(Date.now() / 1000);
  const res = db.prepare(`
    INSERT OR IGNORE INTO extraowners (guild_id, owner_id, added_by, added_at)
    VALUES (?, ?, ?, ?)
  `).run(gid, oid, String(addedBy || 'unknown'), now);
  return res.changes > 0;
}

function removeExtraOwner(guildId, ownerId) {
  const gid = String(guildId);
  const oid = String(ownerId);
  if (!validateSnowflake(gid) && !gid.includes('test')) return false;
  if (!validateSnowflake(oid) && !oid.includes('test')) return false;
  const db = getServerDb(gid);
  if (!db) return false;
  const res = db.prepare('DELETE FROM extraowners WHERE guild_id = ? AND owner_id = ?').run(gid, oid);
  return res.changes > 0;
}

function getExtraOwners(guildId) {
  const gid = String(guildId);
  if (!validateSnowflake(gid) && !gid.includes('test')) return [];
  const db = getServerDb(gid);
  if (!db) return [];
  return db.prepare('SELECT guild_id, owner_id, added_by, added_at FROM extraowners WHERE guild_id = ?').all(gid);
}

module.exports = {
  _DB_CACHE,
  getAllCachedGuildDbs,
  isMongoCloudMode,
  getRootDir: () => ROOT_DIR,
  getDbDir: () => DB_DIR,
  getServersBaseDir: () => SERVERS_BASE_DIR,
  getMasterDbPath: () => (isMongoCloudMode() ? ':memory:' : MASTER_DB_PATH),
  getMasterDb,
  ensureMasterDatabase,
  syncResolvedOwners,
  getServerDir,
  getServerDbPath,
  serverFolderExists,
  ensureServerDatabase,
  getServerDb,
  closeServerDb,
  syncServerDataFromMaster,
  syncServerDataToMaster,
  initAllServerFoldersFromMaster,
  registerGuild,
  prunePhantomServerFolders,
  getGuildAccent,
  setGuildAccent,
  migrateSnowflakeColumnsToText,
  applyVersionedMigrations,
  validateSnowflake,
  pruneAuditLogs,
  addToWatchlist,
  removeFromWatchlist,
  getWatchlist,
  getWatchlistEntry,
  isWatchlisted,
  addExtraOwner,
  removeExtraOwner,
  getExtraOwners
};
