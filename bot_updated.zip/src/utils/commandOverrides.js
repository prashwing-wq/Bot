/**
 * Command Overrides Subsystem (Node.js)
 * Enables granular per-command allow/deny overrides targeting users, roles, and channels.
 * Priority hierarchy: User Deny > Channel Deny > Role Deny > User Allow > Role Allow > Channel Allow > Standard Check.
 * Owner commands (eval, restart, owners, etc.) are strictly immune to overrides.
 */
const { getServerDb } = require('./serverDb');

const OWNER_COMMANDS = new Set([
  'eval',
  'restart',
  'owners',
  'blacklist',
  'bserver',
  'dm',
  'emojiserver',
  'forcepurge',
  'freezenick',
  'getinvite',
  'globalannounce',
  'globalban',
  'guildban',
  'guildinfo',
  'leaveguild',
  'mutual',
  'ownerban',
  'ownerhelp',
  'selfadmin',
  'staff',
  'sync'
]);

/**
 * Checks whether a command is a bot owner command and thus immune to overrides.
 * @param {string} commandName
 * @param {import('discord.js').Client} [client]
 * @returns {boolean}
 */
function isOwnerCommand(commandName, client) {
  if (!commandName) return false;
  const lower = String(commandName).toLowerCase();
  if (OWNER_COMMANDS.has(lower)) return true;

  if (client && client.commands) {
    const cmd = client.commands.get(lower) || client.commands.get(client.aliases?.get(lower));
    if (cmd && (cmd.category === 'owner' || cmd.ownerOnly === true)) {
      return true;
    }
  }
  return false;
}

/**
 * Fetches all overrides for a specific command in a guild.
 * @param {string} guildId
 * @param {string} commandName
 * @returns {Array<{ guild_id: string, command: string, type: string, target_type: string, target_id: string }>}
 */
function getOverrides(guildId, commandName) {
  if (!guildId || !commandName) return [];
  const gid = String(guildId);
  const cmd = String(commandName).toLowerCase();
  try {
    const db = getServerDb(gid);
    return db.prepare('SELECT guild_id, command, type, target_type, target_id FROM command_overrides WHERE guild_id = ? AND command = ?')
      .all(gid, cmd);
  } catch (err) {
    return [];
  }
}

/**
 * Fetches all overrides in a guild.
 * @param {string} guildId
 * @returns {Array<{ guild_id: string, command: string, type: string, target_type: string, target_id: string, created_at: number }>}
 */
function getAllOverrides(guildId) {
  if (!guildId) return [];
  const gid = String(guildId);
  try {
    const db = getServerDb(gid);
    return db.prepare('SELECT guild_id, command, type, target_type, target_id, created_at FROM command_overrides WHERE guild_id = ? ORDER BY command ASC, target_type ASC')
      .all(gid);
  } catch (err) {
    return [];
  }
}

/**
 * Sets a command override for a target.
 * @param {string} guildId
 * @param {string} commandName
 * @param {'allow'|'deny'} type
 * @param {'user'|'role'|'channel'} targetType
 * @param {string} targetId
 * @returns {boolean}
 */
function setOverride(guildId, commandName, type, targetType, targetId) {
  const gid = String(guildId);
  const cmd = String(commandName).toLowerCase();
  const t = String(type).toLowerCase();
  const tt = String(targetType).toLowerCase();
  const tid = String(targetId);

  if (isOwnerCommand(cmd)) {
    throw new Error(`Owner command '${cmd}' cannot be overridden.`);
  }
  if (!['allow', 'deny'].includes(t)) {
    throw new Error("Override type must be 'allow' or 'deny'.");
  }
  if (!['user', 'role', 'channel'].includes(tt)) {
    throw new Error("Target type must be 'user', 'role', or 'channel'.");
  }

  const db = getServerDb(gid);
  const now = Math.floor(Date.now() / 1000);
  db.prepare(`
    INSERT INTO command_overrides (guild_id, command, type, target_type, target_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, command, target_type, target_id) DO UPDATE SET
      type = excluded.type,
      created_at = excluded.created_at
  `).run(gid, cmd, t, tt, tid, now);

  return true;
}

/**
 * Clears all overrides for a specific command in a guild.
 * @param {string} guildId
 * @param {string} commandName
 * @returns {number} Number of deleted overrides.
 */
function clearOverrides(guildId, commandName) {
  const gid = String(guildId);
  const cmd = String(commandName).toLowerCase();
  if (isOwnerCommand(cmd)) {
    throw new Error(`Owner command '${cmd}' cannot be overridden.`);
  }

  const db = getServerDb(gid);
  const res = db.prepare('DELETE FROM command_overrides WHERE guild_id = ? AND command = ?').run(gid, cmd);
  return res.changes || 0;
}

/**
 * Evaluates overrides for a member attempting to run a command in a channel.
 * Priority hierarchy:
 * 1. User Deny
 * 2. Channel Deny
 * 3. Role Deny
 * 4. User Allow
 * 5. Role Allow
 * 6. Channel Allow
 * 7. null (Fallback to standard declarative permissions check)
 *
 * @param {string} guildId
 * @param {string} commandName
 * @param {import('discord.js').GuildMember|object} member
 * @param {string} [channelId]
 * @param {import('discord.js').Client} [client]
 * @returns {'allow'|'deny'|null}
 */
function evaluateOverride(guildId, commandName, member, channelId, client) {
  if (!guildId || !commandName) return null;
  const cmd = String(commandName).toLowerCase();

  // Bot Owner commands are completely immune to overrides
  if (isOwnerCommand(cmd, client)) {
    return null;
  }

  const overrides = getOverrides(guildId, cmd);
  if (!overrides || overrides.length === 0) {
    return null;
  }

  const memberId = member ? String(member.id || member.user?.id || '') : '';
  const chanId = channelId ? String(channelId) : '';

  let roleIds = [];
  if (member?.roles?.cache) {
    roleIds = Array.from(member.roles.cache.keys()).map(String);
  } else if (Array.isArray(member?.roles)) {
    roleIds = member.roles.map(r => (typeof r === 'object' && r ? String(r.id) : String(r)));
  }

  // 1. User Deny
  if (memberId && overrides.some(o => o.target_type === 'user' && o.target_id === memberId && o.type === 'deny')) {
    return 'deny';
  }

  // 2. Channel Deny
  if (chanId && overrides.some(o => o.target_type === 'channel' && o.target_id === chanId && o.type === 'deny')) {
    return 'deny';
  }

  // 3. Role Deny
  if (roleIds.length > 0 && overrides.some(o => o.target_type === 'role' && roleIds.includes(o.target_id) && o.type === 'deny')) {
    return 'deny';
  }

  // 4. User Allow
  if (memberId && overrides.some(o => o.target_type === 'user' && o.target_id === memberId && o.type === 'allow')) {
    return 'allow';
  }

  // 5. Role Allow
  if (roleIds.length > 0 && overrides.some(o => o.target_type === 'role' && roleIds.includes(o.target_id) && o.type === 'allow')) {
    return 'allow';
  }

  // 6. Channel Allow
  if (chanId && overrides.some(o => o.target_type === 'channel' && o.target_id === chanId && o.type === 'allow')) {
    return 'allow';
  }

  // 7. No override matched -> standard permissions check
  return null;
}

module.exports = {
  OWNER_COMMANDS,
  isOwnerCommand,
  getOverrides,
  getAllOverrides,
  setOverride,
  clearOverrides,
  evaluateOverride
};
