/**
 * Tungsten Mass DM & Join Raid Detection Engine (Feature 8)
 * Flags fast join-leave scrapers (<= 60s) and alerts on mass join floods (>= 10 joins in 60s).
 */
const { EmbedBuilder } = require('discord.js');
const { getServerDb } = require('./serverDb');
const { resolveEmoji } = require('./emojis');
const config = require('../config');

// In-memory alert dispatch throttle to prevent channel spam during massive raids (30s cooldown per guild)
const _RAID_ALERT_COOLDOWNS = new Map();

/**
 * Ensures the join_raid_log table exists in the target database.
 * @param {object} db - SQLite database instance
 */
function ensureRaidTable(db) {
  if (!db) return;
  db.exec(`
    CREATE TABLE IF NOT EXISTS join_raid_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      joined_at INTEGER NOT NULL,
      left_at INTEGER,
      flagged INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_join_raid_guild_joined ON join_raid_log(guild_id, joined_at);
    CREATE INDEX IF NOT EXISTS idx_join_raid_guild_user ON join_raid_log(guild_id, user_id, joined_at DESC);
  `);
}

/**
 * Resolves the designated security/mod log channel for a guild.
 * @param {object} guild
 * @returns {Promise<object|null>}
 */
async function resolveSecurityLogChannel(guild) {
  if (!guild || !guild.id) return null;
  try {
    const sdb = getServerDb(guild.id);
    const row = sdb.prepare(`
      SELECT value FROM server_settings
      WHERE key IN ('log_security', 'security_log_channel', 'log_mod', 'log_server', 'audit_log_channel', 'log_channel', 'modlog_channel')
      ORDER BY CASE key
        WHEN 'log_security' THEN 1
        WHEN 'security_log_channel' THEN 2
        WHEN 'log_mod' THEN 3
        WHEN 'audit_log_channel' THEN 4
        WHEN 'log_server' THEN 5
        WHEN 'log_channel' THEN 6
        WHEN 'modlog_channel' THEN 7
        ELSE 8
      END
      LIMIT 1
    `).get();

    if (row && row.value) {
      const ch = guild.channels?.cache?.get(row.value)
        || (guild.channels?.fetch ? await guild.channels.fetch(row.value).catch(() => null) : null);
      if (ch && ch.isTextBased && typeof ch.send === 'function') {
        return ch;
      }
    }
  } catch (e) {}
  return null;
}

/**
 * Records a member join and evaluates sliding 60-second window for Join Raid detection.
 * If 10+ joins occur within 60 seconds, triggers a "JOIN RAID" alert.
 * @param {string} guildId
 * @param {string} userId
 * @param {object} [clientOrGuild=null]
 * @returns {{raidDetected: boolean, count: number, guildId: string, userId: string}}
 */
async function recordMemberJoin(guildId, userId, clientOrGuild = null) {
  if (!guildId || !userId) {
    return { raidDetected: false, count: 0, guildId: String(guildId || ''), userId: String(userId || '') };
  }

  const gid = String(guildId).trim();
  const uid = String(userId).trim();
  const sdb = getServerDb(gid);
  ensureRaidTable(sdb);

  const now = Math.floor(Date.now() / 1000);

  // Insert join log
  sdb.prepare(`
    INSERT INTO join_raid_log (guild_id, user_id, joined_at, left_at, flagged)
    VALUES (?, ?, ?, NULL, 0)
  `).run(gid, uid, now);

  // Query sliding 60-second window
  const windowStart = now - 60;
  const countRow = sdb.prepare(`
    SELECT COUNT(*) AS count FROM join_raid_log
    WHERE guild_id = ? AND joined_at >= ?
  `).get(gid, windowStart);

  const joinCount = Number(countRow?.count) || 1;
  const raidDetected = joinCount >= 10;

  // If raid detected, trigger alert
  if (raidDetected && clientOrGuild) {
    await triggerJoinRaidAlert(gid, uid, joinCount, clientOrGuild).catch(() => null);
  }

  return {
    raidDetected,
    count: joinCount,
    guildId: gid,
    userId: uid
  };
}

/**
 * Dispatches an automated JOIN RAID alert if not in cooldown.
 */
async function triggerJoinRaidAlert(guildId, latestUserId, joinCount, clientOrGuild) {
  const now = Date.now();
  const lastAlert = _RAID_ALERT_COOLDOWNS.get(guildId) || 0;
  if (now - lastAlert < 30000) {
    // 30s cooldown per guild to prevent message flooding
    return;
  }
  _RAID_ALERT_COOLDOWNS.set(guildId, now);

  let guild = null;
  let client = null;

  if (clientOrGuild?.guilds?.cache) {
    client = clientOrGuild;
    guild = client.guilds.cache.get(guildId)
      || (client.guilds.fetch ? await client.guilds.fetch(guildId).catch(() => null) : null);
  } else if (clientOrGuild?.id === guildId) {
    guild = clientOrGuild;
    client = guild.client;
  }

  if (!guild) return;

  const secChannel = await resolveSecurityLogChannel(guild);
  if (!secChannel) return;

  const alarmEmoji = resolveEmoji(client, 'alarm') || resolveEmoji(guild, 'alarm') || '<a:tungsten_alarm:1567229471474585682>';
  const shieldEmoji = resolveEmoji(client, 'shield') || resolveEmoji(guild, 'shield') || '<a:tungsten_shield:1567242104923627574>';

  const embed = new EmbedBuilder()
    .setColor(config.COLORS.DANGER)
    .setTitle(`${alarmEmoji} JOIN RAID DETECTED: Rapid Influx Alert`)
    .setDescription(
      `> **Raid Velocity:** \`${joinCount}\` member joins recorded within 60 seconds!\n` +
      `> **Threshold:** Mass influx limit exceeded (\`10+\` joins / 60s).\n` +
      `> **Latest Join:** <@${latestUserId}> (\`${latestUserId}\`)\n` +
      `> **Sentinel Status:** ${shieldEmoji} Defensive sentinels alerted. Anti-Raid join flood mitigation recommended.`
    )
    .setFooter({ text: 'Tungsten Mass DM & Anti-Raid Sentinel' })
    .setTimestamp();

  await secChannel.send({ embeds: [embed] }).catch(() => null);
}

/**
 * Records a member leave and flags accounts that depart within 60 seconds of joining.
 * Detects Mass DM / user scraping bots that join, blast direct messages, and quickly flee.
 * @param {string} guildId
 * @param {string} userId
 * @param {object} [clientOrGuild=null]
 * @returns {{flagged: boolean, duration: number|null, id: number|null, notFound?: boolean}}
 */
async function recordMemberLeave(guildId, userId, clientOrGuild = null) {
  if (!guildId || !userId) {
    return { flagged: false, duration: null, id: null };
  }

  const gid = String(guildId).trim();
  const uid = String(userId).trim();
  const sdb = getServerDb(gid);
  ensureRaidTable(sdb);

  const now = Math.floor(Date.now() / 1000);

  // Find most recent join entry for this user in this guild
  const row = sdb.prepare(`
    SELECT id, joined_at, left_at, flagged
    FROM join_raid_log
    WHERE guild_id = ? AND user_id = ?
    ORDER BY joined_at DESC
    LIMIT 1
  `).get(gid, uid);

  if (!row) {
    return { flagged: false, duration: null, id: null, notFound: true };
  }

  const duration = Math.max(0, now - Number(row.joined_at));
  const isFastLeave = duration <= 60;
  const flagged = isFastLeave ? 1 : 0;

  sdb.prepare(`
    UPDATE join_raid_log
    SET left_at = ?, flagged = ?
    WHERE id = ?
  `).run(now, flagged, row.id);

  if (flagged === 1 && clientOrGuild) {
    await triggerMassDmScraperAlert(gid, uid, duration, clientOrGuild).catch(() => null);
  }

  return {
    flagged: flagged === 1,
    duration,
    id: row.id
  };
}

/**
 * Dispatches an automated Mass DM scraper detection alert.
 */
async function triggerMassDmScraperAlert(guildId, userId, duration, clientOrGuild) {
  let guild = null;
  let client = null;

  if (clientOrGuild?.guilds?.cache) {
    client = clientOrGuild;
    guild = client.guilds.cache.get(guildId)
      || (client.guilds.fetch ? await client.guilds.fetch(guildId).catch(() => null) : null);
  } else if (clientOrGuild?.id === guildId) {
    guild = clientOrGuild;
    client = guild.client;
  }

  if (!guild) return;

  const secChannel = await resolveSecurityLogChannel(guild);
  if (!secChannel) return;

  const warnEmoji = resolveEmoji(client, 'warning') || resolveEmoji(guild, 'warning') || '<a:tungsten_warn:1567246685082746940>';

  const embed = new EmbedBuilder()
    .setColor(config.COLORS.WARNING)
    .setTitle(`${warnEmoji} Mass DM Scraper Suspect Detected`)
    .setDescription(
      `> **Suspect Account:** <@${userId}> (\`${userId}\`)\n` +
      `> **Behavior:** Member joined and departed in **${duration}s** (Mass DM scrape threshold: ≤ 60s).\n` +
      `> **Classification:** Suspected automated Mass DM bot or unauthorized server member scraper.\n` +
      `> **Action Taken:** Flagged in guild raid log for audit tracking.`
    )
    .setFooter({ text: 'Tungsten Mass DM Sentinel • Anti-Scrape Monitor' })
    .setTimestamp();

  await secChannel.send({ embeds: [embed] }).catch(() => null);
}

/**
 * Checks sliding window join velocity for a guild.
 * @param {string} guildId
 * @param {number} [windowSeconds=60]
 * @returns {{count: number, raidDetected: boolean, windowSeconds: number}}
 */
function checkJoinRaid(guildId, windowSeconds = 60) {
  if (!guildId) return { count: 0, raidDetected: false, windowSeconds };
  const gid = String(guildId).trim();
  const sdb = getServerDb(gid);
  ensureRaidTable(sdb);

  const now = Math.floor(Date.now() / 1000);
  const start = now - windowSeconds;

  const row = sdb.prepare(`
    SELECT COUNT(*) AS count FROM join_raid_log
    WHERE guild_id = ? AND joined_at >= ?
  `).get(gid, start);

  const count = Number(row?.count) || 0;
  return {
    count,
    raidDetected: count >= 10,
    windowSeconds
  };
}

/**
 * Checks if a specific user was flagged as a Mass DM quick-leaver in this guild.
 * @param {string} guildId
 * @param {string} userId
 * @returns {boolean}
 */
function checkMassDm(guildId, userId) {
  if (!guildId || !userId) return false;
  const gid = String(guildId).trim();
  const uid = String(userId).trim();
  const sdb = getServerDb(gid);
  ensureRaidTable(sdb);

  const row = sdb.prepare(`
    SELECT id FROM join_raid_log
    WHERE guild_id = ? AND user_id = ? AND flagged = 1
    LIMIT 1
  `).get(gid, uid);

  return Boolean(row);
}

/**
 * Clears the raid log for a guild (maintenance / test cleanup).
 * @param {string} guildId
 * @returns {number} Number of deleted rows
 */
function clearRaidLog(guildId) {
  if (!guildId) return 0;
  const gid = String(guildId).trim();
  const sdb = getServerDb(gid);
  ensureRaidTable(sdb);

  const res = sdb.prepare('DELETE FROM join_raid_log WHERE guild_id = ?').run(gid);
  return res.changes;
}

/**
 * Integrated helper for guildMemberAdd event
 * @param {object} member
 * @param {object} client
 * @returns {Promise<{raidDetected: boolean, count: number}>}
 */
async function handleRaidOnJoin(member, client) {
  if (!member || !member.guild || !member.id) {
    return { raidDetected: false, count: 0 };
  }
  return recordMemberJoin(member.guild.id, member.id, member.guild);
}

/**
 * Integrated helper for guildMemberRemove event
 * @param {object} member
 * @param {object} client
 * @returns {Promise<{flagged: boolean, duration: number|null}>}
 */
async function handleRaidOnLeave(member, client) {
  if (!member || !member.guild || !member.id) {
    return { flagged: false, duration: null };
  }
  return recordMemberLeave(member.guild.id, member.id, member.guild);
}

module.exports = {
  recordMemberJoin,
  recordMemberLeave,
  checkJoinRaid,
  checkMassDm,
  clearRaidLog,
  handleRaidOnJoin,
  handleRaidOnLeave,
  ensureRaidTable,
  resolveSecurityLogChannel
};
