/**
 * Tungsten Threat Intelligence & Cross-Server Defense Sentinel (Feature 3)
 * Shared Crossban & Threat Registry across all Tungsten-protected servers.
 */
const { EmbedBuilder } = require('discord.js');
const { getMasterDb, getServerDb } = require('./serverDb');
const { resolveEmoji } = require('./emojis');
const config = require('../config');

/**
 * Ensures the global threat tables exist in master tungsten.db
 */
function ensureThreatTable(db) {
  if (!db) db = getMasterDb();
  db.exec(`
    CREATE TABLE IF NOT EXISTS global_threat_registry (
      user_id TEXT PRIMARY KEY,
      first_flagged INTEGER NOT NULL,
      last_flagged INTEGER NOT NULL,
      flag_count INTEGER DEFAULT 1,
      offense_types TEXT DEFAULT '[]',
      source_guilds TEXT DEFAULT '[]'
    );

    CREATE TABLE IF NOT EXISTS global_threats (
      user_id TEXT PRIMARY KEY,
      first_flagged INTEGER NOT NULL,
      last_flagged INTEGER NOT NULL,
      flag_count INTEGER DEFAULT 1,
      offense_types TEXT DEFAULT '[]',
      source_guilds TEXT DEFAULT '[]'
    );
  `);
}

/**
 * Records or updates a threat actor in the global threat registry.
 * @param {string} userId - Discord user snowflake
 * @param {string} [offenseType='antinuke_ban'] - Violation category (e.g. 'antinuke_ban', 'mass_ban', 'bot_add')
 * @param {string} [guildId=null] - Server where infraction occurred
 * @returns {object|null} Updated threat record
 */
function recordGlobalThreat(userId, offenseType = 'antinuke_ban', guildId = null) {
  if (!userId) return null;
  const uid = String(userId).trim();
  if (!uid) return null;

  const db = getMasterDb();
  ensureThreatTable(db);

  const now = Math.floor(Date.now() / 1000);
  const normalizedOffense = offenseType ? String(offenseType).trim() : 'antinuke_ban';
  const gidStr = guildId ? String(guildId).trim() : null;

  let existing = null;
  try {
    existing = db.prepare('SELECT * FROM global_threat_registry WHERE user_id = ?').get(uid);
  } catch (e) {
    ensureThreatTable(db);
    existing = db.prepare('SELECT * FROM global_threat_registry WHERE user_id = ?').get(uid);
  }

  if (!existing) {
    const offenses = normalizedOffense ? [normalizedOffense] : ['antinuke_ban'];
    const sources = gidStr ? [gidStr] : [];
    const offensesJson = JSON.stringify(offenses);
    const sourcesJson = JSON.stringify(sources);

    db.prepare(`
      INSERT OR REPLACE INTO global_threat_registry (user_id, first_flagged, last_flagged, flag_count, offense_types, source_guilds)
      VALUES (?, ?, ?, 1, ?, ?)
    `).run(uid, now, now, offensesJson, sourcesJson);

    // Keep global_threats synchronized
    try {
      db.prepare(`
        INSERT OR REPLACE INTO global_threats (user_id, first_flagged, last_flagged, flag_count, offense_types, source_guilds)
        VALUES (?, ?, ?, 1, ?, ?)
      `).run(uid, now, now, offensesJson, sourcesJson);
    } catch (e) {}

    return {
      user_id: uid,
      first_flagged: now,
      last_flagged: now,
      flag_count: 1,
      offense_types: offensesJson,
      source_guilds: sourcesJson,
      offenses,
      sourceGuilds: sources
    };
  }

  // Parse offenses list
  let offenses = [];
  try {
    offenses = JSON.parse(existing.offense_types);
  } catch (e) {
    offenses = [];
  }
  if (!Array.isArray(offenses)) offenses = [];
  if (normalizedOffense && !offenses.includes(normalizedOffense)) {
    offenses.push(normalizedOffense);
  }

  // Parse source guilds list
  let sources = [];
  try {
    sources = JSON.parse(existing.source_guilds);
  } catch (e) {
    sources = [];
  }
  if (!Array.isArray(sources)) sources = [];
  if (gidStr && !sources.includes(gidStr)) {
    sources.push(gidStr);
  }

  const newCount = (Number(existing.flag_count) || 1) + 1;
  const offensesJson = JSON.stringify(offenses);
  const sourcesJson = JSON.stringify(sources);

  db.prepare(`
    UPDATE global_threat_registry
    SET last_flagged = ?, flag_count = ?, offense_types = ?, source_guilds = ?
    WHERE user_id = ?
  `).run(now, newCount, offensesJson, sourcesJson, uid);

  // Keep global_threats synchronized
  try {
    db.prepare(`
      INSERT OR REPLACE INTO global_threats (user_id, first_flagged, last_flagged, flag_count, offense_types, source_guilds)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(uid, existing.first_flagged, now, newCount, offensesJson, sourcesJson);
  } catch (e) {}

  return {
    user_id: uid,
    first_flagged: existing.first_flagged,
    last_flagged: now,
    flag_count: newCount,
    offense_types: offensesJson,
    source_guilds: sourcesJson,
    offenses,
    sourceGuilds: sources
  };
}

/**
 * Checks if a user is flagged in the global threat registry.
 * @param {string} userId - Discord user snowflake
 * @returns {object|null} Threat record or null if not flagged
 */
function checkGlobalThreat(userId) {
  if (!userId) return null;
  const uid = String(userId).trim();
  if (!uid) return null;

  const db = getMasterDb();
  ensureThreatTable(db);

  let row = null;
  try {
    row = db.prepare('SELECT * FROM global_threat_registry WHERE user_id = ?').get(uid);
  } catch (e) {
    try {
      row = db.prepare('SELECT * FROM global_threats WHERE user_id = ?').get(uid);
    } catch (err) {
      return null;
    }
  }

  if (!row) {
    try {
      row = db.prepare('SELECT * FROM global_threats WHERE user_id = ?').get(uid);
    } catch (e) {}
  }

  if (!row) return null;

  let offenses = [];
  try {
    offenses = JSON.parse(row.offense_types);
  } catch (e) {
    offenses = [];
  }
  if (!Array.isArray(offenses)) offenses = [];

  let sourceGuilds = [];
  try {
    sourceGuilds = JSON.parse(row.source_guilds);
  } catch (e) {
    sourceGuilds = [];
  }
  if (!Array.isArray(sourceGuilds)) sourceGuilds = [];

  return {
    user_id: row.user_id,
    first_flagged: row.first_flagged,
    last_flagged: row.last_flagged,
    flag_count: Number(row.flag_count) || 1,
    offense_types: row.offense_types,
    source_guilds: row.source_guilds,
    offenses,
    sourceGuilds
  };
}

/**
 * Clears a user from the global threat registry (administrative unflagging)
 * @param {string} userId
 * @returns {boolean}
 */
function clearGlobalThreat(userId) {
  if (!userId) return false;
  const uid = String(userId).trim();
  const db = getMasterDb();
  ensureThreatTable(db);

  let changes = 0;
  try {
    const res1 = db.prepare('DELETE FROM global_threat_registry WHERE user_id = ?').run(uid);
    changes += res1.changes;
  } catch (e) {}
  try {
    const res2 = db.prepare('DELETE FROM global_threats WHERE user_id = ?').run(uid);
    changes += res2.changes;
  } catch (e) {}

  return changes > 0;
}

/**
 * Resolves the designated security/mod log channel for a guild.
 * @param {object} guild
 * @returns {Promise<object|null>}
 */
async function resolveSecurityLogChannel(guild) {
  if (!guild || !guild.id) return null;
  try {
    const sdb = getServerDb(guild.id);
    const row = sdb.prepare(`
      SELECT value FROM server_settings
      WHERE key IN ('log_security', 'security_log_channel', 'log_mod', 'log_server', 'audit_log_channel', 'log_channel', 'modlog_channel')
      ORDER BY CASE key
        WHEN 'log_security' THEN 1
        WHEN 'security_log_channel' THEN 2
        WHEN 'log_mod' THEN 3
        WHEN 'audit_log_channel' THEN 4
        WHEN 'log_server' THEN 5
        WHEN 'log_channel' THEN 6
        WHEN 'modlog_channel' THEN 7
        ELSE 8
      END
      LIMIT 1
    `).get();

    if (row && row.value) {
      const ch = guild.channels?.cache?.get(row.value)
        || (guild.channels?.fetch ? await guild.channels.fetch(row.value).catch(() => null) : null);
      if (ch && ch.isTextBased && typeof ch.send === 'function') {
        return ch;
      }
    }
  } catch (e) {}
  return null;
}

/**
 * Handles cross-server threat evaluation when a member joins.
 * Executes owner DM, security channel alert, and optional threat_auto_action ('kick' or 'ban').
 * @param {object} member - Discord GuildMember
 * @param {object} client - TungstenClient
 * @returns {Promise<{flagged: boolean, actionTaken: string|null, threat: object|null}>}
 */
async function handleThreatOnJoin(member, client) {
  if (!member || !member.guild || !member.id) {
    return { flagged: false, actionTaken: null, threat: null };
  }

  const guild = member.guild;
  const threat = checkGlobalThreat(member.id);
  if (!threat) {
    return { flagged: false, actionTaken: null, threat: null };
  }

  const sdb = getServerDb(guild.id);
  const otherGuilds = threat.sourceGuilds.filter(gid => gid !== guild.id);
  const serverCount = otherGuilds.length > 0 ? otherGuilds.length : (threat.sourceGuilds.length || 1);
  const userTag = member.user?.tag || member.user?.username || member.id;

  const warnEmoji = resolveEmoji(client, 'warning') || resolveEmoji(guild, 'warning') || '<a:tungsten_warn:1567246685082746940>';
  const shieldEmoji = resolveEmoji(client, 'shield') || resolveEmoji(guild, 'shield') || '<a:tungsten_shield:1567242104923627574>';
  const banEmoji = resolveEmoji(client, 'an_ban') || resolveEmoji(client, 'ban') || '<a:tungsten_an_ban:1567232483743895684>';

  // Check threat_auto_action setting in server_settings
  let autoAction = '';
  try {
    const actionRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'threat_auto_action'").get();
    if (actionRow && actionRow.value) {
      autoAction = String(actionRow.value).toLowerCase().trim();
    }
  } catch (e) {}

  let actionTaken = null;
  const auditReason = `[Tungsten Threat Intelligence] Auto-sanction: user flagged for antinuke violations across ${serverCount} Tungsten-protected servers.`;

  if (autoAction === 'ban') {
    try {
      if (member.bannable && typeof member.ban === 'function') {
        await member.ban({ deleteMessageSeconds: 86400, reason: auditReason });
        actionTaken = 'ban';
      } else if (guild.bans?.create) {
        const res = await guild.bans.create(member.id, { reason: auditReason }).catch(() => null);
        if (res) actionTaken = 'ban';
      }
    } catch (banErr) {
      console.warn(`[Threat Intelligence] Failed to auto-ban ${member.id} in ${guild.id}:`, banErr.message);
    }
  } else if (autoAction === 'kick') {
    try {
      if (member.kickable && typeof member.kick === 'function') {
        await member.kick(auditReason);
        actionTaken = 'kick';
      }
    } catch (kickErr) {
      console.warn(`[Threat Intelligence] Failed to auto-kick ${member.id} in ${guild.id}:`, kickErr.message);
    }
  }

  // 1. Direct Message Server Owner
  try {
    const ownerUser = guild.members?.cache?.get(guild.ownerId)?.user
      || (guild.fetchOwner ? (await guild.fetchOwner().catch(() => null))?.user : null)
      || (client?.users?.fetch ? await client.users.fetch(guild.ownerId).catch(() => null) : null);

    if (ownerUser && typeof ownerUser.send === 'function') {
      const offensesList = threat.offenses.length > 0
        ? threat.offenses.map(o => `\`${o}\``).join(', ')
        : '`antinuke_ban`';

      const dmContent = `${warnEmoji} **Threat Intelligence Sentinel • ${guild.name}**\n` +
        `User **${userTag}** (\`${member.id}\`) has been flagged for antinuke violations in **${serverCount}** other Tungsten-protected servers.\n` +
        `> **Total Violations Logged:** \`${threat.flag_count}\`\n` +
        `> **Recorded Infraction Vectors:** ${offensesList}\n` +
        (actionTaken
          ? `> **Automated Sanction:** \`${actionTaken.toUpperCase()}\` executed automatically via server \`threat_auto_action\`.\n`
          : `> **Status:** Account allowed to join (threat_auto_action: not set).\n> **Recommended Action:** Monitor closely or ban via \`/ban ${member.id}\`.\n`);

      await ownerUser.send({ content: dmContent }).catch(() => null);
    }
  } catch (ownerDmErr) {
    // Suppress failed DMs due to closed DMs
  }

  // 2. Post Alert to Security Log Channel
  try {
    const secChannel = await resolveSecurityLogChannel(guild);
    if (secChannel) {
      const offensesList = threat.offenses.length > 0
        ? threat.offenses.map(o => `\`${o}\``).join(', ')
        : '`antinuke_ban`';

      const embed = new EmbedBuilder()
        .setColor(actionTaken ? config.COLORS.DANGER : config.COLORS.WARNING)
        .setTitle(`${shieldEmoji} Shared Threat Intelligence Alert: Flagged User Detected`)
        .setDescription(
          `> **Flagged User:** <@${member.id}> (\`${userTag}\` • \`${member.id}\`)\n` +
          `> **Global Flags:** \`${threat.flag_count}\` antinuke violations across \`${serverCount}\` other protected servers\n` +
          `> **Infraction Types:** ${offensesList}\n` +
          `> **First Logged:** <t:${threat.first_flagged}:R> • **Last Logged:** <t:${threat.last_flagged}:R>\n` +
          (actionTaken
            ? `> **Automated Action:** ${banEmoji} Member automatically **${actionTaken.toUpperCase()}NED** on entry.`
            : `> **Status:** No automatic sanction applied. Server policy \`threat_auto_action\` is inactive.`)
        )
        .setFooter({ text: 'Tungsten Shared Threat Intelligence Network' })
        .setTimestamp();

      await secChannel.send({ embeds: [embed] }).catch(() => null);
    }
  } catch (channelAlertErr) {}

  return { flagged: true, actionTaken, threat };
}

module.exports = {
  recordGlobalThreat,
  reportGlobalThreat: recordGlobalThreat,
  checkGlobalThreat,
  clearGlobalThreat,
  resolveSecurityLogChannel,
  handleThreatOnJoin,
  ensureThreatTable
};
