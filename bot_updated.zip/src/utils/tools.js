/**
 * Tungsten Core Utilities & Database Helpers (Node.js)
 */
const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const config = require('../config');
const { getServerDb, getMasterDb, getGuildAccent } = require('./serverDb');
const { replaceEmojis } = require('./emojis');

const _CONFIG_CACHE = new Map();
const _BLACKLIST_CACHE = new Map();
const _NOPREFIX_CACHE = new Map();
const CACHE_TTL = 60000; // 60s memory cache
const NOPREFIX_CACHE_TTL = 30000; // 30s high-speed memory cache

function invalidateNoPrefixCache(userId = null) {
  if (!userId) {
    _NOPREFIX_CACHE.clear();
  } else {
    const uid = String(userId);
    for (const k of _NOPREFIX_CACHE.keys()) {
      if (k.startsWith(uid)) _NOPREFIX_CACHE.delete(k);
    }
  }
}

const _OWNER_SET = new Set();
const _NP_MANAGER_SET = new Set();

function refreshOwners() {
  try {
    _OWNER_SET.clear();
    const envOwners = (process.env.OWNER_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
    for (const id of [...(config.OWNER_IDS || []), ...envOwners]) {
      if (id) {
        _OWNER_SET.add(String(id));
      }
    }
    const mdb = getMasterDb();
    const rows = mdb.prepare("SELECT user_id FROM bot_owners").all();
    for (const r of rows) {
      if (r.user_id) _OWNER_SET.add(String(r.user_id));
    }
    const npRows = mdb.prepare('SELECT user_id FROM np_managers').all();
    _NP_MANAGER_SET.clear();
    for (const r of npRows) {
      _NP_MANAGER_SET.add(String(r.user_id));
    }
  } catch (e) {}
}

refreshOwners();

function isOwner(userId) {
  if (!userId) return false;
  return _OWNER_SET.has(String(userId));
}

function isServerOwner(guild, userId) {
  if (!guild || !userId) return false;
  const uid = String(userId);
  return guild.ownerId === uid;
}

function isExtraOwner(guildId, userId) {
  if (!guildId || !userId) return false;
  const gid = typeof guildId === 'object' && guildId.id ? String(guildId.id) : String(guildId);
  const uid = String(userId);
  try {
    const { getServerDb } = require('./serverDb');
    const sdb = getServerDb(gid);
    const row = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(gid, uid);
    return Boolean(row);
  } catch (e) {
    return false;
  }
}

function isNpManager(userId) {
  if (!userId) return false;
  if (isOwner(userId)) return true;
  const uid = String(userId);
  if (_NP_MANAGER_SET.has(uid)) return true;
  try {
    const row = getMasterDb().prepare('SELECT 1 FROM np_managers WHERE user_id = ?').get(uid);
    if (row) {
      _NP_MANAGER_SET.add(uid);
      return true;
    }
  } catch (e) {}
  return false;
}

function parseDuration(str) {
  if (!str) return { seconds: -1, days: -1, text: 'Lifetime / Permanent' };
  const s = String(str).trim().toLowerCase();
  if (['lifetime', 'permanent', 'perm', 'forever', 'infinite', 'always', 'life', '-1'].includes(s)) {
    return { seconds: -1, days: -1, text: 'Lifetime / Permanent' };
  }
  const match = s.match(/^(\d+)\s*(s|sec|secs|m|min|mins|h|hr|hrs|hour|hours|d|day|days|w|wk|wks|week|weeks|mo|mon|month|months|y|yr|years)$/);
  if (!match) return null;
  const num = parseInt(match[1], 10);
  const unit = match[2];
  let multiplier = 86400;
  let unitText = 'Days';

  if (unit.startsWith('s')) { multiplier = 1; unitText = 'Seconds'; }
  else if (unit.startsWith('m') && !unit.startsWith('mo')) { multiplier = 60; unitText = 'Minutes'; }
  else if (unit.startsWith('h')) { multiplier = 3600; unitText = 'Hours'; }
  else if (unit.startsWith('d')) { multiplier = 86400; unitText = 'Days'; }
  else if (unit.startsWith('w')) { multiplier = 7 * 86400; unitText = 'Weeks'; }
  else if (unit.startsWith('mo')) { multiplier = 30 * 86400; unitText = 'Months'; }
  else if (unit.startsWith('y')) { multiplier = 365 * 86400; unitText = 'Years'; }

  const totalSecs = num * multiplier;
  const days = Math.round(totalSecs / 86400);
  return { seconds: totalSecs, days, text: `${num} ${unitText}` };
}

function isNoPrefix(userId, guildId = null, member = null) {
  if (!userId) return false;
  if (isOwner(userId) || isNpManager(userId)) return true;
  const uid = String(userId);
  const gid = guildId ? String(guildId) : 'global';
  const cacheKey = `${uid}:${gid}`;
  const now = Date.now();
  const cached = _NOPREFIX_CACHE.get(cacheKey);
  if (cached && (now - cached.ts < NOPREFIX_CACHE_TTL)) {
    return cached.allowed;
  }

  let allowed = false;

  // 1. Check global noprefix_users in master.db
  try {
    const mdb = getMasterDb();
    const gRow = mdb.prepare('SELECT expires_at FROM noprefix_users WHERE user_id = ?').get(uid);
    if (gRow) {
      if (gRow.expires_at === null || gRow.expires_at === undefined || gRow.expires_at === -1 || gRow.expires_at > Math.floor(now / 1000)) {
        allowed = true;
      }
    }
  } catch (e) {}

  // 2. Check guild-level noprefix access
  if (!allowed && guildId) {
    try {
      const sdb = getServerDb(guildId);
      const uRow = sdb.prepare('SELECT 1 FROM guild_noprefix_access WHERE guild_id = ? AND target_id = ?').get(String(guildId), uid);
      if (uRow) {
        allowed = true;
      } else if (member && member.roles && member.roles.cache) {
        for (const roleId of member.roles.cache.keys()) {
          const rRow = sdb.prepare('SELECT 1 FROM guild_noprefix_access WHERE guild_id = ? AND target_id = ? AND is_role = 1').get(String(guildId), String(roleId));
          if (rRow) {
            allowed = true;
            break;
          }
        }
      }
    } catch (e) {}
  }

  _NOPREFIX_CACHE.set(cacheKey, { allowed, ts: now });
  return allowed;
}

function getConfig(guildId) {
  const gid = String(guildId);
  const now = Date.now();
  const cached = _CONFIG_CACHE.get(gid);
  if (cached && (now - cached.ts < CACHE_TTL)) {
    return cached.data;
  }

  const result = {
    prefix: config.DEFAULT_PREFIX,
    guild_id: gid
  };

  try {
    const sdb = getServerDb(gid);
    const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get('prefix');
    if (row && row.value) {
      result.prefix = row.value;
      _CONFIG_CACHE.set(gid, { data: result, ts: now });
      return result;
    }
  } catch (e) {}

  // Fallback to master db if exists
  try {
    const mdb = getMasterDb();
    const row = mdb.prepare('SELECT prefix FROM prefix WHERE guild_id = ?').get(gid);
    if (row && row.prefix) {
      result.prefix = row.prefix;
    }
  } catch (e) {}

  _CONFIG_CACHE.set(gid, { data: result, ts: now });
  return result;
}

function setPrefix(guildId, newPrefix) {
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('prefix', newPrefix);

  // Update memory cache instantly
  _CONFIG_CACHE.set(gid, { data: { prefix: newPrefix, guild_id: gid }, ts: Date.now() });

  // Dual-write to master for redundancy
  try {
    const mdb = getMasterDb();
    mdb.prepare('INSERT OR REPLACE INTO prefix (guild_id, prefix) VALUES (?, ?)').run(gid, newPrefix);
  } catch (e) {}
  return true;
}

/**
 * H4: Key cache by `${guildId}:${userId}` so allowed users in guild A are not incorrectly cached in guild B
 */
function blacklistCheck(userId, guildId = null) {
  const uid = String(userId);
  if (isOwner(uid)) return true; // Owners bypass blacklist

  const gidStr = guildId ? String(guildId) : 'global';
  const cacheKey = `${gidStr}:${uid}`;
  const now = Date.now();
  const cached = _BLACKLIST_CACHE.get(cacheKey);
  if (cached && (now - cached.ts < CACHE_TTL)) {
    return cached.allowed;
  }

  let allowed = true;
  try {
    const mdb = getMasterDb();
    // Check master blacklist tables
    const userRow = mdb.prepare('SELECT 1 FROM blacklist_users WHERE user_id = ?').get(uid)
      || mdb.prepare('SELECT 1 FROM blacklist WHERE user_id = ?').get(uid);
    if (userRow) allowed = false;

    if (allowed && guildId) {
      const guildRow = mdb.prepare('SELECT 1 FROM blacklist_guilds WHERE guild_id = ?').get(String(guildId))
        || mdb.prepare('SELECT 1 FROM guild_blacklist WHERE guild_id = ?').get(String(guildId));
      if (guildRow) allowed = false;
    }
  } catch (e) {}

  _BLACKLIST_CACHE.set(cacheKey, { allowed, ts: now });
  return allowed;
}

const _IGNORE_CACHE = new Map();
const IGNORE_TTL = 60000;

function ignoreCheck(channelId, commandName = '') {
  const cid = String(channelId);
  const now = Date.now();

  const cached = _IGNORE_CACHE.get(cid);
  if (cached) {
    if (now - cached.ts < IGNORE_TTL) return !cached.ignored;
    _IGNORE_CACHE.delete(cid);
  }

  let ignored = false;
  try {
    const mdb = getMasterDb();
    const row = mdb.prepare('SELECT 1 FROM ignore WHERE channel_id = ?').get(cid);
    if (row) ignored = true;
  } catch (e) {}

  _IGNORE_CACHE.set(cid, { ignored, ts: now });
  return !ignored;
}

/**
 * Strips custom emoji tags <a?:name:id> so Discord doesn't render raw literal text in embed title, author, or footer.
 */
function stripCustomEmojiTags(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/<a?:[a-zA-Z0-9_]+:[^>]+>/g, '').replace(/\s{2,}/g, ' ').trim();
}

function createEmbed(options = {}) {
  // Across the UI, no embed colors must be used: color is omitted entirely (no stripe/bar)
  const embed = new EmbedBuilder();

  if (options.title) {
    let cleanTitle = typeof options.title === 'string' ? options.title : String(options.title);
    if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(cleanTitle)) {
      cleanTitle = stripCustomEmojiTags(cleanTitle);
    }
    embed.setTitle(cleanTitle || 'Tungsten');
  }

  if (options.description) embed.setDescription(replaceEmojis(null, options.description));
  if (options.url) embed.setURL(options.url);

  if (options.author) {
    if (typeof options.author === 'string') {
      let authorName = options.author;
      if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(authorName)) {
        authorName = stripCustomEmojiTags(authorName);
      }
      embed.setAuthor({ name: authorName || 'Tungsten' });
    } else if (options.author.name) {
      let authorName = String(options.author.name);
      if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(authorName)) {
        authorName = stripCustomEmojiTags(authorName);
      }
      embed.setAuthor({
        ...options.author,
        name: authorName || 'Tungsten'
      });
    } else {
      embed.setAuthor(options.author);
    }
  }

  if (options.thumbnail) embed.setThumbnail(options.thumbnail);
  if (options.image) embed.setImage(options.image);
  if (options.timestamp) embed.setTimestamp(options.timestamp === true ? new Date() : options.timestamp);

  if (options.footer) {
    if (typeof options.footer === 'string') {
      let footerText = options.footer;
      if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(footerText)) {
        footerText = stripCustomEmojiTags(footerText);
      }
      embed.setFooter({ text: footerText || 'Tungsten' });
    } else if (options.footer.text) {
      let footerText = String(options.footer.text);
      if (/<a?:[a-zA-Z0-9_]+:[^>]+>/.test(footerText)) {
        footerText = stripCustomEmojiTags(footerText);
      }
      embed.setFooter({
        ...options.footer,
        text: footerText || 'Tungsten'
      });
    } else {
      embed.setFooter(options.footer);
    }
  }

  if (options.fields && Array.isArray(options.fields)) {
    const sanitizedFields = options.fields.map(f => ({
      ...f,
      name: replaceEmojis(null, f.name),
      value: replaceEmojis(null, f.value)
    }));
    embed.addFields(sanitizedFields);
  }

  return embed;
}

/**
 * Safe permission check helper. Primary server owner and extra owners automatically pass.
 * Bot owners do NOT get automatic server permission bypass unless granted in server.
 * Does NOT mutate member.permissions object.
 */
function hasPerm(member, permission) {
  if (!member || !permission) return false;
  const uid = member.id || member.user?.id;
  const gid = member.guild?.id;
  if (uid && (member.guild?.ownerId === uid || isExtraOwner(gid, uid))) return true;
  if (!member.permissions) return false;
  try {
    if (typeof permission === 'string') {
      if (!PermissionsBitField.Flags[permission]) return false;
    }
    return member.permissions.has(permission);
  } catch (e) {
    return false;
  }
}

/**
 * Formats a timestamp into clean text time with AM/PM (e.g. "9:25 AM").
 * Uses local 12-hour clock time without dynamic Discord tags or extra symbols.
 */
function formatClockTime(dateOrMs) {
  let d;
  if (dateOrMs instanceof Date) {
    d = dateOrMs;
  } else if (typeof dateOrMs === 'number' || typeof dateOrMs === 'string') {
    const n = Number(dateOrMs);
    d = Number.isFinite(n) && n > 0 ? new Date(n) : new Date();
  } else {
    d = new Date();
  }
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

/**
 * Formats a timestamp into a clean Discord timestamp string (e.g. "<t:1700000000:R>").
 * Free of broken emojis and guaranteed valid format.
 *
 * @param {number|Date|string} dateOrMs
 * @param {'R'|'t'|'T'|'d'|'D'|'f'|'F'} [style='R']
 * @returns {string}
 */
function formatDiscordTimestamp(dateOrMs, style = 'R') {
  let sec;
  if (dateOrMs instanceof Date) {
    sec = Math.floor(dateOrMs.getTime() / 1000);
  } else {
    const num = Number(dateOrMs);
    if (!Number.isFinite(num) || num <= 0) {
      sec = Math.floor(Date.now() / 1000);
    } else {
      sec = num > 1e11 ? Math.floor(num / 1000) : Math.floor(num);
    }
  }
  return `<t:${sec}:${style}>`;
}

module.exports = {
  isOwner,
  isServerOwner,
  isExtraOwner,
  hasPerm,
  refreshOwners,
  isNoPrefix,
  invalidateNoPrefixCache,
  isNpManager,
  parseDuration,
  getConfig,
  setPrefix,
  blacklistCheck,
  ignoreCheck,
  createEmbed,
  stripCustomEmojiTags,
  formatClockTime,
  formatDiscordTimestamp
};
