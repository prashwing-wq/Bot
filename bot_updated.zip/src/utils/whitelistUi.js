/**
 * Tungsten Whitelist Interactive UI & Action Toggle Matrix
 * Provides granular action toggle panels with native Discord Components V2 Type 17 Containers
 * for Users, Roles, Channels, and Extra Owners.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  TextDisplayBuilder,
  EmbedBuilder,
  PermissionFlagsBits
} = require('discord.js');
const kit = require('../ui/kit');
const { ICONS } = require('../ui/icons');
const { COLORS } = require('../ui/tokens');
const {
  WHITELIST_SCOPES,
  SCOPES,
  isValidScope,
  getScope,
  isHighDangerScope,
  normalizeScope
} = require('../security/scopes');
const { invalidateBypassCache } = require('../security/resolveBypass');
const { clearImmunityCache } = require('./antinukeEngine');
const { syncServerDataToMaster } = require('./serverDb');

const SCOPE_KEYS = Object.freeze(Object.keys(WHITELIST_SCOPES).filter(k => k !== 'all'));
const LEGACY_ACTIONS = Object.freeze([
  'ban',
  'kick',
  'channel',
  'role',
  'bot',
  'webhook',
  'emoji',
  'server',
  'automod'
]);

const USER_ROLE_ACTIONS = Object.freeze([
  'all',
  ...SCOPE_KEYS,
  ...LEGACY_ACTIONS
]);

const CHANNEL_SCOPES = Object.freeze([
  'all',
  'automod_links',
  'automod_spam',
  'automod_words',
  'ping',
  'channels',
  'automod',
  'links',
  'spam',
  'antinuke'
]);

/**
 * Builds the interactive Target Action Whitelist Panel with real-time toggle buttons using kit.js.
 */
function buildTargetWhitelistPayload(guild, sdb, targetType, targetId, prefix = '!', options = {}) {
  const tid = String(targetId);
  const nowSec = Math.floor(Date.now() / 1000);
  const isEphemeral = Boolean(options && (options.isEphemeral || options.asEmbed));

  // 1. Resolve Target Details
  let targetMention = `\`${tid}\``;
  let targetName = `ID: ${tid}`;
  let roleMemberCount = 0;
  let hasAdmin = false;
  let roleManaged = false;
  let isEveryone = false;

  if (targetType === 'user' || targetType === 'extraowner') {
    const member = guild.members?.cache?.get(tid);
    if (member) {
      targetName = member.displayName || member.user?.username || `User ${tid}`;
      targetMention = `<@${tid}>`;
    } else {
      targetMention = `<@${tid}>`;
      targetName = `User ${tid}`;
    }
  } else if (targetType === 'role') {
    const role = guild.roles?.cache?.get(tid);
    if (role) {
      targetName = `@${role.name}`;
      targetMention = `<@&${tid}>`;
      roleMemberCount = role.members?.size || 0;
      roleManaged = Boolean(role.managed);
      isEveryone = role.id === guild.id;
      if (role.permissions && typeof role.permissions.has === 'function' && role.permissions.has(PermissionFlagsBits.Administrator)) {
        hasAdmin = true;
      }
    } else {
      targetMention = `<@&${tid}>`;
      targetName = `Role ${tid}`;
    }
  } else if (targetType === 'channel') {
    const channel = guild.channels?.cache?.get(tid);
    if (channel) {
      targetName = `#${channel.name}`;
      targetMention = `<#${tid}>`;
    } else {
      targetMention = `<#${tid}>`;
      targetName = `Channel ${tid}`;
    }
  }

  // 2. Fetch Active Actions & Expiry
  let activeActions = [];
  let isAllActive = false;
  let expiresAt = null;

  if (targetType === 'user') {
    const rows = sdb.prepare('SELECT action, expires_at FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').all(guild.id, tid);
    for (const r of rows) {
      if (!r.expires_at || r.expires_at > nowSec) {
        activeActions.push(r.action);
        if (r.expires_at) expiresAt = r.expires_at;
      }
    }
    isAllActive = activeActions.includes('all');
  } else if (targetType === 'role') {
    const rows = sdb.prepare('SELECT action, expires_at FROM whitelisted_roles WHERE guild_id = ? AND role_id = ?').all(guild.id, tid);
    for (const r of rows) {
      if (!r.expires_at || r.expires_at > nowSec) {
        activeActions.push(r.action);
        if (r.expires_at) expiresAt = r.expires_at;
      }
    }
    isAllActive = activeActions.includes('all');
  } else if (targetType === 'channel') {
    const rows = sdb.prepare('SELECT scope FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').all(guild.id, tid);
    activeActions = rows.map(r => r.scope);
    isAllActive = activeActions.includes('all');
  } else if (targetType === 'extraowner') {
    isAllActive = true;
  }

  // Helper to test if a specific action is authorized
  const isActActive = (act) => isAllActive || activeActions.includes(act);

  // 3. Build Header and Status
  const totalSpecificScopes = Object.keys(WHITELIST_SCOPES).filter(k => k !== 'all').length;
  const activeCount = isAllActive ? totalSpecificScopes : activeActions.filter(a => a !== 'all').length;

  let durationText = '';
  if (expiresAt) {
    if (expiresAt <= nowSec) {
      durationText = ' · expired';
    } else {
      durationText = ` · expires <t:${expiresAt}:R>`;
    }
  } else {
    durationText = ' · permanent';
  }

  let statusText = '';
  if (targetType === 'extraowner') {
    statusText = 'Executive Co-Owner · 100% Antinuke Immunity';
  } else if (isAllActive) {
    statusText = `Full access · All ${totalSpecificScopes} scopes active${durationText}`;
  } else if (activeCount > 0) {
    statusText = `Custom access · ${activeCount} of ${totalSpecificScopes} scopes active${durationText}`;
  } else {
    statusText = `No access · 0 scopes active (standard enforcement)${durationText}`;
  }

  const title = `Whitelist · ${targetName}`;

  // 4. Facts List (Role blast radius and warnings)
  const factsList = [];
  if (targetType === 'role') {
    factsList.push(`Blast radius: **${roleMemberCount} member(s)** possess this role.`);
    if (hasAdmin) {
      factsList.push('Warning: Role possesses Administrator permissions.');
    }
    if (roleManaged) {
      factsList.push('Warning: Managed bot integration role.');
    }
    if (isEveryone) {
      factsList.push('Alert: Target is the @everyone role.');
    }
  }

  // 5. Scopes TextDisplay Summary
  let scopeStatusContent = '';
  if (targetType === 'user' || targetType === 'role') {
    const lines = [];
    lines.push(`**Master Protection:** ${isAllActive ? '[ACTIVE] Full Bypass Enabled' : '[ENFORCED] Standard Protection'}`);
    lines.push('');
    lines.push('**Granular Scope Statuses:**');
    for (const [scopeKey, def] of Object.entries(WHITELIST_SCOPES)) {
      if (scopeKey === 'all') continue;
      const isScopeActive = isActActive(scopeKey);
      lines.push(`• **${def.label}**: ${isScopeActive ? 'Allowed' : 'Enforced'}`);
    }
    scopeStatusContent = lines.join('\n');
  } else if (targetType === 'channel') {
    const lines = [];
    lines.push(`**Channel Bypass:** ${isAllActive ? '[ACTIVE] Full Channel Bypass' : '[ENFORCED] Standard Protection'}`);
    lines.push('');
    lines.push('**Active Channel Scopes:**');
    const channelScopeDefs = [
      { key: 'automod_links', label: 'Allowed Links & Invites' },
      { key: 'automod_spam', label: 'Anti-Spam & Flooding' },
      { key: 'automod_words', label: 'Banned Words & Leet' },
      { key: 'ping', label: 'Mass Mentions (@everyone / @here)' },
      { key: 'channels', label: 'Antinuke Channel Guard' }
    ];
    for (const sc of channelScopeDefs) {
      const isScActive = isAllActive || activeActions.includes(sc.key)
        || (sc.key === 'automod_links' && activeActions.includes('links'))
        || (sc.key === 'automod_spam' && activeActions.includes('spam'));
      lines.push(`• **${sc.label}**: ${isScActive ? 'Allowed' : 'Enforced'}`);
    }
    scopeStatusContent = lines.join('\n');
  } else if (targetType === 'extraowner') {
    scopeStatusContent = '**Executive Authority**\nTarget possesses complete antinuke immunity and bypass across all server security features.';
  }

  // 6. ActionRows: Master Toggle, Scope Select, Duration Picker & Navigation
  const rows = [];

  if (targetType === 'user' || targetType === 'role') {
    // Master Full Bypass Button
    const masterBtn = new ButtonBuilder()
      .setCustomId(`wl:act:${targetType}:${tid}:all`)
      .setLabel(isAllActive ? 'Revoke Full Bypass' : 'Full Bypass (All Vectors)')
      .setStyle(isAllActive ? ButtonStyle.Danger : ButtonStyle.Success);
    rows.push(new ActionRowBuilder().addComponents(masterBtn));

    // StringSelectMenu: wl:select_toggle_scope
    const scopeOptions = [];
    for (const [scopeKey, def] of Object.entries(WHITELIST_SCOPES)) {
      if (scopeKey === 'all') continue;
      const isScopeActive = isActActive(scopeKey);
      scopeOptions.push({
        label: def.label.slice(0, 100),
        description: (isScopeActive ? 'Currently: ALLOWED · Click to toggle' : 'Currently: ENFORCED · Click to toggle').slice(0, 100),
        value: scopeKey
      });
    }
    const scopeSelect = new StringSelectMenuBuilder()
      .setCustomId(`wl:select_toggle_scope:${targetType}:${tid}`)
      .setPlaceholder('Toggle specific security or automod scope...')
      .addOptions(scopeOptions);
    rows.push(new ActionRowBuilder().addComponents(scopeSelect));

    // Duration Picker Select Menu
    const durSelect = new StringSelectMenuBuilder()
      .setCustomId(`wl:dur:${targetType}:${tid}`)
      .setPlaceholder('Set temporary grant duration...')
      .addOptions([
        { label: 'Permanent', description: 'Grant never expires', value: 'perm' },
        { label: '1 Hour (3600s)', description: 'Expires in 1 hour', value: '3600' },
        { label: '24 Hours (86400s)', description: 'Expires in 24 hours', value: '86400' },
        { label: '7 Days (604800s)', description: 'Expires in 7 days', value: '604800' }
      ]);
    rows.push(new ActionRowBuilder().addComponents(durSelect));

    // Navigation Buttons
    const navRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`wl:hist:${targetType}:${tid}`)
        .setLabel('View History')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`wl:revoke:${targetType}:${tid}`)
        .setLabel('Revoke All')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('wl:back_studio')
        .setLabel('Back to Whitelist Studio')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(navRow);
  } else if (targetType === 'channel') {
    // Master Full Bypass Button
    const masterBtn = new ButtonBuilder()
      .setCustomId(`wl:act:channel:${tid}:all`)
      .setLabel(isAllActive ? 'Revoke Channel Bypass' : 'Full Channel Bypass')
      .setStyle(isAllActive ? ButtonStyle.Danger : ButtonStyle.Success);
    rows.push(new ActionRowBuilder().addComponents(masterBtn));

    // Channel Scopes Select Menu
    const channelScopeDefs = [
      { key: 'automod_links', label: 'Allowed Links & Invites' },
      { key: 'automod_spam', label: 'Anti-Spam & Flooding' },
      { key: 'automod_words', label: 'Banned Words & Leet' },
      { key: 'ping', label: 'Mass Mentions (@everyone / @here)' },
      { key: 'channels', label: 'Antinuke Channel Guard' }
    ];

    const channelScopeOptions = channelScopeDefs.map(sc => {
      const isScActive = isAllActive || activeActions.includes(sc.key)
        || (sc.key === 'automod_links' && activeActions.includes('links'))
        || (sc.key === 'automod_spam' && activeActions.includes('spam'));
      return {
        label: sc.label.slice(0, 100),
        description: (isScActive ? 'Currently: ALLOWED · Click to toggle' : 'Currently: ENFORCED · Click to toggle').slice(0, 100),
        value: sc.key
      };
    });

    const channelScopeSelect = new StringSelectMenuBuilder()
      .setCustomId(`wl:select_toggle_scope:channel:${tid}`)
      .setPlaceholder('Toggle specific channel bypass scope...')
      .addOptions(channelScopeOptions);
    rows.push(new ActionRowBuilder().addComponents(channelScopeSelect));

    // Navigation Buttons
    const navRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`wl:hist:channel:${tid}`)
        .setLabel('View History')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`wl:revoke:channel:${tid}`)
        .setLabel('Revoke Channel')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('wl:back_studio')
        .setLabel('Back to Whitelist Studio')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(navRow);
  } else if (targetType === 'extraowner') {
    const navRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`eo:revoke:${tid}`)
        .setLabel('Demote Extra Owner')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('wl:back_studio')
        .setLabel('Back to Whitelist Studio')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(navRow);
  }

  // 7. Ephemeral Fallback Handling
  if (isEphemeral) {
    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(`-# Target: ${targetMention} (\`${tid}\`)\n**Status:** ${statusText}`)
      .setColor((isAllActive || activeActions.length > 0) ? 0x2ecc71 : 0x95a5a6);

    if (factsList.length > 0) {
      embed.addFields({ name: 'Security Notice', value: factsList.join('\n') });
    }

    if (scopeStatusContent) {
      embed.addFields({ name: 'Scopes & Bypass Status', value: scopeStatusContent.slice(0, 1024) });
    }

    return {
      embeds: [embed],
      components: rows.slice(0, 5)
    };
  }

  return kit.panel({
    title,
    status: statusText,
    description: `-# Target: ${targetMention} (\`${tid}\`)`,
    facts: factsList.length > 0 ? factsList : null,
    containerComponents: [
      new TextDisplayBuilder().setContent(scopeStatusContent)
    ],
    rows,
    color: (isAllActive || activeActions.length > 0) ? COLORS.success : COLORS.neutral
  });
}

/**
 * Toggles an action on or off for a given target.
 */
function toggleWhitelistAction(guildId, sdb, targetType, targetId, actionInput, operatorId) {
  const tid = String(targetId);
  const action = String(actionInput || '').trim().toLowerCase();
  const nowSec = Math.floor(Date.now() / 1000);

  let specificActions = SCOPE_KEYS;
  if (LEGACY_ACTIONS.includes(action)) {
    specificActions = LEGACY_ACTIONS;
  }

  const runTx = sdb.transaction(() => {
    if (targetType === 'user' || targetType === 'role') {
      const table = targetType === 'user' ? 'whitelisted_users' : 'whitelisted_roles';
      const idCol = targetType === 'user' ? 'user_id' : 'role_id';

      const currentRows = sdb.prepare(`SELECT action, expires_at FROM ${table} WHERE guild_id = ? AND ${idCol} = ?`).all(guildId, tid);
      const currentActions = currentRows.map(r => r.action);
      const hasAll = currentActions.includes('all');
      const existingExpiresAt = currentRows.find(r => r.expires_at)?.expires_at || null;

      if (action === 'all') {
        if (hasAll) {
          // Toggle OFF all
          sdb.prepare(`DELETE FROM ${table} WHERE guild_id = ? AND ${idCol} = ?`).run(guildId, tid);
          sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run(guildId, targetType, tid, 'all', operatorId, 'revoke_all', nowSec);
        } else {
          // Toggle ON all: delete any specific rows and set 'all'
          sdb.prepare(`DELETE FROM ${table} WHERE guild_id = ? AND ${idCol} = ?`).run(guildId, tid);
          sdb.prepare(`INSERT INTO ${table} (guild_id, ${idCol}, action, expires_at, added_by) VALUES (?, ?, 'all', ?, ?)`).run(guildId, tid, existingExpiresAt, operatorId);
          sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run(guildId, targetType, tid, 'all', operatorId, 'grant_all', nowSec);
        }
      } else {
        // Specific action clicked (e.g. 'roles', 'members', 'channels')
        if (hasAll) {
          // Expand 'all' into all other specific scopes EXCEPT this one
          sdb.prepare(`DELETE FROM ${table} WHERE guild_id = ? AND ${idCol} = ?`).run(guildId, tid);
          for (const act of specificActions) {
            if (act !== action) {
              sdb.prepare(`INSERT INTO ${table} (guild_id, ${idCol}, action, expires_at, added_by) VALUES (?, ?, ?, ?, ?)`).run(guildId, tid, act, existingExpiresAt, operatorId);
            }
          }
          sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run(guildId, targetType, tid, action, operatorId, 'disable_action', nowSec);
        } else {
          const isPresent = currentActions.includes(action);
          if (isPresent) {
            // Remove this action
            sdb.prepare(`DELETE FROM ${table} WHERE guild_id = ? AND ${idCol} = ? AND action = ?`).run(guildId, tid, action);
            sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
              .run(guildId, targetType, tid, action, operatorId, 'revoke_action', nowSec);
          } else {
            // Add this action (do not silently auto-promote to 'all' — explicit grants only)
            sdb.prepare(`INSERT OR REPLACE INTO ${table} (guild_id, ${idCol}, action, expires_at, added_by) VALUES (?, ?, ?, ?, ?)`).run(guildId, tid, action, existingExpiresAt, operatorId);
            sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
              .run(guildId, targetType, tid, action, operatorId, 'grant_action', nowSec);
          }
        }
      }
    } else if (targetType === 'channel') {
      const channelScopes = ['automod_links', 'automod_spam', 'automod_words', 'ping', 'channels'];
      const currentRows = sdb.prepare('SELECT scope FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').all(guildId, tid);
      const currentScopes = currentRows.map(r => r.scope);
      const hasAll = currentScopes.includes('all');

      if (action === 'all') {
        if (hasAll) {
          sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').run(guildId, tid);
          sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run(guildId, 'channel', tid, 'all', operatorId, 'revoke_all', nowSec);
        } else {
          sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').run(guildId, tid);
          sdb.prepare("INSERT INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at) VALUES (?, ?, 'all', ?, ?)").run(guildId, tid, operatorId, nowSec);
          sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run(guildId, 'channel', tid, 'all', operatorId, 'grant_all', nowSec);
        }
      } else {
        if (hasAll) {
          sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').run(guildId, tid);
          for (const sc of channelScopes) {
            if (sc !== action) {
              sdb.prepare('INSERT INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at) VALUES (?, ?, ?, ?, ?)').run(guildId, tid, sc, operatorId, nowSec);
            }
          }
          sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run(guildId, 'channel', tid, action, operatorId, 'disable_scope', nowSec);
        } else {
          const isPresent = currentScopes.includes(action);
          if (isPresent) {
            sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ? AND scope = ?').run(guildId, tid, action);
            sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
              .run(guildId, 'channel', tid, action, operatorId, 'revoke_scope', nowSec);
          } else {
            sdb.prepare('INSERT OR REPLACE INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at) VALUES (?, ?, ?, ?, ?)').run(guildId, tid, action, operatorId, nowSec);
            sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
              .run(guildId, 'channel', tid, action, operatorId, 'grant_scope', nowSec);
          }
        }
      }
    }
  });

  runTx();

  clearImmunityCache(guildId);
  invalidateBypassCache(guildId, tid);
  syncServerDataToMaster(guildId);
}

/**
 * Sets temporary grant duration for a target.
 */
function setWhitelistDuration(guildId, sdb, targetType, targetId, durationSeconds, operatorId) {
  const tid = String(targetId);
  const nowSec = Math.floor(Date.now() / 1000);
  const expiresAt = durationSeconds ? (nowSec + Number(durationSeconds)) : null;

  const runTx = sdb.transaction(() => {
    if (targetType === 'user') {
      sdb.prepare('UPDATE whitelisted_users SET expires_at = ? WHERE guild_id = ? AND user_id = ?').run(expiresAt, guildId, tid);
      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(guildId, 'user', tid, 'duration', operatorId, durationSeconds ? `duration_${durationSeconds}s` : 'duration_permanent', nowSec);
    } else if (targetType === 'role') {
      sdb.prepare('UPDATE whitelisted_roles SET expires_at = ? WHERE guild_id = ? AND role_id = ?').run(expiresAt, guildId, tid);
      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(guildId, 'role', tid, 'duration', operatorId, durationSeconds ? `duration_${durationSeconds}s` : 'duration_permanent', nowSec);
    }
  });

  runTx();

  clearImmunityCache(guildId);
  invalidateBypassCache(guildId, tid);
  syncServerDataToMaster(guildId);
  return expiresAt;
}

/**
 * Completely revokes a target from whitelist or extra owners.
 */
function revokeWhitelistTarget(guildId, sdb, targetType, targetId, operatorId) {
  const tid = String(targetId);
  const nowSec = Math.floor(Date.now() / 1000);

  const runTx = sdb.transaction(() => {
    if (targetType === 'user') {
      sdb.prepare('DELETE FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').run(guildId, tid);
    } else if (targetType === 'role') {
      sdb.prepare('DELETE FROM whitelisted_roles WHERE guild_id = ? AND role_id = ?').run(guildId, tid);
    } else if (targetType === 'channel') {
      sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').run(guildId, tid);
    } else if (targetType === 'extraowner') {
      sdb.prepare('DELETE FROM extraowners WHERE guild_id = ? AND owner_id = ?').run(guildId, tid);
    }

    sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(guildId, targetType, tid, 'all', operatorId, 'revoke_target', nowSec);

    try {
      sdb.prepare(`
        INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
        VALUES (?, ?, ?, ?, ?)
      `).run(
        targetType === 'extraowner' ? 'extraowner_remove' : 'whitelist_revoke',
        operatorId ? String(operatorId) : null,
        tid,
        `Revoked ${targetType} whitelist target: ${tid}`,
        nowSec
      );
    } catch (e) {}
  });

  runTx();

  clearImmunityCache(guildId);
  invalidateBypassCache(guildId, tid);
  syncServerDataToMaster(guildId);
}

module.exports = {
  USER_ROLE_ACTIONS,
  CHANNEL_SCOPES,
  buildTargetWhitelistPayload,
  toggleWhitelistAction,
  setWhitelistDuration,
  revokeWhitelistTarget
};
