/**
 * Tungsten Rate Commands Engine & Helper (Node.js)
 * Provides deterministic daily scoring, clean progress bars, and animated emoji telemetry.
 */
const { createEmbed } = require('./tools');
const { resolveEmoji, EMOJIS } = require('./emojis');

function resolveTargetUser(message, args) {
  if (message.mentions && message.mentions.users && message.mentions.users.size > 0) {
    return message.mentions.users.first();
  }

  if (args && args.length > 0) {
    const rawInput = args.join(' ').trim();
    const cleanId = rawInput.replace(/[^0-9]/g, '');

    if (message.guild && message.guild.members && message.guild.members.cache) {
      if (cleanId.length >= 17) {
        const byId = message.guild.members.cache.get(cleanId);
        if (byId && byId.user) return byId.user;
      }

      const inputLower = rawInput.toLowerCase();
      const byName = message.guild.members.cache.find(m =>
        m.user.username.toLowerCase() === inputLower ||
        (m.displayName && m.displayName.toLowerCase() === inputLower)
      );
      if (byName && byName.user) return byName.user;
    }

    // Fallback pseudo-user representation if username string passed
    let pseudoHash = 0;
    for (let i = 0; i < rawInput.length; i++) {
      pseudoHash = (pseudoHash * 31 + rawInput.charCodeAt(i)) >>> 0;
    }
    return {
      id: String(100000000000000000n + BigInt(pseudoHash)),
      username: rawInput,
      tag: `${rawInput}#0000`,
      bot: false,
      displayAvatarURL: () => null
    };
  }

  return message.author;
}

function calculateRateScore(userId, type, min = 0, max = 100) {
  const today = new Date().toISOString().slice(0, 10);
  const key = `${userId}:${type}:${today}`;
  let hash = 0;
  for (let i = 0; i < key.length; i++) {
    hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  }
  const range = max - min + 1;
  return min + (hash % range);
}

function createRateBar(score, min = 0, max = 100, length = 10) {
  const ratio = Math.max(0, Math.min(1, (score - min) / (max - min)));
  const filled = Math.round(ratio * length);
  const empty = length - filled;
  return '█'.repeat(filled) + '░'.repeat(empty);
}

function createRateCommand(config) {
  return {
    permissions: [],
    botPermissions: ['SendMessages', 'EmbedLinks'],
    name: config.name,
    category: 'fun',
    description: config.description || `Calculates the ${config.name} score for a member.`,
    usage: '[@user|username]',
    aliases: config.aliases || [],
    cooldown: 3,
    getComment: config.getComment,
    config,

    async execute(message, args, client, prefix) {
      const target = resolveTargetUser(message, args);
      const min = config.min !== undefined ? config.min : 0;
      const max = config.max !== undefined ? config.max : 100;
      const score = calculateRateScore(target.id, config.type || config.name, min, max);
      const bar = createRateBar(score, min, max);
      const comment = typeof config.getComment === 'function' ? config.getComment(score) : '';
      const scoreText = config.unit === 'IQ' ? `${score} IQ` : `${score}%`;

      const rawEmoji = config.emoji || EMOJIS.SPARKLE;
      const emoji = resolveEmoji(rawEmoji) || rawEmoji;

      const embed = createEmbed({
        color: config.color || (client?.config?.COLORS?.INFO || 0x5865F2),
        title: `${emoji}  ${config.title}`,
        description:
          `> **Target:** **${target.username}** ${target.id === message.author.id ? '*(Self)*' : `(<@${target.id}>)`}\n\n` +
          `**Rating:** **${scoreText}**\n` +
          `\`[${bar}]\`\n\n` +
          `*${comment}*`,
        footer: 'Deterministic daily score • Tungsten Fun Suite'
      });

      return message.reply({ embeds: [embed] });
    }
  };
}

module.exports = {
  resolveTargetUser,
  calculateRateScore,
  createRateBar,
  createRateCommand
};
