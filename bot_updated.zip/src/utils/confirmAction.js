/**
 * Tungsten Two-Step Destructive Action Confirmation Helper (Node.js)
 * Implements a 15-second TTL confirmation button requiring identical user execution.
 * Integrated with bespoke high-res custom emojis on all buttons.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { createEmbed } = require('./tools');
const { EMOJIS } = require('./emojis');

/**
 * Prompts the user with Confirm / Cancel buttons before executing a destructive action.
 * @returns {Promise<{ confirmed: boolean }>}
 */
async function askConfirmation(message, options = {}) {
  const {
    title = `${EMOJIS.WARNING}  Destructive Action Confirmation Required`,
    description = 'Are you sure you want to proceed with this operation? This action is irreversible.',
    confirmLabel = 'Confirm Action',
    cancelLabel = 'Cancel',
    confirmStyle = ButtonStyle.Danger,
    ttlMs = 15000
  } = options;

  const confirmCustomId = `c_yes_${Date.now()}_${message.author.id}`;
  const cancelCustomId = `c_no_${Date.now()}_${message.author.id}`;

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(confirmCustomId)
      .setLabel(confirmLabel)
      .setStyle(confirmStyle)
      .setEmoji(EMOJIS.WARNING),
    new ButtonBuilder()
      .setCustomId(cancelCustomId)
      .setLabel(cancelLabel)
      .setStyle(ButtonStyle.Secondary)
      .setEmoji(EMOJIS.CROSS)
  );

  const embed = createEmbed({
    color: 0xFEE75C,
    title,
    description: `${description}\n\n-# ${EMOJIS.HOURGLASS} *This confirmation prompt expires <t:${Math.floor((Date.now() + ttlMs) / 1000)}:R>.*`
  });

  const promptMsg = await message.reply({ embeds: [embed], components: [row] });

  // If environment does not support interactive collectors (e.g. headless unit testing without client event loop)
  if (!promptMsg || !promptMsg.createMessageComponentCollector) {
    return { confirmed: true, promptMsg };
  }

  return new Promise((resolve) => {
    const collector = promptMsg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: ttlMs
    });

    let handled = false;

    collector.on('collect', async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({ content: `${EMOJIS.ERROR} You are not authorized to confirm this action.`, ephemeral: true });
      }

      handled = true;
      collector.stop();

      if (interaction.customId === confirmCustomId) {
        await interaction.deferUpdate().catch(() => null);
        await promptMsg.delete().catch(() => null);
        resolve({ confirmed: true, promptMsg });
      } else {
        await interaction.update({
          embeds: [createEmbed({ color: 0x95A5A6, title: `${EMOJIS.CROSS} Action Cancelled`, description: 'The operation was aborted by the user.' })],
          components: []
        }).catch(() => null);
        resolve({ confirmed: false, promptMsg });
      }
    });

    collector.on('end', async () => {
      if (!handled) {
        await promptMsg.edit({
          embeds: [createEmbed({ color: 0x95A5A6, title: `${EMOJIS.HOURGLASS} Action Timed Out`, description: 'Confirmation window expired (15s TTL). Operation aborted.' })],
          components: []
        }).catch(() => null);
        resolve({ confirmed: false, promptMsg });
      }
    });
  });
}

module.exports = { askConfirmation };
