/**
 * Tungsten Auto-Logging Provisioning Engine (Node.js)
 * Automatically establishes a dedicated "SERVER LOGS" category and provisions either:
 * - STANDARD mode: 6 core channels (audit_log_channel, log_messages, log_members, log_voice, log_server, log_mod)
 * - ALL / COMPREHENSIVE mode: 22 granular channels matching user specs
 */
const { ChannelType, PermissionFlagsBits } = require('discord.js');
const { createEmbed } = require('./tools');
const { getServerDb } = require('./serverDb');

/**
 * Standard 6-Channel Specification (Maintains 100% backward-compatibility with tests and core workflows)
 */
const LOG_SPECS = [
  {
    key: 'audit_log_channel',
    name: 'audit-logs',
    topic: 'Master Audit & High-Priority Fallback Logs — Tungsten Sentinel',
    title: '📜 Master Audit & Dispatch Sentinel',
    description:
      '> **Primary Server Audit & System Fallback Log Channel**\n\n' +
      '• Receives administrative actions, guild updates, and emergency fallback events.\n' +
      '• Any unrouted or miscellaneous telemetry will automatically arrive here.\n' +
      '• Automated antinuke, antiraid, and security sentinel alerts dispatch in real-time.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_messages',
    name: 'message-logs',
    topic: 'Message Events (Edits, Deletions, Bulk Purges) — Tungsten Sentinel',
    title: '💬 Message Activity & Purge Logs',
    description:
      '> **Dedicated Real-Time Message Event Sentinel**\n\n' +
      '• **Message Edits:** Tracks before-and-after content diffs.\n' +
      '• **Message Deletions:** Logs author, channel, and deleted message contents.\n' +
      '• **Bulk Purges:** Automatically compiles and attaches full transcript .txt files.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_members',
    name: 'member-logs',
    topic: 'Member Lifecycle & Identity Events — Tungsten Sentinel',
    title: '👤 Member Lifecycle & Identity Logs',
    description:
      '> **Dedicated Member Lifecycle & Role Tracking Sentinel**\n\n' +
      '• **Join & Leave Telemetry:** Records account creation age, join time, and invite attribution.\n' +
      '• **Role Changes:** Tracks assigned and removed roles with executor identification.\n' +
      '• **Identity Updates:** Logs nickname and profile changes in real time.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_voice',
    name: 'voice-logs',
    topic: 'Voice State & Room Telemetry — Tungsten Sentinel',
    title: '🔊 Voice Activity & Telemetry Logs',
    description:
      '> **Dedicated Voice State Monitoring Sentinel**\n\n' +
      '• **Room Transitions:** Tracks user connects, disconnects, and room switching.\n' +
      '• **Voice Moderation:** Records server mutes, un-mutes, deafens, and undeafens.\n' +
      '• **Voice Duration:** Feeds voice activity tracking and XP calculation engine.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_server',
    name: 'server-logs',
    topic: 'Server Structural & Configuration Changes — Tungsten Sentinel',
    title: '⚙️ Server Structure & Configuration Logs',
    description:
      '> **Dedicated Server Structure & Hierarchy Sentinel**\n\n' +
      '• **Channels:** Logs channel creation, deletion, renaming, and permission updates.\n' +
      '• **Roles:** Tracks role creation, deletion, permission flags, and hierarchy movements.\n' +
      '• **Assets:** Records custom emojis, stickers, soundboard additions, and removals.\n' +
      '• **Threads:** Tracks forum posts, thread locks, archives, and unarchives.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_mod',
    name: 'mod-logs',
    topic: 'Moderation Enforcement & Disciplinary Cases — Tungsten Sentinel',
    title: '🛡️ Moderation Actions & Case Sentinel',
    description:
      '> **Dedicated Disciplinary Action & Case Sentinel**\n\n' +
      '• **Enforcement Actions:** Records kicks, bans, unbans, softbans, timeouts, and warns.\n' +
      '• **Case Indexing:** Generates unified case numbers with reason and moderator attribution.\n' +
      '• **Appeals & Expirations:** Records temporary punishment durations and auto-unbans.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  }
];

const STANDARD_LOG_SPECS = LOG_SPECS;

/**
 * 22 Granular Channels Specification (Matching the Comprehensive Logging System)
 */
const ALL_LOG_SPECS = [
  {
    key: 'log_mod',
    name: 'mod-logs',
    topic: 'Moderation Enforcement & Disciplinary Cases — Tungsten Sentinel',
    title: '🛡️ Moderation Actions & Case Sentinel',
    description:
      '> **Dedicated Disciplinary Action & Case Sentinel**\n\n' +
      '• **Enforcement Actions:** Records kicks, mutes, warns, and disciplinary decisions.\n' +
      '• **Case Indexing:** Generates unified case numbers with reason and moderator attribution.\n' +
      '• **Appeals & Expirations:** Records temporary punishment durations and auto-unmutes.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_bans',
    name: 'ban-logs',
    topic: 'Ban & Unban Sentinel — Tungsten Sentinel',
    title: '🔨 Ban & Unban Sentinel',
    description:
      '> **Dedicated Guild Ban & Unban Sentinel**\n\n' +
      '• **Ban Executions:** Tracks server bans, softbans, and massbans in real-time.\n' +
      '• **Unban Logs:** Records unbans, pardon notes, and revocation reasons.\n' +
      '• **Security Audit:** Attributed directly to executing staff or Antinuke protection.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_timeouts',
    name: 'timeout-logs',
    topic: 'Member Timeout & Communication Restraints — Tungsten Sentinel',
    title: '⏳ Member Timeout & Restraint Logs',
    description:
      '> **Dedicated Communication Restraint Sentinel**\n\n' +
      '• **Timeout Applied:** Records timeout durations, reasons, and responsible moderators.\n' +
      '• **Timeout Removed:** Logs premature removals and expired restrictions.\n' +
      '• **Automod Triggers:** Tracks automatic timeouts from spam and filter sentinels.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_nicknames',
    name: 'nickname-logs',
    topic: 'Member Nickname & Display Updates — Tungsten Sentinel',
    title: '🏷️ Member Nickname & Display Logs',
    description:
      '> **Dedicated Nickname & Identity Sentinel**\n\n' +
      '• **Nickname Changes:** Tracks before-and-after server nickname updates.\n' +
      '• **Identity Attribution:** Identifies whether self-changed or updated by staff.\n' +
      '• **Moderation Sentinel:** Enforces auto-dehoist and decancer telemetry.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_messages',
    name: 'message-logs',
    topic: 'Message Edits, Deletions & Purges — Tungsten Sentinel',
    title: '💬 Message Edits, Deletions & Purges',
    description:
      '> **Dedicated Real-Time Message Event Sentinel**\n\n' +
      '• **Message Edits:** Tracks before-and-after content diffs.\n' +
      '• **Message Deletions:** Logs author, channel, and deleted message contents.\n' +
      '• **Bulk Purges:** Automatically compiles and attaches full transcript .txt files.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_voice',
    name: 'voice-logs',
    topic: 'Voice State & Telemetry Logs — Tungsten Sentinel',
    title: '🔊 Voice State & Telemetry Logs',
    description:
      '> **Dedicated Voice State Monitoring Sentinel**\n\n' +
      '• **Room Transitions:** Tracks user connects, disconnects, and room switching.\n' +
      '• **Voice Moderation:** Records server mutes, un-mutes, deafens, and undeafens.\n' +
      '• **Voice Duration:** Feeds voice activity tracking and XP calculation engine.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_channels',
    name: 'channel-logs',
    topic: 'Channel Structure & Hierarchy Logs — Tungsten Sentinel',
    title: '📁 Channel Structure & Hierarchy Logs',
    description:
      '> **Dedicated Channel Hierarchy Sentinel**\n\n' +
      '• **Channel Lifecycle:** Tracks channel creations, deletions, and restorations.\n' +
      '• **Configuration Diffs:** Records channel renames, topic changes, and rate limits.\n' +
      '• **Permission Overwrites:** Captures role and member permission alterations.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_roles',
    name: 'role-logs',
    topic: 'Role & Permission Logs — Tungsten Sentinel',
    title: '🎭 Role & Permission Logs',
    description:
      '> **Dedicated Role Configuration & Member Assignment Sentinel**\n\n' +
      '• **Role Changes:** Logs role creations, deletions, name updates, and colors.\n' +
      '• **Permission Flags:** Alerts on critical administrative permission modifications.\n' +
      '• **Member Assignments:** Records role additions and removals on members.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_emojis',
    name: 'emoji-logs',
    topic: 'Custom Emoji Logs — Tungsten Sentinel',
    title: '😀 Custom Emoji Logs',
    description:
      '> **Dedicated Custom Emoji Lifecycle Sentinel**\n\n' +
      '• **Emoji Additions:** Logs newly uploaded custom emojis with author attribution.\n' +
      '• **Emoji Deletions:** Tracks removed custom emojis.\n' +
      '• **Name & Role Restrictions:** Records emoji renames and role accessibility updates.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_guildupdate',
    name: 'guildupdate-logs',
    topic: 'Server Configuration & Feature Logs — Tungsten Sentinel',
    title: '🏰 Server Configuration & Feature Logs',
    description:
      '> **Dedicated Server Configuration Sentinel**\n\n' +
      '• **Server Settings:** Logs server name, icon, banner, and splash changes.\n' +
      '• **Security Tier:** Tracks verification level, MFA, and content filter updates.\n' +
      '• **System Channels:** Records AFK, system, and public updates channel modifications.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_security',
    name: 'security-logs',
    topic: 'Antinuke & Threat Security Logs — Tungsten Sentinel',
    title: '🚨 Antinuke & Threat Security Logs',
    description:
      '> **Dedicated High-Priority Security Sentinel**\n\n' +
      '• **Antinuke Triggers:** Immediate alerts on rate-limit violations and unauthorized actions.\n' +
      '• **Quarantine & Punishment:** Logs automated quarantine, role stripping, and bans.\n' +
      '• **Emergency Locks:** Records lockdown activations and threat neutralizations.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_bots',
    name: 'bot-logs',
    topic: 'Bot Addition & Permission Logs — Tungsten Sentinel',
    title: '🤖 Bot Addition & Permission Logs',
    description:
      '> **Dedicated Bot Integration Sentinel**\n\n' +
      '• **Bot Additions:** Records invited bots, integration timestamps, and inviter.\n' +
      '• **Privileged Permissions:** Audits dangerous permissions granted to bots.\n' +
      '• **Bot Deauthorizations:** Tracks bot removals and antinuke unauthorizations.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_webhooks',
    name: 'webhook-logs',
    topic: 'Webhook Management & Spam Logs — Tungsten Sentinel',
    title: '🔗 Webhook Management & Spam Logs',
    description:
      '> **Dedicated Webhook Sentinel**\n\n' +
      '• **Lifecycle Events:** Logs webhook creation, deletion, and token changes.\n' +
      '• **Target Channels:** Tracks channel moves and target modifications.\n' +
      '• **Spam Sentinel:** Monitors webhook rapid dispatch and rate violations.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_secure_wl',
    name: 'secure-wl-logs',
    topic: 'Security Whitelist & Trust Logs — Tungsten Sentinel',
    title: '🛡️ Security Whitelist & Trust Logs',
    description:
      '> **Dedicated Trust & Whitelist Sentinel**\n\n' +
      '• **Whitelist Changes:** Logs additions and removals from the antinuke whitelist.\n' +
      '• **Trust Hierarchy:** Audits owner-level authorizations and bypass privileges.\n' +
      '• **Security Audits:** Provides tamper-evident logs of security whitelist edits.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_memberjoin',
    name: 'memberjoin-logs',
    topic: 'Member Join & Leave Lifecycle Logs — Tungsten Sentinel',
    title: '🚪 Member Join & Leave Lifecycle Logs',
    description:
      '> **Dedicated Join & Leave Sentinel**\n\n' +
      '• **Member Joins:** Records member join time, account age, and suspicious account flags.\n' +
      '• **Member Leaves:** Tracks member departures, kicks, or voluntary leaves.\n' +
      '• **Raid Sentinel:** Feeds antiraid metrics and join velocity tracking.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_invites',
    name: 'inviteevent-logs',
    topic: 'Invite Link & Attribution Logs — Tungsten Sentinel',
    title: '📨 Invite Link & Attribution Logs',
    description:
      '> **Dedicated Invite Sentinel**\n\n' +
      '• **Invite Creations:** Tracks newly generated invite links, max uses, and creator.\n' +
      '• **Invite Deletions:** Records expired or deleted invite links.\n' +
      '• **Join Attribution:** Dispatches vanity URL and code attribution data on join.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_manual',
    name: 'manual-logs',
    topic: 'Manual Staff Audit Logs & Mod Notes — Tungsten Sentinel',
    title: '📝 Manual Staff Audit Logs & Mod Notes',
    description:
      '> **Dedicated Staff Audit & Internal Notes Sentinel**\n\n' +
      '• **Staff Notes:** Records internal mod notes, warnings, and staff memos.\n' +
      '• **Manual Dispatches:** Logs administrative manual logs and announcements.\n' +
      '• **Audit Trail:** Preserves human moderator remarks and case annotations.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_tickets',
    name: 'tickethistory-logs',
    topic: 'Ticket Transcripts & Resolution Logs — Tungsten Sentinel',
    title: '🎫 Ticket Transcripts & Resolution Logs',
    description:
      '> **Dedicated Support & Ticket Lifecycle Sentinel**\n\n' +
      '• **Ticket Actions:** Logs ticket open, claim, close, and delete events.\n' +
      '• **Transcripts:** Automatically archives complete ticket conversation logs.\n' +
      '• **Staff Attribution:** Tracks handling support members and ticket closure notes.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_quarantine',
    name: 'quarantine-logs',
    topic: 'Threat Quarantine & Isolation Logs — Tungsten Sentinel',
    title: '☣️ Threat Quarantine & Isolation Logs',
    description:
      '> **Dedicated Threat Quarantine Sentinel**\n\n' +
      '• **Quarantine Enactments:** Logs members placed into quarantine isolation.\n' +
      '• **Role Stripping:** Records all removed roles during containment actions.\n' +
      '• **Release & Pardon:** Tracks quarantine release, restored roles, and authorization.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_threads',
    name: 'thread-logs',
    topic: 'Thread & Forum Lifecycle Logs — Tungsten Sentinel',
    title: '🧵 Thread & Forum Lifecycle Logs',
    description:
      '> **Dedicated Thread & Forum Sentinel**\n\n' +
      '• **Thread Creations:** Logs newly started public and private threads and forum posts.\n' +
      '• **Thread States:** Records thread archive, unarchive, lock, and unlock events.\n' +
      '• **Thread Deletions:** Tracks removed threads and purge operations.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_stickers',
    name: 'sticker-logs',
    topic: 'Custom Sticker Logs — Tungsten Sentinel',
    title: '🎨 Custom Sticker Logs',
    description:
      '> **Dedicated Custom Sticker Sentinel**\n\n' +
      '• **Sticker Additions:** Logs newly uploaded server stickers with author attribution.\n' +
      '• **Sticker Deletions:** Tracks removed server stickers.\n' +
      '• **Metadata Updates:** Records sticker name, tag, and description modifications.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  },
  {
    key: 'log_scheduled_events',
    name: 'scheduled-event-logs',
    topic: 'Scheduled Guild Event Logs — Tungsten Sentinel',
    title: '📅 Scheduled Guild Event Logs',
    description:
      '> **Dedicated Scheduled Event Sentinel**\n\n' +
      '• **Event Lifecycle:** Logs scheduled event creations, updates, and cancellations.\n' +
      '• **Status Updates:** Tracks event start, completion, and location updates.\n' +
      '• **User Participation:** Audits event subscriptions and subscriber updates.\n\n' +
      '-# Configured automatically via Tungsten Auto-Logging Engine.'
  }
];

const ALL_LOG_KEYS = [
  'audit_log_channel',
  'log_messages',
  'log_members',
  'log_voice',
  'log_server',
  'log_mod',
  'log_bans',
  'log_timeouts',
  'log_nicknames',
  'log_channels',
  'log_roles',
  'log_emojis',
  'log_guildupdate',
  'log_security',
  'log_bots',
  'log_webhooks',
  'log_secure_wl',
  'log_memberjoin',
  'log_invites',
  'log_manual',
  'log_tickets',
  'log_quarantine',
  'log_threads',
  'log_stickers',
  'log_scheduled_events'
];

const ALL_LOG_NAMES_SET = new Set([
  'audit-logs',
  'message-logs',
  'member-logs',
  'voice-logs',
  'server-logs',
  'mod-logs',
  'ban-logs',
  'timeout-logs',
  'nickname-logs',
  'channel-logs',
  'role-logs',
  'emoji-logs',
  'guildupdate-logs',
  'security-logs',
  'bot-logs',
  'webhook-logs',
  'secure-wl-logs',
  'memberjoin-logs',
  'inviteevent-logs',
  'manual-logs',
  'tickethistory-logs',
  'quarantine-logs',
  'thread-logs',
  'sticker-logs',
  'scheduled-event-logs'
]);

/**
 * Automatically establish "SERVER LOGS" category and provision logging channels.
 * Supports standard mode (6 channels) and comprehensive/all mode (22 channels).
 *
 * @param {import('discord.js').Guild} guild
 * @param {object|string} [sdb=null]
 * @param {string} [mode='standard']
 * @returns {Promise<{ success: boolean, category?: any, channels?: Record<string, any>, newlyCreatedCount?: number, mode?: string, error?: string }>}
 */
async function autoProvisionAllLogChannels(guild, sdb = null, mode = 'standard') {
  if (!guild) return { success: false, error: 'Guild is required' };
  if (typeof sdb === 'string') {
    mode = sdb;
    sdb = null;
  }
  const db = sdb || getServerDb(guild.id);

  // Check bot permission
  const me = guild.members?.me;
  if (me && me.permissions && typeof me.permissions.has === 'function') {
    const hasManage = me.permissions.has(PermissionFlagsBits.ManageChannels);
    if (!hasManage) {
      return {
        success: false,
        error: 'The bot requires `Manage Channels` permission to automatically provision log channels.'
      };
    }
  }

  const selectedMode = (typeof mode === 'string' && ['all', 'comprehensive', '22'].includes(mode.toLowerCase())) ? 'all' : 'standard';
  const specs = selectedMode === 'all' ? ALL_LOG_SPECS : STANDARD_LOG_SPECS;

  // 1. Locate or create "SERVER LOGS" category
  let category = null;
  if (guild.channels?.cache) {
    category = guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory && /^(server\s*logs|logs|log\s*channels)$/i.test(c.name)
    );
  }

  if (!category && guild.channels?.create) {
    try {
      const everyoneRole = guild.roles?.everyone || { id: guild.id };
      const botId = me?.id || guild.client?.user?.id;
      const overwrites = [
        {
          id: everyoneRole.id,
          deny: [PermissionFlagsBits.ViewChannel]
        }
      ];
      if (botId) {
        overwrites.push({
          id: botId,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.EmbedLinks,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.ManageChannels
          ]
        });
      }

      category = await guild.channels.create({
        name: 'SERVER LOGS',
        type: ChannelType.GuildCategory,
        permissionOverwrites: overwrites
      });
    } catch (_) {
      // Continue gracefully even if category creation throws
    }
  }

  const resultChannels = {};
  const newlyCreated = [];

  // 2. Provision each channel
  for (const spec of specs) {
    let targetCh = null;

    // Check existing by name or setting
    if (guild.channels?.cache) {
      targetCh = guild.channels.cache.find(
        c => (!c.isTextBased || (typeof c.isTextBased === 'function' && c.isTextBased())) &&
          (c.name === spec.name || c.name === spec.name.replace(/-/g, '_'))
      );
    }

    if (!targetCh && guild.channels?.create) {
      try {
        const everyoneRole = guild.roles?.everyone || { id: guild.id };
        const botId = me?.id || guild.client?.user?.id;
        const overwrites = category
          ? undefined
          : [
              {
                id: everyoneRole.id,
                deny: [PermissionFlagsBits.ViewChannel]
              },
              ...(botId
                ? [
                    {
                      id: botId,
                      allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.AttachFiles
                      ]
                    }
                  ]
                : [])
            ];

        targetCh = await guild.channels.create({
          name: spec.name,
          type: ChannelType.GuildText,
          topic: spec.topic,
          parent: category?.id || null,
          permissionOverwrites: overwrites
        });
        newlyCreated.push(spec.name);
      } catch (err) {
        // Fall back to current or existing channel if creation restricted
      }
    }

    if (targetCh) {
      // Send initial announcement embed (100% colorless UI)
      if (typeof targetCh.send === 'function') {
        const announceEmbed = createEmbed({
          color: undefined,
          title: spec.title,
          description: spec.description,
          footer: 'Tungsten Automated Log Provisioner'
        });
        await targetCh.send({ embeds: [announceEmbed] }).catch(() => null);
      }

      // Store in SQLite server_settings
      db.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run(spec.key, targetCh.id);
      resultChannels[spec.key] = targetCh;
    }
  }

  return {
    success: true,
    category,
    channels: resultChannels,
    newlyCreatedCount: newlyCreated.length,
    mode: selectedMode
  };
}

/**
 * Delete all provisioned log channels and clean up server_settings database records.
 *
 * @param {import('discord.js').Guild} guild
 * @param {object} [sdb=null]
 * @returns {Promise<{ success: boolean, deletedCount?: number, deletedNames?: string[], error?: string }>}
 */
async function deleteAllLogChannels(guild, sdb = null) {
  if (!guild) return { success: false, error: 'Guild is required' };
  const db = sdb || getServerDb(guild.id);

  // Check bot permission ManageChannels
  const me = guild.members?.me;
  if (me && me.permissions && typeof me.permissions.has === 'function') {
    const hasManage = me.permissions.has(PermissionFlagsBits.ManageChannels);
    if (!hasManage) {
      return {
        success: false,
        error: 'The bot requires `Manage Channels` permission to delete log channels.'
      };
    }
  }

  let category = null;
  if (guild.channels?.cache) {
    category = guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory && /^(server\s*logs|logs|log\s*channels)$/i.test(c.name)
    );
  }

  const channelsToDelete = new Map();

  // 1. Collect all channel IDs from server_settings
  for (const key of ALL_LOG_KEYS) {
    const row = db.prepare('SELECT value FROM server_settings WHERE key = ?').get(key);
    if (row?.value && guild.channels?.cache) {
      const ch = guild.channels.cache.get(row.value);
      if (ch && ch.type !== ChannelType.GuildCategory) {
        channelsToDelete.set(ch.id, ch);
      }
    }
  }

  // 2. Identify any channels in guild.channels.cache under category 'SERVER LOGS' matching log spec names
  if (category && guild.channels?.cache) {
    for (const [id, ch] of guild.channels.cache.entries()) {
      if (id === category.id || ch.type === ChannelType.GuildCategory) continue;
      const isUnderCategory = ch.parentId === category.id || ch.parent?.id === category.id;
      if (isUnderCategory) {
        const normName = (ch.name || '').toLowerCase().replace(/_/g, '-');
        if (ALL_LOG_NAMES_SET.has(normName) || ALL_LOG_NAMES_SET.has((ch.name || '').toLowerCase())) {
          channelsToDelete.set(id, ch);
        }
      }
    }
  }

  // 3. Delete all identified channels with reason
  const reason = 'Tungsten Log Channel Cleanup requested by administrator';
  const deletedNames = [];

  for (const [id, ch] of channelsToDelete.entries()) {
    try {
      if (typeof ch.delete === 'function') {
        await ch.delete(reason);
      }
      deletedNames.push(ch.name || id);
    } catch (_) {
      // Continue deleting remaining channels
    }
  }

  // 4. If the category 'SERVER LOGS' is empty or only contained log channels, delete the category as well
  if (category) {
    let remainingUnderCategory = 0;
    if (guild.channels?.cache) {
      for (const [id, ch] of guild.channels.cache.entries()) {
        if (id === category.id) continue;
        const isUnder = ch.parentId === category.id || ch.parent?.id === category.id;
        if (isUnder && !channelsToDelete.has(id)) {
          remainingUnderCategory++;
        }
      }
    }
    if (remainingUnderCategory === 0) {
      try {
        if (typeof category.delete === 'function') {
          await category.delete(reason);
        }
        deletedNames.push(category.name || 'SERVER LOGS');
      } catch (_) {}
    }
  }

  // 5. Delete all log routing keys from server_settings table
  for (const key of ALL_LOG_KEYS) {
    db.prepare('DELETE FROM server_settings WHERE key = ?').run(key);
  }

  return {
    success: true,
    deletedCount: deletedNames.length,
    deletedNames
  };
}

module.exports = {
  LOG_SPECS,
  STANDARD_LOG_SPECS,
  ALL_LOG_SPECS,
  autoProvisionAllLogChannels,
  deleteAllLogChannels
};
