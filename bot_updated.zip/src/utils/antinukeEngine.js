/**
 * Tungsten Antinuke & Defense Sentinel Engine (Node.js)
 * Enterprise-grade threat detection, Wick/Olympus/Zynrax production parity,
 * automated sub-50ms auto-healing, multi-vector punishment engine,
 * isolated quarantine/jail system, and disaster recovery snapshot manager.
 */
const { PermissionsBitField, AuditLogEvent, EmbedBuilder, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getServerDb, syncServerDataToMaster } = require('./serverDb');
const { createEmbed } = require('./tools');
const { resolveEmoji } = require('./emojis');
const config = require('../config');

// Unified vector actions across Antinuke, Whitelist, and Studios (H10)
const VALID_ACTIONS = [
  'all',
  'ban',
  'kick',
  'channel',
  'role',
  'bot',
  'webhook',
  'vanity',
  'server',
  'emoji',
  'invite',
  'member',
  'automod',
  'links',
  'spam',
  'mention',
  'prune'
];

/**
 * 16 Production Sentinel Vectors (Wick / Olympus / Zynrax Standard)
 */
const ANTINUKE_VECTORS = {
  bot_add: {
    key: 'bot_add',
    name: 'Anti-Bot Add',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_bot:1567233522635247781>',
    desc: 'Auto-bans unauthorized rogue bots and sanctions the inviting administrator'
  },
  channel_delete: {
    key: 'channel_delete',
    name: 'Anti-Channel Delete',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_minus:1567241276057849856>',
    desc: 'Sub-50ms auto-healing for deleted channels with exact permissions and properties'
  },
  channel_create: {
    key: 'channel_create',
    name: 'Anti-Channel Create',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_plus:1567241846453833840>',
    desc: 'Neutralizes mass channel creation spam raids and removes rogue channels'
  },
  channel_update: {
    key: 'channel_update',
    name: 'Anti-Channel Tampering',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_gear:1567239932970406012>',
    desc: 'Reverts unauthorized permission overwrite tampering and visibility alterations'
  },
  role_delete: {
    key: 'role_delete',
    name: 'Anti-Role Delete',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_minus:1567241276057849856>',
    desc: 'Auto-recreates deleted roles with exact permissions, color, hoist, and hierarchy'
  },
  role_create: {
    key: 'role_create',
    name: 'Anti-Role Create',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_plus:1567241846453833840>',
    desc: 'Prevents mass rogue role creation attacks and administrative privilege injection'
  },
  role_update: {
    key: 'role_update',
    name: 'Anti-Role Escalation',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_shield:1567242104923627574>',
    desc: 'Instantly revokes unauthorized Administrator, Manage Server, and dangerous permissions'
  },
  ban: {
    key: 'ban',
    name: 'Anti-Mass Ban',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_close:1567234632905138206>',
    desc: 'Intercepts rogue administrator mass ban attacks and auto-unbans affected victims'
  },
  kick: {
    key: 'kick',
    name: 'Anti-Mass Kick',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 0,
    icon: '<a:tungsten_sweep:1567242656281657414>',
    desc: 'Intercepts rogue administrator mass kick raids and stops unauthorized member expulsions'
  },
  prune: {
    key: 'prune',
    name: 'Anti-Member Prune',
    defaultLimit: 1,
    defaultWindow: 60,
    defaultAction: 'ban',
    defaultHeal: 0,
    icon: '<a:tungsten_sweep:1567242656281657414>',
    desc: 'Blocks unauthorized guild member prune executions'
  },
  webhook: {
    key: 'webhook',
    name: 'Anti-Webhook Rogue',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_bolt:1567233430570405968>',
    desc: 'Immediately deletes unauthorized rogue webhooks and sanctions creator'
  },
  emoji: {
    key: 'emoji',
    name: 'Anti-Emoji Delete',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 0,
    icon: '<a:tungsten_chart:1567234342701367357>',
    desc: 'Halts unauthorized emoji purge attacks and sanctions rogue operator'
  },
  sticker: {
    key: 'sticker',
    name: 'Anti-Sticker Delete',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 0,
    icon: '<a:tungsten_chart:1567234342701367357>',
    desc: 'Halts unauthorized sticker purge attacks and sanctions rogue operator'
  },
  server_update: {
    key: 'server_update',
    name: 'Anti-Server Tampering',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_shield:1567242104923627574>',
    desc: 'Reverts unauthorized changes to server name, icon, banner, and verification level'
  },
  vanity: {
    key: 'vanity',
    name: 'Anti-Vanity Steal',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'ban',
    defaultHeal: 1,
    icon: '<a:tungsten_crown:1567238355463176334>',
    desc: 'Protects and auto-reclaims customized server vanity invite URLs'
  },
  everyone_ping: {
    key: 'everyone_ping',
    name: 'Anti-Everyone/Here Ping',
    defaultLimit: 1,
    defaultWindow: 10,
    defaultAction: 'strip',
    defaultHeal: 1,
    icon: '<a:tungsten_warn:1567246685082746940>',
    desc: 'Intercepts unauthorized mass mention pings from compromised staff accounts'
  }
};

/**
 * Standard Antinuke Security Presets
 * - relaxed: elevated thresholds, default quarantine / strip responses
 * - balanced: default production baseline (1-strike ban/strip on destructive, 2-4 on high-velocity creation)
 * - strict: single-strike ban across primary vectors, 2 for emojis/stickers
 * - lockdown: immediate 1-strike ban across all 16 vectors
 */
const ANTINUKE_PRESETS = {
  relaxed: {
    // Tighter threat vectors
    ban: { limit_count: 3, time_window: 10, action: 'quarantine' },
    kick: { limit_count: 3, time_window: 10, action: 'quarantine' },
    role_delete: { limit_count: 2, time_window: 10, action: 'quarantine' },
    channel_delete: { limit_count: 2, time_window: 10, action: 'quarantine' },
    bot_add: { limit_count: 2, time_window: 10, action: 'quarantine' },
    server_update: { limit_count: 2, time_window: 10, action: 'quarantine' },
    prune: { limit_count: 2, time_window: 10, action: 'quarantine' },
    vanity: { limit_count: 2, time_window: 10, action: 'quarantine' },
    everyone_ping: { limit_count: 2, time_window: 10, action: 'strip' },
    // Looser threat vectors
    channel_create: { limit_count: 5, time_window: 10, action: 'quarantine' },
    role_create: { limit_count: 5, time_window: 10, action: 'quarantine' },
    channel_update: { limit_count: 5, time_window: 10, action: 'strip' },
    role_update: { limit_count: 5, time_window: 10, action: 'strip' },
    webhook: { limit_count: 3, time_window: 10, action: 'quarantine' },
    emoji: { limit_count: 5, time_window: 10, action: 'quarantine' },
    sticker: { limit_count: 5, time_window: 10, action: 'quarantine' }
  },
  balanced: {
    // Tighter threat vectors (Default Production Baseline)
    ban: { limit_count: 1, time_window: 10, action: 'ban' },
    kick: { limit_count: 1, time_window: 10, action: 'kick' },
    role_delete: { limit_count: 1, time_window: 10, action: 'ban' },
    channel_delete: { limit_count: 1, time_window: 10, action: 'ban' },
    bot_add: { limit_count: 1, time_window: 10, action: 'ban' },
    server_update: { limit_count: 1, time_window: 10, action: 'ban' },
    prune: { limit_count: 1, time_window: 10, action: 'ban' },
    vanity: { limit_count: 1, time_window: 10, action: 'ban' },
    everyone_ping: { limit_count: 1, time_window: 10, action: 'strip' },
    // Looser threat vectors
    channel_create: { limit_count: 3, time_window: 10, action: 'quarantine' },
    role_create: { limit_count: 3, time_window: 10, action: 'quarantine' },
    channel_update: { limit_count: 3, time_window: 10, action: 'strip' },
    role_update: { limit_count: 3, time_window: 10, action: 'strip' },
    webhook: { limit_count: 2, time_window: 10, action: 'quarantine' },
    emoji: { limit_count: 4, time_window: 10, action: 'quarantine' },
    sticker: { limit_count: 4, time_window: 10, action: 'quarantine' }
  },
  strict: {
    // All vectors limit 1 / 10s (action: 'ban'), except emoji & sticker (2 / 10s)
    ban: { limit_count: 1, time_window: 10, action: 'ban' },
    kick: { limit_count: 1, time_window: 10, action: 'ban' },
    role_delete: { limit_count: 1, time_window: 10, action: 'ban' },
    channel_delete: { limit_count: 1, time_window: 10, action: 'ban' },
    bot_add: { limit_count: 1, time_window: 10, action: 'ban' },
    server_update: { limit_count: 1, time_window: 10, action: 'ban' },
    prune: { limit_count: 1, time_window: 10, action: 'ban' },
    vanity: { limit_count: 1, time_window: 10, action: 'ban' },
    everyone_ping: { limit_count: 1, time_window: 10, action: 'ban' },
    channel_create: { limit_count: 1, time_window: 10, action: 'ban' },
    role_create: { limit_count: 1, time_window: 10, action: 'ban' },
    channel_update: { limit_count: 1, time_window: 10, action: 'ban' },
    role_update: { limit_count: 1, time_window: 10, action: 'ban' },
    webhook: { limit_count: 1, time_window: 10, action: 'ban' },
    emoji: { limit_count: 2, time_window: 10, action: 'ban' },
    sticker: { limit_count: 2, time_window: 10, action: 'ban' }
  },
  lockdown: {
    // All 16 vectors limit 1 / 10s, action: 'ban'
    ban: { limit_count: 1, time_window: 10, action: 'ban' },
    kick: { limit_count: 1, time_window: 10, action: 'ban' },
    role_delete: { limit_count: 1, time_window: 10, action: 'ban' },
    channel_delete: { limit_count: 1, time_window: 10, action: 'ban' },
    bot_add: { limit_count: 1, time_window: 10, action: 'ban' },
    server_update: { limit_count: 1, time_window: 10, action: 'ban' },
    prune: { limit_count: 1, time_window: 10, action: 'ban' },
    vanity: { limit_count: 1, time_window: 10, action: 'ban' },
    everyone_ping: { limit_count: 1, time_window: 10, action: 'ban' },
    channel_create: { limit_count: 1, time_window: 10, action: 'ban' },
    role_create: { limit_count: 1, time_window: 10, action: 'ban' },
    channel_update: { limit_count: 1, time_window: 10, action: 'ban' },
    role_update: { limit_count: 1, time_window: 10, action: 'ban' },
    webhook: { limit_count: 1, time_window: 10, action: 'ban' },
    emoji: { limit_count: 1, time_window: 10, action: 'ban' },
    sticker: { limit_count: 1, time_window: 10, action: 'ban' }
  }
};

// Aliases for role_escalation -> role_update on each preset object
for (const p of Object.values(ANTINUKE_PRESETS)) {
  Object.defineProperty(p, 'role_escalation', {
    get() { return this.role_update; },
    enumerable: false,
    configurable: true
  });
}

// Bounded Map implementation: caps cache size to maxSize and evicts oldest entries (FIFO)
class BoundedMap extends Map {
  constructor(maxSize = 500, ...args) {
    super(...args);
    this.maxSize = maxSize;
  }
  set(key, value) {
    if (this.size >= this.maxSize && !this.has(key)) {
      const oldest = this.keys().next().value;
      if (oldest !== undefined) this.delete(oldest);
    }
    super.set(key, value);
    while (this.size > this.maxSize) {
      const oldest = this.keys().next().value;
      if (oldest === undefined) break;
      this.delete(oldest);
    }
    return this;
  }
}

// In-memory threat caches, deduplication locks & sliding-window rate limiters
const _IMMUNITY_CACHE = new Map(); // key: `${guildId}:${userId}:${action}` -> { value: bool, expires: number }
const _IMMUNITY_DB_ERRORS = new Map(); // key: `${guildId}:${userId}` -> expires timestamp
const _RATE_LIMIT_BUCKETS = new Map(); // key: `${guildId}:${userId}:${action}` -> timestamps[]
const _CROSS_VECTOR_TRACKER = new Map(); // key: `${guildId}:${userId}`, val: [{ timestamp, weight, vector }]

const CROSS_VECTOR_WEIGHTS = {
  channel_delete: 50,
  role_delete: 50,
  ban: 50,
  kick: 50,
  prune: 50,
  vanity: 50,
  bot_add: 50,
  channel_create: 25,
  role_create: 25,
  channel_update: 25,
  role_update: 25,
  webhook: 25,
  emoji: 15,
  sticker: 15,
  everyone_ping: 30
};

/**
 * Cross-Vector Actor Threat Scoring Engine
 * Accumulates weighted threat scores across disparate attack vectors within a 10s sliding window.
 */
function checkCrossVectorThreat(guildId, userId, vectorKey) {
  const gid = String(guildId);
  const uid = String(userId);
  const key = `${gid}:${uid}`;
  const now = Date.now();
  const weight = CROSS_VECTOR_WEIGHTS[vectorKey] || 0;

  // Clean entries older than 10,000 ms
  let events = _CROSS_VECTOR_TRACKER.get(key) || [];
  events = events.filter(e => (now - e.timestamp) < 10000);

  // Append current event with timestamp, weight, and vector
  const currentEvent = { timestamp: now, weight, vector: vectorKey };
  events.push(currentEvent);
  _CROSS_VECTOR_TRACKER.set(key, events);

  // Automatic TTL sweep helper
  if (events.length === 1) {
    setTimeout(() => {
      const cur = _CROSS_VECTOR_TRACKER.get(key);
      if (cur) {
        const remaining = cur.filter(e => (Date.now() - e.timestamp) < 10000);
        if (remaining.length === 0) {
          _CROSS_VECTOR_TRACKER.delete(key);
        } else {
          _CROSS_VECTOR_TRACKER.set(key, remaining);
        }
      }
    }, 10500).unref?.();
  }

  // Calculate total score in the 10s window across multiple disparate vectors
  const score = events.reduce((sum, e) => sum + (e.weight || 0), 0);
  const distinctVectors = new Set(events.map(e => e.vector));

  if (score >= 100 && distinctVectors.size > 1) {
    return { tripped: true, score, events };
  }
  return { tripped: false, score };
}
const _PUNISH_LOCKS = new Map(); // key: `${guildId}:${userId}` -> { locked: bool, count: number, timer: Timeout }
const _AUDIT_LOG_PUSH_CACHE = new Map(); // key: entryId -> { entry, expires: number }
const _CHANNEL_SNAPSHOT_CACHE = new BoundedMap(500); // key: channelId -> channelData (capped at 500)
const _ROLE_SNAPSHOT_CACHE = new BoundedMap(500); // key: roleId -> roleData (capped at 500)
const _ACTIVE_RAID_ATTACKERS = new Map(); // key: guildId -> { executor, timestamp: number }
const _SERVER_BASELINE_CACHE = new Map(); // key: guildId -> { name, icon_url, icon_base64, banner_url, banner_base64, verification_level }

function recordActiveRaidAttacker(guildId, executor) {
  if (!guildId || !executor || !executor.id) return;
  _ACTIVE_RAID_ATTACKERS.set(String(guildId), {
    executor,
    timestamp: Date.now()
  });
}

function getActiveRaidAttacker(guildId) {
  if (!guildId) return null;
  const data = _ACTIVE_RAID_ATTACKERS.get(String(guildId));
  if (!data) return null;
  if (Date.now() - data.timestamp > 30000) {
    _ACTIVE_RAID_ATTACKERS.delete(String(guildId));
    return null;
  }
  return data;
}

/**
 * Prunes rate limit bucket entries with timestamps older than cutoffMs (default: 60s).
 */
function cleanupRateLimitBuckets(cutoffMs = 60000) {
  const now = Date.now();
  for (const [key, timestamps] of _RATE_LIMIT_BUCKETS.entries()) {
    if (!Array.isArray(timestamps) || timestamps.length === 0) {
      _RATE_LIMIT_BUCKETS.delete(key);
      continue;
    }
    const fresh = timestamps.filter(t => (now - t) < cutoffMs);
    if (fresh.length === 0) {
      _RATE_LIMIT_BUCKETS.delete(key);
    } else if (fresh.length !== timestamps.length) {
      _RATE_LIMIT_BUCKETS.set(key, fresh);
    }
  }
}

// Periodic cleanup sweep every 5 minutes to prune entries older than 60 seconds
const _rateLimitSweepInterval = setInterval(() => {
  cleanupRateLimitBuckets(60000);
}, 5 * 60 * 1000);
if (_rateLimitSweepInterval.unref) _rateLimitSweepInterval.unref();

// Production Anti-Duplicate & Rogue-Loop Guards
const _AUTO_HEAL_LOCKS = new Map(); // key: `${guildId}:${type}:${targetId}` -> timestamp
const _AUTHORIZED_DELETIONS = new Set(); // key: `${guildId}:${targetId}` -> TTL Set
const _BOT_DELETED_ENTITIES = new Set(); // key: `${targetId}` -> TTL Set
const _AUTO_HEALED_ENTITIES = new Set(); // key: `${targetId}` -> TTL Set
const _BOT_CREATED_ENTITIES = new Set(); // key: `${targetId}` -> TTL Set
const _GUILD_ATTACK_VELOCITY = new Map(); // key: `${guildId}` -> timestamps[]
const _DISASTER_RECOVERY_LOCKS = new Map(); // key: `disaster_recovery:${guildId}` -> timestamp
const _BACKUP_ROLE_MUTEX = new Map(); // key: guildId -> Promise
const _LAST_BACKUP_ROLE_ADJUSTMENT = new Map(); // key: guildId -> timestamp
const _UNATTRIBUTED_WARN_TIMESTAMPS = new Map(); // key: guildId -> timestamp

function markAutoHealedEntity(targetId) {
  if (!targetId) return;
  const id = String(targetId);
  _AUTO_HEALED_ENTITIES.add(id);
  setTimeout(() => _AUTO_HEALED_ENTITIES.delete(id), 60000).unref();
}

function isAutoHealedEntity(targetId) {
  if (!targetId) return false;
  return _AUTO_HEALED_ENTITIES.has(String(targetId));
}

function markBotCreatedEntity(targetId) {
  if (!targetId) return;
  const id = String(targetId);
  _BOT_CREATED_ENTITIES.add(id);
  setTimeout(() => _BOT_CREATED_ENTITIES.delete(id), 60000).unref();
}

function isBotCreatedEntity(targetId) {
  if (!targetId) return false;
  return _BOT_CREATED_ENTITIES.has(String(targetId));
}

function isAdjustingBackupRoles(guildId) {
  if (!guildId) return false;
  const gid = String(guildId);
  if (_BACKUP_ROLE_MUTEX.has(gid)) return true;
  const last = _LAST_BACKUP_ROLE_ADJUSTMENT.get(gid);
  if (last && Date.now() - last < 5000) return true;
  return false;
}

function markAuthorizedDeletion(guildId, targetId) {
  if (!guildId || !targetId) return;
  const key = `${guildId}:${targetId}`;
  _AUTHORIZED_DELETIONS.add(key);
  setTimeout(() => _AUTHORIZED_DELETIONS.delete(key), 20000).unref();
}

function isAuthorizedDeletion(guildId, targetId) {
  if (!guildId || !targetId) return false;
  return _AUTHORIZED_DELETIONS.has(`${guildId}:${targetId}`);
}

function markBotDeletedEntity(targetId) {
  if (!targetId) return;
  const id = String(targetId);
  _BOT_DELETED_ENTITIES.add(id);
  _CHANNEL_SNAPSHOT_CACHE.delete(id);
  _ROLE_SNAPSHOT_CACHE.delete(id);
  setTimeout(() => _BOT_DELETED_ENTITIES.delete(id), 30000).unref();
}

function isBotDeletedEntity(targetId) {
  if (!targetId) return false;
  return _BOT_DELETED_ENTITIES.has(String(targetId));
}

function evictChannelSnapshot(channelId) {
  if (!channelId) return;
  _CHANNEL_SNAPSHOT_CACHE.delete(String(channelId));
}

function evictRoleSnapshot(roleId) {
  if (!roleId) return;
  _ROLE_SNAPSHOT_CACHE.delete(String(roleId));
}

function cacheChannelSnapshot(ch) {
  if (!ch || !ch.id) return;
  if (_BOT_DELETED_ENTITIES.has(String(ch.id))) return; // Never cache rogue bot-deleted channels
  const snapshotData = {
    name: ch.name,
    type: ch.type,
    topic: ch.topic || undefined,
    nsfw: ch.nsfw || false,
    bitrate: ch.bitrate || undefined,
    userLimit: ch.userLimit || undefined,
    rateLimitPerUser: ch.rateLimitPerUser || undefined,
    parent: ch.parentId || undefined,
    parentId: ch.parentId || undefined,
    position: ch.position || undefined,
    permissionOverwrites: ch.permissionOverwrites?.cache ? [...ch.permissionOverwrites.cache.values()].map(po => ({
      id: po.id,
      type: po.type,
      allow: po.allow !== undefined ? (typeof po.allow === 'bigint' ? po.allow.toString() : (po.allow?.bitfield ? po.allow.bitfield.toString() : String(po.allow))) : '0',
      deny: po.deny !== undefined ? (typeof po.deny === 'bigint' ? po.deny.toString() : (po.deny?.bitfield ? po.deny.bitfield.toString() : String(po.deny))) : '0'
    })) : []
  };

  _CHANNEL_SNAPSHOT_CACHE.set(String(ch.id), snapshotData);

  // Persist to SQLite channel_snapshots table for zero data loss
  const gid = ch.guild?.id || ch.guildId;
  if (gid) {
    try {
      const sdb = getServerDb(gid);
      if (sdb) {
        sdb.prepare(`
          INSERT INTO channel_snapshots (guild_id, channel_id, data, updated_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(guild_id, channel_id) DO UPDATE SET
            data = excluded.data,
            updated_at = excluded.updated_at
        `).run(
          String(gid),
          String(ch.id),
          JSON.stringify(snapshotData, (key, value) => typeof value === 'bigint' ? value.toString() : value),
          Math.floor(Date.now() / 1000)
        );
      }
    } catch (err) {
      console.warn(`[Snapshot Cache] Failed persisting channel ${ch.id} to SQLite:`, err.message);
    }
  }
}

function cacheRoleSnapshot(r) {
  if (!r || !r.id) return;
  if (_BOT_DELETED_ENTITIES.has(String(r.id))) return; // Never cache rogue bot-deleted roles
  const snapshotData = {
    name: r.name,
    color: r.color,
    hoist: r.hoist,
    permissions: r.permissions?.bitfield ? r.permissions.bitfield.toString() : (r.permissions ? String(r.permissions) : '0'),
    mentionable: r.mentionable,
    position: r.position
  };

  _ROLE_SNAPSHOT_CACHE.set(String(r.id), snapshotData);

  // Persist to SQLite role_snapshots table for zero data loss
  const gid = r.guild?.id || r.guildId;
  if (gid) {
    try {
      const sdb = getServerDb(gid);
      if (sdb) {
        sdb.prepare(`
          INSERT INTO role_snapshots (guild_id, role_id, data, updated_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(guild_id, role_id) DO UPDATE SET
            data = excluded.data,
            updated_at = excluded.updated_at
        `).run(
          String(gid),
          String(r.id),
          JSON.stringify(snapshotData, (key, value) => typeof value === 'bigint' ? value.toString() : value),
          Math.floor(Date.now() / 1000)
        );
      }
    } catch (err) {
      console.warn(`[Snapshot Cache] Failed persisting role ${r.id} to SQLite:`, err.message);
    }
  }
}

/**
 * Resolves an image URL, base64 data-URI, or Buffer to a valid binary Buffer for Discord REST API.
 */
async function resolveImageBuffer(urlOrData) {
  if (!urlOrData) return null;
  if (Buffer.isBuffer(urlOrData)) return urlOrData;
  if (typeof urlOrData === 'string') {
    if (urlOrData.startsWith('data:')) {
      const parts = urlOrData.split(',');
      if (parts[1]) return Buffer.from(parts[1], 'base64');
    }
    if (urlOrData.startsWith('http://') || urlOrData.startsWith('https://')) {
      try {
        const res = await fetch(urlOrData);
        if (res && res.ok) {
          const ab = await res.arrayBuffer();
          if (ab) return Buffer.from(ab);
        }
      } catch (_) {}
      return null;
    }
    // Base64 payload check: decode cleanly
    try {
      const clean = urlOrData.replace(/\s+/g, '');
      const buf = Buffer.from(clean, 'base64');
      if (buf.length > 0 && buf.toString('base64') === clean) {
        return buf;
      }
    } catch (_) {}
  }
  return null;
}

/**
 * Captures clean baseline server identity (Name, Icon, Banner, Verification Level) and persists to SQLite.
 */
async function captureServerBaselineIdentity(guild) {
  if (!guild || !guild.id) return null;
  const gid = String(guild.id);
  const sdb = getServerDb(gid);
  if (!sdb) return null;

  const name = guild.name || '';
  const iconUrl = typeof guild.iconURL === 'function' ? guild.iconURL({ size: 1024, forceStatic: false }) : null;
  const bannerUrl = typeof guild.bannerURL === 'function' ? guild.bannerURL({ size: 2048 }) : null;
  const verifLevel = guild.verificationLevel ?? 0;

  let iconBase64 = null;
  if (iconUrl) {
    const buf = await resolveImageBuffer(iconUrl);
    if (buf) iconBase64 = buf.toString('base64');
  }

  let bannerBase64 = null;
  if (bannerUrl) {
    const bBuf = await resolveImageBuffer(bannerUrl);
    if (bBuf) bannerBase64 = bBuf.toString('base64');
  }

  const baselineData = {
    guild_id: gid,
    name,
    icon_url: iconUrl,
    icon_base64: iconBase64,
    banner_url: bannerUrl,
    banner_base64: bannerBase64,
    verification_level: verifLevel
  };
  _SERVER_BASELINE_CACHE.set(gid, baselineData);

  const nowSec = Math.floor(Date.now() / 1000);
  try {
    sdb.prepare(`
      INSERT INTO server_baseline_identity (guild_id, name, icon_url, icon_base64, banner_url, banner_base64, verification_level, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET
        name = excluded.name,
        icon_url = excluded.icon_url,
        icon_base64 = COALESCE(excluded.icon_base64, server_baseline_identity.icon_base64),
        banner_url = excluded.banner_url,
        banner_base64 = COALESCE(excluded.banner_base64, server_baseline_identity.banner_base64),
        verification_level = excluded.verification_level,
        updated_at = excluded.updated_at
    `).run(gid, name, iconUrl, iconBase64, bannerUrl, bannerBase64, verifLevel, nowSec);
  } catch (_) {}

  try {
    const setStmt = sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)');
    setStmt.run('clean_server_name', name);
    if (iconUrl) setStmt.run('clean_server_icon_url', iconUrl);
    if (iconBase64) setStmt.run('clean_server_icon_base64', iconBase64);
    if (bannerUrl) setStmt.run('clean_server_banner_url', bannerUrl);
    if (bannerBase64) setStmt.run('clean_server_banner_base64', bannerBase64);
    setStmt.run('clean_server_verification_level', String(verifLevel));
  } catch (_) {}

  return { name, iconUrl, bannerUrl, verificationLevel: verifLevel };
}

/**
 * Resolves saved baseline server identity for instantaneous auto-heal restoration.
 */
function resolveServerBaselineIdentity(guildId) {
  if (!guildId) return null;
  const gid = String(guildId);
  const memCached = _SERVER_BASELINE_CACHE.get(gid);
  if (memCached && (memCached.name || memCached.icon_base64 || memCached.icon_url)) {
    return memCached;
  }
  try {
    const sdb = getServerDb(gid);
    if (!sdb) return null;
    const row = sdb.prepare('SELECT * FROM server_baseline_identity WHERE guild_id = ?').get(gid);
    if (row) {
      _SERVER_BASELINE_CACHE.set(gid, row);
      return row;
    }
    const nameRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_server_name'").get();
    const iconRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_server_icon_url'").get();
    const iconB64 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_server_icon_base64'").get();
    const bannerRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_server_banner_url'").get();
    const bannerB64 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_server_banner_base64'").get();
    const verifRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_server_verification_level'").get();
    if (nameRow && nameRow.value) {
      const res = {
        guild_id: gid,
        name: nameRow.value,
        icon_url: iconRow?.value || null,
        icon_base64: iconB64?.value || null,
        banner_url: bannerRow?.value || null,
        banner_base64: bannerB64?.value || null,
        verification_level: verifRow ? parseInt(verifRow.value, 10) : 0
      };
      _SERVER_BASELINE_CACHE.set(gid, res);
      return res;
    }
  } catch (_) {}
  return null;
}

function recordAuditLogEntry(entry) {
  if (!entry || !entry.id) return;
  if (!entry.executor && entry.executorId) {
    entry.executor = { id: String(entry.executorId) };
  }
  _AUDIT_LOG_PUSH_CACHE.set(String(entry.id), {
    entry,
    expires: Date.now() + 20000
  });
}

// Prune audit push cache every 30s
setInterval(() => {
  const now = Date.now();
  for (const [id, data] of _AUDIT_LOG_PUSH_CACHE) {
    if (now > data.expires) {
      _AUDIT_LOG_PUSH_CACHE.delete(id);
    }
  }
}, 30000).unref();

function clearImmunityCache(guildId) {
  for (const k of _IMMUNITY_CACHE.keys()) {
    if (k.startsWith(`${guildId}:`)) {
      _IMMUNITY_CACHE.delete(k);
    }
  }
}

const _ANTINUKE_ARMED_CACHE = new Map();
const _RULE_CACHE = new Map();
const FAST_CACHE_TTL = 30000;

function invalidateAntinukeCache(guildId) {
  if (!guildId) {
    _ANTINUKE_ARMED_CACHE.clear();
    _RULE_CACHE.clear();
  } else {
    const gid = String(guildId);
    _ANTINUKE_ARMED_CACHE.delete(gid);
    for (const k of _RULE_CACHE.keys()) {
      if (k.startsWith(gid)) _RULE_CACHE.delete(k);
    }
  }
}

function recordImmunityDbError(guildId, userId) {
  _IMMUNITY_DB_ERRORS.set(`${guildId}:${userId}`, Date.now() + 30000);
}

function hasImmunityDbError(guildId, userId) {
  const expires = _IMMUNITY_DB_ERRORS.get(`${guildId}:${userId}`);
  if (!expires) return false;
  if (Date.now() > expires) {
    _IMMUNITY_DB_ERRORS.delete(`${guildId}:${userId}`);
    return false;
  }
  return true;
}

/**
 * Checks if Antinuke is armed for the given guild.
 * Antinuke armed state: Defaults to FALSE (opt-in security) unless explicitly enabled in server settings.
 */
function isAntinukeArmed(guildId) {
  if (!guildId) return false;
  const gid = String(guildId);
  const now = Date.now();
  const cached = _ANTINUKE_ARMED_CACHE.get(gid);
  if (cached && (now - cached.ts < FAST_CACHE_TTL)) {
    return cached.armed;
  }

  let armed = false;
  try {
    const sdb = getServerDb(gid);
    const statusRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antinuke_status'").get();
    if (statusRow && statusRow.value !== null) {
      const v = String(statusRow.value).toLowerCase().trim();
      armed = v === '1' || v === 'true' || v === 'enabled' || v === 'on';
    } else {
      const enabledRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antinuke.enabled'").get();
      if (enabledRow && enabledRow.value !== null) {
        const v = String(enabledRow.value).toLowerCase().trim();
        armed = v === '1' || v === 'true' || v === 'enabled' || v === 'on';
      }
    }
  } catch (e) {
    armed = false;
  }
  _ANTINUKE_ARMED_CACHE.set(gid, { armed, ts: now });
  return armed;
}

/**
 * Sets Antinuke armed status for a guild, persists to server_settings,
 * invalidates armed cache, and syncs to master DB.
 */
function setAntinukeStatus(guildId, enabled) {
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)')
    .run('antinuke_status', enabled ? '1' : '0');
  _ANTINUKE_ARMED_CACHE.delete(gid);
  try {
    syncServerDataToMaster(gid);
  } catch (_) {}
  return true;
}

const SCOPE_EQUIVALENTS = {
  channel: ['channel', 'channels', 'channel_delete', 'channel_create', 'channel_update'],
  channels: ['channel', 'channels', 'channel_delete', 'channel_create', 'channel_update'],
  channel_delete: ['channel', 'channels', 'channel_delete'],
  channel_create: ['channel', 'channels', 'channel_create'],
  channel_update: ['channel', 'channels', 'channel_update'],
  role: ['role', 'roles', 'role_delete', 'role_create', 'role_update', 'role_escalation'],
  roles: ['role', 'roles', 'role_delete', 'role_create', 'role_update', 'role_escalation'],
  role_delete: ['role', 'roles', 'role_delete'],
  role_create: ['role', 'roles', 'role_create'],
  role_update: ['role', 'roles', 'role_update', 'role_escalation'],
  role_escalation: ['role', 'roles', 'role_update', 'role_escalation'],
  ban: ['ban', 'member', 'members'],
  kick: ['kick', 'member', 'members'],
  prune: ['prune', 'member', 'members'],
  member: ['ban', 'kick', 'prune', 'member', 'members'],
  members: ['ban', 'kick', 'prune', 'member', 'members'],
  bot: ['bot', 'bots', 'bot_add'],
  bots: ['bot', 'bots', 'bot_add'],
  bot_add: ['bot', 'bots', 'bot_add'],
  webhook: ['webhook', 'webhooks'],
  webhooks: ['webhook', 'webhooks'],
  server: ['server', 'server_update', 'vanity'],
  server_update: ['server', 'server_update'],
  vanity: ['vanity', 'server'],
  emoji: ['emoji', 'emojis', 'sticker'],
  emojis: ['emoji', 'emojis', 'sticker'],
  sticker: ['sticker', 'emoji', 'emojis'],
  mention: ['mention', 'ping', 'everyone_ping'],
  ping: ['mention', 'ping', 'everyone_ping'],
  everyone_ping: ['mention', 'ping', 'everyone_ping']
};

/**
 * Checks if a user is immune from Antinuke punishments.
 * Immunity hierarchy:
 * 1. Discord Server Owner (Absolute immunity)
 * 2. Bot Owners (Absolute immunity)
 * 3. Tungsten Bot Client itself (Self-action immunity)
 * 4. Extra Owners (Immunity against all antinuke triggers)
 * 5. Whitelisted Users (Action-specific or global immunity)
 */
function isImmune(guild, userId, action = 'all', memberObj = null, bypassCache = false) {
  if (!guild || !userId) return false;
  const uid = String(userId);
  const gid = typeof guild === 'string' ? guild : String(guild?.id || guild);
  const guildObj = typeof guild === 'object' && guild !== null && guild.id ? guild : null;

  let client = null;
  let actualAction = 'all';
  let actualMember = null;

  if (typeof action === 'string') {
    actualAction = action;
  } else if (typeof action === 'object' && action !== null) {
    if (action.roles || action.guild) {
      actualMember = action;
      actualAction = 'all';
    } else if (action.ws || action.token || (action.guilds && !action.roles)) {
      client = action;
      actualAction = 'roles';
    }
  }

  if (typeof memberObj === 'object' && memberObj !== null) {
    if (memberObj.roles || memberObj.guild) {
      actualMember = memberObj;
      if (!client && memberObj.client) client = memberObj.client;
    } else if (memberObj.ws || memberObj.token || (memberObj.guilds && !memberObj.roles)) {
      client = memberObj;
    } else if (memberObj.user && !memberObj.guilds) {
      actualMember = memberObj;
      if (!client && memberObj.client) client = memberObj.client;
    } else {
      actualMember = memberObj;
    }
  }

  if (!client && guildObj?.client) client = guildObj.client;
  const resolvedGuild = guildObj || (client?.guilds?.cache?.get ? client.guilds.cache.get(gid) : null);

  // 1. Primary Server Owner & Bot Client
  if ((resolvedGuild && resolvedGuild.ownerId === uid) || (guildObj && guildObj.ownerId === uid) || (client?.user?.id === uid) || (guildObj?.client?.user?.id === uid) || (config.BOT_ID && String(config.BOT_ID) === uid)) {
    return true;
  }

  // Watchlist override: Members on watchlist NEVER receive immunity (Prompt #7, Feature #2)
  try {
    const { isWatchlisted } = require('./watchlist');
    if (isWatchlisted(gid, uid)) {
      return false;
    }
  } catch (_) {}

  const cacheKey = `${gid}:${uid}:${actualAction}`;
  if (!bypassCache) {
    const cached = _IMMUNITY_CACHE.get(cacheKey);
    if (cached) {
      if (cached.expires > Date.now()) return cached.value;
      _IMMUNITY_CACHE.delete(cacheKey);
    }
  }

  let immune = false;
  try {
    const sdb = getServerDb(gid);

    // 2. Extra Owners Check
    const eoRow = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(gid, uid);
    if (eoRow) {
      immune = true;
    } else {
      // 3. Whitelisted Users Check (supports expiration and scope equivalence)
      const nowSec = Math.floor(Date.now() / 1000);
      const validActions = Array.from(new Set(['all', '*', actualAction, ...(SCOPE_EQUIVALENTS[actualAction] || [])]));
      const actionPlaceholders = validActions.map(() => '?').join(',');
      const wlRow = sdb.prepare(`
        SELECT 1 FROM whitelisted_users
        WHERE guild_id = ? AND user_id = ? AND action IN (${actionPlaceholders})
          AND (expires_at IS NULL OR expires_at > ?)
      `).get(gid, uid, ...validActions, nowSec);
      if (wlRow) {
        immune = true;
      } else {
        // 4. Whitelisted Roles Check (supports expiration and scope equivalence)
        const targetMember = actualMember || (resolvedGuild?.members?.cache?.get ? resolvedGuild.members.cache.get(uid) : (guildObj?.members?.cache?.get ? guildObj.members.cache.get(uid) : null));
        if (targetMember && targetMember.roles && targetMember.roles.cache) {
          const roleIds = [...targetMember.roles.cache.keys()];
          if (roleIds.length > 0) {
            const rolePlaceholders = roleIds.map(() => '?').join(',');
            const roleRow = sdb.prepare(`
              SELECT 1 FROM whitelisted_roles
              WHERE guild_id = ? AND role_id IN (${rolePlaceholders}) AND action IN (${actionPlaceholders})
                AND (expires_at IS NULL OR expires_at > ?)
            `).get(gid, ...roleIds, ...validActions, nowSec);
            if (roleRow) {
              immune = true;
            }
          }
        }
      }
    }
  } catch (e) {
    recordImmunityDbError(gid, uid);
    console.error(`[Antinuke Engine] DB error during isImmune check for ${uid} in ${gid}: ${e.message} — Flagged lookup error`);
    return false;
  }

  _IMMUNITY_CACHE.set(cacheKey, { value: immune, expires: Date.now() + 15000 });
  return immune;
}

/**
 * Retrieves rule configuration for a specific vector in a guild.
 */
function getAntinukeRule(guildId, vector) {
  const meta = ANTINUKE_VECTORS[vector];
  if (!meta) return null;
  const gid = String(guildId);
  const cacheKey = `${gid}:${vector}`;
  const now = Date.now();
  const cached = _RULE_CACHE.get(cacheKey);
  if (cached && (now - cached.ts < FAST_CACHE_TTL)) {
    return cached.rule;
  }

  let rule = null;
  try {
    const sdb = getServerDb(gid);
    const row = sdb.prepare('SELECT enabled, action, limit_count, time_window, auto_heal FROM antinuke_rules WHERE guild_id = ? AND vector = ?').get(gid, vector);
    if (row) {
      rule = {
        vector,
        name: meta.name,
        enabled: row.enabled === 1,
        action: row.action || meta.defaultAction,
        limit_count: row.limit_count || meta.defaultLimit,
        time_window: row.time_window || meta.defaultWindow,
        auto_heal: row.auto_heal === 1 || (row.auto_heal === null && Boolean(meta.defaultHeal)),
        icon: meta.icon,
        desc: meta.desc
      };
    }
  } catch (e) {}

  if (!rule) {
    rule = {
      vector,
      name: meta.name,
      enabled: true,
      action: meta.defaultAction,
      limit_count: meta.defaultLimit,
      time_window: meta.defaultWindow,
      auto_heal: Boolean(meta.defaultHeal),
      icon: meta.icon,
      desc: meta.desc
    };
  }

  _RULE_CACHE.set(cacheKey, { rule, ts: now });
  return rule;
}

/**
 * Updates or creates rule configuration for a specific vector in a guild.
 */
function setAntinukeRule(guildId, vector, updates = {}) {
  const current = getAntinukeRule(guildId, vector);
  if (!current) return false;
  const gid = String(guildId);
  const enabled = updates.enabled !== undefined ? (updates.enabled ? 1 : 0) : (current.enabled ? 1 : 0);
  const action = updates.action || current.action;
  const limit_count = updates.limit_count !== undefined ? Number(updates.limit_count) : current.limit_count;
  const time_window = updates.time_window !== undefined ? Number(updates.time_window) : current.time_window;
  const auto_heal = updates.auto_heal !== undefined ? (updates.auto_heal ? 1 : 0) : (current.auto_heal ? 1 : 0);

  try {
    const sdb = getServerDb(gid);
    sdb.prepare(`
      INSERT INTO antinuke_rules (guild_id, vector, enabled, action, limit_count, time_window, auto_heal)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, vector) DO UPDATE SET
        enabled = excluded.enabled,
        action = excluded.action,
        limit_count = excluded.limit_count,
        time_window = excluded.time_window,
        auto_heal = excluded.auto_heal
    `).run(gid, vector, enabled, action, limit_count, time_window, auto_heal);
    _RULE_CACHE.delete(`${gid}:${vector}`);
    return true;
  } catch (e) {
    console.error(`[Antinuke Engine] Failed to save rule for ${vector} in ${gid}:`, e.message);
    return false;
  }
}

/**
 * Retrieves all 16 vector rules for a guild.
 */
function getAllAntinukeRules(guildId) {
  const rules = {};
  for (const v of Object.keys(ANTINUKE_VECTORS)) {
    rules[v] = getAntinukeRule(guildId, v);
  }
  return rules;
}

/**
 * Applies a comprehensive antinuke security profile preset across all 16 threat vectors.
 * Presets: 'relaxed', 'balanced', 'strict', 'lockdown'.
 * Upserts all 16 vector rules with enabled = 1 into antinuke_rules,
 * persists preset in server_settings, writes an audit_logs entry,
 * invalidates rule caches, and returns status.
 */
function applyAntinukePreset(guildId, presetName) {
  const norm = String(presetName || '').toLowerCase().trim();
  const preset = ANTINUKE_PRESETS[norm];
  if (!preset) {
    throw new Error(`Invalid antinuke preset: ${presetName}. Valid presets: ${Object.keys(ANTINUKE_PRESETS).join(', ')}`);
  }

  const gid = String(guildId);
  const sdb = getServerDb(gid);

  const upsertStmt = sdb.prepare(`
    INSERT INTO antinuke_rules (guild_id, vector, enabled, action, limit_count, time_window, auto_heal)
    VALUES (?, ?, 1, ?, ?, ?, 1)
    ON CONFLICT(guild_id, vector) DO UPDATE SET
      enabled = 1,
      action = excluded.action,
      limit_count = excluded.limit_count,
      time_window = excluded.time_window,
      auto_heal = 1
  `);

  let vectorsUpdated = 0;
  const applyTx = sdb.transaction(() => {
    for (const vec of Object.keys(ANTINUKE_VECTORS)) {
      const conf = preset[vec];
      if (conf) {
        upsertStmt.run(gid, vec, conf.action, conf.limit_count, conf.time_window);
        vectorsUpdated++;
      }
    }

    sdb.prepare(`
      INSERT OR REPLACE INTO server_settings (key, value)
      VALUES ('antinuke_preset', ?)
    `).run(norm);

    try {
      sdb.prepare(`
        INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
        VALUES ('antinuke_preset_apply', 'system', ?, ?, ?)
      `).run(gid, `Applied antinuke preset: ${norm} (${vectorsUpdated} vectors)`, Math.floor(Date.now() / 1000));
    } catch (e) {}
  });

  applyTx();

  // Invalidate rule caches for the guild
  for (const k of _RULE_CACHE.keys()) {
    if (k.startsWith(gid)) _RULE_CACHE.delete(k);
  }

  return { success: true, preset: norm, vectorsUpdated };
}

/**
 * Sliding-window rate limit check. Returns true if limit is exceeded.
 */
function checkRateLimitExceeded(guildId, userId, action, limit = 2, windowMs = 10000) {
  const key = `${guildId}:${userId}:${action}`;
  const now = Date.now();
  // On-insert sweep to prune entries older than 60 seconds
  cleanupRateLimitBuckets(60000);
  let timestamps = _RATE_LIMIT_BUCKETS.get(key) || [];
  timestamps = timestamps.filter(t => now - t < windowMs);
  timestamps.push(now);
  _RATE_LIMIT_BUCKETS.set(key, timestamps);

  if (timestamps.length === 1) {
    setTimeout(() => {
      const cur = _RATE_LIMIT_BUCKETS.get(key);
      if (cur && cur.every(t => Date.now() - t >= windowMs)) {
        _RATE_LIMIT_BUCKETS.delete(key);
      }
    }, windowMs + 500).unref();
  }

  // Standardized semantic: N actions in window trips on the Nth action (limit 1 trips on 1st action)
  return timestamps.length >= limit;
}

/**
 * Evaluates vector-specific rate limits using configured thresholds.
 * In Ultra Zero-Tolerance mode (limit_count: 1), trips on the very first destructive action.
 */
function checkVectorRateLimit(guildId, userId, vector) {
  const rule = getAntinukeRule(guildId, vector);
  if (!rule || !rule.enabled) return false;

  // Watchlist override: Monitored accounts trigger immediate evaluation on first action (limit_count overridden to 1)
  try {
    const { isWatchlisted } = require('./watchlist');
    if (isWatchlisted(guildId, userId)) {
      return true;
    }
  } catch (_) {}

  // Cross-Vector Actor Threat Scoring evaluation
  const crossThreat = checkCrossVectorThreat(guildId, userId, vector);
  if (crossThreat && crossThreat.tripped) {
    return true;
  }

  return checkRateLimitExceeded(guildId, userId, vector, rule.limit_count, (rule.time_window || 10) * 1000);
}

// ─────────────────────────────────────────────────────────────
// Isolated Quarantine / Jail System (Wick / Olympus Parity)
// ─────────────────────────────────────────────────────────────

async function getOrCreateQuarantineRole(guild) {
  const roleName = 'Tungsten Quarantined';
  let role = null;
  if (typeof guild.roles?.cache?.find === 'function') {
    role = guild.roles.cache.find(r => r.name === roleName);
  } else if (guild.roles?.cache) {
    role = [...guild.roles.cache.values()].find(r => r.name === roleName);
  }

  if (!role && guild.members?.me?.permissions?.has(PermissionsBitField.Flags.ManageRoles) && guild.roles?.create) {
    try {
      role = await guild.roles.create({
        name: roleName,
        colors: { primaryColor: 0x2B2D31, primary: 0x2B2D31 },
        permissions: [],
        hoist: false,
        mentionable: false,
        reason: '[Tungsten Quarantine System] Initializing automated isolation role.'
      });

      // Apply channel overrides to isolate quarantined accounts
      if (guild.channels?.cache) {
        for (const ch of guild.channels.cache.values()) {
          if (typeof ch.permissionOverwrites?.create === 'function') {
            ch.permissionOverwrites.create(role, {
              ViewChannel: false,
              SendMessages: false,
              Connect: false,
              Speak: false,
              CreatePublicThreads: false,
              CreatePrivateThreads: false,
              SendMessagesInThreads: false
            }, { reason: '[Tungsten Quarantine] Isolating quarantined members.' }).catch(() => null);
          }
        }
      }
    } catch (e) {}
  }
  return role;
}

async function quarantineUser(guild, userOrId, reason = 'Quarantined by Antinuke Sentinel', client) {
  const uid = typeof userOrId === 'object' ? userOrId.id : String(userOrId);
  const gid = String(guild.id);
  if (guild.ownerId === uid) return { success: false, reason: 'Owner cannot be quarantined' };

  try {
    const member = guild.members?.cache?.get(uid) || (guild.members?.fetch ? await guild.members.fetch(uid).catch(() => null) : null);
    if (!member) return { success: false, reason: 'Member not found' };

    // BOTS CANNOT BE QUARANTINED: Managed integration roles cannot be removed and bots cannot be timed out!
    if (member.user?.bot || (typeof userOrId === 'object' && userOrId.bot)) {
      return { success: false, reason: 'Bots cannot be quarantined; must be kicked or banned' };
    }

    const rawRoles = member.roles?.cache ? (typeof member.roles.cache.values === 'function' ? [...member.roles.cache.values()] : [...member.roles.cache]) : [];
    const roleIds = rawRoles.filter(r => r && (r.id ? r.id !== guild.id : true)).map(r => r.id || r);
    const sdb = getServerDb(gid);
    const nowSec = Math.floor(Date.now() / 1000);

    sdb.prepare(`
      INSERT OR REPLACE INTO quarantined_users (guild_id, user_id, quarantined_at, quarantined_by, original_roles, reason)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(gid, uid, nowSec, client?.user?.id || 'system', JSON.stringify(roleIds), reason);

    const qRole = await getOrCreateQuarantineRole(guild);
    const botHighest = guild.members?.me?.roles?.highest?.position || 999;
    const rolesToRemove = rawRoles.filter(r => r && (r.id ? r.id !== guild.id : true) && (r.position === undefined || r.position < botHighest));

    if (rolesToRemove.length > 0 && member.roles?.remove) {
      await member.roles.remove(rolesToRemove, `[Tungsten Quarantine] ${reason}`).catch(() => null);
    }
    if (qRole && member.roles?.add && !member.roles.cache?.has(qRole.id)) {
      await member.roles.add(qRole, `[Tungsten Quarantine] ${reason}`).catch(() => null);
    }

    if (member.moderatable && typeof member.timeout === 'function') {
      await member.timeout(28 * 24 * 60 * 60 * 1000, `[Tungsten Quarantine] ${reason}`).catch(() => null);
    }

    return { success: true, quarantinedRoles: roleIds.length };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

async function unquarantineUser(guild, userOrId, client) {
  const uid = typeof userOrId === 'object' ? userOrId.id : String(userOrId);
  const gid = String(guild.id);

  try {
    const sdb = getServerDb(gid);
    const row = sdb.prepare('SELECT original_roles FROM quarantined_users WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (!row) return { success: false, reason: 'User is not quarantined' };

    const member = guild.members?.cache?.get(uid) || (guild.members?.fetch ? await guild.members.fetch(uid).catch(() => null) : null);
    if (member) {
      let qRole = null;
      if (typeof guild.roles?.cache?.find === 'function') {
        qRole = guild.roles.cache.find(r => r.name === 'Tungsten Quarantined' || r.name === 'Tungsten Quarantined');
      } else if (guild.roles?.cache) {
        qRole = [...guild.roles.cache.values()].find(r => r.name === 'Tungsten Quarantined' || r.name === 'Tungsten Quarantined');
      }
      if (qRole && member.roles?.cache?.has(qRole.id) && member.roles?.remove) {
        await member.roles.remove(qRole, '[Tungsten Unquarantine] Lifting isolation.').catch(() => null);
      }

      if (member.isCommunicationDisabled && member.isCommunicationDisabled() && typeof member.timeout === 'function') {
        await member.timeout(null, '[Tungsten Unquarantine] Lifting isolation.').catch(() => null);
      }

      let restoredIds = [];
      try {
        restoredIds = JSON.parse(row.original_roles) || [];
      } catch (e) {}

      const botHighest = guild.members?.me?.roles?.highest?.position || 999;
      const validRoles = restoredIds.filter(rid => {
        const r = guild.roles?.cache?.get(rid);
        return r && r.position < botHighest;
      });

      if (validRoles.length > 0 && member.roles?.add) {
        await member.roles.add(validRoles, '[Tungsten Unquarantine] Restoring original roles.').catch(() => null);
      }
    }

    sdb.prepare('DELETE FROM quarantined_users WHERE guild_id = ? AND user_id = ?').run(gid, uid);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function isUserQuarantined(guildId, userId) {
  try {
    const sdb = getServerDb(String(guildId));
    const row = sdb.prepare('SELECT 1 FROM quarantined_users WHERE guild_id = ? AND user_id = ?').get(String(guildId), String(userId));
    return Boolean(row);
  } catch (e) {
    return false;
  }
}

/**
 * Periodic security task: Audits and enforces channel permission overwrites
 * for the 'Tungsten Quarantined' role across all guild channels.
 */
async function auditQuarantineRoleOverwrites(guild) {
  if (!guild) return { success: false, reason: 'No guild provided' };

  try {
    let qRole = null;
    if (typeof guild.roles?.cache?.find === 'function') {
      qRole = guild.roles.cache.find(r => r.name === 'Tungsten Quarantined');
    } else if (guild.roles?.cache) {
      const vals = typeof guild.roles.cache.values === 'function' ? [...guild.roles.cache.values()] : Object.values(guild.roles.cache);
      qRole = vals.find(r => r.name === 'Tungsten Quarantined');
    }

    if (!qRole && guild.roles?.fetch) {
      const fetched = await guild.roles.fetch().catch(() => null);
      if (fetched) {
        if (typeof fetched.find === 'function') {
          qRole = fetched.find(r => r.name === 'Tungsten Quarantined');
        } else if (typeof fetched.values === 'function') {
          qRole = [...fetched.values()].find(r => r.name === 'Tungsten Quarantined');
        }
      }
    }

    if (!qRole) {
      return { success: true, reason: 'Quarantine role does not exist', audited: 0, updated: 0 };
    }

    let channels = guild.channels?.cache;
    if ((!channels || channels.size === 0) && guild.channels?.fetch) {
      channels = await guild.channels.fetch().catch(() => null);
    }
    if (!channels) return { success: true, audited: 0, updated: 0 };

    const chList = typeof channels.values === 'function' ? [...channels.values()] : Object.values(channels);
    let updated = 0;

    for (const ch of chList) {
      if (!ch) continue;
      const existing = ch.permissionOverwrites?.cache?.get?.(qRole.id)
        || (typeof ch.permissionOverwrites?.get === 'function' ? ch.permissionOverwrites.get(qRole.id) : null);

      const needsUpdate = !existing || (
        existing.deny && typeof existing.deny.has === 'function' &&
        (!existing.deny.has(PermissionsBitField.Flags.ViewChannel) ||
         !existing.deny.has(PermissionsBitField.Flags.SendMessages) ||
         !existing.deny.has(PermissionsBitField.Flags.Connect) ||
         !existing.deny.has(PermissionsBitField.Flags.Speak))
      );

      if (needsUpdate && typeof ch.permissionOverwrites?.create === 'function') {
        await ch.permissionOverwrites.create(qRole, {
          ViewChannel: false,
          SendMessages: false,
          Connect: false,
          Speak: false,
          CreatePublicThreads: false,
          CreatePrivateThreads: false,
          SendMessagesInThreads: false
        }, { reason: '[Tungsten Quarantine Audit] Enforcing channel isolation overrides.' }).catch(() => null);
        updated++;
      }
    }

    return { success: true, audited: chList.length, updated };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ─────────────────────────────────────────────────────────────
// Disaster Recovery Snapshot Manager (Wick / Olympus Parity)
// ─────────────────────────────────────────────────────────────

async function createServerSnapshot(guild, createdBy = 'system', name = null) {
  if (!guild) return null;
  const gid = String(guild.id);
  const sdb = getServerDb(gid);
  const nowSec = Math.floor(Date.now() / 1000);
  const snapshotName = name || `Snapshot ${new Date().toISOString().replace('T', ' ').slice(0, 16)}`;

  const channels = guild.channels?.cache ? [...guild.channels.cache.values()].map(ch => ({
    id: ch.id,
    name: ch.name,
    type: ch.type,
    parentId: ch.parentId,
    position: ch.position,
    topic: ch.topic,
    nsfw: ch.nsfw,
    bitrate: ch.bitrate,
    userLimit: ch.userLimit,
    rateLimitPerUser: ch.rateLimitPerUser
  })) : [];

  const roles = guild.roles?.cache ? [...guild.roles.cache.values()].filter(r => r.id !== guild.id).map(r => ({
    id: r.id,
    name: r.name,
    color: r.color,
    hoist: r.hoist,
    position: r.position,
    permissions: r.permissions?.bitfield ? r.permissions.bitfield.toString() : '0',
    mentionable: r.mentionable
  })) : [];

  const serverMeta = {
    name: guild.name,
    verificationLevel: guild.verificationLevel,
    vanityURLCode: guild.vanityURLCode,
    description: guild.description,
    iconUrl: typeof guild.iconURL === 'function' ? guild.iconURL({ size: 1024, forceStatic: false }) : null,
    bannerUrl: typeof guild.bannerURL === 'function' ? guild.bannerURL({ size: 2048 }) : null
  };

  const res = sdb.prepare(`
    INSERT INTO server_snapshots (guild_id, name, created_by, created_at, channels_data, roles_data, server_data)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(gid, snapshotName, String(createdBy), nowSec, JSON.stringify(channels), JSON.stringify(roles), JSON.stringify(serverMeta));

  return { id: res.lastInsertRowid, name: snapshotName, channelsCount: channels.length, rolesCount: roles.length };
}

/**
 * Captures a clean baseline server snapshot before any attack occurs.
 * Persists the snapshot ID in server_settings as 'clean_baseline_snapshot_id'.
 * @param {object} guild - Discord Guild
 * @returns {Promise<object|null>} Snapshot object or null
 */
async function captureCleanSnapshot(guild) {
  if (!guild || !guild.id) return null;
  try {
    const result = await createServerSnapshot(guild, 'system', 'Pre-Attack Clean Baseline');
    if (result && result.id) {
      const sdb = getServerDb(guild.id);
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('clean_baseline_snapshot_id', ?)")
        .run(String(result.id));
    }
    return result;
  } catch (err) {
    console.warn(`[Antinuke] Failed capturing clean baseline snapshot for ${guild.id}:`, err.message);
    return null;
  }
}

/**
 * Rate-Limit-Aware Recovery Queue
 * Executes a structured restoration sequence for auto-heal or snapshot recovery:
 *   1. Roles (prerequisite for permissions)
 *   2. Categories
 *   3. Channels (text, voice, forum)
 *   4. Channel Permission Overwrites
 *   5. Webhooks
 * All steps are strictly idempotent: checks if role/channel already exists by name/pointer before creating.
 */
async function executeRecoveryQueue(guild, { roles = [], categories = [], channels = [], permissionOverwrites = [], webhooks = [] } = {}) {
  if (!guild) return { success: false, error: 'No guild' };
  if (!guild.members?.me && guild.members?.fetchMe) {
    await guild.members.fetchMe().catch(() => null);
  }
  const botMember = guild.members?.me;
  const canManageRoles = botMember?.permissions?.has(PermissionsBitField.Flags.ManageRoles);
  const canManageChannels = botMember?.permissions?.has(PermissionsBitField.Flags.ManageChannels);
  const canManageWebhooks = botMember?.permissions?.has(PermissionsBitField.Flags.ManageWebhooks);

  const results = {
    roles: 0,
    categories: 0,
    channels: 0,
    overwrites: 0,
    webhooks: 0,
    roleMap: new Map(),
    channelMap: new Map()
  };

  const rawRoles = Array.isArray(roles) ? roles : [];
  let rawChannels = Array.isArray(channels) ? channels : [];
  let rawCategories = Array.isArray(categories) ? categories : [];
  const rawOverwrites = Array.isArray(permissionOverwrites) ? permissionOverwrites : [];
  const rawWebhooks = Array.isArray(webhooks) ? webhooks : [];

  // If categories not explicitly isolated, extract from channels list
  if (rawCategories.length === 0 && rawChannels.length > 0) {
    const isCategory = (c) => c && (c.type === 4 || c.type === ChannelType?.GuildCategory || String(c.type) === 'GUILD_CATEGORY');
    rawCategories = rawChannels.filter(isCategory);
    rawChannels = rawChannels.filter(c => !isCategory(c));
  }

  // 1. ROLES (Prerequisite for permission overwrites)
  if (canManageRoles && rawRoles.length > 0) {
    const existingRoles = guild.roles?.cache ? [...guild.roles.cache.values()] : [];
    const botHighest = botMember?.roles?.highest?.position || 999;

    for (const rData of rawRoles) {
      if (!rData || !rData.name) continue;
      // Idempotency: Check if role already exists by ID or by name
      let role = existingRoles.find(r => (rData.id && String(r?.id) === String(rData.id)) || (r?.name && typeof r.name === 'string' && typeof rData.name === 'string' && r.name.toLowerCase() === rData.name.toLowerCase()));
      if (role) {
        if (rData.id) results.roleMap.set(String(rData.id), role.id);
        continue;
      }
      try {
        const perms = rData.permissions ? BigInt(rData.permissions) : undefined;
        const rolePayload = {
          name: rData.name,
          hoist: rData.hoist,
          permissions: perms,
          mentionable: rData.mentionable,
          reason: '[Tungsten Recovery Queue] Restoring role from verified snapshot.'
        };
        if (rData.color !== undefined && rData.color !== null) {
          rolePayload.colors = { primaryColor: rData.color, primary: rData.color };
        }
        role = await guild.roles.create(rolePayload);
        if (role) {
          cacheRoleSnapshot(role);
          if (rData.id) results.roleMap.set(String(rData.id), role.id);
          results.roles++;
          if (rData.position && typeof role.setPosition === 'function') {
            const safePos = Math.min(rData.position, botHighest - 1);
            if (safePos > 0) await role.setPosition(safePos).catch(() => null);
          }
        }
      } catch (err) {
        console.warn(`[Recovery Queue] Role creation error: ${err.message}`);
      }
    }
  }

  // 2. CATEGORIES
  if (canManageChannels && rawCategories.length > 0) {
    const existingChannels = guild.channels?.cache ? [...guild.channels.cache.values()] : [];
    const isCat = (c) => c && (c.type === 4 || c.type === ChannelType?.GuildCategory || String(c.type) === 'GUILD_CATEGORY');
    for (const catData of rawCategories) {
      if (!catData || !catData.name) continue;
      // Idempotency: Check if category already exists by ID or by name
      let cat = existingChannels.find(c => isCat(c) && ((catData.id && String(c?.id) === String(catData.id)) || (c?.name && typeof c.name === 'string' && typeof catData.name === 'string' && c.name.toLowerCase() === catData.name.toLowerCase())));
      if (cat) {
        if (catData.id) results.channelMap.set(String(catData.id), cat.id);
        continue;
      }
      try {
        cat = await guild.channels.create({
          name: catData.name,
          type: ChannelType?.GuildCategory || 4,
          position: catData.position,
          reason: '[Tungsten Recovery Queue] Restoring category from verified snapshot.'
        });
        if (cat) {
          cacheChannelSnapshot(cat);
          if (catData.id) results.channelMap.set(String(catData.id), cat.id);
          results.categories++;
          results.channels++;
        }
      } catch (err) {
        console.warn(`[Recovery Queue] Category creation error: ${err.message}`);
      }
    }
  }

  // 3. CHANNELS (Text, Voice, Forum, etc.)
  if (canManageChannels && rawChannels.length > 0) {
    const existingChannels = guild.channels?.cache ? [...guild.channels.cache.values()] : [];
    for (const chData of rawChannels) {
      if (!chData || !chData.name) continue;
      // Idempotency: Check if channel already exists by ID or by (name AND type)
      let ch = existingChannels.find(c =>
        (chData.id && String(c?.id) === String(chData.id)) ||
        (c?.name && typeof c.name === 'string' && typeof chData.name === 'string' && c.name.toLowerCase() === chData.name.toLowerCase() && (chData.type === undefined || c.type === chData.type))
      );
      if (ch) {
        if (chData.id) results.channelMap.set(String(chData.id), ch.id);
        continue;
      }
      try {
        const parentId = (chData.parentId && results.channelMap.get(String(chData.parentId))) || chData.parentId || undefined;
        ch = await guild.channels.create({
          name: chData.name,
          type: chData.type !== undefined ? chData.type : 0,
          topic: chData.topic || undefined,
          nsfw: chData.nsfw || false,
          bitrate: chData.bitrate || undefined,
          userLimit: chData.userLimit || undefined,
          rateLimitPerUser: chData.rateLimitPerUser || undefined,
          parent: parentId,
          position: chData.position || undefined,
          reason: '[Tungsten Recovery Queue] Restoring channel from verified snapshot.'
        });
        if (ch) {
          cacheChannelSnapshot(ch);
          if (chData.id) results.channelMap.set(String(chData.id), ch.id);
          results.channels++;
        }
      } catch (err) {
        console.warn(`[Recovery Queue] Channel creation error: ${err.message}`);
      }
    }
  }

  // 4. CHANNEL PERMISSION OVERWRITES
  if (canManageChannels) {
    const combinedChannels = [...rawCategories, ...rawChannels];
    for (const chData of combinedChannels) {
      const overwrites = chData.permissionOverwrites || (chData.id && rawOverwrites[chData.id]) || [];
      if (!Array.isArray(overwrites) || overwrites.length === 0) continue;
      const targetChannelId = results.channelMap.get(String(chData.id)) || chData.id;
      const channel = guild.channels?.cache?.get(targetChannelId);
      if (!channel || typeof channel.permissionOverwrites?.create !== 'function') continue;

      for (const po of overwrites) {
        try {
          const targetId = (po.type === 0 && results.roleMap.get(String(po.id))) || po.id;
          await channel.permissionOverwrites.create(targetId, {
            allow: po.allow ? BigInt(po.allow) : undefined,
            deny: po.deny ? BigInt(po.deny) : undefined
          }, { reason: '[Tungsten Recovery Queue] Restoring permission overwrites.' }).catch(() => null);
          results.overwrites++;
        } catch (_) {}
      }
    }
  }

  // 5. WEBHOOKS
  if (canManageWebhooks && rawWebhooks.length > 0) {
    for (const whData of rawWebhooks) {
      if (!whData || !whData.name) continue;
      const targetChannelId = (whData.channelId && results.channelMap.get(String(whData.channelId))) || whData.channelId;
      const channel = guild.channels?.cache?.get(targetChannelId);
      if (!channel || typeof channel.createWebhook !== 'function') continue;

      try {
        let existingWh = false;
        if (typeof channel.fetchWebhooks === 'function') {
          const whs = await channel.fetchWebhooks().catch(() => null);
          if (whs && [...whs.values()].some(w => w.name === whData.name)) {
            existingWh = true;
          }
        }
        if (!existingWh) {
          await channel.createWebhook({
            name: whData.name,
            avatar: whData.avatar || undefined,
            reason: '[Tungsten Recovery Queue] Restoring webhook from snapshot.'
          });
          results.webhooks++;
        }
      } catch (err) {
        console.warn(`[Recovery Queue] Webhook creation error: ${err.message}`);
      }
    }
  }

  return { success: true, ...results };
}

async function restoreServerSnapshot(guild, snapshotId) {
  if (!guild) return { success: false, error: 'No guild' };
  const gid = String(guild.id);
  const sdb = getServerDb(gid);
  const snapshot = sdb.prepare('SELECT * FROM server_snapshots WHERE guild_id = ? AND id = ?').get(gid, snapshotId);
  if (!snapshot) return { success: false, error: 'Snapshot not found' };

  let channels = [];
  let roles = [];
  let webhooks = [];
  let serverMeta = {};
  try {
    channels = JSON.parse(snapshot.channels_data) || [];
    roles = JSON.parse(snapshot.roles_data) || [];
    serverMeta = JSON.parse(snapshot.server_data) || {};
    if (snapshot.webhooks_data) {
      webhooks = JSON.parse(snapshot.webhooks_data) || [];
    }
  } catch (e) {
    return { success: false, error: 'Malformed snapshot data' };
  }

  const recoveryResults = await executeRecoveryQueue(guild, {
    roles,
    channels,
    webhooks
  });

  if (serverMeta.name && guild.name !== serverMeta.name && typeof guild.setName === 'function') {
    await guild.setName(serverMeta.name, '[Tungsten Disaster Recovery] Restoring server name.').catch(() => null);
  }
  if (serverMeta.iconUrl && typeof guild.setIcon === 'function') {
    const iconBuf = await resolveImageBuffer(serverMeta.iconBase64 || serverMeta.iconUrl);
    if (iconBuf) {
      await guild.setIcon(iconBuf, '[Tungsten Disaster Recovery] Restoring server icon.').catch(() => null);
    }
  }
  if (serverMeta.bannerUrl && typeof guild.setBanner === 'function') {
    const bannerBuf = await resolveImageBuffer(serverMeta.bannerBase64 || serverMeta.bannerUrl);
    if (bannerBuf) {
      await guild.setBanner(bannerBuf, '[Tungsten Disaster Recovery] Restoring server banner.').catch(() => null);
    }
  }
  if (serverMeta.verificationLevel !== undefined && typeof guild.setVerificationLevel === 'function') {
    await guild.setVerificationLevel(serverMeta.verificationLevel, '[Tungsten Disaster Recovery] Restoring verification level.').catch(() => null);
  }

  return {
    success: true,
    restoredChannels: recoveryResults.channels,
    restoredRoles: recoveryResults.roles,
    restoredCategories: recoveryResults.categories,
    restoredOverwrites: recoveryResults.overwrites,
    restoredWebhooks: recoveryResults.webhooks
  };
}

function listServerSnapshots(guildId) {
  try {
    const sdb = getServerDb(String(guildId));
    return sdb.prepare('SELECT id, name, created_by, created_at FROM server_snapshots WHERE guild_id = ? ORDER BY created_at DESC LIMIT 15').all(String(guildId));
  } catch (e) {
    return [];
  }
}

function deleteServerSnapshot(guildId, snapshotId) {
  try {
    const sdb = getServerDb(String(guildId));
    const res = sdb.prepare('DELETE FROM server_snapshots WHERE guild_id = ? AND id = ?').run(String(guildId), snapshotId);
    return res.changes > 0;
  } catch (e) {
    return false;
  }
}

/**
 * Global Raid Velocity Circuit Breaker (Fortress Emergency Shield)
 * Triggers automated emergency panic lockdown if 3 or more destructive events occur within 5 seconds.
 */
async function checkGuildAttackVelocity(guild, client) {
  if (!guild || !guild.id) return false;
  const gid = String(guild.id);
  const now = Date.now();
  let timestamps = _GUILD_ATTACK_VELOCITY.get(gid) || [];
  timestamps = timestamps.filter(t => now - t < 5000);
  timestamps.push(now);
  _GUILD_ATTACK_VELOCITY.set(gid, timestamps);

  if (timestamps.length >= 3) {
    const key = `fortress_active:${gid}`;
    if (!_GUILD_ATTACK_VELOCITY.get(key)) {
      _GUILD_ATTACK_VELOCITY.set(key, true);
      setTimeout(() => _GUILD_ATTACK_VELOCITY.delete(key), 60000).unref();

      console.warn(`[FORTRESS EMERGENCY SHIELD] High attack velocity detected in guild ${gid}! Engaging emergency protections.`);

      if (guild.channels?.cache) {
        for (const ch of guild.channels.cache.values()) {
          if (typeof ch.permissionOverwrites?.edit === 'function') {
            const isVoice = ch.type === ChannelType.GuildVoice || ch.type === ChannelType.GuildStageVoice || ch.type === 2 || ch.type === 13;
            if (isVoice) {
              ch.permissionOverwrites.edit(guild.id, {
                Connect: false,
                Speak: false
              }, { reason: '[Tungsten Fortress Shield] Emergency anti-raid voice lockdown triggered.' }).catch(() => null);
            } else if (ch.isTextBased || ch.type === ChannelType.GuildText || ch.type === 0) {
              ch.permissionOverwrites.edit(guild.id, {
                SendMessages: false,
                CreatePublicThreads: false,
                CreatePrivateThreads: false
              }, { reason: '[Tungsten Fortress Shield] Emergency anti-raid lockdown triggered.' }).catch(() => null);
            }
          }
        }
      }

      if (guild.invites?.fetch) {
        guild.invites.fetch().then(invites => {
          if (invites) {
            const list = typeof invites.values === 'function' ? [...invites.values()] : Object.values(invites);
            for (const invite of list) {
              if (typeof invite.delete === 'function') {
                invite.delete('[Tungsten Fortress Shield] Emergency anti-raid invite revocation.').catch(() => null);
              }
            }
          }
        }).catch(() => null);
      }

      await triggerAutonomousDisasterRecovery(guild, client, 'Fortress Shield High Attack Velocity').catch(() => null);

      dispatchSecurityAlert(guild, {
        title: '<a:tungsten_shield:1567242104923627574> FORTRESS EMERGENCY SHIELD ENGAGED',
        description: `> **CRITICAL MASS RAID DETECTED**\n\nTungsten detected **${timestamps.length} destructive exploits within 5 seconds**! All public channels have been instantly placed under emergency lockdown to prevent server devastation. Malicious actors have been terminated.`,
        color: 0xED4245
      });
      return true;
    }
  }
  return false;
}

const _DISASTER_RECOVERY_DEBOUNCE = new Set();

/**
 * Autonomous Disaster Recovery & Full Server Restoration
 * Neutralizes rogue bots, purges rogue raid channels and webhooks, and executes
 * full reconstruction from clean baseline snapshots with zero human intervention.
 *
 * @param {object} guild - Discord.js Guild
 * @param {object} client - Discord.js Client
 * @param {string} triggerReason - Reason triggering the disaster recovery
 * @returns {Promise<object>} Recovery execution summary
 */
async function triggerAutonomousDisasterRecovery(guild, client, triggerReason = 'Server Exploit Attempt') {
  if (!guild || !guild.id) return { success: false, reason: 'No guild' };
  const gid = String(guild.id);
  const lockKey = `disaster_recovery:${gid}`;
  const now = Date.now();
  const lastTrigger = _DISASTER_RECOVERY_LOCKS.get(lockKey);

  // 30s Cooldown lock so concurrent raid events do not conflict
  if (lastTrigger && now - lastTrigger < 30000) {
    return { success: false, reason: 'Cooldown active', cooldownRemaining: 30000 - (now - lastTrigger) };
  }
  _DISASTER_RECOVERY_LOCKS.set(lockKey, now);
  setTimeout(() => _DISASTER_RECOVERY_LOCKS.delete(lockKey), 30000).unref?.();

  console.warn(`[Tungsten Disaster Recovery] Initiating Autonomous Disaster Recovery in ${guild.name || gid} (${gid}) for: ${triggerReason}`);

  let rogueBotsBanned = 0;
  let rogueChannelsDeleted = 0;
  let rogueWebhooksPurged = 0;
  let restoreResult = {
    success: false,
    restoredChannels: 0,
    restoredRoles: 0,
    restoredCategories: 0,
    restoredOverwrites: 0,
    restoredWebhooks: 0
  };

  const botId = client?.user?.id || guild.client?.user?.id || (config.BOT_ID ? String(config.BOT_ID) : null);

  // ─────────────────────────────────────────────────────────────
  // Step 1: Rogue Bot Neutralization
  // ─────────────────────────────────────────────────────────────
  try {
    let members = [];
    if (guild.members?.cache) {
      members = typeof guild.members.cache.values === 'function'
        ? [...guild.members.cache.values()]
        : Object.values(guild.members.cache);
    }
    if (members.length === 0 && typeof guild.members?.fetch === 'function') {
      const fetched = await guild.members.fetch().catch(() => null);
      if (fetched) {
        members = typeof fetched.values === 'function' ? [...fetched.values()] : Object.values(fetched);
      }
    }

    const banReason = `[Tungsten Disaster Recovery] Rogue bot neutralized during attack: ${triggerReason}`;

    for (const m of members) {
      if (!m || !m.id) continue;
      const isBot = Boolean(m.user?.bot || m.bot);
      if (!isBot) continue;
      if (m.id === botId || m.id === guild.members?.me?.id) continue;
      if (isImmune(guild, m.id, 'all', client)) continue;

      let hasDangerousPerm = false;
      if (m.permissions && typeof m.permissions.has === 'function') {
        hasDangerousPerm = Boolean(
          m.permissions.has('Administrator') ||
          m.permissions.has('ManageChannels') ||
          m.permissions.has('ManageGuild') ||
          (PermissionsBitField?.Flags?.Administrator && m.permissions.has(PermissionsBitField.Flags.Administrator)) ||
          (PermissionsBitField?.Flags?.ManageChannels && m.permissions.has(PermissionsBitField.Flags.ManageChannels)) ||
          (PermissionsBitField?.Flags?.ManageGuild && m.permissions.has(PermissionsBitField.Flags.ManageGuild))
        );
      } else if (m.roles?.cache) {
        const rolesList = typeof m.roles.cache.values === 'function' ? [...m.roles.cache.values()] : Object.values(m.roles.cache);
        for (const r of rolesList) {
          if (r.permissions) {
            if (typeof r.permissions.has === 'function') {
              if (r.permissions.has('Administrator') || r.permissions.has('ManageChannels') || r.permissions.has('ManageGuild')) {
                hasDangerousPerm = true;
                break;
              }
            } else if (typeof r.permissions === 'bigint' || typeof r.permissions === 'string' || typeof r.permissions === 'number') {
              const bp = BigInt(r.permissions);
              if ((bp & 8n) === 8n || (bp & 16n) === 16n || (bp & 32n) === 32n) {
                hasDangerousPerm = true;
                break;
              }
            }
          }
        }
      }

      if (hasDangerousPerm) {
        let banned = false;
        try {
          if (typeof m.ban === 'function') {
            await m.ban({ reason: banReason, deleteMessageSeconds: 86400 });
            banned = true;
          } else if (guild.bans?.create) {
            await guild.bans.create(m.id, { reason: banReason, deleteMessageSeconds: 86400 });
            banned = true;
          }
        } catch (_) {
          if (guild.bans?.create) {
            try {
              await guild.bans.create(m.id, { reason: banReason, deleteMessageSeconds: 86400 });
              banned = true;
            } catch (_) {}
          }
        }

        if (banned) {
          rogueBotsBanned++;
          recordActiveRaidAttacker(gid, m.user || { id: m.id, bot: true });
        }
      }
    }
  } catch (err) {
    console.warn(`[Tungsten Disaster Recovery] Error in Step 1 (Rogue Bot Neutralization):`, err.message);
  }

  // ─────────────────────────────────────────────────────────────
  // Fetch Clean Baseline Snapshot (for Step 2 and Step 4)
  // ─────────────────────────────────────────────────────────────
  const sdb = getServerDb(gid);
  let baselineSnapshot = null;
  let snapshotId = null;

  try {
    const cleanBaselineRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_baseline_snapshot_id'").get();
    if (cleanBaselineRow && cleanBaselineRow.value) {
      snapshotId = Number(cleanBaselineRow.value);
      baselineSnapshot = sdb.prepare('SELECT * FROM server_snapshots WHERE guild_id = ? AND id = ?').get(gid, snapshotId);
    }
    if (!baselineSnapshot) {
      baselineSnapshot = sdb.prepare('SELECT * FROM server_snapshots WHERE guild_id = ? ORDER BY id DESC LIMIT 1').get(gid);
      if (baselineSnapshot) snapshotId = Number(baselineSnapshot.id);
    }
  } catch (_) {}

  const baselineChannelNames = new Set();
  if (baselineSnapshot && baselineSnapshot.channels_data) {
    try {
      const parsedChannels = JSON.parse(baselineSnapshot.channels_data);
      if (Array.isArray(parsedChannels)) {
        for (const bc of parsedChannels) {
          if (bc.name) baselineChannelNames.add(bc.name.toLowerCase());
        }
      }
    } catch (_) {}
  }

  // ─────────────────────────────────────────────────────────────
  // Step 2: Purge Rogue Channels
  // ─────────────────────────────────────────────────────────────
  try {
    const rogueNameRegex = /(?:nuk|raid|hack|fuck|crash|rip|wiz|trash|destroy|defac|spam|tok|clown|t-o-k-e-n|ban|wipe)/i;

    if (guild.channels?.cache) {
      const channelsList = typeof guild.channels.cache.values === 'function'
        ? [...guild.channels.cache.values()]
        : Object.values(guild.channels.cache);

      for (const ch of channelsList) {
        if (!ch || !ch.id) continue;
        if (isAutoHealedEntity(ch.id)) continue;

        const chName = ch.name || '';
        const matchesRoguePattern = rogueNameRegex.test(chName);

        let isRaidCreated = false;
        if (baselineChannelNames.size > 0 && !baselineChannelNames.has(chName.toLowerCase())) {
          const createdTs = ch.createdTimestamp || (ch.createdAt ? new Date(ch.createdAt).getTime() : 0);
          const isRecent = createdTs && (now - createdTs < 15 * 60 * 1000);
          if (isRecent || isBotCreatedEntity(ch.id)) {
            isRaidCreated = true;
          }
        }

        if (matchesRoguePattern || isRaidCreated) {
          markBotDeletedEntity(ch.id);
          evictChannelSnapshot(ch.id);
          if (typeof ch.delete === 'function') {
            let delRes = false;
            try {
              await ch.delete('[Tungsten Disaster Recovery] Purging rogue raid channel.');
              delRes = true;
            } catch (_) {}
            if (delRes) rogueChannelsDeleted++;
          }
        }
      }
    }
  } catch (err) {
    console.warn(`[Tungsten Disaster Recovery] Error in Step 2 (Purge Rogue Channels):`, err.message);
  }

  // ─────────────────────────────────────────────────────────────
  // Step 3: Purge Rogue Webhooks
  // ─────────────────────────────────────────────────────────────
  try {
    if (typeof guild.fetchWebhooks === 'function') {
      const hooks = await guild.fetchWebhooks().catch(() => null);
      if (hooks) {
        const hookList = typeof hooks.values === 'function' ? [...hooks.values()] : (Array.isArray(hooks) ? hooks : Object.values(hooks));
        for (const hook of hookList) {
          if (!hook) continue;
          const hookOwnerId = hook.owner?.id || hook.ownerId;
          if (hookOwnerId !== botId && !isImmune(guild, hookOwnerId, 'webhook', client)) {
            if (typeof hook.delete === 'function') {
              let hookDel = false;
              try {
                await hook.delete('[Tungsten Disaster Recovery] Purging unauthorized webhook during raid.');
                hookDel = true;
              } catch (_) {}
              if (hookDel) rogueWebhooksPurged++;
            }
          }
        }
      }
    }
  } catch (err) {
    console.warn(`[Tungsten Disaster Recovery] Error in Step 3 (Purge Rogue Webhooks):`, err.message);
  }

  // ─────────────────────────────────────────────────────────────
  // Step 4: Reconstruct Baseline Channels & Roles
  // ─────────────────────────────────────────────────────────────
  try {
    if (snapshotId && typeof restoreServerSnapshot === 'function') {
      const res = await restoreServerSnapshot(guild, snapshotId);
      if (res) {
        restoreResult = res;
      }
    }
  } catch (err) {
    console.warn(`[Tungsten Disaster Recovery] Error in Step 4 (Reconstruct Baseline):`, err.message);
  }

  // ─────────────────────────────────────────────────────────────
  // Step 5: Dispatch Security Alert
  // ─────────────────────────────────────────────────────────────
  try {
    const totalRestoredChannels = (restoreResult.restoredChannels || 0) + (restoreResult.restoredCategories || 0);
    const totalRestoredRoles = restoreResult.restoredRoles || 0;

    await dispatchSecurityAlert(guild, {
      title: '<a:tungsten_shield:1567242104923627574> AUTONOMOUS DISASTER RECOVERY ENGAGED',
      description:
        `> **Automated Threat Neutralization & Server Auto-Healing**\n` +
        `Tungsten initiated emergency disaster recovery in response to: **${triggerReason}**.\n\n` +
        `• **Rogue Bots Banned:** \`${rogueBotsBanned}\`\n` +
        `• **Rogue Channels Purged:** \`${rogueChannelsDeleted}\`\n` +
        `• **Unauthorized Webhooks Purged:** \`${rogueWebhooksPurged}\`\n` +
        `• **Restored Channels & Categories:** \`${totalRestoredChannels}\`\n` +
        `• **Restored Roles:** \`${totalRestoredRoles}\`\n\n` +
        `-# All destroyed server assets have been restored from clean baseline.`,
      color: config.COLORS.DANGER
    }).catch(() => null);
  } catch (err) {
    console.warn(`[Tungsten Disaster Recovery] Error in Step 5 (Dispatch Security Alert):`, err.message);
  }

  return {
    success: true,
    rogueBotsBanned,
    rogueChannelsDeleted,
    rogueWebhooksPurged,
    restoreResult
  };
}

/**
 * Helper to check whether a role grants dangerous administrative or moderation permissions.
 */
function isDangerousRole(r) {
  if (!r) return false;
  const p = r.permissions;
  if (!p) return false;
  if (typeof p.has === 'function') {
    return Boolean(
      p.has(PermissionsBitField.Flags.Administrator) ||
      p.has('Administrator') ||
      p.has(PermissionsBitField.Flags.ManageGuild) ||
      p.has('ManageGuild') ||
      p.has('ManageServer') ||
      p.has(PermissionsBitField.Flags.ManageRoles) ||
      p.has('ManageRoles') ||
      p.has(PermissionsBitField.Flags.ManageChannels) ||
      p.has('ManageChannels') ||
      p.has(PermissionsBitField.Flags.BanMembers) ||
      p.has('BanMembers') ||
      p.has(PermissionsBitField.Flags.KickMembers) ||
      p.has('KickMembers') ||
      p.has(PermissionsBitField.Flags.ManageWebhooks) ||
      p.has('ManageWebhooks')
    );
  }
  if (Array.isArray(p)) {
    const dangerous = ['Administrator', 'ManageGuild', 'ManageServer', 'ManageRoles', 'ManageChannels', 'BanMembers', 'KickMembers', 'ManageWebhooks'];
    return p.some(x => dangerous.includes(x));
  }
  return false;
}

/**
 * Punishes an unauthorized attacker with deduplication locks, vector-specific actions,
 * isolation quarantine, accurate status checking, and role-hierarchy fallbacks.
 */
async function punishAttacker(guild, userOrId, reason, client, vectorName = 'Security Violation', vectorKey = null, targetEntity = null, extra = {}) {
  if (!guild) return false;
  const uid = typeof userOrId === 'object' ? userOrId.id : String(userOrId);
  const gid = String(guild.id);

  // Safety: never attempt to punish server owner or bot client
  if (guild.ownerId === uid || (client && client.user && client.user.id === uid)) {
    return false;
  }

  // Fortress Emergency Shield velocity check
  await checkGuildAttackVelocity(guild, client);

  try {
    const { incrementAntinukeTriggerCount } = require('./httpServer');
    incrementAntinukeTriggerCount();
  } catch (e) {}

  let member = null;
  try {
    member = guild.members?.cache?.get(uid) || (guild.members?.fetch ? await guild.members.fetch(uid).catch(() => null) : null);
  } catch (e) {}

  // Record active raid attacker for zero-latency burst correlation across events
  recordActiveRaidAttacker(gid, member?.user || (typeof userOrId === 'object' ? userOrId : { id: uid }));

  // Deduplication collapse window (60s lock per guildId:userId)
  const lockKey = `${gid}:${uid}`;
  const existingLock = _PUNISH_LOCKS.get(lockKey);
  if (existingLock) {
    existingLock.count++;
    // If the attacker was already removed from the server, suppress redundant execution
    if (!guild.members?.cache?.has(uid)) {
      return true;
    }
  }

  const lockEntry = { count: 1, timer: null };
  lockEntry.timer = setTimeout(() => {
    const lock = _PUNISH_LOCKS.get(lockKey);
    if (lock && lock.count > 1) {
      dispatchSecurityAlert(guild, {
        title: `<a:tungsten_shield:1567242104923627574> Defense Summary: ${vectorName}`,
        description: `> **Actor:** <@${uid}> (\`${uid}\`)\n> **Collapsed Violations:** \`${lock.count}\` attack attempts intercepted and neutralized within 60s.`,
        color: config.COLORS.WARNING
      });
    }
    _PUNISH_LOCKS.delete(lockKey);
  }, 60000);
  if (lockEntry.timer.unref) lockEntry.timer.unref();
  _PUNISH_LOCKS.set(lockKey, lockEntry);

  // Detect whether the attacking actor is a bot
  let isBotAttacker = Boolean(member?.user?.bot || (typeof userOrId === 'object' && userOrId.bot) || extra?.isBot);
  if (!isBotAttacker && uid) {
    const cachedUser = client?.users?.cache?.get(uid);
    if (cachedUser?.bot) {
      isBotAttacker = true;
    }
  }

  // Re-verify immunity with freshly resolved member (authoritative check bypassing in-memory cache)
  if (isImmune(guild, uid, vectorKey || 'all', member, true)) {
    return false;
  }

  // Cross-Vector Actor Threat Scoring check
  const crossThreatKey = `${gid}:${uid}`;
  const crossEvents = _CROSS_VECTOR_TRACKER.get(crossThreatKey) || [];
  const crossNow = Date.now();
  const activeCrossEvents = crossEvents.filter(e => (crossNow - e.timestamp) < 10000);
  const crossScore = activeCrossEvents.reduce((s, e) => s + (e.weight || 0), 0);
  const distinctVectors = new Set(activeCrossEvents.map(e => e.vector));

  if (crossScore >= 100 && (distinctVectors.size >= 2 || vectorKey === 'cross_vector_attack')) {
    vectorKey = 'cross_vector_attack';
    vectorName = 'Cross-Vector Attack Sentinel';
    reason = `Multi-vector coordinated attack detected (Threat Score: ${crossScore}/100 across ${activeCrossEvents.length} actions: ${[...distinctVectors].join(', ')})`;
  }

  let sdb;
  try {
    sdb = getServerDb(gid);
  } catch (e) {}

  // Resolve vector-specific configured action (Wick / Olympus standard)
  let configuredAction = 'ban';
  if (vectorKey && vectorKey !== 'cross_vector_attack') {
    const rule = getAntinukeRule(gid, vectorKey);
    if (rule && rule.action) configuredAction = rule.action.toLowerCase();
  } else if (sdb) {
    try {
      const actionRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antinuke_action'").get();
      if (actionRow && actionRow.value) {
        configuredAction = String(actionRow.value).toLowerCase();
      }
    } catch (e) {}
  }

  // BOTS CANNOT BE QUARANTINED OR TIMED OUT: Managed integration roles cannot be removed by Discord API.
  // Quarantining a bot fails silently and leaves rogue nuke bots with full administrative permissions.
  // Any bot attacker MUST be immediately banned (or kicked).
  if (isBotAttacker) {
    if (configuredAction === 'quarantine' || configuredAction === 'strip') {
      configuredAction = 'ban';
    }
  }

  // Fail-safe protection: If DB error was flagged during immunity lookup, downgrade irreversible action
  if (!isBotAttacker && hasImmunityDbError(gid, uid) && (configuredAction === 'ban' || configuredAction === 'kick')) {
    console.warn(`[Antinuke Engine] DB error flagged during immunity lookup for ${uid} in ${gid}. Downgrading punishment to reversible action (strip/quarantine).`);
    configuredAction = 'strip';
  }

  // Check monitor-only mode: query server_settings for antinuke_monitor_only or check if rule's action is 'monitor'
  let isMonitorMode = false;
  if (configuredAction === 'monitor') {
    isMonitorMode = true;
  }
  if (!isMonitorMode && sdb) {
    try {
      const monRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antinuke_monitor_only'").get();
      if (monRow && (monRow.value === '1' || monRow.value === 'true' || monRow.value === 1)) {
        isMonitorMode = true;
      }
    } catch (e) {}
  }

  if (isMonitorMode) {
    const effectiveAction = (configuredAction === 'monitor')
      ? ((vectorKey && ANTINUKE_VECTORS[vectorKey]?.defaultAction) || 'ban')
      : configuredAction;
    const userDisplay = typeof userOrId === 'object' ? (userOrId.tag || userOrId.username || userOrId.id) : String(userOrId);
    const monitorMsg = `Monitor mode: would have executed ${effectiveAction} on ${userDisplay} for ${reason}`;
    const botUserId = client?.user?.id || '0';

    // Log to audit log in server.db
    if (sdb) {
      try {
        sdb.prepare(`
          INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
          VALUES ('antinuke_monitor', ?, ?, ?, ?)
        `).run(String(botUserId), uid, monitorMsg, Math.floor(Date.now() / 1000));
      } catch (e) {}
    }

    // Log to security channel
    dispatchSecurityAlert(guild, {
      title: `<a:tungsten_shield:1567242104923627574> Security Alert: ${vectorName}`,
      description: monitorMsg,
      color: config.COLORS?.INFO || 0x3498db
    });

    // Still execute auto-heal (channel/role recovery) so the server stays healthy
    const entityToHeal = targetEntity || extra?.targetEntity || extra?.channel || extra?.role;
    if (entityToHeal) {
      if (vectorKey === 'channel_delete' || vectorKey === 'channel' || entityToHeal.type !== undefined) {
        await autoHealChannel(guild, entityToHeal).catch(() => null);
      } else if (vectorKey === 'role_delete' || vectorKey === 'role' || entityToHeal.permissions !== undefined) {
        await autoHealRole(guild, entityToHeal).catch(() => null);
      }
    } else if (typeof extra?.autoHeal === 'function') {
      await extra.autoHeal().catch(() => null);
    }

    return { monitored: true, action: effectiveAction, userOrId };
  }

  let punished = false;
  let actionTakenText = 'PERMANENT BAN';
  const botUserId = client?.user?.id || '0';
  const auditReason = `[Tungsten Antinuke] ${vectorName}: ${reason}`;
  const incidentId = `inc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  let strippedRoleIds = [];

  // 1. Quarantine Action (Humans only: never attempt quarantine on bots)
  if (!isBotAttacker && configuredAction === 'quarantine') {
    const qRes = await quarantineUser(guild, uid, auditReason, client);
    if (qRes.success) {
      punished = true;
      actionTakenText = 'ACCOUNT QUARANTINED (ISOLATED)';
    } else {
      configuredAction = 'strip'; // fallback if quarantine failed
    }
  }

  if (!punished) {
    // Role hierarchy check
    const botMember = guild.members?.me || (guild.members?.fetchMe ? await guild.members.fetchMe().catch(() => null) : null);
    const isHierarchyBlocked = member && botMember && member.roles?.highest && botMember.roles?.highest && member.roles.highest.position >= botMember.roles.highest.position;

    if (isHierarchyBlocked) {
      console.warn(`[Antinuke Warning] Role hierarchy blocked direct action on ${uid} in ${gid}`);
      let partialDemoted = false;
      if (member && member.roles?.cache && member.roles?.remove) {
        try {
          const rawMemberRoles = member.roles.cache ? (typeof member.roles.cache.values === 'function' ? [...member.roles.cache.values()] : [...member.roles.cache]) : [];
          const stripRoles = rawMemberRoles.filter(r =>
            !r.managed && r.position < botMember.roles.highest.position && isDangerousRole(r)
          );
          if (stripRoles.length > 0) {
            strippedRoleIds = stripRoles.map(r => r.id);
            await member.roles.remove(stripRoles, `[Antinuke Partial Demotion] ${reason}`).catch(() => null);
            partialDemoted = true;
            punished = true;
            actionTakenText = 'PARTIAL DANGEROUS ROLES STRIPPED';
          }
        } catch (err) {}
      }

      // Timeout is only valid for non-bot members
      if (!isBotAttacker && !partialDemoted && member && member.moderatable && typeof member.timeout === 'function') {
        try {
          await member.timeout(28 * 24 * 60 * 60 * 1000, auditReason).catch(() => null);
          punished = true;
          actionTakenText = 'MAXIMUM TIMEOUT (28 DAYS)';
        } catch (err) {}
      }

      // If rogue bot is hierarchy blocked, attempt direct REST ban/kick anyway
      if (isBotAttacker) {
        checkGuildAttackVelocity(guild, client).catch(() => null);
        if (guild.bans?.create) {
          const bRes = await guild.bans.create(uid, { reason: auditReason, deleteMessageSeconds: 86400 }).catch(() => null);
          if (bRes) {
            punished = true;
            actionTakenText = 'PERMANENT BAN';
          }
        }
        if (!punished && guild.members?.kick) {
          const kRes = await guild.members.kick(uid, auditReason).catch(() => null);
          if (kRes) {
            punished = true;
            actionTakenText = 'KICKED FROM SERVER';
          }
        }
      }

      dispatchSecurityAlert(guild, {
        title: '<a:tungsten_warn:1567246685082746940> Antinuke Hierarchy Alert',
        description: `⚠️ **URGENT:** Attempted to neutralize <@${uid}> for **${vectorName}**, but their highest role is equal to or above Tungsten's top role!\nAction Result: **${actionTakenText}**.\n\n🚨 **Move Tungsten's role to the top in Server Settings -> Roles immediately to enable full autonomous protection!**`,
        color: config.COLORS.DANGER
      });
    } else {
      try {
        // For bot attackers: aggressively strip any non-managed dangerous roles first
        if (isBotAttacker && member && member.roles && typeof member.roles.remove === 'function') {
          try {
            const rawMemberRoles = member.roles.cache ? (typeof member.roles.cache.values === 'function' ? [...member.roles.cache.values()] : [...member.roles.cache]) : [];
            const dangerousRoles = rawMemberRoles.filter(r => !r.managed && isDangerousRole(r));
            if (dangerousRoles.length > 0) {
              strippedRoleIds = dangerousRoles.map(r => r.id);
              await member.roles.remove(dangerousRoles, `[Antinuke Bot Role Strip] ${auditReason}`).catch(() => null);
            }
          } catch (_) {}
        }

        if (!isBotAttacker && configuredAction === 'strip' && member && member.roles && typeof member.roles.remove === 'function') {
          const rawMemberRoles = member.roles.cache ? (typeof member.roles.cache.values === 'function' ? [...member.roles.cache.values()] : [...member.roles.cache]) : [];
          const dangerousRoles = rawMemberRoles.filter(r => !r.managed && isDangerousRole(r));
          if (dangerousRoles.length > 0) {
            strippedRoleIds = dangerousRoles.map(r => r.id);
            await member.roles.remove(dangerousRoles, auditReason).catch(() => null);
          }
          punished = true;
          actionTakenText = 'ADMINISTRATIVE ROLES STRIPPED';
        } else if (configuredAction === 'kick') {
          // Attempt Kick first
          let kicked = false;
          if (member && member.kickable && typeof member.kick === 'function') {
            await member.kick(auditReason);
            kicked = true;
            punished = true;
            actionTakenText = 'KICKED FROM SERVER';
          } else if (guild.members?.kick) {
            const kRes = await guild.members.kick(uid, auditReason).catch(() => null);
            if (kRes) {
              kicked = true;
              punished = true;
              actionTakenText = 'KICKED FROM SERVER';
            }
          }
          // Fallback to ban if kick was unsuccessful (e.g. for a bot)
          if (!kicked) {
            if (member && member.bannable && typeof member.ban === 'function') {
              await member.ban({ deleteMessageSeconds: 86400, reason: auditReason });
              punished = true;
              actionTakenText = 'PERMANENT BAN';
            } else if (guild.bans?.create) {
              const banResult = await guild.bans.create(uid, { reason: auditReason, deleteMessageSeconds: 86400 }).catch(() => null);
              if (banResult) {
                punished = true;
                actionTakenText = 'PERMANENT BAN';
              }
            }
          }
        } else {
          // Default to Ban (Zero-Tolerance)
          let banned = false;
          if (member && member.bannable && typeof member.ban === 'function') {
            await member.ban({ deleteMessageSeconds: 86400, reason: auditReason });
            banned = true;
            punished = true;
            actionTakenText = 'PERMANENT BAN';
          } else if (guild.bans?.create) {
            const banResult = await guild.bans.create(uid, { reason: auditReason, deleteMessageSeconds: 86400 }).catch(() => null);
            if (banResult) {
              banned = true;
              punished = true;
              actionTakenText = 'PERMANENT BAN';
            }
          }

          // Fallback to Kick if Ban failed or was blocked by permissions
          if (!banned) {
            if (member && member.kickable && typeof member.kick === 'function') {
              await member.kick(auditReason).catch(() => null);
              punished = true;
              actionTakenText = 'KICKED FROM SERVER (BAN FALLBACK)';
            } else if (guild.members?.kick) {
              const kRes = await guild.members.kick(uid, auditReason).catch(() => null);
              if (kRes) {
                punished = true;
                actionTakenText = 'KICKED FROM SERVER (BAN FALLBACK)';
              }
            }
          }
        }
      } catch (e) {
        // Fallback: Attempt kick if ban threw
        if (member && member.kickable && typeof member.kick === 'function') {
          try {
            await member.kick(auditReason);
            punished = true;
            actionTakenText = 'KICKED FROM SERVER (ERROR FALLBACK)';
          } catch (_) {}
        } else if (guild.members?.kick) {
          try {
            await guild.members.kick(uid, auditReason);
            punished = true;
            actionTakenText = 'KICKED FROM SERVER (ERROR FALLBACK)';
          } catch (_) {}
        }
        // Fallback: Strip dangerous roles
        if (!punished && member && member.roles && typeof member.roles.remove === 'function') {
          try {
            const rawMemberRoles = member.roles.cache ? (typeof member.roles.cache.values === 'function' ? [...member.roles.cache.values()] : [...member.roles.cache]) : [];
            const dangerousRoles = rawMemberRoles.filter(r => !r.managed && isDangerousRole(r));
            if (dangerousRoles.length > 0) {
              strippedRoleIds = dangerousRoles.map(r => r.id);
              await member.roles.remove(dangerousRoles, auditReason).catch(() => null);
              punished = true;
              actionTakenText = 'ADMINISTRATIVE ROLES STRIPPED (FALLBACK)';
            }
          } catch (stripErr) {}
        }
      }
    }
  }

  // Record into audit_logs in server.db with Incident Tracking
  const incidentPayload = JSON.stringify({
    incidentId,
    actorId: uid,
    vector: vectorKey || vectorName,
    action: configuredAction || actionTakenText,
    evidence: reason,
    healedItems: [],
    strippedRoles: strippedRoleIds
  });
  const nowSec = Math.floor(Date.now() / 1000);

  if (sdb) {
    try {
      const insertRes = sdb.prepare(`
        INSERT INTO audit_logs (guild_id, user_id, action, target_id, reason, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(gid, String(botUserId), 'antinuke_punishment', uid, incidentPayload, nowSec);

      if (insertRes?.lastInsertRowid) {
        try {
          sdb.prepare(`
            UPDATE audit_logs
            SET details = COALESCE(details, reason),
                actor_id = COALESCE(actor_id, user_id),
                timestamp = COALESCE(timestamp, created_at)
            WHERE log_id = ?
          `).run(insertRes.lastInsertRowid);
        } catch (_) {}
      }
    } catch (e) {
      try {
        sdb.prepare(`
          INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
          VALUES ('antinuke_punishment', ?, ?, ?, ?)
        `).run(String(botUserId), uid, incidentPayload, nowSec);
      } catch (_) {}
    }
  }

  // Dispatch alert to log channel with Undo button
  dispatchSecurityAlert(guild, {
    title: `<a:tungsten_shield:1567242104923627574> Defense Interception: ${vectorName}`,
    description:
      `> **Offender Neutralized:** <@${uid}> (\`${uid}\`)\n` +
      `> **Action Taken:** **${actionTakenText}**\n` +
      `> **Trigger:** ${reason}\n` +
      `> **Incident ID:** \`${incidentId}\`\n\n` +
      `• *Tungsten actively monitored and blocked this attack vector with zero data loss.*`,
    color: config.COLORS.DANGER,
    incidentId
  });

  // Fix 4: Invalidate immunity cache and rule cache after punishment completes
  clearImmunityCache(gid);
  for (const k of _RULE_CACHE.keys()) {
    if (k.startsWith(gid)) _RULE_CACHE.delete(k);
  }

  return punished;
}

/**
 * Dispatches an embed to the configured audit log channel and emergency alerts to Server Owner.
 */
async function dispatchSecurityAlert(guild, { title, description, color = config.COLORS.PRIMARY, incidentId = null, components = [] }) {
  try {
    if (!guild) return;
    const sdb = getServerDb(guild.id);
    const priorityKeys = ['log_server', 'log_mod', 'audit_log_channel', 'log_channel', 'modlog_channel'];
    let channel = null;

    let alertComponents = Array.isArray(components) ? [...components] : [];
    if (incidentId && alertComponents.length === 0) {
      const undoBtn = new ButtonBuilder()
        .setCustomId('an:undo:' + incidentId)
        .setLabel('Undo punishment')
        .setStyle(ButtonStyle.Secondary);
      alertComponents = [new ActionRowBuilder().addComponents(undoBtn)];
    }

    for (const key of priorityKeys) {
      const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(key);
      if (row && row.value) {
        const ch = guild.channels?.cache?.get(row.value)
          || (guild.channels?.fetch ? await guild.channels.fetch(row.value).catch(() => null) : null);
        if (ch) {
          const isText = typeof ch.isTextBased === 'function' ? ch.isTextBased() : (Boolean(ch.isTextBased) || typeof ch.send === 'function');
          if (isText) {
            channel = ch;
            break;
          }
        }
      }
    }

    if (channel && typeof channel.send === 'function') {
      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle(title)
        .setDescription(description)
        .setTimestamp()
        .setFooter({ text: 'Tungsten Defense Sentinel • Sub-50ms Reaction' });

      const sendOpts = { embeds: [embed] };
      if (alertComponents.length > 0) sendOpts.components = alertComponents;
      await channel.send(sendOpts).catch(() => null);
    }

    // Critical Emergency Dispatch: Notify server owner directly upon serious attacks
    if (color === config.COLORS.DANGER && guild.ownerId) {
      const owner = guild.members?.cache?.get(guild.ownerId)?.user
        || (guild.client?.users ? await guild.client.users.fetch(guild.ownerId).catch(() => null) : null);
      if (owner && typeof owner.send === 'function') {
        const shieldEmoji = resolveEmoji('shield') || '<a:tungsten_shield:1567242104923627574>';
        const ownerEmbed = new EmbedBuilder()
          .setColor(color)
          .setTitle(`${shieldEmoji} Security Incident Intercepted • ${guild.name}`)
          .setDescription(description)
          .setTimestamp()
          .setFooter({ text: 'Tungsten Enterprise Defense Sentinel' });
        const ownerSendOpts = { embeds: [ownerEmbed] };
        if (alertComponents.length > 0) ownerSendOpts.components = alertComponents;
        await owner.send(ownerSendOpts).catch(() => null);
      }
    }
  } catch (e) {}
}

/**
 * Setup Health Diagnostics
 * Evaluates operational readiness and structural integrity across 4 pillars:
 *   1. Bot Role Hierarchy: Bot's highest role must be above quarantine role and above any protected admin roles.
 *   2. Bot Permissions: ViewAuditLog, BanMembers, KickMembers, ManageRoles, ManageChannels.
 *   3. Log Channel: Security log channel set in server_settings and bot can view/send messages.
 *   4. Dual Backup Roles: Tungsten Backup Tier I and Tier II present in guild.roles.cache.
 * @param {object} guild - Discord.js Guild
 * @param {object} client - TungstenClient
 * @returns {Promise<{ healthy: boolean, checks: Array<{ name: string, passed: boolean, detail: string, fix: string|null }> }>}
 */
async function getAntinukeHealth(guild, client) {
  if (!guild) return { healthy: false, checks: [] };
  if (!guild.members?.me && guild.members?.fetchMe) {
    await guild.members.fetchMe().catch(() => null);
  }
  const botMember = guild.members?.me || (guild.members?.cache?.get(client?.user?.id));
  const checks = [];

  // 1. Bot Role Hierarchy
  let hierarchyPassed = true;
  let hierarchyDetail = 'Bot role is positioned above protected roles.';
  let hierarchyFix = null;
  const botHighest = botMember?.roles?.highest?.position || 0;
  if (!botMember || botHighest === 0) {
    hierarchyPassed = false;
    hierarchyDetail = "Bot member or bot's highest role could not be resolved.";
    hierarchyFix = 'Ensure Tungsten bot is in the guild with assigned roles.';
  } else {
    const rolesCache = guild.roles?.cache ? [...guild.roles.cache.values()] : [];
    // Quarantine role check
    const qRole = rolesCache.find(r => r.name === 'Tungsten Quarantined' || r.name === 'Tungsten Quarantined');
    if (qRole && qRole.position >= botHighest) {
      hierarchyPassed = false;
      hierarchyDetail = `Quarantine role @${qRole.name} is higher than or equal to Tungsten's highest role.`;
      hierarchyFix = 'Move Tungsten role above the Tungsten Quarantined role in Server Settings -> Roles.';
    }
    // Protected admin roles check
    const blockingRoles = rolesCache.filter(r =>
      r.id !== guild.id &&
      r.id !== botMember.roles?.highest?.id &&
      r.position >= botHighest &&
      (r.permissions?.has?.(PermissionsBitField.Flags.Administrator) || r.name.startsWith('Tungsten Backup') || r.name.startsWith('Tungsten Backup'))
    );
    if (blockingRoles.length > 0) {
      hierarchyPassed = false;
      hierarchyDetail = `Found ${blockingRoles.length} administrative/protected role(s) above Tungsten: ${blockingRoles.map(r => '@' + r.name).join(', ')}.`;
      hierarchyFix = 'Move Tungsten role to the top of Server Settings -> Roles (above administrator and backup roles).';
    }
  }
  checks.push({
    name: 'Bot Role Hierarchy',
    passed: hierarchyPassed,
    detail: hierarchyDetail,
    fix: hierarchyFix
  });

  // 2. Bot Permissions
  const requiredPermissions = [
    { flag: PermissionsBitField.Flags.ViewAuditLog, name: 'ViewAuditLog' },
    { flag: PermissionsBitField.Flags.BanMembers, name: 'BanMembers' },
    { flag: PermissionsBitField.Flags.KickMembers, name: 'KickMembers' },
    { flag: PermissionsBitField.Flags.ManageRoles, name: 'ManageRoles' },
    { flag: PermissionsBitField.Flags.ManageChannels, name: 'ManageChannels' }
  ];
  const missingPerms = [];
  for (const perm of requiredPermissions) {
    if (!botMember?.permissions?.has(perm.flag)) {
      missingPerms.push(perm.name);
    }
  }
  const permsPassed = missingPerms.length === 0;
  checks.push({
    name: 'Bot Permissions',
    passed: permsPassed,
    detail: permsPassed
      ? 'All required antinuke management permissions are granted.'
      : `Missing permissions: ${missingPerms.join(', ')}.`,
    fix: permsPassed ? null : `Grant Tungsten the following permissions: ${missingPerms.join(', ')}.`
  });

  // 3. Log Channel
  let logChannelPassed = false;
  let logDetail = 'No security log channel configured.';
  let logFix = 'Configure a log channel using /setup or /setlog.';
  let configuredChannelId = null;
  try {
    const sdb = getServerDb(guild.id);
    const priorityKeys = ['log_server', 'log_mod', 'audit_log_channel', 'log_channel', 'modlog_channel', 'security_log_channel'];
    for (const key of priorityKeys) {
      const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(key);
      if (row && row.value) {
        configuredChannelId = row.value;
        break;
      }
    }
  } catch (_) {}

  if (configuredChannelId) {
    const ch = guild.channels?.cache?.get(configuredChannelId)
      || (guild.channels?.fetch ? await guild.channels.fetch(configuredChannelId).catch(() => null) : null);
    if (!ch) {
      logDetail = `Configured log channel (${configuredChannelId}) not found in server.`;
      logFix = 'Update the log channel setting with an existing text channel.';
    } else {
      const canView = botMember ? (ch.permissionsFor ? ch.permissionsFor(botMember)?.has(PermissionsBitField.Flags.ViewChannel) : true) : true;
      const canSend = botMember ? (ch.permissionsFor ? ch.permissionsFor(botMember)?.has(PermissionsBitField.Flags.SendMessages) : true) : true;
      if (!canView || !canSend) {
        logDetail = `Channel #${ch.name} exists but Tungsten lacks ViewChannel or SendMessages permission.`;
        logFix = 'Ensure Tungsten has ViewChannel and SendMessages permissions in the log channel.';
      } else {
        logChannelPassed = true;
        logDetail = `Security log channel #${ch.name} is configured and accessible.`;
        logFix = null;
      }
    }
  }
  checks.push({
    name: 'Security Log Channel',
    passed: logChannelPassed,
    detail: logDetail,
    fix: logFix
  });

  // 4. Dual Backup Roles
  const roles = guild.roles?.cache ? [...guild.roles.cache.values()] : [];
  const tier1 = roles.find(r => r.name === 'Tungsten Backup Tier I' || r.name === 'Tungsten Backup Tier I');
  const tier2 = roles.find(r => r.name === 'Tungsten Backup Tier II' || r.name === 'Tungsten Backup Tier II');
  const dualBackupPassed = Boolean(tier1 && tier2);
  const missingBackups = [];
  if (!tier1) missingBackups.push('Tungsten Backup Tier I');
  if (!tier2) missingBackups.push('Tungsten Backup Tier II');
  checks.push({
    name: 'Dual Backup Roles',
    passed: dualBackupPassed,
    detail: dualBackupPassed
      ? 'Dual backup roles (Tier I & Tier II) are installed.'
      : `Missing backup roles: ${missingBackups.join(', ')}.`,
    fix: dualBackupPassed ? null : 'Deploy Tungsten Dual Backup Roles using antinuke setup or auto-recovery.'
  });

  const healthy = checks.every(c => c.passed);
  return { healthy, checks };
}

/**
 * Resolves the executor of an audit log event with target matching, extraMatch predicate,
 * push cache fallback, and adaptive retry delays [0, 150, 300, 500, 1000].
 */
async function resolveAuditExecutor(guild, auditType, options = {}) {
  try {
    if (!guild) return null;
    if (!guild.members?.me && guild.members?.fetchMe) {
      await guild.members.fetchMe().catch(() => null);
    }
    if (!guild.members?.me || !guild.members.me.permissions?.has(PermissionsBitField.Flags.ViewAuditLog)) {
      return null;
    }

    const {
      targetId = null,
      extraMatch = null,
      fallbackRecent = false
    } = typeof options === 'number' ? { maxRetries: options } : options;

    let resolvedAuditType = auditType;
    if (auditType === 'BOT_ADD' || auditType === 'BotAdd') {
      resolvedAuditType = AuditLogEvent?.BotAdd || 28;
    }
    const isGuildUpdate = (resolvedAuditType === AuditLogEvent?.GuildUpdate || auditType === AuditLogEvent?.GuildUpdate || resolvedAuditType === 1 || auditType === 1);

    const now = Date.now();
    for (const [id, data] of _AUDIT_LOG_PUSH_CACHE) {
      if (now <= data.expires && data.entry.guildId === guild.id &&
         (data.entry.action === resolvedAuditType || data.entry.action === auditType || String(data.entry.action) === String(resolvedAuditType) || String(data.entry.action) === String(auditType))) {
        const entry = data.entry;
        const age = now - (entry.createdTimestamp || now);
        if (age <= 15000) {
          const isTargetMatch = !targetId || String(entry.targetId) === String(targetId) ||
            (isGuildUpdate && (!entry.targetId || String(entry.targetId) === String(guild.id)));
          if (isTargetMatch) {
            if (!extraMatch || (typeof extraMatch === 'function' && extraMatch(entry))) {
              const exec = entry.executor || (entry.executorId ? (guild.client?.users?.cache?.get(String(entry.executorId)) || { id: String(entry.executorId) }) : null);
              if (exec) return exec;
            }
          }
        }
      }
    }

    // Push cache fallback check for non-immune actor
    if (fallbackRecent && targetId) {
      for (const [id, data] of _AUDIT_LOG_PUSH_CACHE) {
        if (now <= data.expires && data.entry.guildId === guild.id &&
           (data.entry.action === resolvedAuditType || data.entry.action === auditType || String(data.entry.action) === String(resolvedAuditType) || String(data.entry.action) === String(auditType))) {
          const entry = data.entry;
          const age = now - (entry.createdTimestamp || now);
          const exec = entry.executor || (entry.executorId ? (guild.client?.users?.cache?.get(String(entry.executorId)) || { id: String(entry.executorId) }) : null);
          if (age <= 15000 && exec && exec.id) {
            const eid = String(exec.id);
            if (eid !== guild.client?.user?.id && eid !== guild.ownerId && !isImmune(guild, eid, null, null, true)) {
              recordActiveRaidAttacker(guild.id, exec);
              return exec;
            }
          }
        }
      }
    }

    if (!guild.fetchAuditLogs) return null;

    const defaultDelays = (typeof options === 'object' && options?.maxRetries === 5)
      ? [0, 150, 300, 500, 1000]
      : [50, 150, 300, 500, 1000];

    const retryDelays = (typeof options === 'object' && Array.isArray(options?.retryDelays))
      ? options.retryDelays
      : ((typeof options === 'object' && Array.isArray(options?.delays)) ? options.delays : defaultDelays);

    const maxRetries = typeof options === 'number'
      ? options
      : (options.maxRetries ?? (Array.isArray(options?.retryDelays) ? options.retryDelays.length : 3));

    for (let i = 0; i < maxRetries; i++) {
      const delay = retryDelays[i] !== undefined ? retryDelays[i] : (300 * Math.pow(2, i - 2));
      if (delay > 0) await new Promise(r => setTimeout(r, delay));
      const auditLogs = await guild.fetchAuditLogs({ limit: 8, type: resolvedAuditType }).catch(() => null);
      if (auditLogs && auditLogs.entries && auditLogs.entries.size > 0) {
        // Phase 1: Exact targetId match (or GuildUpdate)
        for (const entry of auditLogs.entries.values()) {
          const age = Date.now() - (entry.createdTimestamp || Date.now());
          if (age > 20000) continue;

          const isTargetMatch = !targetId || String(entry.targetId) === String(targetId) ||
            (isGuildUpdate && (!entry.targetId || String(entry.targetId) === String(guild.id)));

          if (!isTargetMatch) {
            continue;
          }

          if (typeof extraMatch === 'function' && !extraMatch(entry)) {
            continue;
          }

          const exec = entry.executor || (entry.executorId ? (guild.client?.users?.cache?.get(String(entry.executorId)) || { id: String(entry.executorId) }) : null);
          if (exec) {
            return exec;
          }
        }

        // Phase 2: If targetId was given but exact match wasn't found, check recent destructive entries from non-immune actors
        if (fallbackRecent && targetId) {
          for (const entry of auditLogs.entries.values()) {
            const age = Date.now() - (entry.createdTimestamp || Date.now());
            if (age > 20000) continue;

            if (typeof extraMatch === 'function' && !extraMatch(entry)) {
              continue;
            }

            const recentExec = entry.executor || (entry.executorId ? (guild.client?.users?.cache?.get(String(entry.executorId)) || { id: String(entry.executorId) }) : null);
            if (recentExec && recentExec.id) {
              const eid = String(recentExec.id);
              if (eid === guild.client?.user?.id || eid === guild.ownerId || isImmune(guild, eid, null, null, true)) {
                continue;
              }
              recordActiveRaidAttacker(guild.id, recentExec);
              return recentExec;
            }
          }
        }
      }
    }
  } catch (e) {}

  // Return null quietly without noisy REST alerts when executor cannot be resolved within retries
  if (guild?.id) {
    const now = Date.now();
    const lastWarn = _UNATTRIBUTED_WARN_TIMESTAMPS.get(guild.id) || 0;
    if (now - lastWarn >= 60000) {
      _UNATTRIBUTED_WARN_TIMESTAMPS.set(guild.id, now);
      console.warn(`[Antinuke Attribution Alert] Unattributed high-velocity security event in ${guild.id}`);
    }
  }
  return null;
}

/**
 * Auto-Heal: Recreates deleted channel with exact configuration and snapshot fidelity.
 * Fortified with deduplication locks, authorized deletion bypass, and 429 resilience.
 */
async function autoHealChannel(guild, channel) {
  try {
    if (!guild || !guild.id) return null;
    const chId = channel?.id ? String(channel.id) : null;
    if (chId) {
      if (isAuthorizedDeletion(guild.id, chId)) return null;
      if (isBotDeletedEntity(chId)) return null;

      const lockKey = `${guild.id}:channel:${chId}`;
      const lastLock = _AUTO_HEAL_LOCKS.get(lockKey);
      if (lastLock && Date.now() - lastLock < 10000) {
        return null; // Deduplicated: already in-progress or restored
      }
    }

    if (!guild.members?.me && guild.members?.fetchMe) {
      await guild.members.fetchMe().catch(() => null);
    }
    if (!guild.members?.me?.permissions?.has(PermissionsBitField.Flags.ManageChannels)) return null;

    // 1. Resolve from in-memory cache
    let cached = chId ? _CHANNEL_SNAPSHOT_CACHE.get(chId) : null;

    // 2. Fallback to SQLite channel_snapshots table
    if (!cached && chId) {
      try {
        const sdb = getServerDb(guild.id);
        const row = sdb.prepare('SELECT data FROM channel_snapshots WHERE guild_id = ? AND channel_id = ?').get(guild.id, chId);
        if (row && row.data) {
          cached = JSON.parse(row.data);
          _CHANNEL_SNAPSHOT_CACHE.set(chId, cached);
        }
      } catch (_) {}
    }

    // 3. Fallback to SQLite server_snapshots table (latest snapshot)
    if (!cached && chId) {
      try {
        const sdb = getServerDb(guild.id);
        const snapRow = sdb.prepare('SELECT channels_data FROM server_snapshots WHERE guild_id = ? ORDER BY id DESC LIMIT 1').get(guild.id);
        if (snapRow && snapRow.channels_data) {
          const snapChannels = JSON.parse(snapRow.channels_data);
          const found = snapChannels.find(c => String(c.id) === chId);
          if (found) {
            cached = found;
            _CHANNEL_SNAPSHOT_CACHE.set(chId, cached);
          }
        }
      } catch (_) {}
    }

    const name = channel?.name || cached?.name;
    if (!name) return null; // Cannot recreate channel without a name

    // Set lock only after verifying name
    if (chId) {
      _AUTO_HEAL_LOCKS.set(`${guild.id}:channel:${chId}`, Date.now());
    }

    const rawType = channel?.type !== undefined ? channel.type : (cached?.type !== undefined ? cached.type : 0);
    const isCategory = (rawType === 4 || rawType === ChannelType.GuildCategory || String(rawType) === 'GUILD_CATEGORY');
    const type = isCategory ? (ChannelType.GuildCategory ?? 4) : rawType;

    const topic = channel?.topic || cached?.topic || undefined;
    const nsfw = channel?.nsfw !== undefined ? channel.nsfw : (cached?.nsfw || false);
    const bitrate = channel?.bitrate || cached?.bitrate || undefined;
    const userLimit = channel?.userLimit || cached?.userLimit || undefined;
    const rateLimitPerUser = channel?.rateLimitPerUser || cached?.rateLimitPerUser || undefined;

    // Check parent category validity: categories CANNOT have a parent
    let parent = isCategory ? undefined : (channel?.parentId || cached?.parent || cached?.parentId || undefined);
    if (parent && guild.channels?.cache) {
      const parentCat = guild.channels.cache.get(parent);
      if (!parentCat) {
        parent = undefined;
      }
    }
    const position = channel?.position !== undefined ? channel.position : (cached?.position || undefined);

    let rawOverwrites = [];
    if (channel?.permissionOverwrites?.cache && channel.permissionOverwrites.cache.size > 0) {
      rawOverwrites = [...channel.permissionOverwrites.cache.values()].map(po => ({
        id: po.id,
        type: po.type,
        allow: po.allow,
        deny: po.deny
      }));
    } else if (cached?.permissionOverwrites && cached.permissionOverwrites.length > 0) {
      rawOverwrites = cached.permissionOverwrites;
    } else if (guild.channels?.cache && guild.channels.cache.size > 0) {
      for (const ch of guild.channels.cache.values()) {
        if (ch && ch.permissionOverwrites?.cache && ch.permissionOverwrites.cache.size > 0) {
          rawOverwrites = [...ch.permissionOverwrites.cache.values()].map(po => ({
            id: po.id,
            type: po.type,
            allow: po.allow,
            deny: po.deny
          }));
          break;
        }
      }
    }

    // Defensive Overwrite Filtering: Strip references to deleted roles or missing members if cache is populated
    let permissionOverwrites = rawOverwrites;
    if (guild.roles?.cache && guild.roles.cache.size > 0) {
      const validRoleIds = new Set(guild.roles.cache.keys());
      const validMemberIds = new Set(guild.members?.cache ? guild.members.cache.keys() : []);
      permissionOverwrites = rawOverwrites.filter(po =>
        po && po.id && (po.id === guild.id || validRoleIds.has(po.id) || validMemberIds.has(po.id))
      );
    }

    let restored = null;
    const createPayload = {
      name,
      type,
      topic,
      nsfw,
      bitrate,
      userLimit,
      rateLimitPerUser,
      parent,
      position,
      permissionOverwrites,
      reason: '[Tungsten Auto-Heal] Re-creating channel deleted by unauthorized actor.'
    };

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        restored = await guild.channels.create(createPayload);
        if (restored) break;
      } catch (err) {
        const errMsg = String(err?.message || '');
        if (errMsg.includes('50035') || errMsg.includes('Unknown Role') || errMsg.includes('Unknown Member') || errMsg.includes('Invalid Form Body')) {
          createPayload.permissionOverwrites = [];
          try {
            restored = await guild.channels.create(createPayload);
            if (restored) break;
          } catch (_) {}
        }
        if (attempt < 3 && err?.status === 429) {
          const retryAfter = (err?.rawError?.retry_after || 0.5) * 1000;
          await new Promise(r => setTimeout(r, retryAfter + (attempt * 200)));
        } else {
          console.warn(`[Auto-Heal Channel Create Error] in ${guild.id}: ${err.message}`);
          break;
        }
      }
    }

    if (restored) {
      markAutoHealedEntity(restored.id);
      markBotCreatedEntity(restored.id);
      cacheChannelSnapshot(restored);
      dispatchSecurityAlert(guild, {
        title: '<a:tungsten_refresh:1567241907116187658> Channel Auto-Healed',
        description: `Channel **#${name}** was deleted in an unauthorized action and has been automatically reconstructed with identical settings and permissions.`,
        color: config.COLORS.SUCCESS
      });
    }

    return restored;
  } catch (e) {
    console.warn(`[Auto-Heal Channel Exception] in ${guild?.id}:`, e.message);
    return null;
  }
}

/**
 * Auto-Heal: Recreates deleted role with exact configuration and snapshot fidelity.
 * Fortified with deduplication locks, hierarchy restoration, and 429 resilience.
 */
async function autoHealRole(guild, role) {
  try {
    if (!guild || !guild.id) return null;
    const roleId = role?.id ? String(role.id) : null;
    if (roleId) {
      if (isAuthorizedDeletion(guild.id, roleId)) return null;
      if (isBotDeletedEntity(roleId)) return null;

      const lockKey = `${guild.id}:role:${roleId}`;
      const lastLock = _AUTO_HEAL_LOCKS.get(lockKey);
      if (lastLock && Date.now() - lastLock < 10000) {
        return null;
      }
    }

    if (!guild.members?.me && guild.members?.fetchMe) {
      await guild.members.fetchMe().catch(() => null);
    }
    if (!guild.members?.me?.permissions?.has(PermissionsBitField.Flags.ManageRoles)) return null;

    let cached = roleId ? _ROLE_SNAPSHOT_CACHE.get(roleId) : null;

    if (!cached && roleId) {
      try {
        const sdb = getServerDb(guild.id);
        const row = sdb.prepare('SELECT data FROM role_snapshots WHERE guild_id = ? AND role_id = ?').get(guild.id, roleId);
        if (row && row.data) {
          cached = JSON.parse(row.data);
          _ROLE_SNAPSHOT_CACHE.set(roleId, cached);
        }
      } catch (_) {}
    }

    if (!cached && roleId) {
      try {
        const sdb = getServerDb(guild.id);
        const snapRow = sdb.prepare('SELECT roles_data FROM server_snapshots WHERE guild_id = ? ORDER BY id DESC LIMIT 1').get(guild.id);
        if (snapRow && snapRow.roles_data) {
          const snapRoles = JSON.parse(snapRow.roles_data);
          const found = snapRoles.find(r => String(r.id) === roleId);
          if (found) {
            cached = found;
            _ROLE_SNAPSHOT_CACHE.set(roleId, cached);
          }
        }
      } catch (_) {}
    }

    const name = role?.name || cached?.name;
    if (!name) return null;

    if (roleId) {
      _AUTO_HEAL_LOCKS.set(`${guild.id}:role:${roleId}`, Date.now());
    }

    const color = role?.color !== undefined ? role.color : (cached?.color !== undefined ? cached.color : 0);
    const hoist = role?.hoist !== undefined ? role.hoist : (cached?.hoist || false);
    const permissions = role?.permissions ? BigInt(role.permissions.bitfield || role.permissions) : (cached?.permissions ? BigInt(cached.permissions) : 0n);
    const mentionable = role?.mentionable !== undefined ? role.mentionable : (cached?.mentionable || false);
    const botHighest = guild.members?.me?.roles?.highest?.position || 999;
    const targetPos = Math.min((role?.position ?? cached?.position ?? 1), botHighest - 1);

    const roleCreatePayload = {
      name,
      hoist,
      permissions,
      mentionable,
      reason: '[Tungsten Auto-Heal] Re-creating role deleted by unauthorized actor.'
    };
    if (color !== undefined && color !== null) {
      roleCreatePayload.colors = { primaryColor: color, primary: color };
    }

    let restored = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        restored = await guild.roles.create(roleCreatePayload);
        if (restored) {
          if (targetPos > 0 && typeof restored.setPosition === 'function') {
            await restored.setPosition(targetPos).catch(() => null);
          }
          break;
        }
      } catch (err) {
        if (attempt < 3 && err?.status === 429) {
          const retryAfter = (err?.rawError?.retry_after || 0.5) * 1000;
          await new Promise(r => setTimeout(r, retryAfter + (attempt * 200)));
        } else {
          // Fallback: create role with standard properties
          try {
            restored = await guild.roles.create({
              name,
              reason: '[Tungsten Auto-Heal Fallback] Re-creating role deleted by unauthorized actor.'
            });
            if (restored) break;
          } catch (_) {}
          console.warn(`[Auto-Heal Role Create Error] in ${guild.id}: ${err.message}`);
          break;
        }
      }
    }

    if (restored) {
      markAutoHealedEntity(restored.id);
      markBotCreatedEntity(restored.id);
      cacheRoleSnapshot(restored);
      dispatchSecurityAlert(guild, {
        title: '<a:tungsten_refresh:1567241907116187658> Role Auto-Healed',
        description: `Role **@${name}** was deleted in an unauthorized action and has been automatically reconstructed with identical settings and permissions.`,
        color: config.COLORS.SUCCESS
      });
    }

    return restored;
  } catch (e) {
    console.warn(`[Auto-Heal Role Exception] in ${guild?.id}:`, e.message);
    return null;
  }
}

/**
 * Real-time Gateway Audit Log Entry Dispatcher
 * Sub-30ms zero-latency threat interception and autonomous damage mitigation.
 */
async function handleRealtimeAuditEntry(entry, guild, client) {
  if (!entry || !guild) return;
  const gid = String(guild.id);
  if (!isAntinukeArmed(gid)) return;

  let executor = entry.executor || (entry.executorId ? (client?.users?.cache?.get(String(entry.executorId)) || { id: String(entry.executorId) }) : null);
  if (!executor || !executor.id) return;
  const eid = String(executor.id);

  // Absolute safety check: Never punish bot itself or guild owner
  if (eid === guild.ownerId || (client?.user && client.user.id === eid)) {
    return;
  }

  const action = entry.action;

  // 1. Channel Deletion
  if (action === AuditLogEvent.ChannelDelete) {
    if (isImmune(guild, eid, 'channel')) {
      markAuthorizedDeletion(gid, entry.targetId);
      return;
    }
    const rule = getAntinukeRule(gid, 'channel_delete');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'channel_delete') || rule.limit_count <= 1) {
      recordActiveRaidAttacker(gid, executor);
      await punishAttacker(guild, executor, `Deleted channel #${entry.target?.name || entry.targetId} (${entry.targetId})`, client, 'Anti-Channel Delete', 'channel_delete', null, { isBot: executor?.bot });
      if (rule?.auto_heal) {
        const hasSnap = _CHANNEL_SNAPSHOT_CACHE.has(entry.targetId) || Boolean(entry.target?.name);
        if (hasSnap) {
          await autoHealChannel(guild, { id: entry.targetId, name: entry.target?.name });
        }
      }
    }
    return;
  }

  // 2. Channel Creation (Spam Raid)
  if (action === AuditLogEvent.ChannelCreate) {
    if (isImmune(guild, eid, 'channel')) return;
    const rule = getAntinukeRule(gid, 'channel_create');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'channel_create') || rule.limit_count <= 1) {
      recordActiveRaidAttacker(gid, executor);
      markBotDeletedEntity(entry.targetId);
      await Promise.allSettled([
        punishAttacker(guild, executor, `Created rogue channel #${entry.target?.name || entry.targetId} during raid`, client, 'Anti-Channel Spam', 'channel_create', null, { isBot: executor?.bot }),
        (async () => {
          const ch = guild.channels?.cache?.get(entry.targetId) || await guild.channels?.fetch(entry.targetId).catch(() => null);
          if (ch && typeof ch.delete === 'function') {
            await ch.delete('[Tungsten Anti-Raid] Deleting rogue channel created during spam attack.').catch(() => null);
          }
        })()
      ]);
    }
    return;
  }

  // 3. Channel Update / Overwrite Tampering
  if (action === AuditLogEvent.ChannelUpdate ||
      action === AuditLogEvent.ChannelOverwriteCreate ||
      action === AuditLogEvent.ChannelOverwriteUpdate ||
      action === AuditLogEvent.ChannelOverwriteDelete) {
    if (isImmune(guild, eid, 'channel')) return;
    const rule = getAntinukeRule(gid, 'channel_update');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'channel_update') || rule.limit_count <= 1) {
      await punishAttacker(guild, executor, `Tampered with channel configuration/overwrites (${entry.targetId})`, client, 'Anti-Channel Overwrite Tampering', 'channel_update');
    }
    return;
  }

  // 4. Role Deletion
  if (action === AuditLogEvent.RoleDelete) {
    if (isImmune(guild, eid, 'role')) {
      markAuthorizedDeletion(gid, entry.targetId);
      return;
    }

    // Fix 8: Backup role deletion protection
    const isBackupRole = entry.target?.name === 'Tungsten Backup Tier I' ||
      entry.target?.name === 'Tungsten Backup Tier II' ||
      entry.target?.name === 'Tungsten Backup Tier I' ||
      entry.target?.name === 'Tungsten Backup Tier II' ||
      (() => {
        try {
          const sdb = getServerDb(gid);
          const r1 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_1'").get();
          const r2 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_2'").get();
          return (r1 && r1.value === entry.targetId) || (r2 && r2.value === entry.targetId);
        } catch (e) {
          return false;
        }
      })();

    if (isBackupRole) {
      await punishAttacker(guild, executor, `Deleted Tungsten Backup Role @${entry.target?.name || entry.targetId} (${entry.targetId})`, client, 'Anti-Role Delete', 'role_delete');
      await ensureDualBackupRoles(guild, { force: true });
      return;
    }

    const rule = getAntinukeRule(gid, 'role_delete');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'role_delete') || rule.limit_count <= 1) {
      recordActiveRaidAttacker(gid, executor);
      await punishAttacker(guild, executor, `Deleted role @${entry.target?.name || entry.targetId} (${entry.targetId})`, client, 'Anti-Role Delete', 'role_delete', null, { isBot: executor?.bot });
      if (rule?.auto_heal) {
        const hasSnap = _ROLE_SNAPSHOT_CACHE.has(entry.targetId) || Boolean(entry.target?.name);
        if (hasSnap) {
          await autoHealRole(guild, { id: entry.targetId, name: entry.target?.name });
        }
      }
    }
    return;
  }

  // 5. Role Creation (Rogue Admin Role / Spam)
  if (action === AuditLogEvent.RoleCreate) {
    if (isImmune(guild, eid, 'role')) return;
    const rule = getAntinukeRule(gid, 'role_create');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'role_create') || rule.limit_count <= 1) {
      markBotDeletedEntity(entry.targetId);
      await Promise.allSettled([
        punishAttacker(guild, executor, `Created rogue role (${entry.targetId}) without authorization`, client, 'Anti-Role Create', 'role_create'),
        (async () => {
          const r = guild.roles?.cache?.get(entry.targetId) || await guild.roles?.fetch(entry.targetId).catch(() => null);
          if (r && typeof r.delete === 'function') {
            await r.delete('[Tungsten Anti-Raid] Deleting rogue role created during raid.').catch(() => null);
          }
        })()
      ]);
    }
    return;
  }

  // 6. Role Update / Escalation
  if (action === AuditLogEvent.RoleUpdate) {
    if (isImmune(guild, eid, 'role')) return;
    const rule = getAntinukeRule(gid, 'role_update');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'role_update') || rule.limit_count <= 1) {
      const cachedRole = _ROLE_SNAPSHOT_CACHE.get(String(entry.targetId));
      if (cachedRole && rule?.auto_heal) {
        const liveRole = guild.roles?.cache?.get(entry.targetId) || await guild.roles?.fetch(entry.targetId).catch(() => null);
        if (liveRole && cachedRole.permissions) {
          await liveRole.setPermissions(cachedRole.permissions, '[Tungsten Anti-Escalation] Reverting unauthorized role privilege tampering.').catch(() => null);
        }
      }

      await punishAttacker(guild, executor, `Modified role permissions/settings for @${entry.target?.name || entry.targetId}`, client, 'Anti-Role Escalation', 'role_update');
    }
    return;
  }

  // 7. Member Ban
  if (action === AuditLogEvent.MemberBanAdd) {
    if (isImmune(guild, eid, 'ban')) return;
    const rule = getAntinukeRule(gid, 'ban');
    if (rule && !rule.enabled) return;

    const victimId = entry.targetId;
    if (checkVectorRateLimit(gid, eid, 'ban') || rule.limit_count <= 1) {
      await punishAttacker(guild, executor, `Banned user (${victimId}) without authorization`, client, 'Anti-Ban Interception', 'ban');
      if (rule?.auto_heal && victimId) {
        await guild.bans?.remove(victimId, '[Tungsten Auto-Heal] Reverting unauthorized ban executed by rogue actor.').catch(() => null);
      }
    }
    return;
  }

  // 8. Member Kick
  if (action === AuditLogEvent.MemberKick) {
    if (isImmune(guild, eid, 'kick')) return;
    const rule = getAntinukeRule(gid, 'kick');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'kick') || rule.limit_count <= 1) {
      await punishAttacker(guild, executor, `Kicked member (${entry.targetId}) without authorization`, client, 'Anti-Kick Interception', 'kick');
    }
    return;
  }

  // 9. Member Prune
  if (action === AuditLogEvent.MemberPrune) {
    if (isImmune(guild, eid, 'prune')) return;
    const rule = getAntinukeRule(gid, 'prune');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'prune') || rule.limit_count <= 1) {
      await punishAttacker(guild, executor, `Initiated unauthorized server member prune`, client, 'Anti-Member Prune', 'prune');
    }
    return;
  }

  // 10. Bot Addition (Rogue Bot Injection)
  if (action === AuditLogEvent.BotAdd) {
    if (isImmune(guild, eid, 'bot')) return;
    const rule = getAntinukeRule(gid, 'bot_add');
    if (rule && !rule.enabled) return;

    const rogueBotId = entry.targetId;
    if (checkVectorRateLimit(gid, eid, 'bot_add') || rule.limit_count <= 1) {
      await Promise.allSettled([
        punishAttacker(guild, executor, `Added unauthorized bot (${rogueBotId})`, client, 'Anti-Bot Add', 'bot_add'),
        (async () => {
          if (!rogueBotId) return;
          const botMember = guild.members?.cache?.get(rogueBotId) || await guild.members?.fetch(rogueBotId).catch(() => null);
          if (botMember && typeof botMember.ban === 'function') {
            await botMember.ban({ reason: `[Tungsten Anti-Bot] Unauthorized bot added by ${executor.username} (${eid})` }).catch(() => null);
          } else if (guild.bans?.create) {
            await guild.bans.create(rogueBotId, { reason: `[Tungsten Anti-Bot] Unauthorized bot added by ${executor.username} (${eid})` }).catch(() => null);
          }
        })()
      ]);
    }
    return;
  }

  // 11. Webhook Create
  if (action === AuditLogEvent.WebhookCreate) {
    if (isImmune(guild, eid, 'webhook', client)) return;
    const rule = getAntinukeRule(gid, 'webhook');
    if (rule && !rule.enabled) return;

    recordActiveRaidAttacker(gid, executor);
    markBotDeletedEntity(entry.targetId);

    await Promise.allSettled([
      punishAttacker(guild, executor, `Created unauthorized webhook (${entry.targetId})`, client, 'Anti-Webhook Rogue', 'webhook', null, { isBot: Boolean(executor?.bot) }),
      (async () => {
        try {
          let targetHook = null;
          if (client?.fetchWebhook && entry.targetId) {
            targetHook = await client.fetchWebhook(entry.targetId).catch(() => null);
          }
          if (!targetHook && guild.fetchWebhooks && entry.targetId) {
            const hooks = await guild.fetchWebhooks().catch(() => null);
            targetHook = hooks?.get(entry.targetId);
          }
          if (targetHook && typeof targetHook.delete === 'function') {
            await targetHook.delete('[Tungsten Anti-Webhook] Deleting rogue webhook created by unauthorized actor.').catch(() => null);
          }
        } catch (_) {}
      })()
    ]);
    return;
  }

  // 12. Emoji Delete
  if (action === AuditLogEvent.EmojiDelete) {
    if (isImmune(guild, eid, 'emoji')) return;
    const rule = getAntinukeRule(gid, 'emoji');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'emoji') || rule.limit_count <= 1) {
      await punishAttacker(guild, executor, `Deleted server emoji (${entry.targetId}) without authorization`, client, 'Anti-Emoji Delete', 'emoji');
    }
    return;
  }

  // 13. Sticker Delete
  if (action === AuditLogEvent.StickerDelete) {
    if (isImmune(guild, eid, 'sticker')) return;
    const rule = getAntinukeRule(gid, 'sticker');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'sticker') || rule.limit_count <= 1) {
      await punishAttacker(guild, executor, `Deleted server sticker (${entry.targetId}) without authorization`, client, 'Anti-Sticker Delete', 'sticker');
    }
    return;
  }

  // 14. Server / Guild Update & Vanity
  if (action === AuditLogEvent.GuildUpdate) {
    recordActiveRaidAttacker(gid, executor);
    // Fix 3: Vanity vector separate handler
    const isVanityChange = Array.isArray(entry.changes) && entry.changes.some(c => c.key === 'vanity_url_code');
    if (isVanityChange) {
      if (isImmune(guild, eid, 'vanity')) return;
      const rule = getAntinukeRule(gid, 'vanity');
      if (rule && !rule.enabled) return;

      if (checkVectorRateLimit(gid, eid, 'vanity') || rule.limit_count <= 1) {
        await punishAttacker(guild, executor, 'Tampered with server vanity URL without authorization', client, 'Anti-Vanity Steal', 'vanity', null, { isBot: executor?.bot });
        if (rule?.auto_heal && typeof guild.setVanityURLCode === 'function') {
          const oldChange = entry.changes.find(c => c.key === 'vanity_url_code');
          if (oldChange && oldChange.old) {
            await guild.setVanityURLCode(oldChange.old, '[Tungsten Auto-Heal] Restoring vanity URL code.').catch(() => null);
          }
        }
      }
      return;
    }

    if (isImmune(guild, eid, 'server')) return;
    const rule = getAntinukeRule(gid, 'server_update');
    if (rule && !rule.enabled) return;

    if (checkVectorRateLimit(gid, eid, 'server_update') || rule.limit_count <= 1) {
      await punishAttacker(guild, executor, `Modified guild settings without authorization`, client, 'Anti-Server Tampering', 'server_update', null, { isBot: executor?.bot });

      // Auto-Heal Server Identity in Realtime
      if (rule?.auto_heal !== false) {
        const baseline = resolveServerBaselineIdentity(gid);
        if (baseline) {
          const nameChange = Array.isArray(entry.changes) && entry.changes.find(c => c.key === 'name');
          if (nameChange && baseline.name && typeof guild.setName === 'function') {
            await guild.setName(baseline.name, '[Tungsten Antinuke] Reverting unauthorized server name change.').catch(() => null);
          }
          const iconChange = Array.isArray(entry.changes) && entry.changes.find(c => c.key === 'icon_hash');
          if (iconChange && typeof guild.setIcon === 'function') {
            const buf = await resolveImageBuffer(baseline.icon_base64 || baseline.icon_url);
            if (buf) await guild.setIcon(buf, '[Tungsten Antinuke] Reverting unauthorized server icon change.').catch(() => null);
            else if (!baseline.icon_url) await guild.setIcon(null).catch(() => null);
          }
          const bannerChange = Array.isArray(entry.changes) && entry.changes.find(c => c.key === 'banner_hash');
          if (bannerChange && typeof guild.setBanner === 'function') {
            const buf = await resolveImageBuffer(baseline.banner_base64 || baseline.banner_url);
            if (buf) await guild.setBanner(buf, '[Tungsten Antinuke] Reverting unauthorized server banner change.').catch(() => null);
            else if (!baseline.banner_url) await guild.setBanner(null).catch(() => null);
          }
          const verifChange = Array.isArray(entry.changes) && entry.changes.find(c => c.key === 'verification_level');
          if (verifChange && baseline.verification_level !== undefined && typeof guild.setVerificationLevel === 'function') {
            await guild.setVerificationLevel(baseline.verification_level, '[Tungsten Antinuke] Reverting verification level.').catch(() => null);
          }
        }
      }
    }
    return;
  }
}

/**
 * Dual Backup Roles Safeguard (Tier I & II)
 * Automatically ensures high-availability administrative backup roles exist
 * and remain anchored to Tungsten whenever Antinuke is armed.
 * Synchronized with _BACKUP_ROLE_MUTEX to prevent concurrent execution races.
 */
async function ensureDualBackupRoles(guild, options = {}) {
  if (!guild || !guild.id) return { success: false, reason: 'No guild provided' };

  if (_BACKUP_ROLE_MUTEX.has(guild.id)) {
    return _BACKUP_ROLE_MUTEX.get(guild.id);
  }

  const runPromise = (async () => {
    try {
      return await _ensureDualBackupRolesInternal(guild, options);
    } finally {
      _LAST_BACKUP_ROLE_ADJUSTMENT.set(guild.id, Date.now());
      _BACKUP_ROLE_MUTEX.delete(guild.id);
    }
  })();

  _BACKUP_ROLE_MUTEX.set(guild.id, runPromise);
  return runPromise;
}

async function _ensureDualBackupRolesInternal(guild, options = {}) {
  if (!guild) return { success: false, reason: 'No guild provided' };

  // 1. Resolve bot member ('me') defensively
  let me = guild.members?.me;
  if (!me && guild.members?.fetchMe) {
    me = await guild.members.fetchMe().catch(() => null);
  }
  if (!me && guild.client?.user?.id && guild.members?.fetch) {
    me = await guild.members.fetch(guild.client.user.id).catch(() => null);
  }
  if (!me) return { success: false, reason: 'Could not resolve bot member (me)' };

  // 2. Permission check: require Administrator or ManageRoles
  const hasAdmin = me.permissions?.has?.(PermissionsBitField.Flags.Administrator);
  const hasManageRoles = me.permissions?.has?.(PermissionsBitField.Flags.ManageRoles);
  if (!hasAdmin && !hasManageRoles) {
    return { success: false, reason: 'Missing ManageRoles / Administrator permissions' };
  }

  // 3. Activation check: Only deploy if Antinuke is explicitly armed or force is set
  const sdb = getServerDb(guild.id);
  const statusRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antinuke_status'").get();
  const backupRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_roles_enabled'").get();
  const isExplicitlyArmed = (statusRow && (statusRow.value === '1' || statusRow.value === 'true')) ||
                            (backupRow && (backupRow.value === '1' || backupRow.value === 'true'));

  const isEnabled = isExplicitlyArmed || Boolean(options.force);
  if (!isEnabled) {
    return { success: false, reason: 'Backup roles require Antinuke to be enabled.' };
  }

  try {
    sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('backup_roles_enabled', '1')").run();
  } catch (e) {}

  const roleNames = ['Tungsten Backup Tier I', 'Tungsten Backup Tier II'];
  const createdRoles = [];

  // Determine permissions for the backup role:
  // If the bot has Administrator, grant Administrator.
  // Otherwise grant all high-privilege permissions the bot possesses.
  const targetPermissions = hasAdmin
    ? [PermissionsBitField.Flags.Administrator]
    : [
        PermissionsBitField.Flags.ManageRoles,
        PermissionsBitField.Flags.ManageChannels,
        PermissionsBitField.Flags.BanMembers,
        PermissionsBitField.Flags.KickMembers,
        PermissionsBitField.Flags.ModerateMembers,
        PermissionsBitField.Flags.ViewAuditLog
      ];

  for (const name of roleNames) {
    // Look in guild.roles.cache (defensive for Collection, Map, or Array)
    let role = null;
    if (guild.roles?.cache) {
      if (typeof guild.roles.cache.find === 'function') {
        role = guild.roles.cache.find(r => r.name === name);
      } else if (typeof guild.roles.cache.values === 'function') {
        role = [...guild.roles.cache.values()].find(r => r.name === name);
      }
    }

    // If not found in cache, but guild.roles.fetch exists, try fetching from Discord REST
    if (!role && guild.roles?.fetch) {
      try {
        const fetchedRoles = await guild.roles.fetch().catch(() => null);
        if (fetchedRoles) {
          if (typeof fetchedRoles.find === 'function') {
            role = fetchedRoles.find(r => r.name === name || r.name === legacyName);
          } else if (typeof fetchedRoles.values === 'function') {
            role = [...fetchedRoles.values()].find(r => r.name === name || r.name === legacyName);
          }
        }
      } catch (e) {}
    }

    // If still not found, create it
    if (!role && guild.roles?.create) {
      try {
        role = await guild.roles.create({
          name: name,
          colors: { primaryColor: 0x2B2D31, primary: 0x2B2D31 },
          permissions: targetPermissions,
          hoist: false,
          mentionable: false,
          reason: '[Tungsten Dual-Role Safeguard] High-availability antinuke administrator role.'
        });
        console.log(`[DualBackupRoles] Created role ${name} (${role.id}) in guild ${guild.name || guild.id}`);
      } catch (err) {
        console.warn(`[DualBackupRoles Error] Failed to create ${name} in ${guild.id}:`, err.message);
      }
    }

    if (role) {
      // Check if bot already has this role
      let hasRole = false;
      if (me.roles?.cache) {
        if (typeof me.roles.cache.has === 'function') {
          hasRole = me.roles.cache.has(role.id);
        } else if (typeof me.roles.cache.values === 'function') {
          hasRole = [...me.roles.cache.values()].some(r => r.id === role.id);
        }
      }

      let assignedSuccessfully = true;

      if (!hasRole && me.roles?.add) {
        try {
          await me.roles.add(role, 'Tungsten Dual-Role Safeguard binding');
          console.log(`[DualBackupRoles] Successfully bound ${name} (${role.id}) to Tungsten in guild ${guild.id}`);
        } catch (addErr) {
          console.warn(`[DualBackupRoles Error] Failed to assign ${name} to Tungsten in ${guild.id}:`, addErr.message);
          const isUnknownRole = addErr?.code === 10011 ||
                                (typeof addErr?.message === 'string' && addErr.message.includes('Unknown Role')) ||
                                (addErr?.rawError && addErr.rawError.code === 10011);
          if (isUnknownRole) {
            assignedSuccessfully = false;
            try {
              if (guild.roles?.cache?.delete) {
                guild.roles.cache.delete(role.id);
              }
              if (me.roles?.cache?.delete) {
                me.roles.cache.delete(role.id);
              }
              evictRoleSnapshot(role.id);
            } catch (_) {}
          }
        }
      }

      if (assignedSuccessfully) {
        createdRoles.push(role);

        // Try to optimize position: place right below Tungsten's highest role
        try {
          const highestPos = me.roles?.highest?.position || 0;
          if (highestPos > 1 && role.position < highestPos - 1 && role.setPosition) {
            await role.setPosition(highestPos - 1).catch(() => null);
          }
        } catch (posErr) {}
      }
    }
  }

  // Persist backup role IDs in server_settings
  try {
    const tier1Role = createdRoles.find(r => r.name.includes('Tier I')) || (createdRoles[0]?.name?.includes('Tier II') ? null : createdRoles[0]);
    const tier2Role = createdRoles.find(r => r.name.includes('Tier II')) || (createdRoles[1]?.name?.includes('Tier I') ? null : createdRoles[1]);

    if (tier1Role) {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('backup_role_tier_1', ?)").run(tier1Role.id);
    }
    if (tier2Role) {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('backup_role_tier_2', ?)").run(tier2Role.id);
    }
    syncServerDataToMaster(guild.id);
  } catch (e) {}

  return { success: true, roles: createdRoles.map(r => r.id) };
}

/**
 * Checks if a channel is whitelisted for a specific action scope or 'all'.
 */
function isChannelWhitelisted(guildId, channelId, scope = 'all') {
  if (!guildId || !channelId) return false;
  try {
    const sdb = getServerDb(String(guildId));
    const row = sdb.prepare(`
      SELECT 1 FROM whitelisted_channels
      WHERE guild_id = ? AND channel_id = ? AND (scope = 'all' OR scope = ?)
    `).get(String(guildId), String(channelId), String(scope));
    return Boolean(row);
  } catch (e) {
    return false;
  }
}

module.exports = {
  VALID_ACTIONS,
  ANTINUKE_VECTORS,
  ANTINUKE_PRESETS,
  applyAntinukePreset,
  isAntinukeArmed,
  setAntinukeStatus,
  isImmune,
  hasImmunityDbError,
  recordImmunityDbError,
  isChannelWhitelisted,
  clearImmunityCache,
  getAntinukeRule,
  setAntinukeRule,
  getAllAntinukeRules,
  checkVectorRateLimit,
  quarantineUser,
  unquarantineUser,
  isUserQuarantined,
  auditQuarantineRoleOverwrites,
  createServerSnapshot,
  captureCleanSnapshot,
  restoreServerSnapshot,
  listServerSnapshots,
  deleteServerSnapshot,
  punishAttacker,
  dispatchSecurityAlert,
  resolveAuditExecutor,
  autoHealChannel,
  autoHealRole,
  handleRealtimeAuditEntry,
  cacheChannelSnapshot,
  cacheRoleSnapshot,
  checkRateLimitExceeded,
  invalidateAntinukeCache,
  ensureDualBackupRoles,
  recordAuditLogEntry,
  markAuthorizedDeletion,
  isAuthorizedDeletion,
  markBotDeletedEntity,
  isBotDeletedEntity,
  evictChannelSnapshot,
  evictRoleSnapshot,
  checkGuildAttackVelocity,
  getAntinukeHealth,
  executeRecoveryQueue,
  cleanupRateLimitBuckets,
  checkCrossVectorThreat,
  _CROSS_VECTOR_TRACKER,
  CROSS_VECTOR_WEIGHTS,
  _RATE_LIMIT_BUCKETS,
  _AUTO_HEAL_LOCKS,
  _AUTHORIZED_DELETIONS,
  _BOT_DELETED_ENTITIES,
  _AUDIT_LOG_PUSH_CACHE,
  _CHANNEL_SNAPSHOT_CACHE,
  _ROLE_SNAPSHOT_CACHE,
  _PUNISH_LOCKS,
  _BACKUP_ROLE_MUTEX,
  isAdjustingBackupRoles,
  markAutoHealedEntity,
  isAutoHealedEntity,
  markBotCreatedEntity,
  isBotCreatedEntity,
  captureServerBaselineIdentity,
  resolveServerBaselineIdentity,
  resolveImageBuffer,
  getActiveRaidAttacker,
  recordActiveRaidAttacker,
  _ACTIVE_RAID_ATTACKERS,
  _DISASTER_RECOVERY_LOCKS,
  triggerAutonomousDisasterRecovery
};
