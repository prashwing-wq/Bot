/**
 * Tungsten Dynamic Member Trust Score Engine (Node.js)
 * Implements dynamic numeric reputation & threat analysis scoring (0–100) per member
 * based on account age, server tenure, chat activity, automod strikes, warnings,
 * and previous moderation history.
 *
 * Production Invariants:
 * - Dynamic numeric score clamped strictly between 0 and 100.
 * - Base score: 50.
 * - +15 if account age > 30 days
 * - +10 if account age > 1 year
 * - +10 if member has been in server > 7 days
 * - +10 if member has sent >= 10 messages (from DB message counts)
 * - -20 if member has 1+ automod strikes in last 7 days
 * - -30 if member has 1+ warnings in last 30 days
 * - -40 if member has been previously banned (and unbanned)
 * - -50 if member has 0 days server tenure (just joined)
 * - SQLite table: member_trust_scores (guild_id, user_id, score, calculated_at, signal_flags)
 * - Custom Tungsten emojis only. Zero raw unicode emojis.
 */

const { getServerDb } = require('./serverDb');

const MS_PER_DAY = 86400000;
const MS_PER_YEAR = 365 * MS_PER_DAY;
const DISCORD_EPOCH = 1420070400000n;

/**
 * Ensures the member_trust_scores and member_messages tables exist in guild SQLite DB.
 * @param {import('better-sqlite3').Database} db
 */
function ensureTrustScoreTable(db) {
  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS member_trust_scores (
        guild_id TEXT,
        user_id TEXT,
        score INTEGER,
        calculated_at INTEGER,
        signal_flags TEXT,
        PRIMARY KEY (guild_id, user_id)
      );
      CREATE INDEX IF NOT EXISTS idx_member_trust_scores_guild_user ON member_trust_scores (guild_id, user_id);

      CREATE TABLE IF NOT EXISTS member_messages (
        guild_id TEXT,
        user_id TEXT,
        message_count INTEGER DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
      );
    `);
  } catch (_) {}
}

/**
 * Increments or sets the tracked message count for a member in a guild.
 * @param {string} guildId
 * @param {string} userId
 * @param {number} [amount=1]
 */
function recordMemberMessage(guildId, userId, amount = 1) {
  const gid = String(guildId);
  const uid = String(userId);
  try {
    const sdb = getServerDb(gid);
    ensureTrustScoreTable(sdb);
    sdb.prepare(`
      INSERT INTO member_messages (guild_id, user_id, message_count)
      VALUES (?, ?, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET
        message_count = member_messages.message_count + excluded.message_count
    `).run(gid, uid, amount);
  } catch (_) {}
}

/**
 * Retrieves the total message count for a member from multiple DB representations.
 * @param {import('better-sqlite3').Database} sdb
 * @param {string} guildId
 * @param {string} userId
 * @returns {number}
 */
function getUserMessageCount(sdb, guildId, userId) {
  const gid = String(guildId);
  const uid = String(userId);

  // 1. Check member_messages table
  try {
    const row = sdb.prepare('SELECT message_count FROM member_messages WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (row && typeof row.message_count === 'number') {
      return row.message_count;
    }
  } catch (_) {}

  // 2. Check user_messages table if present
  try {
    const row = sdb.prepare('SELECT message_count FROM user_messages WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (row && typeof row.message_count === 'number') {
      return row.message_count;
    }
  } catch (_) {}

  // 3. Check leveling_users table
  try {
    const lvlRow = sdb.prepare('SELECT * FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (lvlRow) {
      if (typeof lvlRow.message_count === 'number') return lvlRow.message_count;
      if (typeof lvlRow.messages === 'number') return lvlRow.messages;
      // In Tungsten leveling system, 15-25 XP per minute/message: >= 150 XP or level >= 1 indicates >= 10 messages
      if (typeof lvlRow.xp === 'number' && lvlRow.xp >= 150) return Math.floor(lvlRow.xp / 15);
      if (typeof lvlRow.level === 'number' && lvlRow.level >= 1) return 10;
    }
  } catch (_) {}

  return 0;
}

/**
 * Checks if a member has 1 or more automod strikes within the last 7 days.
 * @param {import('better-sqlite3').Database} sdb
 * @param {string} guildId
 * @param {string} userId
 * @param {number} nowMs
 * @returns {boolean}
 */
function checkAutomodStrikesLast7Days(sdb, guildId, userId, nowMs) {
  const gid = String(guildId);
  const uid = String(userId);
  const sevenDaysAgoMs = nowMs - (7 * MS_PER_DAY);
  const sevenDaysAgoSec = Math.floor(sevenDaysAgoMs / 1000);

  try {
    const strikeRow = sdb.prepare('SELECT strikes, last_strike_at FROM automod_strikes WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (strikeRow && Number(strikeRow.strikes) >= 1) {
      const t = Number(strikeRow.last_strike_at);
      const ms = t > 100000000000 ? t : t * 1000;
      if (ms >= sevenDaysAgoMs) {
        return true;
      }
    }
  } catch (_) {}

  try {
    const logRow = sdb.prepare(`
      SELECT 1 FROM automod_logs
      WHERE guild_id = ? AND user_id = ?
        AND (
          (timestamp > 100000000000 AND timestamp >= ?) OR
          (timestamp <= 100000000000 AND timestamp >= ?)
        )
      LIMIT 1
    `).get(gid, uid, sevenDaysAgoMs, sevenDaysAgoSec);
    if (logRow) return true;
  } catch (_) {}

  return false;
}

/**
 * Checks if a member has 1 or more warnings within the last 30 days.
 * @param {import('better-sqlite3').Database} sdb
 * @param {string} guildId
 * @param {string} userId
 * @param {number} nowMs
 * @returns {boolean}
 */
function checkWarningsLast30Days(sdb, guildId, userId, nowMs) {
  const gid = String(guildId);
  const uid = String(userId);
  const thirtyDaysAgoMs = nowMs - (30 * MS_PER_DAY);
  const thirtyDaysAgoSec = Math.floor(thirtyDaysAgoMs / 1000);

  try {
    const warnRow = sdb.prepare(`
      SELECT 1 FROM member_warnings
      WHERE guild_id = ? AND user_id = ?
        AND (
          (timestamp > 100000000000 AND timestamp >= ?) OR
          (timestamp <= 100000000000 AND timestamp >= ?)
        )
      LIMIT 1
    `).get(gid, uid, thirtyDaysAgoMs, thirtyDaysAgoSec);
    if (warnRow) return true;
  } catch (_) {}

  try {
    const caseRow = sdb.prepare(`
      SELECT 1 FROM mod_cases
      WHERE guild_id = ? AND user_id = ? AND LOWER(action) = 'warn'
        AND (
          (timestamp > 100000000000 AND timestamp >= ?) OR
          (timestamp <= 100000000000 AND timestamp >= ?)
        )
      LIMIT 1
    `).get(gid, uid, thirtyDaysAgoMs, thirtyDaysAgoSec);
    if (caseRow) return true;
  } catch (_) {}

  return false;
}

/**
 * Checks if a member has been previously banned and unbanned in the server.
 * @param {import('better-sqlite3').Database} sdb
 * @param {string} guildId
 * @param {string} userId
 * @param {any} member
 * @returns {boolean}
 */
function checkPreviouslyBannedAndUnbanned(sdb, guildId, userId, member) {
  const gid = String(guildId);
  const uid = String(userId);

  try {
    // 1. Explicit unban case in mod_cases
    const unbanCase = sdb.prepare("SELECT 1 FROM mod_cases WHERE guild_id = ? AND user_id = ? AND LOWER(action) = 'unban' LIMIT 1").get(gid, uid);
    if (unbanCase) return true;

    // 2. Ban/tempban/softban case in mod_cases, but member is currently active in guild
    const banCase = sdb.prepare("SELECT 1 FROM mod_cases WHERE guild_id = ? AND user_id = ? AND LOWER(action) IN ('ban', 'tempban', 'softban') LIMIT 1").get(gid, uid);
    if (banCase && member) {
      return true;
    }
  } catch (_) {}

  return false;
}

/**
 * Resolves account creation timestamp from member/user object or Discord snowflake.
 * @param {string} userId
 * @param {any} member
 * @param {any} guild
 * @returns {number|null}
 */
function resolveAccountCreatedAt(userId, member, guild) {
  if (member?.user?.createdTimestamp) return member.user.createdTimestamp;
  if (member?.createdTimestamp) return member.createdTimestamp;
  if (member?.user?.createdAt instanceof Date) return member.user.createdAt.getTime();

  if (guild?.client?.users?.cache?.has(userId)) {
    const cachedUser = guild.client.users.cache.get(userId);
    if (cachedUser?.createdTimestamp) return cachedUser.createdTimestamp;
  }

  // Discord snowflake timestamp fallback
  const uidStr = String(userId);
  if (/^\d{16,21}$/.test(uidStr)) {
    try {
      const snowflakeTime = Number((BigInt(uidStr) >> 22n) + DISCORD_EPOCH);
      if (snowflakeTime > Number(DISCORD_EPOCH) && snowflakeTime <= Date.now()) {
        return snowflakeTime;
      }
    } catch (_) {}
  }

  return null;
}

/**
 * Calculates dynamic member trust score (0–100) and persists result to SQLite DB.
 *
 * Scoring Rules:
 * - Base score: 50.
 * - +15 if account age > 30 days
 * - +10 if account age > 1 year
 * - +10 if member has been in server > 7 days
 * - +10 if member has sent >= 10 messages (from DB)
 * - -20 if member has 1+ automod strikes in last 7 days
 * - -30 if member has 1+ warnings in last 30 days
 * - -40 if member has been previously banned (and unbanned)
 * - -50 if member has 0 days server tenure (just joined)
 * - Clamped strictly between 0 and 100.
 *
 * @param {any} guild Discord.js Guild object or guildId string
 * @param {any} userId Discord snowflake string or GuildMember
 * @param {object} [options={}]
 * @param {boolean} [options.detailed=false]
 * @returns {Promise<number|object>}
 */
async function calculateTrustScore(guild, userId, options = {}) {
  const now = Date.now();
  let gid = typeof guild === 'object' && guild !== null ? guild.id : String(guild);
  let uid = typeof userId === 'object' && userId !== null ? (userId.id || userId.user?.id) : String(userId);
  let member = null;

  if (typeof userId === 'object' && userId !== null && (userId.guild || userId.joinedTimestamp !== undefined)) {
    member = userId;
  } else if (guild && typeof guild === 'object') {
    if (guild.members?.cache?.has?.(uid)) {
      member = guild.members.cache.get(uid);
    } else if (typeof guild.members?.fetch === 'function') {
      try {
        member = await guild.members.fetch(uid).catch(() => null);
      } catch (_) {}
    }
  }

  const sdb = getServerDb(gid);
  ensureTrustScoreTable(sdb);

  let score = 50; // Base score
  const signalFlags = {
    accountAgeOver30Days: false,
    accountAgeOver1Year: false,
    tenureOver7Days: false,
    zeroDaysTenure: false,
    messagesSentOver10: false,
    automodStrikesLast7Days: false,
    warningsLast30Days: false,
    previouslyBanned: false
  };

  // 1. Account age evaluation
  const accountCreatedAt = resolveAccountCreatedAt(uid, member, guild);
  if (accountCreatedAt) {
    const accountAgeMs = now - accountCreatedAt;
    if (accountAgeMs > 30 * MS_PER_DAY) {
      score += 15;
      signalFlags.accountAgeOver30Days = true;
    }
    if (accountAgeMs > MS_PER_YEAR) {
      score += 10;
      signalFlags.accountAgeOver1Year = true;
    }
  }

  // 2. Server tenure evaluation
  const joinedAt = member?.joinedTimestamp || (member?.joinedAt instanceof Date ? member.joinedAt.getTime() : null);
  if (joinedAt) {
    const tenureMs = now - joinedAt;
    const tenureDays = tenureMs / MS_PER_DAY;
    if (tenureDays < 1) {
      // 0 days server tenure (just joined within 24h)
      score -= 50;
      signalFlags.zeroDaysTenure = true;
    } else if (tenureDays > 7) {
      score += 10;
      signalFlags.tenureOver7Days = true;
    }
  } else if (!member) {
    // Not a guild member / just arrived or not joined: 0 days tenure
    score -= 50;
    signalFlags.zeroDaysTenure = true;
  }

  // 3. Message count evaluation (from DB)
  const messageCount = getUserMessageCount(sdb, gid, uid);
  if (messageCount >= 10) {
    score += 10;
    signalFlags.messagesSentOver10 = true;
  }

  // 4. Automod strikes evaluation (last 7 days)
  if (checkAutomodStrikesLast7Days(sdb, gid, uid, now)) {
    score -= 20;
    signalFlags.automodStrikesLast7Days = true;
  }

  // 5. Warnings evaluation (last 30 days)
  if (checkWarningsLast30Days(sdb, gid, uid, now)) {
    score -= 30;
    signalFlags.warningsLast30Days = true;
  }

  // 6. Previously banned and unbanned evaluation
  if (checkPreviouslyBannedAndUnbanned(sdb, gid, uid, member)) {
    score -= 40;
    signalFlags.previouslyBanned = true;
  }

  // Clamp strictly between 0 and 100
  score = Math.max(0, Math.min(100, Math.round(score)));

  // Persist to member_trust_scores
  const calculatedAtSec = Math.floor(now / 1000);
  const flagsJson = JSON.stringify(signalFlags);
  try {
    sdb.prepare(`
      INSERT OR REPLACE INTO member_trust_scores (guild_id, user_id, score, calculated_at, signal_flags)
      VALUES (?, ?, ?, ?, ?)
    `).run(gid, uid, score, calculatedAtSec, flagsJson);
  } catch (_) {}

  if (options && options.detailed) {
    return {
      score,
      calculatedAt: calculatedAtSec,
      signalFlags,
      flags: signalFlags
    };
  }

  return score;
}

/**
 * Retrieves cached trust score from member_trust_scores table.
 * Defaults to base score (50) if not yet calculated.
 *
 * @param {string} guildId
 * @param {string} userId
 * @returns {number}
 */
function getTrustScore(guildId, userId) {
  const gid = String(guildId);
  const uid = String(userId);
  try {
    const sdb = getServerDb(gid);
    ensureTrustScoreTable(sdb);
    const row = sdb.prepare('SELECT score FROM member_trust_scores WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (row && typeof row.score === 'number') {
      return row.score;
    }
  } catch (_) {}
  return 50; // Base score default
}

/**
 * Retrieves full persisted trust record including calculated_at and signal_flags.
 * @param {string} guildId
 * @param {string} userId
 * @returns {{ guildId: string, userId: string, score: number, calculatedAt: number, signalFlags: object }|null}
 */
function getTrustScoreRecord(guildId, userId) {
  const gid = String(guildId);
  const uid = String(userId);
  try {
    const sdb = getServerDb(gid);
    ensureTrustScoreTable(sdb);
    const row = sdb.prepare('SELECT guild_id, user_id, score, calculated_at, signal_flags FROM member_trust_scores WHERE guild_id = ? AND user_id = ?').get(gid, uid);
    if (row) {
      let flags = {};
      try { flags = JSON.parse(row.signal_flags || '{}'); } catch (_) {}
      return {
        guildId: row.guild_id,
        userId: row.user_id,
        score: row.score,
        calculatedAt: row.calculated_at,
        signalFlags: flags
      };
    }
  } catch (_) {}
  return null;
}

/**
 * Calculates trust score and returns full detailed diagnostic breakdown.
 * @param {any} guild
 * @param {any} userId
 * @returns {Promise<{ score: number, calculatedAt: number, signalFlags: object, flags: object }>}
 */
async function calculateTrustScoreDetails(guild, userId) {
  return calculateTrustScore(guild, userId, { detailed: true });
}

/**
 * Formats trust score with custom Tungsten emojis. Zero raw unicode emojis.
 * @param {number} score
 * @returns {string}
 */
function formatTrustBadge(score) {
  const numeric = Math.max(0, Math.min(100, Math.round(Number(score) || 0)));
  if (numeric >= 80) {
    return `<a:tungsten_shield:1567242104923627574> \`Trusted (${numeric}/100)\``;
  }
  if (numeric >= 50) {
    return `<a:tungsten_shield:1567242104923627574> \`Moderate (${numeric}/100)\``;
  }
  return `<a:tungsten_warn:1567246685082746940> \`High Risk (${numeric}/100)\``;
}

module.exports = {
  calculateTrustScore,
  getTrustScore,
  getTrustScoreRecord,
  calculateTrustScoreDetails,
  ensureTrustScoreTable,
  recordMemberMessage,
  formatTrustBadge
};
