/**
 * Unified SQLite Database Adapter
 * Provides high-performance SQLite WAL access using native node:sqlite with better-sqlite3 compatibility.
 */
const fs = require('fs');
const path = require('path');

const MAX_SAFE_BIGINT = 9007199254740991n;
const MIN_SAFE_BIGINT = -9007199254740991n;

/**
 * Normalizes SQLite values returned when readBigInts is enabled.
 * - Safe integers (within JS Number limits) are converted to Number (e.g. status, amounts, counts, timestamps).
 * - 64-bit snowflakes (exceeding JS Number limits) are safely converted to String (e.g. 1562090786089074789).
 */
function normalizeRow(row) {
  if (!row || typeof row !== 'object') return row;
  for (const k in row) {
    const val = row[k];
    if (typeof val === 'bigint') {
      if (val <= MAX_SAFE_BIGINT && val >= MIN_SAFE_BIGINT) {
        row[k] = Number(val);
      } else {
        row[k] = val.toString();
      }
    }
  }
  return row;
}

function normalizeRows(rows) {
  if (!Array.isArray(rows)) return rows;
  for (let i = 0; i < rows.length; i++) {
    normalizeRow(rows[i]);
  }
  return rows;
}

function normalizeRunResult(res) {
  if (!res) return res;
  return {
    changes: typeof res.changes === 'bigint' ? Number(res.changes) : (res.changes || 0),
    lastInsertRowid: typeof res.lastInsertRowid === 'bigint'
      ? (res.lastInsertRowid <= MAX_SAFE_BIGINT && res.lastInsertRowid >= MIN_SAFE_BIGINT ? Number(res.lastInsertRowid) : res.lastInsertRowid.toString())
      : res.lastInsertRowid
  };
}

let DatabaseDriver;
try {
  // 1. Prefer native zero-dependency node:sqlite (Node 22+)
  const { DatabaseSync } = require('node:sqlite');
  DatabaseDriver = class NodeSqliteDriver {
    constructor(dbPath, options = {}) {
      const dir = path.dirname(dbPath);
      if (dbPath !== ':memory:' && !fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      this._db = new DatabaseSync(dbPath, options);
      this._stmtCache = new Map();
      try {
        this._db.exec('PRAGMA journal_mode = WAL;');
        this._db.exec('PRAGMA synchronous = NORMAL;');
        this._db.exec('PRAGMA temp_store = MEMORY;');
        this._db.exec('PRAGMA cache_size = -32000;');
        this._db.exec('PRAGMA mmap_size = 268435456;');
        this._db.exec('PRAGMA wal_autocheckpoint = 1000;');
        this._db.exec('PRAGMA threads = 4;');
        this._db.exec('PRAGMA busy_timeout = 30000;');
      } catch (e) {
        // pragma setup
      }
    }

    prepare(sql) {
      let cached = this._stmtCache.get(sql);
      if (cached) {
        // LRU touch: delete and re-insert moves to end
        this._stmtCache.delete(sql);
        this._stmtCache.set(sql, cached);
        return cached;
      }

      if (this._stmtCache.size >= 500) {
        const oldestKey = this._stmtCache.keys().next().value;
        this._stmtCache.delete(oldestKey);
      }

      const stmt = this._db.prepare(sql);
      try {
        stmt.setReadBigInts(true);
      } catch (e) {}

      cached = {
        run: (...params) => {
          const flatParams = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
          return normalizeRunResult(stmt.run(...flatParams));
        },
        get: (...params) => {
          const flatParams = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
          return normalizeRow(stmt.get(...flatParams));
        },
        all: (...params) => {
          const flatParams = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
          return normalizeRows(stmt.all(...flatParams));
        },
        iterate: (...params) => {
          const flatParams = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
          const iter = stmt.iterate(...flatParams);
          return (function* () {
            for (const row of iter) {
              yield normalizeRow(row);
            }
          })();
        }
      };
      this._stmtCache.set(sql, cached);
      return cached;
    }

    exec(sql) {
      return this._db.exec(sql);
    }

    transaction(fn) {
      return (...args) => {
        this._db.exec('BEGIN IMMEDIATE');
        try {
          const r = fn(...args);
          this._db.exec('COMMIT');
          return r;
        } catch (e) {
          try {
            this._db.exec('ROLLBACK');
          } catch (_) {}
          throw e;
        }
      };
    }

    checkpoint(mode = 'PASSIVE') {
      try {
        return this._db.exec(`PRAGMA wal_checkpoint(${mode});`);
      } catch (e) {
        return null;
      }
    }

    close() {
      try {
        this._db.close();
      } catch (e) {}
    }
  };
} catch (e) {
  // 2. Fallback to better-sqlite3 if node:sqlite is unavailable
  try {
    const BetterSqlite = require('better-sqlite3');
    DatabaseDriver = class BetterSqliteDriver {
      constructor(dbPath, options = {}) {
        this._db = new BetterSqlite(dbPath, options);
        try {
          this._db.defaultSafeIntegers(true);
        } catch (e) {}
        this._db.pragma('journal_mode = WAL');
        this._db.pragma('synchronous = NORMAL');
        this._db.pragma('temp_store = MEMORY');
        this._db.pragma('cache_size = -32000');
        this._db.pragma('mmap_size = 268435456');
        this._db.pragma('wal_autocheckpoint = 1000');
        this._db.pragma('threads = 4');
        this._db.pragma('busy_timeout = 30000');
      }
      prepare(sql) {
        const stmt = this._db.prepare(sql);
        try {
          stmt.safeIntegers(true);
        } catch (e) {}
        return {
          run: (...params) => normalizeRunResult(stmt.run(...params)),
          get: (...params) => normalizeRow(stmt.get(...params)),
          all: (...params) => normalizeRows(stmt.all(...params)),
          iterate: (...params) => {
            const iter = stmt.iterate(...params);
            return (function* () {
              for (const row of iter) {
                yield normalizeRow(row);
              }
            })();
          }
        };
      }
      exec(sql) {
        return this._db.exec(sql);
      }
      transaction(fn) {
        if (typeof this._db.transaction === 'function') {
          return this._db.transaction(fn);
        }
        return (...args) => {
          this._db.exec('BEGIN IMMEDIATE');
          try {
            const r = fn(...args);
            this._db.exec('COMMIT');
            return r;
          } catch (e) {
            try {
              this._db.exec('ROLLBACK');
            } catch (_) {}
            throw e;
          }
        };
      }
      checkpoint(mode = 'PASSIVE') {
        try {
          return this._db.pragma(`wal_checkpoint(${mode})`);
        } catch (e) {
          return null;
        }
      }
      close() {
        return this._db.close();
      }
    };
  } catch (err) {
    throw new Error('No compatible SQLite driver found. Please ensure Node.js >= 22 or install better-sqlite3.');
  }
}

function checkpoint(db, mode = 'PASSIVE') {
  if (!db) return null;
  if (typeof db.checkpoint === 'function') {
    return db.checkpoint(mode);
  }
  try {
    return db.exec ? db.exec(`PRAGMA wal_checkpoint(${mode});`) : null;
  } catch (e) {
    return null;
  }
}

function openDatabase(dbPath, options = {}) {
  return new DatabaseDriver(dbPath, options);
}

module.exports = {
  openDatabase,
  DatabaseDriver,
  checkpoint
};
