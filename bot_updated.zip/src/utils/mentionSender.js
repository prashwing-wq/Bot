/**
 * Tungsten Mention Notification Dispatcher
 * Delivers DM alerts to tagged users and handles bot tag notifications with 5-minute anti-spam protection.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { isMentionAllowed, isMentionDebounced, recordMentionDebounce } = require('./pingsDb');
const { getGuildAccent } = require('./serverDb');
const { getSetting } = require('../settings/registry');
const { getConfig, formatClockTime, isOwner } = require('./tools');

/**
 * Sanitizes message content for stylized quote blocks in DMs:
 * - Strips raw bot mention tags (<@bot_id>)
 * - Resolves raw channel mentions (<#channel_id>) to #channel-name so they never render as #deleted-channel in DMs
 * - Replaces backticks to protect markdown quote block syntax
 * - Clamps snippet length and formats as a stylized blockquote
 */
function sanitizeSnippet(message, client, maxLength = 450) {
  let snippet = message.cleanContent || message.content || '*[Attachment or Media]*';

  // Strip raw bot mention tags: <@botId> or <@!botId>
  if (client?.user?.id) {
    snippet = snippet.replace(new RegExp(`<@!?${client.user.id}>`, 'g'), '').trim();
  }

  // Resolve any raw channel mentions so they don't render as #deleted-channel in DMs
  if (message.guild?.channels?.cache) {
    snippet = snippet.replace(/<#(\d+)>/g, (match, cid) => {
      const ch = message.guild.channels.cache.get(cid);
      return ch ? `#${ch.name}` : '#channel';
    });
  }

  // Replace backticks to prevent breaking markdown quote blocks
  snippet = snippet.replace(/`/g, "'").trim();

  if (!snippet) {
    snippet = '*[Bot Tag]*';
  } else if (snippet.length > maxLength) {
    snippet = snippet.slice(0, maxLength) + '...';
  }

  return snippet.split('\n').map(l => `> ${l}`).join('\n') || '> *[No message text]*';
}

/**
 * Handles bot mention DMs:
 * When a user tags the bot, notifies the user in their DMs with server prefix & help info,
 * with strict 5-minute per-user per-server spam debounce.
 */
async function handleBotMention(message, client) {
  if (!message || !message.guild || !message.author || message.author.bot) return;

  const guild = message.guild;
  const author = message.author;
  const channel = message.channel;
  const channelName = channel?.name || 'channel';
  const guildName = guild?.name || 'Server';

  // 1. Check 5-minute per-user per-server debounce for bot mentions (bypass for bot owners and server owners during testing)
  const botTagKey = `bot_tag:${guild.id}`;
  if (!isOwner(author.id) && author.id !== guild.ownerId && isMentionDebounced(author.id, botTagKey)) {
    return; // Ignore spam in DMs if tagged within last 5 minutes in this server
  }

  // 2. Resolve server prefix and accent
  const guildConfig = getConfig(guild.id);
  const prefix = guildConfig?.prefix || client?.config?.DEFAULT_PREFIX || '!';
  const accent = getGuildAccent(guild.id);

  const quoteSnippet = sanitizeSnippet(message, client, 350);

  // Format robust text clock time with AM/PM (e.g. "9:25 AM")
  const timeFormatted = formatClockTime(message.createdTimestamp || message.createdAt);

  const embed = new EmbedBuilder()
    .setColor(accent)
    .setTitle(`Tagged in ${guildName}`)
    .setDescription(
      `You tagged Tungsten in **${guildName}** (#${channelName}).\n\n` +
      `• **Prefix:** \`${prefix}\`\n` +
      `• **Commands:** \`${prefix}help\`\n` +
      `• **Antinuke:** \`${prefix}antinuke\`\n` +
      `• **Automod:** \`${prefix}automod\`\n\n` +
      `-# Anti-spam active: 5-minute cooldown between tag notifications in this server.`
    )
    .setAuthor({
      name: client.user?.username || 'Tungsten',
      iconURL: client.user?.displayAvatarURL ? client.user.displayAvatarURL() : undefined
    })
    .addFields(
      { name: 'Channel & Server', value: `#${channelName} • **${guildName}**`, inline: false },
      { name: 'Time', value: timeFormatted, inline: false },
      { name: 'Your Message', value: quoteSnippet, inline: false }
    )
    .setFooter({
      text: `Server: ${guildName}`,
      iconURL: client.user?.displayAvatarURL ? client.user.displayAvatarURL() : undefined
    })
    .setTimestamp(message.createdAt || new Date());

  if (guild.iconURL && guild.iconURL()) {
    embed.setThumbnail(guild.iconURL());
  }

  const jumpLabel = `Jump to #${channelName}`.slice(0, 80);
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel(jumpLabel)
      .setStyle(ButtonStyle.Link)
      .setURL(message.url)
  );

  try {
    await author.send({ embeds: [embed], components: [row] });
    recordMentionDebounce(author.id, botTagKey);
  } catch (err) {
    try {
      await author.send({ embeds: [embed] });
      recordMentionDebounce(author.id, botTagKey);
    } catch (innerErr) {
      // User has DMs closed
    }
  }
}

/**
 * Handles user and bot mention alerts:
 * When a user is tagged, notifies them in DMs with 5-minute per-user per-server spam debounce.
 */
async function handleMessageMentions(message, client) {
  if (!message || !message.guild || !message.author || message.author.bot) return;
  if (!message.mentions?.users?.size) return;

  const guild = message.guild;
  const author = message.author;
  const channel = message.channel;
  const channelName = channel?.name || 'channel';
  const guildName = guild?.name || 'Server';

  // 1. If bot itself is tagged explicitly, deliver Bot Tag DM
  const hasBotTag = client.user && message.mentions.users.has(client.user.id);
  const isContentBotPing = !message.reference || (message.content && message.content.includes(client.user.id));
  if (hasBotTag && isContentBotPing) {
    await handleBotMention(message, client).catch(() => null);
  }

  // 2. Check if mention alerts are explicitly disabled for this guild
  const isEnabled = getSetting(guild.id, 'utility.mention_alerts_enabled');
  if (isEnabled === false) return;

  const accent = getGuildAccent(guild.id);

  // 3. Process each mentioned user
  for (const [targetId, targetUser] of message.mentions.users.entries()) {
    // Skip self-mentions or bot targets
    if (targetId === author.id || targetUser.bot) continue;

    // Ensure target user has permission to view the channel (security safeguard)
    const member = message.guild.members.cache.get(targetId);
    if (member && channel.permissionsFor) {
      const perms = channel.permissionsFor(member);
      if (perms && !perms.has('ViewChannel')) {
        continue;
      }
    }

    // Check mention preferences & 5-minute per-server debounce
    if (!isMentionAllowed(targetId, author.id, guild.id)) {
      continue; // Ignored due to 5-minute cooldown, user settings, or blocklist
    }

    // Construct sanitized quote block
    const quoteSnippet = sanitizeSnippet(message, client, 450);

    // Format robust text clock time with AM/PM (e.g. "9:25 AM")
    const timeFormatted = formatClockTime(message.createdTimestamp || message.createdAt);

    const embed = new EmbedBuilder()
      .setColor(accent)
      .setTitle('Mention Alert')
      .setDescription(
        `You were mentioned by **${author.displayName || author.username}** in **${guildName}** (#${channelName}).\n\n` +
        `-# Anti-spam active: 5-minute cooldown between mention alerts in this server.`
      )
      .setAuthor({
        name: `${author.displayName || author.username} in #${channelName}`,
        iconURL: author.displayAvatarURL ? author.displayAvatarURL() : undefined
      })
      .addFields(
        { name: 'Channel & Server', value: `#${channelName} • **${guildName}**`, inline: false },
        { name: 'Mentioned By', value: `**${author.displayName || author.username}** (<@${author.id}>)`, inline: false },
        { name: 'Time', value: timeFormatted, inline: false },
        { name: 'Message', value: quoteSnippet, inline: false }
      )
      .setFooter({
        text: `Server: ${guildName}`,
        iconURL: client.user?.displayAvatarURL ? client.user.displayAvatarURL() : undefined
      })
      .setTimestamp(message.createdAt || new Date());

    if (guild.iconURL && guild.iconURL()) {
      embed.setThumbnail(guild.iconURL());
    }

    const jumpLabel = `Jump to #${channelName}`.slice(0, 80);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel(jumpLabel)
        .setStyle(ButtonStyle.Link)
        .setURL(message.url),
      new ButtonBuilder()
        .setCustomId(`pings:disable:${targetId}`)
        .setLabel('Disable Alerts')
        .setStyle(ButtonStyle.Secondary)
    );

    // Deliver DM with resilient fallback
    try {
      await targetUser.send({ embeds: [embed], components: [row] });
    } catch (err) {
      try {
        await targetUser.send({ embeds: [embed] });
      } catch (innerErr) {
        // Target user has DMs closed
      }
    }
  }
}

module.exports = {
  handleBotMention,
  handleMessageMentions
};
