/**
 * Tungsten Animated Emoji Suite v2 — 489 Bespoke Transparent Animated Icons
 * Integrated cleanly across all dedicated emoji servers with zero duplicates.
 */
const path = require('node:path');
const fs = require('node:fs');

const ASSETS_DIR = path.resolve(__dirname, '../../assets/emojis');

// Built-in Registry of all Animated Emojis + Compatibility Aliases
const BUILTIN_PACK = [
  {
    "name": "tungsten_alarm",
    "label": "Alarm",
    "animated": true,
    "discordTag": "<a:tungsten_alarm:1567229471474585682>",
    "id": "1567229471474585682",
    "file": "tungsten_alarm.gif"
  },
  {
    "name": "tungsten_an_arm",
    "label": "An Arm",
    "animated": true,
    "discordTag": "<a:tungsten_an_arm:1567232430908244079>",
    "id": "1567232430908244079",
    "file": "tungsten_an_arm.gif"
  },
  {
    "name": "tungsten_an_backup_roles",
    "label": "An Backup Roles",
    "animated": true,
    "discordTag": "<a:tungsten_an_backup_roles:1567232464970322071>",
    "id": "1567232464970322071",
    "file": "tungsten_an_backup_roles.gif"
  },
  {
    "name": "tungsten_an_ban",
    "label": "An Ban",
    "animated": true,
    "discordTag": "<a:tungsten_an_ban:1567232483743895684>",
    "id": "1567232483743895684",
    "file": "tungsten_an_ban.gif"
  },
  {
    "name": "tungsten_an_bot",
    "label": "An Bot",
    "animated": true,
    "discordTag": "<a:tungsten_an_bot:1567232510893490216>",
    "id": "1567232510893490216",
    "file": "tungsten_an_bot.gif"
  },
  {
    "name": "tungsten_an_caps",
    "label": "An Caps",
    "animated": true,
    "discordTag": "<a:tungsten_an_caps:1567232530988662824>",
    "id": "1567232530988662824",
    "file": "tungsten_an_caps.gif"
  },
  {
    "name": "tungsten_an_channel_create",
    "label": "An Channel Create",
    "animated": true,
    "discordTag": "<a:tungsten_an_channel_create:1567232575855005736>",
    "id": "1567232575855005736",
    "file": "tungsten_an_channel_create.gif"
  },
  {
    "name": "tungsten_an_channel_delete",
    "label": "An Channel Delete",
    "animated": true,
    "discordTag": "<a:tungsten_an_channel_delete:1567232594930696262>",
    "id": "1567232594930696262",
    "file": "tungsten_an_channel_delete.gif"
  },
  {
    "name": "tungsten_an_disarm",
    "label": "An Disarm",
    "animated": true,
    "discordTag": "<a:tungsten_an_disarm:1567232635237834762>",
    "id": "1567232635237834762",
    "file": "tungsten_an_disarm.gif"
  },
  {
    "name": "tungsten_an_everyone",
    "label": "An Everyone",
    "animated": true,
    "discordTag": "<a:tungsten_an_everyone:1567232659715793068>",
    "id": "1567232659715793068",
    "file": "tungsten_an_everyone.gif"
  },
  {
    "name": "tungsten_an_ghostping",
    "label": "An Ghostping",
    "animated": true,
    "discordTag": "<a:tungsten_an_ghostping:1567232680020672664>",
    "id": "1567232680020672664",
    "file": "tungsten_an_ghostping.gif"
  },
  {
    "name": "tungsten_an_integrity",
    "label": "An Integrity",
    "animated": true,
    "discordTag": "<a:tungsten_an_integrity:1567232702690623490>",
    "id": "1567232702690623490",
    "file": "tungsten_an_integrity.gif"
  },
  {
    "name": "tungsten_an_invite",
    "label": "An Invite",
    "animated": true,
    "discordTag": "<a:tungsten_an_invite:1567232720126607421>",
    "id": "1567232720126607421",
    "file": "tungsten_an_invite.gif"
  },
  {
    "name": "tungsten_an_join_flood",
    "label": "An Join Flood",
    "animated": true,
    "discordTag": "<a:tungsten_an_join_flood:1567232740041031831>",
    "id": "1567232740041031831",
    "file": "tungsten_an_join_flood.gif"
  },
  {
    "name": "tungsten_an_kick",
    "label": "An Kick",
    "animated": true,
    "discordTag": "<a:tungsten_an_kick:1567232757330083940>",
    "id": "1567232757330083940",
    "file": "tungsten_an_kick.gif"
  },
  {
    "name": "tungsten_an_limits",
    "label": "An Limits",
    "animated": true,
    "discordTag": "<a:tungsten_an_limits:1567232774367092797>",
    "id": "1567232774367092797",
    "file": "tungsten_an_limits.gif"
  },
  {
    "name": "tungsten_an_link",
    "label": "An Link",
    "animated": true,
    "discordTag": "<a:tungsten_an_link:1567232798299922585>",
    "id": "1567232798299922585",
    "file": "tungsten_an_link.gif"
  },
  {
    "name": "tungsten_an_lockdown",
    "label": "An Lockdown",
    "animated": true,
    "discordTag": "<a:tungsten_an_lockdown:1567232816406732850>",
    "id": "1567232816406732850",
    "file": "tungsten_an_lockdown.gif"
  },
  {
    "name": "tungsten_an_lockdown_lift",
    "label": "An Lockdown Lift",
    "animated": true,
    "discordTag": "<a:tungsten_an_lockdown_lift:1567232833670488064>",
    "id": "1567232833670488064",
    "file": "tungsten_an_lockdown_lift.gif"
  },
  {
    "name": "tungsten_an_logs",
    "label": "An Logs",
    "animated": true,
    "discordTag": "<a:tungsten_an_logs:1567232852200923149>",
    "id": "1567232852200923149",
    "file": "tungsten_an_logs.gif"
  },
  {
    "name": "tungsten_an_mention",
    "label": "An Mention",
    "animated": true,
    "discordTag": "<a:tungsten_an_mention:1567232877584715970>",
    "id": "1567232877584715970",
    "file": "tungsten_an_mention.gif"
  },
  {
    "name": "tungsten_an_nsfw",
    "label": "An Nsfw",
    "animated": true,
    "discordTag": "<a:tungsten_an_nsfw:1567232895830196495>",
    "id": "1567232895830196495",
    "file": "tungsten_an_nsfw.gif"
  },
  {
    "name": "tungsten_an_punish",
    "label": "An Punish",
    "animated": true,
    "discordTag": "<a:tungsten_an_punish:1567232919984939141>",
    "id": "1567232919984939141",
    "file": "tungsten_an_punish.gif"
  },
  {
    "name": "tungsten_an_raid",
    "label": "An Raid",
    "animated": true,
    "discordTag": "<a:tungsten_an_raid:1567232943435292972>",
    "id": "1567232943435292972",
    "file": "tungsten_an_raid.gif"
  },
  {
    "name": "tungsten_an_role_create",
    "label": "An Role Create",
    "animated": true,
    "discordTag": "<a:tungsten_an_role_create:1567232961181384745>",
    "id": "1567232961181384745",
    "file": "tungsten_an_role_create.gif"
  },
  {
    "name": "tungsten_an_role_delete",
    "label": "An Role Delete",
    "animated": true,
    "discordTag": "<a:tungsten_an_role_delete:1567232979569483776>",
    "id": "1567232979569483776",
    "file": "tungsten_an_role_delete.gif"
  },
  {
    "name": "tungsten_an_spam",
    "label": "An Spam",
    "animated": true,
    "discordTag": "<a:tungsten_an_spam:1567233007415197823>",
    "id": "1567233007415197823",
    "file": "tungsten_an_spam.gif"
  },
  {
    "name": "tungsten_an_standard",
    "label": "An Standard",
    "animated": true,
    "discordTag": "<a:tungsten_an_standard:1567233029233967106>",
    "id": "1567233029233967106",
    "file": "tungsten_an_standard.gif"
  },
  {
    "name": "tungsten_an_strict",
    "label": "An Strict",
    "animated": true,
    "discordTag": "<a:tungsten_an_strict:1567233050260021398>",
    "id": "1567233050260021398",
    "file": "tungsten_an_strict.gif"
  },
  {
    "name": "tungsten_an_ultra",
    "label": "An Ultra",
    "animated": true,
    "discordTag": "<a:tungsten_an_ultra:1567233073005731872>",
    "id": "1567233073005731872",
    "file": "tungsten_an_ultra.gif"
  },
  {
    "name": "tungsten_an_webhook",
    "label": "An Webhook",
    "animated": true,
    "discordTag": "<a:tungsten_an_webhook:1567233087388262422>",
    "id": "1567233087388262422",
    "file": "tungsten_an_webhook.gif"
  },
  {
    "name": "tungsten_anger",
    "label": "Anger",
    "animated": true,
    "discordTag": "<a:tungsten_anger:1567233100776218734>",
    "id": "1567233100776218734",
    "file": "tungsten_anger.gif"
  },
  {
    "name": "tungsten_arrow_left",
    "label": "Arrow Left",
    "animated": true,
    "discordTag": "<a:tungsten_arrow_left:1567233111601844267>",
    "id": "1567233111601844267",
    "file": "tungsten_arrow_left.gif"
  },
  {
    "name": "tungsten_arrow_right",
    "label": "Arrow Right",
    "animated": true,
    "discordTag": "<a:tungsten_arrow_right:1567233126143361135>",
    "id": "1567233126143361135",
    "file": "tungsten_arrow_right.gif"
  },
  {
    "name": "tungsten_arrow_small",
    "label": "Arrow Small",
    "animated": true,
    "discordTag": "<a:tungsten_arrow_small:1567233140357988574>",
    "id": "1567233140357988574",
    "file": "tungsten_arrow_small.gif"
  },
  {
    "name": "tungsten_atm",
    "label": "Atm",
    "animated": true,
    "discordTag": "<a:tungsten_atm:1567233228350300292>",
    "id": "1567233228350300292",
    "file": "tungsten_atm.gif"
  },
  {
    "name": "tungsten_bank",
    "label": "Bank",
    "animated": true,
    "discordTag": "<a:tungsten_bank:1567233290656677924>",
    "id": "1567233290656677924",
    "file": "tungsten_bank.gif"
  },
  {
    "name": "tungsten_bell",
    "label": "Bell",
    "animated": true,
    "discordTag": "<a:tungsten_bell:1567233316925612173>",
    "id": "1567233316925612173",
    "file": "tungsten_bell.gif"
  },
  {
    "name": "tungsten_bell_slash",
    "label": "Bell Slash",
    "animated": true,
    "discordTag": "<a:tungsten_bell_slash:1567233400996106260>",
    "id": "1567233400996106260",
    "file": "tungsten_bell_slash.gif"
  },
  {
    "name": "tungsten_bolt",
    "label": "Bolt",
    "animated": true,
    "discordTag": "<a:tungsten_bolt:1567233430570405968>",
    "id": "1567233430570405968",
    "file": "tungsten_bolt.gif"
  },
  {
    "name": "tungsten_bomb",
    "label": "Bomb",
    "animated": true,
    "discordTag": "<a:tungsten_bomb:1567233448945385502>",
    "id": "1567233448945385502",
    "file": "tungsten_bomb.gif"
  },
  {
    "name": "tungsten_book",
    "label": "Book",
    "animated": true,
    "discordTag": "<a:tungsten_book:1567233482499948606>",
    "id": "1567233482499948606",
    "file": "tungsten_book.gif"
  },
  {
    "name": "tungsten_boot",
    "label": "Boot",
    "animated": true,
    "discordTag": "<a:tungsten_boot:1567233502418575501>",
    "id": "1567233502418575501",
    "file": "tungsten_boot.gif"
  },
  {
    "name": "tungsten_bot",
    "label": "Bot",
    "animated": true,
    "discordTag": "<a:tungsten_bot:1567233522635247781>",
    "id": "1567233522635247781",
    "file": "tungsten_bot.gif"
  },
  {
    "name": "tungsten_brain",
    "label": "Brain",
    "animated": true,
    "discordTag": "<a:tungsten_brain:1567233547272454144>",
    "id": "1567233547272454144",
    "file": "tungsten_brain.gif"
  },
  {
    "name": "tungsten_briefcase",
    "label": "Briefcase",
    "animated": true,
    "discordTag": "<a:tungsten_briefcase:1567233568596295821>",
    "id": "1567233568596295821",
    "file": "tungsten_briefcase.gif"
  },
  {
    "name": "tungsten_bullet",
    "label": "Bullet",
    "animated": true,
    "discordTag": "<a:tungsten_bullet:1567233589949497434>",
    "id": "1567233589949497434",
    "file": "tungsten_bullet.gif"
  },
  {
    "name": "tungsten_cabinet",
    "label": "Cabinet",
    "animated": true,
    "discordTag": "<a:tungsten_cabinet:1567233617489297548>",
    "id": "1567233617489297548",
    "file": "tungsten_cabinet.gif"
  },
  {
    "name": "tungsten_calendar",
    "label": "Calendar",
    "animated": true,
    "discordTag": "<a:tungsten_calendar:1567233642554458154>",
    "id": "1567233642554458154",
    "file": "tungsten_calendar.gif"
  },
  {
    "name": "tungsten_cash",
    "label": "Cash",
    "animated": true,
    "discordTag": "<a:tungsten_cash:1567233665082200267>",
    "id": "1567233665082200267",
    "file": "tungsten_cash.gif"
  },
  {
    "name": "tungsten_castle",
    "label": "Castle",
    "animated": true,
    "discordTag": "<a:tungsten_castle:1567233687332982844>",
    "id": "1567233687332982844",
    "file": "tungsten_castle.gif"
  },
  {
    "name": "tungsten_cat_automation",
    "label": "Cat Automation",
    "animated": true,
    "discordTag": "<a:tungsten_cat_automation:1567233718861435011>",
    "id": "1567233718861435011",
    "file": "tungsten_cat_automation.gif"
  },
  {
    "name": "tungsten_cat_backups",
    "label": "Cat Backups",
    "animated": true,
    "discordTag": "<a:tungsten_cat_backups:1567233747567251666>",
    "id": "1567233747567251666",
    "file": "tungsten_cat_backups.gif"
  },
  {
    "name": "tungsten_cat_channels",
    "label": "Cat Channels",
    "animated": true,
    "discordTag": "<a:tungsten_cat_channels:1567233777024110652>",
    "id": "1567233777024110652",
    "file": "tungsten_cat_channels.gif"
  },
  {
    "name": "tungsten_cat_economy",
    "label": "Cat Economy",
    "animated": true,
    "discordTag": "<a:tungsten_cat_economy:1567233807822618735>",
    "id": "1567233807822618735",
    "file": "tungsten_cat_economy.gif"
  },
  {
    "name": "tungsten_cat_fun",
    "label": "Cat Fun",
    "animated": true,
    "discordTag": "<a:tungsten_cat_fun:1567233835035402350>",
    "id": "1567233835035402350",
    "file": "tungsten_cat_fun.gif"
  },
  {
    "name": "tungsten_cat_giveaways",
    "label": "Cat Giveaways",
    "animated": true,
    "discordTag": "<a:tungsten_cat_giveaways:1567233867637588015>",
    "id": "1567233867637588015",
    "file": "tungsten_cat_giveaways.gif"
  },
  {
    "name": "tungsten_cat_leaderboards",
    "label": "Cat Leaderboards",
    "animated": true,
    "discordTag": "<a:tungsten_cat_leaderboards:1567233900366008430>",
    "id": "1567233900366008430",
    "file": "tungsten_cat_leaderboards.gif"
  },
  {
    "name": "tungsten_cat_logging",
    "label": "Cat Logging",
    "animated": true,
    "discordTag": "<a:tungsten_cat_logging:1567233934490738860>",
    "id": "1567233934490738860",
    "file": "tungsten_cat_logging.gif"
  },
  {
    "name": "tungsten_cat_media",
    "label": "Cat Media",
    "animated": true,
    "discordTag": "<a:tungsten_cat_media:1567233959207764080>",
    "id": "1567233959207764080",
    "file": "tungsten_cat_media.gif"
  },
  {
    "name": "tungsten_cat_moderation",
    "label": "Cat Moderation",
    "animated": true,
    "discordTag": "<a:tungsten_cat_moderation:1567233980523225148>",
    "id": "1567233980523225148",
    "file": "tungsten_cat_moderation.gif"
  },
  {
    "name": "tungsten_cat_owner",
    "label": "Cat Owner",
    "animated": true,
    "discordTag": "<a:tungsten_cat_owner:1567234022927638649>",
    "id": "1567234022927638649",
    "file": "tungsten_cat_owner.gif"
  },
  {
    "name": "tungsten_cat_premium",
    "label": "Cat Premium",
    "animated": true,
    "discordTag": "<a:tungsten_cat_premium:1567234059510223029>",
    "id": "1567234059510223029",
    "file": "tungsten_cat_premium.gif"
  },
  {
    "name": "tungsten_cat_roles",
    "label": "Cat Roles",
    "animated": true,
    "discordTag": "<a:tungsten_cat_roles:1567234100975378512>",
    "id": "1567234100975378512",
    "file": "tungsten_cat_roles.gif"
  },
  {
    "name": "tungsten_cat_security",
    "label": "Cat Security",
    "animated": true,
    "discordTag": "<a:tungsten_cat_security:1567234156075683940>",
    "id": "1567234156075683940",
    "file": "tungsten_cat_security.gif"
  },
  {
    "name": "tungsten_cat_tickets",
    "label": "Cat Tickets",
    "animated": true,
    "discordTag": "<a:tungsten_cat_tickets:1567234238737031290>",
    "id": "1567234238737031290",
    "file": "tungsten_cat_tickets.gif"
  },
  {
    "name": "tungsten_cat_utility",
    "label": "Cat Utility",
    "animated": true,
    "discordTag": "<a:tungsten_cat_utility:1567234274183217304>",
    "id": "1567234274183217304",
    "file": "tungsten_cat_utility.gif"
  },
  {
    "name": "tungsten_cat_welcomer",
    "label": "Cat Welcomer",
    "animated": true,
    "discordTag": "<a:tungsten_cat_welcomer:1567234301869822153>",
    "id": "1567234301869822153",
    "file": "tungsten_cat_welcomer.gif"
  },
  {
    "name": "tungsten_cat_whitelist",
    "label": "Cat Whitelist",
    "animated": true,
    "discordTag": "<a:tungsten_cat_whitelist:1567234327970848848>",
    "id": "1567234327970848848",
    "file": "tungsten_cat_whitelist.gif"
  },
  {
    "name": "tungsten_chart",
    "label": "Chart",
    "animated": true,
    "discordTag": "<a:tungsten_chart:1567234342701367357>",
    "id": "1567234342701367357",
    "file": "tungsten_chart.gif"
  },
  {
    "name": "tungsten_chat",
    "label": "Chat",
    "animated": true,
    "discordTag": "<a:tungsten_chat:1567234399450177665>",
    "id": "1567234399450177665",
    "file": "tungsten_chat.gif"
  },
  {
    "name": "tungsten_cherry",
    "label": "Cherry",
    "animated": true,
    "discordTag": "<a:tungsten_cherry:1567234489682362439>",
    "id": "1567234489682362439",
    "file": "tungsten_cherry.gif"
  },
  {
    "name": "tungsten_circle_green",
    "label": "Circle Green",
    "animated": true,
    "discordTag": "<a:tungsten_circle_green:1567234524512002088>",
    "id": "1567234524512002088",
    "file": "tungsten_circle_green.gif"
  },
  {
    "name": "tungsten_circle_red",
    "label": "Circle Red",
    "animated": true,
    "discordTag": "<a:tungsten_circle_red:1567234546586353686>",
    "id": "1567234546586353686",
    "file": "tungsten_circle_red.gif"
  },
  {
    "name": "tungsten_circle_white",
    "label": "Circle White",
    "animated": true,
    "discordTag": "<a:tungsten_circle_white:1567234561799233547>",
    "id": "1567234561799233547",
    "file": "tungsten_circle_white.gif"
  },
  {
    "name": "tungsten_circle_yellow",
    "label": "Circle Yellow",
    "animated": true,
    "discordTag": "<a:tungsten_circle_yellow:1567234580690501693>",
    "id": "1567234580690501693",
    "file": "tungsten_circle_yellow.gif"
  },
  {
    "name": "tungsten_clapper",
    "label": "Clapper",
    "animated": true,
    "discordTag": "<a:tungsten_clapper:1567234599262879815>",
    "id": "1567234599262879815",
    "file": "tungsten_clapper.gif"
  },
  {
    "name": "tungsten_clipboard",
    "label": "Clipboard",
    "animated": true,
    "discordTag": "<a:tungsten_clipboard:1567234610176204900>",
    "id": "1567234610176204900",
    "file": "tungsten_clipboard.gif"
  },
  {
    "name": "tungsten_clock",
    "label": "Clock",
    "animated": true,
    "discordTag": "<a:tungsten_clock:1567234623216554118>",
    "id": "1567234623216554118",
    "file": "tungsten_clock.gif"
  },
  {
    "name": "tungsten_close",
    "label": "Close",
    "animated": true,
    "discordTag": "<a:tungsten_close:1567234632905138206>",
    "id": "1567234632905138206",
    "file": "tungsten_close.gif"
  },
  {
    "name": "tungsten_cmd_8ball",
    "label": "Cmd 8ball",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_8ball:1567234645140181082>",
    "id": "1567234645140181082",
    "file": "tungsten_cmd_8ball.gif"
  },
  {
    "name": "tungsten_cmd_addemoji",
    "label": "Cmd Addemoji",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_addemoji:1567234657026707537>",
    "id": "1567234657026707537",
    "file": "tungsten_cmd_addemoji.gif"
  },
  {
    "name": "tungsten_cmd_afk",
    "label": "Cmd Afk",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_afk:1567234668347260938>",
    "id": "1567234668347260938",
    "file": "tungsten_cmd_afk.gif"
  },
  {
    "name": "tungsten_cmd_anaudit",
    "label": "Cmd Anaudit",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_anaudit:1567234683937497259>",
    "id": "1567234683937497259",
    "file": "tungsten_cmd_anaudit.gif"
  },
  {
    "name": "tungsten_cmd_anmode",
    "label": "Cmd Anmode",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_anmode:1567234697556271327>",
    "id": "1567234697556271327",
    "file": "tungsten_cmd_anmode.gif"
  },
  {
    "name": "tungsten_cmd_antighostping",
    "label": "Cmd Antighostping",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_antighostping:1567234715549835435>",
    "id": "1567234715549835435",
    "file": "tungsten_cmd_antighostping.gif"
  },
  {
    "name": "tungsten_cmd_antinuke",
    "label": "Cmd Antinuke",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_antinuke:1567234734726316142>",
    "id": "1567234734726316142",
    "file": "tungsten_cmd_antinuke.gif"
  },
  {
    "name": "tungsten_cmd_antiraid",
    "label": "Cmd Antiraid",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_antiraid:1567234763755102373>",
    "id": "1567234763755102373",
    "file": "tungsten_cmd_antiraid.gif"
  },
  {
    "name": "tungsten_cmd_auditlog",
    "label": "Cmd Auditlog",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_auditlog:1567234776841195712>",
    "id": "1567234776841195712",
    "file": "tungsten_cmd_auditlog.gif"
  },
  {
    "name": "tungsten_cmd_automod",
    "label": "Cmd Automod",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_automod:1567234793022689290>",
    "id": "1567234793022689290",
    "file": "tungsten_cmd_automod.gif"
  },
  {
    "name": "tungsten_cmd_autoreact",
    "label": "Cmd Autoreact",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_autoreact:1567234807379922944>",
    "id": "1567234807379922944",
    "file": "tungsten_cmd_autoreact.gif"
  },
  {
    "name": "tungsten_cmd_autoresponder",
    "label": "Cmd Autoresponder",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_autoresponder:1567234819992330240>",
    "id": "1567234819992330240",
    "file": "tungsten_cmd_autoresponder.gif"
  },
  {
    "name": "tungsten_cmd_autorole",
    "label": "Cmd Autorole",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_autorole:1567234834504482948>",
    "id": "1567234834504482948",
    "file": "tungsten_cmd_autorole.gif"
  },
  {
    "name": "tungsten_cmd_avatar",
    "label": "Cmd Avatar",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_avatar:1567234845363540139>",
    "id": "1567234845363540139",
    "file": "tungsten_cmd_avatar.gif"
  },
  {
    "name": "tungsten_cmd_backup",
    "label": "Cmd Backup",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_backup:1567234860119236649>",
    "id": "1567234860119236649",
    "file": "tungsten_cmd_backup.gif"
  },
  {
    "name": "tungsten_cmd_balance",
    "label": "Cmd Balance",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_balance:1567234874736250981>",
    "id": "1567234874736250981",
    "file": "tungsten_cmd_balance.gif"
  },
  {
    "name": "tungsten_cmd_ban",
    "label": "Cmd Ban",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_ban:1567234887503585321>",
    "id": "1567234887503585321",
    "file": "tungsten_cmd_ban.gif"
  },
  {
    "name": "tungsten_cmd_banpanel",
    "label": "Cmd Banpanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_banpanel:1567234900233552055>",
    "id": "1567234900233552055",
    "file": "tungsten_cmd_banpanel.gif"
  },
  {
    "name": "tungsten_cmd_botinfo",
    "label": "Cmd Botinfo",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_botinfo:1567234914867224616>",
    "id": "1567234914867224616",
    "file": "tungsten_cmd_botinfo.gif"
  },
  {
    "name": "tungsten_cmd_cases",
    "label": "Cmd Cases",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_cases:1567234927450390658>",
    "id": "1567234927450390658",
    "file": "tungsten_cmd_cases.gif"
  },
  {
    "name": "tungsten_cmd_celmod",
    "label": "Cmd Celmod",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_celmod:1567234939886370929>",
    "id": "1567234939886370929",
    "file": "tungsten_cmd_celmod.gif"
  },
  {
    "name": "tungsten_cmd_channelinfo",
    "label": "Cmd Channelinfo",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_channelinfo:1567234953803210806>",
    "id": "1567234953803210806",
    "file": "tungsten_cmd_channelinfo.gif"
  },
  {
    "name": "tungsten_cmd_cleanup",
    "label": "Cmd Cleanup",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_cleanup:1567234967203745988>",
    "id": "1567234967203745988",
    "file": "tungsten_cmd_cleanup.gif"
  },
  {
    "name": "tungsten_cmd_clearwarns",
    "label": "Cmd Clearwarns",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_clearwarns:1567234980797612133>",
    "id": "1567234980797612133",
    "file": "tungsten_cmd_clearwarns.gif"
  },
  {
    "name": "tungsten_cmd_cm",
    "label": "Cmd Cm",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_cm:1567234994768715806>",
    "id": "1567234994768715806",
    "file": "tungsten_cmd_cm.gif"
  },
  {
    "name": "tungsten_cmd_coinflip",
    "label": "Cmd Coinflip",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_coinflip:1567235008547258368>",
    "id": "1567235008547258368",
    "file": "tungsten_cmd_coinflip.gif"
  },
  {
    "name": "tungsten_cmd_componentsv2",
    "label": "Cmd Componentsv2",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_componentsv2:1567235021910315069>",
    "id": "1567235021910315069",
    "file": "tungsten_cmd_componentsv2.gif"
  },
  {
    "name": "tungsten_cmd_connect4",
    "label": "Cmd Connect4",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_connect4:1567235052243517541>",
    "id": "1567235052243517541",
    "file": "tungsten_cmd_connect4.gif"
  },
  {
    "name": "tungsten_cmd_customcmd",
    "label": "Cmd Customcmd",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_customcmd:1567235065107452015>",
    "id": "1567235065107452015",
    "file": "tungsten_cmd_customcmd.gif"
  },
  {
    "name": "tungsten_cmd_customrole",
    "label": "Cmd Customrole",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_customrole:1567235078654791690>",
    "id": "1567235078654791690",
    "file": "tungsten_cmd_customrole.gif"
  },
  {
    "name": "tungsten_cmd_daily",
    "label": "Cmd Daily",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_daily:1567235093611675650>",
    "id": "1567235093611675650",
    "file": "tungsten_cmd_daily.gif"
  },
  {
    "name": "tungsten_cmd_database",
    "label": "Cmd Database",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_database:1567235125513687152>",
    "id": "1567235125513687152",
    "file": "tungsten_cmd_database.gif"
  },
  {
    "name": "tungsten_cmd_deleteemoji",
    "label": "Cmd Deleteemoji",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_deleteemoji:1567235155574267935>",
    "id": "1567235155574267935",
    "file": "tungsten_cmd_deleteemoji.gif"
  },
  {
    "name": "tungsten_cmd_deposit",
    "label": "Cmd Deposit",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_deposit:1567235175472041994>",
    "id": "1567235175472041994",
    "file": "tungsten_cmd_deposit.gif"
  },
  {
    "name": "tungsten_cmd_duty",
    "label": "Cmd Duty",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_duty:1567235200541528074>",
    "id": "1567235200541528074",
    "file": "tungsten_cmd_duty.gif"
  },
  {
    "name": "tungsten_cmd_emergency",
    "label": "Cmd Emergency",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_emergency:1567235226504134656>",
    "id": "1567235226504134656",
    "file": "tungsten_cmd_emergency.gif"
  },
  {
    "name": "tungsten_cmd_emojilist",
    "label": "Cmd Emojilist",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_emojilist:1567235260012298260>",
    "id": "1567235260012298260",
    "file": "tungsten_cmd_emojilist.gif"
  },
  {
    "name": "tungsten_cmd_emojipack",
    "label": "Cmd Emojipack",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_emojipack:1567235282489839766>",
    "id": "1567235282489839766",
    "file": "tungsten_cmd_emojipack.gif"
  },
  {
    "name": "tungsten_cmd_emojiserver",
    "label": "Cmd Emojiserver",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_emojiserver:1567235306711818290>",
    "id": "1567235306711818290",
    "file": "tungsten_cmd_emojiserver.gif"
  },
  {
    "name": "tungsten_cmd_extraowner",
    "label": "Cmd Extraowner",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_extraowner:1567235342850064407>",
    "id": "1567235342850064407",
    "file": "tungsten_cmd_extraowner.gif"
  },
  {
    "name": "tungsten_cmd_gif",
    "label": "Cmd Gif",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_gif:1567235366665326693>",
    "id": "1567235366665326693",
    "file": "tungsten_cmd_gif.gif"
  },
  {
    "name": "tungsten_cmd_giveaway",
    "label": "Cmd Giveaway",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_giveaway:1567235389226352785>",
    "id": "1567235389226352785",
    "file": "tungsten_cmd_giveaway.gif"
  },
  {
    "name": "tungsten_cmd_giverole",
    "label": "Cmd Giverole",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_giverole:1567235411615678545>",
    "id": "1567235411615678545",
    "file": "tungsten_cmd_giverole.gif"
  },
  {
    "name": "tungsten_cmd_help",
    "label": "Cmd Help",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_help:1567235431567724626>",
    "id": "1567235431567724626",
    "file": "tungsten_cmd_help.gif"
  },
  {
    "name": "tungsten_cmd_hide",
    "label": "Cmd Hide",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_hide:1567235456494731295>",
    "id": "1567235456494731295",
    "file": "tungsten_cmd_hide.gif"
  },
  {
    "name": "tungsten_cmd_inrole",
    "label": "Cmd Inrole",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_inrole:1567235483904249897>",
    "id": "1567235483904249897",
    "file": "tungsten_cmd_inrole.gif"
  },
  {
    "name": "tungsten_cmd_investigate",
    "label": "Cmd Investigate",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_investigate:1567235510517375127>",
    "id": "1567235510517375127",
    "file": "tungsten_cmd_investigate.gif"
  },
  {
    "name": "tungsten_cmd_invite",
    "label": "Cmd Invite",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_invite:1567235535573885110>",
    "id": "1567235535573885110",
    "file": "tungsten_cmd_invite.gif"
  },
  {
    "name": "tungsten_cmd_joke",
    "label": "Cmd Joke",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_joke:1567235558705598494>",
    "id": "1567235558705598494",
    "file": "tungsten_cmd_joke.gif"
  },
  {
    "name": "tungsten_cmd_kick",
    "label": "Cmd Kick",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_kick:1567235578293129256>",
    "id": "1567235578293129256",
    "file": "tungsten_cmd_kick.gif"
  },
  {
    "name": "tungsten_cmd_kickpanel",
    "label": "Cmd Kickpanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_kickpanel:1567235599557984417>",
    "id": "1567235599557984417",
    "file": "tungsten_cmd_kickpanel.gif"
  },
  {
    "name": "tungsten_cmd_leaderboard",
    "label": "Cmd Leaderboard",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_leaderboard:1567235635331473509>",
    "id": "1567235635331473509",
    "file": "tungsten_cmd_leaderboard.gif"
  },
  {
    "name": "tungsten_cmd_leave",
    "label": "Cmd Leave",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_leave:1567235657783447573>",
    "id": "1567235657783447573",
    "file": "tungsten_cmd_leave.gif"
  },
  {
    "name": "tungsten_cmd_levels",
    "label": "Cmd Levels",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_levels:1567235696920371301>",
    "id": "1567235696920371301",
    "file": "tungsten_cmd_levels.gif"
  },
  {
    "name": "tungsten_cmd_lock",
    "label": "Cmd Lock",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_lock:1567235715983609857>",
    "id": "1567235715983609857",
    "file": "tungsten_cmd_lock.gif"
  },
  {
    "name": "tungsten_cmd_lockpanel",
    "label": "Cmd Lockpanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_lockpanel:1567235752344035459>",
    "id": "1567235752344035459",
    "file": "tungsten_cmd_lockpanel.gif"
  },
  {
    "name": "tungsten_cmd_membercount",
    "label": "Cmd Membercount",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_membercount:1567235784182857868>",
    "id": "1567235784182857868",
    "file": "tungsten_cmd_membercount.gif"
  },
  {
    "name": "tungsten_cmd_meme",
    "label": "Cmd Meme",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_meme:1567235815833337940>",
    "id": "1567235815833337940",
    "file": "tungsten_cmd_meme.gif"
  },
  {
    "name": "tungsten_cmd_modpanel",
    "label": "Cmd Modpanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_modpanel:1567235859063906364>",
    "id": "1567235859063906364",
    "file": "tungsten_cmd_modpanel.gif"
  },
  {
    "name": "tungsten_cmd_modrolepanel",
    "label": "Cmd Modrolepanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_modrolepanel:1567235913829056616>",
    "id": "1567235913829056616",
    "file": "tungsten_cmd_modrolepanel.gif"
  },
  {
    "name": "tungsten_cmd_mute",
    "label": "Cmd Mute",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_mute:1567235956644253696>",
    "id": "1567235956644253696",
    "file": "tungsten_cmd_mute.gif"
  },
  {
    "name": "tungsten_cmd_mutepanel",
    "label": "Cmd Mutepanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_mutepanel:1567235994359562391>",
    "id": "1567235994359562391",
    "file": "tungsten_cmd_mutepanel.gif"
  },
  {
    "name": "tungsten_cmd_nightmode",
    "label": "Cmd Nightmode",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_nightmode:1567236036550074390>",
    "id": "1567236036550074390",
    "file": "tungsten_cmd_nightmode.gif"
  },
  {
    "name": "tungsten_cmd_noprefix",
    "label": "Cmd Noprefix",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_noprefix:1567236069643132972>",
    "id": "1567236069643132972",
    "file": "tungsten_cmd_noprefix.gif"
  },
  {
    "name": "tungsten_cmd_npmanager",
    "label": "Cmd Npmanager",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_npmanager:1567236115197591596>",
    "id": "1567236115197591596",
    "file": "tungsten_cmd_npmanager.gif"
  },
  {
    "name": "tungsten_cmd_nuke",
    "label": "Cmd Nuke",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_nuke:1567236137746169887>",
    "id": "1567236137746169887",
    "file": "tungsten_cmd_nuke.gif"
  },
  {
    "name": "tungsten_cmd_ownerpanel",
    "label": "Cmd Ownerpanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_ownerpanel:1567236155634622514>",
    "id": "1567236155634622514",
    "file": "tungsten_cmd_ownerpanel.gif"
  },
  {
    "name": "tungsten_cmd_panel",
    "label": "Cmd Panel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_panel:1567236187700338759>",
    "id": "1567236187700338759",
    "file": "tungsten_cmd_panel.gif"
  },
  {
    "name": "tungsten_cmd_panic",
    "label": "Cmd Panic",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_panic:1567236213897822388>",
    "id": "1567236213897822388",
    "file": "tungsten_cmd_panic.gif"
  },
  {
    "name": "tungsten_cmd_pay",
    "label": "Cmd Pay",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_pay:1567236244205867130>",
    "id": "1567236244205867130",
    "file": "tungsten_cmd_pay.gif"
  },
  {
    "name": "tungsten_cmd_ping",
    "label": "Cmd Ping",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_ping:1567236300271255715>",
    "id": "1567236300271255715",
    "file": "tungsten_cmd_ping.gif"
  },
  {
    "name": "tungsten_cmd_pings",
    "label": "Cmd Pings",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_pings:1567236330038235206>",
    "id": "1567236330038235206",
    "file": "tungsten_cmd_pings.gif"
  },
  {
    "name": "tungsten_cmd_prefix",
    "label": "Cmd Prefix",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_prefix:1567236353924792524>",
    "id": "1567236353924792524",
    "file": "tungsten_cmd_prefix.gif"
  },
  {
    "name": "tungsten_cmd_premium",
    "label": "Cmd Premium",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_premium:1567236385734139966>",
    "id": "1567236385734139966",
    "file": "tungsten_cmd_premium.gif"
  },
  {
    "name": "tungsten_cmd_premiummanager",
    "label": "Cmd Premiummanager",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_premiummanager:1567236418634252458>",
    "id": "1567236418634252458",
    "file": "tungsten_cmd_premiummanager.gif"
  },
  {
    "name": "tungsten_cmd_profile",
    "label": "Cmd Profile",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_profile:1567236443917525154>",
    "id": "1567236443917525154",
    "file": "tungsten_cmd_profile.gif"
  },
  {
    "name": "tungsten_cmd_purge",
    "label": "Cmd Purge",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_purge:1567236474280083516>",
    "id": "1567236474280083516",
    "file": "tungsten_cmd_purge.gif"
  },
  {
    "name": "tungsten_cmd_purgepanel",
    "label": "Cmd Purgepanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_purgepanel:1567236525425430749>",
    "id": "1567236525425430749",
    "file": "tungsten_cmd_purgepanel.gif"
  },
  {
    "name": "tungsten_cmd_reactionrole",
    "label": "Cmd Reactionrole",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_reactionrole:1567236559248429167>",
    "id": "1567236559248429167",
    "file": "tungsten_cmd_reactionrole.gif"
  },
  {
    "name": "tungsten_cmd_removerole",
    "label": "Cmd Removerole",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_removerole:1567236636641599548>",
    "id": "1567236636641599548",
    "file": "tungsten_cmd_removerole.gif"
  },
  {
    "name": "tungsten_cmd_rob",
    "label": "Cmd Rob",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_rob:1567236704203571431>",
    "id": "1567236704203571431",
    "file": "tungsten_cmd_rob.gif"
  },
  {
    "name": "tungsten_cmd_roleinfo",
    "label": "Cmd Roleinfo",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_roleinfo:1567236816225046629>",
    "id": "1567236816225046629",
    "file": "tungsten_cmd_roleinfo.gif"
  },
  {
    "name": "tungsten_cmd_roll",
    "label": "Cmd Roll",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_roll:1567236993287725196>",
    "id": "1567236993287725196",
    "file": "tungsten_cmd_roll.gif"
  },
  {
    "name": "tungsten_cmd_rps",
    "label": "Cmd Rps",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_rps:1567237016662577224>",
    "id": "1567237016662577224",
    "file": "tungsten_cmd_rps.gif"
  },
  {
    "name": "tungsten_cmd_securityscore",
    "label": "Cmd Securityscore",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_securityscore:1567237039135400067>",
    "id": "1567237039135400067",
    "file": "tungsten_cmd_securityscore.gif"
  },
  {
    "name": "tungsten_cmd_serverinfo",
    "label": "Cmd Serverinfo",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_serverinfo:1567237069502287923>",
    "id": "1567237069502287923",
    "file": "tungsten_cmd_serverinfo.gif"
  },
  {
    "name": "tungsten_cmd_sethomevc",
    "label": "Cmd Sethomevc",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_sethomevc:1567237101341380720>",
    "id": "1567237101341380720",
    "file": "tungsten_cmd_sethomevc.gif"
  },
  {
    "name": "tungsten_cmd_ship",
    "label": "Cmd Ship",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_ship:1567237143049539777>",
    "id": "1567237143049539777",
    "file": "tungsten_cmd_ship.gif"
  },
  {
    "name": "tungsten_cmd_slots",
    "label": "Cmd Slots",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_slots:1567237210565120220>",
    "id": "1567237210565120220",
    "file": "tungsten_cmd_slots.gif"
  },
  {
    "name": "tungsten_cmd_slowmode",
    "label": "Cmd Slowmode",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_slowmode:1567237253061804164>",
    "id": "1567237253061804164",
    "file": "tungsten_cmd_slowmode.gif"
  },
  {
    "name": "tungsten_cmd_snipe",
    "label": "Cmd Snipe",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_snipe:1567237311106777210>",
    "id": "1567237311106777210",
    "file": "tungsten_cmd_snipe.gif"
  },
  {
    "name": "tungsten_cmd_softban",
    "label": "Cmd Softban",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_softban:1567237338374086719>",
    "id": "1567237338374086719",
    "file": "tungsten_cmd_softban.gif"
  },
  {
    "name": "tungsten_cmd_stats",
    "label": "Cmd Stats",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_stats:1567237361664925757>",
    "id": "1567237361664925757",
    "file": "tungsten_cmd_stats.gif"
  },
  {
    "name": "tungsten_cmd_stickymessage",
    "label": "Cmd Stickymessage",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_stickymessage:1567237387925454968>",
    "id": "1567237387925454968",
    "file": "tungsten_cmd_stickymessage.gif"
  },
  {
    "name": "tungsten_cmd_support",
    "label": "Cmd Support",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_support:1567237424843591770>",
    "id": "1567237424843591770",
    "file": "tungsten_cmd_support.gif"
  },
  {
    "name": "tungsten_cmd_ticket",
    "label": "Cmd Ticket",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_ticket:1567237476173619345>",
    "id": "1567237476173619345",
    "file": "tungsten_cmd_ticket.gif"
  },
  {
    "name": "tungsten_cmd_trivia",
    "label": "Cmd Trivia",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_trivia:1567237570192998610>",
    "id": "1567237570192998610",
    "file": "tungsten_cmd_trivia.gif"
  },
  {
    "name": "tungsten_cmd_unban",
    "label": "Cmd Unban",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_unban:1567237654230208743>",
    "id": "1567237654230208743",
    "file": "tungsten_cmd_unban.gif"
  },
  {
    "name": "tungsten_cmd_unhide",
    "label": "Cmd Unhide",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_unhide:1567237716330946600>",
    "id": "1567237716330946600",
    "file": "tungsten_cmd_unhide.gif"
  },
  {
    "name": "tungsten_cmd_unlock",
    "label": "Cmd Unlock",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_unlock:1567237734299467886>",
    "id": "1567237734299467886",
    "file": "tungsten_cmd_unlock.gif"
  },
  {
    "name": "tungsten_cmd_unmute",
    "label": "Cmd Unmute",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_unmute:1567237746697961612>",
    "id": "1567237746697961612",
    "file": "tungsten_cmd_unmute.gif"
  },
  {
    "name": "tungsten_cmd_unwhitelist",
    "label": "Cmd Unwhitelist",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_unwhitelist:1567237762376273990>",
    "id": "1567237762376273990",
    "file": "tungsten_cmd_unwhitelist.gif"
  },
  {
    "name": "tungsten_cmd_uptime",
    "label": "Cmd Uptime",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_uptime:1567237782605398036>",
    "id": "1567237782605398036",
    "file": "tungsten_cmd_uptime.gif"
  },
  {
    "name": "tungsten_cmd_userinfo",
    "label": "Cmd Userinfo",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_userinfo:1567237805266964481>",
    "id": "1567237805266964481",
    "file": "tungsten_cmd_userinfo.gif"
  },
  {
    "name": "tungsten_cmd_vanityguard",
    "label": "Cmd Vanityguard",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_vanityguard:1567237826154602613>",
    "id": "1567237826154602613",
    "file": "tungsten_cmd_vanityguard.gif"
  },
  {
    "name": "tungsten_cmd_vcrole",
    "label": "Cmd Vcrole",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_vcrole:1567237847486832640>",
    "id": "1567237847486832640",
    "file": "tungsten_cmd_vcrole.gif"
  },
  {
    "name": "tungsten_cmd_vcstatus",
    "label": "Cmd Vcstatus",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_vcstatus:1567237869133635628>",
    "id": "1567237869133635628",
    "file": "tungsten_cmd_vcstatus.gif"
  },
  {
    "name": "tungsten_cmd_voice",
    "label": "Cmd Voice",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_voice:1567237893590753360>",
    "id": "1567237893590753360",
    "file": "tungsten_cmd_voice.gif"
  },
  {
    "name": "tungsten_cmd_voicemod",
    "label": "Cmd Voicemod",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_voicemod:1567237946053099530>",
    "id": "1567237946053099530",
    "file": "tungsten_cmd_voicemod.gif"
  },
  {
    "name": "tungsten_cmd_warn",
    "label": "Cmd Warn",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_warn:1567238033705799771>",
    "id": "1567238033705799771",
    "file": "tungsten_cmd_warn.gif"
  },
  {
    "name": "tungsten_cmd_warnings",
    "label": "Cmd Warnings",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_warnings:1567238062759739435>",
    "id": "1567238062759739435",
    "file": "tungsten_cmd_warnings.gif"
  },
  {
    "name": "tungsten_cmd_warnpanel",
    "label": "Cmd Warnpanel",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_warnpanel:1567238091708702792>",
    "id": "1567238091708702792",
    "file": "tungsten_cmd_warnpanel.gif"
  },
  {
    "name": "tungsten_cmd_welcome",
    "label": "Cmd Welcome",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_welcome:1567238123807842346>",
    "id": "1567238123807842346",
    "file": "tungsten_cmd_welcome.gif"
  },
  {
    "name": "tungsten_cmd_whitelist",
    "label": "Cmd Whitelist",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_whitelist:1567238164991451146>",
    "id": "1567238164991451146",
    "file": "tungsten_cmd_whitelist.gif"
  },
  {
    "name": "tungsten_cmd_whitelisted",
    "label": "Cmd Whitelisted",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_whitelisted:1567238207295455329>",
    "id": "1567238207295455329",
    "file": "tungsten_cmd_whitelisted.gif"
  },
  {
    "name": "tungsten_cmd_withdraw",
    "label": "Cmd Withdraw",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_withdraw:1567238237108310077>",
    "id": "1567238237108310077",
    "file": "tungsten_cmd_withdraw.gif"
  },
  {
    "name": "tungsten_cmd_work",
    "label": "Cmd Work",
    "animated": true,
    "discordTag": "<a:tungsten_cmd_work:1567238276161601567>",
    "id": "1567238276161601567",
    "file": "tungsten_cmd_work.gif"
  },
  {
    "name": "tungsten_coin",
    "label": "Coin",
    "animated": true,
    "discordTag": "<a:tungsten_coin:1567238316967985244>",
    "id": "1567238316967985244",
    "file": "tungsten_coin.gif"
  },
  {
    "name": "tungsten_crown",
    "label": "Crown",
    "animated": true,
    "discordTag": "<a:tungsten_crown:1567238355463176334>",
    "id": "1567238355463176334",
    "file": "tungsten_crown.gif"
  },
  {
    "name": "tungsten_crystal",
    "label": "Crystal",
    "animated": true,
    "discordTag": "<a:tungsten_crystal:1567238398400532571>",
    "id": "1567238398400532571",
    "file": "tungsten_crystal.gif"
  },
  {
    "name": "tungsten_dancer",
    "label": "Dancer",
    "animated": true,
    "discordTag": "<a:tungsten_dancer:1567238442092601424>",
    "id": "1567238442092601424",
    "file": "tungsten_dancer.gif"
  },
  {
    "name": "tungsten_database",
    "label": "Database",
    "animated": true,
    "discordTag": "<a:tungsten_database:1567238475684651168>",
    "id": "1567238475684651168",
    "file": "tungsten_database.gif"
  },
  {
    "name": "tungsten_diamond_small",
    "label": "Diamond Small",
    "animated": true,
    "discordTag": "<a:tungsten_diamond_small:1567238516855939283>",
    "id": "1567238516855939283",
    "file": "tungsten_diamond_small.gif"
  },
  {
    "name": "tungsten_dice",
    "label": "Dice",
    "animated": true,
    "discordTag": "<a:tungsten_dice:1567238580827328582>",
    "id": "1567238580827328582",
    "file": "tungsten_dice.gif"
  },
  {
    "name": "tungsten_door",
    "label": "Door",
    "animated": true,
    "discordTag": "<a:tungsten_door:1567238621432643794>",
    "id": "1567238621432643794",
    "file": "tungsten_door.gif"
  },
  {
    "name": "tungsten_drama",
    "label": "Drama",
    "animated": true,
    "discordTag": "<a:tungsten_drama:1567238681557991474>",
    "id": "1567238681557991474",
    "file": "tungsten_drama.gif"
  },
  {
    "name": "tungsten_eightball",
    "label": "Eightball",
    "animated": true,
    "discordTag": "<a:tungsten_eightball:1567238723995967638>",
    "id": "1567238723995967638",
    "file": "tungsten_eightball.gif"
  },
  {
    "name": "tungsten_error",
    "label": "Error",
    "animated": true,
    "discordTag": "<a:tungsten_error:1567238753284653106>",
    "id": "1567238753284653106",
    "file": "tungsten_error.gif"
  },
  {
    "name": "tungsten_explosion",
    "label": "Explosion",
    "animated": true,
    "discordTag": "<a:tungsten_explosion:1567238834343911554>",
    "id": "1567238834343911554",
    "file": "tungsten_explosion.gif"
  },
  {
    "name": "tungsten_eye",
    "label": "Eye",
    "animated": true,
    "discordTag": "<a:tungsten_eye:1567238862042833088>",
    "id": "1567238862042833088",
    "file": "tungsten_eye.gif"
  },
  {
    "name": "tungsten_eye_slash",
    "label": "Eye Slash",
    "animated": true,
    "discordTag": "<a:tungsten_eye_slash:1567238896612282430>",
    "id": "1567238896612282430",
    "file": "tungsten_eye_slash.gif"
  },
  {
    "name": "tungsten_eyes",
    "label": "Eyes",
    "animated": true,
    "discordTag": "<a:tungsten_eyes:1567238923913011254>",
    "id": "1567238923913011254",
    "file": "tungsten_eyes.gif"
  },
  {
    "name": "tungsten_face_angry",
    "label": "Face Angry",
    "animated": true,
    "discordTag": "<a:tungsten_face_angry:1567238949284618291>",
    "id": "1567238949284618291",
    "file": "tungsten_face_angry.gif"
  },
  {
    "name": "tungsten_face_cool",
    "label": "Face Cool",
    "animated": true,
    "discordTag": "<a:tungsten_face_cool:1567238977264685118>",
    "id": "1567238977264685118",
    "file": "tungsten_face_cool.gif"
  },
  {
    "name": "tungsten_face_crazy",
    "label": "Face Crazy",
    "animated": true,
    "discordTag": "<a:tungsten_face_crazy:1567239007463669832>",
    "id": "1567239007463669832",
    "file": "tungsten_face_crazy.gif"
  },
  {
    "name": "tungsten_face_cry",
    "label": "Face Cry",
    "animated": true,
    "discordTag": "<a:tungsten_face_cry:1567239031735980053>",
    "id": "1567239031735980053",
    "file": "tungsten_face_cry.gif"
  },
  {
    "name": "tungsten_face_devil",
    "label": "Face Devil",
    "animated": true,
    "discordTag": "<a:tungsten_face_devil:1567239058327871564>",
    "id": "1567239058327871564",
    "file": "tungsten_face_devil.gif"
  },
  {
    "name": "tungsten_face_flushed",
    "label": "Face Flushed",
    "animated": true,
    "discordTag": "<a:tungsten_face_flushed:1567239086484357130>",
    "id": "1567239086484357130",
    "file": "tungsten_face_flushed.gif"
  },
  {
    "name": "tungsten_face_grin",
    "label": "Face Grin",
    "animated": true,
    "discordTag": "<a:tungsten_face_grin:1567239115089514536>",
    "id": "1567239115089514536",
    "file": "tungsten_face_grin.gif"
  },
  {
    "name": "tungsten_face_laugh",
    "label": "Face Laugh",
    "animated": true,
    "discordTag": "<a:tungsten_face_laugh:1567239143048613900>",
    "id": "1567239143048613900",
    "file": "tungsten_face_laugh.gif"
  },
  {
    "name": "tungsten_face_love",
    "label": "Face Love",
    "animated": true,
    "discordTag": "<a:tungsten_face_love:1567239175110140056>",
    "id": "1567239175110140056",
    "file": "tungsten_face_love.gif"
  },
  {
    "name": "tungsten_face_melting",
    "label": "Face Melting",
    "animated": true,
    "discordTag": "<a:tungsten_face_melting:1567239201269743827>",
    "id": "1567239201269743827",
    "file": "tungsten_face_melting.gif"
  },
  {
    "name": "tungsten_face_pleading",
    "label": "Face Pleading",
    "animated": true,
    "discordTag": "<a:tungsten_face_pleading:1567239233788448939>",
    "id": "1567239233788448939",
    "file": "tungsten_face_pleading.gif"
  },
  {
    "name": "tungsten_face_scared",
    "label": "Face Scared",
    "animated": true,
    "discordTag": "<a:tungsten_face_scared:1567239267774763038>",
    "id": "1567239267774763038",
    "file": "tungsten_face_scared.gif"
  },
  {
    "name": "tungsten_face_sleep",
    "label": "Face Sleep",
    "animated": true,
    "discordTag": "<a:tungsten_face_sleep:1567239295914213548>",
    "id": "1567239295914213548",
    "file": "tungsten_face_sleep.gif"
  },
  {
    "name": "tungsten_face_smile",
    "label": "Face Smile",
    "animated": true,
    "discordTag": "<a:tungsten_face_smile:1567239325941375126>",
    "id": "1567239325941375126",
    "file": "tungsten_face_smile.gif"
  },
  {
    "name": "tungsten_face_surprised",
    "label": "Face Surprised",
    "animated": true,
    "discordTag": "<a:tungsten_face_surprised:1567239358975582248>",
    "id": "1567239358975582248",
    "file": "tungsten_face_surprised.gif"
  },
  {
    "name": "tungsten_face_wink",
    "label": "Face Wink",
    "animated": true,
    "discordTag": "<a:tungsten_face_wink:1567239380244897846>",
    "id": "1567239380244897846",
    "file": "tungsten_face_wink.gif"
  },
  {
    "name": "tungsten_fist",
    "label": "Fist",
    "animated": true,
    "discordTag": "<a:tungsten_fist:1567239431444897892>",
    "id": "1567239431444897892",
    "file": "tungsten_fist.gif"
  },
  {
    "name": "tungsten_flag_chequered",
    "label": "Flag Chequered",
    "animated": true,
    "discordTag": "<a:tungsten_flag_chequered:1567239507135307972>",
    "id": "1567239507135307972",
    "file": "tungsten_flag_chequered.gif"
  },
  {
    "name": "tungsten_flag_white",
    "label": "Flag White",
    "animated": true,
    "discordTag": "<a:tungsten_flag_white:1567239547769589771>",
    "id": "1567239547769589771",
    "file": "tungsten_flag_white.gif"
  },
  {
    "name": "tungsten_folder",
    "label": "Folder",
    "animated": true,
    "discordTag": "<a:tungsten_folder:1567239623145558046>",
    "id": "1567239623145558046",
    "file": "tungsten_folder.gif"
  },
  {
    "name": "tungsten_folder_open",
    "label": "Folder Open",
    "animated": true,
    "discordTag": "<a:tungsten_folder_open:1567239652501495988>",
    "id": "1567239652501495988",
    "file": "tungsten_folder_open.gif"
  },
  {
    "name": "tungsten_foot",
    "label": "Foot",
    "animated": true,
    "discordTag": "<a:tungsten_foot:1567239740942458880>",
    "id": "1567239740942458880",
    "file": "tungsten_foot.gif"
  },
  {
    "name": "tungsten_frame",
    "label": "Frame",
    "animated": true,
    "discordTag": "<a:tungsten_frame:1567239867983863889>",
    "id": "1567239867983863889",
    "file": "tungsten_frame.gif"
  },
  {
    "name": "tungsten_gamepad",
    "label": "Gamepad",
    "animated": true,
    "discordTag": "<a:tungsten_gamepad:1567239909985616063>",
    "id": "1567239909985616063",
    "file": "tungsten_gamepad.gif"
  },
  {
    "name": "tungsten_gear",
    "label": "Gear",
    "animated": true,
    "discordTag": "<a:tungsten_gear:1567239932970406012>",
    "id": "1567239932970406012",
    "file": "tungsten_gear.gif"
  },
  {
    "name": "tungsten_gem",
    "label": "Gem",
    "animated": true,
    "discordTag": "<a:tungsten_gem:1567239960837357759>",
    "id": "1567239960837357759",
    "file": "tungsten_gem.gif"
  },
  {
    "name": "tungsten_gem_flower",
    "label": "Gem Flower",
    "animated": true,
    "discordTag": "<a:tungsten_gem_flower:1567239998779031595>",
    "id": "1567239998779031595",
    "file": "tungsten_gem_flower.gif"
  },
  {
    "name": "tungsten_ghost",
    "label": "Ghost",
    "animated": true,
    "discordTag": "<a:tungsten_ghost:1567240021692518512>",
    "id": "1567240021692518512",
    "file": "tungsten_ghost.gif"
  },
  {
    "name": "tungsten_gift",
    "label": "Gift",
    "animated": true,
    "discordTag": "<a:tungsten_gift:1567240042563244072>",
    "id": "1567240042563244072",
    "file": "tungsten_gift.gif"
  },
  {
    "name": "tungsten_globe",
    "label": "Globe",
    "animated": true,
    "discordTag": "<a:tungsten_globe:1567240068253622433>",
    "id": "1567240068253622433",
    "file": "tungsten_globe.gif"
  },
  {
    "name": "tungsten_grapes",
    "label": "Grapes",
    "animated": true,
    "discordTag": "<a:tungsten_grapes:1567240092739833866>",
    "id": "1567240092739833866",
    "file": "tungsten_grapes.gif"
  },
  {
    "name": "tungsten_gun",
    "label": "Gun",
    "animated": true,
    "discordTag": "<a:tungsten_gun:1567240119612874822>",
    "id": "1567240119612874822",
    "file": "tungsten_gun.gif"
  },
  {
    "name": "tungsten_hammer",
    "label": "Hammer",
    "animated": true,
    "discordTag": "<a:tungsten_hammer:1567240140277944350>",
    "id": "1567240140277944350",
    "file": "tungsten_hammer.gif"
  },
  {
    "name": "tungsten_hands_up",
    "label": "Hands Up",
    "animated": true,
    "discordTag": "<a:tungsten_hands_up:1567240175594250302>",
    "id": "1567240175594250302",
    "file": "tungsten_hands_up.gif"
  },
  {
    "name": "tungsten_handshake",
    "label": "Handshake",
    "animated": true,
    "discordTag": "<a:tungsten_handshake:1567240195646951494>",
    "id": "1567240195646951494",
    "file": "tungsten_handshake.gif"
  },
  {
    "name": "tungsten_headphones",
    "label": "Headphones",
    "animated": true,
    "discordTag": "<a:tungsten_headphones:1567240226789785730>",
    "id": "1567240226789785730",
    "file": "tungsten_headphones.gif"
  },
  {
    "name": "tungsten_heart",
    "label": "Heart",
    "animated": true,
    "discordTag": "<a:tungsten_heart:1567240255680155718>",
    "id": "1567240255680155718",
    "file": "tungsten_heart.gif"
  },
  {
    "name": "tungsten_heart_broken",
    "label": "Heart Broken",
    "animated": true,
    "discordTag": "<a:tungsten_heart_broken:1567240285053001738>",
    "id": "1567240285053001738",
    "file": "tungsten_heart_broken.gif"
  },
  {
    "name": "tungsten_heart_orange",
    "label": "Heart Orange",
    "animated": true,
    "discordTag": "<a:tungsten_heart_orange:1567240324336582743>",
    "id": "1567240324336582743",
    "file": "tungsten_heart_orange.gif"
  },
  {
    "name": "tungsten_heart_sparkle",
    "label": "Heart Sparkle",
    "animated": true,
    "discordTag": "<a:tungsten_heart_sparkle:1567240386659885106>",
    "id": "1567240386659885106",
    "file": "tungsten_heart_sparkle.gif"
  },
  {
    "name": "tungsten_heart_yellow",
    "label": "Heart Yellow",
    "animated": true,
    "discordTag": "<a:tungsten_heart_yellow:1567240422068068529>",
    "id": "1567240422068068529",
    "file": "tungsten_heart_yellow.gif"
  },
  {
    "name": "tungsten_hearts",
    "label": "Hearts",
    "animated": true,
    "discordTag": "<a:tungsten_hearts:1567240511670976552>",
    "id": "1567240511670976552",
    "file": "tungsten_hearts.gif"
  },
  {
    "name": "tungsten_home",
    "label": "Home",
    "animated": true,
    "discordTag": "<a:tungsten_home:1567240545661620387>",
    "id": "1567240545661620387",
    "file": "tungsten_home.gif"
  },
  {
    "name": "tungsten_hourglass",
    "label": "Hourglass",
    "animated": true,
    "discordTag": "<a:tungsten_hourglass:1567240660702986281>",
    "id": "1567240660702986281",
    "file": "tungsten_hourglass.gif"
  },
  {
    "name": "tungsten_id",
    "label": "Id",
    "animated": true,
    "discordTag": "<a:tungsten_id:1567240689048355008>",
    "id": "1567240689048355008",
    "file": "tungsten_id.gif"
  },
  {
    "name": "tungsten_inbox",
    "label": "Inbox",
    "animated": true,
    "discordTag": "<a:tungsten_inbox:1567240785219289108>",
    "id": "1567240785219289108",
    "file": "tungsten_inbox.gif"
  },
  {
    "name": "tungsten_infinity",
    "label": "Infinity",
    "animated": true,
    "discordTag": "<a:tungsten_infinity:1567240813895745626>",
    "id": "1567240813895745626",
    "file": "tungsten_infinity.gif"
  },
  {
    "name": "tungsten_info",
    "label": "Info",
    "animated": true,
    "discordTag": "<a:tungsten_info:1567240890748248084>",
    "id": "1567240890748248084",
    "file": "tungsten_info.gif"
  },
  {
    "name": "tungsten_key",
    "label": "Key",
    "animated": true,
    "discordTag": "<a:tungsten_key:1567240907684581492>",
    "id": "1567240907684581492",
    "file": "tungsten_key.gif"
  },
  {
    "name": "tungsten_keycap_ten",
    "label": "Keycap Ten",
    "animated": true,
    "discordTag": "<a:tungsten_keycap_ten:1567240934599688303>",
    "id": "1567240934599688303",
    "file": "tungsten_keycap_ten.gif"
  },
  {
    "name": "tungsten_keylock",
    "label": "Keylock",
    "animated": true,
    "discordTag": "<a:tungsten_keylock:1567240958075084951>",
    "id": "1567240958075084951",
    "file": "tungsten_keylock.gif"
  },
  {
    "name": "tungsten_knife",
    "label": "Knife",
    "animated": true,
    "discordTag": "<a:tungsten_knife:1567240975758270495>",
    "id": "1567240975758270495",
    "file": "tungsten_knife.gif"
  },
  {
    "name": "tungsten_lemon",
    "label": "Lemon",
    "animated": true,
    "discordTag": "<a:tungsten_lemon:1567240998231343184>",
    "id": "1567240998231343184",
    "file": "tungsten_lemon.gif"
  },
  {
    "name": "tungsten_link",
    "label": "Link",
    "animated": true,
    "discordTag": "<a:tungsten_link:1567241025813086210>",
    "id": "1567241025813086210",
    "file": "tungsten_link.gif"
  },
  {
    "name": "tungsten_loading",
    "label": "Loading",
    "animated": true,
    "discordTag": "<a:tungsten_loading:1567241050567876698>",
    "id": "1567241050567876698",
    "file": "tungsten_loading.gif"
  },
  {
    "name": "tungsten_lock",
    "label": "Lock",
    "animated": true,
    "discordTag": "<a:tungsten_lock:1567241079030550668>",
    "id": "1567241079030550668",
    "file": "tungsten_lock.gif"
  },
  {
    "name": "tungsten_mailbox",
    "label": "Mailbox",
    "animated": true,
    "discordTag": "<a:tungsten_mailbox:1567241098009509949>",
    "id": "1567241098009509949",
    "file": "tungsten_mailbox.gif"
  },
  {
    "name": "tungsten_medal_bronze",
    "label": "Medal Bronze",
    "animated": true,
    "discordTag": "<a:tungsten_medal_bronze:1567241129030582403>",
    "id": "1567241129030582403",
    "file": "tungsten_medal_bronze.gif"
  },
  {
    "name": "tungsten_medal_gold",
    "label": "Medal Gold",
    "animated": true,
    "discordTag": "<a:tungsten_medal_gold:1567241163453366472>",
    "id": "1567241163453366472",
    "file": "tungsten_medal_gold.gif"
  },
  {
    "name": "tungsten_medal_silver",
    "label": "Medal Silver",
    "animated": true,
    "discordTag": "<a:tungsten_medal_silver:1567241205409128649>",
    "id": "1567241205409128649",
    "file": "tungsten_medal_silver.gif"
  },
  {
    "name": "tungsten_memo",
    "label": "Memo",
    "animated": true,
    "discordTag": "<a:tungsten_memo:1567241226577780957>",
    "id": "1567241226577780957",
    "file": "tungsten_memo.gif"
  },
  {
    "name": "tungsten_mic",
    "label": "Mic",
    "animated": true,
    "discordTag": "<a:tungsten_mic:1567241257862832189>",
    "id": "1567241257862832189",
    "file": "tungsten_mic.gif"
  },
  {
    "name": "tungsten_minus",
    "label": "Minus",
    "animated": true,
    "discordTag": "<a:tungsten_minus:1567241276057849856>",
    "id": "1567241276057849856",
    "file": "tungsten_minus.gif"
  },
  {
    "name": "tungsten_money_wings",
    "label": "Money Wings",
    "animated": true,
    "discordTag": "<a:tungsten_money_wings:1567241294408061024>",
    "id": "1567241294408061024",
    "file": "tungsten_money_wings.gif"
  },
  {
    "name": "tungsten_moneybag",
    "label": "Moneybag",
    "animated": true,
    "discordTag": "<a:tungsten_moneybag:1567241334698541109>",
    "id": "1567241334698541109",
    "file": "tungsten_moneybag.gif"
  },
  {
    "name": "tungsten_monitor",
    "label": "Monitor",
    "animated": true,
    "discordTag": "<a:tungsten_monitor:1567241360984121485>",
    "id": "1567241360984121485",
    "file": "tungsten_monitor.gif"
  },
  {
    "name": "tungsten_moon",
    "label": "Moon",
    "animated": true,
    "discordTag": "<a:tungsten_moon:1567241385021673674>",
    "id": "1567241385021673674",
    "file": "tungsten_moon.gif"
  },
  {
    "name": "tungsten_music",
    "label": "Music",
    "animated": true,
    "discordTag": "<a:tungsten_music:1567241425328939110>",
    "id": "1567241425328939110",
    "file": "tungsten_music.gif"
  },
  {
    "name": "tungsten_mute",
    "label": "Mute",
    "animated": true,
    "discordTag": "<a:tungsten_mute:1567241451992121647>",
    "id": "1567241451992121647",
    "file": "tungsten_mute.gif"
  },
  {
    "name": "tungsten_nametag",
    "label": "Nametag",
    "animated": true,
    "discordTag": "<a:tungsten_nametag:1567241539082526760>",
    "id": "1567241539082526760",
    "file": "tungsten_nametag.gif"
  },
  {
    "name": "tungsten_ninja",
    "label": "Ninja",
    "animated": true,
    "discordTag": "<a:tungsten_ninja:1567241598260093050>",
    "id": "1567241598260093050",
    "file": "tungsten_ninja.gif"
  },
  {
    "name": "tungsten_notepad",
    "label": "Notepad",
    "animated": true,
    "discordTag": "<a:tungsten_notepad:1567241681911152733>",
    "id": "1567241681911152733",
    "file": "tungsten_notepad.gif"
  },
  {
    "name": "tungsten_package",
    "label": "Package",
    "animated": true,
    "discordTag": "<a:tungsten_package:1567241719177543862>",
    "id": "1567241719177543862",
    "file": "tungsten_package.gif"
  },
  {
    "name": "tungsten_palette",
    "label": "Palette",
    "animated": true,
    "discordTag": "<a:tungsten_palette:1567241748613169344>",
    "id": "1567241748613169344",
    "file": "tungsten_palette.gif"
  },
  {
    "name": "tungsten_party",
    "label": "Party",
    "animated": true,
    "discordTag": "<a:tungsten_party:1567241769593339988>",
    "id": "1567241769593339988",
    "file": "tungsten_party.gif"
  },
  {
    "name": "tungsten_person",
    "label": "Person",
    "animated": true,
    "discordTag": "<a:tungsten_person:1567241792150175834>",
    "id": "1567241792150175834",
    "file": "tungsten_person.gif"
  },
  {
    "name": "tungsten_pin",
    "label": "Pin",
    "animated": true,
    "discordTag": "<a:tungsten_pin:1567241810114379987>",
    "id": "1567241810114379987",
    "file": "tungsten_pin.gif"
  },
  {
    "name": "tungsten_plane",
    "label": "Plane",
    "animated": true,
    "discordTag": "<a:tungsten_plane:1567241829538336884>",
    "id": "1567241829538336884",
    "file": "tungsten_plane.gif"
  },
  {
    "name": "tungsten_plus",
    "label": "Plus",
    "animated": true,
    "discordTag": "<a:tungsten_plus:1567241846453833840>",
    "id": "1567241846453833840",
    "file": "tungsten_plus.gif"
  },
  {
    "name": "tungsten_point",
    "label": "Point",
    "animated": true,
    "discordTag": "<a:tungsten_point:1567241861293408391>",
    "id": "1567241861293408391",
    "file": "tungsten_point.gif"
  },
  {
    "name": "tungsten_question",
    "label": "Question",
    "animated": true,
    "discordTag": "<a:tungsten_question:1567241882080116776>",
    "id": "1567241882080116776",
    "file": "tungsten_question.gif"
  },
  {
    "name": "tungsten_refresh",
    "label": "Refresh",
    "animated": true,
    "discordTag": "<a:tungsten_refresh:1567241907116187658>",
    "id": "1567241907116187658",
    "file": "tungsten_refresh.gif"
  },
  {
    "name": "tungsten_rice",
    "label": "Rice",
    "animated": true,
    "discordTag": "<a:tungsten_rice:1567241928603336724>",
    "id": "1567241928603336724",
    "file": "tungsten_rice.gif"
  },
  {
    "name": "tungsten_ring",
    "label": "Ring",
    "animated": true,
    "discordTag": "<a:tungsten_ring:1567241949461618768>",
    "id": "1567241949461618768",
    "file": "tungsten_ring.gif"
  },
  {
    "name": "tungsten_rocket",
    "label": "Rocket",
    "animated": true,
    "discordTag": "<a:tungsten_rocket:1567241971804798976>",
    "id": "1567241971804798976",
    "file": "tungsten_rocket.gif"
  },
  {
    "name": "tungsten_satellite",
    "label": "Satellite",
    "animated": true,
    "discordTag": "<a:tungsten_satellite:1567241994928005137>",
    "id": "1567241994928005137",
    "file": "tungsten_satellite.gif"
  },
  {
    "name": "tungsten_save",
    "label": "Save",
    "animated": true,
    "discordTag": "<a:tungsten_save:1567242015283085507>",
    "id": "1567242015283085507",
    "file": "tungsten_save.gif"
  },
  {
    "name": "tungsten_scales",
    "label": "Scales",
    "animated": true,
    "discordTag": "<a:tungsten_scales:1567242041098895521>",
    "id": "1567242041098895521",
    "file": "tungsten_scales.gif"
  },
  {
    "name": "tungsten_scroll",
    "label": "Scroll",
    "animated": true,
    "discordTag": "<a:tungsten_scroll:1567242059708899381>",
    "id": "1567242059708899381",
    "file": "tungsten_scroll.gif"
  },
  {
    "name": "tungsten_search",
    "label": "Search",
    "animated": true,
    "discordTag": "<a:tungsten_search:1567242081167216771>",
    "id": "1567242081167216771",
    "file": "tungsten_search.gif"
  },
  {
    "name": "tungsten_shield",
    "label": "Shield",
    "animated": true,
    "discordTag": "<a:tungsten_shield:1567242104923627574>",
    "id": "1567242104923627574",
    "file": "tungsten_shield.gif"
  },
  {
    "name": "tungsten_shrug",
    "label": "Shrug",
    "animated": true,
    "discordTag": "<a:tungsten_shrug:1567242138323001384>",
    "id": "1567242138323001384",
    "file": "tungsten_shrug.gif"
  },
  {
    "name": "tungsten_siren",
    "label": "Siren",
    "animated": true,
    "discordTag": "<a:tungsten_siren:1567242157725712555>",
    "id": "1567242157725712555",
    "file": "tungsten_siren.gif"
  },
  {
    "name": "tungsten_skull",
    "label": "Skull",
    "animated": true,
    "discordTag": "<a:tungsten_skull:1567242182836883486>",
    "id": "1567242182836883486",
    "file": "tungsten_skull.gif"
  },
  {
    "name": "tungsten_slots",
    "label": "Slots",
    "animated": true,
    "discordTag": "<a:tungsten_slots:1567242206266527956>",
    "id": "1567242206266527956",
    "file": "tungsten_slots.gif"
  },
  {
    "name": "tungsten_sound",
    "label": "Sound",
    "animated": true,
    "discordTag": "<a:tungsten_sound:1567242242127568958>",
    "id": "1567242242127568958",
    "file": "tungsten_sound.gif"
  },
  {
    "name": "tungsten_sparkle",
    "label": "Sparkle",
    "animated": true,
    "discordTag": "<a:tungsten_sparkle:1567242264311369839>",
    "id": "1567242264311369839",
    "file": "tungsten_sparkle.gif"
  },
  {
    "name": "tungsten_star",
    "label": "Star",
    "animated": true,
    "discordTag": "<a:tungsten_star:1567242331785138238>",
    "id": "1567242331785138238",
    "file": "tungsten_star.gif"
  },
  {
    "name": "tungsten_stop",
    "label": "Stop",
    "animated": true,
    "discordTag": "<a:tungsten_stop:1567242365335511121>",
    "id": "1567242365335511121",
    "file": "tungsten_stop.gif"
  },
  {
    "name": "tungsten_stopwatch",
    "label": "Stopwatch",
    "animated": true,
    "discordTag": "<a:tungsten_stopwatch:1567242453562687558>",
    "id": "1567242453562687558",
    "file": "tungsten_stopwatch.gif"
  },
  {
    "name": "tungsten_success",
    "label": "Success",
    "animated": true,
    "discordTag": "<a:tungsten_success:1567242523468890274>",
    "id": "1567242523468890274",
    "file": "tungsten_success.gif"
  },
  {
    "name": "tungsten_sun",
    "label": "Sun",
    "animated": true,
    "discordTag": "<a:tungsten_sun:1567242622701932604>",
    "id": "1567242622701932604",
    "file": "tungsten_sun.gif"
  },
  {
    "name": "tungsten_sweep",
    "label": "Sweep",
    "animated": true,
    "discordTag": "<a:tungsten_sweep:1567242656281657414>",
    "id": "1567242656281657414",
    "file": "tungsten_sweep.gif"
  },
  {
    "name": "tungsten_swords",
    "label": "Swords",
    "animated": true,
    "discordTag": "<a:tungsten_swords:1567242677819277352>",
    "id": "1567242677819277352",
    "file": "tungsten_swords.gif"
  },
  {
    "name": "tungsten_tag",
    "label": "Tag",
    "animated": true,
    "discordTag": "<a:tungsten_tag:1567242698904047691>",
    "id": "1567242698904047691",
    "file": "tungsten_tag.gif"
  },
  {
    "name": "tungsten_target",
    "label": "Target",
    "animated": true,
    "discordTag": "<a:tungsten_target:1567242733997789205>",
    "id": "1567242733997789205",
    "file": "tungsten_target.gif"
  },
  {
    "name": "tungsten_terminal",
    "label": "Terminal",
    "animated": true,
    "discordTag": "<a:tungsten_terminal:1567242755040878664>",
    "id": "1567242755040878664",
    "file": "tungsten_terminal.gif"
  },
  {
    "name": "tungsten_tick",
    "label": "Tick",
    "animated": true,
    "discordTag": "<a:tungsten_tick:1567242779908636802>",
    "id": "1567242779908636802",
    "file": "tungsten_tick.gif"
  },
  {
    "name": "tungsten_ticket",
    "label": "Ticket",
    "animated": true,
    "discordTag": "<a:tungsten_ticket:1567242811961770155>",
    "id": "1567242811961770155",
    "file": "tungsten_ticket.gif"
  },
  {
    "name": "tungsten_tools",
    "label": "Tools",
    "animated": true,
    "discordTag": "<a:tungsten_tools:1567242831834124431>",
    "id": "1567242831834124431",
    "file": "tungsten_tools.gif"
  },
  {
    "name": "tungsten_tooth",
    "label": "Tooth",
    "animated": true,
    "discordTag": "<a:tungsten_tooth:1567242851480375296>",
    "id": "1567242851480375296",
    "file": "tungsten_tooth.gif"
  },
  {
    "name": "tungsten_top",
    "label": "Top",
    "animated": true,
    "discordTag": "<a:tungsten_top:1567242867846680718>",
    "id": "1567242867846680718",
    "file": "tungsten_top.gif"
  },
  {
    "name": "tungsten_trash",
    "label": "Trash",
    "animated": true,
    "discordTag": "<a:tungsten_trash:1567242891276062872>",
    "id": "1567242891276062872",
    "file": "tungsten_trash.gif"
  },
  {
    "name": "tungsten_trophy",
    "label": "Trophy",
    "animated": true,
    "discordTag": "<a:tungsten_trophy:1567242918446501939>",
    "id": "1567242918446501939",
    "file": "tungsten_trophy.gif"
  },
  {
    "name": "tungsten_tv",
    "label": "Tv",
    "animated": true,
    "discordTag": "<a:tungsten_tv:1567242943197224960>",
    "id": "1567242943197224960",
    "file": "tungsten_tv.gif"
  },
  {
    "name": "tungsten_ui_appoint",
    "label": "Ui Appoint",
    "animated": true,
    "discordTag": "<a:tungsten_ui_appoint:1567242963359375450>",
    "id": "1567242963359375450",
    "file": "tungsten_ui_appoint.gif"
  },
  {
    "name": "tungsten_ui_assign",
    "label": "Ui Assign",
    "animated": true,
    "discordTag": "<a:tungsten_ui_assign:1567242984397742250>",
    "id": "1567242984397742250",
    "file": "tungsten_ui_assign.gif"
  },
  {
    "name": "tungsten_ui_backup_db",
    "label": "Ui Backup Db",
    "animated": true,
    "discordTag": "<a:tungsten_ui_backup_db:1567243012629729341>",
    "id": "1567243012629729341",
    "file": "tungsten_ui_backup_db.gif"
  },
  {
    "name": "tungsten_ui_channel_tools",
    "label": "Ui Channel Tools",
    "animated": true,
    "discordTag": "<a:tungsten_ui_channel_tools:1567243046951854130>",
    "id": "1567243046951854130",
    "file": "tungsten_ui_channel_tools.gif"
  },
  {
    "name": "tungsten_ui_check_rank",
    "label": "Ui Check Rank",
    "animated": true,
    "discordTag": "<a:tungsten_ui_check_rank:1567243080464335058>",
    "id": "1567243080464335058",
    "file": "tungsten_ui_check_rank.gif"
  },
  {
    "name": "tungsten_ui_complete_verify",
    "label": "Ui Complete Verify",
    "animated": true,
    "discordTag": "<a:tungsten_ui_complete_verify:1567243101477806101>",
    "id": "1567243101477806101",
    "file": "tungsten_ui_complete_verify.gif"
  },
  {
    "name": "tungsten_ui_d10m",
    "label": "Ui D10m",
    "animated": true,
    "discordTag": "<a:tungsten_ui_d10m:1567243132008136765>",
    "id": "1567243132008136765",
    "file": "tungsten_ui_d10m.gif"
  },
  {
    "name": "tungsten_ui_d1d",
    "label": "Ui D1d",
    "animated": true,
    "discordTag": "<a:tungsten_ui_d1d:1567243179269423157>",
    "id": "1567243179269423157",
    "file": "tungsten_ui_d1d.gif"
  },
  {
    "name": "tungsten_ui_d1h",
    "label": "Ui D1h",
    "animated": true,
    "discordTag": "<a:tungsten_ui_d1h:1567243251767971951>",
    "id": "1567243251767971951",
    "file": "tungsten_ui_d1h.gif"
  },
  {
    "name": "tungsten_ui_d1w",
    "label": "Ui D1w",
    "animated": true,
    "discordTag": "<a:tungsten_ui_d1w:1567243278917836991>",
    "id": "1567243278917836991",
    "file": "tungsten_ui_d1w.gif"
  },
  {
    "name": "tungsten_ui_d5m",
    "label": "Ui D5m",
    "animated": true,
    "discordTag": "<a:tungsten_ui_d5m:1567243350279725106>",
    "id": "1567243350279725106",
    "file": "tungsten_ui_d5m.gif"
  },
  {
    "name": "tungsten_ui_daily_usage",
    "label": "Ui Daily Usage",
    "animated": true,
    "discordTag": "<a:tungsten_ui_daily_usage:1567243371603296270>",
    "id": "1567243371603296270",
    "file": "tungsten_ui_daily_usage.gif"
  },
  {
    "name": "tungsten_ui_disable_all",
    "label": "Ui Disable All",
    "animated": true,
    "discordTag": "<a:tungsten_ui_disable_all:1567243443338485862>",
    "id": "1567243443338485862",
    "file": "tungsten_ui_disable_all.gif"
  },
  {
    "name": "tungsten_ui_disconnect",
    "label": "Ui Disconnect",
    "animated": true,
    "discordTag": "<a:tungsten_ui_disconnect:1567243506072682706>",
    "id": "1567243506072682706",
    "file": "tungsten_ui_disconnect.gif"
  },
  {
    "name": "tungsten_ui_dismiss",
    "label": "Ui Dismiss",
    "animated": true,
    "discordTag": "<a:tungsten_ui_dismiss:1567243549555036200>",
    "id": "1567243549555036200",
    "file": "tungsten_ui_dismiss.gif"
  },
  {
    "name": "tungsten_ui_dm_test",
    "label": "Ui Dm Test",
    "animated": true,
    "discordTag": "<a:tungsten_ui_dm_test:1567243572002951178>",
    "id": "1567243572002951178",
    "file": "tungsten_ui_dm_test.gif"
  },
  {
    "name": "tungsten_ui_edit_nick",
    "label": "Ui Edit Nick",
    "animated": true,
    "discordTag": "<a:tungsten_ui_edit_nick:1567243591686823967>",
    "id": "1567243591686823967",
    "file": "tungsten_ui_edit_nick.gif"
  },
  {
    "name": "tungsten_ui_enable_all",
    "label": "Ui Enable All",
    "animated": true,
    "discordTag": "<a:tungsten_ui_enable_all:1567243610716508202>",
    "id": "1567243610716508202",
    "file": "tungsten_ui_enable_all.gif"
  },
  {
    "name": "tungsten_ui_events",
    "label": "Ui Events",
    "animated": true,
    "discordTag": "<a:tungsten_ui_events:1567243642094092323>",
    "id": "1567243642094092323",
    "file": "tungsten_ui_events.gif"
  },
  {
    "name": "tungsten_ui_forfeit",
    "label": "Ui Forfeit",
    "animated": true,
    "discordTag": "<a:tungsten_ui_forfeit:1567243664613314610>",
    "id": "1567243664613314610",
    "file": "tungsten_ui_forfeit.gif"
  },
  {
    "name": "tungsten_ui_hide",
    "label": "Ui Hide",
    "animated": true,
    "discordTag": "<a:tungsten_ui_hide:1567243688143487107>",
    "id": "1567243688143487107",
    "file": "tungsten_ui_hide.gif"
  },
  {
    "name": "tungsten_ui_hide_vc",
    "label": "Ui Hide Vc",
    "animated": true,
    "discordTag": "<a:tungsten_ui_hide_vc:1567243710075371651>",
    "id": "1567243710075371651",
    "file": "tungsten_ui_hide_vc.gif"
  },
  {
    "name": "tungsten_ui_install",
    "label": "Ui Install",
    "animated": true,
    "discordTag": "<a:tungsten_ui_install:1567243737363386509>",
    "id": "1567243737363386509",
    "file": "tungsten_ui_install.gif"
  },
  {
    "name": "tungsten_ui_invite_admin",
    "label": "Ui Invite Admin",
    "animated": true,
    "discordTag": "<a:tungsten_ui_invite_admin:1567243760079741052>",
    "id": "1567243760079741052",
    "file": "tungsten_ui_invite_admin.gif"
  },
  {
    "name": "tungsten_ui_invite_std",
    "label": "Ui Invite Std",
    "animated": true,
    "discordTag": "<a:tungsten_ui_invite_std:1567243779495305246>",
    "id": "1567243779495305246",
    "file": "tungsten_ui_invite_std.gif"
  },
  {
    "name": "tungsten_ui_join_support",
    "label": "Ui Join Support",
    "animated": true,
    "discordTag": "<a:tungsten_ui_join_support:1567243801343299704>",
    "id": "1567243801343299704",
    "file": "tungsten_ui_join_support.gif"
  },
  {
    "name": "tungsten_ui_jump",
    "label": "Ui Jump",
    "animated": true,
    "discordTag": "<a:tungsten_ui_jump:1567243825028538530>",
    "id": "1567243825028538530",
    "file": "tungsten_ui_jump.gif"
  },
  {
    "name": "tungsten_ui_lb_history",
    "label": "Ui Lb History",
    "animated": true,
    "discordTag": "<a:tungsten_ui_lb_history:1567243859229147236>",
    "id": "1567243859229147236",
    "file": "tungsten_ui_lb_history.gif"
  },
  {
    "name": "tungsten_ui_leveling",
    "label": "Ui Leveling",
    "animated": true,
    "discordTag": "<a:tungsten_ui_leveling:1567243886294737016>",
    "id": "1567243886294737016",
    "file": "tungsten_ui_leveling.gif"
  },
  {
    "name": "tungsten_ui_list",
    "label": "Ui List",
    "animated": true,
    "discordTag": "<a:tungsten_ui_list:1567243909707604059>",
    "id": "1567243909707604059",
    "file": "tungsten_ui_list.gif"
  },
  {
    "name": "tungsten_ui_lock_vc",
    "label": "Ui Lock Vc",
    "animated": true,
    "discordTag": "<a:tungsten_ui_lock_vc:1567243939503931611>",
    "id": "1567243939503931611",
    "file": "tungsten_ui_lock_vc.gif"
  },
  {
    "name": "tungsten_ui_lockdown",
    "label": "Ui Lockdown",
    "animated": true,
    "discordTag": "<a:tungsten_ui_lockdown:1567243966150082580>",
    "id": "1567243966150082580",
    "file": "tungsten_ui_lockdown.gif"
  },
  {
    "name": "tungsten_ui_manage",
    "label": "Ui Manage",
    "animated": true,
    "discordTag": "<a:tungsten_ui_manage:1567243992435920926>",
    "id": "1567243992435920926",
    "file": "tungsten_ui_manage.gif"
  },
  {
    "name": "tungsten_ui_mute_all",
    "label": "Ui Mute All",
    "animated": true,
    "discordTag": "<a:tungsten_ui_mute_all:1567244037264506951>",
    "id": "1567244037264506951",
    "file": "tungsten_ui_mute_all.gif"
  },
  {
    "name": "tungsten_ui_n1",
    "label": "Ui N1",
    "animated": true,
    "discordTag": "<a:tungsten_ui_n1:1567244083447996537>",
    "id": "1567244083447996537",
    "file": "tungsten_ui_n1.gif"
  },
  {
    "name": "tungsten_ui_n2",
    "label": "Ui N2",
    "animated": true,
    "discordTag": "<a:tungsten_ui_n2:1567244128704659548>",
    "id": "1567244128704659548",
    "file": "tungsten_ui_n2.gif"
  },
  {
    "name": "tungsten_ui_n3",
    "label": "Ui N3",
    "animated": true,
    "discordTag": "<a:tungsten_ui_n3:1567244152553603203>",
    "id": "1567244152553603203",
    "file": "tungsten_ui_n3.gif"
  },
  {
    "name": "tungsten_ui_n4",
    "label": "Ui N4",
    "animated": true,
    "discordTag": "<a:tungsten_ui_n4:1567244239912575056>",
    "id": "1567244239912575056",
    "file": "tungsten_ui_n4.gif"
  },
  {
    "name": "tungsten_ui_n5",
    "label": "Ui N5",
    "animated": true,
    "discordTag": "<a:tungsten_ui_n5:1567244324213755965>",
    "id": "1567244324213755965",
    "file": "tungsten_ui_n5.gif"
  },
  {
    "name": "tungsten_ui_n6",
    "label": "Ui N6",
    "animated": true,
    "discordTag": "<a:tungsten_ui_n6:1567244344866639972>",
    "id": "1567244344866639972",
    "file": "tungsten_ui_n6.gif"
  },
  {
    "name": "tungsten_ui_n7",
    "label": "Ui N7",
    "animated": true,
    "discordTag": "<a:tungsten_ui_n7:1567244425057411202>",
    "id": "1567244425057411202",
    "file": "tungsten_ui_n7.gif"
  },
  {
    "name": "tungsten_ui_off",
    "label": "Ui Off",
    "animated": true,
    "discordTag": "<a:tungsten_ui_off:1567244478178402347>",
    "id": "1567244478178402347",
    "file": "tungsten_ui_off.gif"
  },
  {
    "name": "tungsten_ui_on",
    "label": "Ui On",
    "animated": true,
    "discordTag": "<a:tungsten_ui_on:1567244543546630266>",
    "id": "1567244543546630266",
    "file": "tungsten_ui_on.gif"
  },
  {
    "name": "tungsten_ui_open",
    "label": "Ui Open",
    "animated": true,
    "discordTag": "<a:tungsten_ui_open:1567244565159743488>",
    "id": "1567244565159743488",
    "file": "tungsten_ui_open.gif"
  },
  {
    "name": "tungsten_ui_overview",
    "label": "Ui Overview",
    "animated": true,
    "discordTag": "<a:tungsten_ui_overview:1567244587137769573>",
    "id": "1567244587137769573",
    "file": "tungsten_ui_overview.gif"
  },
  {
    "name": "tungsten_ui_p10",
    "label": "Ui P10",
    "animated": true,
    "discordTag": "<a:tungsten_ui_p10:1567244612081553568>",
    "id": "1567244612081553568",
    "file": "tungsten_ui_p10.gif"
  },
  {
    "name": "tungsten_ui_p100",
    "label": "Ui P100",
    "animated": true,
    "discordTag": "<a:tungsten_ui_p100:1567244632121671763>",
    "id": "1567244632121671763",
    "file": "tungsten_ui_p100.gif"
  },
  {
    "name": "tungsten_ui_p25",
    "label": "Ui P25",
    "animated": true,
    "discordTag": "<a:tungsten_ui_p25:1567244653416161343>",
    "id": "1567244653416161343",
    "file": "tungsten_ui_p25.gif"
  },
  {
    "name": "tungsten_ui_p50",
    "label": "Ui P50",
    "animated": true,
    "discordTag": "<a:tungsten_ui_p50:1567244676057006090>",
    "id": "1567244676057006090",
    "file": "tungsten_ui_p50.gif"
  },
  {
    "name": "tungsten_ui_paper",
    "label": "Ui Paper",
    "animated": true,
    "discordTag": "<a:tungsten_ui_paper:1567244704989454378>",
    "id": "1567244704989454378",
    "file": "tungsten_ui_paper.gif"
  },
  {
    "name": "tungsten_ui_perks",
    "label": "Ui Perks",
    "animated": true,
    "discordTag": "<a:tungsten_ui_perks:1567244732160147549>",
    "id": "1567244732160147549",
    "file": "tungsten_ui_perks.gif"
  },
  {
    "name": "tungsten_ui_presets",
    "label": "Ui Presets",
    "animated": true,
    "discordTag": "<a:tungsten_ui_presets:1567244762405150832>",
    "id": "1567244762405150832",
    "file": "tungsten_ui_presets.gif"
  },
  {
    "name": "tungsten_ui_pulse",
    "label": "Ui Pulse",
    "animated": true,
    "discordTag": "<a:tungsten_ui_pulse:1567244779249729658>",
    "id": "1567244779249729658",
    "file": "tungsten_ui_pulse.gif"
  },
  {
    "name": "tungsten_ui_purge_all",
    "label": "Ui Purge All",
    "animated": true,
    "discordTag": "<a:tungsten_ui_purge_all:1567244800946606170>",
    "id": "1567244800946606170",
    "file": "tungsten_ui_purge_all.gif"
  },
  {
    "name": "tungsten_ui_purge_bots",
    "label": "Ui Purge Bots",
    "animated": true,
    "discordTag": "<a:tungsten_ui_purge_bots:1567244820274225244>",
    "id": "1567244820274225244",
    "file": "tungsten_ui_purge_bots.gif"
  },
  {
    "name": "tungsten_ui_quickpunish",
    "label": "Ui Quickpunish",
    "animated": true,
    "discordTag": "<a:tungsten_ui_quickpunish:1567244834576801813>",
    "id": "1567244834576801813",
    "file": "tungsten_ui_quickpunish.gif"
  },
  {
    "name": "tungsten_ui_quit",
    "label": "Ui Quit",
    "animated": true,
    "discordTag": "<a:tungsten_ui_quit:1567244850779258981>",
    "id": "1567244850779258981",
    "file": "tungsten_ui_quit.gif"
  },
  {
    "name": "tungsten_ui_rank",
    "label": "Ui Rank",
    "animated": true,
    "discordTag": "<a:tungsten_ui_rank:1567244880005038184>",
    "id": "1567244880005038184",
    "file": "tungsten_ui_rank.gif"
  },
  {
    "name": "tungsten_ui_redeem",
    "label": "Ui Redeem",
    "animated": true,
    "discordTag": "<a:tungsten_ui_redeem:1567244905896616090>",
    "id": "1567244905896616090",
    "file": "tungsten_ui_redeem.gif"
  },
  {
    "name": "tungsten_ui_remove_timeout",
    "label": "Ui Remove Timeout",
    "animated": true,
    "discordTag": "<a:tungsten_ui_remove_timeout:1567244927346155600>",
    "id": "1567244927346155600",
    "file": "tungsten_ui_remove_timeout.gif"
  },
  {
    "name": "tungsten_ui_reset",
    "label": "Ui Reset",
    "animated": true,
    "discordTag": "<a:tungsten_ui_reset:1567244948041113621>",
    "id": "1567244948041113621",
    "file": "tungsten_ui_reset.gif"
  },
  {
    "name": "tungsten_ui_revoke",
    "label": "Ui Revoke",
    "animated": true,
    "discordTag": "<a:tungsten_ui_revoke:1567244971436679319>",
    "id": "1567244971436679319",
    "file": "tungsten_ui_revoke.gif"
  },
  {
    "name": "tungsten_ui_rock",
    "label": "Ui Rock",
    "animated": true,
    "discordTag": "<a:tungsten_ui_rock:1567244992609517809>",
    "id": "1567244992609517809",
    "file": "tungsten_ui_rock.gif"
  },
  {
    "name": "tungsten_ui_role_add",
    "label": "Ui Role Add",
    "animated": true,
    "discordTag": "<a:tungsten_ui_role_add:1567245019587411968>",
    "id": "1567245019587411968",
    "file": "tungsten_ui_role_add.gif"
  },
  {
    "name": "tungsten_ui_role_remove",
    "label": "Ui Role Remove",
    "animated": true,
    "discordTag": "<a:tungsten_ui_role_remove:1567245052009255103>",
    "id": "1567245052009255103",
    "file": "tungsten_ui_role_remove.gif"
  },
  {
    "name": "tungsten_ui_roles_nick",
    "label": "Ui Roles Nick",
    "animated": true,
    "discordTag": "<a:tungsten_ui_roles_nick:1567245091091910751>",
    "id": "1567245091091910751",
    "file": "tungsten_ui_roles_nick.gif"
  },
  {
    "name": "tungsten_ui_rules",
    "label": "Ui Rules",
    "animated": true,
    "discordTag": "<a:tungsten_ui_rules:1567245114655641680>",
    "id": "1567245114655641680",
    "file": "tungsten_ui_rules.gif"
  },
  {
    "name": "tungsten_ui_scissors",
    "label": "Ui Scissors",
    "animated": true,
    "discordTag": "<a:tungsten_ui_scissors:1567245155545780484>",
    "id": "1567245155545780484",
    "file": "tungsten_ui_scissors.gif"
  },
  {
    "name": "tungsten_ui_score",
    "label": "Ui Score",
    "animated": true,
    "discordTag": "<a:tungsten_ui_score:1567245190027288709>",
    "id": "1567245190027288709",
    "file": "tungsten_ui_score.gif"
  },
  {
    "name": "tungsten_ui_server_status",
    "label": "Ui Server Status",
    "animated": true,
    "discordTag": "<a:tungsten_ui_server_status:1567245256393625651>",
    "id": "1567245256393625651",
    "file": "tungsten_ui_server_status.gif"
  },
  {
    "name": "tungsten_ui_telemetry",
    "label": "Ui Telemetry",
    "animated": true,
    "discordTag": "<a:tungsten_ui_telemetry:1567245337486434404>",
    "id": "1567245337486434404",
    "file": "tungsten_ui_telemetry.gif"
  },
  {
    "name": "tungsten_ui_test",
    "label": "Ui Test",
    "animated": true,
    "discordTag": "<a:tungsten_ui_test:1567245407510204466>",
    "id": "1567245407510204466",
    "file": "tungsten_ui_test.gif"
  },
  {
    "name": "tungsten_ui_ticket_close",
    "label": "Ui Ticket Close",
    "animated": true,
    "discordTag": "<a:tungsten_ui_ticket_close:1567245485117284382>",
    "id": "1567245485117284382",
    "file": "tungsten_ui_ticket_close.gif"
  },
  {
    "name": "tungsten_ui_ticket_open",
    "label": "Ui Ticket Open",
    "animated": true,
    "discordTag": "<a:tungsten_ui_ticket_open:1567245507699675276>",
    "id": "1567245507699675276",
    "file": "tungsten_ui_ticket_open.gif"
  },
  {
    "name": "tungsten_ui_timeout",
    "label": "Ui Timeout",
    "animated": true,
    "discordTag": "<a:tungsten_ui_timeout:1567245550204493934>",
    "id": "1567245550204493934",
    "file": "tungsten_ui_timeout.gif"
  },
  {
    "name": "tungsten_ui_unassign",
    "label": "Ui Unassign",
    "animated": true,
    "discordTag": "<a:tungsten_ui_unassign:1567245588783829053>",
    "id": "1567245588783829053",
    "file": "tungsten_ui_unassign.gif"
  },
  {
    "name": "tungsten_ui_undo",
    "label": "Ui Undo",
    "animated": true,
    "discordTag": "<a:tungsten_ui_undo:1567245669087846462>",
    "id": "1567245669087846462",
    "file": "tungsten_ui_undo.gif"
  },
  {
    "name": "tungsten_ui_unhide",
    "label": "Ui Unhide",
    "animated": true,
    "discordTag": "<a:tungsten_ui_unhide:1567245749073354832>",
    "id": "1567245749073354832",
    "file": "tungsten_ui_unhide.gif"
  },
  {
    "name": "tungsten_ui_unhide_vc",
    "label": "Ui Unhide Vc",
    "animated": true,
    "discordTag": "<a:tungsten_ui_unhide_vc:1567245826777161792>",
    "id": "1567245826777161792",
    "file": "tungsten_ui_unhide_vc.gif"
  },
  {
    "name": "tungsten_ui_unlock_vc",
    "label": "Ui Unlock Vc",
    "animated": true,
    "discordTag": "<a:tungsten_ui_unlock_vc:1567245856430620782>",
    "id": "1567245856430620782",
    "file": "tungsten_ui_unlock_vc.gif"
  },
  {
    "name": "tungsten_ui_unlockdown",
    "label": "Ui Unlockdown",
    "animated": true,
    "discordTag": "<a:tungsten_ui_unlockdown:1567245990556209313>",
    "id": "1567245990556209313",
    "file": "tungsten_ui_unlockdown.gif"
  },
  {
    "name": "tungsten_ui_unmute_all",
    "label": "Ui Unmute All",
    "animated": true,
    "discordTag": "<a:tungsten_ui_unmute_all:1567246118520365256>",
    "id": "1567246118520365256",
    "file": "tungsten_ui_unmute_all.gif"
  },
  {
    "name": "tungsten_ui_user_add",
    "label": "Ui User Add",
    "animated": true,
    "discordTag": "<a:tungsten_ui_user_add:1567246155706929205>",
    "id": "1567246155706929205",
    "file": "tungsten_ui_user_add.gif"
  },
  {
    "name": "tungsten_ui_user_remove",
    "label": "Ui User Remove",
    "animated": true,
    "discordTag": "<a:tungsten_ui_user_remove:1567246253467631616>",
    "id": "1567246253467631616",
    "file": "tungsten_ui_user_remove.gif"
  },
  {
    "name": "tungsten_ui_verbose",
    "label": "Ui Verbose",
    "animated": true,
    "discordTag": "<a:tungsten_ui_verbose:1567246309063397548>",
    "id": "1567246309063397548",
    "file": "tungsten_ui_verbose.gif"
  },
  {
    "name": "tungsten_ui_view_emojis",
    "label": "Ui View Emojis",
    "animated": true,
    "discordTag": "<a:tungsten_ui_view_emojis:1567246384980168774>",
    "id": "1567246384980168774",
    "file": "tungsten_ui_view_emojis.gif"
  },
  {
    "name": "tungsten_ui_welcome_test",
    "label": "Ui Welcome Test",
    "animated": true,
    "discordTag": "<a:tungsten_ui_welcome_test:1567246433336299654>",
    "id": "1567246433336299654",
    "file": "tungsten_ui_welcome_test.gif"
  },
  {
    "name": "tungsten_unlock",
    "label": "Unlock",
    "animated": true,
    "discordTag": "<a:tungsten_unlock:1567246515209117968>",
    "id": "1567246515209117968",
    "file": "tungsten_unlock.gif"
  },
  {
    "name": "tungsten_user",
    "label": "User",
    "animated": true,
    "discordTag": "<a:tungsten_user:1567246556778995802>",
    "id": "1567246556778995802",
    "file": "tungsten_user.gif"
  },
  {
    "name": "tungsten_users",
    "label": "Users",
    "animated": true,
    "discordTag": "<a:tungsten_users:1567246628606185502>",
    "id": "1567246628606185502",
    "file": "tungsten_users.gif"
  },
  {
    "name": "tungsten_warn",
    "label": "Warn",
    "animated": true,
    "discordTag": "<a:tungsten_warn:1567246685082746940>",
    "id": "1567246685082746940",
    "file": "tungsten_warn.gif"
  },
  {
    "name": "tungsten_wave",
    "label": "Wave",
    "animated": true,
    "discordTag": "<a:tungsten_wave:1567246763822158004>",
    "id": "1567246763822158004",
    "file": "tungsten_wave.gif"
  },
  {
    "name": "tungsten_wind",
    "label": "Wind",
    "animated": true,
    "discordTag": "<a:tungsten_wind:1567246820927602838>",
    "id": "1567246820927602838",
    "file": "tungsten_wind.gif"
  },
  {
    "name": "tungsten_zzz",
    "label": "Zzz",
    "animated": true,
    "discordTag": "<a:tungsten_zzz:1567246871834132673>",
    "id": "1567246871834132673",
    "file": "tungsten_zzz.gif"
  },
  {
    "name": "tungsten_achievements",
    "label": "Achievements",
    "animated": true,
    "discordTag": "<a:tungsten_achievements:1569329206842757271>",
    "id": "1569329206842757271",
    "file": "tungsten_achievements.gif"
  },
  {
    "name": "tungsten_an_stage_abuse",
    "label": "An Stage Abuse",
    "animated": true,
    "discordTag": "<a:tungsten_an_stage_abuse:1569329214539173898>",
    "id": "1569329214539173898",
    "file": "tungsten_an_stage_abuse.gif"
  },
  {
    "name": "tungsten_analytics",
    "label": "Analytics",
    "animated": true,
    "discordTag": "<a:tungsten_analytics:1569329222265208843>",
    "id": "1569329222265208843",
    "file": "tungsten_analytics.gif"
  },
  {
    "name": "tungsten_auction",
    "label": "Auction",
    "animated": true,
    "discordTag": "<a:tungsten_auction:1569329230435590194>",
    "id": "1569329230435590194",
    "file": "tungsten_auction.gif"
  },
  {
    "name": "tungsten_autoslow",
    "label": "Autoslow",
    "animated": true,
    "discordTag": "<a:tungsten_autoslow:1569329238585118783>",
    "id": "1569329238585118783",
    "file": "tungsten_autoslow.gif"
  },
  {
    "name": "tungsten_autothread",
    "label": "Autothread",
    "animated": true,
    "discordTag": "<a:tungsten_autothread:1569329247355539606>",
    "id": "1569329247355539606",
    "file": "tungsten_autothread.gif"
  },
  {
    "name": "tungsten_bans",
    "label": "Bans",
    "animated": true,
    "discordTag": "<a:tungsten_bans:1569329255693688853>",
    "id": "1569329255693688853",
    "file": "tungsten_bans.gif"
  },
  {
    "name": "tungsten_calc",
    "label": "Calc",
    "animated": true,
    "discordTag": "<a:tungsten_calc:1569329263469924396>",
    "id": "1569329263469924396",
    "file": "tungsten_calc.gif"
  },
  {
    "name": "tungsten_cat_clans",
    "label": "Cat Clans",
    "animated": true,
    "discordTag": "<a:tungsten_cat_clans:1569329279701884928>",
    "id": "1569329279701884928",
    "file": "tungsten_cat_clans.gif"
  },
  {
    "name": "tungsten_cat_modmail",
    "label": "Cat Modmail",
    "animated": true,
    "discordTag": "<a:tungsten_cat_modmail:1569329287692296213>",
    "id": "1569329287692296213",
    "file": "tungsten_cat_modmail.gif"
  },
  {
    "name": "tungsten_cat_pets",
    "label": "Cat Pets",
    "animated": true,
    "discordTag": "<a:tungsten_cat_pets:1569329296542011563>",
    "id": "1569329296542011563",
    "file": "tungsten_cat_pets.gif"
  },
  {
    "name": "tungsten_cat_social",
    "label": "Cat Social",
    "animated": true,
    "discordTag": "<a:tungsten_cat_social:1569329304196747418>",
    "id": "1569329304196747418",
    "file": "tungsten_cat_social.gif"
  },
  {
    "name": "tungsten_clan",
    "label": "Clan",
    "animated": true,
    "discordTag": "<a:tungsten_clan:1569329312774103142>",
    "id": "1569329312774103142",
    "file": "tungsten_clan.gif"
  },
  {
    "name": "tungsten_convert",
    "label": "Convert",
    "animated": true,
    "discordTag": "<a:tungsten_convert:1569329320802000956>",
    "id": "1569329320802000956",
    "file": "tungsten_convert.gif"
  },
  {
    "name": "tungsten_countdown",
    "label": "Countdown",
    "animated": true,
    "discordTag": "<a:tungsten_countdown:1569329328838152274>",
    "id": "1569329328838152274",
    "file": "tungsten_countdown.gif"
  },
  {
    "name": "tungsten_discordpoll",
    "label": "Discordpoll",
    "animated": true,
    "discordTag": "<a:tungsten_discordpoll:1569329347171590216>",
    "id": "1569329347171590216",
    "file": "tungsten_discordpoll.gif"
  },
  {
    "name": "tungsten_encode",
    "label": "Encode",
    "animated": true,
    "discordTag": "<a:tungsten_encode:1569329355111538820>",
    "id": "1569329355111538820",
    "file": "tungsten_encode.gif"
  },
  {
    "name": "tungsten_event",
    "label": "Event",
    "animated": true,
    "discordTag": "<a:tungsten_event:1569329363038638090>",
    "id": "1569329363038638090",
    "file": "tungsten_event.gif"
  },
  {
    "name": "tungsten_evidence",
    "label": "Evidence",
    "animated": true,
    "discordTag": "<a:tungsten_evidence:1569329371850874921>",
    "id": "1569329371850874921",
    "file": "tungsten_evidence.gif"
  },
  {
    "name": "tungsten_farm",
    "label": "Farm",
    "animated": true,
    "discordTag": "<a:tungsten_farm:1569329379975364628>",
    "id": "1569329379975364628",
    "file": "tungsten_farm.gif"
  },
  {
    "name": "tungsten_feed",
    "label": "Feed",
    "animated": true,
    "discordTag": "<a:tungsten_feed:1569329388053467276>",
    "id": "1569329388053467276",
    "file": "tungsten_feed.gif"
  },
  {
    "name": "tungsten_forum",
    "label": "Forum",
    "animated": true,
    "discordTag": "<a:tungsten_forum:1569329396278370374>",
    "id": "1569329396278370374",
    "file": "tungsten_forum.gif"
  },
  {
    "name": "tungsten_guildsettings",
    "label": "Guildsettings",
    "animated": true,
    "discordTag": "<a:tungsten_guildsettings:1569329404558184562>",
    "id": "1569329404558184562",
    "file": "tungsten_guildsettings.gif"
  },
  {
    "name": "tungsten_integrations",
    "label": "Integrations",
    "animated": true,
    "discordTag": "<a:tungsten_integrations:1569329413110239292>",
    "id": "1569329413110239292",
    "file": "tungsten_integrations.gif"
  },
  {
    "name": "tungsten_linkedroles",
    "label": "Linkedroles",
    "animated": true,
    "discordTag": "<a:tungsten_linkedroles:1569329421352046592>",
    "id": "1569329421352046592",
    "file": "tungsten_linkedroles.gif"
  },
  {
    "name": "tungsten_lockdown",
    "label": "Lockdown",
    "animated": true,
    "discordTag": "<a:tungsten_lockdown:1569329429174296697>",
    "id": "1569329429174296697",
    "file": "tungsten_lockdown.gif"
  },
  {
    "name": "tungsten_macro",
    "label": "Macro",
    "animated": true,
    "discordTag": "<a:tungsten_macro:1569329438586310706>",
    "id": "1569329438586310706",
    "file": "tungsten_macro.gif"
  },
  {
    "name": "tungsten_marriage",
    "label": "Marriage",
    "animated": true,
    "discordTag": "<a:tungsten_marriage:1569329446325063725>",
    "id": "1569329446325063725",
    "file": "tungsten_marriage.gif"
  },
  {
    "name": "tungsten_modmail",
    "label": "Modmail",
    "animated": true,
    "discordTag": "<a:tungsten_modmail:1569329454952611870>",
    "id": "1569329454952611870",
    "file": "tungsten_modmail.gif"
  },
  {
    "name": "tungsten_nativeautomod",
    "label": "Nativeautomod",
    "animated": true,
    "discordTag": "<a:tungsten_nativeautomod:1569329462921920542>",
    "id": "1569329462921920542",
    "file": "tungsten_nativeautomod.gif"
  },
  {
    "name": "tungsten_npm",
    "label": "Npm",
    "animated": true,
    "discordTag": "<a:tungsten_npm:1569329471373320352>",
    "id": "1569329471373320352",
    "file": "tungsten_npm.gif"
  },
  {
    "name": "tungsten_onboarding",
    "label": "Onboarding",
    "animated": true,
    "discordTag": "<a:tungsten_onboarding:1569329479325585481>",
    "id": "1569329479325585481",
    "file": "tungsten_onboarding.gif"
  },
  {
    "name": "tungsten_override",
    "label": "Override",
    "animated": true,
    "discordTag": "<a:tungsten_override:1569329487794143305>",
    "id": "1569329487794143305",
    "file": "tungsten_override.gif"
  },
  {
    "name": "tungsten_panelbuilder",
    "label": "Panelbuilder",
    "animated": true,
    "discordTag": "<a:tungsten_panelbuilder:1569329495809200158>",
    "id": "1569329495809200158",
    "file": "tungsten_panelbuilder.gif"
  },
  {
    "name": "tungsten_password",
    "label": "Password",
    "animated": true,
    "discordTag": "<a:tungsten_password:1569329504994852944>",
    "id": "1569329504994852944",
    "file": "tungsten_password.gif"
  },
  {
    "name": "tungsten_pet",
    "label": "Pet",
    "animated": true,
    "discordTag": "<a:tungsten_pet:1569329513408634920>",
    "id": "1569329513408634920",
    "file": "tungsten_pet.gif"
  },
  {
    "name": "tungsten_pokemon",
    "label": "Pokemon",
    "animated": true,
    "discordTag": "<a:tungsten_pokemon:1569329520966635581>",
    "id": "1569329520966635581",
    "file": "tungsten_pokemon.gif"
  },
  {
    "name": "tungsten_policy",
    "label": "Policy",
    "animated": true,
    "discordTag": "<a:tungsten_policy:1569329528851927131>",
    "id": "1569329528851927131",
    "file": "tungsten_policy.gif"
  },
  {
    "name": "tungsten_presence",
    "label": "Presence",
    "animated": true,
    "discordTag": "<a:tungsten_presence:1569329536875888711>",
    "id": "1569329536875888711",
    "file": "tungsten_presence.gif"
  },
  {
    "name": "tungsten_profile",
    "label": "Profile",
    "animated": true,
    "discordTag": "<a:tungsten_profile:1569329544819900416>",
    "id": "1569329544819900416",
    "file": "tungsten_profile.gif"
  },
  {
    "name": "tungsten_quests",
    "label": "Quests",
    "animated": true,
    "discordTag": "<a:tungsten_quests:1569329552453533827>",
    "id": "1569329552453533827",
    "file": "tungsten_quests.gif"
  },
  {
    "name": "tungsten_rep",
    "label": "Rep",
    "animated": true,
    "discordTag": "<a:tungsten_rep:1569329560917381213>",
    "id": "1569329560917381213",
    "file": "tungsten_rep.gif"
  },
  {
    "name": "tungsten_serverdoctor",
    "label": "Serverdoctor",
    "animated": true,
    "discordTag": "<a:tungsten_serverdoctor:1569329568471457898>",
    "id": "1569329568471457898",
    "file": "tungsten_serverdoctor.gif"
  },
  {
    "name": "tungsten_setup",
    "label": "Setup",
    "animated": true,
    "discordTag": "<a:tungsten_setup:1569329576490836098>",
    "id": "1569329576490836098",
    "file": "tungsten_setup.gif"
  },
  {
    "name": "tungsten_snowflake",
    "label": "Snowflake",
    "animated": true,
    "discordTag": "<a:tungsten_snowflake:1569329585487614105>",
    "id": "1569329585487614105",
    "file": "tungsten_snowflake.gif"
  },
  {
    "name": "tungsten_soundboard",
    "label": "Soundboard",
    "animated": true,
    "discordTag": "<a:tungsten_soundboard:1569329593561780354>",
    "id": "1569329593561780354",
    "file": "tungsten_soundboard.gif"
  },
  {
    "name": "tungsten_stage",
    "label": "Stage",
    "animated": true,
    "discordTag": "<a:tungsten_stage:1569329601971224720>",
    "id": "1569329601971224720",
    "file": "tungsten_stage.gif"
  },
  {
    "name": "tungsten_thread",
    "label": "Thread",
    "animated": true,
    "discordTag": "<a:tungsten_thread:1569329618928930846>",
    "id": "1569329618928930846",
    "file": "tungsten_thread.gif"
  },
  {
    "name": "tungsten_tournament",
    "label": "Tournament",
    "animated": true,
    "discordTag": "<a:tungsten_tournament:1569329627057487993>",
    "id": "1569329627057487993",
    "file": "tungsten_tournament.gif"
  },
  {
    "name": "tungsten_trade",
    "label": "Trade",
    "animated": true,
    "discordTag": "<a:tungsten_trade:1569329634733072495>",
    "id": "1569329634733072495",
    "file": "tungsten_trade.gif"
  },
  {
    "name": "tungsten_ui_bid",
    "label": "Ui Bid",
    "animated": true,
    "discordTag": "<a:tungsten_ui_bid:1569329642609836154>",
    "id": "1569329642609836154",
    "file": "tungsten_ui_bid.gif"
  },
  {
    "name": "tungsten_ui_bracket",
    "label": "Ui Bracket",
    "animated": true,
    "discordTag": "<a:tungsten_ui_bracket:1569329652714184704>",
    "id": "1569329652714184704",
    "file": "tungsten_ui_bracket.gif"
  },
  {
    "name": "tungsten_ui_harvest",
    "label": "Ui Harvest",
    "animated": true,
    "discordTag": "<a:tungsten_ui_harvest:1569329661148930230>",
    "id": "1569329661148930230",
    "file": "tungsten_ui_harvest.gif"
  },
  {
    "name": "tungsten_ui_plant",
    "label": "Ui Plant",
    "animated": true,
    "discordTag": "<a:tungsten_ui_plant:1569329669503717397>",
    "id": "1569329669503717397",
    "file": "tungsten_ui_plant.gif"
  },
  {
    "name": "tungsten_ui_toggle_off",
    "label": "Ui Toggle Off",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
    "id": "1569329677187678368",
    "file": "tungsten_ui_toggle_off.gif"
  },
  {
    "name": "tungsten_ui_toggle_on",
    "label": "Ui Toggle On",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
    "id": "1569329685110849576",
    "file": "tungsten_ui_toggle_on.gif"
  },
  {
    "name": "tungsten_ui_trade",
    "label": "Ui Trade",
    "animated": true,
    "discordTag": "<a:tungsten_ui_trade:1569329692899680408>",
    "id": "1569329692899680408",
    "file": "tungsten_ui_trade.gif"
  },
  {
    "name": "tungsten_ui_water",
    "label": "Ui Water",
    "animated": true,
    "discordTag": "<a:tungsten_ui_water:1569329701409915022>",
    "id": "1569329701409915022",
    "file": "tungsten_ui_water.gif"
  },
  {
    "name": "tungsten_ui_wizard_back",
    "label": "Ui Wizard Back",
    "animated": true,
    "discordTag": "<a:tungsten_ui_wizard_back:1569329709613850625>",
    "id": "1569329709613850625",
    "file": "tungsten_ui_wizard_back.gif"
  },
  {
    "name": "tungsten_ui_wizard_finish",
    "label": "Ui Wizard Finish",
    "animated": true,
    "discordTag": "<a:tungsten_ui_wizard_finish:1569329717243412595>",
    "id": "1569329717243412595",
    "file": "tungsten_ui_wizard_finish.gif"
  },
  {
    "name": "tungsten_ui_wizard_next",
    "label": "Ui Wizard Next",
    "animated": true,
    "discordTag": "<a:tungsten_ui_wizard_next:1569329725405536328>",
    "id": "1569329725405536328",
    "file": "tungsten_ui_wizard_next.gif"
  },
  {
    "name": "tungsten_watchlist",
    "label": "Watchlist",
    "animated": true,
    "discordTag": "<a:tungsten_watchlist:1569329733303541801>",
    "id": "1569329733303541801",
    "file": "tungsten_watchlist.gif"
  },
  {
    "name": "tungsten_webhook",
    "label": "Webhook",
    "animated": true,
    "discordTag": "<a:tungsten_webhook:1569329741150949488>",
    "id": "1569329741150949488",
    "file": "tungsten_webhook.gif"
  },
  {
    "name": "tungsten_welcomescreen",
    "label": "Welcomescreen",
    "animated": true,
    "discordTag": "<a:tungsten_welcomescreen:1569329748486787085>",
    "id": "1569329748486787085",
    "file": "tungsten_welcomescreen.gif"
  },
  {
    "name": "tungsten_whois",
    "label": "Whois",
    "animated": true,
    "discordTag": "<a:tungsten_whois:1569329756657160402>",
    "id": "1569329756657160402",
    "file": "tungsten_whois.gif"
  },
  {
    "name": "tungsten_wordcount",
    "label": "Wordcount",
    "animated": true,
    "discordTag": "<a:tungsten_wordcount:1569329764508893246>",
    "id": "1569329764508893246",
    "file": "tungsten_wordcount.gif"
  },
  {
    "name": "tungsten_workflow",
    "label": "Workflow",
    "animated": true,
    "discordTag": "<a:tungsten_workflow:1569329772520018061>",
    "id": "1569329772520018061",
    "file": "tungsten_workflow.gif"
  },
  {
    "name": "tungsten_worldclock",
    "label": "Worldclock",
    "animated": true,
    "discordTag": "<a:tungsten_worldclock:1569329780229275668>",
    "id": "1569329780229275668",
    "file": "tungsten_worldclock.gif"
  },
  {
    "name": "tungsten_an_mitigation",
    "label": "An Mitigation",
    "animated": true,
    "discordTag": "<a:tungsten_an_ban:1567232483743895684>",
    "id": "1567232483743895684",
    "file": "tungsten_an_ban.gif"
  },
  {
    "name": "tungsten_cmd_verification",
    "label": "Cmd Verification",
    "animated": true,
    "discordTag": "<a:tungsten_an_standard:1567233029233967106>",
    "id": "1567233029233967106",
    "file": "tungsten_an_standard.gif"
  },
  {
    "name": "tungsten_ui_integrity",
    "label": "Ui Integrity",
    "animated": true,
    "discordTag": "<a:tungsten_ui_complete_verify:1567243101477806101>",
    "id": "1567243101477806101",
    "file": "tungsten_ui_complete_verify.gif"
  },
  {
    "name": "custom_emoji_1",
    "label": "Custom Emoji 1",
    "animated": true,
    "discordTag": "<a:custom_emoji_1:1567244083447996537>",
    "id": "1567244083447996537",
    "file": "tungsten_ui_n1.gif"
  },
  {
    "name": "custom_emoji_2",
    "label": "Custom Emoji 2",
    "animated": true,
    "discordTag": "<a:custom_emoji_2:1567244128704659548>",
    "id": "1567244128704659548",
    "file": "tungsten_ui_n2.gif"
  },
  {
    "name": "custom_emoji_3",
    "label": "Custom Emoji 3",
    "animated": true,
    "discordTag": "<a:custom_emoji_3:1567244152553603203>",
    "id": "1567244152553603203",
    "file": "tungsten_ui_n3.gif"
  },
  {
    "name": "shield_cyber",
    "label": "Shield Cyber",
    "animated": true,
    "discordTag": "<a:tungsten_cat_security:1567234156075683940>",
    "id": "1567234156075683940",
    "file": "tungsten_cat_security.gif"
  },
  {
    "name": "ticket_anim",
    "label": "Ticket Anim",
    "animated": true,
    "discordTag": "<a:tungsten_cat_tickets:1567234238737031290>",
    "id": "1567234238737031290",
    "file": "tungsten_cat_tickets.gif"
  },
  {
    "name": "volume_up_anim",
    "label": "Volume Up Anim",
    "animated": true,
    "discordTag": "<a:tungsten_cat_media:1567233959207764080>",
    "id": "1567233959207764080",
    "file": "tungsten_cat_media.gif"
  },
  {
    "name": "chart_anim",
    "label": "Chart Anim",
    "animated": true,
    "discordTag": "<a:tungsten_cat_logging:1567233934490738860>",
    "id": "1567233934490738860",
    "file": "tungsten_cat_logging.gif"
  },
  {
    "name": "crowned",
    "label": "Crowned",
    "animated": true,
    "discordTag": "<a:tungsten_cat_roles:1567234100975378512>",
    "id": "1567234100975378512",
    "file": "tungsten_cat_roles.gif"
  },
  {
    "name": "toggle_on",
    "label": "Toggle On",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
    "id": "1569329685110849576",
    "file": "tungsten_ui_toggle_on.gif"
  },
  {
    "name": "toggle_off",
    "label": "Toggle Off",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
    "id": "1569329677187678368",
    "file": "tungsten_ui_toggle_off.gif"
  },
  {
    "name": "ui_toggle_on",
    "label": "Ui Toggle On",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
    "id": "1569329685110849576",
    "file": "tungsten_ui_toggle_on.gif"
  },
  {
    "name": "ui_toggle_off",
    "label": "Ui Toggle Off",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
    "id": "1569329677187678368",
    "file": "tungsten_ui_toggle_off.gif"
  },
  {
    "name": "on",
    "label": "On",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
    "id": "1569329685110849576",
    "file": "tungsten_ui_toggle_on.gif"
  },
  {
    "name": "off",
    "label": "Off",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
    "id": "1569329677187678368",
    "file": "tungsten_ui_toggle_off.gif"
  },
  {
    "name": "enable",
    "label": "Enable",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
    "id": "1569329685110849576",
    "file": "tungsten_ui_toggle_on.gif"
  },
  {
    "name": "disable",
    "label": "Disable",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
    "id": "1569329677187678368",
    "file": "tungsten_ui_toggle_off.gif"
  },
  {
    "name": "enabled",
    "label": "Enabled",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_on:1569329685110849576>",
    "id": "1569329685110849576",
    "file": "tungsten_ui_toggle_on.gif"
  },
  {
    "name": "disabled",
    "label": "Disabled",
    "animated": true,
    "discordTag": "<a:tungsten_ui_toggle_off:1569329677187678368>",
    "id": "1569329677187678368",
    "file": "tungsten_ui_toggle_off.gif"
  },
  {
    "name": "server_doctor",
    "label": "Server Doctor",
    "animated": true,
    "discordTag": "<a:tungsten_serverdoctor:1569329568471457898>",
    "id": "1569329568471457898",
    "file": "tungsten_serverdoctor.gif"
  },
  {
    "name": "doctor",
    "label": "Doctor",
    "animated": true,
    "discordTag": "<a:tungsten_serverdoctor:1569329568471457898>",
    "id": "1569329568471457898",
    "file": "tungsten_serverdoctor.gif"
  },
  {
    "name": "watchlist",
    "label": "Watchlist",
    "animated": true,
    "discordTag": "<a:tungsten_watchlist:1569329733303541801>",
    "id": "1569329733303541801",
    "file": "tungsten_watchlist.gif"
  },
  {
    "name": "lockdown",
    "label": "Lockdown",
    "animated": true,
    "discordTag": "<a:tungsten_lockdown:1569329429174296697>",
    "id": "1569329429174296697",
    "file": "tungsten_lockdown.gif"
  }
];

// Direct Name to ID mapping
const IDS = {
  "tungsten_alarm": "1567229471474585682",
  "tungsten_an_arm": "1567232430908244079",
  "tungsten_an_backup_roles": "1567232464970322071",
  "tungsten_an_ban": "1567232483743895684",
  "tungsten_an_bot": "1567232510893490216",
  "tungsten_an_caps": "1567232530988662824",
  "tungsten_an_channel_create": "1567232575855005736",
  "tungsten_an_channel_delete": "1567232594930696262",
  "tungsten_an_disarm": "1567232635237834762",
  "tungsten_an_everyone": "1567232659715793068",
  "tungsten_an_ghostping": "1567232680020672664",
  "tungsten_an_integrity": "1567232702690623490",
  "tungsten_an_invite": "1567232720126607421",
  "tungsten_an_join_flood": "1567232740041031831",
  "tungsten_an_kick": "1567232757330083940",
  "tungsten_an_limits": "1567232774367092797",
  "tungsten_an_link": "1567232798299922585",
  "tungsten_an_lockdown": "1567232816406732850",
  "tungsten_an_lockdown_lift": "1567232833670488064",
  "tungsten_an_logs": "1567232852200923149",
  "tungsten_an_mention": "1567232877584715970",
  "tungsten_an_nsfw": "1567232895830196495",
  "tungsten_an_punish": "1567232919984939141",
  "tungsten_an_raid": "1567232943435292972",
  "tungsten_an_role_create": "1567232961181384745",
  "tungsten_an_role_delete": "1567232979569483776",
  "tungsten_an_spam": "1567233007415197823",
  "tungsten_an_standard": "1567233029233967106",
  "tungsten_an_strict": "1567233050260021398",
  "tungsten_an_ultra": "1567233073005731872",
  "tungsten_an_webhook": "1567233087388262422",
  "tungsten_anger": "1567233100776218734",
  "tungsten_arrow_left": "1567233111601844267",
  "tungsten_arrow_right": "1567233126143361135",
  "tungsten_arrow_small": "1567233140357988574",
  "tungsten_atm": "1567233228350300292",
  "tungsten_bank": "1567233290656677924",
  "tungsten_bell": "1567233316925612173",
  "tungsten_bell_slash": "1567233400996106260",
  "tungsten_bolt": "1567233430570405968",
  "tungsten_bomb": "1567233448945385502",
  "tungsten_book": "1567233482499948606",
  "tungsten_boot": "1567233502418575501",
  "tungsten_bot": "1567233522635247781",
  "tungsten_brain": "1567233547272454144",
  "tungsten_briefcase": "1567233568596295821",
  "tungsten_bullet": "1567233589949497434",
  "tungsten_cabinet": "1567233617489297548",
  "tungsten_calendar": "1567233642554458154",
  "tungsten_cash": "1567233665082200267",
  "tungsten_castle": "1567233687332982844",
  "tungsten_cat_automation": "1567233718861435011",
  "tungsten_cat_backups": "1567233747567251666",
  "tungsten_cat_channels": "1567233777024110652",
  "tungsten_cat_economy": "1567233807822618735",
  "tungsten_cat_fun": "1567233835035402350",
  "tungsten_cat_giveaways": "1567233867637588015",
  "tungsten_cat_leaderboards": "1567233900366008430",
  "tungsten_cat_logging": "1567233934490738860",
  "tungsten_cat_media": "1567233959207764080",
  "tungsten_cat_moderation": "1567233980523225148",
  "tungsten_cat_owner": "1567234022927638649",
  "tungsten_cat_premium": "1567234059510223029",
  "tungsten_cat_roles": "1567234100975378512",
  "tungsten_cat_security": "1567234156075683940",
  "tungsten_cat_tickets": "1567234238737031290",
  "tungsten_cat_utility": "1567234274183217304",
  "tungsten_cat_welcomer": "1567234301869822153",
  "tungsten_cat_whitelist": "1567234327970848848",
  "tungsten_chart": "1567234342701367357",
  "tungsten_chat": "1567234399450177665",
  "tungsten_cherry": "1567234489682362439",
  "tungsten_circle_green": "1567234524512002088",
  "tungsten_circle_red": "1567234546586353686",
  "tungsten_circle_white": "1567234561799233547",
  "tungsten_circle_yellow": "1567234580690501693",
  "tungsten_clapper": "1567234599262879815",
  "tungsten_clipboard": "1567234610176204900",
  "tungsten_clock": "1567234623216554118",
  "tungsten_close": "1567234632905138206",
  "tungsten_cmd_8ball": "1567234645140181082",
  "tungsten_cmd_addemoji": "1567234657026707537",
  "tungsten_cmd_afk": "1567234668347260938",
  "tungsten_cmd_anaudit": "1567234683937497259",
  "tungsten_cmd_anmode": "1567234697556271327",
  "tungsten_cmd_antighostping": "1567234715549835435",
  "tungsten_cmd_antinuke": "1567234734726316142",
  "tungsten_cmd_antiraid": "1567234763755102373",
  "tungsten_cmd_auditlog": "1567234776841195712",
  "tungsten_cmd_automod": "1567234793022689290",
  "tungsten_cmd_autoreact": "1567234807379922944",
  "tungsten_cmd_autoresponder": "1567234819992330240",
  "tungsten_cmd_autorole": "1567234834504482948",
  "tungsten_cmd_avatar": "1567234845363540139",
  "tungsten_cmd_backup": "1567234860119236649",
  "tungsten_cmd_balance": "1567234874736250981",
  "tungsten_cmd_ban": "1567234887503585321",
  "tungsten_cmd_banpanel": "1567234900233552055",
  "tungsten_cmd_botinfo": "1567234914867224616",
  "tungsten_cmd_cases": "1567234927450390658",
  "tungsten_cmd_celmod": "1567234939886370929",
  "tungsten_cmd_channelinfo": "1567234953803210806",
  "tungsten_cmd_cleanup": "1567234967203745988",
  "tungsten_cmd_clearwarns": "1567234980797612133",
  "tungsten_cmd_cm": "1567234994768715806",
  "tungsten_cmd_coinflip": "1567235008547258368",
  "tungsten_cmd_componentsv2": "1567235021910315069",
  "tungsten_cmd_connect4": "1567235052243517541",
  "tungsten_cmd_customcmd": "1567235065107452015",
  "tungsten_cmd_customrole": "1567235078654791690",
  "tungsten_cmd_daily": "1567235093611675650",
  "tungsten_cmd_database": "1567235125513687152",
  "tungsten_cmd_deleteemoji": "1567235155574267935",
  "tungsten_cmd_deposit": "1567235175472041994",
  "tungsten_cmd_duty": "1567235200541528074",
  "tungsten_cmd_emergency": "1567235226504134656",
  "tungsten_cmd_emojilist": "1567235260012298260",
  "tungsten_cmd_emojipack": "1567235282489839766",
  "tungsten_cmd_emojiserver": "1567235306711818290",
  "tungsten_cmd_extraowner": "1567235342850064407",
  "tungsten_cmd_gif": "1567235366665326693",
  "tungsten_cmd_giveaway": "1567235389226352785",
  "tungsten_cmd_giverole": "1567235411615678545",
  "tungsten_cmd_help": "1567235431567724626",
  "tungsten_cmd_hide": "1567235456494731295",
  "tungsten_cmd_inrole": "1567235483904249897",
  "tungsten_cmd_investigate": "1567235510517375127",
  "tungsten_cmd_invite": "1567235535573885110",
  "tungsten_cmd_joke": "1567235558705598494",
  "tungsten_cmd_kick": "1567235578293129256",
  "tungsten_cmd_kickpanel": "1567235599557984417",
  "tungsten_cmd_leaderboard": "1567235635331473509",
  "tungsten_cmd_leave": "1567235657783447573",
  "tungsten_cmd_levels": "1567235696920371301",
  "tungsten_cmd_lock": "1567235715983609857",
  "tungsten_cmd_lockpanel": "1567235752344035459",
  "tungsten_cmd_membercount": "1567235784182857868",
  "tungsten_cmd_meme": "1567235815833337940",
  "tungsten_cmd_modpanel": "1567235859063906364",
  "tungsten_cmd_modrolepanel": "1567235913829056616",
  "tungsten_cmd_mute": "1567235956644253696",
  "tungsten_cmd_mutepanel": "1567235994359562391",
  "tungsten_cmd_nightmode": "1567236036550074390",
  "tungsten_cmd_noprefix": "1567236069643132972",
  "tungsten_cmd_npmanager": "1567236115197591596",
  "tungsten_cmd_nuke": "1567236137746169887",
  "tungsten_cmd_ownerpanel": "1567236155634622514",
  "tungsten_cmd_panel": "1567236187700338759",
  "tungsten_cmd_panic": "1567236213897822388",
  "tungsten_cmd_pay": "1567236244205867130",
  "tungsten_cmd_ping": "1567236300271255715",
  "tungsten_cmd_pings": "1567236330038235206",
  "tungsten_cmd_prefix": "1567236353924792524",
  "tungsten_cmd_premium": "1567236385734139966",
  "tungsten_cmd_premiummanager": "1567236418634252458",
  "tungsten_cmd_profile": "1567236443917525154",
  "tungsten_cmd_purge": "1567236474280083516",
  "tungsten_cmd_purgepanel": "1567236525425430749",
  "tungsten_cmd_reactionrole": "1567236559248429167",
  "tungsten_cmd_removerole": "1567236636641599548",
  "tungsten_cmd_rob": "1567236704203571431",
  "tungsten_cmd_roleinfo": "1567236816225046629",
  "tungsten_cmd_roll": "1567236993287725196",
  "tungsten_cmd_rps": "1567237016662577224",
  "tungsten_cmd_securityscore": "1567237039135400067",
  "tungsten_cmd_serverinfo": "1567237069502287923",
  "tungsten_cmd_sethomevc": "1567237101341380720",
  "tungsten_cmd_ship": "1567237143049539777",
  "tungsten_cmd_slots": "1567237210565120220",
  "tungsten_cmd_slowmode": "1567237253061804164",
  "tungsten_cmd_snipe": "1567237311106777210",
  "tungsten_cmd_softban": "1567237338374086719",
  "tungsten_cmd_stats": "1567237361664925757",
  "tungsten_cmd_stickymessage": "1567237387925454968",
  "tungsten_cmd_support": "1567237424843591770",
  "tungsten_cmd_ticket": "1567237476173619345",
  "tungsten_cmd_trivia": "1567237570192998610",
  "tungsten_cmd_unban": "1567237654230208743",
  "tungsten_cmd_unhide": "1567237716330946600",
  "tungsten_cmd_unlock": "1567237734299467886",
  "tungsten_cmd_unmute": "1567237746697961612",
  "tungsten_cmd_unwhitelist": "1567237762376273990",
  "tungsten_cmd_uptime": "1567237782605398036",
  "tungsten_cmd_userinfo": "1567237805266964481",
  "tungsten_cmd_vanityguard": "1567237826154602613",
  "tungsten_cmd_vcrole": "1567237847486832640",
  "tungsten_cmd_vcstatus": "1567237869133635628",
  "tungsten_cmd_voice": "1567237893590753360",
  "tungsten_cmd_voicemod": "1567237946053099530",
  "tungsten_cmd_warn": "1567238033705799771",
  "tungsten_cmd_warnings": "1567238062759739435",
  "tungsten_cmd_warnpanel": "1567238091708702792",
  "tungsten_cmd_welcome": "1567238123807842346",
  "tungsten_cmd_whitelist": "1567238164991451146",
  "tungsten_cmd_whitelisted": "1567238207295455329",
  "tungsten_cmd_withdraw": "1567238237108310077",
  "tungsten_cmd_work": "1567238276161601567",
  "tungsten_coin": "1567238316967985244",
  "tungsten_crown": "1567238355463176334",
  "tungsten_crystal": "1567238398400532571",
  "tungsten_dancer": "1567238442092601424",
  "tungsten_database": "1567238475684651168",
  "tungsten_diamond_small": "1567238516855939283",
  "tungsten_dice": "1567238580827328582",
  "tungsten_door": "1567238621432643794",
  "tungsten_drama": "1567238681557991474",
  "tungsten_eightball": "1567238723995967638",
  "tungsten_error": "1567238753284653106",
  "tungsten_explosion": "1567238834343911554",
  "tungsten_eye": "1567238862042833088",
  "tungsten_eye_slash": "1567238896612282430",
  "tungsten_eyes": "1567238923913011254",
  "tungsten_face_angry": "1567238949284618291",
  "tungsten_face_cool": "1567238977264685118",
  "tungsten_face_crazy": "1567239007463669832",
  "tungsten_face_cry": "1567239031735980053",
  "tungsten_face_devil": "1567239058327871564",
  "tungsten_face_flushed": "1567239086484357130",
  "tungsten_face_grin": "1567239115089514536",
  "tungsten_face_laugh": "1567239143048613900",
  "tungsten_face_love": "1567239175110140056",
  "tungsten_face_melting": "1567239201269743827",
  "tungsten_face_pleading": "1567239233788448939",
  "tungsten_face_scared": "1567239267774763038",
  "tungsten_face_sleep": "1567239295914213548",
  "tungsten_face_smile": "1567239325941375126",
  "tungsten_face_surprised": "1567239358975582248",
  "tungsten_face_wink": "1567239380244897846",
  "tungsten_fist": "1567239431444897892",
  "tungsten_flag_chequered": "1567239507135307972",
  "tungsten_flag_white": "1567239547769589771",
  "tungsten_folder": "1567239623145558046",
  "tungsten_folder_open": "1567239652501495988",
  "tungsten_foot": "1567239740942458880",
  "tungsten_frame": "1567239867983863889",
  "tungsten_gamepad": "1567239909985616063",
  "tungsten_gear": "1567239932970406012",
  "tungsten_gem": "1567239960837357759",
  "tungsten_gem_flower": "1567239998779031595",
  "tungsten_ghost": "1567240021692518512",
  "tungsten_gift": "1567240042563244072",
  "tungsten_globe": "1567240068253622433",
  "tungsten_grapes": "1567240092739833866",
  "tungsten_gun": "1567240119612874822",
  "tungsten_hammer": "1567240140277944350",
  "tungsten_hands_up": "1567240175594250302",
  "tungsten_handshake": "1567240195646951494",
  "tungsten_headphones": "1567240226789785730",
  "tungsten_heart": "1567240255680155718",
  "tungsten_heart_broken": "1567240285053001738",
  "tungsten_heart_orange": "1567240324336582743",
  "tungsten_heart_sparkle": "1567240386659885106",
  "tungsten_heart_yellow": "1567240422068068529",
  "tungsten_hearts": "1567240511670976552",
  "tungsten_home": "1567240545661620387",
  "tungsten_hourglass": "1567240660702986281",
  "tungsten_id": "1567240689048355008",
  "tungsten_inbox": "1567240785219289108",
  "tungsten_infinity": "1567240813895745626",
  "tungsten_info": "1567240890748248084",
  "tungsten_key": "1567240907684581492",
  "tungsten_keycap_ten": "1567240934599688303",
  "tungsten_keylock": "1567240958075084951",
  "tungsten_knife": "1567240975758270495",
  "tungsten_lemon": "1567240998231343184",
  "tungsten_link": "1567241025813086210",
  "tungsten_loading": "1567241050567876698",
  "tungsten_lock": "1567241079030550668",
  "tungsten_mailbox": "1567241098009509949",
  "tungsten_medal_bronze": "1567241129030582403",
  "tungsten_medal_gold": "1567241163453366472",
  "tungsten_medal_silver": "1567241205409128649",
  "tungsten_memo": "1567241226577780957",
  "tungsten_mic": "1567241257862832189",
  "tungsten_minus": "1567241276057849856",
  "tungsten_money_wings": "1567241294408061024",
  "tungsten_moneybag": "1567241334698541109",
  "tungsten_monitor": "1567241360984121485",
  "tungsten_moon": "1567241385021673674",
  "tungsten_music": "1567241425328939110",
  "tungsten_mute": "1567241451992121647",
  "tungsten_nametag": "1567241539082526760",
  "tungsten_ninja": "1567241598260093050",
  "tungsten_notepad": "1567241681911152733",
  "tungsten_package": "1567241719177543862",
  "tungsten_palette": "1567241748613169344",
  "tungsten_party": "1567241769593339988",
  "tungsten_person": "1567241792150175834",
  "tungsten_pin": "1567241810114379987",
  "tungsten_plane": "1567241829538336884",
  "tungsten_plus": "1567241846453833840",
  "tungsten_point": "1567241861293408391",
  "tungsten_question": "1567241882080116776",
  "tungsten_refresh": "1567241907116187658",
  "tungsten_rice": "1567241928603336724",
  "tungsten_ring": "1567241949461618768",
  "tungsten_rocket": "1567241971804798976",
  "tungsten_satellite": "1567241994928005137",
  "tungsten_save": "1567242015283085507",
  "tungsten_scales": "1567242041098895521",
  "tungsten_scroll": "1567242059708899381",
  "tungsten_search": "1567242081167216771",
  "tungsten_shield": "1567242104923627574",
  "tungsten_shrug": "1567242138323001384",
  "tungsten_siren": "1567242157725712555",
  "tungsten_skull": "1567242182836883486",
  "tungsten_slots": "1567242206266527956",
  "tungsten_sound": "1567242242127568958",
  "tungsten_sparkle": "1567242264311369839",
  "tungsten_star": "1567242331785138238",
  "tungsten_stop": "1567242365335511121",
  "tungsten_stopwatch": "1567242453562687558",
  "tungsten_success": "1567242523468890274",
  "tungsten_sun": "1567242622701932604",
  "tungsten_sweep": "1567242656281657414",
  "tungsten_swords": "1567242677819277352",
  "tungsten_tag": "1567242698904047691",
  "tungsten_target": "1567242733997789205",
  "tungsten_terminal": "1567242755040878664",
  "tungsten_tick": "1567242779908636802",
  "tungsten_ticket": "1567242811961770155",
  "tungsten_tools": "1567242831834124431",
  "tungsten_tooth": "1567242851480375296",
  "tungsten_top": "1567242867846680718",
  "tungsten_trash": "1567242891276062872",
  "tungsten_trophy": "1567242918446501939",
  "tungsten_tv": "1567242943197224960",
  "tungsten_ui_appoint": "1567242963359375450",
  "tungsten_ui_assign": "1567242984397742250",
  "tungsten_ui_backup_db": "1567243012629729341",
  "tungsten_ui_channel_tools": "1567243046951854130",
  "tungsten_ui_check_rank": "1567243080464335058",
  "tungsten_ui_complete_verify": "1567243101477806101",
  "tungsten_ui_d10m": "1567243132008136765",
  "tungsten_ui_d1d": "1567243179269423157",
  "tungsten_ui_d1h": "1567243251767971951",
  "tungsten_ui_d1w": "1567243278917836991",
  "tungsten_ui_d5m": "1567243350279725106",
  "tungsten_ui_daily_usage": "1567243371603296270",
  "tungsten_ui_disable_all": "1567243443338485862",
  "tungsten_ui_disconnect": "1567243506072682706",
  "tungsten_ui_dismiss": "1567243549555036200",
  "tungsten_ui_dm_test": "1567243572002951178",
  "tungsten_ui_edit_nick": "1567243591686823967",
  "tungsten_ui_enable_all": "1567243610716508202",
  "tungsten_ui_events": "1567243642094092323",
  "tungsten_ui_forfeit": "1567243664613314610",
  "tungsten_ui_hide": "1567243688143487107",
  "tungsten_ui_hide_vc": "1567243710075371651",
  "tungsten_ui_install": "1567243737363386509",
  "tungsten_ui_invite_admin": "1567243760079741052",
  "tungsten_ui_invite_std": "1567243779495305246",
  "tungsten_ui_join_support": "1567243801343299704",
  "tungsten_ui_jump": "1567243825028538530",
  "tungsten_ui_lb_history": "1567243859229147236",
  "tungsten_ui_leveling": "1567243886294737016",
  "tungsten_ui_list": "1567243909707604059",
  "tungsten_ui_lock_vc": "1567243939503931611",
  "tungsten_ui_lockdown": "1567243966150082580",
  "tungsten_ui_manage": "1567243992435920926",
  "tungsten_ui_mute_all": "1567244037264506951",
  "tungsten_ui_n1": "1567244083447996537",
  "tungsten_ui_n2": "1567244128704659548",
  "tungsten_ui_n3": "1567244152553603203",
  "tungsten_ui_n4": "1567244239912575056",
  "tungsten_ui_n5": "1567244324213755965",
  "tungsten_ui_n6": "1567244344866639972",
  "tungsten_ui_n7": "1567244425057411202",
  "tungsten_ui_off": "1567244478178402347",
  "tungsten_ui_on": "1567244543546630266",
  "tungsten_ui_open": "1567244565159743488",
  "tungsten_ui_overview": "1567244587137769573",
  "tungsten_ui_p10": "1567244612081553568",
  "tungsten_ui_p100": "1567244632121671763",
  "tungsten_ui_p25": "1567244653416161343",
  "tungsten_ui_p50": "1567244676057006090",
  "tungsten_ui_paper": "1567244704989454378",
  "tungsten_ui_perks": "1567244732160147549",
  "tungsten_ui_presets": "1567244762405150832",
  "tungsten_ui_pulse": "1567244779249729658",
  "tungsten_ui_purge_all": "1567244800946606170",
  "tungsten_ui_purge_bots": "1567244820274225244",
  "tungsten_ui_quickpunish": "1567244834576801813",
  "tungsten_ui_quit": "1567244850779258981",
  "tungsten_ui_rank": "1567244880005038184",
  "tungsten_ui_redeem": "1567244905896616090",
  "tungsten_ui_remove_timeout": "1567244927346155600",
  "tungsten_ui_reset": "1567244948041113621",
  "tungsten_ui_revoke": "1567244971436679319",
  "tungsten_ui_rock": "1567244992609517809",
  "tungsten_ui_role_add": "1567245019587411968",
  "tungsten_ui_role_remove": "1567245052009255103",
  "tungsten_ui_roles_nick": "1567245091091910751",
  "tungsten_ui_rules": "1567245114655641680",
  "tungsten_ui_scissors": "1567245155545780484",
  "tungsten_ui_score": "1567245190027288709",
  "tungsten_ui_server_status": "1567245256393625651",
  "tungsten_ui_telemetry": "1567245337486434404",
  "tungsten_ui_test": "1567245407510204466",
  "tungsten_ui_ticket_close": "1567245485117284382",
  "tungsten_ui_ticket_open": "1567245507699675276",
  "tungsten_ui_timeout": "1567245550204493934",
  "tungsten_ui_unassign": "1567245588783829053",
  "tungsten_ui_undo": "1567245669087846462",
  "tungsten_ui_unhide": "1567245749073354832",
  "tungsten_ui_unhide_vc": "1567245826777161792",
  "tungsten_ui_unlock_vc": "1567245856430620782",
  "tungsten_ui_unlockdown": "1567245990556209313",
  "tungsten_ui_unmute_all": "1567246118520365256",
  "tungsten_ui_user_add": "1567246155706929205",
  "tungsten_ui_user_remove": "1567246253467631616",
  "tungsten_ui_verbose": "1567246309063397548",
  "tungsten_ui_view_emojis": "1567246384980168774",
  "tungsten_ui_welcome_test": "1567246433336299654",
  "tungsten_unlock": "1567246515209117968",
  "tungsten_user": "1567246556778995802",
  "tungsten_users": "1567246628606185502",
  "tungsten_warn": "1567246685082746940",
  "tungsten_wave": "1567246763822158004",
  "tungsten_wind": "1567246820927602838",
  "tungsten_zzz": "1567246871834132673",
  "tungsten_achievements": "1569329206842757271",
  "tungsten_an_stage_abuse": "1569329214539173898",
  "tungsten_analytics": "1569329222265208843",
  "tungsten_auction": "1569329230435590194",
  "tungsten_autoslow": "1569329238585118783",
  "tungsten_autothread": "1569329247355539606",
  "tungsten_bans": "1569329255693688853",
  "tungsten_calc": "1569329263469924396",
  "tungsten_cat_clans": "1569329279701884928",
  "tungsten_cat_modmail": "1569329287692296213",
  "tungsten_cat_pets": "1569329296542011563",
  "tungsten_cat_social": "1569329304196747418",
  "tungsten_clan": "1569329312774103142",
  "tungsten_convert": "1569329320802000956",
  "tungsten_countdown": "1569329328838152274",
  "tungsten_discordpoll": "1569329347171590216",
  "tungsten_encode": "1569329355111538820",
  "tungsten_event": "1569329363038638090",
  "tungsten_evidence": "1569329371850874921",
  "tungsten_farm": "1569329379975364628",
  "tungsten_feed": "1569329388053467276",
  "tungsten_forum": "1569329396278370374",
  "tungsten_guildsettings": "1569329404558184562",
  "tungsten_integrations": "1569329413110239292",
  "tungsten_linkedroles": "1569329421352046592",
  "tungsten_lockdown": "1569329429174296697",
  "tungsten_macro": "1569329438586310706",
  "tungsten_marriage": "1569329446325063725",
  "tungsten_modmail": "1569329454952611870",
  "tungsten_nativeautomod": "1569329462921920542",
  "tungsten_npm": "1569329471373320352",
  "tungsten_onboarding": "1569329479325585481",
  "tungsten_override": "1569329487794143305",
  "tungsten_panelbuilder": "1569329495809200158",
  "tungsten_password": "1569329504994852944",
  "tungsten_pet": "1569329513408634920",
  "tungsten_pokemon": "1569329520966635581",
  "tungsten_policy": "1569329528851927131",
  "tungsten_presence": "1569329536875888711",
  "tungsten_profile": "1569329544819900416",
  "tungsten_quests": "1569329552453533827",
  "tungsten_rep": "1569329560917381213",
  "tungsten_serverdoctor": "1569329568471457898",
  "tungsten_setup": "1569329576490836098",
  "tungsten_snowflake": "1569329585487614105",
  "tungsten_soundboard": "1569329593561780354",
  "tungsten_stage": "1569329601971224720",
  "tungsten_thread": "1569329618928930846",
  "tungsten_tournament": "1569329627057487993",
  "tungsten_trade": "1569329634733072495",
  "tungsten_ui_bid": "1569329642609836154",
  "tungsten_ui_bracket": "1569329652714184704",
  "tungsten_ui_harvest": "1569329661148930230",
  "tungsten_ui_plant": "1569329669503717397",
  "tungsten_ui_toggle_off": "1569329677187678368",
  "tungsten_ui_toggle_on": "1569329685110849576",
  "tungsten_ui_trade": "1569329692899680408",
  "tungsten_ui_water": "1569329701409915022",
  "tungsten_ui_wizard_back": "1569329709613850625",
  "tungsten_ui_wizard_finish": "1569329717243412595",
  "tungsten_ui_wizard_next": "1569329725405536328",
  "tungsten_watchlist": "1569329733303541801",
  "tungsten_webhook": "1569329741150949488",
  "tungsten_welcomescreen": "1569329748486787085",
  "tungsten_whois": "1569329756657160402",
  "tungsten_wordcount": "1569329764508893246",
  "tungsten_workflow": "1569329772520018061",
  "tungsten_worldclock": "1569329780229275668",
  "tungsten_an_mitigation": "1567232483743895684",
  "tungsten_cmd_verification": "1567233029233967106",
  "tungsten_ui_integrity": "1567243101477806101",
  "custom_emoji_1": "1567244083447996537",
  "custom_emoji_2": "1567244128704659548",
  "custom_emoji_3": "1567244152553603203",
  "shield_cyber": "1567234156075683940",
  "ticket_anim": "1567234238737031290",
  "volume_up_anim": "1567233959207764080",
  "chart_anim": "1567233934490738860",
  "crowned": "1567234100975378512",
  "toggle_on": "1569329685110849576",
  "toggle_off": "1569329677187678368",
  "ui_toggle_on": "1569329685110849576",
  "ui_toggle_off": "1569329677187678368",
  "on": "1569329685110849576",
  "off": "1569329677187678368",
  "enable": "1569329685110849576",
  "disable": "1569329677187678368",
  "enabled": "1569329685110849576",
  "disabled": "1569329677187678368",
  "server_doctor": "1569329568471457898",
  "doctor": "1569329568471457898",
  "watchlist": "1569329733303541801",
  "lockdown": "1569329429174296697",
  "tungsten_check": "1567234479968223323",
  "tungsten_menu": "1567241240167190588",
  "tungsten_delete": "1567242891276062872",
  "tungsten_voice": "1567242242127568958",
  "tungsten_sparkles": "1567242264311369839",
  "tungsten_commands": "1567241240167190588",
  "tungsten_zap": "1567233430570405968"
};
const EMOJI_IDS = IDS;

// Name to Tag mapping

// Backward compatibility for celestia_ keys
for (const [k, v] of Object.entries(IDS)) {
  if (k.startsWith("tungsten_")) {
    IDS["celestia_" + k.slice(9)] = v;
  }
}
const E = {
  "tungsten_alarm": "<a:tungsten_alarm:1567229471474585682>",
  "tungsten_an_arm": "<a:tungsten_an_arm:1567232430908244079>",
  "tungsten_an_backup_roles": "<a:tungsten_an_backup_roles:1567232464970322071>",
  "tungsten_an_ban": "<a:tungsten_an_ban:1567232483743895684>",
  "tungsten_an_bot": "<a:tungsten_an_bot:1567232510893490216>",
  "tungsten_an_caps": "<a:tungsten_an_caps:1567232530988662824>",
  "tungsten_an_channel_create": "<a:tungsten_an_channel_create:1567232575855005736>",
  "tungsten_an_channel_delete": "<a:tungsten_an_channel_delete:1567232594930696262>",
  "tungsten_an_disarm": "<a:tungsten_an_disarm:1567232635237834762>",
  "tungsten_an_everyone": "<a:tungsten_an_everyone:1567232659715793068>",
  "tungsten_an_ghostping": "<a:tungsten_an_ghostping:1567232680020672664>",
  "tungsten_an_integrity": "<a:tungsten_an_integrity:1567232702690623490>",
  "tungsten_an_invite": "<a:tungsten_an_invite:1567232720126607421>",
  "tungsten_an_join_flood": "<a:tungsten_an_join_flood:1567232740041031831>",
  "tungsten_an_kick": "<a:tungsten_an_kick:1567232757330083940>",
  "tungsten_an_limits": "<a:tungsten_an_limits:1567232774367092797>",
  "tungsten_an_link": "<a:tungsten_an_link:1567232798299922585>",
  "tungsten_an_lockdown": "<a:tungsten_an_lockdown:1567232816406732850>",
  "tungsten_an_lockdown_lift": "<a:tungsten_an_lockdown_lift:1567232833670488064>",
  "tungsten_an_logs": "<a:tungsten_an_logs:1567232852200923149>",
  "tungsten_an_mention": "<a:tungsten_an_mention:1567232877584715970>",
  "tungsten_an_nsfw": "<a:tungsten_an_nsfw:1567232895830196495>",
  "tungsten_an_punish": "<a:tungsten_an_punish:1567232919984939141>",
  "tungsten_an_raid": "<a:tungsten_an_raid:1567232943435292972>",
  "tungsten_an_role_create": "<a:tungsten_an_role_create:1567232961181384745>",
  "tungsten_an_role_delete": "<a:tungsten_an_role_delete:1567232979569483776>",
  "tungsten_an_spam": "<a:tungsten_an_spam:1567233007415197823>",
  "tungsten_an_standard": "<a:tungsten_an_standard:1567233029233967106>",
  "tungsten_an_strict": "<a:tungsten_an_strict:1567233050260021398>",
  "tungsten_an_ultra": "<a:tungsten_an_ultra:1567233073005731872>",
  "tungsten_an_webhook": "<a:tungsten_an_webhook:1567233087388262422>",
  "tungsten_anger": "<a:tungsten_anger:1567233100776218734>",
  "tungsten_arrow_left": "<a:tungsten_arrow_left:1567233111601844267>",
  "tungsten_arrow_right": "<a:tungsten_arrow_right:1567233126143361135>",
  "tungsten_arrow_small": "<a:tungsten_arrow_small:1567233140357988574>",
  "tungsten_atm": "<a:tungsten_atm:1567233228350300292>",
  "tungsten_bank": "<a:tungsten_bank:1567233290656677924>",
  "tungsten_bell": "<a:tungsten_bell:1567233316925612173>",
  "tungsten_bell_slash": "<a:tungsten_bell_slash:1567233400996106260>",
  "tungsten_bolt": "<a:tungsten_bolt:1567233430570405968>",
  "tungsten_bomb": "<a:tungsten_bomb:1567233448945385502>",
  "tungsten_book": "<a:tungsten_book:1567233482499948606>",
  "tungsten_boot": "<a:tungsten_boot:1567233502418575501>",
  "tungsten_bot": "<a:tungsten_bot:1567233522635247781>",
  "tungsten_brain": "<a:tungsten_brain:1567233547272454144>",
  "tungsten_briefcase": "<a:tungsten_briefcase:1567233568596295821>",
  "tungsten_bullet": "<a:tungsten_bullet:1567233589949497434>",
  "tungsten_cabinet": "<a:tungsten_cabinet:1567233617489297548>",
  "tungsten_calendar": "<a:tungsten_calendar:1567233642554458154>",
  "tungsten_cash": "<a:tungsten_cash:1567233665082200267>",
  "tungsten_castle": "<a:tungsten_castle:1567233687332982844>",
  "tungsten_cat_automation": "<a:tungsten_cat_automation:1567233718861435011>",
  "tungsten_cat_backups": "<a:tungsten_cat_backups:1567233747567251666>",
  "tungsten_cat_channels": "<a:tungsten_cat_channels:1567233777024110652>",
  "tungsten_cat_economy": "<a:tungsten_cat_economy:1567233807822618735>",
  "tungsten_cat_fun": "<a:tungsten_cat_fun:1567233835035402350>",
  "tungsten_cat_giveaways": "<a:tungsten_cat_giveaways:1567233867637588015>",
  "tungsten_cat_leaderboards": "<a:tungsten_cat_leaderboards:1567233900366008430>",
  "tungsten_cat_logging": "<a:tungsten_cat_logging:1567233934490738860>",
  "tungsten_cat_media": "<a:tungsten_cat_media:1567233959207764080>",
  "tungsten_cat_moderation": "<a:tungsten_cat_moderation:1567233980523225148>",
  "tungsten_cat_owner": "<a:tungsten_cat_owner:1567234022927638649>",
  "tungsten_cat_premium": "<a:tungsten_cat_premium:1567234059510223029>",
  "tungsten_cat_roles": "<a:tungsten_cat_roles:1567234100975378512>",
  "tungsten_cat_security": "<a:tungsten_cat_security:1567234156075683940>",
  "tungsten_cat_tickets": "<a:tungsten_cat_tickets:1567234238737031290>",
  "tungsten_cat_utility": "<a:tungsten_cat_utility:1567234274183217304>",
  "tungsten_cat_welcomer": "<a:tungsten_cat_welcomer:1567234301869822153>",
  "tungsten_cat_whitelist": "<a:tungsten_cat_whitelist:1567234327970848848>",
  "tungsten_chart": "<a:tungsten_chart:1567234342701367357>",
  "tungsten_chat": "<a:tungsten_chat:1567234399450177665>",
  "tungsten_cherry": "<a:tungsten_cherry:1567234489682362439>",
  "tungsten_circle_green": "<a:tungsten_circle_green:1567234524512002088>",
  "tungsten_circle_red": "<a:tungsten_circle_red:1567234546586353686>",
  "tungsten_circle_white": "<a:tungsten_circle_white:1567234561799233547>",
  "tungsten_circle_yellow": "<a:tungsten_circle_yellow:1567234580690501693>",
  "tungsten_clapper": "<a:tungsten_clapper:1567234599262879815>",
  "tungsten_clipboard": "<a:tungsten_clipboard:1567234610176204900>",
  "tungsten_clock": "<a:tungsten_clock:1567234623216554118>",
  "tungsten_close": "<a:tungsten_close:1567234632905138206>",
  "tungsten_cmd_8ball": "<a:tungsten_cmd_8ball:1567234645140181082>",
  "tungsten_cmd_addemoji": "<a:tungsten_cmd_addemoji:1567234657026707537>",
  "tungsten_cmd_afk": "<a:tungsten_cmd_afk:1567234668347260938>",
  "tungsten_cmd_anaudit": "<a:tungsten_cmd_anaudit:1567234683937497259>",
  "tungsten_cmd_anmode": "<a:tungsten_cmd_anmode:1567234697556271327>",
  "tungsten_cmd_antighostping": "<a:tungsten_cmd_antighostping:1567234715549835435>",
  "tungsten_cmd_antinuke": "<a:tungsten_cmd_antinuke:1567234734726316142>",
  "tungsten_cmd_antiraid": "<a:tungsten_cmd_antiraid:1567234763755102373>",
  "tungsten_cmd_auditlog": "<a:tungsten_cmd_auditlog:1567234776841195712>",
  "tungsten_cmd_automod": "<a:tungsten_cmd_automod:1567234793022689290>",
  "tungsten_cmd_autoreact": "<a:tungsten_cmd_autoreact:1567234807379922944>",
  "tungsten_cmd_autoresponder": "<a:tungsten_cmd_autoresponder:1567234819992330240>",
  "tungsten_cmd_autorole": "<a:tungsten_cmd_autorole:1567234834504482948>",
  "tungsten_cmd_avatar": "<a:tungsten_cmd_avatar:1567234845363540139>",
  "tungsten_cmd_backup": "<a:tungsten_cmd_backup:1567234860119236649>",
  "tungsten_cmd_balance": "<a:tungsten_cmd_balance:1567234874736250981>",
  "tungsten_cmd_ban": "<a:tungsten_cmd_ban:1567234887503585321>",
  "tungsten_cmd_banpanel": "<a:tungsten_cmd_banpanel:1567234900233552055>",
  "tungsten_cmd_botinfo": "<a:tungsten_cmd_botinfo:1567234914867224616>",
  "tungsten_cmd_cases": "<a:tungsten_cmd_cases:1567234927450390658>",
  "tungsten_cmd_celmod": "<a:tungsten_cmd_celmod:1567234939886370929>",
  "tungsten_cmd_channelinfo": "<a:tungsten_cmd_channelinfo:1567234953803210806>",
  "tungsten_cmd_cleanup": "<a:tungsten_cmd_cleanup:1567234967203745988>",
  "tungsten_cmd_clearwarns": "<a:tungsten_cmd_clearwarns:1567234980797612133>",
  "tungsten_cmd_cm": "<a:tungsten_cmd_cm:1567234994768715806>",
  "tungsten_cmd_coinflip": "<a:tungsten_cmd_coinflip:1567235008547258368>",
  "tungsten_cmd_componentsv2": "<a:tungsten_cmd_componentsv2:1567235021910315069>",
  "tungsten_cmd_connect4": "<a:tungsten_cmd_connect4:1567235052243517541>",
  "tungsten_cmd_customcmd": "<a:tungsten_cmd_customcmd:1567235065107452015>",
  "tungsten_cmd_customrole": "<a:tungsten_cmd_customrole:1567235078654791690>",
  "tungsten_cmd_daily": "<a:tungsten_cmd_daily:1567235093611675650>",
  "tungsten_cmd_database": "<a:tungsten_cmd_database:1567235125513687152>",
  "tungsten_cmd_deleteemoji": "<a:tungsten_cmd_deleteemoji:1567235155574267935>",
  "tungsten_cmd_deposit": "<a:tungsten_cmd_deposit:1567235175472041994>",
  "tungsten_cmd_duty": "<a:tungsten_cmd_duty:1567235200541528074>",
  "tungsten_cmd_emergency": "<a:tungsten_cmd_emergency:1567235226504134656>",
  "tungsten_cmd_emojilist": "<a:tungsten_cmd_emojilist:1567235260012298260>",
  "tungsten_cmd_emojipack": "<a:tungsten_cmd_emojipack:1567235282489839766>",
  "tungsten_cmd_emojiserver": "<a:tungsten_cmd_emojiserver:1567235306711818290>",
  "tungsten_cmd_extraowner": "<a:tungsten_cmd_extraowner:1567235342850064407>",
  "tungsten_cmd_gif": "<a:tungsten_cmd_gif:1567235366665326693>",
  "tungsten_cmd_giveaway": "<a:tungsten_cmd_giveaway:1567235389226352785>",
  "tungsten_cmd_giverole": "<a:tungsten_cmd_giverole:1567235411615678545>",
  "tungsten_cmd_help": "<a:tungsten_cmd_help:1567235431567724626>",
  "tungsten_cmd_hide": "<a:tungsten_cmd_hide:1567235456494731295>",
  "tungsten_cmd_inrole": "<a:tungsten_cmd_inrole:1567235483904249897>",
  "tungsten_cmd_investigate": "<a:tungsten_cmd_investigate:1567235510517375127>",
  "tungsten_cmd_invite": "<a:tungsten_cmd_invite:1567235535573885110>",
  "tungsten_cmd_joke": "<a:tungsten_cmd_joke:1567235558705598494>",
  "tungsten_cmd_kick": "<a:tungsten_cmd_kick:1567235578293129256>",
  "tungsten_cmd_kickpanel": "<a:tungsten_cmd_kickpanel:1567235599557984417>",
  "tungsten_cmd_leaderboard": "<a:tungsten_cmd_leaderboard:1567235635331473509>",
  "tungsten_cmd_leave": "<a:tungsten_cmd_leave:1567235657783447573>",
  "tungsten_cmd_levels": "<a:tungsten_cmd_levels:1567235696920371301>",
  "tungsten_cmd_lock": "<a:tungsten_cmd_lock:1567235715983609857>",
  "tungsten_cmd_lockpanel": "<a:tungsten_cmd_lockpanel:1567235752344035459>",
  "tungsten_cmd_membercount": "<a:tungsten_cmd_membercount:1567235784182857868>",
  "tungsten_cmd_meme": "<a:tungsten_cmd_meme:1567235815833337940>",
  "tungsten_cmd_modpanel": "<a:tungsten_cmd_modpanel:1567235859063906364>",
  "tungsten_cmd_modrolepanel": "<a:tungsten_cmd_modrolepanel:1567235913829056616>",
  "tungsten_cmd_mute": "<a:tungsten_cmd_mute:1567235956644253696>",
  "tungsten_cmd_mutepanel": "<a:tungsten_cmd_mutepanel:1567235994359562391>",
  "tungsten_cmd_nightmode": "<a:tungsten_cmd_nightmode:1567236036550074390>",
  "tungsten_cmd_noprefix": "<a:tungsten_cmd_noprefix:1567236069643132972>",
  "tungsten_cmd_npmanager": "<a:tungsten_cmd_npmanager:1567236115197591596>",
  "tungsten_cmd_nuke": "<a:tungsten_cmd_nuke:1567236137746169887>",
  "tungsten_cmd_ownerpanel": "<a:tungsten_cmd_ownerpanel:1567236155634622514>",
  "tungsten_cmd_panel": "<a:tungsten_cmd_panel:1567236187700338759>",
  "tungsten_cmd_panic": "<a:tungsten_cmd_panic:1567236213897822388>",
  "tungsten_cmd_pay": "<a:tungsten_cmd_pay:1567236244205867130>",
  "tungsten_cmd_ping": "<a:tungsten_cmd_ping:1567236300271255715>",
  "tungsten_cmd_pings": "<a:tungsten_cmd_pings:1567236330038235206>",
  "tungsten_cmd_prefix": "<a:tungsten_cmd_prefix:1567236353924792524>",
  "tungsten_cmd_premium": "<a:tungsten_cmd_premium:1567236385734139966>",
  "tungsten_cmd_premiummanager": "<a:tungsten_cmd_premiummanager:1567236418634252458>",
  "tungsten_cmd_profile": "<a:tungsten_cmd_profile:1567236443917525154>",
  "tungsten_cmd_purge": "<a:tungsten_cmd_purge:1567236474280083516>",
  "tungsten_cmd_purgepanel": "<a:tungsten_cmd_purgepanel:1567236525425430749>",
  "tungsten_cmd_reactionrole": "<a:tungsten_cmd_reactionrole:1567236559248429167>",
  "tungsten_cmd_removerole": "<a:tungsten_cmd_removerole:1567236636641599548>",
  "tungsten_cmd_rob": "<a:tungsten_cmd_rob:1567236704203571431>",
  "tungsten_cmd_roleinfo": "<a:tungsten_cmd_roleinfo:1567236816225046629>",
  "tungsten_cmd_roll": "<a:tungsten_cmd_roll:1567236993287725196>",
  "tungsten_cmd_rps": "<a:tungsten_cmd_rps:1567237016662577224>",
  "tungsten_cmd_securityscore": "<a:tungsten_cmd_securityscore:1567237039135400067>",
  "tungsten_cmd_serverinfo": "<a:tungsten_cmd_serverinfo:1567237069502287923>",
  "tungsten_cmd_sethomevc": "<a:tungsten_cmd_sethomevc:1567237101341380720>",
  "tungsten_cmd_ship": "<a:tungsten_cmd_ship:1567237143049539777>",
  "tungsten_cmd_slots": "<a:tungsten_cmd_slots:1567237210565120220>",
  "tungsten_cmd_slowmode": "<a:tungsten_cmd_slowmode:1567237253061804164>",
  "tungsten_cmd_snipe": "<a:tungsten_cmd_snipe:1567237311106777210>",
  "tungsten_cmd_softban": "<a:tungsten_cmd_softban:1567237338374086719>",
  "tungsten_cmd_stats": "<a:tungsten_cmd_stats:1567237361664925757>",
  "tungsten_cmd_stickymessage": "<a:tungsten_cmd_stickymessage:1567237387925454968>",
  "tungsten_cmd_support": "<a:tungsten_cmd_support:1567237424843591770>",
  "tungsten_cmd_ticket": "<a:tungsten_cmd_ticket:1567237476173619345>",
  "tungsten_cmd_trivia": "<a:tungsten_cmd_trivia:1567237570192998610>",
  "tungsten_cmd_unban": "<a:tungsten_cmd_unban:1567237654230208743>",
  "tungsten_cmd_unhide": "<a:tungsten_cmd_unhide:1567237716330946600>",
  "tungsten_cmd_unlock": "<a:tungsten_cmd_unlock:1567237734299467886>",
  "tungsten_cmd_unmute": "<a:tungsten_cmd_unmute:1567237746697961612>",
  "tungsten_cmd_unwhitelist": "<a:tungsten_cmd_unwhitelist:1567237762376273990>",
  "tungsten_cmd_uptime": "<a:tungsten_cmd_uptime:1567237782605398036>",
  "tungsten_cmd_userinfo": "<a:tungsten_cmd_userinfo:1567237805266964481>",
  "tungsten_cmd_vanityguard": "<a:tungsten_cmd_vanityguard:1567237826154602613>",
  "tungsten_cmd_vcrole": "<a:tungsten_cmd_vcrole:1567237847486832640>",
  "tungsten_cmd_vcstatus": "<a:tungsten_cmd_vcstatus:1567237869133635628>",
  "tungsten_cmd_voice": "<a:tungsten_cmd_voice:1567237893590753360>",
  "tungsten_cmd_voicemod": "<a:tungsten_cmd_voicemod:1567237946053099530>",
  "tungsten_cmd_warn": "<a:tungsten_cmd_warn:1567238033705799771>",
  "tungsten_cmd_warnings": "<a:tungsten_cmd_warnings:1567238062759739435>",
  "tungsten_cmd_warnpanel": "<a:tungsten_cmd_warnpanel:1567238091708702792>",
  "tungsten_cmd_welcome": "<a:tungsten_cmd_welcome:1567238123807842346>",
  "tungsten_cmd_whitelist": "<a:tungsten_cmd_whitelist:1567238164991451146>",
  "tungsten_cmd_whitelisted": "<a:tungsten_cmd_whitelisted:1567238207295455329>",
  "tungsten_cmd_withdraw": "<a:tungsten_cmd_withdraw:1567238237108310077>",
  "tungsten_cmd_work": "<a:tungsten_cmd_work:1567238276161601567>",
  "tungsten_coin": "<a:tungsten_coin:1567238316967985244>",
  "tungsten_crown": "<a:tungsten_crown:1567238355463176334>",
  "tungsten_crystal": "<a:tungsten_crystal:1567238398400532571>",
  "tungsten_dancer": "<a:tungsten_dancer:1567238442092601424>",
  "tungsten_database": "<a:tungsten_database:1567238475684651168>",
  "tungsten_diamond_small": "<a:tungsten_diamond_small:1567238516855939283>",
  "tungsten_dice": "<a:tungsten_dice:1567238580827328582>",
  "tungsten_door": "<a:tungsten_door:1567238621432643794>",
  "tungsten_drama": "<a:tungsten_drama:1567238681557991474>",
  "tungsten_eightball": "<a:tungsten_eightball:1567238723995967638>",
  "tungsten_error": "<a:tungsten_error:1567238753284653106>",
  "tungsten_explosion": "<a:tungsten_explosion:1567238834343911554>",
  "tungsten_eye": "<a:tungsten_eye:1567238862042833088>",
  "tungsten_eye_slash": "<a:tungsten_eye_slash:1567238896612282430>",
  "tungsten_eyes": "<a:tungsten_eyes:1567238923913011254>",
  "tungsten_face_angry": "<a:tungsten_face_angry:1567238949284618291>",
  "tungsten_face_cool": "<a:tungsten_face_cool:1567238977264685118>",
  "tungsten_face_crazy": "<a:tungsten_face_crazy:1567239007463669832>",
  "tungsten_face_cry": "<a:tungsten_face_cry:1567239031735980053>",
  "tungsten_face_devil": "<a:tungsten_face_devil:1567239058327871564>",
  "tungsten_face_flushed": "<a:tungsten_face_flushed:1567239086484357130>",
  "tungsten_face_grin": "<a:tungsten_face_grin:1567239115089514536>",
  "tungsten_face_laugh": "<a:tungsten_face_laugh:1567239143048613900>",
  "tungsten_face_love": "<a:tungsten_face_love:1567239175110140056>",
  "tungsten_face_melting": "<a:tungsten_face_melting:1567239201269743827>",
  "tungsten_face_pleading": "<a:tungsten_face_pleading:1567239233788448939>",
  "tungsten_face_scared": "<a:tungsten_face_scared:1567239267774763038>",
  "tungsten_face_sleep": "<a:tungsten_face_sleep:1567239295914213548>",
  "tungsten_face_smile": "<a:tungsten_face_smile:1567239325941375126>",
  "tungsten_face_surprised": "<a:tungsten_face_surprised:1567239358975582248>",
  "tungsten_face_wink": "<a:tungsten_face_wink:1567239380244897846>",
  "tungsten_fist": "<a:tungsten_fist:1567239431444897892>",
  "tungsten_flag_chequered": "<a:tungsten_flag_chequered:1567239507135307972>",
  "tungsten_flag_white": "<a:tungsten_flag_white:1567239547769589771>",
  "tungsten_folder": "<a:tungsten_folder:1567239623145558046>",
  "tungsten_folder_open": "<a:tungsten_folder_open:1567239652501495988>",
  "tungsten_foot": "<a:tungsten_foot:1567239740942458880>",
  "tungsten_frame": "<a:tungsten_frame:1567239867983863889>",
  "tungsten_gamepad": "<a:tungsten_gamepad:1567239909985616063>",
  "tungsten_gear": "<a:tungsten_gear:1567239932970406012>",
  "tungsten_gem": "<a:tungsten_gem:1567239960837357759>",
  "tungsten_gem_flower": "<a:tungsten_gem_flower:1567239998779031595>",
  "tungsten_ghost": "<a:tungsten_ghost:1567240021692518512>",
  "tungsten_gift": "<a:tungsten_gift:1567240042563244072>",
  "tungsten_globe": "<a:tungsten_globe:1567240068253622433>",
  "tungsten_grapes": "<a:tungsten_grapes:1567240092739833866>",
  "tungsten_gun": "<a:tungsten_gun:1567240119612874822>",
  "tungsten_hammer": "<a:tungsten_hammer:1567240140277944350>",
  "tungsten_hands_up": "<a:tungsten_hands_up:1567240175594250302>",
  "tungsten_handshake": "<a:tungsten_handshake:1567240195646951494>",
  "tungsten_headphones": "<a:tungsten_headphones:1567240226789785730>",
  "tungsten_heart": "<a:tungsten_heart:1567240255680155718>",
  "tungsten_heart_broken": "<a:tungsten_heart_broken:1567240285053001738>",
  "tungsten_heart_orange": "<a:tungsten_heart_orange:1567240324336582743>",
  "tungsten_heart_sparkle": "<a:tungsten_heart_sparkle:1567240386659885106>",
  "tungsten_heart_yellow": "<a:tungsten_heart_yellow:1567240422068068529>",
  "tungsten_hearts": "<a:tungsten_hearts:1567240511670976552>",
  "tungsten_home": "<a:tungsten_home:1567240545661620387>",
  "tungsten_hourglass": "<a:tungsten_hourglass:1567240660702986281>",
  "tungsten_id": "<a:tungsten_id:1567240689048355008>",
  "tungsten_inbox": "<a:tungsten_inbox:1567240785219289108>",
  "tungsten_infinity": "<a:tungsten_infinity:1567240813895745626>",
  "tungsten_info": "<a:tungsten_info:1567240890748248084>",
  "tungsten_key": "<a:tungsten_key:1567240907684581492>",
  "tungsten_keycap_ten": "<a:tungsten_keycap_ten:1567240934599688303>",
  "tungsten_keylock": "<a:tungsten_keylock:1567240958075084951>",
  "tungsten_knife": "<a:tungsten_knife:1567240975758270495>",
  "tungsten_lemon": "<a:tungsten_lemon:1567240998231343184>",
  "tungsten_link": "<a:tungsten_link:1567241025813086210>",
  "tungsten_loading": "<a:tungsten_loading:1567241050567876698>",
  "tungsten_lock": "<a:tungsten_lock:1567241079030550668>",
  "tungsten_mailbox": "<a:tungsten_mailbox:1567241098009509949>",
  "tungsten_medal_bronze": "<a:tungsten_medal_bronze:1567241129030582403>",
  "tungsten_medal_gold": "<a:tungsten_medal_gold:1567241163453366472>",
  "tungsten_medal_silver": "<a:tungsten_medal_silver:1567241205409128649>",
  "tungsten_memo": "<a:tungsten_memo:1567241226577780957>",
  "tungsten_mic": "<a:tungsten_mic:1567241257862832189>",
  "tungsten_minus": "<a:tungsten_minus:1567241276057849856>",
  "tungsten_money_wings": "<a:tungsten_money_wings:1567241294408061024>",
  "tungsten_moneybag": "<a:tungsten_moneybag:1567241334698541109>",
  "tungsten_monitor": "<a:tungsten_monitor:1567241360984121485>",
  "tungsten_moon": "<a:tungsten_moon:1567241385021673674>",
  "tungsten_music": "<a:tungsten_music:1567241425328939110>",
  "tungsten_mute": "<a:tungsten_mute:1567241451992121647>",
  "tungsten_nametag": "<a:tungsten_nametag:1567241539082526760>",
  "tungsten_ninja": "<a:tungsten_ninja:1567241598260093050>",
  "tungsten_notepad": "<a:tungsten_notepad:1567241681911152733>",
  "tungsten_package": "<a:tungsten_package:1567241719177543862>",
  "tungsten_palette": "<a:tungsten_palette:1567241748613169344>",
  "tungsten_party": "<a:tungsten_party:1567241769593339988>",
  "tungsten_person": "<a:tungsten_person:1567241792150175834>",
  "tungsten_pin": "<a:tungsten_pin:1567241810114379987>",
  "tungsten_plane": "<a:tungsten_plane:1567241829538336884>",
  "tungsten_plus": "<a:tungsten_plus:1567241846453833840>",
  "tungsten_point": "<a:tungsten_point:1567241861293408391>",
  "tungsten_question": "<a:tungsten_question:1567241882080116776>",
  "tungsten_refresh": "<a:tungsten_refresh:1567241907116187658>",
  "tungsten_rice": "<a:tungsten_rice:1567241928603336724>",
  "tungsten_ring": "<a:tungsten_ring:1567241949461618768>",
  "tungsten_rocket": "<a:tungsten_rocket:1567241971804798976>",
  "tungsten_satellite": "<a:tungsten_satellite:1567241994928005137>",
  "tungsten_save": "<a:tungsten_save:1567242015283085507>",
  "tungsten_scales": "<a:tungsten_scales:1567242041098895521>",
  "tungsten_scroll": "<a:tungsten_scroll:1567242059708899381>",
  "tungsten_search": "<a:tungsten_search:1567242081167216771>",
  "tungsten_shield": "<a:tungsten_shield:1567242104923627574>",
  "tungsten_shrug": "<a:tungsten_shrug:1567242138323001384>",
  "tungsten_siren": "<a:tungsten_siren:1567242157725712555>",
  "tungsten_skull": "<a:tungsten_skull:1567242182836883486>",
  "tungsten_slots": "<a:tungsten_slots:1567242206266527956>",
  "tungsten_sound": "<a:tungsten_sound:1567242242127568958>",
  "tungsten_sparkle": "<a:tungsten_sparkle:1567242264311369839>",
  "tungsten_star": "<a:tungsten_star:1567242331785138238>",
  "tungsten_stop": "<a:tungsten_stop:1567242365335511121>",
  "tungsten_stopwatch": "<a:tungsten_stopwatch:1567242453562687558>",
  "tungsten_success": "<a:tungsten_success:1567242523468890274>",
  "tungsten_sun": "<a:tungsten_sun:1567242622701932604>",
  "tungsten_sweep": "<a:tungsten_sweep:1567242656281657414>",
  "tungsten_swords": "<a:tungsten_swords:1567242677819277352>",
  "tungsten_tag": "<a:tungsten_tag:1567242698904047691>",
  "tungsten_target": "<a:tungsten_target:1567242733997789205>",
  "tungsten_terminal": "<a:tungsten_terminal:1567242755040878664>",
  "tungsten_tick": "<a:tungsten_tick:1567242779908636802>",
  "tungsten_ticket": "<a:tungsten_ticket:1567242811961770155>",
  "tungsten_tools": "<a:tungsten_tools:1567242831834124431>",
  "tungsten_tooth": "<a:tungsten_tooth:1567242851480375296>",
  "tungsten_top": "<a:tungsten_top:1567242867846680718>",
  "tungsten_trash": "<a:tungsten_trash:1567242891276062872>",
  "tungsten_trophy": "<a:tungsten_trophy:1567242918446501939>",
  "tungsten_tv": "<a:tungsten_tv:1567242943197224960>",
  "tungsten_ui_appoint": "<a:tungsten_ui_appoint:1567242963359375450>",
  "tungsten_ui_assign": "<a:tungsten_ui_assign:1567242984397742250>",
  "tungsten_ui_backup_db": "<a:tungsten_ui_backup_db:1567243012629729341>",
  "tungsten_ui_channel_tools": "<a:tungsten_ui_channel_tools:1567243046951854130>",
  "tungsten_ui_check_rank": "<a:tungsten_ui_check_rank:1567243080464335058>",
  "tungsten_ui_complete_verify": "<a:tungsten_ui_complete_verify:1567243101477806101>",
  "tungsten_ui_d10m": "<a:tungsten_ui_d10m:1567243132008136765>",
  "tungsten_ui_d1d": "<a:tungsten_ui_d1d:1567243179269423157>",
  "tungsten_ui_d1h": "<a:tungsten_ui_d1h:1567243251767971951>",
  "tungsten_ui_d1w": "<a:tungsten_ui_d1w:1567243278917836991>",
  "tungsten_ui_d5m": "<a:tungsten_ui_d5m:1567243350279725106>",
  "tungsten_ui_daily_usage": "<a:tungsten_ui_daily_usage:1567243371603296270>",
  "tungsten_ui_disable_all": "<a:tungsten_ui_disable_all:1567243443338485862>",
  "tungsten_ui_disconnect": "<a:tungsten_ui_disconnect:1567243506072682706>",
  "tungsten_ui_dismiss": "<a:tungsten_ui_dismiss:1567243549555036200>",
  "tungsten_ui_dm_test": "<a:tungsten_ui_dm_test:1567243572002951178>",
  "tungsten_ui_edit_nick": "<a:tungsten_ui_edit_nick:1567243591686823967>",
  "tungsten_ui_enable_all": "<a:tungsten_ui_enable_all:1567243610716508202>",
  "tungsten_ui_events": "<a:tungsten_ui_events:1567243642094092323>",
  "tungsten_ui_forfeit": "<a:tungsten_ui_forfeit:1567243664613314610>",
  "tungsten_ui_hide": "<a:tungsten_ui_hide:1567243688143487107>",
  "tungsten_ui_hide_vc": "<a:tungsten_ui_hide_vc:1567243710075371651>",
  "tungsten_ui_install": "<a:tungsten_ui_install:1567243737363386509>",
  "tungsten_ui_invite_admin": "<a:tungsten_ui_invite_admin:1567243760079741052>",
  "tungsten_ui_invite_std": "<a:tungsten_ui_invite_std:1567243779495305246>",
  "tungsten_ui_join_support": "<a:tungsten_ui_join_support:1567243801343299704>",
  "tungsten_ui_jump": "<a:tungsten_ui_jump:1567243825028538530>",
  "tungsten_ui_lb_history": "<a:tungsten_ui_lb_history:1567243859229147236>",
  "tungsten_ui_leveling": "<a:tungsten_ui_leveling:1567243886294737016>",
  "tungsten_ui_list": "<a:tungsten_ui_list:1567243909707604059>",
  "tungsten_ui_lock_vc": "<a:tungsten_ui_lock_vc:1567243939503931611>",
  "tungsten_ui_lockdown": "<a:tungsten_ui_lockdown:1567243966150082580>",
  "tungsten_ui_manage": "<a:tungsten_ui_manage:1567243992435920926>",
  "tungsten_ui_mute_all": "<a:tungsten_ui_mute_all:1567244037264506951>",
  "tungsten_ui_n1": "<a:tungsten_ui_n1:1567244083447996537>",
  "tungsten_ui_n2": "<a:tungsten_ui_n2:1567244128704659548>",
  "tungsten_ui_n3": "<a:tungsten_ui_n3:1567244152553603203>",
  "tungsten_ui_n4": "<a:tungsten_ui_n4:1567244239912575056>",
  "tungsten_ui_n5": "<a:tungsten_ui_n5:1567244324213755965>",
  "tungsten_ui_n6": "<a:tungsten_ui_n6:1567244344866639972>",
  "tungsten_ui_n7": "<a:tungsten_ui_n7:1567244425057411202>",
  "tungsten_ui_off": "<a:tungsten_ui_off:1567244478178402347>",
  "tungsten_ui_on": "<a:tungsten_ui_on:1567244543546630266>",
  "tungsten_ui_open": "<a:tungsten_ui_open:1567244565159743488>",
  "tungsten_ui_overview": "<a:tungsten_ui_overview:1567244587137769573>",
  "tungsten_ui_p10": "<a:tungsten_ui_p10:1567244612081553568>",
  "tungsten_ui_p100": "<a:tungsten_ui_p100:1567244632121671763>",
  "tungsten_ui_p25": "<a:tungsten_ui_p25:1567244653416161343>",
  "tungsten_ui_p50": "<a:tungsten_ui_p50:1567244676057006090>",
  "tungsten_ui_paper": "<a:tungsten_ui_paper:1567244704989454378>",
  "tungsten_ui_perks": "<a:tungsten_ui_perks:1567244732160147549>",
  "tungsten_ui_presets": "<a:tungsten_ui_presets:1567244762405150832>",
  "tungsten_ui_pulse": "<a:tungsten_ui_pulse:1567244779249729658>",
  "tungsten_ui_purge_all": "<a:tungsten_ui_purge_all:1567244800946606170>",
  "tungsten_ui_purge_bots": "<a:tungsten_ui_purge_bots:1567244820274225244>",
  "tungsten_ui_quickpunish": "<a:tungsten_ui_quickpunish:1567244834576801813>",
  "tungsten_ui_quit": "<a:tungsten_ui_quit:1567244850779258981>",
  "tungsten_ui_rank": "<a:tungsten_ui_rank:1567244880005038184>",
  "tungsten_ui_redeem": "<a:tungsten_ui_redeem:1567244905896616090>",
  "tungsten_ui_remove_timeout": "<a:tungsten_ui_remove_timeout:1567244927346155600>",
  "tungsten_ui_reset": "<a:tungsten_ui_reset:1567244948041113621>",
  "tungsten_ui_revoke": "<a:tungsten_ui_revoke:1567244971436679319>",
  "tungsten_ui_rock": "<a:tungsten_ui_rock:1567244992609517809>",
  "tungsten_ui_role_add": "<a:tungsten_ui_role_add:1567245019587411968>",
  "tungsten_ui_role_remove": "<a:tungsten_ui_role_remove:1567245052009255103>",
  "tungsten_ui_roles_nick": "<a:tungsten_ui_roles_nick:1567245091091910751>",
  "tungsten_ui_rules": "<a:tungsten_ui_rules:1567245114655641680>",
  "tungsten_ui_scissors": "<a:tungsten_ui_scissors:1567245155545780484>",
  "tungsten_ui_score": "<a:tungsten_ui_score:1567245190027288709>",
  "tungsten_ui_server_status": "<a:tungsten_ui_server_status:1567245256393625651>",
  "tungsten_ui_telemetry": "<a:tungsten_ui_telemetry:1567245337486434404>",
  "tungsten_ui_test": "<a:tungsten_ui_test:1567245407510204466>",
  "tungsten_ui_ticket_close": "<a:tungsten_ui_ticket_close:1567245485117284382>",
  "tungsten_ui_ticket_open": "<a:tungsten_ui_ticket_open:1567245507699675276>",
  "tungsten_ui_timeout": "<a:tungsten_ui_timeout:1567245550204493934>",
  "tungsten_ui_unassign": "<a:tungsten_ui_unassign:1567245588783829053>",
  "tungsten_ui_undo": "<a:tungsten_ui_undo:1567245669087846462>",
  "tungsten_ui_unhide": "<a:tungsten_ui_unhide:1567245749073354832>",
  "tungsten_ui_unhide_vc": "<a:tungsten_ui_unhide_vc:1567245826777161792>",
  "tungsten_ui_unlock_vc": "<a:tungsten_ui_unlock_vc:1567245856430620782>",
  "tungsten_ui_unlockdown": "<a:tungsten_ui_unlockdown:1567245990556209313>",
  "tungsten_ui_unmute_all": "<a:tungsten_ui_unmute_all:1567246118520365256>",
  "tungsten_ui_user_add": "<a:tungsten_ui_user_add:1567246155706929205>",
  "tungsten_ui_user_remove": "<a:tungsten_ui_user_remove:1567246253467631616>",
  "tungsten_ui_verbose": "<a:tungsten_ui_verbose:1567246309063397548>",
  "tungsten_ui_view_emojis": "<a:tungsten_ui_view_emojis:1567246384980168774>",
  "tungsten_ui_welcome_test": "<a:tungsten_ui_welcome_test:1567246433336299654>",
  "tungsten_unlock": "<a:tungsten_unlock:1567246515209117968>",
  "tungsten_user": "<a:tungsten_user:1567246556778995802>",
  "tungsten_users": "<a:tungsten_users:1567246628606185502>",
  "tungsten_warn": "<a:tungsten_warn:1567246685082746940>",
  "tungsten_wave": "<a:tungsten_wave:1567246763822158004>",
  "tungsten_wind": "<a:tungsten_wind:1567246820927602838>",
  "tungsten_zzz": "<a:tungsten_zzz:1567246871834132673>",
  "tungsten_achievements": "<a:tungsten_achievements:1569329206842757271>",
  "tungsten_an_stage_abuse": "<a:tungsten_an_stage_abuse:1569329214539173898>",
  "tungsten_analytics": "<a:tungsten_analytics:1569329222265208843>",
  "tungsten_auction": "<a:tungsten_auction:1569329230435590194>",
  "tungsten_autoslow": "<a:tungsten_autoslow:1569329238585118783>",
  "tungsten_autothread": "<a:tungsten_autothread:1569329247355539606>",
  "tungsten_bans": "<a:tungsten_bans:1569329255693688853>",
  "tungsten_calc": "<a:tungsten_calc:1569329263469924396>",
  "tungsten_cat_clans": "<a:tungsten_cat_clans:1569329279701884928>",
  "tungsten_cat_modmail": "<a:tungsten_cat_modmail:1569329287692296213>",
  "tungsten_cat_pets": "<a:tungsten_cat_pets:1569329296542011563>",
  "tungsten_cat_social": "<a:tungsten_cat_social:1569329304196747418>",
  "tungsten_clan": "<a:tungsten_clan:1569329312774103142>",
  "tungsten_convert": "<a:tungsten_convert:1569329320802000956>",
  "tungsten_countdown": "<a:tungsten_countdown:1569329328838152274>",
  "tungsten_discordpoll": "<a:tungsten_discordpoll:1569329347171590216>",
  "tungsten_encode": "<a:tungsten_encode:1569329355111538820>",
  "tungsten_event": "<a:tungsten_event:1569329363038638090>",
  "tungsten_evidence": "<a:tungsten_evidence:1569329371850874921>",
  "tungsten_farm": "<a:tungsten_farm:1569329379975364628>",
  "tungsten_feed": "<a:tungsten_feed:1569329388053467276>",
  "tungsten_forum": "<a:tungsten_forum:1569329396278370374>",
  "tungsten_guildsettings": "<a:tungsten_guildsettings:1569329404558184562>",
  "tungsten_integrations": "<a:tungsten_integrations:1569329413110239292>",
  "tungsten_linkedroles": "<a:tungsten_linkedroles:1569329421352046592>",
  "tungsten_lockdown": "<a:tungsten_lockdown:1569329429174296697>",
  "tungsten_macro": "<a:tungsten_macro:1569329438586310706>",
  "tungsten_marriage": "<a:tungsten_marriage:1569329446325063725>",
  "tungsten_modmail": "<a:tungsten_modmail:1569329454952611870>",
  "tungsten_nativeautomod": "<a:tungsten_nativeautomod:1569329462921920542>",
  "tungsten_npm": "<a:tungsten_npm:1569329471373320352>",
  "tungsten_onboarding": "<a:tungsten_onboarding:1569329479325585481>",
  "tungsten_override": "<a:tungsten_override:1569329487794143305>",
  "tungsten_panelbuilder": "<a:tungsten_panelbuilder:1569329495809200158>",
  "tungsten_password": "<a:tungsten_password:1569329504994852944>",
  "tungsten_pet": "<a:tungsten_pet:1569329513408634920>",
  "tungsten_pokemon": "<a:tungsten_pokemon:1569329520966635581>",
  "tungsten_policy": "<a:tungsten_policy:1569329528851927131>",
  "tungsten_presence": "<a:tungsten_presence:1569329536875888711>",
  "tungsten_profile": "<a:tungsten_profile:1569329544819900416>",
  "tungsten_quests": "<a:tungsten_quests:1569329552453533827>",
  "tungsten_rep": "<a:tungsten_rep:1569329560917381213>",
  "tungsten_serverdoctor": "<a:tungsten_serverdoctor:1569329568471457898>",
  "tungsten_setup": "<a:tungsten_setup:1569329576490836098>",
  "tungsten_snowflake": "<a:tungsten_snowflake:1569329585487614105>",
  "tungsten_soundboard": "<a:tungsten_soundboard:1569329593561780354>",
  "tungsten_stage": "<a:tungsten_stage:1569329601971224720>",
  "tungsten_thread": "<a:tungsten_thread:1569329618928930846>",
  "tungsten_tournament": "<a:tungsten_tournament:1569329627057487993>",
  "tungsten_trade": "<a:tungsten_trade:1569329634733072495>",
  "tungsten_ui_bid": "<a:tungsten_ui_bid:1569329642609836154>",
  "tungsten_ui_bracket": "<a:tungsten_ui_bracket:1569329652714184704>",
  "tungsten_ui_harvest": "<a:tungsten_ui_harvest:1569329661148930230>",
  "tungsten_ui_plant": "<a:tungsten_ui_plant:1569329669503717397>",
  "tungsten_ui_toggle_off": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "tungsten_ui_toggle_on": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "tungsten_ui_trade": "<a:tungsten_ui_trade:1569329692899680408>",
  "tungsten_ui_water": "<a:tungsten_ui_water:1569329701409915022>",
  "tungsten_ui_wizard_back": "<a:tungsten_ui_wizard_back:1569329709613850625>",
  "tungsten_ui_wizard_finish": "<a:tungsten_ui_wizard_finish:1569329717243412595>",
  "tungsten_ui_wizard_next": "<a:tungsten_ui_wizard_next:1569329725405536328>",
  "tungsten_watchlist": "<a:tungsten_watchlist:1569329733303541801>",
  "tungsten_webhook": "<a:tungsten_webhook:1569329741150949488>",
  "tungsten_welcomescreen": "<a:tungsten_welcomescreen:1569329748486787085>",
  "tungsten_whois": "<a:tungsten_whois:1569329756657160402>",
  "tungsten_wordcount": "<a:tungsten_wordcount:1569329764508893246>",
  "tungsten_workflow": "<a:tungsten_workflow:1569329772520018061>",
  "tungsten_worldclock": "<a:tungsten_worldclock:1569329780229275668>",
  "tungsten_an_mitigation": "<a:tungsten_an_ban:1567232483743895684>",
  "tungsten_cmd_verification": "<a:tungsten_an_standard:1567233029233967106>",
  "tungsten_ui_integrity": "<a:tungsten_ui_complete_verify:1567243101477806101>",
  "custom_emoji_1": "<a:custom_emoji_1:1567244083447996537>",
  "custom_emoji_2": "<a:custom_emoji_2:1567244128704659548>",
  "custom_emoji_3": "<a:custom_emoji_3:1567244152553603203>",
  "shield_cyber": "<a:tungsten_cat_security:1567234156075683940>",
  "ticket_anim": "<a:tungsten_cat_tickets:1567234238737031290>",
  "volume_up_anim": "<a:tungsten_cat_media:1567233959207764080>",
  "chart_anim": "<a:tungsten_cat_logging:1567233934490738860>",
  "crowned": "<a:tungsten_cat_roles:1567234100975378512>",
  "toggle_on": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "toggle_off": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "ui_toggle_on": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "ui_toggle_off": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "on": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "off": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "enable": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "disable": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "enabled": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "disabled": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "server_doctor": "<a:tungsten_serverdoctor:1569329568471457898>",
  "doctor": "<a:tungsten_serverdoctor:1569329568471457898>",
  "watchlist": "<a:tungsten_watchlist:1569329733303541801>",
  "lockdown": "<a:tungsten_lockdown:1569329429174296697>",
  "tungsten_check": "<a:tungsten_check:1567234479968223323>",
  "tungsten_menu": "<a:tungsten_menu:1567241240167190588>",
  "tungsten_delete": "<a:tungsten_trash:1567242891276062872>",
  "tungsten_voice": "<a:tungsten_sound:1567242242127568958>",
  "tungsten_sparkles": "<a:tungsten_sparkle:1567242264311369839>",
  "tungsten_commands": "<a:tungsten_menu:1567241240167190588>",
  "tungsten_zap": "<a:tungsten_bolt:1567233430570405968>"
};

// Semantic / Aliases Map

// Backward compatibility for celestia_ keys
for (const [k, v] of Object.entries(E)) {
  if (k.startsWith("tungsten_")) {
    E["celestia_" + k.slice(9)] = v;
  }
}
const EMOJIS = {
  "MENU": "<a:tungsten_menu:1567241240167190588>",
  "celestia_check": "<a:tungsten_check:1567234479968223323>",
  "celestia_menu": "<a:tungsten_menu:1567241240167190588>",
  "celestia_delete": "<a:tungsten_trash:1567242891276062872>",
  "celestia_voice": "<a:tungsten_sound:1567242242127568958>",
  "celestia_sparkles": "<a:tungsten_sparkle:1567242264311369839>",
  "celestia_commands": "<a:tungsten_menu:1567241240167190588>",
  "celestia_zap": "<a:tungsten_bolt:1567233430570405968>",
  "SUCCESS": "<a:tungsten_success:1567242523468890274>",
  "SUCCESS_ANIMATED": "<a:tungsten_success:1567242523468890274>",
  "CHECK": "<a:tungsten_success:1567242523468890274>",
  "TICK": "<a:tungsten_tick:1567242779908636802>",
  "ERROR": "<a:tungsten_error:1567238753284653106>",
  "CROSS": "<a:tungsten_close:1567234632905138206>",
  "XMARK": "<a:tungsten_close:1567234632905138206>",
  "CLOSE": "<a:tungsten_close:1567234632905138206>",
  "WARNING": "<a:tungsten_warn:1567246685082746940>",
  "WARN": "<a:tungsten_warn:1567246685082746940>",
  "WARN_FLASH": "<a:tungsten_warn:1567246685082746940>",
  "ALERT": "<a:tungsten_siren:1567242157725712555>",
  "SIREN": "<a:tungsten_siren:1567242157725712555>",
  "ALARM": "<a:tungsten_alarm:1567229471474585682>",
  "INFO": "<a:tungsten_info:1567240890748248084>",
  "BADGE": "<a:tungsten_info:1567240890748248084>",
  "LOADING": "<a:tungsten_loading:1567241050567876698>",
  "HOURGLASS": "<a:tungsten_hourglass:1567240660702986281>",
  "TIMER": "<a:tungsten_stopwatch:1567242453562687558>",
  "STOPWATCH": "<a:tungsten_stopwatch:1567242453562687558>",
  "CLOCK": "<a:tungsten_clock:1567234623216554118>",
  "UI_TOGGLE_ON": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "UI_TOGGLE_OFF": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "TOGGLE_ON": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "TOGGLE_OFF": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "ON": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "OFF": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "ENABLED": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "DISABLED": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "SWITCH_ON": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "SWITCH_OFF": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "WATCHLIST": "<a:tungsten_watchlist:1569329733303541801>",
  "SERVER_DOCTOR": "<a:tungsten_serverdoctor:1569329568471457898>",
  "SERVERDOCTOR": "<a:tungsten_serverdoctor:1569329568471457898>",
  "LOCKDOWN": "<a:tungsten_lockdown:1569329429174296697>",
  "CALC": "<a:tungsten_calc:1569329263469924396>",
  "CONVERT": "<a:tungsten_convert:1569329320802000956>",
  "ENCODE": "<a:tungsten_encode:1569329355111538820>",
  "WORDCOUNT": "<a:tungsten_wordcount:1569329764508893246>",
  "CLAN": "<a:tungsten_clan:1569329312774103142>",
  "CLANS": "<a:tungsten_clan:1569329312774103142>",
  "MARRIAGE": "<a:tungsten_marriage:1569329446325063725>",
  "QUESTS": "<a:tungsten_quests:1569329552453533827>",
  "ACHIEVEMENTS": "<a:tungsten_achievements:1569329206842757271>",
  "TRADE": "<a:tungsten_trade:1569329634733072495>",
  "AUCTION": "<a:tungsten_auction:1569329230435590194>",
  "DISCORDPOLL": "<a:tungsten_discordpoll:1569329347171590216>",
  "FORUM": "<a:tungsten_forum:1569329396278370374>",
  "EVENT": "<a:tungsten_event:1569329363038638090>",
  "PET": "<a:tungsten_pet:1569329513408634920>",
  "FARM": "<a:tungsten_farm:1569329379975364628>",
  "WIZARD_NEXT": "<a:tungsten_ui_wizard_next:1569329725405536328>",
  "WIZARD_BACK": "<a:tungsten_ui_wizard_back:1569329709613850625>",
  "WIZARD_FINISH": "<a:tungsten_ui_wizard_finish:1569329717243412595>",
  "STAGE_ABUSE": "<a:tungsten_an_stage_abuse:1569329214539173898>",
  "AUTOSLOW": "<a:tungsten_autoslow:1569329238585118783>",
  "AUTOTHREAD": "<a:tungsten_autothread:1569329247355539606>",
  "EVIDENCE": "<a:tungsten_evidence:1569329371850874921>",
  "PANELBUILDER": "<a:tungsten_panelbuilder:1569329495809200158>",
  "POLICY": "<a:tungsten_policy:1569329528851927131>",
  "SNOWFLAKE": "<a:tungsten_snowflake:1569329585487614105>",
  "SOUNDBOARD": "<a:tungsten_soundboard:1569329593561780354>",
  "TOURNAMENT": "<a:tungsten_tournament:1569329627057487993>",
  "WELCOMESCREEN": "<a:tungsten_welcomescreen:1569329748486787085>",
  "WHOIS": "<a:tungsten_whois:1569329756657160402>",
  "WORKFLOW": "<a:tungsten_workflow:1569329772520018061>",
  "WORLDCLOCK": "<a:tungsten_worldclock:1569329780229275668>",
  "SHIELD": "<a:tungsten_shield:1567242104923627574>",
  "SENTINEL": "<a:tungsten_shield:1567242104923627574>",
  "PROTECT": "<a:tungsten_shield:1567242104923627574>",
  "FIREWALL": "<a:tungsten_shield:1567242104923627574>",
  "GEAR": "<a:tungsten_gear:1567239932970406012>",
  "SETTINGS": "<a:tungsten_gear:1567239932970406012>",
  "TOOLS": "<a:tungsten_tools:1567242831834124431>",
  "BOLT": "<a:tungsten_bolt:1567233430570405968>",
  "ZAP": "<a:tungsten_bolt:1567233430570405968>",
  "CROWN": "<a:tungsten_crown:1567238355463176334>",
  "CROWN2": "<a:tungsten_crown:1567238355463176334>",
  "VIP": "<a:tungsten_crown:1567238355463176334>",
  "SWORDS": "<a:tungsten_swords:1567242677819277352>",
  "HAMMER": "<a:tungsten_hammer:1567240140277944350>",
  "LOCK": "<a:tungsten_lock:1567241079030550668>",
  "UNLOCK": "<a:tungsten_unlock:1567246515209117968>",
  "KEY": "<a:tungsten_key:1567240907684581492>",
  "KEYLOCK": "<a:tungsten_keylock:1567240958075084951>",
  "SWEEP": "<a:tungsten_sweep:1567242656281657414>",
  "REFRESH": "<a:tungsten_refresh:1567241907116187658>",
  "PLUS": "<a:tungsten_plus:1567241846453833840>",
  "MINUS": "<a:tungsten_minus:1567241276057849856>",
  "SEARCH": "<a:tungsten_search:1567242081167216771>",
  "CHART": "<a:tungsten_chart:1567234342701367357>",
  "TERMINAL": "<a:tungsten_terminal:1567242755040878664>",
  "DATABASE": "<a:tungsten_database:1567238475684651168>",
  "DB": "<a:tungsten_database:1567238475684651168>",
  "GLOBE": "<a:tungsten_globe:1567240068253622433>",
  "BOT": "<a:tungsten_bot:1567233522635247781>",
  "USER": "<a:tungsten_user:1567246556778995802>",
  "USERS": "<a:tungsten_users:1567246628606185502>",
  "PEOPLE": "<a:tungsten_person:1567241792150175834>",
  "PERSON": "<a:tungsten_person:1567241792150175834>",
  "HOME": "<a:tungsten_home:1567240545661620387>",
  "ONLINE": "<a:tungsten_circle_green:1567234524512002088>",
  "GREEN_CIRCLE": "<a:tungsten_circle_green:1567234524512002088>",
  "OFFLINE": "<a:tungsten_circle_red:1567234546586353686>",
  "RED_CIRCLE": "<a:tungsten_circle_red:1567234546586353686>",
  "AFK": "<a:tungsten_circle_yellow:1567234580690501693>",
  "YELLOW_CIRCLE": "<a:tungsten_circle_yellow:1567234580690501693>",
  "WHITE_CIRCLE": "<a:tungsten_circle_white:1567234561799233547>",
  "COIN": "<a:tungsten_coin:1567238316967985244>",
  "DIAMOND": "<a:tungsten_diamond_small:1567238516855939283>",
  "GEM": "<a:tungsten_gem:1567239960837357759>",
  "MONEY": "<a:tungsten_cash:1567233665082200267>",
  "CASH": "<a:tungsten_cash:1567233665082200267>",
  "MONEYBAG": "<a:tungsten_moneybag:1567241334698541109>",
  "BANK": "<a:tungsten_bank:1567233290656677924>",
  "ATM": "<a:tungsten_atm:1567233228350300292>",
  "GOLD": "<a:tungsten_medal_gold:1567241163453366472>",
  "SILVER": "<a:tungsten_medal_silver:1567241205409128649>",
  "BRONZE": "<a:tungsten_medal_bronze:1567241129030582403>",
  "TROPHY": "<a:tungsten_trophy:1567242918446501939>",
  "STAR": "<a:tungsten_star:1567242331785138238>",
  "SPARKLE": "<a:tungsten_sparkle:1567242264311369839>",
  "SPARKLES": "<a:tungsten_sparkle:1567242264311369839>",
  "GIFT": "<a:tungsten_gift:1567240042563244072>",
  "GIVEAWAY": "<a:tungsten_cat_giveaways:1567233867637588015>",
  "PARTY": "<a:tungsten_party:1567241769593339988>",
  "ROCKET": "<a:tungsten_rocket:1567241971804798976>",
  "PACKAGE": "<a:tungsten_package:1567241719177543862>",
  "TICKET": "<a:tungsten_ticket:1567242811961770155>",
  "MEMO": "<a:tungsten_memo:1567241226577780957>",
  "DOCUMENT": "<a:tungsten_memo:1567241226577780957>",
  "CLIPBOARD": "<a:tungsten_clipboard:1567234610176204900>",
  "NOTEPAD": "<a:tungsten_notepad:1567241681911152733>",
  "NOTE": "<a:tungsten_notepad:1567241681911152733>",
  "BOOK": "<a:tungsten_book:1567233482499948606>",
  "PIN": "<a:tungsten_pin:1567241810114379987>",
  "TAG": "<a:tungsten_tag:1567242698904047691>",
  "TARGET": "<a:tungsten_target:1567242733997789205>",
  "TRASH": "<a:tungsten_trash:1567242891276062872>",
  "VOLUME_UP": "<a:tungsten_sound:1567242242127568958>",
  "SOUND": "<a:tungsten_sound:1567242242127568958>",
  "SPEAKER": "<a:tungsten_sound:1567242242127568958>",
  "MUTE": "<a:tungsten_mute:1567241451992121647>",
  "MUTED": "<a:tungsten_mute:1567241451992121647>",
  "MUSIC": "<a:tungsten_music:1567241425328939110>",
  "MIC": "<a:tungsten_mic:1567241257862832189>",
  "HEADPHONES": "<a:tungsten_headphones:1567240226789785730>",
  "ARROW_LEFT": "<a:tungsten_arrow_left:1567233111601844267>",
  "ARROW_RIGHT": "<a:tungsten_arrow_right:1567233126143361135>",
  "ARROW_SMALL": "<a:tungsten_arrow_small:1567233140357988574>",
  "PREVIOUS": "<a:tungsten_arrow_left:1567233111601844267>",
  "PREV": "<a:tungsten_arrow_left:1567233111601844267>",
  "NEXT": "<a:tungsten_arrow_right:1567233126143361135>",
  "BULLET": "<a:tungsten_bullet:1567233589949497434>",
  "CAT_SECURITY": "<a:tungsten_cat_security:1567234156075683940>",
  "CAT_MODERATION": "<a:tungsten_cat_moderation:1567233980523225148>",
  "CAT_CHANNELS": "<a:tungsten_cat_channels:1567233777024110652>",
  "CAT_ROLES": "<a:tungsten_cat_roles:1567234100975378512>",
  "CAT_WELCOMER": "<a:tungsten_cat_welcomer:1567234301869822153>",
  "CAT_AUTOMATION": "<a:tungsten_cat_automation:1567233718861435011>",
  "CAT_ECONOMY": "<a:tungsten_cat_economy:1567233807822618735>",
  "CAT_FUN": "<a:tungsten_cat_fun:1567233835035402350>",
  "CAT_GIVEAWAYS": "<a:tungsten_cat_giveaways:1567233867637588015>",
  "CAT_TICKETS": "<a:tungsten_cat_tickets:1567234238737031290>",
  "CAT_BACKUPS": "<a:tungsten_cat_backups:1567233747567251666>",
  "CAT_LOGGING": "<a:tungsten_cat_logging:1567233934490738860>",
  "CAT_MEDIA": "<a:tungsten_cat_media:1567233959207764080>",
  "CAT_LEADERBOARDS": "<a:tungsten_cat_leaderboards:1567233900366008430>",
  "CAT_WHITELIST": "<a:tungsten_cat_whitelist:1567234327970848848>",
  "CAT_UTILITY": "<a:tungsten_cat_utility:1567234274183217304>",
  "CAT_PREMIUM": "<a:tungsten_cat_premium:1567234059510223029>",
  "CAT_OWNER": "<a:tungsten_cat_owner:1567234022927638649>",
  "CELESTIA_ALARM": "<a:tungsten_alarm:1567229471474585682>",
  "CELESTIA_AN_ARM": "<a:tungsten_an_arm:1567232430908244079>",
  "AN_ARM": "<a:tungsten_an_arm:1567232430908244079>",
  "CELESTIA_AN_BACKUP_ROLES": "<a:tungsten_an_backup_roles:1567232464970322071>",
  "AN_BACKUP_ROLES": "<a:tungsten_an_backup_roles:1567232464970322071>",
  "CELESTIA_AN_BAN": "<a:tungsten_an_ban:1567232483743895684>",
  "AN_BAN": "<a:tungsten_an_ban:1567232483743895684>",
  "CELESTIA_AN_BOT": "<a:tungsten_an_bot:1567232510893490216>",
  "AN_BOT": "<a:tungsten_an_bot:1567232510893490216>",
  "CELESTIA_AN_CAPS": "<a:tungsten_an_caps:1567232530988662824>",
  "AN_CAPS": "<a:tungsten_an_caps:1567232530988662824>",
  "CELESTIA_AN_CHANNEL_CREATE": "<a:tungsten_an_channel_create:1567232575855005736>",
  "AN_CHANNEL_CREATE": "<a:tungsten_an_channel_create:1567232575855005736>",
  "CELESTIA_AN_CHANNEL_DELETE": "<a:tungsten_an_channel_delete:1567232594930696262>",
  "AN_CHANNEL_DELETE": "<a:tungsten_an_channel_delete:1567232594930696262>",
  "CELESTIA_AN_DISARM": "<a:tungsten_an_disarm:1567232635237834762>",
  "AN_DISARM": "<a:tungsten_an_disarm:1567232635237834762>",
  "CELESTIA_AN_EVERYONE": "<a:tungsten_an_everyone:1567232659715793068>",
  "AN_EVERYONE": "<a:tungsten_an_everyone:1567232659715793068>",
  "CELESTIA_AN_GHOSTPING": "<a:tungsten_an_ghostping:1567232680020672664>",
  "AN_GHOSTPING": "<a:tungsten_an_ghostping:1567232680020672664>",
  "CELESTIA_AN_INTEGRITY": "<a:tungsten_an_integrity:1567232702690623490>",
  "AN_INTEGRITY": "<a:tungsten_an_integrity:1567232702690623490>",
  "CELESTIA_AN_INVITE": "<a:tungsten_an_invite:1567232720126607421>",
  "AN_INVITE": "<a:tungsten_an_invite:1567232720126607421>",
  "CELESTIA_AN_JOIN_FLOOD": "<a:tungsten_an_join_flood:1567232740041031831>",
  "AN_JOIN_FLOOD": "<a:tungsten_an_join_flood:1567232740041031831>",
  "CELESTIA_AN_KICK": "<a:tungsten_an_kick:1567232757330083940>",
  "AN_KICK": "<a:tungsten_an_kick:1567232757330083940>",
  "CELESTIA_AN_LIMITS": "<a:tungsten_an_limits:1567232774367092797>",
  "AN_LIMITS": "<a:tungsten_an_limits:1567232774367092797>",
  "CELESTIA_AN_LINK": "<a:tungsten_an_link:1567232798299922585>",
  "AN_LINK": "<a:tungsten_an_link:1567232798299922585>",
  "CELESTIA_AN_LOCKDOWN": "<a:tungsten_an_lockdown:1567232816406732850>",
  "AN_LOCKDOWN": "<a:tungsten_an_lockdown:1567232816406732850>",
  "CELESTIA_AN_LOCKDOWN_LIFT": "<a:tungsten_an_lockdown_lift:1567232833670488064>",
  "AN_LOCKDOWN_LIFT": "<a:tungsten_an_lockdown_lift:1567232833670488064>",
  "CELESTIA_AN_LOGS": "<a:tungsten_an_logs:1567232852200923149>",
  "AN_LOGS": "<a:tungsten_an_logs:1567232852200923149>",
  "CELESTIA_AN_MENTION": "<a:tungsten_an_mention:1567232877584715970>",
  "AN_MENTION": "<a:tungsten_an_mention:1567232877584715970>",
  "CELESTIA_AN_NSFW": "<a:tungsten_an_nsfw:1567232895830196495>",
  "AN_NSFW": "<a:tungsten_an_nsfw:1567232895830196495>",
  "CELESTIA_AN_PUNISH": "<a:tungsten_an_punish:1567232919984939141>",
  "AN_PUNISH": "<a:tungsten_an_punish:1567232919984939141>",
  "CELESTIA_AN_RAID": "<a:tungsten_an_raid:1567232943435292972>",
  "AN_RAID": "<a:tungsten_an_raid:1567232943435292972>",
  "CELESTIA_AN_ROLE_CREATE": "<a:tungsten_an_role_create:1567232961181384745>",
  "AN_ROLE_CREATE": "<a:tungsten_an_role_create:1567232961181384745>",
  "CELESTIA_AN_ROLE_DELETE": "<a:tungsten_an_role_delete:1567232979569483776>",
  "AN_ROLE_DELETE": "<a:tungsten_an_role_delete:1567232979569483776>",
  "CELESTIA_AN_SPAM": "<a:tungsten_an_spam:1567233007415197823>",
  "AN_SPAM": "<a:tungsten_an_spam:1567233007415197823>",
  "CELESTIA_AN_STANDARD": "<a:tungsten_an_standard:1567233029233967106>",
  "AN_STANDARD": "<a:tungsten_an_standard:1567233029233967106>",
  "CELESTIA_AN_STRICT": "<a:tungsten_an_strict:1567233050260021398>",
  "AN_STRICT": "<a:tungsten_an_strict:1567233050260021398>",
  "CELESTIA_AN_ULTRA": "<a:tungsten_an_ultra:1567233073005731872>",
  "AN_ULTRA": "<a:tungsten_an_ultra:1567233073005731872>",
  "CELESTIA_AN_WEBHOOK": "<a:tungsten_an_webhook:1567233087388262422>",
  "AN_WEBHOOK": "<a:tungsten_an_webhook:1567233087388262422>",
  "CELESTIA_ANGER": "<a:tungsten_anger:1567233100776218734>",
  "ANGER": "<a:tungsten_anger:1567233100776218734>",
  "CELESTIA_ARROW_LEFT": "<a:tungsten_arrow_left:1567233111601844267>",
  "CELESTIA_ARROW_RIGHT": "<a:tungsten_arrow_right:1567233126143361135>",
  "CELESTIA_ARROW_SMALL": "<a:tungsten_arrow_small:1567233140357988574>",
  "CELESTIA_ATM": "<a:tungsten_atm:1567233228350300292>",
  "CELESTIA_BANK": "<a:tungsten_bank:1567233290656677924>",
  "CELESTIA_BELL": "<a:tungsten_bell:1567233316925612173>",
  "BELL": "<a:tungsten_bell:1567233316925612173>",
  "CELESTIA_BELL_SLASH": "<a:tungsten_bell_slash:1567233400996106260>",
  "BELL_SLASH": "<a:tungsten_bell_slash:1567233400996106260>",
  "CELESTIA_BOLT": "<a:tungsten_bolt:1567233430570405968>",
  "CELESTIA_BOMB": "<a:tungsten_bomb:1567233448945385502>",
  "BOMB": "<a:tungsten_bomb:1567233448945385502>",
  "CELESTIA_BOOK": "<a:tungsten_book:1567233482499948606>",
  "CELESTIA_BOOT": "<a:tungsten_boot:1567233502418575501>",
  "BOOT": "<a:tungsten_boot:1567233502418575501>",
  "CELESTIA_BOT": "<a:tungsten_bot:1567233522635247781>",
  "CELESTIA_BRAIN": "<a:tungsten_brain:1567233547272454144>",
  "BRAIN": "<a:tungsten_brain:1567233547272454144>",
  "CELESTIA_BRIEFCASE": "<a:tungsten_briefcase:1567233568596295821>",
  "BRIEFCASE": "<a:tungsten_briefcase:1567233568596295821>",
  "CELESTIA_BULLET": "<a:tungsten_bullet:1567233589949497434>",
  "CELESTIA_CABINET": "<a:tungsten_cabinet:1567233617489297548>",
  "CABINET": "<a:tungsten_cabinet:1567233617489297548>",
  "CELESTIA_CALENDAR": "<a:tungsten_calendar:1567233642554458154>",
  "CALENDAR": "<a:tungsten_calendar:1567233642554458154>",
  "CELESTIA_CASH": "<a:tungsten_cash:1567233665082200267>",
  "CELESTIA_CASTLE": "<a:tungsten_castle:1567233687332982844>",
  "CASTLE": "<a:tungsten_castle:1567233687332982844>",
  "CELESTIA_CAT_AUTOMATION": "<a:tungsten_cat_automation:1567233718861435011>",
  "CELESTIA_CAT_BACKUPS": "<a:tungsten_cat_backups:1567233747567251666>",
  "CELESTIA_CAT_CHANNELS": "<a:tungsten_cat_channels:1567233777024110652>",
  "CELESTIA_CAT_ECONOMY": "<a:tungsten_cat_economy:1567233807822618735>",
  "CELESTIA_CAT_FUN": "<a:tungsten_cat_fun:1567233835035402350>",
  "CELESTIA_CAT_GIVEAWAYS": "<a:tungsten_cat_giveaways:1567233867637588015>",
  "CELESTIA_CAT_LEADERBOARDS": "<a:tungsten_cat_leaderboards:1567233900366008430>",
  "CELESTIA_CAT_LOGGING": "<a:tungsten_cat_logging:1567233934490738860>",
  "CELESTIA_CAT_MEDIA": "<a:tungsten_cat_media:1567233959207764080>",
  "CELESTIA_CAT_MODERATION": "<a:tungsten_cat_moderation:1567233980523225148>",
  "CELESTIA_CAT_OWNER": "<a:tungsten_cat_owner:1567234022927638649>",
  "CELESTIA_CAT_PREMIUM": "<a:tungsten_cat_premium:1567234059510223029>",
  "CELESTIA_CAT_ROLES": "<a:tungsten_cat_roles:1567234100975378512>",
  "CELESTIA_CAT_SECURITY": "<a:tungsten_cat_security:1567234156075683940>",
  "CELESTIA_CAT_TICKETS": "<a:tungsten_cat_tickets:1567234238737031290>",
  "CELESTIA_CAT_UTILITY": "<a:tungsten_cat_utility:1567234274183217304>",
  "CELESTIA_CAT_WELCOMER": "<a:tungsten_cat_welcomer:1567234301869822153>",
  "CELESTIA_CAT_WHITELIST": "<a:tungsten_cat_whitelist:1567234327970848848>",
  "CELESTIA_CHART": "<a:tungsten_chart:1567234342701367357>",
  "CELESTIA_CHAT": "<a:tungsten_chat:1567234399450177665>",
  "CHAT": "<a:tungsten_chat:1567234399450177665>",
  "CELESTIA_CHERRY": "<a:tungsten_cherry:1567234489682362439>",
  "CHERRY": "<a:tungsten_cherry:1567234489682362439>",
  "CELESTIA_CIRCLE_GREEN": "<a:tungsten_circle_green:1567234524512002088>",
  "CIRCLE_GREEN": "<a:tungsten_circle_green:1567234524512002088>",
  "CELESTIA_CIRCLE_RED": "<a:tungsten_circle_red:1567234546586353686>",
  "CIRCLE_RED": "<a:tungsten_circle_red:1567234546586353686>",
  "CELESTIA_CIRCLE_WHITE": "<a:tungsten_circle_white:1567234561799233547>",
  "CIRCLE_WHITE": "<a:tungsten_circle_white:1567234561799233547>",
  "CELESTIA_CIRCLE_YELLOW": "<a:tungsten_circle_yellow:1567234580690501693>",
  "CIRCLE_YELLOW": "<a:tungsten_circle_yellow:1567234580690501693>",
  "CELESTIA_CLAPPER": "<a:tungsten_clapper:1567234599262879815>",
  "CLAPPER": "<a:tungsten_clapper:1567234599262879815>",
  "CELESTIA_CLIPBOARD": "<a:tungsten_clipboard:1567234610176204900>",
  "CELESTIA_CLOCK": "<a:tungsten_clock:1567234623216554118>",
  "CELESTIA_CLOSE": "<a:tungsten_close:1567234632905138206>",
  "CELESTIA_CMD_8BALL": "<a:tungsten_cmd_8ball:1567234645140181082>",
  "CMD_8BALL": "<a:tungsten_cmd_8ball:1567234645140181082>",
  "CELESTIA_CMD_ADDEMOJI": "<a:tungsten_cmd_addemoji:1567234657026707537>",
  "CMD_ADDEMOJI": "<a:tungsten_cmd_addemoji:1567234657026707537>",
  "CELESTIA_CMD_AFK": "<a:tungsten_cmd_afk:1567234668347260938>",
  "CMD_AFK": "<a:tungsten_cmd_afk:1567234668347260938>",
  "CELESTIA_CMD_ANAUDIT": "<a:tungsten_cmd_anaudit:1567234683937497259>",
  "CMD_ANAUDIT": "<a:tungsten_cmd_anaudit:1567234683937497259>",
  "CELESTIA_CMD_ANMODE": "<a:tungsten_cmd_anmode:1567234697556271327>",
  "CMD_ANMODE": "<a:tungsten_cmd_anmode:1567234697556271327>",
  "CELESTIA_CMD_ANTIGHOSTPING": "<a:tungsten_cmd_antighostping:1567234715549835435>",
  "CMD_ANTIGHOSTPING": "<a:tungsten_cmd_antighostping:1567234715549835435>",
  "CELESTIA_CMD_ANTINUKE": "<a:tungsten_cmd_antinuke:1567234734726316142>",
  "CMD_ANTINUKE": "<a:tungsten_cmd_antinuke:1567234734726316142>",
  "CELESTIA_CMD_ANTIRAID": "<a:tungsten_cmd_antiraid:1567234763755102373>",
  "CMD_ANTIRAID": "<a:tungsten_cmd_antiraid:1567234763755102373>",
  "CELESTIA_CMD_AUDITLOG": "<a:tungsten_cmd_auditlog:1567234776841195712>",
  "CMD_AUDITLOG": "<a:tungsten_cmd_auditlog:1567234776841195712>",
  "CELESTIA_CMD_AUTOMOD": "<a:tungsten_cmd_automod:1567234793022689290>",
  "CMD_AUTOMOD": "<a:tungsten_cmd_automod:1567234793022689290>",
  "CELESTIA_CMD_AUTOREACT": "<a:tungsten_cmd_autoreact:1567234807379922944>",
  "CMD_AUTOREACT": "<a:tungsten_cmd_autoreact:1567234807379922944>",
  "CELESTIA_CMD_AUTORESPONDER": "<a:tungsten_cmd_autoresponder:1567234819992330240>",
  "CMD_AUTORESPONDER": "<a:tungsten_cmd_autoresponder:1567234819992330240>",
  "CELESTIA_CMD_AUTOROLE": "<a:tungsten_cmd_autorole:1567234834504482948>",
  "CMD_AUTOROLE": "<a:tungsten_cmd_autorole:1567234834504482948>",
  "CELESTIA_CMD_AVATAR": "<a:tungsten_cmd_avatar:1567234845363540139>",
  "CMD_AVATAR": "<a:tungsten_cmd_avatar:1567234845363540139>",
  "CELESTIA_CMD_BACKUP": "<a:tungsten_cmd_backup:1567234860119236649>",
  "CMD_BACKUP": "<a:tungsten_cmd_backup:1567234860119236649>",
  "CELESTIA_CMD_BALANCE": "<a:tungsten_cmd_balance:1567234874736250981>",
  "CMD_BALANCE": "<a:tungsten_cmd_balance:1567234874736250981>",
  "CELESTIA_CMD_BAN": "<a:tungsten_cmd_ban:1567234887503585321>",
  "CMD_BAN": "<a:tungsten_cmd_ban:1567234887503585321>",
  "CELESTIA_CMD_BANPANEL": "<a:tungsten_cmd_banpanel:1567234900233552055>",
  "CMD_BANPANEL": "<a:tungsten_cmd_banpanel:1567234900233552055>",
  "CELESTIA_CMD_BOTINFO": "<a:tungsten_cmd_botinfo:1567234914867224616>",
  "CMD_BOTINFO": "<a:tungsten_cmd_botinfo:1567234914867224616>",
  "CELESTIA_CMD_CASES": "<a:tungsten_cmd_cases:1567234927450390658>",
  "CMD_CASES": "<a:tungsten_cmd_cases:1567234927450390658>",
  "CELESTIA_CMD_CELMOD": "<a:tungsten_cmd_celmod:1567234939886370929>",
  "CMD_CELMOD": "<a:tungsten_cmd_celmod:1567234939886370929>",
  "CELESTIA_CMD_CHANNELINFO": "<a:tungsten_cmd_channelinfo:1567234953803210806>",
  "CMD_CHANNELINFO": "<a:tungsten_cmd_channelinfo:1567234953803210806>",
  "CELESTIA_CMD_CLEANUP": "<a:tungsten_cmd_cleanup:1567234967203745988>",
  "CMD_CLEANUP": "<a:tungsten_cmd_cleanup:1567234967203745988>",
  "CELESTIA_CMD_CLEARWARNS": "<a:tungsten_cmd_clearwarns:1567234980797612133>",
  "CMD_CLEARWARNS": "<a:tungsten_cmd_clearwarns:1567234980797612133>",
  "CELESTIA_CMD_CM": "<a:tungsten_cmd_cm:1567234994768715806>",
  "CMD_CM": "<a:tungsten_cmd_cm:1567234994768715806>",
  "CELESTIA_CMD_COINFLIP": "<a:tungsten_cmd_coinflip:1567235008547258368>",
  "CMD_COINFLIP": "<a:tungsten_cmd_coinflip:1567235008547258368>",
  "CELESTIA_CMD_COMPONENTSV2": "<a:tungsten_cmd_componentsv2:1567235021910315069>",
  "CMD_COMPONENTSV2": "<a:tungsten_cmd_componentsv2:1567235021910315069>",
  "CELESTIA_CMD_CONNECT4": "<a:tungsten_cmd_connect4:1567235052243517541>",
  "CMD_CONNECT4": "<a:tungsten_cmd_connect4:1567235052243517541>",
  "CELESTIA_CMD_CUSTOMCMD": "<a:tungsten_cmd_customcmd:1567235065107452015>",
  "CMD_CUSTOMCMD": "<a:tungsten_cmd_customcmd:1567235065107452015>",
  "CELESTIA_CMD_CUSTOMROLE": "<a:tungsten_cmd_customrole:1567235078654791690>",
  "CMD_CUSTOMROLE": "<a:tungsten_cmd_customrole:1567235078654791690>",
  "CELESTIA_CMD_DAILY": "<a:tungsten_cmd_daily:1567235093611675650>",
  "CMD_DAILY": "<a:tungsten_cmd_daily:1567235093611675650>",
  "CELESTIA_CMD_DATABASE": "<a:tungsten_cmd_database:1567235125513687152>",
  "CMD_DATABASE": "<a:tungsten_cmd_database:1567235125513687152>",
  "CELESTIA_CMD_DELETEEMOJI": "<a:tungsten_cmd_deleteemoji:1567235155574267935>",
  "CMD_DELETEEMOJI": "<a:tungsten_cmd_deleteemoji:1567235155574267935>",
  "CELESTIA_CMD_DEPOSIT": "<a:tungsten_cmd_deposit:1567235175472041994>",
  "CMD_DEPOSIT": "<a:tungsten_cmd_deposit:1567235175472041994>",
  "CELESTIA_CMD_DUTY": "<a:tungsten_cmd_duty:1567235200541528074>",
  "CMD_DUTY": "<a:tungsten_cmd_duty:1567235200541528074>",
  "CELESTIA_CMD_EMERGENCY": "<a:tungsten_cmd_emergency:1567235226504134656>",
  "CMD_EMERGENCY": "<a:tungsten_cmd_emergency:1567235226504134656>",
  "CELESTIA_CMD_EMOJILIST": "<a:tungsten_cmd_emojilist:1567235260012298260>",
  "CMD_EMOJILIST": "<a:tungsten_cmd_emojilist:1567235260012298260>",
  "CELESTIA_CMD_EMOJIPACK": "<a:tungsten_cmd_emojipack:1567235282489839766>",
  "CMD_EMOJIPACK": "<a:tungsten_cmd_emojipack:1567235282489839766>",
  "CELESTIA_CMD_EMOJISERVER": "<a:tungsten_cmd_emojiserver:1567235306711818290>",
  "CMD_EMOJISERVER": "<a:tungsten_cmd_emojiserver:1567235306711818290>",
  "CELESTIA_CMD_EXTRAOWNER": "<a:tungsten_cmd_extraowner:1567235342850064407>",
  "CMD_EXTRAOWNER": "<a:tungsten_cmd_extraowner:1567235342850064407>",
  "CELESTIA_CMD_GIF": "<a:tungsten_cmd_gif:1567235366665326693>",
  "CMD_GIF": "<a:tungsten_cmd_gif:1567235366665326693>",
  "CELESTIA_CMD_GIVEAWAY": "<a:tungsten_cmd_giveaway:1567235389226352785>",
  "CMD_GIVEAWAY": "<a:tungsten_cmd_giveaway:1567235389226352785>",
  "CELESTIA_CMD_GIVEROLE": "<a:tungsten_cmd_giverole:1567235411615678545>",
  "CMD_GIVEROLE": "<a:tungsten_cmd_giverole:1567235411615678545>",
  "CELESTIA_CMD_HELP": "<a:tungsten_cmd_help:1567235431567724626>",
  "CMD_HELP": "<a:tungsten_cmd_help:1567235431567724626>",
  "CELESTIA_CMD_HIDE": "<a:tungsten_cmd_hide:1567235456494731295>",
  "CMD_HIDE": "<a:tungsten_cmd_hide:1567235456494731295>",
  "CELESTIA_CMD_INROLE": "<a:tungsten_cmd_inrole:1567235483904249897>",
  "CMD_INROLE": "<a:tungsten_cmd_inrole:1567235483904249897>",
  "CELESTIA_CMD_INVESTIGATE": "<a:tungsten_cmd_investigate:1567235510517375127>",
  "CMD_INVESTIGATE": "<a:tungsten_cmd_investigate:1567235510517375127>",
  "CELESTIA_CMD_INVITE": "<a:tungsten_cmd_invite:1567235535573885110>",
  "CMD_INVITE": "<a:tungsten_cmd_invite:1567235535573885110>",
  "CELESTIA_CMD_JOKE": "<a:tungsten_cmd_joke:1567235558705598494>",
  "CMD_JOKE": "<a:tungsten_cmd_joke:1567235558705598494>",
  "CELESTIA_CMD_KICK": "<a:tungsten_cmd_kick:1567235578293129256>",
  "CMD_KICK": "<a:tungsten_cmd_kick:1567235578293129256>",
  "CELESTIA_CMD_KICKPANEL": "<a:tungsten_cmd_kickpanel:1567235599557984417>",
  "CMD_KICKPANEL": "<a:tungsten_cmd_kickpanel:1567235599557984417>",
  "CELESTIA_CMD_LEADERBOARD": "<a:tungsten_cmd_leaderboard:1567235635331473509>",
  "CMD_LEADERBOARD": "<a:tungsten_cmd_leaderboard:1567235635331473509>",
  "CELESTIA_CMD_LEAVE": "<a:tungsten_cmd_leave:1567235657783447573>",
  "CMD_LEAVE": "<a:tungsten_cmd_leave:1567235657783447573>",
  "CELESTIA_CMD_LEVELS": "<a:tungsten_cmd_levels:1567235696920371301>",
  "CMD_LEVELS": "<a:tungsten_cmd_levels:1567235696920371301>",
  "CELESTIA_CMD_LOCK": "<a:tungsten_cmd_lock:1567235715983609857>",
  "CMD_LOCK": "<a:tungsten_cmd_lock:1567235715983609857>",
  "CELESTIA_CMD_LOCKPANEL": "<a:tungsten_cmd_lockpanel:1567235752344035459>",
  "CMD_LOCKPANEL": "<a:tungsten_cmd_lockpanel:1567235752344035459>",
  "CELESTIA_CMD_MEMBERCOUNT": "<a:tungsten_cmd_membercount:1567235784182857868>",
  "CMD_MEMBERCOUNT": "<a:tungsten_cmd_membercount:1567235784182857868>",
  "CELESTIA_CMD_MEME": "<a:tungsten_cmd_meme:1567235815833337940>",
  "CMD_MEME": "<a:tungsten_cmd_meme:1567235815833337940>",
  "CELESTIA_CMD_MODPANEL": "<a:tungsten_cmd_modpanel:1567235859063906364>",
  "CMD_MODPANEL": "<a:tungsten_cmd_modpanel:1567235859063906364>",
  "CELESTIA_CMD_MODROLEPANEL": "<a:tungsten_cmd_modrolepanel:1567235913829056616>",
  "CMD_MODROLEPANEL": "<a:tungsten_cmd_modrolepanel:1567235913829056616>",
  "CELESTIA_CMD_MUTE": "<a:tungsten_cmd_mute:1567235956644253696>",
  "CMD_MUTE": "<a:tungsten_cmd_mute:1567235956644253696>",
  "CELESTIA_CMD_MUTEPANEL": "<a:tungsten_cmd_mutepanel:1567235994359562391>",
  "CMD_MUTEPANEL": "<a:tungsten_cmd_mutepanel:1567235994359562391>",
  "CELESTIA_CMD_NIGHTMODE": "<a:tungsten_cmd_nightmode:1567236036550074390>",
  "CMD_NIGHTMODE": "<a:tungsten_cmd_nightmode:1567236036550074390>",
  "CELESTIA_CMD_NOPREFIX": "<a:tungsten_cmd_noprefix:1567236069643132972>",
  "CMD_NOPREFIX": "<a:tungsten_cmd_noprefix:1567236069643132972>",
  "CELESTIA_CMD_NPMANAGER": "<a:tungsten_cmd_npmanager:1567236115197591596>",
  "CMD_NPMANAGER": "<a:tungsten_cmd_npmanager:1567236115197591596>",
  "CELESTIA_CMD_NUKE": "<a:tungsten_cmd_nuke:1567236137746169887>",
  "CMD_NUKE": "<a:tungsten_cmd_nuke:1567236137746169887>",
  "CELESTIA_CMD_OWNERPANEL": "<a:tungsten_cmd_ownerpanel:1567236155634622514>",
  "CMD_OWNERPANEL": "<a:tungsten_cmd_ownerpanel:1567236155634622514>",
  "CELESTIA_CMD_PANEL": "<a:tungsten_cmd_panel:1567236187700338759>",
  "CMD_PANEL": "<a:tungsten_cmd_panel:1567236187700338759>",
  "CELESTIA_CMD_PANIC": "<a:tungsten_cmd_panic:1567236213897822388>",
  "CMD_PANIC": "<a:tungsten_cmd_panic:1567236213897822388>",
  "CELESTIA_CMD_PAY": "<a:tungsten_cmd_pay:1567236244205867130>",
  "CMD_PAY": "<a:tungsten_cmd_pay:1567236244205867130>",
  "CELESTIA_CMD_PING": "<a:tungsten_cmd_ping:1567236300271255715>",
  "CMD_PING": "<a:tungsten_cmd_ping:1567236300271255715>",
  "CELESTIA_CMD_PINGS": "<a:tungsten_cmd_pings:1567236330038235206>",
  "CMD_PINGS": "<a:tungsten_cmd_pings:1567236330038235206>",
  "CELESTIA_CMD_PREFIX": "<a:tungsten_cmd_prefix:1567236353924792524>",
  "CMD_PREFIX": "<a:tungsten_cmd_prefix:1567236353924792524>",
  "CELESTIA_CMD_PREMIUM": "<a:tungsten_cmd_premium:1567236385734139966>",
  "CMD_PREMIUM": "<a:tungsten_cmd_premium:1567236385734139966>",
  "CELESTIA_CMD_PREMIUMMANAGER": "<a:tungsten_cmd_premiummanager:1567236418634252458>",
  "CMD_PREMIUMMANAGER": "<a:tungsten_cmd_premiummanager:1567236418634252458>",
  "CELESTIA_CMD_PROFILE": "<a:tungsten_cmd_profile:1567236443917525154>",
  "CMD_PROFILE": "<a:tungsten_cmd_profile:1567236443917525154>",
  "CELESTIA_CMD_PURGE": "<a:tungsten_cmd_purge:1567236474280083516>",
  "CMD_PURGE": "<a:tungsten_cmd_purge:1567236474280083516>",
  "CELESTIA_CMD_PURGEPANEL": "<a:tungsten_cmd_purgepanel:1567236525425430749>",
  "CMD_PURGEPANEL": "<a:tungsten_cmd_purgepanel:1567236525425430749>",
  "CELESTIA_CMD_REACTIONROLE": "<a:tungsten_cmd_reactionrole:1567236559248429167>",
  "CMD_REACTIONROLE": "<a:tungsten_cmd_reactionrole:1567236559248429167>",
  "CELESTIA_CMD_REMOVEROLE": "<a:tungsten_cmd_removerole:1567236636641599548>",
  "CMD_REMOVEROLE": "<a:tungsten_cmd_removerole:1567236636641599548>",
  "CELESTIA_CMD_ROB": "<a:tungsten_cmd_rob:1567236704203571431>",
  "CMD_ROB": "<a:tungsten_cmd_rob:1567236704203571431>",
  "CELESTIA_CMD_ROLEINFO": "<a:tungsten_cmd_roleinfo:1567236816225046629>",
  "CMD_ROLEINFO": "<a:tungsten_cmd_roleinfo:1567236816225046629>",
  "CELESTIA_CMD_ROLL": "<a:tungsten_cmd_roll:1567236993287725196>",
  "CMD_ROLL": "<a:tungsten_cmd_roll:1567236993287725196>",
  "CELESTIA_CMD_RPS": "<a:tungsten_cmd_rps:1567237016662577224>",
  "CMD_RPS": "<a:tungsten_cmd_rps:1567237016662577224>",
  "CELESTIA_CMD_SECURITYSCORE": "<a:tungsten_cmd_securityscore:1567237039135400067>",
  "CMD_SECURITYSCORE": "<a:tungsten_cmd_securityscore:1567237039135400067>",
  "CELESTIA_CMD_SERVERINFO": "<a:tungsten_cmd_serverinfo:1567237069502287923>",
  "CMD_SERVERINFO": "<a:tungsten_cmd_serverinfo:1567237069502287923>",
  "CELESTIA_CMD_SETHOMEVC": "<a:tungsten_cmd_sethomevc:1567237101341380720>",
  "CMD_SETHOMEVC": "<a:tungsten_cmd_sethomevc:1567237101341380720>",
  "CELESTIA_CMD_SHIP": "<a:tungsten_cmd_ship:1567237143049539777>",
  "CMD_SHIP": "<a:tungsten_cmd_ship:1567237143049539777>",
  "CELESTIA_CMD_SLOTS": "<a:tungsten_cmd_slots:1567237210565120220>",
  "CMD_SLOTS": "<a:tungsten_cmd_slots:1567237210565120220>",
  "CELESTIA_CMD_SLOWMODE": "<a:tungsten_cmd_slowmode:1567237253061804164>",
  "CMD_SLOWMODE": "<a:tungsten_cmd_slowmode:1567237253061804164>",
  "CELESTIA_CMD_SNIPE": "<a:tungsten_cmd_snipe:1567237311106777210>",
  "CMD_SNIPE": "<a:tungsten_cmd_snipe:1567237311106777210>",
  "CELESTIA_CMD_SOFTBAN": "<a:tungsten_cmd_softban:1567237338374086719>",
  "CMD_SOFTBAN": "<a:tungsten_cmd_softban:1567237338374086719>",
  "CELESTIA_CMD_STATS": "<a:tungsten_cmd_stats:1567237361664925757>",
  "CMD_STATS": "<a:tungsten_cmd_stats:1567237361664925757>",
  "CELESTIA_CMD_STICKYMESSAGE": "<a:tungsten_cmd_stickymessage:1567237387925454968>",
  "CMD_STICKYMESSAGE": "<a:tungsten_cmd_stickymessage:1567237387925454968>",
  "CELESTIA_CMD_SUPPORT": "<a:tungsten_cmd_support:1567237424843591770>",
  "CMD_SUPPORT": "<a:tungsten_cmd_support:1567237424843591770>",
  "CELESTIA_CMD_TICKET": "<a:tungsten_cmd_ticket:1567237476173619345>",
  "CMD_TICKET": "<a:tungsten_cmd_ticket:1567237476173619345>",
  "CELESTIA_CMD_TRIVIA": "<a:tungsten_cmd_trivia:1567237570192998610>",
  "CMD_TRIVIA": "<a:tungsten_cmd_trivia:1567237570192998610>",
  "CELESTIA_CMD_UNBAN": "<a:tungsten_cmd_unban:1567237654230208743>",
  "CMD_UNBAN": "<a:tungsten_cmd_unban:1567237654230208743>",
  "CELESTIA_CMD_UNHIDE": "<a:tungsten_cmd_unhide:1567237716330946600>",
  "CMD_UNHIDE": "<a:tungsten_cmd_unhide:1567237716330946600>",
  "CELESTIA_CMD_UNLOCK": "<a:tungsten_cmd_unlock:1567237734299467886>",
  "CMD_UNLOCK": "<a:tungsten_cmd_unlock:1567237734299467886>",
  "CELESTIA_CMD_UNMUTE": "<a:tungsten_cmd_unmute:1567237746697961612>",
  "CMD_UNMUTE": "<a:tungsten_cmd_unmute:1567237746697961612>",
  "CELESTIA_CMD_UNWHITELIST": "<a:tungsten_cmd_unwhitelist:1567237762376273990>",
  "CMD_UNWHITELIST": "<a:tungsten_cmd_unwhitelist:1567237762376273990>",
  "CELESTIA_CMD_UPTIME": "<a:tungsten_cmd_uptime:1567237782605398036>",
  "CMD_UPTIME": "<a:tungsten_cmd_uptime:1567237782605398036>",
  "CELESTIA_CMD_USERINFO": "<a:tungsten_cmd_userinfo:1567237805266964481>",
  "CMD_USERINFO": "<a:tungsten_cmd_userinfo:1567237805266964481>",
  "CELESTIA_CMD_VANITYGUARD": "<a:tungsten_cmd_vanityguard:1567237826154602613>",
  "CMD_VANITYGUARD": "<a:tungsten_cmd_vanityguard:1567237826154602613>",
  "CELESTIA_CMD_VCROLE": "<a:tungsten_cmd_vcrole:1567237847486832640>",
  "CMD_VCROLE": "<a:tungsten_cmd_vcrole:1567237847486832640>",
  "CELESTIA_CMD_VCSTATUS": "<a:tungsten_cmd_vcstatus:1567237869133635628>",
  "CMD_VCSTATUS": "<a:tungsten_cmd_vcstatus:1567237869133635628>",
  "CELESTIA_CMD_VOICE": "<a:tungsten_cmd_voice:1567237893590753360>",
  "CMD_VOICE": "<a:tungsten_cmd_voice:1567237893590753360>",
  "CELESTIA_CMD_VOICEMOD": "<a:tungsten_cmd_voicemod:1567237946053099530>",
  "CMD_VOICEMOD": "<a:tungsten_cmd_voicemod:1567237946053099530>",
  "CELESTIA_CMD_WARN": "<a:tungsten_cmd_warn:1567238033705799771>",
  "CMD_WARN": "<a:tungsten_cmd_warn:1567238033705799771>",
  "CELESTIA_CMD_WARNINGS": "<a:tungsten_cmd_warnings:1567238062759739435>",
  "CMD_WARNINGS": "<a:tungsten_cmd_warnings:1567238062759739435>",
  "CELESTIA_CMD_WARNPANEL": "<a:tungsten_cmd_warnpanel:1567238091708702792>",
  "CMD_WARNPANEL": "<a:tungsten_cmd_warnpanel:1567238091708702792>",
  "CELESTIA_CMD_WELCOME": "<a:tungsten_cmd_welcome:1567238123807842346>",
  "CMD_WELCOME": "<a:tungsten_cmd_welcome:1567238123807842346>",
  "CELESTIA_CMD_WHITELIST": "<a:tungsten_cmd_whitelist:1567238164991451146>",
  "CMD_WHITELIST": "<a:tungsten_cmd_whitelist:1567238164991451146>",
  "CELESTIA_CMD_WHITELISTED": "<a:tungsten_cmd_whitelisted:1567238207295455329>",
  "CMD_WHITELISTED": "<a:tungsten_cmd_whitelisted:1567238207295455329>",
  "CELESTIA_CMD_WITHDRAW": "<a:tungsten_cmd_withdraw:1567238237108310077>",
  "CMD_WITHDRAW": "<a:tungsten_cmd_withdraw:1567238237108310077>",
  "CELESTIA_CMD_WORK": "<a:tungsten_cmd_work:1567238276161601567>",
  "CMD_WORK": "<a:tungsten_cmd_work:1567238276161601567>",
  "CELESTIA_COIN": "<a:tungsten_coin:1567238316967985244>",
  "CELESTIA_CROWN": "<a:tungsten_crown:1567238355463176334>",
  "CELESTIA_CRYSTAL": "<a:tungsten_crystal:1567238398400532571>",
  "CRYSTAL": "<a:tungsten_crystal:1567238398400532571>",
  "CELESTIA_DANCER": "<a:tungsten_dancer:1567238442092601424>",
  "DANCER": "<a:tungsten_dancer:1567238442092601424>",
  "CELESTIA_DATABASE": "<a:tungsten_database:1567238475684651168>",
  "CELESTIA_DIAMOND_SMALL": "<a:tungsten_diamond_small:1567238516855939283>",
  "DIAMOND_SMALL": "<a:tungsten_diamond_small:1567238516855939283>",
  "CELESTIA_DICE": "<a:tungsten_dice:1567238580827328582>",
  "DICE": "<a:tungsten_dice:1567238580827328582>",
  "CELESTIA_DOOR": "<a:tungsten_door:1567238621432643794>",
  "DOOR": "<a:tungsten_door:1567238621432643794>",
  "CELESTIA_DRAMA": "<a:tungsten_drama:1567238681557991474>",
  "DRAMA": "<a:tungsten_drama:1567238681557991474>",
  "CELESTIA_EIGHTBALL": "<a:tungsten_eightball:1567238723995967638>",
  "EIGHTBALL": "<a:tungsten_eightball:1567238723995967638>",
  "CELESTIA_ERROR": "<a:tungsten_error:1567238753284653106>",
  "CELESTIA_EXPLOSION": "<a:tungsten_explosion:1567238834343911554>",
  "EXPLOSION": "<a:tungsten_explosion:1567238834343911554>",
  "CELESTIA_EYE": "<a:tungsten_eye:1567238862042833088>",
  "EYE": "<a:tungsten_eye:1567238862042833088>",
  "CELESTIA_EYE_SLASH": "<a:tungsten_eye_slash:1567238896612282430>",
  "EYE_SLASH": "<a:tungsten_eye_slash:1567238896612282430>",
  "CELESTIA_EYES": "<a:tungsten_eyes:1567238923913011254>",
  "EYES": "<a:tungsten_eyes:1567238923913011254>",
  "CELESTIA_FACE_ANGRY": "<a:tungsten_face_angry:1567238949284618291>",
  "FACE_ANGRY": "<a:tungsten_face_angry:1567238949284618291>",
  "CELESTIA_FACE_COOL": "<a:tungsten_face_cool:1567238977264685118>",
  "FACE_COOL": "<a:tungsten_face_cool:1567238977264685118>",
  "CELESTIA_FACE_CRAZY": "<a:tungsten_face_crazy:1567239007463669832>",
  "FACE_CRAZY": "<a:tungsten_face_crazy:1567239007463669832>",
  "CELESTIA_FACE_CRY": "<a:tungsten_face_cry:1567239031735980053>",
  "FACE_CRY": "<a:tungsten_face_cry:1567239031735980053>",
  "CELESTIA_FACE_DEVIL": "<a:tungsten_face_devil:1567239058327871564>",
  "FACE_DEVIL": "<a:tungsten_face_devil:1567239058327871564>",
  "CELESTIA_FACE_FLUSHED": "<a:tungsten_face_flushed:1567239086484357130>",
  "FACE_FLUSHED": "<a:tungsten_face_flushed:1567239086484357130>",
  "CELESTIA_FACE_GRIN": "<a:tungsten_face_grin:1567239115089514536>",
  "FACE_GRIN": "<a:tungsten_face_grin:1567239115089514536>",
  "CELESTIA_FACE_LAUGH": "<a:tungsten_face_laugh:1567239143048613900>",
  "FACE_LAUGH": "<a:tungsten_face_laugh:1567239143048613900>",
  "CELESTIA_FACE_LOVE": "<a:tungsten_face_love:1567239175110140056>",
  "FACE_LOVE": "<a:tungsten_face_love:1567239175110140056>",
  "CELESTIA_FACE_MELTING": "<a:tungsten_face_melting:1567239201269743827>",
  "FACE_MELTING": "<a:tungsten_face_melting:1567239201269743827>",
  "CELESTIA_FACE_PLEADING": "<a:tungsten_face_pleading:1567239233788448939>",
  "FACE_PLEADING": "<a:tungsten_face_pleading:1567239233788448939>",
  "CELESTIA_FACE_SCARED": "<a:tungsten_face_scared:1567239267774763038>",
  "FACE_SCARED": "<a:tungsten_face_scared:1567239267774763038>",
  "CELESTIA_FACE_SLEEP": "<a:tungsten_face_sleep:1567239295914213548>",
  "FACE_SLEEP": "<a:tungsten_face_sleep:1567239295914213548>",
  "CELESTIA_FACE_SMILE": "<a:tungsten_face_smile:1567239325941375126>",
  "FACE_SMILE": "<a:tungsten_face_smile:1567239325941375126>",
  "CELESTIA_FACE_SURPRISED": "<a:tungsten_face_surprised:1567239358975582248>",
  "FACE_SURPRISED": "<a:tungsten_face_surprised:1567239358975582248>",
  "CELESTIA_FACE_WINK": "<a:tungsten_face_wink:1567239380244897846>",
  "FACE_WINK": "<a:tungsten_face_wink:1567239380244897846>",
  "CELESTIA_FIST": "<a:tungsten_fist:1567239431444897892>",
  "FIST": "<a:tungsten_fist:1567239431444897892>",
  "CELESTIA_FLAG_CHEQUERED": "<a:tungsten_flag_chequered:1567239507135307972>",
  "FLAG_CHEQUERED": "<a:tungsten_flag_chequered:1567239507135307972>",
  "CELESTIA_FLAG_WHITE": "<a:tungsten_flag_white:1567239547769589771>",
  "FLAG_WHITE": "<a:tungsten_flag_white:1567239547769589771>",
  "CELESTIA_FOLDER": "<a:tungsten_folder:1567239623145558046>",
  "FOLDER": "<a:tungsten_folder:1567239623145558046>",
  "CELESTIA_FOLDER_OPEN": "<a:tungsten_folder_open:1567239652501495988>",
  "FOLDER_OPEN": "<a:tungsten_folder_open:1567239652501495988>",
  "CELESTIA_FOOT": "<a:tungsten_foot:1567239740942458880>",
  "FOOT": "<a:tungsten_foot:1567239740942458880>",
  "CELESTIA_FRAME": "<a:tungsten_frame:1567239867983863889>",
  "FRAME": "<a:tungsten_frame:1567239867983863889>",
  "CELESTIA_GAMEPAD": "<a:tungsten_gamepad:1567239909985616063>",
  "GAMEPAD": "<a:tungsten_gamepad:1567239909985616063>",
  "CELESTIA_GEAR": "<a:tungsten_gear:1567239932970406012>",
  "CELESTIA_GEM": "<a:tungsten_gem:1567239960837357759>",
  "CELESTIA_GEM_FLOWER": "<a:tungsten_gem_flower:1567239998779031595>",
  "GEM_FLOWER": "<a:tungsten_gem_flower:1567239998779031595>",
  "CELESTIA_GHOST": "<a:tungsten_ghost:1567240021692518512>",
  "GHOST": "<a:tungsten_ghost:1567240021692518512>",
  "CELESTIA_GIFT": "<a:tungsten_gift:1567240042563244072>",
  "CELESTIA_GLOBE": "<a:tungsten_globe:1567240068253622433>",
  "CELESTIA_GRAPES": "<a:tungsten_grapes:1567240092739833866>",
  "GRAPES": "<a:tungsten_grapes:1567240092739833866>",
  "CELESTIA_GUN": "<a:tungsten_gun:1567240119612874822>",
  "GUN": "<a:tungsten_gun:1567240119612874822>",
  "CELESTIA_HAMMER": "<a:tungsten_hammer:1567240140277944350>",
  "CELESTIA_HANDS_UP": "<a:tungsten_hands_up:1567240175594250302>",
  "HANDS_UP": "<a:tungsten_hands_up:1567240175594250302>",
  "CELESTIA_HANDSHAKE": "<a:tungsten_handshake:1567240195646951494>",
  "HANDSHAKE": "<a:tungsten_handshake:1567240195646951494>",
  "CELESTIA_HEADPHONES": "<a:tungsten_headphones:1567240226789785730>",
  "CELESTIA_HEART": "<a:tungsten_heart:1567240255680155718>",
  "HEART": "<a:tungsten_heart:1567240255680155718>",
  "CELESTIA_HEART_BROKEN": "<a:tungsten_heart_broken:1567240285053001738>",
  "HEART_BROKEN": "<a:tungsten_heart_broken:1567240285053001738>",
  "CELESTIA_HEART_ORANGE": "<a:tungsten_heart_orange:1567240324336582743>",
  "HEART_ORANGE": "<a:tungsten_heart_orange:1567240324336582743>",
  "CELESTIA_HEART_SPARKLE": "<a:tungsten_heart_sparkle:1567240386659885106>",
  "HEART_SPARKLE": "<a:tungsten_heart_sparkle:1567240386659885106>",
  "CELESTIA_HEART_YELLOW": "<a:tungsten_heart_yellow:1567240422068068529>",
  "HEART_YELLOW": "<a:tungsten_heart_yellow:1567240422068068529>",
  "CELESTIA_HEARTS": "<a:tungsten_hearts:1567240511670976552>",
  "HEARTS": "<a:tungsten_hearts:1567240511670976552>",
  "CELESTIA_HOME": "<a:tungsten_home:1567240545661620387>",
  "CELESTIA_HOURGLASS": "<a:tungsten_hourglass:1567240660702986281>",
  "CELESTIA_ID": "<a:tungsten_id:1567240689048355008>",
  "ID": "<a:tungsten_id:1567240689048355008>",
  "CELESTIA_INBOX": "<a:tungsten_inbox:1567240785219289108>",
  "INBOX": "<a:tungsten_inbox:1567240785219289108>",
  "CELESTIA_INFINITY": "<a:tungsten_infinity:1567240813895745626>",
  "INFINITY": "<a:tungsten_infinity:1567240813895745626>",
  "CELESTIA_INFO": "<a:tungsten_info:1567240890748248084>",
  "CELESTIA_KEY": "<a:tungsten_key:1567240907684581492>",
  "CELESTIA_KEYCAP_TEN": "<a:tungsten_keycap_ten:1567240934599688303>",
  "KEYCAP_TEN": "<a:tungsten_keycap_ten:1567240934599688303>",
  "CELESTIA_KEYLOCK": "<a:tungsten_keylock:1567240958075084951>",
  "CELESTIA_KNIFE": "<a:tungsten_knife:1567240975758270495>",
  "KNIFE": "<a:tungsten_knife:1567240975758270495>",
  "CELESTIA_LEMON": "<a:tungsten_lemon:1567240998231343184>",
  "LEMON": "<a:tungsten_lemon:1567240998231343184>",
  "CELESTIA_LINK": "<a:tungsten_link:1567241025813086210>",
  "LINK": "<a:tungsten_link:1567241025813086210>",
  "CELESTIA_LOADING": "<a:tungsten_loading:1567241050567876698>",
  "CELESTIA_LOCK": "<a:tungsten_lock:1567241079030550668>",
  "CELESTIA_MAILBOX": "<a:tungsten_mailbox:1567241098009509949>",
  "MAILBOX": "<a:tungsten_mailbox:1567241098009509949>",
  "CELESTIA_MEDAL_BRONZE": "<a:tungsten_medal_bronze:1567241129030582403>",
  "MEDAL_BRONZE": "<a:tungsten_medal_bronze:1567241129030582403>",
  "CELESTIA_MEDAL_GOLD": "<a:tungsten_medal_gold:1567241163453366472>",
  "MEDAL_GOLD": "<a:tungsten_medal_gold:1567241163453366472>",
  "CELESTIA_MEDAL_SILVER": "<a:tungsten_medal_silver:1567241205409128649>",
  "MEDAL_SILVER": "<a:tungsten_medal_silver:1567241205409128649>",
  "CELESTIA_MEMO": "<a:tungsten_memo:1567241226577780957>",
  "CELESTIA_MIC": "<a:tungsten_mic:1567241257862832189>",
  "CELESTIA_MINUS": "<a:tungsten_minus:1567241276057849856>",
  "CELESTIA_MONEY_WINGS": "<a:tungsten_money_wings:1567241294408061024>",
  "MONEY_WINGS": "<a:tungsten_money_wings:1567241294408061024>",
  "CELESTIA_MONEYBAG": "<a:tungsten_moneybag:1567241334698541109>",
  "CELESTIA_MONITOR": "<a:tungsten_monitor:1567241360984121485>",
  "MONITOR": "<a:tungsten_monitor:1567241360984121485>",
  "CELESTIA_MOON": "<a:tungsten_moon:1567241385021673674>",
  "MOON": "<a:tungsten_moon:1567241385021673674>",
  "CELESTIA_MUSIC": "<a:tungsten_music:1567241425328939110>",
  "CELESTIA_MUTE": "<a:tungsten_mute:1567241451992121647>",
  "CELESTIA_NAMETAG": "<a:tungsten_nametag:1567241539082526760>",
  "NAMETAG": "<a:tungsten_nametag:1567241539082526760>",
  "CELESTIA_NINJA": "<a:tungsten_ninja:1567241598260093050>",
  "NINJA": "<a:tungsten_ninja:1567241598260093050>",
  "CELESTIA_NOTEPAD": "<a:tungsten_notepad:1567241681911152733>",
  "CELESTIA_PACKAGE": "<a:tungsten_package:1567241719177543862>",
  "CELESTIA_PALETTE": "<a:tungsten_palette:1567241748613169344>",
  "PALETTE": "<a:tungsten_palette:1567241748613169344>",
  "CELESTIA_PARTY": "<a:tungsten_party:1567241769593339988>",
  "CELESTIA_PERSON": "<a:tungsten_person:1567241792150175834>",
  "CELESTIA_PIN": "<a:tungsten_pin:1567241810114379987>",
  "CELESTIA_PLANE": "<a:tungsten_plane:1567241829538336884>",
  "PLANE": "<a:tungsten_plane:1567241829538336884>",
  "CELESTIA_PLUS": "<a:tungsten_plus:1567241846453833840>",
  "CELESTIA_POINT": "<a:tungsten_point:1567241861293408391>",
  "POINT": "<a:tungsten_point:1567241861293408391>",
  "CELESTIA_QUESTION": "<a:tungsten_question:1567241882080116776>",
  "QUESTION": "<a:tungsten_question:1567241882080116776>",
  "CELESTIA_REFRESH": "<a:tungsten_refresh:1567241907116187658>",
  "CELESTIA_RICE": "<a:tungsten_rice:1567241928603336724>",
  "RICE": "<a:tungsten_rice:1567241928603336724>",
  "CELESTIA_RING": "<a:tungsten_ring:1567241949461618768>",
  "RING": "<a:tungsten_ring:1567241949461618768>",
  "CELESTIA_ROCKET": "<a:tungsten_rocket:1567241971804798976>",
  "CELESTIA_SATELLITE": "<a:tungsten_satellite:1567241994928005137>",
  "SATELLITE": "<a:tungsten_satellite:1567241994928005137>",
  "CELESTIA_SAVE": "<a:tungsten_save:1567242015283085507>",
  "SAVE": "<a:tungsten_save:1567242015283085507>",
  "CELESTIA_SCALES": "<a:tungsten_scales:1567242041098895521>",
  "SCALES": "<a:tungsten_scales:1567242041098895521>",
  "CELESTIA_SCROLL": "<a:tungsten_scroll:1567242059708899381>",
  "SCROLL": "<a:tungsten_scroll:1567242059708899381>",
  "CELESTIA_SEARCH": "<a:tungsten_search:1567242081167216771>",
  "CELESTIA_SHIELD": "<a:tungsten_shield:1567242104923627574>",
  "CELESTIA_SHRUG": "<a:tungsten_shrug:1567242138323001384>",
  "SHRUG": "<a:tungsten_shrug:1567242138323001384>",
  "CELESTIA_SIREN": "<a:tungsten_siren:1567242157725712555>",
  "CELESTIA_SKULL": "<a:tungsten_skull:1567242182836883486>",
  "SKULL": "<a:tungsten_skull:1567242182836883486>",
  "CELESTIA_SLOTS": "<a:tungsten_slots:1567242206266527956>",
  "SLOTS": "<a:tungsten_slots:1567242206266527956>",
  "CELESTIA_SOUND": "<a:tungsten_sound:1567242242127568958>",
  "CELESTIA_SPARKLE": "<a:tungsten_sparkle:1567242264311369839>",
  "CELESTIA_STAR": "<a:tungsten_star:1567242331785138238>",
  "CELESTIA_STOP": "<a:tungsten_stop:1567242365335511121>",
  "STOP": "<a:tungsten_stop:1567242365335511121>",
  "CELESTIA_STOPWATCH": "<a:tungsten_stopwatch:1567242453562687558>",
  "CELESTIA_SUCCESS": "<a:tungsten_success:1567242523468890274>",
  "CELESTIA_SUN": "<a:tungsten_sun:1567242622701932604>",
  "SUN": "<a:tungsten_sun:1567242622701932604>",
  "CELESTIA_SWEEP": "<a:tungsten_sweep:1567242656281657414>",
  "CELESTIA_SWORDS": "<a:tungsten_swords:1567242677819277352>",
  "CELESTIA_TAG": "<a:tungsten_tag:1567242698904047691>",
  "CELESTIA_TARGET": "<a:tungsten_target:1567242733997789205>",
  "CELESTIA_TERMINAL": "<a:tungsten_terminal:1567242755040878664>",
  "CELESTIA_TICK": "<a:tungsten_tick:1567242779908636802>",
  "CELESTIA_TICKET": "<a:tungsten_ticket:1567242811961770155>",
  "CELESTIA_TOOLS": "<a:tungsten_tools:1567242831834124431>",
  "CELESTIA_TOOTH": "<a:tungsten_tooth:1567242851480375296>",
  "TOOTH": "<a:tungsten_tooth:1567242851480375296>",
  "CELESTIA_TOP": "<a:tungsten_top:1567242867846680718>",
  "TOP": "<a:tungsten_top:1567242867846680718>",
  "CELESTIA_TRASH": "<a:tungsten_trash:1567242891276062872>",
  "CELESTIA_TROPHY": "<a:tungsten_trophy:1567242918446501939>",
  "CELESTIA_TV": "<a:tungsten_tv:1567242943197224960>",
  "TV": "<a:tungsten_tv:1567242943197224960>",
  "CELESTIA_UI_APPOINT": "<a:tungsten_ui_appoint:1567242963359375450>",
  "UI_APPOINT": "<a:tungsten_ui_appoint:1567242963359375450>",
  "CELESTIA_UI_ASSIGN": "<a:tungsten_ui_assign:1567242984397742250>",
  "UI_ASSIGN": "<a:tungsten_ui_assign:1567242984397742250>",
  "CELESTIA_UI_BACKUP_DB": "<a:tungsten_ui_backup_db:1567243012629729341>",
  "UI_BACKUP_DB": "<a:tungsten_ui_backup_db:1567243012629729341>",
  "CELESTIA_UI_CHANNEL_TOOLS": "<a:tungsten_ui_channel_tools:1567243046951854130>",
  "UI_CHANNEL_TOOLS": "<a:tungsten_ui_channel_tools:1567243046951854130>",
  "CELESTIA_UI_CHECK_RANK": "<a:tungsten_ui_check_rank:1567243080464335058>",
  "UI_CHECK_RANK": "<a:tungsten_ui_check_rank:1567243080464335058>",
  "CELESTIA_UI_COMPLETE_VERIFY": "<a:tungsten_ui_complete_verify:1567243101477806101>",
  "UI_COMPLETE_VERIFY": "<a:tungsten_ui_complete_verify:1567243101477806101>",
  "CELESTIA_UI_D10M": "<a:tungsten_ui_d10m:1567243132008136765>",
  "UI_D10M": "<a:tungsten_ui_d10m:1567243132008136765>",
  "CELESTIA_UI_D1D": "<a:tungsten_ui_d1d:1567243179269423157>",
  "UI_D1D": "<a:tungsten_ui_d1d:1567243179269423157>",
  "CELESTIA_UI_D1H": "<a:tungsten_ui_d1h:1567243251767971951>",
  "UI_D1H": "<a:tungsten_ui_d1h:1567243251767971951>",
  "CELESTIA_UI_D1W": "<a:tungsten_ui_d1w:1567243278917836991>",
  "UI_D1W": "<a:tungsten_ui_d1w:1567243278917836991>",
  "CELESTIA_UI_D5M": "<a:tungsten_ui_d5m:1567243350279725106>",
  "UI_D5M": "<a:tungsten_ui_d5m:1567243350279725106>",
  "CELESTIA_UI_DAILY_USAGE": "<a:tungsten_ui_daily_usage:1567243371603296270>",
  "UI_DAILY_USAGE": "<a:tungsten_ui_daily_usage:1567243371603296270>",
  "CELESTIA_UI_DISABLE_ALL": "<a:tungsten_ui_disable_all:1567243443338485862>",
  "UI_DISABLE_ALL": "<a:tungsten_ui_disable_all:1567243443338485862>",
  "CELESTIA_UI_DISCONNECT": "<a:tungsten_ui_disconnect:1567243506072682706>",
  "UI_DISCONNECT": "<a:tungsten_ui_disconnect:1567243506072682706>",
  "CELESTIA_UI_DISMISS": "<a:tungsten_ui_dismiss:1567243549555036200>",
  "UI_DISMISS": "<a:tungsten_ui_dismiss:1567243549555036200>",
  "CELESTIA_UI_DM_TEST": "<a:tungsten_ui_dm_test:1567243572002951178>",
  "UI_DM_TEST": "<a:tungsten_ui_dm_test:1567243572002951178>",
  "CELESTIA_UI_EDIT_NICK": "<a:tungsten_ui_edit_nick:1567243591686823967>",
  "UI_EDIT_NICK": "<a:tungsten_ui_edit_nick:1567243591686823967>",
  "CELESTIA_UI_ENABLE_ALL": "<a:tungsten_ui_enable_all:1567243610716508202>",
  "UI_ENABLE_ALL": "<a:tungsten_ui_enable_all:1567243610716508202>",
  "CELESTIA_UI_EVENTS": "<a:tungsten_ui_events:1567243642094092323>",
  "UI_EVENTS": "<a:tungsten_ui_events:1567243642094092323>",
  "CELESTIA_UI_FORFEIT": "<a:tungsten_ui_forfeit:1567243664613314610>",
  "UI_FORFEIT": "<a:tungsten_ui_forfeit:1567243664613314610>",
  "CELESTIA_UI_HIDE": "<a:tungsten_ui_hide:1567243688143487107>",
  "UI_HIDE": "<a:tungsten_ui_hide:1567243688143487107>",
  "CELESTIA_UI_HIDE_VC": "<a:tungsten_ui_hide_vc:1567243710075371651>",
  "UI_HIDE_VC": "<a:tungsten_ui_hide_vc:1567243710075371651>",
  "CELESTIA_UI_INSTALL": "<a:tungsten_ui_install:1567243737363386509>",
  "UI_INSTALL": "<a:tungsten_ui_install:1567243737363386509>",
  "CELESTIA_UI_INVITE_ADMIN": "<a:tungsten_ui_invite_admin:1567243760079741052>",
  "UI_INVITE_ADMIN": "<a:tungsten_ui_invite_admin:1567243760079741052>",
  "CELESTIA_UI_INVITE_STD": "<a:tungsten_ui_invite_std:1567243779495305246>",
  "UI_INVITE_STD": "<a:tungsten_ui_invite_std:1567243779495305246>",
  "CELESTIA_UI_JOIN_SUPPORT": "<a:tungsten_ui_join_support:1567243801343299704>",
  "UI_JOIN_SUPPORT": "<a:tungsten_ui_join_support:1567243801343299704>",
  "CELESTIA_UI_JUMP": "<a:tungsten_ui_jump:1567243825028538530>",
  "UI_JUMP": "<a:tungsten_ui_jump:1567243825028538530>",
  "CELESTIA_UI_LB_HISTORY": "<a:tungsten_ui_lb_history:1567243859229147236>",
  "UI_LB_HISTORY": "<a:tungsten_ui_lb_history:1567243859229147236>",
  "CELESTIA_UI_LEVELING": "<a:tungsten_ui_leveling:1567243886294737016>",
  "UI_LEVELING": "<a:tungsten_ui_leveling:1567243886294737016>",
  "CELESTIA_UI_LIST": "<a:tungsten_ui_list:1567243909707604059>",
  "UI_LIST": "<a:tungsten_ui_list:1567243909707604059>",
  "CELESTIA_UI_LOCK_VC": "<a:tungsten_ui_lock_vc:1567243939503931611>",
  "UI_LOCK_VC": "<a:tungsten_ui_lock_vc:1567243939503931611>",
  "CELESTIA_UI_LOCKDOWN": "<a:tungsten_ui_lockdown:1567243966150082580>",
  "UI_LOCKDOWN": "<a:tungsten_ui_lockdown:1567243966150082580>",
  "CELESTIA_UI_MANAGE": "<a:tungsten_ui_manage:1567243992435920926>",
  "UI_MANAGE": "<a:tungsten_ui_manage:1567243992435920926>",
  "CELESTIA_UI_MUTE_ALL": "<a:tungsten_ui_mute_all:1567244037264506951>",
  "UI_MUTE_ALL": "<a:tungsten_ui_mute_all:1567244037264506951>",
  "CELESTIA_UI_N1": "<a:tungsten_ui_n1:1567244083447996537>",
  "UI_N1": "<a:tungsten_ui_n1:1567244083447996537>",
  "CELESTIA_UI_N2": "<a:tungsten_ui_n2:1567244128704659548>",
  "UI_N2": "<a:tungsten_ui_n2:1567244128704659548>",
  "CELESTIA_UI_N3": "<a:tungsten_ui_n3:1567244152553603203>",
  "UI_N3": "<a:tungsten_ui_n3:1567244152553603203>",
  "CELESTIA_UI_N4": "<a:tungsten_ui_n4:1567244239912575056>",
  "UI_N4": "<a:tungsten_ui_n4:1567244239912575056>",
  "CELESTIA_UI_N5": "<a:tungsten_ui_n5:1567244324213755965>",
  "UI_N5": "<a:tungsten_ui_n5:1567244324213755965>",
  "CELESTIA_UI_N6": "<a:tungsten_ui_n6:1567244344866639972>",
  "UI_N6": "<a:tungsten_ui_n6:1567244344866639972>",
  "CELESTIA_UI_N7": "<a:tungsten_ui_n7:1567244425057411202>",
  "UI_N7": "<a:tungsten_ui_n7:1567244425057411202>",
  "CELESTIA_UI_OFF": "<a:tungsten_ui_off:1567244478178402347>",
  "UI_OFF": "<a:tungsten_ui_off:1567244478178402347>",
  "CELESTIA_UI_ON": "<a:tungsten_ui_on:1567244543546630266>",
  "UI_ON": "<a:tungsten_ui_on:1567244543546630266>",
  "CELESTIA_UI_OPEN": "<a:tungsten_ui_open:1567244565159743488>",
  "UI_OPEN": "<a:tungsten_ui_open:1567244565159743488>",
  "CELESTIA_UI_OVERVIEW": "<a:tungsten_ui_overview:1567244587137769573>",
  "UI_OVERVIEW": "<a:tungsten_ui_overview:1567244587137769573>",
  "CELESTIA_UI_P10": "<a:tungsten_ui_p10:1567244612081553568>",
  "UI_P10": "<a:tungsten_ui_p10:1567244612081553568>",
  "CELESTIA_UI_P100": "<a:tungsten_ui_p100:1567244632121671763>",
  "UI_P100": "<a:tungsten_ui_p100:1567244632121671763>",
  "CELESTIA_UI_P25": "<a:tungsten_ui_p25:1567244653416161343>",
  "UI_P25": "<a:tungsten_ui_p25:1567244653416161343>",
  "CELESTIA_UI_P50": "<a:tungsten_ui_p50:1567244676057006090>",
  "UI_P50": "<a:tungsten_ui_p50:1567244676057006090>",
  "CELESTIA_UI_PAPER": "<a:tungsten_ui_paper:1567244704989454378>",
  "UI_PAPER": "<a:tungsten_ui_paper:1567244704989454378>",
  "CELESTIA_UI_PERKS": "<a:tungsten_ui_perks:1567244732160147549>",
  "UI_PERKS": "<a:tungsten_ui_perks:1567244732160147549>",
  "CELESTIA_UI_PRESETS": "<a:tungsten_ui_presets:1567244762405150832>",
  "UI_PRESETS": "<a:tungsten_ui_presets:1567244762405150832>",
  "CELESTIA_UI_PULSE": "<a:tungsten_ui_pulse:1567244779249729658>",
  "UI_PULSE": "<a:tungsten_ui_pulse:1567244779249729658>",
  "CELESTIA_UI_PURGE_ALL": "<a:tungsten_ui_purge_all:1567244800946606170>",
  "UI_PURGE_ALL": "<a:tungsten_ui_purge_all:1567244800946606170>",
  "CELESTIA_UI_PURGE_BOTS": "<a:tungsten_ui_purge_bots:1567244820274225244>",
  "UI_PURGE_BOTS": "<a:tungsten_ui_purge_bots:1567244820274225244>",
  "CELESTIA_UI_QUICKPUNISH": "<a:tungsten_ui_quickpunish:1567244834576801813>",
  "UI_QUICKPUNISH": "<a:tungsten_ui_quickpunish:1567244834576801813>",
  "CELESTIA_UI_QUIT": "<a:tungsten_ui_quit:1567244850779258981>",
  "UI_QUIT": "<a:tungsten_ui_quit:1567244850779258981>",
  "CELESTIA_UI_RANK": "<a:tungsten_ui_rank:1567244880005038184>",
  "UI_RANK": "<a:tungsten_ui_rank:1567244880005038184>",
  "CELESTIA_UI_REDEEM": "<a:tungsten_ui_redeem:1567244905896616090>",
  "UI_REDEEM": "<a:tungsten_ui_redeem:1567244905896616090>",
  "CELESTIA_UI_REMOVE_TIMEOUT": "<a:tungsten_ui_remove_timeout:1567244927346155600>",
  "UI_REMOVE_TIMEOUT": "<a:tungsten_ui_remove_timeout:1567244927346155600>",
  "CELESTIA_UI_RESET": "<a:tungsten_ui_reset:1567244948041113621>",
  "UI_RESET": "<a:tungsten_ui_reset:1567244948041113621>",
  "CELESTIA_UI_REVOKE": "<a:tungsten_ui_revoke:1567244971436679319>",
  "UI_REVOKE": "<a:tungsten_ui_revoke:1567244971436679319>",
  "CELESTIA_UI_ROCK": "<a:tungsten_ui_rock:1567244992609517809>",
  "UI_ROCK": "<a:tungsten_ui_rock:1567244992609517809>",
  "CELESTIA_UI_ROLE_ADD": "<a:tungsten_ui_role_add:1567245019587411968>",
  "UI_ROLE_ADD": "<a:tungsten_ui_role_add:1567245019587411968>",
  "CELESTIA_UI_ROLE_REMOVE": "<a:tungsten_ui_role_remove:1567245052009255103>",
  "UI_ROLE_REMOVE": "<a:tungsten_ui_role_remove:1567245052009255103>",
  "CELESTIA_UI_ROLES_NICK": "<a:tungsten_ui_roles_nick:1567245091091910751>",
  "UI_ROLES_NICK": "<a:tungsten_ui_roles_nick:1567245091091910751>",
  "CELESTIA_UI_RULES": "<a:tungsten_ui_rules:1567245114655641680>",
  "UI_RULES": "<a:tungsten_ui_rules:1567245114655641680>",
  "CELESTIA_UI_SCISSORS": "<a:tungsten_ui_scissors:1567245155545780484>",
  "UI_SCISSORS": "<a:tungsten_ui_scissors:1567245155545780484>",
  "CELESTIA_UI_SCORE": "<a:tungsten_ui_score:1567245190027288709>",
  "UI_SCORE": "<a:tungsten_ui_score:1567245190027288709>",
  "CELESTIA_UI_SERVER_STATUS": "<a:tungsten_ui_server_status:1567245256393625651>",
  "UI_SERVER_STATUS": "<a:tungsten_ui_server_status:1567245256393625651>",
  "CELESTIA_UI_TELEMETRY": "<a:tungsten_ui_telemetry:1567245337486434404>",
  "UI_TELEMETRY": "<a:tungsten_ui_telemetry:1567245337486434404>",
  "CELESTIA_UI_TEST": "<a:tungsten_ui_test:1567245407510204466>",
  "UI_TEST": "<a:tungsten_ui_test:1567245407510204466>",
  "CELESTIA_UI_TICKET_CLOSE": "<a:tungsten_ui_ticket_close:1567245485117284382>",
  "UI_TICKET_CLOSE": "<a:tungsten_ui_ticket_close:1567245485117284382>",
  "CELESTIA_UI_TICKET_OPEN": "<a:tungsten_ui_ticket_open:1567245507699675276>",
  "UI_TICKET_OPEN": "<a:tungsten_ui_ticket_open:1567245507699675276>",
  "CELESTIA_UI_TIMEOUT": "<a:tungsten_ui_timeout:1567245550204493934>",
  "UI_TIMEOUT": "<a:tungsten_ui_timeout:1567245550204493934>",
  "CELESTIA_UI_UNASSIGN": "<a:tungsten_ui_unassign:1567245588783829053>",
  "UI_UNASSIGN": "<a:tungsten_ui_unassign:1567245588783829053>",
  "CELESTIA_UI_UNDO": "<a:tungsten_ui_undo:1567245669087846462>",
  "UI_UNDO": "<a:tungsten_ui_undo:1567245669087846462>",
  "CELESTIA_UI_UNHIDE": "<a:tungsten_ui_unhide:1567245749073354832>",
  "UI_UNHIDE": "<a:tungsten_ui_unhide:1567245749073354832>",
  "CELESTIA_UI_UNHIDE_VC": "<a:tungsten_ui_unhide_vc:1567245826777161792>",
  "UI_UNHIDE_VC": "<a:tungsten_ui_unhide_vc:1567245826777161792>",
  "CELESTIA_UI_UNLOCK_VC": "<a:tungsten_ui_unlock_vc:1567245856430620782>",
  "UI_UNLOCK_VC": "<a:tungsten_ui_unlock_vc:1567245856430620782>",
  "CELESTIA_UI_UNLOCKDOWN": "<a:tungsten_ui_unlockdown:1567245990556209313>",
  "UI_UNLOCKDOWN": "<a:tungsten_ui_unlockdown:1567245990556209313>",
  "CELESTIA_UI_UNMUTE_ALL": "<a:tungsten_ui_unmute_all:1567246118520365256>",
  "UI_UNMUTE_ALL": "<a:tungsten_ui_unmute_all:1567246118520365256>",
  "CELESTIA_UI_USER_ADD": "<a:tungsten_ui_user_add:1567246155706929205>",
  "UI_USER_ADD": "<a:tungsten_ui_user_add:1567246155706929205>",
  "CELESTIA_UI_USER_REMOVE": "<a:tungsten_ui_user_remove:1567246253467631616>",
  "UI_USER_REMOVE": "<a:tungsten_ui_user_remove:1567246253467631616>",
  "CELESTIA_UI_VERBOSE": "<a:tungsten_ui_verbose:1567246309063397548>",
  "UI_VERBOSE": "<a:tungsten_ui_verbose:1567246309063397548>",
  "CELESTIA_UI_VIEW_EMOJIS": "<a:tungsten_ui_view_emojis:1567246384980168774>",
  "UI_VIEW_EMOJIS": "<a:tungsten_ui_view_emojis:1567246384980168774>",
  "CELESTIA_UI_WELCOME_TEST": "<a:tungsten_ui_welcome_test:1567246433336299654>",
  "UI_WELCOME_TEST": "<a:tungsten_ui_welcome_test:1567246433336299654>",
  "CELESTIA_UNLOCK": "<a:tungsten_unlock:1567246515209117968>",
  "CELESTIA_USER": "<a:tungsten_user:1567246556778995802>",
  "CELESTIA_USERS": "<a:tungsten_users:1567246628606185502>",
  "CELESTIA_WARN": "<a:tungsten_warn:1567246685082746940>",
  "CELESTIA_WAVE": "<a:tungsten_wave:1567246763822158004>",
  "WAVE": "<a:tungsten_wave:1567246763822158004>",
  "CELESTIA_WIND": "<a:tungsten_wind:1567246820927602838>",
  "WIND": "<a:tungsten_wind:1567246820927602838>",
  "CELESTIA_ZZZ": "<a:tungsten_zzz:1567246871834132673>",
  "ZZZ": "<a:tungsten_zzz:1567246871834132673>",
  "CELESTIA_ACHIEVEMENTS": "<a:tungsten_achievements:1569329206842757271>",
  "CELESTIA_AN_STAGE_ABUSE": "<a:tungsten_an_stage_abuse:1569329214539173898>",
  "AN_STAGE_ABUSE": "<a:tungsten_an_stage_abuse:1569329214539173898>",
  "CELESTIA_ANALYTICS": "<a:tungsten_analytics:1569329222265208843>",
  "ANALYTICS": "<a:tungsten_analytics:1569329222265208843>",
  "CELESTIA_AUCTION": "<a:tungsten_auction:1569329230435590194>",
  "CELESTIA_AUTOSLOW": "<a:tungsten_autoslow:1569329238585118783>",
  "CELESTIA_AUTOTHREAD": "<a:tungsten_autothread:1569329247355539606>",
  "CELESTIA_BANS": "<a:tungsten_bans:1569329255693688853>",
  "BANS": "<a:tungsten_bans:1569329255693688853>",
  "CELESTIA_CALC": "<a:tungsten_calc:1569329263469924396>",
  "CELESTIA_CAT_CLANS": "<a:tungsten_cat_clans:1569329279701884928>",
  "CAT_CLANS": "<a:tungsten_cat_clans:1569329279701884928>",
  "CELESTIA_CAT_MODMAIL": "<a:tungsten_cat_modmail:1569329287692296213>",
  "CAT_MODMAIL": "<a:tungsten_cat_modmail:1569329287692296213>",
  "CELESTIA_CAT_PETS": "<a:tungsten_cat_pets:1569329296542011563>",
  "CAT_PETS": "<a:tungsten_cat_pets:1569329296542011563>",
  "CELESTIA_CAT_SOCIAL": "<a:tungsten_cat_social:1569329304196747418>",
  "CAT_SOCIAL": "<a:tungsten_cat_social:1569329304196747418>",
  "CELESTIA_CLAN": "<a:tungsten_clan:1569329312774103142>",
  "CELESTIA_CONVERT": "<a:tungsten_convert:1569329320802000956>",
  "CELESTIA_COUNTDOWN": "<a:tungsten_countdown:1569329328838152274>",
  "COUNTDOWN": "<a:tungsten_countdown:1569329328838152274>",
  "CELESTIA_DISCORDPOLL": "<a:tungsten_discordpoll:1569329347171590216>",
  "CELESTIA_ENCODE": "<a:tungsten_encode:1569329355111538820>",
  "CELESTIA_EVENT": "<a:tungsten_event:1569329363038638090>",
  "CELESTIA_EVIDENCE": "<a:tungsten_evidence:1569329371850874921>",
  "CELESTIA_FARM": "<a:tungsten_farm:1569329379975364628>",
  "CELESTIA_FEED": "<a:tungsten_feed:1569329388053467276>",
  "FEED": "<a:tungsten_feed:1569329388053467276>",
  "CELESTIA_FORUM": "<a:tungsten_forum:1569329396278370374>",
  "CELESTIA_GUILDSETTINGS": "<a:tungsten_guildsettings:1569329404558184562>",
  "GUILDSETTINGS": "<a:tungsten_guildsettings:1569329404558184562>",
  "CELESTIA_INTEGRATIONS": "<a:tungsten_integrations:1569329413110239292>",
  "INTEGRATIONS": "<a:tungsten_integrations:1569329413110239292>",
  "CELESTIA_LINKEDROLES": "<a:tungsten_linkedroles:1569329421352046592>",
  "LINKEDROLES": "<a:tungsten_linkedroles:1569329421352046592>",
  "CELESTIA_LOCKDOWN": "<a:tungsten_lockdown:1569329429174296697>",
  "CELESTIA_MACRO": "<a:tungsten_macro:1569329438586310706>",
  "MACRO": "<a:tungsten_macro:1569329438586310706>",
  "CELESTIA_MARRIAGE": "<a:tungsten_marriage:1569329446325063725>",
  "CELESTIA_MODMAIL": "<a:tungsten_modmail:1569329454952611870>",
  "MODMAIL": "<a:tungsten_modmail:1569329454952611870>",
  "CELESTIA_NATIVEAUTOMOD": "<a:tungsten_nativeautomod:1569329462921920542>",
  "NATIVEAUTOMOD": "<a:tungsten_nativeautomod:1569329462921920542>",
  "CELESTIA_NPM": "<a:tungsten_npm:1569329471373320352>",
  "NPM": "<a:tungsten_npm:1569329471373320352>",
  "CELESTIA_ONBOARDING": "<a:tungsten_onboarding:1569329479325585481>",
  "ONBOARDING": "<a:tungsten_onboarding:1569329479325585481>",
  "CELESTIA_OVERRIDE": "<a:tungsten_override:1569329487794143305>",
  "OVERRIDE": "<a:tungsten_override:1569329487794143305>",
  "CELESTIA_PANELBUILDER": "<a:tungsten_panelbuilder:1569329495809200158>",
  "CELESTIA_PASSWORD": "<a:tungsten_password:1569329504994852944>",
  "PASSWORD": "<a:tungsten_password:1569329504994852944>",
  "CELESTIA_PET": "<a:tungsten_pet:1569329513408634920>",
  "CELESTIA_POKEMON": "<a:tungsten_pokemon:1569329520966635581>",
  "POKEMON": "<a:tungsten_pokemon:1569329520966635581>",
  "CELESTIA_POLICY": "<a:tungsten_policy:1569329528851927131>",
  "CELESTIA_PRESENCE": "<a:tungsten_presence:1569329536875888711>",
  "PRESENCE": "<a:tungsten_presence:1569329536875888711>",
  "CELESTIA_PROFILE": "<a:tungsten_profile:1569329544819900416>",
  "PROFILE": "<a:tungsten_profile:1569329544819900416>",
  "CELESTIA_QUESTS": "<a:tungsten_quests:1569329552453533827>",
  "CELESTIA_REP": "<a:tungsten_rep:1569329560917381213>",
  "REP": "<a:tungsten_rep:1569329560917381213>",
  "CELESTIA_SERVERDOCTOR": "<a:tungsten_serverdoctor:1569329568471457898>",
  "CELESTIA_SETUP": "<a:tungsten_setup:1569329576490836098>",
  "SETUP": "<a:tungsten_setup:1569329576490836098>",
  "CELESTIA_SNOWFLAKE": "<a:tungsten_snowflake:1569329585487614105>",
  "CELESTIA_SOUNDBOARD": "<a:tungsten_soundboard:1569329593561780354>",
  "CELESTIA_STAGE": "<a:tungsten_stage:1569329601971224720>",
  "STAGE": "<a:tungsten_stage:1569329601971224720>",
  "CELESTIA_THREAD": "<a:tungsten_thread:1569329618928930846>",
  "THREAD": "<a:tungsten_thread:1569329618928930846>",
  "CELESTIA_TOURNAMENT": "<a:tungsten_tournament:1569329627057487993>",
  "CELESTIA_TRADE": "<a:tungsten_trade:1569329634733072495>",
  "CELESTIA_UI_BID": "<a:tungsten_ui_bid:1569329642609836154>",
  "UI_BID": "<a:tungsten_ui_bid:1569329642609836154>",
  "CELESTIA_UI_BRACKET": "<a:tungsten_ui_bracket:1569329652714184704>",
  "UI_BRACKET": "<a:tungsten_ui_bracket:1569329652714184704>",
  "CELESTIA_UI_HARVEST": "<a:tungsten_ui_harvest:1569329661148930230>",
  "UI_HARVEST": "<a:tungsten_ui_harvest:1569329661148930230>",
  "CELESTIA_UI_PLANT": "<a:tungsten_ui_plant:1569329669503717397>",
  "UI_PLANT": "<a:tungsten_ui_plant:1569329669503717397>",
  "CELESTIA_UI_TOGGLE_OFF": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "CELESTIA_UI_TOGGLE_ON": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "CELESTIA_UI_TRADE": "<a:tungsten_ui_trade:1569329692899680408>",
  "UI_TRADE": "<a:tungsten_ui_trade:1569329692899680408>",
  "CELESTIA_UI_WATER": "<a:tungsten_ui_water:1569329701409915022>",
  "UI_WATER": "<a:tungsten_ui_water:1569329701409915022>",
  "CELESTIA_UI_WIZARD_BACK": "<a:tungsten_ui_wizard_back:1569329709613850625>",
  "UI_WIZARD_BACK": "<a:tungsten_ui_wizard_back:1569329709613850625>",
  "CELESTIA_UI_WIZARD_FINISH": "<a:tungsten_ui_wizard_finish:1569329717243412595>",
  "UI_WIZARD_FINISH": "<a:tungsten_ui_wizard_finish:1569329717243412595>",
  "CELESTIA_UI_WIZARD_NEXT": "<a:tungsten_ui_wizard_next:1569329725405536328>",
  "UI_WIZARD_NEXT": "<a:tungsten_ui_wizard_next:1569329725405536328>",
  "CELESTIA_WATCHLIST": "<a:tungsten_watchlist:1569329733303541801>",
  "CELESTIA_WEBHOOK": "<a:tungsten_webhook:1569329741150949488>",
  "WEBHOOK": "<a:tungsten_webhook:1569329741150949488>",
  "CELESTIA_WELCOMESCREEN": "<a:tungsten_welcomescreen:1569329748486787085>",
  "CELESTIA_WHOIS": "<a:tungsten_whois:1569329756657160402>",
  "CELESTIA_WORDCOUNT": "<a:tungsten_wordcount:1569329764508893246>",
  "CELESTIA_WORKFLOW": "<a:tungsten_workflow:1569329772520018061>",
  "CELESTIA_WORLDCLOCK": "<a:tungsten_worldclock:1569329780229275668>",
  "CELESTIA_AN_MITIGATION": "<a:tungsten_an_ban:1567232483743895684>",
  "AN_MITIGATION": "<a:tungsten_an_ban:1567232483743895684>",
  "CELESTIA_CMD_VERIFICATION": "<a:tungsten_an_standard:1567233029233967106>",
  "CMD_VERIFICATION": "<a:tungsten_an_standard:1567233029233967106>",
  "CELESTIA_UI_INTEGRITY": "<a:tungsten_ui_complete_verify:1567243101477806101>",
  "UI_INTEGRITY": "<a:tungsten_ui_complete_verify:1567243101477806101>"
};

// Fallback tags

// Ensure all tungsten_ / TUNGSTEN_ keys and legacy celestia_ keys are accessible
for (const [k, v] of Object.entries(EMOJIS)) {
  if (k.startsWith("CELESTIA_")) {
    EMOJIS["TUNGSTEN_" + k.slice(9)] = v;
  } else if (k.startsWith("celestia_")) {
    EMOJIS["tungsten_" + k.slice(9)] = v;
  }
}

for (const item of BUILTIN_PACK) {
  if (item.name && item.discordTag) {
    EMOJIS[item.name] = item.discordTag;
    EMOJIS[item.name.toUpperCase()] = item.discordTag;
    if (item.name.startsWith("tungsten_")) {
      EMOJIS["celestia_" + item.name.slice(9)] = item.discordTag;
      EMOJIS["CELESTIA_" + item.name.slice(9).toUpperCase()] = item.discordTag;
    }
  }
}
const FALLBACKS = { ...EMOJIS };

// Unicode to Custom Animated Emoji mapping
const UNICODE_MAP = {
  "❌": "<a:tungsten_close:1567234632905138206>",
  "❌️": "<a:tungsten_close:1567234632905138206>",
  "✅": "<a:tungsten_success:1567242523468890274>",
  "✅️": "<a:tungsten_success:1567242523468890274>",
  "⚠️": "<a:tungsten_warn:1567246685082746940>",
  "⚠️️": "<a:tungsten_warn:1567246685082746940>",
  "🚨": "<a:tungsten_siren:1567242157725712555>",
  "🛡️": "<a:tungsten_shield:1567242104923627574>",
  "🛡": "<a:tungsten_shield:1567242104923627574>",
  "⚙️": "<a:tungsten_gear:1567239932970406012>",
  "⚙": "<a:tungsten_gear:1567239932970406012>",
  "👑": "<a:tungsten_crown:1567238355463176334>",
  "👑️": "<a:tungsten_crown:1567238355463176334>",
  "⚡": "<a:tungsten_bolt:1567233430570405968>",
  "⚡️": "<a:tungsten_bolt:1567233430570405968>",
  "🗑️": "<a:tungsten_trash:1567242891276062872>",
  "🗑": "<a:tungsten_trash:1567242891276062872>",
  "🔄": "<a:tungsten_refresh:1567241907116187658>",
  "➕": "<a:tungsten_plus:1567241846453833840>",
  "➖": "<a:tungsten_minus:1567241276057849856>",
  "🔒": "<a:tungsten_lock:1567241079030550668>",
  "🔓": "<a:tungsten_unlock:1567246515209117968>",
  "🔑": "<a:tungsten_key:1567240907684581492>",
  "🔍": "<a:tungsten_search:1567242081167216771>",
  "🔎": "<a:tungsten_search:1567242081167216771>",
  "📊": "<a:tungsten_chart:1567234342701367357>",
  "📈": "<a:tungsten_chart:1567234342701367357>",
  "🎮": "<a:tungsten_gamepad:1567239909985616063>",
  "💎": "<a:tungsten_diamond_small:1567238516855939283>",
  "💰": "<a:tungsten_moneybag:1567241334698541109>",
  "🪙": "<a:tungsten_coin:1567238316967985244>",
  "⭐": "<a:tungsten_star:1567242331785138238>",
  "🌟": "<a:tungsten_sparkle:1567242264311369839>",
  "✨": "<a:tungsten_sparkle:1567242264311369839>",
  "🎉": "<a:tungsten_party:1567241769593339988>",
  "🎁": "<a:tungsten_gift:1567240042563244072>",
  "🚀": "<a:tungsten_rocket:1567241971804798976>",
  "📦": "<a:tungsten_package:1567241719177543862>",
  "🎫": "<a:tungsten_ticket:1567242811961770155>",
  "📝": "<a:tungsten_memo:1567241226577780957>",
  "📋": "<a:tungsten_clipboard:1567234610176204900>",
  "📌": "<a:tungsten_pin:1567241810114379987>",
  "🏷️": "<a:tungsten_tag:1567242698904047691>",
  "🏷": "<a:tungsten_tag:1567242698904047691>",
  "🎯": "<a:tungsten_target:1567242733997789205>",
  "🔊": "<a:tungsten_sound:1567242242127568958>",
  "🔈": "<a:tungsten_sound:1567242242127568958>",
  "🔇": "<a:tungsten_mute:1567241451992121647>",
  "🎵": "<a:tungsten_music:1567241425328939110>",
  "🎶": "<a:tungsten_music:1567241425328939110>",
  "🎤": "<a:tungsten_mic:1567241257862832189>",
  "🎧": "<a:tungsten_headphones:1567240226789785730>",
  "💬": "<a:tungsten_chat:1567234399450177665>",
  "🤖": "<a:tungsten_bot:1567233522635247781>",
  "👤": "<a:tungsten_user:1567246556778995802>",
  "👥": "<a:tungsten_users:1567246628606185502>",
  "🟢": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "🔴": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "🔘": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "☑️": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "☑": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "🟩": "<a:tungsten_ui_toggle_on:1569329685110849576>",
  "🟥": "<a:tungsten_ui_toggle_off:1569329677187678368>",
  "🟡": "<a:tungsten_circle_yellow:1567234580690501693>",
  "⚪": "<a:tungsten_circle_white:1567234561799233547>",
  "⚔️": "<a:tungsten_swords:1567242677819277352>",
  "⚔": "<a:tungsten_swords:1567242677819277352>",
  "🔨": "<a:tungsten_hammer:1567240140277944350>",
  "🏆": "<a:tungsten_trophy:1567242918446501939>",
  "🥇": "<a:tungsten_medal_gold:1567241163453366472>",
  "🥈": "<a:tungsten_medal_silver:1567241205409128649>",
  "🥉": "<a:tungsten_medal_bronze:1567241129030582403>",
  "⏳": "<a:tungsten_hourglass:1567240660702986281>",
  "⏱️": "<a:tungsten_stopwatch:1567242453562687558>",
  "⏱": "<a:tungsten_stopwatch:1567242453562687558>",
  "⏰": "<a:tungsten_alarm:1567229471474585682>",
  "ℹ️": "<a:tungsten_info:1567240890748248084>",
  "ℹ": "<a:tungsten_info:1567240890748248084>",
  "❓": "<a:tungsten_question:1567241882080116776>",
  "👋": "<a:tungsten_wave:1567246763822158004>",
  "👻": "<a:tungsten_ghost:1567240021692518512>",
  "👁️": "<a:tungsten_eye:1567238862042833088>",
  "👁": "<a:tungsten_eye:1567238862042833088>",
  "👍": "<a:tungsten_success:1567242523468890274>",
  "👎": "<a:tungsten_close:1567234632905138206>",
  "🧑": "<a:tungsten_user:1567246556778995802>",
  "⏹️": "<a:tungsten_stop:1567242365335511121>",
  "⏹": "<a:tungsten_stop:1567242365335511121>",
  "🏠": "<a:tungsten_home:1567240545661620387>",
  "🔗": "<a:tungsten_link:1567241025813086210>",
  "◀️": "<a:tungsten_arrow_left:1567233111601844267>",
  "◀": "<a:tungsten_arrow_left:1567233111601844267>",
  "▶️": "<a:tungsten_arrow_right:1567233126143361135>",
  "▶": "<a:tungsten_arrow_right:1567233126143361135>",
  "📜": "<a:tungsten_scroll:1567242059708899381>",
  "👢": "<a:tungsten_boot:1567233502418575501>",
  "🕒": "<a:tungsten_stopwatch:1567242453562687558>",
  "📁": "<a:tungsten_cabinet:1567233617489297548>",
  "🚪": "<a:tungsten_door:1567238621432643794>",
  "📄": "<a:tungsten_memo:1567241226577780957>",
  "✂️": "<a:tungsten_sweep:1567242656281657414>",
  "✂": "<a:tungsten_sweep:1567242656281657414>",
  "🔁": "<a:tungsten_refresh:1567241907116187658>",
  "✖️": "<a:tungsten_close:1567234632905138206>",
  "✖": "<a:tungsten_close:1567234632905138206>",
  "↩️": "<a:tungsten_arrow_left:1567233111601844267>",
  "↩": "<a:tungsten_arrow_left:1567233111601844267>",
  "🔔": "<a:tungsten_bell:1567233405786132510>",
  "💵": "<a:tungsten_coin:1567238316967985244>",
  "🏦": "<a:tungsten_bank:1567233290656677924>",
  "🎭": "<a:tungsten_party:1567241769593339988>",
  "💸": "<a:tungsten_money_wings:1567241294408061024>",
  "💾": "<a:tungsten_save:1567242015283085507>",
  "🌐": "<a:tungsten_globe:1567240068253622433>",
  "🪨": "<a:tungsten_ui_rock:1567244992609517809>",
  "⏸️": "<a:tungsten_stop:1567242365335511121>",
  "⏸": "<a:tungsten_stop:1567242365335511121>",
  "💼": "<a:tungsten_briefcase:1567233568596295821>",
  "📅": "<a:tungsten_calendar:1567233642554458154>",
  "🎰": "<a:tungsten_slots:1567242206266527956>",
  "🏧": "<a:tungsten_atm:1567233228350300292>",
  "⚖️": "<a:tungsten_scales:1567242041098895521>",
  "⚖": "<a:tungsten_scales:1567242041098895521>",
  "🧹": "<a:tungsten_sweep:1567242656281657414>",
  "✈️": "<a:tungsten_plane:1567241837562167387>",
  "✈": "<a:tungsten_plane:1567241837562167387>",
  "🚫": "<a:tungsten_close:1567234632905138206>",
  "💳": "<a:tungsten_coin:1567238316967985244>",
  "🤝": "<a:tungsten_handshake:1567240212005060678>",
  "🦉": "<a:tungsten_search:1567242081167216771>",
  "🎖️": "<a:tungsten_medal_gold:1567241163453366472>",
  "🎖": "<a:tungsten_medal_gold:1567241163453366472>",
  "🏅": "<a:tungsten_medal_gold:1567241163453366472>",
  "🧠": "<a:tungsten_brain:1567233547843014696>",
  "👀": "<a:tungsten_eye:1567238862042833088>",
  "🤡": "<a:tungsten_party:1567241769593339988>",
  "🌈": "<a:tungsten_sparkles:1567242275988307968>",
  "👭": "<a:tungsten_users:1567246628606185502>",
  "🔥": "<a:tungsten_bolt:1567233430570405968>",
  "❤️": "<a:tungsten_heart_sparkle:1567240244795932785>",
  "❤": "<a:tungsten_heart_sparkle:1567240244795932785>",
  "💖": "<a:tungsten_heart_sparkle:1567240244795932785>",
  "💕": "<a:tungsten_heart_sparkle:1567240244795932785>",
  "💞": "<a:tungsten_heart_sparkle:1567240244795932785>",
  "💔": "<a:tungsten_close:1567234632905138206>",
  "💛": "<a:tungsten_circle_yellow:1567234580690501693>",
  "🧡": "<a:tungsten_circle_yellow:1567234580690501693>",
  "💻": "<a:tungsten_cmd_eval:1567235252873728073>",
  "🖥️": "<a:tungsten_cmd_eval:1567235252873728073>",
  "🖥": "<a:tungsten_cmd_eval:1567235252873728073>",
  "📱": "<a:tungsten_link:1567241025813086210>",
  "📡": "<a:tungsten_link:1567241025813086210>",
  "✉️": "<a:tungsten_chat:1567234399450177665>",
  "✉": "<a:tungsten_chat:1567234399450177665>",
  "📨": "<a:tungsten_chat:1567234399450177665>",
  "📬": "<a:tungsten_chat:1567234399450177665>",
  "✏️": "<a:tungsten_memo:1567241226577780957>",
  "✏": "<a:tungsten_memo:1567241226577780957>",
  "📖": "<a:tungsten_book:1567233481237336114>",
  "📚": "<a:tungsten_book:1567233481237336114>",
  "🎲": "<a:tungsten_gamepad:1567239909985616063>",
  "🎯": "<a:tungsten_target:1567242733997789205>",
  "🔮": "<a:tungsten_sparkle:1567242264311369839>",
  "🎱": "<a:tungsten_cmd_8ball:1567234676572164106>",
  "💨": "<a:tungsten_sweep:1567242656281657414>",
  "🏹": "<a:tungsten_target:1567242733997789205>",
  "🎒": "<a:tungsten_briefcase:1567233568596295821>",
  "👔": "<a:tungsten_user:1567246556778995802>",
  "🏙️": "<a:tungsten_castle:1567234320953897042>",
  "🏙": "<a:tungsten_castle:1567234320953897042>",
  "🏢": "<a:tungsten_bank:1567233290656677924>",
  "🏰": "<a:tungsten_castle:1567234320953897042>",
  "🥷": "<a:tungsten_ghost:1567240021692518512>",
  "💀": "<a:tungsten_close:1567234632905138206>",
  "😇": "<a:tungsten_sparkle:1567242264311369839>",
  "😊": "<a:tungsten_wave:1567246763822158004>",
  "😂": "<a:tungsten_party:1567241769593339988>",
  "🧐": "<a:tungsten_search:1567242081167216771>",
  "🤪": "<a:tungsten_party:1567241769593339988>",
  "🤫": "<a:tungsten_mute:1567241451992121647>",
  "🤬": "<a:tungsten_warn:1567246685082746940>",
  "🎈": "<a:tungsten_party:1567241769593339988>",
  "💡": "<a:tungsten_bolt:1567233430570405968>",
  "🎓": "<a:tungsten_crown:1567238355463176334>",
  "🔬": "<a:tungsten_search:1567242081167216771>",
  "🌌": "<a:tungsten_sparkles:1567242275988307968>",
  "🌸": "<a:tungsten_sparkle:1567242264311369839>",
  "☕": "<a:tungsten_coin:1567238316967985244>",
  "☕️": "<a:tungsten_coin:1567238316967985244>",
  "🎸": "<a:tungsten_party:1567241769593339988>",
  "🕊️": "<a:tungsten_wave:1567246763822158004>",
  "🕊": "<a:tungsten_wave:1567246763822158004>",
  "🌤️": "<a:tungsten_globe:1567240068253622433>",
  "🌤": "<a:tungsten_globe:1567240068253622433>",
  "☁️": "<a:tungsten_globe:1567240068253622433>",
  "☁": "<a:tungsten_globe:1567240068253622433>",
  "🌡️": "<a:tungsten_stopwatch:1567242453562687558>",
  "🌡": "<a:tungsten_stopwatch:1567242453562687558>",
  "💧": "<a:tungsten_coin:1567238316967985244>",
  "🔟": "<a:tungsten_trophy:1567242918446501939>",
  "🎙️": "<a:tungsten_sound:1567242242127568958>",
  "🎙": "<a:tungsten_sound:1567242242127568958>",
  "🔕": "<a:tungsten_mute:1567241451992121647>",
  "🔐": "<a:tungsten_lock:1567241079030550668>",
  "🗒️": "<a:tungsten_memo:1567241226577780957>",
  "🗒": "<a:tungsten_memo:1567241226577780957>",
  "🏁": "<a:tungsten_flag:1567239855581564999>",
  "🚩": "<a:tungsten_flag:1567239855581564999>",
  "🎨": "<a:tungsten_party:1567241769593339988>",
  "🛠️": "<a:tungsten_gear:1567239932970406012>",
  "🛠": "<a:tungsten_gear:1567239932970406012>",
  "🐛": "<a:tungsten_warn:1567246685082746940>",
  "🐞": "<a:tungsten_warn:1567246685082746940>",
  "📸": "<a:tungsten_clapper:1567234503728959559>",
  "🎞️": "<a:tungsten_clapper:1567234503728959559>",
  "🎞": "<a:tungsten_clapper:1567234503728959559>",
  "📢": "<a:tungsten_sound:1567242242127568958>",
  "📣": "<a:tungsten_sound:1567242242127568958>",
  "🔞": "<a:tungsten_an_nsfw:1567230489994334338>",
  "⛔": "<a:tungsten_close:1567234632905138206>",
  "🛑": "<a:tungsten_close:1567234632905138206>",
  "❄️": "<a:tungsten_sparkle:1567242264311369839>",
  "❄": "<a:tungsten_sparkle:1567242264311369839>",
  "🎟️": "<a:tungsten_ticket:1567242817208586321>",
  "🎟": "<a:tungsten_ticket:1567242817208586321>",
  "🎂": "<a:tungsten_party:1567241769593339988>",
  "🚧": "<a:tungsten_warn:1567246685082746940>",
  "📉": "<a:tungsten_chart:1567234342701367357>",
  "📑": "<a:tungsten_scroll:1567242059708899381>",
  "🧮": "<a:tungsten_calc:1567233630650990664>",
  "🗄️": "<a:tungsten_cabinet:1567233617489297548>",
  "🗄": "<a:tungsten_cabinet:1567233617489297548>",
  "🧾": "<a:tungsten_memo:1567241226577780957>",
  "📍": "<a:tungsten_pin:1567241810114379987>",
  "🍒": "<a:tungsten_cherry:1567234538831089674>",
  "🍋": "<a:tungsten_coin:1567238316967985244>",
  "🍇": "<a:tungsten_coin:1567238316967985244>",
  "✔": "<a:tungsten_success:1567242523468890274>",
  "✔️": "<a:tungsten_success:1567242523468890274>",
  "❯": "<a:tungsten_arrow_right:1567233126143361135>",
  "➔": "<a:tungsten_arrow_right:1567233126143361135>"
};

const SORTED_UNICODE_KEYS = Object.keys(UNICODE_MAP).sort((a, b) => b.length - a.length);

const EMOJI_MAP = new Map(BUILTIN_PACK.map(e => [e.name.toLowerCase(), e]));

let emojiFallbacks = null;
try {
  emojiFallbacks = require('../data/emojiFallbacks');
} catch (_) {
  emojiFallbacks = null;
}

const CANONICAL_ALIASES = {
  tungsten_delete: 'tungsten_trash',
  tungsten_voice: 'tungsten_sound',
  tungsten_sparkles: 'tungsten_sparkle',
  tungsten_commands: 'tungsten_menu',
  tungsten_zap: 'tungsten_bolt',
  tungsten_tada: 'tungsten_party',
  tungsten_role: 'tungsten_cmd_customrole',
  tungsten_roles: 'tungsten_cat_roles',
  tungsten_giveaway: 'tungsten_cmd_giveaway',
  tungsten_vanity: 'tungsten_cmd_vanityguard',
  tungsten_vanityroles: 'tungsten_cmd_vanityguard',
  tungsten_help: 'tungsten_cmd_help',
  tungsten_check: 'tungsten_success',
  tungsten_cross: 'tungsten_close',
  tungsten_arrowleft: 'tungsten_arrow_left',
  tungsten_arrowright: 'tungsten_arrow_right',
  tungsten_warning: 'tungsten_warn',
  tungsten_door: 'tungsten_door',

  delete: 'tungsten_trash',
  voice: 'tungsten_sound',
  sparkles: 'tungsten_sparkle',
  commands: 'tungsten_menu',
  zap: 'tungsten_bolt',
  tada: 'tungsten_party',
  role: 'tungsten_cmd_customrole',
  roles: 'tungsten_cat_roles',
  giveaway: 'tungsten_cmd_giveaway',
  vanity: 'tungsten_cmd_vanityguard',
  vanityroles: 'tungsten_cmd_vanityguard',
  help: 'tungsten_cmd_help',
  check: 'tungsten_success',
  cross: 'tungsten_close',
  arrowleft: 'tungsten_arrow_left',
  arrowright: 'tungsten_arrow_right',
  warning: 'tungsten_warn',
  door: 'tungsten_door',

  celestia_delete: 'celestia_trash',
  celestia_voice: 'celestia_sound',
  celestia_sparkles: 'celestia_sparkle',
  celestia_commands: 'celestia_menu',
  celestia_zap: 'celestia_bolt',
  celestia_tada: 'celestia_party',
  celestia_role: 'celestia_cmd_customrole',
  celestia_roles: 'celestia_cat_roles',
  celestia_giveaway: 'celestia_cmd_giveaway',
  celestia_vanity: 'celestia_cmd_vanityguard',
  celestia_vanityroles: 'celestia_cmd_vanityguard',
  celestia_help: 'celestia_cmd_help',
  celestia_check: 'celestia_success',
  celestia_cross: 'celestia_close',
  celestia_arrowleft: 'celestia_arrow_left',
  celestia_arrowright: 'celestia_arrow_right',
  celestia_warning: 'celestia_warn',
  celestia_door: 'celestia_door'
};

function getCustomEmojiMap() {
  return EMOJIS;
}

/**
 * Dynamic Custom Emoji Resolver
 */
function resolveEmoji(clientOrGuild, name) {
  if (name === undefined && typeof clientOrGuild === 'string') {
    name = clientOrGuild;
    clientOrGuild = null;
  }
  if (!name) return null;
  const rawKey = String(name).toLowerCase();
  let key = rawKey.replace(/[^a-z0-9_]/g, '');
  if (!key) return null;

  if (CANONICAL_ALIASES[key]) {
    key = CANONICAL_ALIASES[key];
  } else if (key.startsWith('celestia_')) {
    const base = key.slice(9);
    if (CANONICAL_ALIASES['tungsten_' + base]) key = CANONICAL_ALIASES['tungsten_' + base];
    else if (CANONICAL_ALIASES[base]) key = CANONICAL_ALIASES[base];
    else key = 'tungsten_' + base;
  } else if (key.startsWith('tungsten_')) {
    const base = key.slice(9);
    if (CANONICAL_ALIASES['tungsten_' + base]) key = CANONICAL_ALIASES['tungsten_' + base];
    else if (CANONICAL_ALIASES[base]) key = CANONICAL_ALIASES[base];
  } else if (CANONICAL_ALIASES['tungsten_' + key]) {
    key = CANONICAL_ALIASES['tungsten_' + key];
  } else if (CANONICAL_ALIASES['celestia_' + key]) {
    key = CANONICAL_ALIASES['celestia_' + key];
  }

  // If key is still celestia_*, convert to tungsten_
  if (key.startsWith('celestia_')) {
    key = 'tungsten_' + key.slice(9);
  }

  if (key === 'loading' || key === 'spinner') {
    return EMOJIS.LOADING || EMOJIS.TUNGSTEN_LOADING || EMOJIS.CELESTIA_LOADING || null;
  }
  if (key === 'refresh') {
    return EMOJIS.REFRESH || EMOJIS.TUNGSTEN_REFRESH || EMOJIS.CELESTIA_REFRESH || null;
  }

  const strippedKey = key.startsWith('tungsten_') ? key.slice(9) : (key.startsWith('celestia_') ? key.slice(9) : key);

  if (clientOrGuild) {
    const client = clientOrGuild.client || clientOrGuild;
    const emojiStore = client.tungstenEmojis || client.celestiaEmojis;
    if (emojiStore) {
      if (emojiStore.has(key)) return emojiStore.get(key).toString();
      if (emojiStore.has('tungsten_' + strippedKey)) return emojiStore.get('tungsten_' + strippedKey).toString();
      if (emojiStore.has('celestia_' + strippedKey)) return emojiStore.get('celestia_' + strippedKey).toString();
      if (emojiStore.has(strippedKey)) return emojiStore.get(strippedKey).toString();
    }
    const emojisCache = clientOrGuild.emojis?.cache || clientOrGuild.guild?.emojis?.cache || client.emojis?.cache;
    if (emojisCache) {
      const found = emojisCache.find(e => {
        const en = e.name.toLowerCase();
        return en === key ||
               en === 'tungsten_' + strippedKey ||
               en === 'celestia_' + strippedKey ||
               en === strippedKey ||
               en === 'cel_' + strippedKey;
      });
      if (found) return found.toString();
    }
  }

  const meta = EMOJI_MAP.get(key) ||
               EMOJI_MAP.get('tungsten_' + strippedKey) ||
               EMOJI_MAP.get('celestia_' + strippedKey) ||
               EMOJI_MAP.get(strippedKey) ||
               EMOJI_MAP.get('cel_' + strippedKey);
  if (meta && meta.discordTag) {
    return meta.discordTag;
  }

  if (E[key]) return E[key];
  if (E['tungsten_' + strippedKey]) return E['tungsten_' + strippedKey];
  if (E['celestia_' + strippedKey]) return E['celestia_' + strippedKey];
  if (E[strippedKey]) return E[strippedKey];

  const upperKey = name.toUpperCase().replace(/[^A-Z0-9_]/g, '');
  const upperStripped = strippedKey.toUpperCase();
  if (EMOJIS[upperKey]) return EMOJIS[upperKey];
  if (EMOJIS['TUNGSTEN_' + upperStripped]) return EMOJIS['TUNGSTEN_' + upperStripped];
  if (EMOJIS['CELESTIA_' + upperStripped]) return EMOJIS['CELESTIA_' + upperStripped];
  if (EMOJIS[upperStripped]) return EMOJIS[upperStripped];

  if (emojiFallbacks) {
    if (emojiFallbacks[key]) return emojiFallbacks[key];
    if (emojiFallbacks['tungsten_' + strippedKey]) return emojiFallbacks['tungsten_' + strippedKey];
    if (emojiFallbacks['celestia_' + strippedKey]) return emojiFallbacks['celestia_' + strippedKey];
    if (emojiFallbacks[strippedKey]) return emojiFallbacks[strippedKey];
  }

  return null;
}

/**
 * Replaces :emoji_name: syntax and Unicode icons with bespoke custom animated emojis
 */
function replaceEmojis(clientOrGuild, text) {
  if (text === undefined && typeof clientOrGuild === 'string') {
    text = clientOrGuild;
    clientOrGuild = null;
  }
  if (!text || typeof text !== 'string') return text;

  for (const unicode of SORTED_UNICODE_KEYS) {
    if (text.includes(unicode)) {
      text = text.split(unicode).join(UNICODE_MAP[unicode]);
    }
  }

  text = text.replace(/(?<!<[at]?):([a-zA-Z0-9_]+):(?!\d+>|[a-zA-Z]+>)/g, (match, name) => {
    const resolved = resolveEmoji(clientOrGuild, name);
    return resolved || match;
  });

  text = text.replace(/<a?:([a-zA-Z0-9_]+):(\d+)>/g, (match, rawName, id) => {
    let name = rawName;
    if (CANONICAL_ALIASES[name]) {
      name = CANONICAL_ALIASES[name];
    } else if (name.startsWith('tungsten_')) {
      const base = name.slice(9);
      if (CANONICAL_ALIASES['tungsten_' + base]) name = CANONICAL_ALIASES['tungsten_' + base];
      else if (CANONICAL_ALIASES[base]) name = CANONICAL_ALIASES[base];
    } else if (name.startsWith('celestia_')) {
      const base = name.slice(9);
      if (CANONICAL_ALIASES['celestia_' + base]) name = CANONICAL_ALIASES['celestia_' + base];
      else if (CANONICAL_ALIASES[base]) name = CANONICAL_ALIASES[base];
    } else if (CANONICAL_ALIASES['tungsten_' + name]) {
      name = CANONICAL_ALIASES['tungsten_' + name];
    } else if (CANONICAL_ALIASES['celestia_' + name]) {
      name = CANONICAL_ALIASES['celestia_' + name];
    }

    if (IDS[name]) {
      const targetId = IDS[name];
      const client = clientOrGuild?.client || clientOrGuild;
      const emojiStore = client?.tungstenEmojis || client?.celestiaEmojis;
      if (emojiStore?.has(rawName) || emojiStore?.has(name)) {
        const live = emojiStore.get(name) || emojiStore.get(rawName);
        if (live && typeof live.toString === 'function') {
          return live.toString();
        }
        return match;
      }
      if (id !== targetId || rawName !== name || match.startsWith('<:')) {
        return `<a:${name}:${targetId}>`;
      }
      return match;
    }

    const resolved = resolveEmoji(clientOrGuild, rawName);
    if (resolved && resolved.startsWith('<a:') && match.startsWith('<:')) {
      return resolved;
    }
    return match;
  });

  return text;
}

function healEmojiObjectOrString(em, clientOrGuild) {
  if (!em) return em;
  if (typeof em === 'string') {
    let rep = UNICODE_MAP[em] || (typeof replaceEmojis === 'function' ? replaceEmojis(clientOrGuild, em) : em);
    let target = (rep && typeof rep === 'string') ? rep : em;
    let m = target.match(/<a?:([a-zA-Z0-9_]+):(\d+)>/);
    if (m) {
      let name = m[1];
      let id = m[2];
      if (CANONICAL_ALIASES[name]) {
        name = CANONICAL_ALIASES[name];
      } else if (name.startsWith('tungsten_')) {
        const base = name.slice(9);
        if (CANONICAL_ALIASES['tungsten_' + base]) name = CANONICAL_ALIASES['tungsten_' + base];
        else if (CANONICAL_ALIASES[base]) name = CANONICAL_ALIASES[base];
      } else if (name.startsWith('celestia_')) {
        const base = name.slice(9);
        if (CANONICAL_ALIASES['celestia_' + base]) name = CANONICAL_ALIASES['celestia_' + base];
        else if (CANONICAL_ALIASES[base]) name = CANONICAL_ALIASES[base];
      } else if (CANONICAL_ALIASES['tungsten_' + name]) {
        name = CANONICAL_ALIASES['tungsten_' + name];
      } else if (CANONICAL_ALIASES['celestia_' + name]) {
        name = CANONICAL_ALIASES['celestia_' + name];
      }
      if (IDS[name] && id !== IDS[name]) {
        id = IDS[name];
      }
      return { name, id, animated: true };
    }
    return rep || em;
  } else if (typeof em === 'object' && em.name) {
    let name = em.name;
    let id = em.id;
    if (CANONICAL_ALIASES[name]) {
      name = CANONICAL_ALIASES[name];
    } else if (name.startsWith('tungsten_')) {
      const base = name.slice(9);
      if (CANONICAL_ALIASES['tungsten_' + base]) name = CANONICAL_ALIASES['tungsten_' + base];
      else if (CANONICAL_ALIASES[base]) name = CANONICAL_ALIASES[base];
    } else if (name.startsWith('celestia_')) {
      const base = name.slice(9);
      if (CANONICAL_ALIASES['celestia_' + base]) name = CANONICAL_ALIASES['celestia_' + base];
      else if (CANONICAL_ALIASES[base]) name = CANONICAL_ALIASES[base];
    } else if (CANONICAL_ALIASES['tungsten_' + name]) {
      name = CANONICAL_ALIASES['tungsten_' + name];
    } else if (CANONICAL_ALIASES['celestia_' + name]) {
      name = CANONICAL_ALIASES['celestia_' + name];
    }
    if (IDS[name] && id !== IDS[name]) {
      id = IDS[name];
    }
    return { ...em, name, id, animated: em.animated !== false };
  }
  return em;
}

/**
 * Recursively sanitizes any Discord payload
 */
function sanitizeUiPayload(clientOrGuild, payload) {
  if (!payload) return payload;

  if (typeof payload === 'string') {
    return replaceEmojis(clientOrGuild, payload);
  }

  if (typeof payload === 'object') {
    if (typeof payload.content === 'string') {
      payload.content = replaceEmojis(clientOrGuild, payload.content);
    }

    if (Array.isArray(payload.embeds)) {
      for (const embed of payload.embeds) {
        if (!embed) continue;
        if (typeof embed.setTitle === 'function' && embed.data) {
          if (embed.data.title) embed.data.title = replaceEmojis(clientOrGuild, embed.data.title);
          if (embed.data.description) embed.data.description = replaceEmojis(clientOrGuild, embed.data.description);
          if (embed.data.footer?.text) embed.data.footer.text = replaceEmojis(clientOrGuild, embed.data.footer.text);
          if (embed.data.author?.name) embed.data.author.name = replaceEmojis(clientOrGuild, embed.data.author.name);
          if (Array.isArray(embed.data.fields)) {
            for (const f of embed.data.fields) {
              if (f.name) f.name = replaceEmojis(clientOrGuild, f.name);
              if (f.value) f.value = replaceEmojis(clientOrGuild, f.value);
            }
          }
        } else {
          if (embed.title) embed.title = replaceEmojis(clientOrGuild, embed.title);
          if (embed.description) embed.description = replaceEmojis(clientOrGuild, embed.description);
          if (embed.footer?.text) embed.footer.text = replaceEmojis(clientOrGuild, embed.footer.text);
          if (embed.author?.name) embed.author.name = replaceEmojis(clientOrGuild, embed.author.name);
          if (Array.isArray(embed.fields)) {
            for (const f of embed.fields) {
              if (f.name) f.name = replaceEmojis(clientOrGuild, f.name);
              if (f.value) f.value = replaceEmojis(clientOrGuild, f.value);
            }
          }
        }
      }
    }

    function sanitizeComponentNode(comp) {
      if (!comp || typeof comp !== 'object') return;

      if (comp.setEmoji && comp.data?.emoji) {
        const healed = healEmojiObjectOrString(comp.data.emoji, clientOrGuild);
        if (typeof healed === 'object') {
          comp.data.emoji = healed;
          try { comp.setEmoji(healed); } catch (e) {}
        } else if (typeof healed === 'string') {
          try { comp.setEmoji(healed); } catch (e) {}
        }
      } else if (comp.emoji) {
        const healed = healEmojiObjectOrString(comp.emoji, clientOrGuild);
        comp.emoji = healed;
        if (typeof comp.setEmoji === 'function' && typeof healed === 'object') {
          try { comp.setEmoji(healed); } catch (e) {}
        }
      } else if (comp.data?.emoji) {
        const healed = healEmojiObjectOrString(comp.data.emoji, clientOrGuild);
        comp.data.emoji = healed;
        if (typeof comp.setEmoji === 'function') {
          try { comp.setEmoji(healed); } catch (e) {}
        }
      }

      const options = comp.options || comp.data?.options;
      if (Array.isArray(options)) {
        for (const opt of options) {
          if (opt && opt.emoji) {
            opt.emoji = healEmojiObjectOrString(opt.emoji, clientOrGuild);
          }
          if (opt && opt.description) {
            opt.description = replaceEmojis(clientOrGuild, opt.description);
          }
        }
      }

      const childComps = comp.components || comp.data?.components;
      if (Array.isArray(childComps)) {
        for (const child of childComps) {
          sanitizeComponentNode(child);
        }
      }
    }

    if (Array.isArray(payload.components)) {
      for (const comp of payload.components) {
        sanitizeComponentNode(comp);
      }
    }
  }

  return payload;
}

const EMOJI_SERVER_IDS = new Set([
  '1566265776753610974', // Custom emoji 1
  '1566266030794346528', // Custom emoji 2
  '1563432162626113596', // Custom emoji 3
  '1566282297177538562', // Custom emoji 4
  '1567213617215049854', // Custom emoji 5
  '1566764668779761906', // Custom emoji 6
  '1567216768018022540', // Custom emoji 7
  '1567217022444773561', // Custom emoji 8
  '1567217408312344680', // Custom emoji 9
  '1568221270091497533', // Custom emoji 10
  '1568221442422607942', // Custom emoji 11
  '1568221697063129108', // Custom emoji 12
  '1569017330283839518', // Custom emoji 13
  '1569026596218863739', // Custom emoji 14
  '1569027728596803637'  // Custom emoji 15
]);

function isEmojiServer(guildOrId) {
  if (!guildOrId) return false;
  if (typeof guildOrId === 'string') return EMOJI_SERVER_IDS.has(guildOrId);
  if (guildOrId.id && EMOJI_SERVER_IDS.has(String(guildOrId.id))) return true;
  const name = (guildOrId.name || '').toLowerCase().trim();
  const ownerId = guildOrId.ownerId || '';
  if (name.includes('custom emoji') || /custom\s*emoji\s*[0-9]+/i.test(name)) {
    return true;
  }
  const isNameMatch = name.includes('emoji') || name.includes('emote') || name.includes('asset') || name.includes('tungsten') || name.includes('celestia');
  const isOwnerGuild = (process.env.OWNER_IDS && process.env.OWNER_IDS.includes(ownerId)) || ownerId === '100000000000000001';
  return isNameMatch || isOwnerGuild;
}

module.exports = {
  E,
  IDS,
  EMOJI_IDS,
  FALLBACKS,
  ASSETS_DIR,
  BUILTIN_PACK,
  EMOJIS,
  UNICODE_MAP,
  SORTED_UNICODE_KEYS,
  getCustomEmojiMap,
  resolveEmoji,
  replaceEmojis,
  sanitizeUiPayload,
  CANONICAL_ALIASES,
  healEmojiObjectOrString,
  isEmojiServer,
  EMOJI_SERVER_IDS
};
