/**
 * Tungsten Leveling Engine (Node.js)
 * Implements level-role rewards, no-XP channel/role ignores,
 * XP multipliers per channel/role, configurable level-up channel, and voice XP.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed } = require('./tools');
const { isModuleEnabled } = require('./modulesHelper');

function isLevelingEnabled(guildId, sdb) {
  try {
    if (!isModuleEnabled(guildId, 'leveling')) return false;
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leveling_enabled'").get();
    return row ? (row.value === '1' || row.value === 'true') : false;
  } catch (_) {
    return false;
  }
}

function isChannelOrRoleIgnored(guildId, channelId, member, sdb) {
  try {
    if (channelId) {
      const chRow = sdb.prepare("SELECT 1 FROM leveling_ignored WHERE guild_id = ? AND target_id = ? AND type = 'channel'").get(guildId, channelId);
      if (chRow) return true;
    }

    if (member && member.roles && member.roles.cache) {
      const ignoredRoles = sdb.prepare("SELECT target_id FROM leveling_ignored WHERE guild_id = ? AND type = 'role'").all(guildId);
      for (const r of ignoredRoles) {
        if (member.roles.cache.has(r.target_id)) return true;
      }
    }
  } catch (_) {}
  return false;
}

function getEffectiveMultiplier(guildId, channelId, member, sdb) {
  let chMulti = 1.0;
  let roleMulti = 1.0;

  try {
    if (channelId) {
      const chRow = sdb.prepare("SELECT multiplier FROM leveling_multipliers WHERE guild_id = ? AND target_id = ? AND type = 'channel'").get(guildId, channelId);
      if (chRow && chRow.multiplier > 0) {
        chMulti = Number(chRow.multiplier);
      }
    }

    if (member && member.roles && member.roles.cache) {
      const roleRows = sdb.prepare("SELECT target_id, multiplier FROM leveling_multipliers WHERE guild_id = ? AND type = 'role'").all(guildId);
      for (const r of roleRows) {
        if (member.roles.cache.has(r.target_id)) {
          const val = Number(r.multiplier);
          if (val > roleMulti) {
            roleMulti = val;
          }
        }
      }
    }
  } catch (_) {}

  return chMulti * roleMulti;
}

async function checkAndAwardLevelRoles(guild, member, newLevel, sdb) {
  const awardedRoles = [];
  try {
    const roles = sdb.prepare('SELECT level, role_id FROM leveling_roles WHERE guild_id = ? AND level <= ? ORDER BY level ASC').all(guild.id, newLevel);
    for (const r of roles) {
      if (member && member.roles && member.roles.cache && !member.roles.cache.has(r.role_id)) {
        const roleObj = guild.roles?.cache?.get(r.role_id) || (typeof guild.roles?.fetch === 'function' ? await guild.roles.fetch(r.role_id).catch(() => null) : null);
        if (roleObj) {
          const added = await member.roles.add(roleObj, `[Leveling] Reached Level ${newLevel}`).then(() => true).catch(() => false);
          if (added) awardedRoles.push(roleObj);
        }
      }
    }
  } catch (_) {}
  return awardedRoles;
}

async function sendLevelUpNotification(guild, member, newLevel, awardedRoles, fallbackChannel, client, sdb) {
  try {
    const settingRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'level_up_channel'").get();
    const targetConfig = settingRow ? settingRow.value : null;

    if (targetConfig === 'none') return;

    let roleText = '';
    if (awardedRoles && awardedRoles.length > 0) {
      roleText = `\n🎁 **Unlocked Role(s):** ${awardedRoles.map(r => `<@&${r.id}>`).join(', ')}`;
    }

    const embed = createEmbed({
      color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
      title: '🎉 Level Up!',
      description: `Congratulations <@${member.id}>, you have ascended to **Level ${newLevel}**!${roleText}`,
      footer: `Server: ${guild.name}`
    });

    if (targetConfig === 'dm') {
      await member.send({ embeds: [embed] }).catch(() => null);
      return;
    }

    if (targetConfig && targetConfig !== 'current') {
      const targetCh = guild.channels?.cache?.get(targetConfig) || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(targetConfig).catch(() => null) : null);
      if (targetCh && targetCh.isTextBased()) {
        await targetCh.send({ embeds: [embed] }).catch(() => null);
        return;
      }
    }

    // Default: send in current chat channel if text based
    if (fallbackChannel && typeof fallbackChannel.send === 'function') {
      await fallbackChannel.send({ embeds: [embed] }).catch(() => null);
    }
  } catch (_) {}
}

async function processChatXp(message, sdb, client) {
  if (!message || !message.guild || !message.author || message.author.bot) return null;

  const guildId = message.guild.id;
  const userId = message.author.id;

  if (!isLevelingEnabled(guildId, sdb)) return null;
  if (isChannelOrRoleIgnored(guildId, message.channel.id, message.member, sdb)) return null;

  const now = Math.floor(Date.now() / 1000);
  const row = sdb.prepare('SELECT xp, level, last_xp_time FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(guildId, userId);

  if (row && now - row.last_xp_time < 60) {
    return null; // 1-minute chat cooldown
  }

  const currentXp = row ? row.xp : 0;
  const currentLevel = row ? row.level : 0;

  const multiplier = getEffectiveMultiplier(guildId, message.channel.id, message.member, sdb);
  const baseXp = Math.floor(Math.random() * 11) + 15; // 15 - 25 XP
  const gainedXp = Math.max(1, Math.floor(baseXp * multiplier));
  const newXp = currentXp + gainedXp;
  const newLevel = Math.floor(0.1 * Math.sqrt(newXp));

  sdb.prepare(`
    INSERT INTO leveling_users (guild_id, user_id, xp, level, last_xp_time)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET
      xp = excluded.xp,
      level = excluded.level,
      last_xp_time = excluded.last_xp_time
  `).run(guildId, userId, newXp, newLevel, now);

  if (newLevel > currentLevel) {
    const awardedRoles = await checkAndAwardLevelRoles(message.guild, message.member, newLevel, sdb);
    await sendLevelUpNotification(message.guild, message.member, newLevel, awardedRoles, message.channel, client, sdb);
    return { leveledUp: true, oldLevel: currentLevel, newLevel, gainedXp, awardedRoles };
  }

  return { leveledUp: false, gainedXp };
}

async function processVoiceXp(guild, member, channelId, elapsedMinutes, sdb, client) {
  if (!guild || !member || !channelId || elapsedMinutes <= 0) return null;

  const guildId = guild.id;
  const userId = member.id;

  if (!isLevelingEnabled(guildId, sdb)) return null;
  if (isChannelOrRoleIgnored(guildId, channelId, member, sdb)) return null;

  const multiplier = getEffectiveMultiplier(guildId, channelId, member, sdb);
  const baseVoiceXp = elapsedMinutes * 15; // 15 XP per minute
  const gainedXp = Math.max(1, Math.floor(baseVoiceXp * multiplier));

  const row = sdb.prepare('SELECT xp, level FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
  const currentXp = row ? row.xp : 0;
  const currentLevel = row ? row.level : 0;

  const newXp = currentXp + gainedXp;
  const newLevel = Math.floor(0.1 * Math.sqrt(newXp));
  const now = Math.floor(Date.now() / 1000);

  sdb.prepare(`
    INSERT INTO leveling_users (guild_id, user_id, xp, level, last_xp_time)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET
      xp = excluded.xp,
      level = excluded.level,
      last_xp_time = excluded.last_xp_time
  `).run(guildId, userId, newXp, newLevel, now);

  if (newLevel > currentLevel) {
    const awardedRoles = await checkAndAwardLevelRoles(guild, member, newLevel, sdb);
    await sendLevelUpNotification(guild, member, newLevel, awardedRoles, null, client, sdb);
    return { leveledUp: true, oldLevel: currentLevel, newLevel, gainedXp, awardedRoles };
  }

  return { leveledUp: false, gainedXp };
}

module.exports = {
  isLevelingEnabled,
  isChannelOrRoleIgnored,
  getEffectiveMultiplier,
  checkAndAwardLevelRoles,
  sendLevelUpNotification,
  processChatXp,
  processVoiceXp
};
