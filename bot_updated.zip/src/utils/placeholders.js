const { replaceEmojis } = require('./emojis');

/**
 * Tungsten Placeholder Engine
 * Replaces tokens in welcome/leave text with live member and guild values.
 */
function formatPlaceholders(text, member, guild) {
  if (!text) return '';
  const now = Date.now();
  const createdTimestamp = member?.user?.createdTimestamp || now;
  const daysOld = Math.floor((now - createdTimestamp) / (1000 * 60 * 60 * 24));
  const memberId = member?.id || '';
  const username = member?.user?.username || member?.displayName || '';
  const avatar = member?.user?.displayAvatarURL ? member.user.displayAvatarURL() : '';
  const guildName = guild?.name || '';
  const guildId = guild?.id || '';
  const memberCount = String(guild?.memberCount || 0);
  const guildIcon = guild?.iconURL ? guild.iconURL() : '';

  let result = text
    .replace(/{user\.mention}/gi, `<@${memberId}>`)
    .replace(/{user\.name}/gi, username)
    .replace(/{user\.username}/gi, username)
    .replace(/{user\.tag}/gi, username)
    .replace(/{user\.id}/gi, memberId)
    .replace(/{user\.avatar}/gi, avatar)
    .replace(/{user\.created_at}/gi, `${daysOld} days ago`)
    .replace(/{server\.name}/gi, guildName)
    .replace(/{server\.id}/gi, guildId)
    .replace(/{server\.member_count}/gi, memberCount)
    .replace(/{member\.count}/gi, memberCount)
    .replace(/{memberCount}/gi, memberCount)
    .replace(/{server\.icon}/gi, guildIcon);

  if (/{emoji:[a-zA-Z0-9_]+}/i.test(result)) {
    result = result.replace(/{emoji:([a-zA-Z0-9_]+)}/gi, (_, name) => {
      return replaceEmojis(guild, `:${name}:`);
    });
  }

  return result;
}

module.exports = {
  formatPlaceholders
};
