/**
 * Tungsten Unified Event-Driven Task Scheduler (Node.js)
 * Replaces high-overhead 20s polling with an indexed, crash-resilient master task queue.
 */
const { getMasterDb, getServerDb } = require('./serverDb');
const { createEmbed } = require('./tools');
const { createCase } = require('./modlog');
const { EMOJIS } = require('./emojis');

let _client = null;
let _timer = null;
let _currentNextRun = null;
const _handlers = new Map();

/**
 * Register a task execution handler for a specific task kind.
 */
function registerHandler(kind, handler) {
  _handlers.set(kind, handler);
}

/**
 * Schedule a task to run at a specific timestamp (in milliseconds).
 */
function scheduleTask(guildId, kind, runAtMs, payload = {}) {
  const mdb = getMasterDb();
  const runAt = Math.floor(Number(runAtMs));
  const payloadStr = typeof payload === 'string' ? payload : JSON.stringify(payload);

  const res = mdb.prepare(`
    INSERT INTO scheduled_tasks (guild_id, kind, run_at, payload, done)
    VALUES (?, ?, ?, ?, 0)
  `).run(guildId ? String(guildId) : null, String(kind), runAt, payloadStr);

  const taskId = res.lastInsertRowid;

  // Re-arm timer if this task runs sooner than currently scheduled next run
  if (!_currentNextRun || runAt < _currentNextRun) {
    armTimer();
  }

  return taskId;
}

/**
 * Cancel or mark a scheduled task as completed.
 */
function cancelTask(taskId) {
  const mdb = getMasterDb();
  mdb.prepare('UPDATE scheduled_tasks SET done = 1 WHERE id = ?').run(Number(taskId));
  armTimer();
}

/**
 * Arms the next execution timer from master DB.
 */
function armTimer() {
  if (_timer) {
    clearTimeout(_timer);
    _timer = null;
  }

  try {
    const mdb = getMasterDb();
    const row = mdb.prepare('SELECT MIN(run_at) AS nextRun FROM scheduled_tasks WHERE done = 0').get();
    if (!row || row.nextRun === null || row.nextRun === undefined) {
      _currentNextRun = null;
      return;
    }

    const nextRun = Number(row.nextRun);
    _currentNextRun = nextRun;
    const now = Date.now();
    const delay = Math.max(0, Math.min(nextRun - now, 2147483647)); // Max 32-bit signed int (~24.8 days)

    _timer = setTimeout(async () => {
      await processDueTasks();
      armTimer();
    }, delay);

    if (_timer && typeof _timer.unref === 'function') {
      _timer.unref();
    }
  } catch (err) {
    console.error('[Scheduler] Error arming timer:', err);
  }
}

/**
 * Execute all overdue tasks.
 */
async function processDueTasks() {
  try {
    const mdb = getMasterDb();
    const now = Date.now();
    const dueTasks = mdb.prepare('SELECT * FROM scheduled_tasks WHERE done = 0 AND run_at <= ? ORDER BY run_at ASC').all(now);

    for (const task of dueTasks) {
      let success = false;
      try {
        const handler = _handlers.get(task.kind);
        if (handler) {
          let payload = {};
          try {
            payload = JSON.parse(task.payload);
          } catch (e) {
            payload = task.payload;
          }
          await handler(task, payload, _client);
          success = true;
        } else {
          console.warn(`[Scheduler] No handler registered for task kind "${task.kind}" (id: ${task.id})`);
          success = true; // No handler registered, do not loop-retry
        }
      } catch (execErr) {
        console.error(`[Scheduler] Error executing task ${task.id} (${task.kind}):`, execErr);
      }

      if (success) {
        mdb.prepare('UPDATE scheduled_tasks SET done = 1 WHERE id = ?').run(task.id);
      } else {
        const retries = (task.retries || 0) + 1;
        if (retries >= 3) {
          // Permanently mark failed after 3 retries (done = -1) (Review 2.6)
          mdb.prepare('UPDATE scheduled_tasks SET done = -1 WHERE id = ?').run(task.id);
          console.error(`[Scheduler] Task ${task.id} (${task.kind}) permanently failed after 3 retries.`);
        } else {
          // Retry with exponential backoff (30s * retries)
          const nextRun = Date.now() + (30000 * retries);
          try {
            mdb.prepare('UPDATE scheduled_tasks SET run_at = ?, retries = ? WHERE id = ?').run(nextRun, retries, task.id);
          } catch (_) {
            mdb.prepare('UPDATE scheduled_tasks SET run_at = ? WHERE id = ?').run(nextRun, task.id);
          }
        }
      }
    }
  } catch (err) {
    console.error('[Scheduler] Error processing due tasks:', err);
  }
}

/**
 * Built-in handler: Giveaway resolution
 */
async function handleGiveawayEnd(task, payload, client) {
  if (!client) return;
  const { guildId, channelId, messageId } = payload;
  if (!guildId || !channelId || !messageId) return;

  const guild = (client?.guilds?.cache?.get ? client.guilds.cache.get(guildId) : null)
    || (typeof client?.guilds?.fetch === 'function' ? await client.guilds.fetch(guildId).catch(() => null) : null)
    || payload.guild;
  if (!guild) return;

  const sdb = getServerDb(guildId);
  const ga = sdb.prepare('SELECT * FROM server_giveaways WHERE message_id = ?').get(messageId);
  if (!ga || ga.ended === 1 || ga.paused === 1) return;

  const channel = guild.channels?.cache?.get(channelId) || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(channelId).catch(() => null) : null);
  if (!channel || !channel.isTextBased()) {
    sdb.prepare('UPDATE server_giveaways SET ended = 1 WHERE message_id = ?').run(messageId);
    return;
  }

  const msg = await channel.messages.fetch(messageId).catch(() => null);
  if (!msg) {
    sdb.prepare('UPDATE server_giveaways SET ended = 1 WHERE message_id = ?').run(messageId);
    return;
  }

  // 1. Collect button entries
  const buttonEntries = sdb.prepare('SELECT user_id FROM server_giveaway_entries WHERE message_id = ?').all(messageId).map(r => r.user_id);

  // 2. Collect reaction entries (backward compatibility fallback)
  const reaction = msg.reactions?.cache?.get('🎉');
  const reactionUsers = reaction ? (await reaction.users.fetch().catch(() => new Map())) : new Map();
  const reactionUserIds = [...reactionUsers.values()].filter(u => !u.bot).map(u => u.id);

  // 3. Deduplicate
  const allUserIds = Array.from(new Set([...buttonEntries, ...reactionUserIds]));

  // 4. Verify requirements
  const eligible = [];
  for (const uid of allUserIds) {
    if (client.user && uid === client.user.id) continue;
    let ok = true;
    if (ga.required_role_id || ga.min_level > 0 || ga.min_server_age > 0) {
      const member = guild.members?.cache?.get(uid) || (typeof guild.members?.fetch === 'function' ? await guild.members.fetch(uid).catch(() => null) : null);
      if (!member) {
        ok = false;
      } else {
        if (ga.required_role_id && !member.roles?.cache?.has(ga.required_role_id)) ok = false;
        if (ok && ga.min_level > 0) {
          const lvlRow = sdb.prepare('SELECT level FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(guildId, uid);
          if ((lvlRow?.level || 0) < ga.min_level) ok = false;
        }
        if (ok && ga.min_server_age > 0) {
          const joined = member.joinedTimestamp || Date.now();
          const ageDays = (Date.now() - joined) / (86400000);
          if (ageDays < ga.min_server_age) ok = false;
        }
      }
    }
    if (ok) eligible.push(uid);
  }

  const winners = [];
  const available = [...eligible];
  const winnersCount = Math.max(1, ga.winners_count || 1);
  for (let i = 0; i < Math.min(winnersCount, available.length); i++) {
    const idx = Math.floor(Math.random() * available.length);
    winners.push(available.splice(idx, 1)[0]);
  }

  const winnerMentions = winners.length
    ? winners.map(id => `<@${id}>`).join(', ')
    : 'No valid entrants';

  await channel.send({
    content: `🎉 **Giveaway Ended!**\n\n**Prize:** **${ga.prize}**\n**Winners:** ${winnerMentions}\n**Original Post:** https://discord.com/channels/${guild.id}/${channelId}/${messageId}`
  }).catch(() => null);

  try {
    const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
    const endRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`ga:ended:${messageId}`)
        .setLabel(`Giveaway Ended (${allUserIds.length})`)
        .setStyle(ButtonStyle.Secondary)
        .setEmoji(EMOJIS.GIVEAWAY)
        .setDisabled(true)
    );
    await msg.edit({ components: [endRow] }).catch(() => null);
  } catch (_) {}

  sdb.prepare('UPDATE server_giveaways SET ended = 1 WHERE message_id = ?').run(messageId);
}

/**
 * Built-in handler: Tempban expiration (Auto-unban)
 */
async function handleTempbanEnd(task, payload, client) {
  if (!client) return;
  const { guildId, userId, reason } = payload;
  const guild = client.guilds.cache.get(guildId) || (await client.guilds.fetch(guildId).catch(() => null));
  if (!guild) return;

  try {
    await guild.bans.remove(userId, `[Tungsten Scheduler] Tempban duration expired${reason ? `: ${reason}` : ''}`);
    const sdb = getServerDb(guildId);
    createCase(guildId, sdb, {
      action: 'unban',
      targetId: userId,
      moderatorId: client.user.id,
      reason: '[Auto-Scheduler] Tempban duration expired'
    });
  } catch (err) {}
}

/**
 * Built-in handler: Temprole expiration (Auto-remove role)
 */
async function handleTemproleEnd(task, payload, client) {
  if (!client) return;
  const { guildId, userId, roleId } = payload;
  const guild = client.guilds.cache.get(guildId) || (await client.guilds.fetch(guildId).catch(() => null));
  if (!guild) return;

  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member && member.roles && member.roles.cache.has(roleId)) {
      await member.roles.remove(roleId, '[Tungsten Scheduler] Temprole duration expired');
    }
  } catch (err) {}
}

/**
 * Built-in handler: Tempmute expiration
 */
async function handleTempmuteEnd(task, payload, client) {
  if (!client) return;
  const { guildId, userId } = payload;
  const guild = client.guilds.cache.get(guildId) || (await client.guilds.fetch(guildId).catch(() => null));
  if (!guild) return;

  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member && member.communicationDisabledUntilTimestamp && member.communicationDisabledUntilTimestamp > Date.now()) {
      await member.timeout(null, '[Tungsten Scheduler] Tempmute duration expired');
    }
  } catch (err) {}
}

/**
 * Built-in handler: Auto-close inactive ticket
 */
async function handleTicketAutoclose(task, payload, client) {
  if (!client) return;
  const { guildId, channelId } = payload;
  const guild = client.guilds.cache.get(guildId) || (await client.guilds.fetch(guildId).catch(() => null));
  if (!guild) return;

  const sdb = getServerDb(guildId);
  const ticket = sdb.prepare('SELECT * FROM server_tickets WHERE channel_id = ?').get(channelId);
  if (!ticket || ticket.status === 'closed') return;

  const channel = guild.channels?.cache?.get(channelId) || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(channelId).catch(() => null) : null);
  if (!channel) {
    sdb.prepare("UPDATE server_tickets SET status = 'closed' WHERE channel_id = ?").run(channelId);
    return;
  }

  const { closeTicketWithTranscript } = require('./ticketTranscript');
  await closeTicketWithTranscript({
    guild,
    channel,
    closerUser: client.user,
    reason: 'Automatically closed due to inactivity',
    client,
    sdb
  });
}

/**
 * Built-in handler: Reminder delivery
 */
async function handleReminder(task, payload, client) {
  if (!client) return;
  const { userId, channelId, message } = payload;
  const targetUser = await client.users.fetch(userId).catch(() => null);
  if (!targetUser) return;

  const embed = createEmbed({
    color: 0x5865F2,
    title: '⏰  Tungsten Reminder',
    description: `You asked to be reminded:\n\n> ${message}`
  });

  try {
    await targetUser.send({ embeds: [embed] });
  } catch (err) {
    if (channelId) {
      const channel = await client.channels.fetch(channelId).catch(() => null);
      if (channel && channel.isTextBased()) {
        await channel.send({ content: `<@${userId}>`, embeds: [embed] }).catch(() => null);
      }
    }
  }
}

/**
 * Built-in handler: Purge expired whitelist grants
 */
async function handlePurgeWhitelistGrants(task, payload, client) {
  const { purgeExpiredGrants } = require('../security/resolveBypass');
  if (payload && payload.guildId) {
    purgeExpiredGrants(payload.guildId);
  } else if (client?.guilds?.cache) {
    for (const guild of client.guilds.cache.values()) {
      purgeExpiredGrants(guild.id);
    }
  }
}

/**
 * Triggers purge of expired whitelist grants across all guilds.
 */
function purgeAllExpiredGrants(client = _client) {
  const { purgeExpiredGrants } = require('../security/resolveBypass');
  let total = 0;
  if (client?.guilds?.cache) {
    for (const guild of client.guilds.cache.values()) {
      total += purgeExpiredGrants(guild.id);
    }
  }
  return total;
}

/**
 * Automatically lifts emergency panic lockdown when scheduled auto-unlock timer expires.
 */
async function handlePanicAutoUnlock(task, payload, client) {
  const guildId = task.guild_id;
  if (!guildId) return;
  const { executePanicUnlock, getLockdownStatus } = require('../interactions/panic');
  const isStillLocked = getLockdownStatus(guildId);
  if (!isStillLocked) return;

  const guild = (client?.guilds?.cache?.get ? client.guilds.cache.get(guildId) : null)
    || (typeof client?.guilds?.fetch === 'function' ? await client.guilds.fetch(guildId).catch(() => null) : null)
    || payload?.guild;
  if (!guild) return;

  await executePanicUnlock(guild, client, payload?.reason || 'Auto-unlock: Time limit reached');
}

/**
 * Initialize the unified task scheduler with bot client and register default handlers.
 */
function initScheduler(client) {
  _client = client;

  // Register built-in handlers
  registerHandler('giveaway_end', handleGiveawayEnd);
  registerHandler('tempban_end', handleTempbanEnd);
  registerHandler('unban_task', handleTempbanEnd);
  registerHandler('tempmute_end', handleTempmuteEnd);
  registerHandler('temprole_end', handleTemproleEnd);
  registerHandler('unrole_task', handleTemproleEnd);
  registerHandler('ticket_autoclose', handleTicketAutoclose);
  registerHandler('reminder', handleReminder);
  registerHandler('panic_auto_unlock', handlePanicAutoUnlock);
  registerHandler('purge_whitelist_grants', handlePurgeWhitelistGrants);

  // Periodic purge of expired whitelist grants (every 60s)
  const _whitelistPurgeTimer = setInterval(() => {
    try {
      const { purgeExpiredGrants } = require('../security/resolveBypass');
      if (_client?.guilds?.cache) {
        for (const guild of _client.guilds.cache.values()) {
          purgeExpiredGrants(guild.id);
        }
      }
    } catch (_) {}
  }, 60000);
  if (_whitelistPurgeTimer && typeof _whitelistPurgeTimer.unref === 'function') {
    _whitelistPurgeTimer.unref();
  }

  // Sync existing active giveaways from per-guild DBs into scheduled_tasks
  try {
    const mdb = getMasterDb();
    for (const guild of client.guilds.cache.values()) {
      try {
        const sdb = getServerDb(guild.id);
        const activeGiveaways = sdb.prepare('SELECT * FROM server_giveaways WHERE ended = 0').all();
        for (const ga of activeGiveaways) {
          const runAtMs = Number(ga.ends_at) * 1000;
          const exists = mdb.prepare(`
            SELECT id FROM scheduled_tasks
            WHERE guild_id = ? AND kind = 'giveaway_end' AND payload LIKE ? AND done = 0
          `).get(String(guild.id), `%"messageId":"${ga.message_id}"%`);

          if (!exists) {
            scheduleTask(guild.id, 'giveaway_end', runAtMs, {
              guildId: String(guild.id),
              channelId: String(ga.channel_id),
              messageId: String(ga.message_id)
            });
          }
        }
      } catch (gErr) {}
    }
  } catch (err) {
    console.error('[Scheduler] Error syncing existing giveaways:', err);
  }

  // Arm timer
  armTimer();
  console.log('[Scheduler] Unified Event-Driven Task Scheduler active.');
}

module.exports = {
  initScheduler,
  registerHandler,
  scheduleTask,
  cancelTask,
  armTimer,
  processDueTasks,
  handleGiveawayEnd,
  handlePurgeWhitelistGrants,
  purgeAllExpiredGrants
};
