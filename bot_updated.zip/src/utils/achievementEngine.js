/**
 * Tungsten Achievements & Badges Engine (Node.js)
 * Implements built-in achievements, custom guild badges, automatic qualification triggers,
 * and leaderboard rankings.
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('./serverDb');
const { EMOJIS } = require('./emojis');

const BUILTIN_ACHIEVEMENTS = {
  first_message: {
    id: 'first_message',
    name: 'First Message',
    emoji: EMOJIS.CHAT,
    description: 'Sent your first message in the server.'
  },
  level_10: {
    id: 'level_10',
    name: 'Level 10',
    emoji: EMOJIS.MEDAL_BRONZE,
    description: 'Reached Level 10 in the server leveling system.'
  },
  level_50: {
    id: 'level_50',
    name: 'Level 50',
    emoji: EMOJIS.MEDAL_GOLD,
    description: 'Reached Level 50 in the server leveling system.'
  },
  rich: {
    id: 'rich',
    name: 'Rich',
    emoji: EMOJIS.MONEYBAG,
    description: 'Accumulated a total net worth of 50,000+ coins.'
  },
  generous: {
    id: 'generous',
    name: 'Generous',
    emoji: EMOJIS.GIFT,
    description: 'Shared your wealth by paying or gifting fellow members.'
  },
  veteran: {
    id: 'veteran',
    name: 'Veteran',
    emoji: EMOJIS.MEDAL_GOLD,
    description: 'Dedicated server member for at least 30 days.'
  },
  helper: {
    id: 'helper',
    name: 'Helper',
    emoji: EMOJIS.HANDSHAKE,
    description: 'Assisted server members or community support.'
  },
  moderated: {
    id: 'moderated',
    name: 'Moderated',
    emoji: EMOJIS.SHIELD,
    description: 'Active participant in server moderation or discipline.'
  },
  night_owl: {
    id: 'night_owl',
    name: 'Night Owl',
    emoji: EMOJIS.SEARCH,
    description: 'Active in the server during late night hours (12 AM - 5 AM UTC).'
  }
};

/**
 * Checks and awards any eligible built-in achievements automatically for a member.
 * @param {object} guild Discord Guild object
 * @param {object} member Discord GuildMember or User object
 * @param {object} [sdb] Optional SQLite database instance
 * @returns {Array<string>} List of newly awarded achievement IDs
 */
function checkAndAwardAchievements(guild, member, sdb) {
  if (!guild || !member) return [];
  const guildId = guild.id;
  const userId = member.id || member.user?.id;
  if (!guildId || !userId) return [];

  const db = sdb || getServerDb(guildId);
  if (!db) return [];

  let existingBadges;
  try {
    const rows = db.prepare('SELECT badge_id FROM user_achievements WHERE guild_id = ? AND user_id = ?').all(guildId, userId);
    existingBadges = new Set(rows.map(r => r.badge_id));
  } catch (_) {
    return [];
  }

  const newlyEarned = [];
  const now = Math.floor(Date.now() / 1000);

  // 1. First Message: Triggered when member is active in chat / executing a command
  if (!existingBadges.has('first_message')) {
    newlyEarned.push('first_message');
  }

  // 2. Level 10 & 3. Level 50
  if (!existingBadges.has('level_10') || !existingBadges.has('level_50')) {
    try {
      const lvlRow = db.prepare('SELECT level FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
      const userLevel = lvlRow?.level || 0;
      if (!existingBadges.has('level_10') && userLevel >= 10) {
        newlyEarned.push('level_10');
      }
      if (!existingBadges.has('level_50') && userLevel >= 50) {
        newlyEarned.push('level_50');
      }
    } catch (_) {}
  }

  // 4. Rich: 50,000+ total coins in wallet + bank
  if (!existingBadges.has('rich')) {
    try {
      const ecoRow = db.prepare('SELECT wallet, bank FROM economy_users WHERE user_id = ?').get(userId);
      const netWorth = (ecoRow?.wallet || 0) + (ecoRow?.bank || 0);
      if (netWorth >= 50000) {
        newlyEarned.push('rich');
      }
    } catch (_) {}
  }

  // 5. Veteran: In server for at least 30 days
  if (!existingBadges.has('veteran')) {
    const joined = member.joinedTimestamp || (member.joinedAt ? new Date(member.joinedAt).getTime() : 0);
    if (joined > 0 && (Date.now() - joined) >= (30 * 24 * 60 * 60 * 1000)) {
      newlyEarned.push('veteran');
    }
  }

  // 6. Helper: Has helper/support role or permission
  if (!existingBadges.has('helper')) {
    try {
      const hasHelperRole = member.roles?.cache?.some(r => /helper|support|guide|assist/i.test(r.name));
      if (hasHelperRole) {
        newlyEarned.push('helper');
      }
    } catch (_) {}
  }

  // 7. Moderated: Has staff moderation perms or recorded warnings
  if (!existingBadges.has('moderated')) {
    try {
      const isStaff = member.permissions?.has?.(PermissionsBitField.Flags.ManageMessages) ||
                      member.permissions?.has?.(PermissionsBitField.Flags.KickMembers) ||
                      member.permissions?.has?.(PermissionsBitField.Flags.ModerateMembers) ||
                      member.permissions?.has?.(PermissionsBitField.Flags.Administrator);
      if (isStaff) {
        newlyEarned.push('moderated');
      } else {
        const warnRow = db.prepare('SELECT 1 FROM member_warnings WHERE guild_id = ? AND user_id = ? LIMIT 1').get(guildId, userId);
        if (warnRow) {
          newlyEarned.push('moderated');
        }
      }
    } catch (_) {}
  }

  // 8. Night Owl: Active between 12 AM and 5 AM UTC
  if (!existingBadges.has('night_owl')) {
    const utcHour = new Date().getUTCHours();
    if (utcHour >= 0 && utcHour < 5) {
      newlyEarned.push('night_owl');
    }
  }

  // Insert newly qualified achievements
  if (newlyEarned.length > 0) {
    const insertStmt = db.prepare(`
      INSERT OR IGNORE INTO user_achievements (user_id, guild_id, badge_id, earned_at)
      VALUES (?, ?, ?, ?)
    `);
    const tx = db.transaction((badges) => {
      for (const bid of badges) {
        insertStmt.run(userId, guildId, bid, now);
      }
    });
    try {
      tx(newlyEarned);
    } catch (_) {}
  }

  return newlyEarned;
}

/**
 * Manually awards any badge (built-in or custom) to a user.
 */
function awardBadge(guildId, userId, badgeId, sdb) {
  const db = sdb || getServerDb(guildId);
  const normalizedId = String(badgeId).trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_');

  // Verify badge exists in built-ins or guild_badges
  let badgeInfo = BUILTIN_ACHIEVEMENTS[normalizedId];
  if (!badgeInfo) {
    try {
      const customRow = db.prepare('SELECT badge_id, name, emoji, description FROM guild_badges WHERE guild_id = ? AND (badge_id = ? OR LOWER(name) = ?)')
        .get(guildId, normalizedId, String(badgeId).trim().toLowerCase());
      if (customRow) {
        badgeInfo = {
          id: customRow.badge_id,
          name: customRow.name,
          emoji: customRow.emoji,
          description: customRow.description
        };
      }
    } catch (_) {}
  }

  if (!badgeInfo) {
    return { success: false, reason: 'not_found' };
  }

  try {
    const exists = db.prepare('SELECT 1 FROM user_achievements WHERE guild_id = ? AND user_id = ? AND badge_id = ?')
      .get(guildId, String(userId), badgeInfo.id);
    if (exists) {
      return { success: false, reason: 'already_has', badge: badgeInfo };
    }

    const now = Math.floor(Date.now() / 1000);
    db.prepare(`
      INSERT INTO user_achievements (user_id, guild_id, badge_id, earned_at)
      VALUES (?, ?, ?, ?)
    `).run(String(userId), guildId, badgeInfo.id, now);

    return { success: true, badge: badgeInfo, earned_at: now };
  } catch (err) {
    return { success: false, reason: err.message };
  }
}

/**
 * Revokes a badge from a user.
 */
function revokeBadge(guildId, userId, badgeId, sdb) {
  const db = sdb || getServerDb(guildId);
  const normalizedId = String(badgeId).trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_');

  try {
    // Resolve matching ID
    let targetId = normalizedId;
    const customRow = db.prepare('SELECT badge_id FROM guild_badges WHERE guild_id = ? AND (badge_id = ? OR LOWER(name) = ?)')
      .get(guildId, normalizedId, String(badgeId).trim().toLowerCase());
    if (customRow) targetId = customRow.badge_id;

    const res = db.prepare('DELETE FROM user_achievements WHERE guild_id = ? AND user_id = ? AND badge_id = ?')
      .run(guildId, String(userId), targetId);

    return { success: res.changes > 0, badge_id: targetId };
  } catch (err) {
    return { success: false, reason: err.message };
  }
}

/**
 * Creates a custom badge for a guild.
 */
function createBadge(guildId, badgeId, name, emoji, description, sdb) {
  const db = sdb || getServerDb(guildId);
  const normalizedId = String(badgeId || name).trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_');

  try {
    db.prepare(`
      INSERT INTO guild_badges (guild_id, badge_id, name, emoji, description)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, badge_id) DO UPDATE SET
        name = excluded.name,
        emoji = excluded.emoji,
        description = excluded.description
    `).run(guildId, normalizedId, String(name).trim(), String(emoji).trim(), String(description || '').trim());

    return {
      success: true,
      badge: {
        badge_id: normalizedId,
        name: String(name).trim(),
        emoji: String(emoji).trim(),
        description: String(description || '').trim()
      }
    };
  } catch (err) {
    return { success: false, reason: err.message };
  }
}

/**
 * Retrieves earned badges and locked built-in achievements for a user.
 */
function getUserAchievements(guildId, userId, sdb) {
  const db = sdb || getServerDb(guildId);
  const earnedRows = db.prepare(`
    SELECT badge_id, earned_at
    FROM user_achievements
    WHERE guild_id = ? AND user_id = ?
    ORDER BY earned_at DESC
  `).all(guildId, String(userId));

  const customRows = db.prepare('SELECT badge_id, name, emoji, description FROM guild_badges WHERE guild_id = ?').all(guildId);
  const customMap = new Map();
  for (const c of customRows) {
    customMap.set(c.badge_id, c);
  }

  const earned = [];
  const earnedSet = new Set();

  for (const row of earnedRows) {
    earnedSet.add(row.badge_id);
    if (BUILTIN_ACHIEVEMENTS[row.badge_id]) {
      earned.push({
        ...BUILTIN_ACHIEVEMENTS[row.badge_id],
        isCustom: false,
        earned_at: row.earned_at
      });
    } else if (customMap.has(row.badge_id)) {
      const c = customMap.get(row.badge_id);
      earned.push({
        id: c.badge_id,
        name: c.name,
        emoji: c.emoji,
        description: c.description,
        isCustom: true,
        earned_at: row.earned_at
      });
    } else {
      earned.push({
        id: row.badge_id,
        name: row.badge_id,
        emoji: EMOJIS.MEDAL_GOLD,
        description: 'Guild Badge',
        isCustom: true,
        earned_at: row.earned_at
      });
    }
  }

  const locked = [];
  for (const [id, def] of Object.entries(BUILTIN_ACHIEVEMENTS)) {
    if (!earnedSet.has(id)) {
      locked.push(def);
    }
  }

  return {
    earned,
    locked,
    totalEarned: earned.length,
    totalAvailable: Object.keys(BUILTIN_ACHIEVEMENTS).length + customRows.length
  };
}

/**
 * Fetches badge count leaderboard for the guild.
 */
function getBadgeLeaderboard(guildId, sdb, limit = 10) {
  const db = sdb || getServerDb(guildId);
  try {
    const rows = db.prepare(`
      SELECT user_id, COUNT(*) as badge_count
      FROM user_achievements
      WHERE guild_id = ?
      GROUP BY user_id
      ORDER BY badge_count DESC, MAX(earned_at) ASC
      LIMIT ?
    `).all(guildId, limit);
    return rows;
  } catch (_) {
    return [];
  }
}

/**
 * Retrieves all custom badges created for a guild.
 */
function getGuildBadges(guildId, sdb) {
  const db = sdb || getServerDb(guildId);
  try {
    return db.prepare('SELECT badge_id, name, emoji, description FROM guild_badges WHERE guild_id = ?').all(guildId);
  } catch (_) {
    return [];
  }
}

module.exports = {
  BUILTIN_ACHIEVEMENTS,
  checkAndAwardAchievements,
  awardBadge,
  revokeBadge,
  createBadge,
  getUserAchievements,
  getBadgeLeaderboard,
  getGuildBadges
};
