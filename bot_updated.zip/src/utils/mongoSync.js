/**
 * Celestia / Tungsten MongoDB Synchronization & Migration Engine
 * Pushes and mirrors all SQLite databases (master DB and all per-server DBs)
 * to MongoDB Atlas with idempotent bulk upserts, index management, and telemetry.
 */
const fs = require('fs');
const path = require('path');
const { getMongoDb, initMongo, isMongoConnected } = require('./mongoClient');

const _INDEXED_COLLECTIONS = new Set();
let _periodicSyncInterval = null;
let _isSyncInProgress = false;

/**
 * Normalizes SQLite table values for safe MongoDB BSON storage.
 * - Converts 64-bit BigInt snowflakes to Strings.
 * - Converts JSON string blobs if parseable or leaves as string.
 */
function normalizeMongoDoc(row) {
  if (!row || typeof row !== 'object') return row;
  const doc = {};
  for (const [k, v] of Object.entries(row)) {
    if (typeof v === 'bigint') {
      doc[k] = v.toString();
    } else if (v === null || v === undefined) {
      doc[k] = null;
    } else if (typeof v === 'string') {
      // If it looks like a JSON object or array, try to store as native JSON for rich querying
      if ((v.startsWith('{') && v.endsWith('}')) || (v.startsWith('[') && v.endsWith(']'))) {
        try {
          doc[k] = JSON.parse(v);
        } catch (_) {
          doc[k] = v;
        }
      } else {
        doc[k] = v;
      }
    } else {
      doc[k] = v;
    }
  }
  return doc;
}

/**
 * Resolves the primary key columns for an SQLite table
 */
function getPrimaryKeyColumns(sqliteDb, tableName) {
  try {
    const cols = sqliteDb.prepare(`PRAGMA table_info("${tableName}")`).all();
    const pkCols = cols.filter(c => c.pk > 0).sort((a, b) => a.pk - b.pk).map(c => c.name);
    return pkCols;
  } catch (_) {
    return [];
  }
}

/**
 * Pushes an entire SQLite database (all tables and rows) to MongoDB collections.
 * @param {object} sqliteDb - Open SQLite instance
 * @param {object} mongoDb - Connected MongoDB Database instance
 * @param {object} options - { prefix: 'master'|'guild', guildId: string|null, logger: Function }
 */
async function pushSqliteDbToMongo(sqliteDb, mongoDb, options = {}) {
  const { prefix = 'master', guildId = null, logger = console.log } = options;
  const stats = { tablesCount: 0, rowsCount: 0, skippedEmpty: 0 };

  const tables = sqliteDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();

  for (const table of tables) {
    const tableName = table.name;
    const rows = sqliteDb.prepare(`SELECT * FROM "${tableName}"`).all();
    if (!rows || rows.length === 0) {
      stats.skippedEmpty++;
      continue;
    }

    const collName = prefix === 'guild' ? 'guild_records' : 'master_records';
    const collection = mongoDb.collection(collName);

    // Ensure optimized composite indexes once per consolidated collection
    if (!_INDEXED_COLLECTIONS.has(collName)) {
      _INDEXED_COLLECTIONS.add(collName);
      if (prefix === 'guild') {
        collection.createIndex({ guild_id: 1, table: 1 }).catch(() => null);
      } else {
        collection.createIndex({ table: 1 }).catch(() => null);
      }
    }

    stats.tablesCount++;
    const pkCols = getPrimaryKeyColumns(sqliteDb, tableName);

    // Prepare bulk upsert operations in chunks of 500
    const CHUNK_SIZE = 500;
    for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
      const chunk = rows.slice(i, i + CHUNK_SIZE);
      const bulkOps = chunk.map((rawRow, idx) => {
        const doc = normalizeMongoDoc(rawRow);
        doc.table = tableName;
        if (prefix === 'guild' && guildId) {
          doc.guild_id = String(guildId);
        }

        // Construct unique deterministic _id
        let customId;
        if (pkCols.length > 0) {
          const pkVals = pkCols.map(col => String(rawRow[col] ?? ''));
          customId = prefix === 'guild' && guildId
            ? `${guildId}:${tableName}:${pkVals.join(':')}`
            : `${tableName}:${pkVals.join(':')}`;
        } else if (rawRow.id) {
          customId = prefix === 'guild' && guildId ? `${guildId}:${tableName}:${rawRow.id}` : `${tableName}:${rawRow.id}`;
        } else if (rawRow.key) {
          customId = prefix === 'guild' && guildId ? `${guildId}:${tableName}:${rawRow.key}` : `${tableName}:${rawRow.key}`;
        } else {
          customId = prefix === 'guild' && guildId ? `${guildId}:${tableName}:${i + idx}` : `${tableName}:${i + idx}`;
        }

        doc._id = customId;
        doc._synced_at = new Date();

        return {
          replaceOne: {
            filter: { _id: customId },
            replacement: doc,
            upsert: true
          }
        };
      });

      if (bulkOps.length > 0) {
        await collection.bulkWrite(bulkOps, { ordered: false });
        stats.rowsCount += bulkOps.length;
      }
    }
  }

  return stats;
}

/**
 * Pushes all SQLite databases (master DB + all guild DBs) to MongoDB Atlas.
 */
async function pushAllDatabasesToMongo(options = {}) {
  const startTime = Date.now();
  const logger = options.logger || console.log;

  let mongoDb = getMongoDb();
  if (!mongoDb) {
    const initRes = await initMongo();
    if (!initRes || !initRes.db) {
      throw new Error('Could not establish connection to MongoDB Atlas. Check MONGODB_URI in .env.');
    }
    mongoDb = initRes.db;
  }

  const { openDatabase } = require('./sqliteDb');
  const { isMongoCloudMode, getMasterDb, getAllCachedGuildDbs, _DB_CACHE } = require('./serverDb');
  const inCloud = typeof isMongoCloudMode === 'function' ? isMongoCloudMode() : false;
  const ROOT_DIR = path.resolve(__dirname, '..', '..');
  const DB_DIR = (process.env.TUNGSTEN_DB_DIR || process.env.CELESTIA_DB_DIR)
    ? path.resolve(process.env.TUNGSTEN_DB_DIR || process.env.CELESTIA_DB_DIR)
    : path.join(ROOT_DIR, 'db');

  const summary = {
    success: false,
    databaseName: mongoDb.databaseName,
    masterTablesCount: 0,
    masterRowsCount: 0,
    guildsCount: 0,
    guildTablesCount: 0,
    guildRowsCount: 0,
    totalDocuments: 0,
    durationMs: 0
  };

  logger('[MongoSync] Beginning comprehensive push to MongoDB Atlas...');

  // Purge/Drop legacy database if present to reclaim 150MB overhead
  try {
    const { getMongoClient } = require('./mongoClient');
    const client = getMongoClient();
    if (client) {
      await client.db('celestia_bot').dropDatabase().catch(() => null);
    }
  } catch (_) {}

  // 1. Push Master Database
  if (inCloud) {
    try {
      const mdb = getMasterDb();
      logger('[MongoSync] Pushing master database (in-memory)...');
      const masterStats = await pushSqliteDbToMongo(mdb, mongoDb, {
        prefix: 'master',
        logger
      });
      summary.masterTablesCount = masterStats.tablesCount;
      summary.masterRowsCount = masterStats.rowsCount;
      summary.totalDocuments += masterStats.rowsCount;
      logger(`[MongoSync] Master DB pushed: ${masterStats.tablesCount} tables, ${masterStats.rowsCount} documents.`);
    } catch (err) {
      logger(`[MongoSync Error] Failed pushing in-memory master DB: ${err.message}`);
    }
  } else {
    const masterDbPath = path.join(DB_DIR, 'tungsten.db');
    if (fs.existsSync(masterDbPath)) {
      try {
        const mdb = openDatabase(masterDbPath);
        logger(`[MongoSync] Pushing master database (${masterDbPath})...`);
        const masterStats = await pushSqliteDbToMongo(mdb, mongoDb, {
          prefix: 'master',
          logger
        });
        mdb.close();
        summary.masterTablesCount = masterStats.tablesCount;
        summary.masterRowsCount = masterStats.rowsCount;
        summary.totalDocuments += masterStats.rowsCount;
        logger(`[MongoSync] Master DB pushed: ${masterStats.tablesCount} tables, ${masterStats.rowsCount} documents.`);
      } catch (err) {
        logger(`[MongoSync Error] Failed pushing master DB: ${err.message}`);
      }
    }
  }

  // 2. Push Per-Server Databases
  const pushedGuilds = new Set();

  if (inCloud) {
    const cachedDbs = getAllCachedGuildDbs ? getAllCachedGuildDbs() : _DB_CACHE;
    if (cachedDbs && cachedDbs.size > 0) {
      for (const [gid, sdb] of cachedDbs.entries()) {
        try {
          pushedGuilds.add(String(gid));
          const guildStats = await pushSqliteDbToMongo(sdb, mongoDb, {
            prefix: 'guild',
            guildId: gid,
            logger
          });
          summary.guildsCount++;
          summary.guildTablesCount += guildStats.tablesCount;
          summary.guildRowsCount += guildStats.rowsCount;
          summary.totalDocuments += guildStats.rowsCount;
        } catch (err) {
          logger(`[MongoSync Error] Failed pushing in-memory guild ${gid}: ${err.message}`);
        }
      }
    }
  }

  // Also check serversBaseDir on disk if it exists
  const serversBaseDir = path.join(DB_DIR, 'servers');
  if (fs.existsSync(serversBaseDir)) {
    const guildDirs = fs.readdirSync(serversBaseDir);
    for (const gid of guildDirs) {
      if (pushedGuilds.has(String(gid))) continue;
      const serverDbPath = path.join(serversBaseDir, gid, 'server.db');
      if (fs.existsSync(serverDbPath)) {
        try {
          const sdb = openDatabase(serverDbPath);
          const guildStats = await pushSqliteDbToMongo(sdb, mongoDb, {
            prefix: 'guild',
            guildId: gid,
            logger
          });
          sdb.close();
          pushedGuilds.add(String(gid));
          summary.guildsCount++;
          summary.guildTablesCount += guildStats.tablesCount;
          summary.guildRowsCount += guildStats.rowsCount;
          summary.totalDocuments += guildStats.rowsCount;
        } catch (err) {
          logger(`[MongoSync Error] Failed pushing guild ${gid}: ${err.message}`);
        }
      }
    }
  }

  logger(`[MongoSync] Pushed ${summary.guildsCount} guild databases (${summary.guildRowsCount} documents).`);

  summary.durationMs = Date.now() - startTime;
  summary.success = true;
  logger(`[MongoSync Complete] Successfully pushed ${summary.totalDocuments} total documents in ${summary.durationMs}ms.`);
  return summary;
}

/**
 * Starts continuous background periodic sync to MongoDB Atlas
 */
function startPeriodicMongoSync(intervalMinutes = 30) {
  if (_periodicSyncInterval) {
    clearInterval(_periodicSyncInterval);
  }

  const ms = Math.max(intervalMinutes, 5) * 60 * 1000;
  _periodicSyncInterval = setInterval(async () => {
    if (_isSyncInProgress) return;
    _isSyncInProgress = true;
    try {
      if (isMongoConnected()) {
        await pushAllDatabasesToMongo({ logger: () => {} });
      }
    } catch (e) {
      console.warn('[MongoSync Periodic Warning]:', e.message);
    } finally {
      _isSyncInProgress = false;
    }
  }, ms).unref();

  console.log(`[MongoSync] Periodic replication active (every ${intervalMinutes}m).`);
}

/**
 * Stops periodic sync
 */
function stopPeriodicMongoSync() {
  if (_periodicSyncInterval) {
    clearInterval(_periodicSyncInterval);
    _periodicSyncInterval = null;
  }
}

module.exports = {
  normalizeMongoDoc,
  pushSqliteDbToMongo,
  pushAllDatabasesToMongo,
  startPeriodicMongoSync,
  stopPeriodicMongoSync
};
