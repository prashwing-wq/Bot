/**
 * Tungsten Discord Components V2 Layout Engine (Node.js)
 * Implements Discord Components V2 container architecture, cards, sections,
 * subtext formatting, and persistent per-guild Components V2 preferences.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  StringSelectMenuBuilder,
  ButtonStyle,
  EmbedBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  MessageFlags
} = require('discord.js');
const { getMasterDb } = require('./serverDb');
const config = require('../config');

// In-memory cache for fast sub-millisecond access
const _V2_GUILD_CACHE = new Map();

const V2_BUTTON_PANEL_REGEX = /(?:\r?\n\r?\n|\r?\n|^)\*\*Components V2 •[^\n]*\r?\n```ansi[\s\S]*?```(?:\r?\n-# [^\n]*)?/g;

/**
 * Strips any existing Components V2 in-embed button panels from a description string.
 */
function stripButtonPanel(desc) {
  if (!desc) return '';
  return String(desc)
    .replace(/(?:\r?\n\r?\n|\r?\n|^)\*\*Components V2 •[^\n]*\r?\n```(?:ansi)?[\s\S]*?```(?:\r?\n-# [^\n]*)?/g, '')
    .replace(/(?:\r?\n\r?\n|\r?\n|^)\*\*Components V2 •[^\n]*\*\*(?:\r?\n```(?:ansi)?[\s\S]*?```)?(?:\r?\n-# [^\n]*)?/g, '')
    .trim();
}

/**
 * Safely truncates an embed description ensuring open markdown codeblocks are closed.
 */
function safeTruncateDescription(desc, maxLen) {
  if (!desc || desc.length <= maxLen) return desc || '';
  const targetLen = Math.max(0, maxLen - 3);
  let truncated = desc.slice(0, targetLen).trim() + '...';
  const codeBlocks = (truncated.match(/```/g) || []).length;
  if (codeBlocks % 2 !== 0) {
    truncated += '\n```';
  }
  return truncated;
}

/**
 * Cleans custom and unicode emojis for ANSI codeblocks.
 * Returns empty string '' so default unicode emojis ('🛡️ ', '⚠️ ', etc.)
 * are NEVER injected into in-embed panels.
 */
function cleanEmojiForAnsi(em) {
  return '';
}

/**
 * Formats an in-embed Components V2 visual button control panel (text badge mode).
 * Compatible with ButtonBuilder instances, plain objects, and raw component JSON.
 */
function formatButtonPanel(buttons = [], title = 'Interactive Controls') {
  if (!buttons || buttons.length === 0) return '';
  const badges = [];
  for (const b of buttons) {
    if (!b) continue;
    const raw = (b.data ? b.data : (typeof b.toJSON === 'function' ? b.toJSON() : b)) || {};
    const rawLabel = raw.label || b.label || '';
    const style = raw.style !== undefined ? raw.style : b.style;
    const emoji = raw.emoji || b.emoji || null;
    const disabled = Boolean(raw.disabled !== undefined ? raw.disabled : b.disabled);

    let colorCode = '1;34m'; // Primary / Blurple default
    if (disabled) {
      colorCode = '0;30m';
    } else if (style === ButtonStyle.Success || style === 3 || String(style).toLowerCase() === 'success') {
      colorCode = '1;32m';
    } else if (style === ButtonStyle.Danger || style === 4 || String(style).toLowerCase() === 'danger') {
      colorCode = '1;31m';
    } else if (style === ButtonStyle.Secondary || style === 2 || String(style).toLowerCase() === 'secondary') {
      colorCode = '1;30m';
    } else if (style === ButtonStyle.Link || style === 5 || String(style).toLowerCase() === 'link') {
      colorCode = '1;36m';
    }

    const em = cleanEmojiForAnsi(emoji);
    let displayText = '';
    if (rawLabel && em) {
      displayText = `${em}${rawLabel}`;
    } else if (rawLabel) {
      displayText = rawLabel;
    } else if (em) {
      displayText = em.trim();
    } else {
      displayText = 'Action';
    }

    badges.push(`\u001b[${colorCode}[ ${displayText} ]\u001b[0m`);
  }

  if (badges.length === 0) return '';

  const lines = [];
  for (let i = 0; i < badges.length; i += 3) {
    lines.push('  ' + badges.slice(i, i + 3).join('   '));
  }

  return (
    `\n\n**Components V2 • ${title}**\n` +
    `\`\`\`ansi\n` +
    `${lines.join('\n')}\n` +
    `\`\`\`\n` +
    `-# All interactive buttons are integrated directly into this card.`
  );
}

/**
 * Attaches the in-embed button controls panel directly into any EmbedBuilder or raw embed object.
 */
function attachButtonsToEmbed(embed, buttons = [], title = null) {
  if (!embed || !buttons || buttons.length === 0) return embed;
  const isBuilder = embed instanceof EmbedBuilder;
  const raw = isBuilder ? embed.toJSON() : (embed || {});
  const currentDesc = String(raw.description || '');

  // Preserve existing custom title if present and default title was specified
  let resolvedTitle = title;
  if (!resolvedTitle || resolvedTitle === 'Interactive Controls') {
    const existingTitleMatch = currentDesc.match(/\*\*Components V2 • ([^\*\n]+)\*\*/);
    if (existingTitleMatch && existingTitleMatch[1]) {
      resolvedTitle = existingTitleMatch[1];
    } else {
      resolvedTitle = resolvedTitle || 'Interactive Controls';
    }
  }

  let desc = stripButtonPanel(currentDesc);
  const panel = formatButtonPanel(buttons, resolvedTitle);
  if (!panel) return embed;

  if (desc.length + panel.length > 4000) {
    desc = safeTruncateDescription(desc, 4000 - panel.length);
  }

  const finalDesc = desc ? `${desc}${panel}` : panel.trim();

  if (isBuilder) {
    embed.setDescription(finalDesc);
    return embed;
  } else {
    return { ...embed, description: finalDesc };
  }
}

const V2_CACHE_TTL = 300000; // 5 minutes

/**
 * Check if Components V2 mode is enabled for a guild (default: true).
 */
function isComponentsV2Enabled(guildId) {
  if (!guildId) return true;
  const cached = _V2_GUILD_CACHE.get(guildId);
  if (cached && (Date.now() - cached.ts < V2_CACHE_TTL)) {
    return cached.enabled;
  }

  try {
    const db = getMasterDb();
    db.prepare(`
      CREATE TABLE IF NOT EXISTS components_v2_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1
      )
    `).run();

    const row = db.prepare('SELECT enabled FROM components_v2_settings WHERE guild_id = ?').get(String(guildId));
    const enabled = row ? Boolean(row.enabled) : true;
    _V2_GUILD_CACHE.set(guildId, { enabled, ts: Date.now() });
    return enabled;
  } catch (e) {
    return true;
  }
}

/**
 * Set Components V2 mode enabled/disabled for a guild.
 */
function setComponentsV2Enabled(guildId, enabled) {
  if (!guildId) return;
  _V2_GUILD_CACHE.set(guildId, { enabled: Boolean(enabled), ts: Date.now() });

  try {
    const db = getMasterDb();
    db.prepare(`
      CREATE TABLE IF NOT EXISTS components_v2_settings (
        guild_id TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1
      )
    `).run();

    db.prepare(`
      INSERT INTO components_v2_settings (guild_id, enabled)
      VALUES (?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET enabled = excluded.enabled
    `).run(String(guildId), enabled ? 1 : 0);
  } catch (e) {
    console.warn(`[ComponentsV2] Failed to persist guild ${guildId} setting:`, e.message);
  }
}

/**
 * Creates a Discord Components V2 compliant card embed.
 */
function createV2Card({
  title,
  description = '',
  fields = [],
  color = 0x000000,
  footerText = null,
  footerIcon = null,
  thumbnailUrl = null,
  authorName = null,
  authorIcon = null,
  buttons = [],
  buttonTitle = 'Interactive Controls'
}) {
  const embed = new EmbedBuilder();

  if (title) {
    embed.setTitle(title);
  }

  let fullDescription = description;
  if (buttons && buttons.length > 0) {
    fullDescription += formatButtonPanel(buttons, buttonTitle);
  }

  if (fullDescription) {
    embed.setDescription(fullDescription);
  }

  if (fields && fields.length > 0) {
    for (const f of fields) {
      if (f && f.name && f.value) {
        embed.addFields({
          name: f.name,
          value: f.value,
          inline: Boolean(f.inline)
        });
      }
    }
  }

  if (authorName) {
    embed.setAuthor({
      name: authorName,
      iconURL: authorIcon || undefined
    });
  }

  if (thumbnailUrl) {
    embed.setThumbnail(thumbnailUrl);
  }

  if (footerText) {
    embed.setFooter({
      text: footerText,
      iconURL: footerIcon || undefined
    });
  }

  return embed;
}

/**
 * Helper to construct an ActionRow with buttons.
 */
function createButtonRow(buttons = []) {
  const row = new ActionRowBuilder();
  for (const b of buttons) {
    const btn = new ButtonBuilder()
      .setCustomId(b.customId || `btn_${Math.random().toString(36).substring(7)}`)
      .setLabel(b.label || 'Action')
      .setStyle(b.style || ButtonStyle.Secondary);
    if (b.emoji) btn.setEmoji(b.emoji);
    if (b.disabled !== undefined) btn.setDisabled(Boolean(b.disabled));
    if (b.url) {
      btn.setURL(b.url);
      btn.setStyle(ButtonStyle.Link);
    }
    row.addComponents(btn);
  }
  return row;
}

/**
 * Helper to construct an ActionRow with a SelectMenu.
 */
function createSelectMenuRow({
  customId,
  placeholder,
  options = [],
  minValues = 1,
  maxValues = 1,
  disabled = false
}) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(customId)
    .setPlaceholder(placeholder || 'Select an option...')
    .setMinValues(minValues)
    .setMaxValues(maxValues)
    .setDisabled(disabled)
    .addOptions(options);

  return new ActionRowBuilder().addComponents(menu);
}

/**
 * Creates a native Discord Components V2 Type 17 Container.
 * Houses ActionRows and Buttons physically inside the container card.
 */
function createV2Container({
  title,
  description = '',
  color = config.COLORS?.PRIMARY || 0x000001,
  buttons = [],
  actionRows = []
}) {
  const { embedToContainer } = require('./patchComponentsV2');
  const embed = new EmbedBuilder();
  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);

  const rows = [];
  if (buttons && buttons.length > 0) {
    rows.push(createButtonRow(buttons));
  }
  for (const ar of actionRows) {
    rows.push(ar);
  }

  return embedToContainer(embed, rows);
}

/**
 * Creates a universal Components V2 response payload.
 * Houses all interactive action rows and buttons INSIDE the container card.
 */
function createV2Payload({
  title,
  description = '',
  color = config.COLORS?.PRIMARY || 0x000001,
  buttons = [],
  actionRows = [],
  fields = [],
  footerText = null,
  thumbnailUrl = null,
  authorName = null,
  authorIcon = null
}) {
  const { embedToContainer } = require('./patchComponentsV2');
  const card = createV2Card({
    title,
    description,
    color,
    fields,
    footerText,
    thumbnailUrl,
    authorName,
    authorIcon,
    buttons: []
  });

  const components = [];
  if (buttons && buttons.length > 0) {
    components.push(createButtonRow(buttons));
  }
  for (const ar of actionRows) {
    components.push(ar);
  }

  const { isSelectMenuRow } = require('./patchComponentsV2');
  const buttonRows = [];
  const selectRows = [];
  for (const row of components) {
    if (!row) continue;
    if (typeof isSelectMenuRow === 'function' && isSelectMenuRow(row)) {
      selectRows.push(row);
    } else {
      buttonRows.push(row);
    }
  }

  const container = embedToContainer(card, buttonRows);
  return {
    components: [container, ...selectRows].slice(0, 5),
    flags: MessageFlags.IsComponentsV2
  };
}

function clearV2Cache(guildId) {
  if (guildId) _V2_GUILD_CACHE.delete(guildId);
  else _V2_GUILD_CACHE.clear();
}

module.exports = {
  isComponentsV2Enabled,
  setComponentsV2Enabled,
  clearV2Cache,
  createV2Card,
  createV2Container,
  createV2Payload,
  formatButtonPanel,
  cleanEmojiForAnsi,
  attachButtonsToEmbed,
  createButtonRow,
  createSelectMenuRow,
  stripButtonPanel,
  safeTruncateDescription
};
