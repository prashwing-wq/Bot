/**
 * Tungsten Modules Management Helper (Node.js)
 * Manages per-guild feature toggles across core bot subsystems.
 */
const { getServerDb } = require('./serverDb');

const AVAILABLE_MODULES = [
  { id: 'antinuke', name: 'Antinuke Defense', description: 'Zero-bypass antinuke and fortress protection', default: 1 },
  { id: 'automod', name: 'Automod Sentinel', description: 'Anti-spam, anti-link, bad words and strike ladder', default: 1 },
  { id: 'welcomer', name: 'Welcomer Studio', description: 'Custom welcome cards, leave logs, and autorole', default: 1 },
  { id: 'starboard', name: 'Starboard', description: 'Pin top messages based on community star reactions', default: 1 },
  { id: 'suggestions', name: 'Suggestions', description: 'Community suggestions system with live interactive voting', default: 1 },
  { id: 'warnladder', name: 'Warning Escalation Ladder', description: 'Automated punishments for cumulative infractions', default: 1 },
  { id: 'leveling', name: 'Leveling & XP', description: 'Text XP progression and leaderboard tracking', default: 0 },
  { id: 'economy', name: 'Virtual Economy', description: 'Daily rewards, wallet, bank, and currency games', default: 1 },
  { id: 'tickets', name: 'Ticket Support', description: 'Interactive support ticket channels and transcripts', default: 1 },
  { id: 'giveaways', name: 'Giveaways', description: 'Automated prize giveaways and scheduled rollings', default: 1 },
  { id: 'polls', name: 'Interactive Polls', description: 'Interactive community polls with live visual progress bars', default: 1 },
  { id: 'media', name: 'Media & Voice', description: 'Voice master, join-to-create channels, and VC tools', default: 1 }
];

function isModuleEnabled(guildId, moduleName) {
  if (!guildId) return true;
  const modKey = String(moduleName).toLowerCase().trim();
  const def = AVAILABLE_MODULES.find(m => m.id === modKey);
  const defaultVal = def ? def.default === 1 : true;

  try {
    const sdb = getServerDb(guildId);
    if (!sdb) return defaultVal;

    if (modKey === 'leveling') {
      const sRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leveling_enabled'").get();
      if (sRow && sRow.value === '0') return false;
      if (sRow && sRow.value === '1') return true;
    }

    const row = sdb.prepare('SELECT enabled FROM guild_modules WHERE guild_id = ? AND module_name = ?').get(String(guildId), modKey);
    if (row !== undefined && row !== null) {
      return row.enabled === 1;
    }
    return defaultVal;
  } catch (e) {
    return defaultVal;
  }
}

function setModuleStatus(guildId, moduleName, enabled) {
  if (!guildId) return false;
  const modKey = String(moduleName).toLowerCase().trim();
  const val = enabled ? 1 : 0;
  const sdb = getServerDb(guildId);
  const now = Math.floor(Date.now() / 1000);

  sdb.prepare(`
    INSERT INTO guild_modules (guild_id, module_name, enabled, updated_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(guild_id, module_name) DO UPDATE SET
      enabled = excluded.enabled,
      updated_at = excluded.updated_at
  `).run(String(guildId), modKey, val, now);

  if (modKey === 'leveling') {
    sdb.prepare(`
      INSERT INTO server_settings (key, value) VALUES ('leveling_enabled', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(String(val));
  }

  return val === 1;
}

function toggleModule(guildId, moduleName) {
  const current = isModuleEnabled(guildId, moduleName);
  const target = !current;
  setModuleStatus(guildId, moduleName, target);
  return target;
}

function getAllModuleStatuses(guildId) {
  const result = {};
  for (const m of AVAILABLE_MODULES) {
    result[m.id] = {
      ...m,
      enabled: isModuleEnabled(guildId, m.id)
    };
  }
  return result;
}

module.exports = {
  AVAILABLE_MODULES,
  isModuleEnabled,
  setModuleStatus,
  toggleModule,
  getAllModuleStatuses
};
