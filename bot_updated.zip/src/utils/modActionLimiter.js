/**
 * Tungsten Confused Deputy & Moderator Action Limiter (C10)
 * Prevents rogue administrators or compromised accounts from executing mass destructive actions
 * through Tungsten's own moderation commands (!ban, !kick, !purge, !nuke, !lock, etc.).
 */
const { isOwner } = require('./tools');
const { getServerDb } = require('./serverDb');
const { dispatchSecurityAlert } = require('./antinukeEngine');
const { resolveEmoji } = require('./emojis');
const config = require('../config');

// In-memory sliding windows: key `${guildId}:${userId}:${action}` -> array of timestamps
const _MOD_ACTION_WINDOWS = new Map();

// Default limits and windows
const DEFAULT_LIMITS = {
  ban: { limit: 3, windowMs: 10 * 60 * 1000 },       // 3 bans per 10 min
  kick: { limit: 5, windowMs: 10 * 60 * 1000 },      // 5 kicks per 10 min
  purge: { limit: 5, windowMs: 5 * 60 * 1000 },      // 5 purges per 5 min
  channel: { limit: 3, windowMs: 5 * 60 * 1000 }     // 3 channel nuke/lock/hides per 5 min
};

/**
 * Checks if a moderator is allowed to execute a destructive action.
 * @returns {{ allowed: boolean, remainingTime?: number, limit?: number }}
 */
async function checkModAction(guild, userId, action) {
  if (!guild || !userId) return { allowed: true };
  const uid = String(userId);
  const gid = String(guild.id);

  // Server owner & bot owners bypass
  if (guild.ownerId === uid || isOwner(uid)) {
    return { allowed: true };
  }

  // Validation assertion: ensure action key is valid (ban, kick, purge, channel) with fallback
  const VALID_MOD_ACTIONS = Object.keys(DEFAULT_LIMITS);
  if (!VALID_MOD_ACTIONS.includes(action)) {
    console.warn(`[ModActionLimiter] Unknown action key: ${action} — falling back to 'ban' limits`);
    action = 'ban';
  }

  // Check extra owners
  let isExtraOwner = false;
  let isWhitelisted = false;
  try {
    const sdb = getServerDb(gid);
    const eo = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(gid, uid);
    if (eo) isExtraOwner = true;

    const wl = sdb.prepare(`
      SELECT 1 FROM whitelisted_users
      WHERE guild_id = ? AND user_id = ? AND (action = 'all' OR action = ?)
    `).get(gid, uid, action);
    if (wl) isWhitelisted = true;
  } catch (e) {}

  if (isExtraOwner) return { allowed: true };

  let { limit, windowMs } = DEFAULT_LIMITS[action] || DEFAULT_LIMITS.ban;

  // Whitelisted users receive 4x higher threshold allowance
  if (isWhitelisted) {
    limit = limit * 4;
  }

  // Check DB-persisted windows for critical actions (ban, kick) so action counts survive bot restarts
  const isCritical = action === 'ban' || action === 'kick';

  if (isCritical) {
    try {
      const sdb = getServerDb(gid);
      const windowStart = Math.floor((Date.now() - windowMs) / 1000);

      const recentCount = sdb.prepare(`
        SELECT COUNT(*) as cnt, MIN(timestamp) as oldest_ts FROM audit_logs
        WHERE action = ? AND actor_id = ? AND timestamp > ?
      `).get(`mod_${action}`, uid, windowStart);

      if (recentCount && recentCount.cnt >= limit) {
        const oldestMs = recentCount.oldest_ts ? recentCount.oldest_ts * 1000 : (Date.now() - windowMs);
        const remainingTime = Math.max(1, Math.ceil((windowMs - (Date.now() - oldestMs)) / 1000));

        // Alert server owners about the rate-limited moderator attempt
        dispatchSecurityAlert(guild, {
          title: `${resolveEmoji(guild, 'warning')} Confused Deputy Sentinel Tripped`,
          description: `Moderator <@${uid}> (\`${uid}\`) exceeded the safe action quota for **${action.toUpperCase()}** (\`${recentCount.cnt}/${limit}\` within \`${windowMs / 60000}m\`).\nExecution was blocked to protect server integrity. Cooldown remaining: **${remainingTime}s**.`,
          color: config.COLORS.WARNING
        });

        return { allowed: false, remainingTime, limit };
      }

      // Record the action in DB audit_logs
      sdb.prepare(`
        INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
        VALUES (?, ?, ?, ?, ?)
      `).run(`mod_${action}`, uid, gid, `Moderator ${action} action`, Math.floor(Date.now() / 1000));
    } catch (e) {
      // Fall through to in-memory check if DB fails
    }
  }

  const key = `${gid}:${uid}:${action}`;
  const now = Date.now();
  let timestamps = _MOD_ACTION_WINDOWS.get(key) || [];
  timestamps = timestamps.filter(t => now - t < windowMs);

  if (timestamps.length >= limit) {
    const oldest = timestamps[0];
    const remainingTime = Math.ceil((windowMs - (now - oldest)) / 1000);

    // Alert server owners about the rate-limited moderator attempt
    dispatchSecurityAlert(guild, {
      title: `${resolveEmoji(guild, 'warning')} Confused Deputy Sentinel Tripped`,
      description: `Moderator <@${uid}> (\`${uid}\`) exceeded the safe action quota for **${action.toUpperCase()}** (\`${timestamps.length}/${limit}\` within \`${windowMs / 60000}m\`).\nExecution was blocked to protect server integrity. Cooldown remaining: **${remainingTime}s**.`,
      color: config.COLORS.WARNING
    });

    return { allowed: false, remainingTime, limit };
  }

  timestamps.push(now);
  _MOD_ACTION_WINDOWS.set(key, timestamps);

  if (timestamps.length === 1) {
    setTimeout(() => {
      const cur = _MOD_ACTION_WINDOWS.get(key);
      if (cur && cur.every(t => Date.now() - t >= windowMs)) {
        _MOD_ACTION_WINDOWS.delete(key);
      }
    }, windowMs + 1000).unref();
  }

  return { allowed: true };
}

module.exports = {
  checkModAction,
  DEFAULT_LIMITS
};
