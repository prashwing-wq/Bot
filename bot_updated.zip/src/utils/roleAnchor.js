/**
 * Tungsten Role Position Auto-Anchor Sentinel (NEW FEATURE 5)
 * Continuous background verification and autonomous re-anchoring of Tungsten's role hierarchy.
 * Wick / Olympus / Zynrax enterprise security parity.
 */
const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const { getServerDb } = require('./serverDb');
const { dispatchSecurityAlert, ensureDualBackupRoles, createServerSnapshot } = require('./antinukeEngine');
const { resolveEmoji } = require('./emojis');
const config = require('../config');

let _roleAnchorInterval = null;

/**
 * Calculates the highest possible role position Tungsten should occupy,
 * sitting immediately below immutable Discord system roles.
 * @param {object} guild - Discord Guild
 * @param {object} botRole - Tungsten's highest role
 * @returns {number} Target role position integer
 */
function calculateHighestPossiblePosition(guild, botRole) {
  if (!guild?.roles?.cache || !botRole) return botRole?.position || 0;
  const roles = [...guild.roles.cache.values()].filter(r => r.id !== guild.id);
  if (roles.length === 0) return botRole.position;

  // Discord system roles (managed integration roles, Nitro booster role)
  const isSystemRole = (r) => Boolean(r.managed || r.tags?.premiumSubscriberRole !== undefined);

  // Sort descending by hierarchy position
  roles.sort((a, b) => b.position - a.position);

  let targetPos = roles[0].position;
  let nonSystemFoundAbove = false;

  for (const r of roles) {
    if (r.id === botRole.id) {
      break;
    }
    if (isSystemRole(r)) {
      targetPos = r.position - 1;
    } else {
      nonSystemFoundAbove = true;
      targetPos = Math.max(r.position, targetPos);
      break;
    }
  }

  return Math.max(botRole.position, targetPos);
}

/**
 * Sends a high-priority alert to the server owner when Tungsten's role hierarchy
 * has been demoted and the bot lacks authority to auto-correct it.
 */
async function notifyServerOwnerHierarchyFailure(guild, botRole, currentPos, targetPos, failureReason) {
  if (!guild) return;
  const client = guild.client;
  const warnEmoji = resolveEmoji(guild, 'warning') || '<a:tungsten_warn:1567246685082746940>';
  const shieldEmoji = resolveEmoji(guild, 'shield') || '<a:tungsten_shield:1567242104923627574>';
  const alarmEmoji = resolveEmoji(guild, 'alarm') || '<a:tungsten_alarm:1567229471474585682>';

  // 1. Dispatch security alert to configured log channel
  try {
    await dispatchSecurityAlert(guild, {
      title: `${alarmEmoji} Role Hierarchy Modified — Action Required`,
      description: `> ${warnEmoji} **Tungsten role hierarchy was modified in ${guild.name}**\n\n` +
        `• **Role:** <@&${botRole.id}> (\`${botRole.name}\`)\n` +
        `• **Current Position:** \`${currentPos}\` (Required: \`${targetPos}\`)\n` +
        `• **Auto-Correction Status:** ${alarmEmoji} Failed (${failureReason}).\n` +
        `• **Impact:** Antinuke sentinels and moderation actions may fail due to role hierarchy.\n` +
        `• **Resolution:** Server owner must manually elevate Tungsten's role back to the top.`,
      color: config.COLORS.DANGER || 0xED4245
    });
  } catch (_) {}

  // 2. Direct message the server owner
  try {
    const ownerId = guild.ownerId;
    if (!ownerId) return;

    const owner = guild.members?.cache?.get(ownerId)?.user
      || (guild.fetchOwner ? (await guild.fetchOwner().catch(() => null))?.user : null)
      || (client?.users ? await client.users.fetch(ownerId).catch(() => null) : null);

    if (owner && typeof owner.send === 'function') {
      const dmEmbed = new EmbedBuilder()
        .setColor(config.COLORS.DANGER || 0xED4245)
        .setTitle(`${alarmEmoji} Urgent Security Alert: Tungsten Role Demoted`)
        .setDescription(
          `> ${shieldEmoji} **Tungsten role hierarchy was modified in ${guild.name}**\n\n` +
          `Tungsten's role (\`${botRole.name}\`) was demoted from required position \`${targetPos}\` down to \`${currentPos}\`.\n\n` +
          `**Auto-Correction Failed:** ${failureReason}.\n\n` +
          `**Why This Matters:**\n` +
          `When Tungsten's role is below other roles, Discord's permission hierarchy prevents Tungsten from banning, kicking, or managing members with roles above it. Attackers often demote security bot roles prior to executing a raid.\n\n` +
          `**Immediate Remediation Required:**\n` +
          `1. Open **Server Settings** -> **Roles** in **${guild.name}**.\n` +
          `2. Drag Tungsten's role (\`${botRole.name}\`) to the top of the list (right below Discord system roles).\n` +
          `3. Verify that Tungsten has the **Manage Roles** and **Administrator** permissions.`
        )
        .setFooter({ text: 'Tungsten Role Auto-Anchor Sentinel • Enterprise Security' })
        .setTimestamp();

      await owner.send({ embeds: [dmEmbed] }).catch(() => null);
    }
  } catch (_) {}
}

/**
 * Checks a guild's role hierarchy and ensures Tungsten's highest role is anchored
 * at the top possible position in the guild.
 * @param {object} guild - Discord Guild
 * @returns {Promise<{success: boolean, anchored?: boolean, corrected?: boolean, reason?: string, previousPosition?: number, restoredPosition?: number}>}
 */
async function checkGuildRoleAnchor(guild) {
  if (!guild || !guild.id) {
    return { success: false, reason: 'Invalid guild' };
  }

  // 1. Resolve bot member ('me') defensively
  let me = guild.members?.me;
  if (!me && guild.members?.fetchMe) {
    me = await guild.members.fetchMe().catch(() => null);
  }
  if (!me && guild.client?.user?.id && guild.members?.fetch) {
    me = await guild.members.fetch(guild.client.user.id).catch(() => null);
  }
  if (!me) {
    return { success: false, reason: 'Could not resolve bot member' };
  }

  // 2. Identify Tungsten's highest role
  const botHighestRole = me.roles?.highest;
  if (!botHighestRole || botHighestRole.id === guild.id) {
    return { success: false, reason: 'Tungsten has no distinct role assigned' };
  }

  // 3. Collect non-everyone roles
  const roles = guild.roles?.cache ? [...guild.roles.cache.values()].filter(r => r.id !== guild.id) : [];
  if (roles.length === 0) {
    return { success: true, anchored: true, reason: 'No roles other than @everyone' };
  }

  const isSystemRole = (r) => Boolean(r.managed || r.tags?.premiumSubscriberRole !== undefined);

  // 4. Check if there are non-system roles above Tungsten's highest role
  const nonSystemAbove = roles.filter(r => !isSystemRole(r) && r.position > botHighestRole.position);
  const targetPosition = calculateHighestPossiblePosition(guild, botHighestRole);

  if (nonSystemAbove.length === 0 && botHighestRole.position >= targetPosition) {
    return { success: true, anchored: true, currentPosition: botHighestRole.position };
  }

  // Role was demoted below manageable roles!
  const previousPosition = botHighestRole.position;

  // 5. Verify ManageRoles or Administrator permission
  const hasManageRoles = Boolean(
    me.permissions?.has?.(PermissionsBitField.Flags.ManageRoles) ||
    me.permissions?.has?.(PermissionsBitField.Flags.Administrator)
  );

  const warnEmoji = resolveEmoji(guild, 'warning') || '<a:tungsten_warn:1567246685082746940>';
  const shieldEmoji = resolveEmoji(guild, 'shield') || '<a:tungsten_shield:1567242104923627574>';

  if (!hasManageRoles) {
    await notifyServerOwnerHierarchyFailure(guild, botHighestRole, previousPosition, targetPosition, 'Missing ManageRoles permission');
    return { success: false, reason: 'Missing ManageRoles permission', previousPosition, targetPosition };
  }

  // 6. Attempt to reposition role back to highest slot
  let moved = false;
  try {
    if (typeof botHighestRole.setPosition === 'function') {
      await botHighestRole.setPosition(targetPosition, { reason: '[Tungsten Role Anchor] Auto-correcting demoted role position' });
      moved = true;
    } else if (guild.roles?.setPositions) {
      await guild.roles.setPositions([{ role: botHighestRole.id, position: targetPosition }], { reason: '[Tungsten Role Anchor] Auto-correcting demoted role position' });
      moved = true;
    }
  } catch (err) {
    console.warn(`[RoleAnchor Error] Failed repositioning role in ${guild.id}:`, err.message);
    moved = false;
  }

  if (moved) {
    // Fire security alert: "Tungsten role hierarchy was modified — auto-correction applied"
    await dispatchSecurityAlert(guild, {
      title: `${warnEmoji} Tungsten Role Hierarchy Auto-Corrected`,
      description: `> ${shieldEmoji} **Tungsten role hierarchy was modified — auto-correction applied**\n\n` +
        `• **Role:** <@&${botHighestRole.id}> (\`${botHighestRole.name}\`)\n` +
        `• **Demoted Position:** \`${previousPosition}\`\n` +
        `• **Restored Position:** \`${targetPosition}\`\n` +
        `• **Hierarchy Status:** Successfully elevated to highest available position below Discord system roles.`,
      color: config.COLORS.WARNING || 0xFEE75C
    });

    // Re-verify dual backup roles anchoring
    try {
      await ensureDualBackupRoles(guild, { force: false }).catch(() => null);
    } catch (_) {}

    return {
      success: true,
      corrected: true,
      roleId: botHighestRole.id,
      previousPosition,
      restoredPosition: targetPosition
    };
  } else {
    // Repositioning failed (e.g. Discord API hierarchy constraint) -> notify server owner
    await notifyServerOwnerHierarchyFailure(guild, botHighestRole, previousPosition, targetPosition, 'Discord API hierarchy constraint or insufficient role elevation');
    return { success: false, reason: 'Repositioning failed', previousPosition, targetPosition };
  }
}

/**
 * Starts the continuous 10-minute role anchor background task.
 * @param {object} client - TungstenClient instance
 * @returns {NodeJS.Timeout} Active timer handle
 */
function startRoleAnchorTask(client) {
  if (!client) return null;
  if (_roleAnchorInterval) {
    clearInterval(_roleAnchorInterval);
    _roleAnchorInterval = null;
  }

  const runAll = async () => {
    if (!client.guilds?.cache) return;
    for (const guild of client.guilds.cache.values()) {
      try {
        await checkGuildRoleAnchor(guild);
      } catch (err) {
        console.warn(`[RoleAnchor] Unhandled error checking guild ${guild.id}:`, err.message);
      }
    }
  };

  // 10-second initial boot warmup
  setTimeout(() => {
    runAll().catch(() => null);
  }, 10000).unref();

  // 10-minute recurring sentinel interval
  _roleAnchorInterval = setInterval(() => {
    runAll().catch(() => null);
  }, 10 * 60 * 1000);
  _roleAnchorInterval.unref();

  return _roleAnchorInterval;
}

/**
 * Captures a clean baseline server snapshot before any attack occurs.
 * Persists the snapshot ID in server_settings as 'clean_baseline_snapshot_id'.
 * @param {object} guild - Discord Guild
 * @returns {Promise<object|null>} Snapshot result or null
 */
async function captureCleanSnapshot(guild) {
  if (!guild || !guild.id) return null;
  try {
    const result = await createServerSnapshot(guild, 'system', 'Pre-Attack Clean Baseline');
    if (result && result.id) {
      const sdb = getServerDb(guild.id);
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('clean_baseline_snapshot_id', ?)")
        .run(String(result.id));
    }
    return result;
  } catch (err) {
    console.warn(`[RoleAnchor] Failed capturing clean baseline snapshot for ${guild.id}:`, err.message);
    return null;
  }
}

module.exports = {
  startRoleAnchorTask,
  checkGuildRoleAnchor,
  calculateHighestPossiblePosition,
  captureCleanSnapshot,
  notifyServerOwnerHierarchyFailure
};
