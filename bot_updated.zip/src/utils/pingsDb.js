/**
 * Tungsten Pings & Mention Notification Database Utility
 * Handles mention alerts preferences, blocked senders/guilds, and AFK records.
 */
const fs = require('node:fs');
const { getServerDb, getMasterDbPath } = require('./serverDb');
const { openDatabase } = require('./sqliteDb');
const { isOwner } = require('./tools');

// In-memory debounce cache to prevent mention spam: Map<"targetId:guildId", timestampMs>
const debounceCache = new Map();
const DEBOUNCE_WINDOW_MS = 5 * 60 * 1000; // 5 minutes per user per server

function recordMentionDebounce(targetId, guildId) {
  const debounceKey = `${String(targetId)}:${String(guildId)}`;
  debounceCache.set(debounceKey, Date.now());
}

function isMentionDebounced(targetId, guildId) {
  const debounceKey = `${String(targetId)}:${String(guildId)}`;
  const now = Date.now();
  const lastPing = debounceCache.get(debounceKey) || 0;
  return (now - lastPing < DEBOUNCE_WINDOW_MS);
}

// High-speed RAM caches
const _USER_PREFS_CACHE = new Map(); // userId -> { enabled, ts }
const _AFK_CACHE = new Map(); // `${userId}:${guildId}` -> afkData
const PREFS_TTL = 60000;

function ensurePingsTables(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_settings (
      user_id TEXT PRIMARY KEY,
      enabled INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS blocked_senders (
      user_id TEXT NOT NULL,
      sender_id TEXT NOT NULL,
      PRIMARY KEY (user_id, sender_id)
    );

    CREATE TABLE IF NOT EXISTS blocked_guilds (
      user_id TEXT NOT NULL,
      guild_id TEXT NOT NULL,
      PRIMARY KEY (user_id, guild_id)
    );

    CREATE TABLE IF NOT EXISTS user_afk (
      user_id TEXT NOT NULL,
      guild_id TEXT NOT NULL,
      reason TEXT DEFAULT 'AFK',
      afk_time INTEGER NOT NULL,
      mentions_count INTEGER DEFAULT 0,
      dm_remind INTEGER DEFAULT 1,
      PRIMARY KEY (user_id, guild_id)
    );
  `);
}

function getPingsDb(guildId = null) {
  if (guildId) {
    const sdb = getServerDb(guildId);
    return sdb;
  }
  const masterPath = getMasterDbPath();
  const mdb = openDatabase(masterPath);
  ensurePingsTables(mdb);
  return mdb;
}

/**
 * Check if mention alert DM should be delivered to target
 */
function isMentionAllowed(targetId, senderId, guildId) {
  const tid = String(targetId);
  const sid = String(senderId);
  const gid = String(guildId);

  // Bot Owner immunity: never send unsolicited mention DM alerts unless explicitly opted in
  if (isOwner(tid)) {
    const cachedPref = _USER_PREFS_CACHE.get(tid);
    if (cachedPref && (Date.now() - cachedPref.ts < PREFS_TTL)) {
      if (!cachedPref.enabled) return false;
    }
    try {
      const sdb = getServerDb(gid);
      const setting = sdb.prepare('SELECT enabled FROM user_settings WHERE user_id = ?').get(tid);
      if (!setting || setting.enabled !== 1) {
        _USER_PREFS_CACHE.set(tid, { enabled: false, ts: Date.now() });
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  // 1. Debounce check
  const debounceKey = `${tid}:${gid}`;
  const now = Date.now();
  const lastPing = debounceCache.get(debounceKey) || 0;
  if (now - lastPing < DEBOUNCE_WINDOW_MS) {
    return false;
  }

  // Fast RAM preference check
  const cachedPref = _USER_PREFS_CACHE.get(tid);
  if (cachedPref && (now - cachedPref.ts < PREFS_TTL)) {
    if (!cachedPref.enabled) return false;
  }

  // 2. Settings check (per-server DB or master DB)
  try {
    const sdb = getServerDb(gid);

    const setting = sdb.prepare('SELECT enabled FROM user_settings WHERE user_id = ?').get(tid);
    if (setting && setting.enabled === 0) {
      _USER_PREFS_CACHE.set(tid, { enabled: false, ts: now });
      return false; // Explicitly disabled
    }
    _USER_PREFS_CACHE.set(tid, { enabled: true, ts: now });

    const blockedSender = sdb.prepare('SELECT 1 FROM blocked_senders WHERE user_id = ? AND sender_id = ?').get(tid, sid);
    if (blockedSender) {
      return false;
    }

    const blockedGuild = sdb.prepare('SELECT 1 FROM blocked_guilds WHERE user_id = ? AND guild_id = ?').get(tid, gid);
    if (blockedGuild) {
      return false;
    }

    // Record debounce on allowed
    debounceCache.set(debounceKey, now);
    return true;
  } catch (e) {
    return true; // Default allow if lookup fails
  }
}

/**
 * Enable or disable mention alert DMs for a user
 */
function setMentionAlertsEnabled(userId, enabled, guildId = null) {
  const uid = String(userId);
  const val = enabled ? 1 : 0;
  _USER_PREFS_CACHE.set(uid, { enabled: !!enabled, ts: Date.now() });

  if (guildId) {
    const sdb = getServerDb(guildId);
    ensurePingsTables(sdb);
    sdb.prepare('INSERT OR REPLACE INTO user_settings (user_id, enabled) VALUES (?, ?)').run(uid, val);
  }

  // Dual-write to master
  try {
    const masterPath = getMasterDbPath();
    if (fs.existsSync(masterPath)) {
      const mdb = openDatabase(masterPath);
      try {
        ensurePingsTables(mdb);
        mdb.prepare('INSERT OR REPLACE INTO user_settings (user_id, enabled) VALUES (?, ?)').run(uid, val);
      } finally {
        mdb.close();
      }
    }
  } catch (e) {}

  return true;
}

/**
 * Check if a user has mention alerts enabled
 */
function isMentionAlertsEnabled(userId, guildId = null) {
  const uid = String(userId);
  const cachedPref = _USER_PREFS_CACHE.get(uid);
  if (cachedPref && (Date.now() - cachedPref.ts < PREFS_TTL)) {
    return cachedPref.enabled;
  }

  if (guildId) {
    try {
      const sdb = getServerDb(guildId);
      const row = sdb.prepare('SELECT enabled FROM user_settings WHERE user_id = ?').get(uid);
      if (row !== undefined && row.enabled !== undefined) {
        const enabled = row.enabled === 1;
        _USER_PREFS_CACHE.set(uid, { enabled, ts: Date.now() });
        return enabled;
      }
    } catch (e) {}
  }
  return true; // Default enabled
}

/**
 * AFK Subsystem: Get AFK status
 */
function getAfkStatus(userId, guildId) {
  const uid = String(userId);
  const gid = String(guildId);
  const key = `${uid}:${gid}`;
  if (_AFK_CACHE.has(key)) {
    return _AFK_CACHE.get(key);
  }

  try {
    const sdb = getServerDb(gid);
    const row = sdb.prepare('SELECT * FROM user_afk WHERE user_id = ? AND guild_id = ?').get(uid, gid) || null;
    _AFK_CACHE.set(key, row);
    return row;
  } catch (e) {
    return null;
  }
}

/**
 * AFK Subsystem: Set AFK status
 */
function setAfkStatus(userId, guildId, reason = 'AFK', dmRemind = 1) {
  const uid = String(userId);
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const now = Date.now();

  const record = {
    user_id: uid,
    guild_id: gid,
    reason,
    afk_time: now,
    mentions_count: 0,
    dm_remind: dmRemind ? 1 : 0
  };

  _AFK_CACHE.set(`${uid}:${gid}`, record);

  sdb.prepare(`
    INSERT OR REPLACE INTO user_afk (user_id, guild_id, reason, afk_time, mentions_count, dm_remind)
    VALUES (?, ?, ?, ?, 0, ?)
  `).run(uid, gid, reason, now, dmRemind ? 1 : 0);

  return true;
}

/**
 * AFK Subsystem: Clear AFK status
 */
function clearAfkStatus(userId, guildId) {
  const uid = String(userId);
  const gid = String(guildId);
  const key = `${uid}:${gid}`;
  _AFK_CACHE.delete(key);

  try {
    const sdb = getServerDb(gid);
    const existing = sdb.prepare('SELECT mentions_count, afk_time FROM user_afk WHERE user_id = ? AND guild_id = ?').get(uid, gid);
    if (existing) {
      sdb.prepare('DELETE FROM user_afk WHERE user_id = ? AND guild_id = ?').run(uid, gid);
      return existing;
    }
  } catch (e) {}
  return null;
}

/**
 * AFK Subsystem: Increment mentions count for AFK user
 */
function incrementAfkMentions(userId, guildId) {
  const uid = String(userId);
  const gid = String(guildId);
  const key = `${uid}:${gid}`;

  try {
    const sdb = getServerDb(gid);
    sdb.prepare('UPDATE user_afk SET mentions_count = mentions_count + 1 WHERE user_id = ? AND guild_id = ?').run(uid, gid);
    const row = sdb.prepare('SELECT mentions_count FROM user_afk WHERE user_id = ? AND guild_id = ?').get(uid, gid);
    const count = row ? row.mentions_count : 1;
    if (_AFK_CACHE.has(key)) {
      const cached = _AFK_CACHE.get(key);
      if (cached) cached.mentions_count = count;
    }
    return count;
  } catch (e) {
    return 1;
  }
}

module.exports = {
  isMentionAllowed,
  recordMentionDebounce,
  isMentionDebounced,
  DEBOUNCE_WINDOW_MS,
  setMentionAlertsEnabled,
  isMentionAlertsEnabled,
  getAfkStatus,
  setAfkStatus,
  clearAfkStatus,
  incrementAfkMentions
};
