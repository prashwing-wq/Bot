/**
 * Panic / Emergency Lockdown Interaction Router (Node.js)
 * Implements high-speed server quarantine, voice channel lockdown, invite revocation,
 * pre-attack clean baseline snapshots, and auto-unlock timer scheduling.
 */
const { MessageFlags, PermissionFlagsBits, ChannelType } = require('discord.js');
const { createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { resolveEmoji } = require('../utils/emojis');
const { getLockdownStatus, setLockdownStatus, createPanicButtons } = require('../commands/security/panic');
const { animateSequence, getPanicLockdownFrames, getPanicUnlockFrames } = require('../utils/animation');

/**
 * Captures a pre-attack clean baseline server snapshot (separate from lockdown snapshot).
 * Can be called at bot startup or on-demand.
 * @param {import('discord.js').Guild} guild
 * @returns {Promise<object|null>}
 */
async function captureCleanSnapshot(guild) {
  if (!guild) return null;
  try {
    const { createServerSnapshot } = require('../utils/antinukeEngine');
    const result = await createServerSnapshot(guild, 'system', 'Pre-Attack Clean Baseline');
    if (result && result.id) {
      const sdb = getServerDb(guild.id);
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('clean_baseline_snapshot_id', ?)")
        .run(String(result.id));
    }
    return result;
  } catch (err) {
    console.error(`[Panic] Error capturing clean snapshot for ${guild.id}:`, err.message);
    return null;
  }
}

/**
 * Executes full lockdown unlock procedure across text and voice channels.
 * Can be called manually or by the automated auto-unlock timer.
 * @param {import('discord.js').Guild} guild
 * @param {import('discord.js').Client} client
 * @param {string} reason
 * @returns {Promise<{ success: boolean, unlockedCount: number, unlockedVoiceCount: number }>}
 */
async function executePanicUnlock(guild, client, reason = 'Lockdown lifted') {
  if (!guild) return { success: false, unlockedCount: 0, unlockedVoiceCount: 0 };
  const sdb = getServerDb(guild.id);
  setLockdownStatus(guild.id, false);
  try {
    sdb.prepare("DELETE FROM server_settings WHERE key = 'panic_auto_unlock_at'").run();
  } catch (_) {}

  const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'panic_snapshot'").get();
  let snapshotData = {};
  try { snapshotData = row ? JSON.parse(row.value) : {}; } catch (_) {}
  const snapshot = snapshotData.channels || snapshotData;

  let unlockedCount = 0;
  let unlockedVoiceCount = 0;
  const channelList = Array.from(guild.channels?.cache?.values?.() || []);

  for (const channel of channelList) {
    if (channel.isThread?.()) continue;

    // Text channels
    if (channel.isTextBased?.() && channel.permissionsFor?.(guild.members?.me || guild.members?.cache?.get?.(client?.user?.id))?.has?.(PermissionFlagsBits.ManageChannels)) {
      try {
        const state = snapshot[channel.id];
        if (state === null) {
          await channel.permissionOverwrites?.delete?.(guild.id).catch(() => null);
        } else if (state && state.deny !== undefined) {
          const wasDenied = (BigInt(state.deny) & PermissionFlagsBits.SendMessages) !== 0n;
          const wasAllowed = (BigInt(state.allow) & PermissionFlagsBits.SendMessages) !== 0n;
          await channel.permissionOverwrites?.edit?.(guild.roles.everyone, {
            SendMessages: wasDenied ? false : (wasAllowed ? true : null)
          }).catch(() => null);
        } else {
          await channel.permissionOverwrites?.edit?.(guild.roles.everyone, {
            SendMessages: null
          }).catch(() => null);
        }
        unlockedCount++;
      } catch (e) {}
    }

    // Voice & Stage channels
    const isVoice = channel.type === 2 || channel.type === 13 || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildStageVoice;
    if (isVoice && channel.permissionsFor?.(guild.members?.me || guild.members?.cache?.get?.(client?.user?.id))?.has?.(PermissionFlagsBits.ManageChannels)) {
      try {
        const state = snapshot[channel.id];
        if (state?.voiceLocked || (state && state.deny !== undefined)) {
          if (state && state.deny !== undefined) {
            const wasDeniedConnect = (BigInt(state.deny) & PermissionFlagsBits.Connect) !== 0n;
            const wasAllowedConnect = (BigInt(state.allow) & PermissionFlagsBits.Connect) !== 0n;
            const wasDeniedSpeak = (BigInt(state.deny) & PermissionFlagsBits.Speak) !== 0n;
            const wasAllowedSpeak = (BigInt(state.allow) & PermissionFlagsBits.Speak) !== 0n;
            await channel.permissionOverwrites?.edit?.(guild.roles.everyone, {
              Connect: wasDeniedConnect ? false : (wasAllowedConnect ? true : null),
              Speak: wasDeniedSpeak ? false : (wasAllowedSpeak ? true : null)
            }).catch(() => null);
          } else {
            await channel.permissionOverwrites?.edit?.(guild.roles.everyone, {
              Connect: null,
              Speak: null
            }).catch(() => null);
          }
          unlockedVoiceCount++;
        }
      } catch (e) {}
    }
  }

  try {
    const { dispatchSecurityAlert } = require('../utils/antinukeEngine');
    dispatchSecurityAlert(guild, {
      title: `${resolveEmoji(client || guild, 'shield')} Emergency Lockdown Disengaged`,
      description: `Emergency Lockdown quarantine has been lifted (${reason}). Restored \`${unlockedCount}\` text channels and \`${unlockedVoiceCount}\` voice channels.`,
      color: client?.config?.COLORS?.SUCCESS || 0x2ECC71
    });
  } catch (_) {}

  return { success: true, unlockedCount, unlockedVoiceCount };
}

module.exports = {
  prefixes: ['panic'],
  captureCleanSnapshot,
  executePanicUnlock,
  getLockdownStatus,
  setLockdownStatus,

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    let isAuthorizedPanic = interaction.user.id === interaction.guild.ownerId;
    if (!isAuthorizedPanic) {
      try {
        const sdb = getServerDb(interaction.guild.id);
        const eo = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(interaction.guild.id, interaction.user.id);
        if (eo) isAuthorizedPanic = true;
      } catch (e) {}
    }

    if (!isAuthorizedPanic) {
      return interaction.reply({
        content: `${resolveEmoji(interaction.client || interaction.guild, 'cross')} Only the **Server Owner** or **Extra Owners** can use Emergency Panic controls.`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId === 'panic:lock') {
      const sdb = getServerDb(interaction.guild.id);
      const isCurrentlyLocked = getLockdownStatus(interaction.guild.id);

      if (isCurrentlyLocked) {
        return interaction.reply({
          content: `${resolveEmoji(interaction.client || interaction.guild, 'warning')} Emergency Lockdown is already active! Re-snapshotting is blocked to prevent permanent lockdown.`,
          flags: MessageFlags.Ephemeral
        });
      }

      await interaction.deferUpdate();

      const snapshot = {
        timestamp: Date.now(),
        channels: {}
      };
      const channelList = Array.from(interaction.guild.channels.cache?.values?.() || []);
      for (const channel of channelList) {
        if (channel.isThread?.()) continue;
        const overwrite = channel.permissionOverwrites?.cache?.get?.(interaction.guild.id);
        const isVoice = channel.type === 2 || channel.type === 13 || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildStageVoice;
        if (channel.isTextBased?.() || isVoice) {
          snapshot.channels[channel.id] = overwrite
            ? { allow: overwrite.allow.bitfield.toString(), deny: overwrite.deny.bitfield.toString() }
            : null;
        }
      }

      const frames = getPanicLockdownFrames();
      const animPromise = animateSequence(interaction.message, frames.slice(0, 4), { intervalMs: 500 });

      // 1. Lock text channels
      let lockedCount = 0;
      for (const channel of channelList) {
        if (channel.isTextBased?.() && !channel.isThread?.() && channel.permissionsFor?.(interaction.guild.members.me)?.has?.(PermissionFlagsBits.ManageChannels)) {
          try {
            await channel.permissionOverwrites?.edit?.(interaction.guild.roles.everyone, {
              SendMessages: false
            });
            lockedCount++;
          } catch (e) {}
        }
      }

      // 2. Lock voice channels (Fix 1: GuildVoice & GuildStageVoice -> Connect/Speak: false)
      let voiceLockedCount = 0;
      for (const channel of channelList) {
        const isVoice = channel.type === 2 || channel.type === 13 || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildStageVoice;
        if (isVoice) {
          if (channel.permissionsFor?.(interaction.guild.members.me)?.has?.(PermissionFlagsBits.ManageChannels)) {
            try {
              await channel.permissionOverwrites?.edit?.(interaction.guild.roles.everyone, {
                Connect: false,
                Speak: false
              });
              snapshot.channels[channel.id] = Object.assign(snapshot.channels[channel.id] || {}, { voiceLocked: true });
              voiceLockedCount++;
            } catch (e) {}
          }
        }
      }

      // 3. Revoke all active invites (Fix 2: guild.fetchInvites / invites.fetch -> invite.delete)
      let revokedInvites = 0;
      try {
        if (typeof interaction.guild.invites?.fetch === 'function') {
          const invites = await interaction.guild.invites.fetch().catch(() => null);
          if (invites) {
            for (const invite of invites.values()) {
              await invite.delete('[Tungsten Panic] Revoking all invites during emergency lockdown.').catch(() => null);
              revokedInvites++;
            }
          }
        } else if (typeof interaction.guild.fetchInvites === 'function') {
          const invites = await interaction.guild.fetchInvites().catch(() => null);
          if (invites) {
            for (const invite of invites.values()) {
              await invite.delete('[Tungsten Panic] Revoking all invites during emergency lockdown.').catch(() => null);
              revokedInvites++;
            }
          }
        }
      } catch (e) {}
      snapshot.invitesRevoked = revokedInvites;

      try {
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('panic_snapshot', ?)").run(JSON.stringify(snapshot));
      } catch (e) {}
      setLockdownStatus(interaction.guild.id, true);

      // 4. Auto-unlock timer (Fix 4: panic_auto_unlock_hours & panic_auto_unlock_at)
      const autoUnlockRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'panic_auto_unlock_hours'").get();
      const autoUnlockHours = (autoUnlockRow && !isNaN(autoUnlockRow.value)) ? Number(autoUnlockRow.value) : 6; // default 6 hours
      if (autoUnlockHours > 0) {
        const unlockAt = Date.now() + (autoUnlockHours * 3600000);
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('panic_auto_unlock_at', ?)").run(String(unlockAt));

        try {
          const { scheduleTask } = require('../utils/scheduler');
          scheduleTask(interaction.guild.id, 'panic_auto_unlock', unlockAt, { reason: 'Auto-unlock: Time limit reached' });
        } catch (_) {}

        const timer = setTimeout(async () => {
          try {
            const isStillLocked = getLockdownStatus(interaction.guild.id);
            if (isStillLocked) {
              await executePanicUnlock(interaction.guild, client, 'Auto-unlock: Time limit reached');
            }
          } catch (_) {}
        }, Math.min(autoUnlockHours * 3600000, 2147483647));
        if (timer && typeof timer.unref === 'function') timer.unref();
      }

      await animPromise;

      const cleanBaselineRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_baseline_snapshot_id'").get();
      const hasBaseline = Boolean(cleanBaselineRow?.value);

      const finalEmbed = createEmbed({
        color: client.config.COLORS.DANGER,
        title: `${resolveEmoji(client, 'alarm')}  EMERGENCY LOCKDOWN ENGAGED`,
        description:
          `> **Server Quarantine is Active**\n` +
          `> All public communications have been frozen.\n\n` +
          `• **Secured Channels:** \`${lockedCount}\` text channels locked\n` +
          `• **Secured Voice Channels:** \`${voiceLockedCount}\` voice channels locked\n` +
          `• **Channel State:** \`SendMessages: FALSE\` & \`Connect/Speak: FALSE\` for \`@everyone\`\n` +
          (revokedInvites > 0 ? `• **Revoked Invites:** \`${revokedInvites}\` active invites deleted\n` : '') +
          `• **Auto-Unlock:** ${autoUnlockHours > 0 ? `\`${autoUnlockHours} hours\`` : '`Manual Only`'}\n` +
          `• **Exempt:** Server Owner and Authorized Administrators\n\n` +
          `-# Click Lift Lockdown below to restore normal communications.`,
        footer: { text: 'Tungsten Threat Containment Protocol • Locked' }
      });

      await interaction.message.edit({ embeds: [finalEmbed], components: [createPanicButtons(true, hasBaseline)] }).catch(() => null);
      return true;
    }

    if (customId === 'panic:unlock') {
      await interaction.deferUpdate();
      const sdb = getServerDb(interaction.guild.id);

      const frames = getPanicUnlockFrames();
      const animPromise = animateSequence(interaction.message, frames.slice(0, 2), { intervalMs: 500 });

      const unlockResult = await executePanicUnlock(interaction.guild, client, 'Manual unlock via control panel');

      await animPromise;

      const cleanBaselineRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_baseline_snapshot_id'").get();
      const hasBaseline = Boolean(cleanBaselineRow?.value);

      const finalEmbed = createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: `${resolveEmoji(client, 'shield')}  EMERGENCY LOCKDOWN DISENGAGED`,
        description:
          `> **Server Quarantine Lifted**\n` +
          `> Normal member communications active across all text & voice channels.\n\n` +
          `• **Restored Channels:** \`${unlockResult.unlockedCount}\` text channels reopened\n` +
          `• **Restored Voice Channels:** \`${unlockResult.unlockedVoiceCount}\` voice channels reopened\n` +
          (hasBaseline ? `• **Clean Baseline Available:** Snapshot \`#${cleanBaselineRow.value}\` ready. Click Restore Baseline below to fully rollback to pre-attack state.\n` : '') +
          `• **Status:** Normal operations active.`,
        footer: { text: 'Tungsten Threat Containment Protocol • Restored' }
      });

      await interaction.message.edit({ embeds: [finalEmbed], components: [createPanicButtons(false, hasBaseline)] }).catch(() => null);
      return true;
    }

    if (customId === 'panic:restore_baseline') {
      await interaction.deferUpdate();
      const sdb = getServerDb(interaction.guild.id);
      const cleanBaselineRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_baseline_snapshot_id'").get();
      if (!cleanBaselineRow || !cleanBaselineRow.value) {
        return interaction.followUp({
          content: `${resolveEmoji(client, 'cross')} No pre-attack clean baseline snapshot found for this server.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const { restoreServerSnapshot } = require('../utils/antinukeEngine');
      const restoreResult = await restoreServerSnapshot(interaction.guild, Number(cleanBaselineRow.value));
      setLockdownStatus(interaction.guild.id, false);

      const embed = createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: `${resolveEmoji(client, 'shield')}  CLEAN BASELINE RESTORED`,
        description:
          `> **Pre-Attack Baseline Restored**\n` +
          `> Server channels and roles have been rolled back to baseline snapshot \`#${cleanBaselineRow.value}\`.\n\n` +
          `• **Restored Channels:** \`${restoreResult.restoredChannels || 0}\` channels restored\n` +
          `• **Restored Roles:** \`${restoreResult.restoredRoles || 0}\` roles restored\n` +
          `• **Lockdown Status:** Disengaged\n\n` +
          `-# Server structure and permissions have been cleanly recovered.`,
        footer: { text: 'Tungsten Disaster Recovery Engine' }
      });

      return interaction.message.edit({ embeds: [embed], components: [createPanicButtons(false, true)] }).catch(() => null);
    }

    if (customId === 'panic:status') {
      await interaction.deferUpdate().catch(() => null);
      const isLocked = getLockdownStatus(interaction.guild.id);
      const sdb = getServerDb(interaction.guild.id);
      const cleanBaselineRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_baseline_snapshot_id'").get();
      const hasBaseline = Boolean(cleanBaselineRow?.value);

      const statusBadge = isLocked ? '<a:tungsten_circle_red:1567234546586353686> `LOCKDOWN ACTIVE (Quarantined)`' : '<a:tungsten_circle_green:1567234524512002088> `NORMAL (Unrestricted)`';
      const textChannels = Array.from(interaction.guild.channels.cache?.values?.() || []).filter(c => c.isTextBased?.()).length;
      const voiceChannels = Array.from(interaction.guild.channels.cache?.values?.() || []).filter(c => c.type === 2 || c.type === 13 || c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice).length;

      const embed = createEmbed({
        color: isLocked ? client.config.COLORS.DANGER : client.config.COLORS.PRIMARY,
        title: `<a:tungsten_alarm:1567229471474585682>  Tungsten Emergency Lockdown Hub • ${interaction.guild.name}`,
        description:
          `> **Instant Full-Server Quarantine Protocol**\n` +
          `> Freezes public channels and neutralizes ongoing raids in real-time.\n\n` +
          `• **Lockdown Status:** ${statusBadge}\n` +
          `• **Monitored Channels:** \`${textChannels}\` text channels • \`${voiceChannels}\` voice channels\n` +
          `• **Target Permissions:** Revokes \`SendMessages\` and \`Connect/Speak\` from \`@everyone\`\n` +
          `• **Bypass Authorization:** Server Owner & Whitelisted Administrators\n` +
          (hasBaseline ? `• **Clean Baseline:** Baseline snapshot \`#${cleanBaselineRow.value}\` active\n` : '') +
          `\n-# Click an interactive control below to engage or lift server quarantine.`,
        footer: { text: 'Tungsten Zero-Bypass Incident Response' }
      });

      return interaction.editReply({ embeds: [embed], components: [createPanicButtons(isLocked, hasBaseline)] });
    }

    return false;
  }
};
