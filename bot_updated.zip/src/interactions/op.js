/**
 * Owner Control Panel Interaction Router (Node.js)
 * Strictly restricted to verified Bot Owners.
 */
const { MessageFlags } = require('discord.js');
const { isOwner } = require('../utils/tools');
const { getMasterDb } = require('../utils/serverDb');
const { buildOwnerPanelPayload } = require('../commands/security/ownerpanel');

module.exports = {
  prefixes: ['op'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!customId.startsWith('op:')) return false;

    if (!isOwner(interaction.user.id)) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> Access Denied: This control panel is strictly restricted to Bot Owners.',
        flags: MessageFlags.Ephemeral
      });
    }

    // 1. Dismiss panel
    if (customId.startsWith('op:dismiss:now')) {
      try {
        await interaction.deferUpdate();
        await interaction.message.delete();
      } catch (e) {
        try {
          await interaction.editReply({ components: [] });
        } catch (_) {}
      }
      return true;
    }

    // 2. Refresh panel metrics
    if (customId.startsWith('op:refresh:now')) {
      const payload = buildOwnerPanelPayload(client, interaction.user.id);
      return interaction.update(payload);
    }

    // 3. Trigger live database backup
    if (customId.startsWith('op:backup:now')) {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const backupDir = client.createBackup();
        return interaction.editReply({
          content: `<a:tungsten_success:1567242523468890274> **Hot Database Backup Complete!** Master database and active guild databases snapshotted to:\n\`${backupDir}\``
        });
      } catch (err) {
        return interaction.editReply({
          content: `<a:tungsten_close:1567234632905138206> Backup error: ${err.message}`
        });
      }
    }

    // 4. Run database integrity check
    if (customId.startsWith('op:db:integrity')) {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const mdb = getMasterDb();
        const rows = mdb.prepare('PRAGMA integrity_check').all();
        const isMasterOk = rows.length === 1 && rows[0].integrity_check === 'ok';

        return interaction.editReply({
          content: isMasterOk
            ? '<a:tungsten_success:1567242523468890274> **Database Integrity Verified!** `db/tungsten.db` PRAGMA integrity check returned `ok` with 0 corruption flags.'
            : `<a:tungsten_warn:1567246685082746940> **Integrity Check Diagnostic:** Result: ${JSON.stringify(rows)}`
        });
      } catch (err) {
        return interaction.editReply({
          content: `<a:tungsten_close:1567234632905138206> Integrity check error: ${err.message}`
        });
      }
    }

    return true;
  }
};
