/**
 * Tungsten Whitelist Interactive Router (Node.js)
 * Modular interaction handler for Whitelist Studio & Real-time Action Toggles.
 */
const {
  MessageFlags,
  EmbedBuilder,
  UserSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ChannelType
} = require('discord.js');
const { getConfig } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { clearImmunityCache } = require('../utils/antinukeEngine');
const { buildWhitelistStudioPayload } = require('../commands/security/whitelist');
const { buildExtraOwnerStudioPayload } = require('../commands/security/extraowner');
const {
  toggleWhitelistAction,
  revokeWhitelistTarget,
  buildTargetWhitelistPayload,
  setWhitelistDuration
} = require('../utils/whitelistUi');
const { isHighDangerScope, getScope } = require('../security/scopes');
const kit = require('../ui/kit');
const { EMOJIS } = require('../utils/emojis');

function isEphemeralInteraction(interaction) {
  if (!interaction) return false;
  if (interaction.message?.flags?.has?.(MessageFlags.Ephemeral)) return true;
  const rawFlags = interaction.message?.flags?.bitfield ?? interaction.message?.flags;
  if (typeof rawFlags === 'number' && (rawFlags & MessageFlags.Ephemeral)) return true;
  return false;
}

module.exports = {
  prefixes: ['wl'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    const sdb = getServerDb(interaction.guild.id);
    const isServerOwner = interaction.user.id === interaction.guild.ownerId;
    const isExtraOwner = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(interaction.guild.id, interaction.user.id));

    // Governance: Whitelisted members CANNOT grant or edit whitelist access
    if (!isServerOwner && !isExtraOwner) {
      return interaction.reply({
        content: `${EMOJIS.CROSS} **Access Denied**: Only the **Server Owner** or **Extra Owners** can configure whitelist settings. Whitelisted members cannot grant or edit whitelist access.`,
        flags: MessageFlags.Ephemeral
      });
    }

    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    // 1. Back to Studio & Refresh Studio
    if (customId === 'wl:studio' || customId === 'wl:refresh' || customId === 'wl:back_studio') {
      const payload = buildWhitelistStudioPayload(interaction.guild, sdb, prefix, interaction.user.username);
      try {
        await interaction.update(payload);
      } catch (e) {
        await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }
      return true;
    }

    // 2. Target Specific View / Cancel Return
    if (customId.startsWith('wl:target:')) {
      const parts = customId.split(':');
      const targetType = parts[2];
      const targetId = parts[3];
      const isEphemeral = isEphemeralInteraction(interaction);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, targetType, targetId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 3. Real-time Action Vector Toggle with Two-Step High-Danger Confirmation
    if (customId.startsWith('wl:act:')) {
      const parts = customId.split(':');
      const targetType = parts[2];
      const targetId = parts[3];
      const action = parts[4];
      const isEphemeral = isEphemeralInteraction(interaction);

      const table = targetType === 'user' ? 'whitelisted_users' : (targetType === 'role' ? 'whitelisted_roles' : 'whitelisted_channels');
      const idCol = targetType === 'user' ? 'user_id' : (targetType === 'role' ? 'role_id' : 'channel_id');
      const currentRows = sdb.prepare(`SELECT action FROM ${table} WHERE guild_id = ? AND ${idCol} = ?`).all(interaction.guild.id, targetId);
      const currentActions = currentRows.map(r => r.action || r.scope);
      const hasAll = currentActions.includes('all');
      const isAlreadyActive = hasAll || currentActions.includes(action);

      const isHighDanger = action === 'all' || isHighDangerScope(action);

      // High-danger scope grant requires two-step confirmation dialog
      if (isHighDanger && !isAlreadyActive) {
        const scopeDef = getScope(action) || { label: action, description: 'High-danger security bypass', dangerTier: 'high', vectors: [] };
        let targetMention = `\`${targetId}\``;
        if (targetType === 'user') targetMention = `<@${targetId}>`;
        else if (targetType === 'role') targetMention = `<@&${targetId}>`;
        else if (targetType === 'channel') targetMention = `<#${targetId}>`;

        if (isEphemeral) {
          const embed = new EmbedBuilder()
            .setTitle('Confirm High-Danger Scope Grant')
            .setDescription(`Granting **${scopeDef.label}** (\`${action}\`) gives elevated bypass privileges across critical server security sentinels.\n\n• **Target:** ${targetMention} (\`${targetId}\`)\n• **Danger Tier:** HIGH\n• **Vectors:** ${scopeDef.vectors?.join(', ') || 'all security vectors'}\n\nAre you sure you want to authorize this bypass?`)
            .setColor(0xe74c3c);
          const confirmRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(`wl:target:${targetType}:${targetId}`)
              .setLabel('Cancel')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId(`wl:confirm_act:${targetType}:${targetId}:${action}`)
              .setLabel('Grant High-Danger Scope')
              .setStyle(ButtonStyle.Danger)
          );
          await interaction.update({ embeds: [embed], components: [confirmRow] });
          return true;
        }

        const confirmDialog = kit.confirm({
          title: 'Confirm High-Danger Scope Grant',
          body: `Granting **${scopeDef.label}** (\`${action}\`) gives elevated bypass privileges across critical server security sentinels.\n\n• **Target:** ${targetMention} (\`${targetId}\`)\n• **Danger Tier:** HIGH\n• **Vectors:** ${scopeDef.vectors?.join(', ') || 'all security vectors'}\n\nAre you sure you want to authorize this bypass?`,
          confirmId: `wl:confirm_act:${targetType}:${targetId}:${action}`,
          cancelId: `wl:target:${targetType}:${targetId}`,
          confirmLabel: 'Grant High-Danger Scope',
          cancelLabel: 'Cancel',
          danger: true
        });
        await interaction.update(confirmDialog);
        return true;
      }

      toggleWhitelistAction(interaction.guild.id, sdb, targetType, targetId, action, interaction.user.id);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, targetType, targetId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 4. Confirmed High-Danger Action Execution
    if (customId.startsWith('wl:confirm_act:')) {
      const parts = customId.split(':');
      const targetType = parts[2];
      const targetId = parts[3];
      const action = parts[4];
      const isEphemeral = isEphemeralInteraction(interaction);

      toggleWhitelistAction(interaction.guild.id, sdb, targetType, targetId, action, interaction.user.id);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, targetType, targetId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 5. StringSelectMenu: Granular Scope Toggle
    if (customId.startsWith('wl:select_toggle_scope')) {
      const parts = customId.split(':');
      const targetType = parts[2] || 'user';
      const targetId = parts[3];
      const action = interaction.values[0];

      if (!targetId || !action) return true;

      const isEphemeral = isEphemeralInteraction(interaction);

      const table = targetType === 'user' ? 'whitelisted_users' : (targetType === 'role' ? 'whitelisted_roles' : 'whitelisted_channels');
      const idCol = targetType === 'user' ? 'user_id' : (targetType === 'role' ? 'role_id' : 'channel_id');
      const currentRows = sdb.prepare(`SELECT action FROM ${table} WHERE guild_id = ? AND ${idCol} = ?`).all(interaction.guild.id, targetId);
      const currentActions = currentRows.map(r => r.action || r.scope);
      const hasAll = currentActions.includes('all');
      const isAlreadyActive = hasAll || currentActions.includes(action);

      const isHighDanger = action === 'all' || isHighDangerScope(action);

      // High-danger scope grant requires two-step confirmation dialog
      if (isHighDanger && !isAlreadyActive) {
        const scopeDef = getScope(action) || { label: action, description: 'High-danger security bypass', dangerTier: 'high', vectors: [] };
        let targetMention = `\`${targetId}\``;
        if (targetType === 'user') targetMention = `<@${targetId}>`;
        else if (targetType === 'role') targetMention = `<@&${targetId}>`;
        else if (targetType === 'channel') targetMention = `<#${targetId}>`;

        if (isEphemeral) {
          const embed = new EmbedBuilder()
            .setTitle('Confirm High-Danger Scope Grant')
            .setDescription(`Granting **${scopeDef.label}** (\`${action}\`) gives elevated bypass privileges across critical server security sentinels.\n\n• **Target:** ${targetMention} (\`${targetId}\`)\n• **Danger Tier:** HIGH\n• **Vectors:** ${scopeDef.vectors?.join(', ') || 'all security vectors'}\n\nAre you sure you want to authorize this bypass?`)
            .setColor(0xe74c3c);
          const confirmRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(`wl:target:${targetType}:${targetId}`)
              .setLabel('Cancel')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId(`wl:confirm_act:${targetType}:${targetId}:${action}`)
              .setLabel('Grant High-Danger Scope')
              .setStyle(ButtonStyle.Danger)
          );
          await interaction.update({ embeds: [embed], components: [confirmRow] });
          return true;
        }

        const confirmDialog = kit.confirm({
          title: 'Confirm High-Danger Scope Grant',
          body: `Granting **${scopeDef.label}** (\`${action}\`) gives elevated bypass privileges across critical server security sentinels.\n\n• **Target:** ${targetMention} (\`${targetId}\`)\n• **Danger Tier:** HIGH\n• **Vectors:** ${scopeDef.vectors?.join(', ') || 'all security vectors'}\n\nAre you sure you want to authorize this bypass?`,
          confirmId: `wl:confirm_act:${targetType}:${targetId}:${action}`,
          cancelId: `wl:target:${targetType}:${targetId}`,
          confirmLabel: 'Grant High-Danger Scope',
          cancelLabel: 'Cancel',
          danger: true
        });
        await interaction.update(confirmDialog);
        return true;
      }

      toggleWhitelistAction(interaction.guild.id, sdb, targetType, targetId, action, interaction.user.id);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, targetType, targetId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 6. Duration Picker Trigger
    if (customId.startsWith('wl:dur:')) {
      const parts = customId.split(':');
      const targetType = parts[2];
      const targetId = parts[3];
      const selectedVal = interaction.values[0];
      const durSec = (selectedVal === 'perm' || selectedVal === '0') ? null : parseInt(selectedVal, 10);
      const isEphemeral = isEphemeralInteraction(interaction);

      setWhitelistDuration(interaction.guild.id, sdb, targetType, targetId, durSec, interaction.user.id);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, targetType, targetId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 6. View History / Audit Log Surface
    if (customId.startsWith('wl:hist:') || customId === 'wl:audit') {
      let logs = [];
      let backBtn = null;
      if (customId.startsWith('wl:hist:')) {
        const parts = customId.split(':');
        const targetType = parts[2];
        const targetId = parts[3];
        logs = sdb.prepare(`
          SELECT target_type, target_id, action_scope, operator_id, operation, timestamp
          FROM whitelist_audit_log
          WHERE guild_id = ? AND target_id = ?
          ORDER BY timestamp DESC LIMIT 10
        `).all(interaction.guild.id, targetId);

        backBtn = new ButtonBuilder()
          .setCustomId(`wl:target:${targetType}:${targetId}`)
          .setLabel('Back to Target')
          .setStyle(ButtonStyle.Secondary);
      } else {
        logs = sdb.prepare(`
          SELECT target_type, target_id, action_scope, operator_id, operation, timestamp
          FROM whitelist_audit_log
          WHERE guild_id = ?
          ORDER BY timestamp DESC LIMIT 15
        `).all(interaction.guild.id);

        backBtn = new ButtonBuilder()
          .setCustomId('wl:back_studio')
          .setLabel('Back to Whitelist Studio')
          .setStyle(ButtonStyle.Secondary);
      }

      const logLines = logs.length > 0
        ? logs.map(l => {
            let targetStr = `\`${l.target_id}\``;
            if (l.target_type === 'user') targetStr = `<@${l.target_id}>`;
            else if (l.target_type === 'role') targetStr = `<@&${l.target_id}>`;
            else if (l.target_type === 'channel') targetStr = `<#${l.target_id}>`;
            return `<t:${l.timestamp}:R> - **${l.operation.toUpperCase()}** ${l.target_type} ${targetStr} [${l.action_scope}] by <@${l.operator_id}>`;
          })
        : ['No recent whitelist audit events recorded.'];

      if (isEphemeralInteraction(interaction)) {
        const embed = new EmbedBuilder()
          .setTitle('Whitelist — Audit History')
          .setDescription(`**${logs.length} recent audit event${logs.length === 1 ? '' : 's'}**\n-# Historical log of trust modifications, temporary grants, and revocations.\n\n` + logLines.join('\n'))
          .setColor(0x2b2d31);
        const row = new ActionRowBuilder().addComponents(
          backBtn,
          new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Close').setStyle(ButtonStyle.Secondary)
        );
        await interaction.update({ embeds: [embed], components: [row] });
        return true;
      }

      const auditPayload = kit.panel({
        title: 'Whitelist - Audit History',
        status: `${logs.length} recent audit event${logs.length === 1 ? '' : 's'}`,
        description: '-# Historical log of trust modifications, temporary grants, and revocations.',
        facts: logLines,
        rows: [
          new ActionRowBuilder().addComponents(
            backBtn,
            new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Close').setStyle(ButtonStyle.Secondary)
          )
        ]
      });

      await interaction.update(auditPayload);
      return true;
    }

    // 7. Complete Target Revocation
    if (customId.startsWith('wl:revoke:')) {
      const parts = customId.split(':');
      const targetType = parts[2];
      const targetId = parts[3];

      revokeWhitelistTarget(interaction.guild.id, sdb, targetType, targetId, interaction.user.id);
      const payload = buildWhitelistStudioPayload(interaction.guild, sdb, prefix, interaction.user.username);
      await interaction.update(payload);
      return true;
    }

    // 8. Add User Trigger
    if (customId === 'wl:add_user') {
      const userCount = sdb.prepare('SELECT COUNT(DISTINCT user_id) as cnt FROM whitelisted_users WHERE guild_id = ?').get(interaction.guild.id)?.cnt || 0;
      if (userCount >= 20) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} **Whitelist Limit Reached**: Maximum limit of **20 whitelisted users** reached for this server. Remove an existing user first.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const userSelect = new UserSelectMenuBuilder()
        .setCustomId('wl:select_add_user')
        .setPlaceholder('Select a user to add to Master Whitelist...')
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(userSelect);
      await interaction.reply({
        content: `${EMOJIS.SHIELD} Select a member from the server to grant **Antinuke Whitelist Immunity**:`,
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 9. User Selected to Add -> Shows Action Toggle Panel Immediately
    if (customId === 'wl:select_add_user') {
      const targetId = interaction.values[0];
      const targetMember = interaction.guild.members?.cache?.get(targetId) || await interaction.guild.members?.fetch(targetId).catch(() => null);

      if (targetMember?.user?.bot) {
        await interaction.update({
          content: `${EMOJIS.CROSS} **Security Restriction**: Bot accounts cannot be added to the user whitelist.`,
          components: []
        });
        return true;
      }

      const alreadyWhitelisted = Boolean(sdb.prepare('SELECT 1 FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').get(interaction.guild.id, targetId));
      if (!alreadyWhitelisted) {
        const userCount = sdb.prepare('SELECT COUNT(DISTINCT user_id) as cnt FROM whitelisted_users WHERE guild_id = ?').get(interaction.guild.id)?.cnt || 0;
        if (userCount >= 20) {
          await interaction.update({
            content: `${EMOJIS.CROSS} **Whitelist Limit Reached**: Maximum limit of **20 whitelisted users** reached for this server.`,
            components: []
          });
          return true;
        }
      }

      const nowSec = Math.floor(Date.now() / 1000);
      sdb.prepare(`
        INSERT OR REPLACE INTO whitelisted_users (guild_id, user_id, action, expires_at, added_by)
        VALUES (?, ?, 'all', NULL, ?)
      `).run(interaction.guild.id, targetId, interaction.user.id);

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(interaction.guild.id, 'user', targetId, 'all', interaction.user.id, 'whitelist', nowSec);

      clearImmunityCache(interaction.guild.id);
      const isEphemeral = isEphemeralInteraction(interaction);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'user', targetId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 10. Remove User Trigger & Pagination
    if (customId === 'wl:remove_user' || customId.startsWith('wl:remove_user:page:')) {
      const page = customId.startsWith('wl:remove_user:page:') ? (parseInt(customId.split(':')[3], 10) || 1) : 1;
      const rows = sdb.prepare('SELECT DISTINCT user_id FROM whitelisted_users WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        const emptyPayload = { content: `${EMOJIS.INFO} No whitelisted users found to remove.`, flags: MessageFlags.Ephemeral };
        if (customId.startsWith('wl:remove_user:page:')) await interaction.update(emptyPayload);
        else await interaction.reply(emptyPayload);
        return true;
      }

      const PAGE_SIZE = 10;
      const totalPages = Math.ceil(rows.length / PAGE_SIZE) || 1;
      const currentPage = Math.max(1, Math.min(page, totalPages));
      const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

      const selectOptions = pageRows.map(r => {
        const member = interaction.guild.members?.cache?.get(r.user_id);
        const name = member ? member.displayName : `User ${r.user_id}`;
        return {
          label: name.slice(0, 100),
          description: `ID: ${r.user_id}`,
          value: r.user_id
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('wl:select_remove_user')
        .setPlaceholder(`Select user to remove (Page ${currentPage}/${totalPages})...`)
        .addOptions(selectOptions);
      const rowsComponents = [new ActionRowBuilder().addComponents(select)];

      const navRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`wl:remove_user:page:${currentPage - 1}`)
          .setLabel('Previous')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(EMOJIS.ARROW_LEFT)
          .setDisabled(currentPage <= 1),
        new ButtonBuilder()
          .setCustomId('wl_page_info_user')
          .setLabel(`Page ${currentPage}/${totalPages}`)
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(true),
        new ButtonBuilder()
          .setCustomId(`wl:remove_user:page:${currentPage + 1}`)
          .setLabel('Next')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(EMOJIS.ARROW_RIGHT)
          .setDisabled(currentPage >= totalPages)
      );
      rowsComponents.push(navRow);

      const responsePayload = {
        content: `${EMOJIS.SHIELD} Select a user to revoke from the **Antinuke Whitelist** (Page ${currentPage}/${totalPages}):`,
        components: rowsComponents,
        flags: MessageFlags.Ephemeral
      };

      if (customId.startsWith('wl:remove_user:page:')) {
        await interaction.update(responsePayload);
      } else {
        await interaction.reply(responsePayload);
      }
      return true;
    }

    // 11. User Selected to Remove
    if (customId === 'wl:select_remove_user') {
      const targetId = interaction.values[0];
      revokeWhitelistTarget(interaction.guild.id, sdb, 'user', targetId, interaction.user.id);
      await interaction.update({
        content: `${EMOJIS.SUCCESS} <@${targetId}> has been removed from the whitelist.\n*Click **Refresh Panel** on the main studio to view updated roster.*`,
        components: []
      });
      return true;
    }

    // 12. Manage User Trigger
    if (customId === 'wl:manage_user') {
      const rows = sdb.prepare('SELECT DISTINCT user_id FROM whitelisted_users WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        return interaction.reply({ content: `${EMOJIS.INFO} No whitelisted users found. Click **Add User** first.`, flags: MessageFlags.Ephemeral });
      }

      const selectOptions = rows.slice(0, 25).map(r => {
        const member = interaction.guild.members?.cache?.get(r.user_id);
        const name = member ? member.displayName : `User ${r.user_id}`;
        return {
          label: name.slice(0, 100),
          description: `ID: ${r.user_id}`,
          value: r.user_id
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('wl:select_manage_user')
        .setPlaceholder('Select a user to inspect permissions...')
        .addOptions(selectOptions);
      const row = new ActionRowBuilder().addComponents(select);

      await interaction.reply({
        content: 'Select a whitelisted user to view or manage bypass scopes:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 13. User Selected to Manage -> Shows Action Toggle Panel
    if (customId === 'wl:select_manage_user') {
      const targetId = interaction.values[0];
      const isEphemeral = isEphemeralInteraction(interaction);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'user', targetId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 14. Add Role Trigger
    if (customId === 'wl:add_role') {
      const roleCount = sdb.prepare('SELECT COUNT(DISTINCT role_id) as cnt FROM whitelisted_roles WHERE guild_id = ?').get(interaction.guild.id)?.cnt || 0;
      if (roleCount >= 10) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} **Whitelist Limit Reached**: Maximum limit of **10 whitelisted roles** reached for this server. Remove an existing role first.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const roleSelect = new RoleSelectMenuBuilder()
        .setCustomId('wl:select_add_role')
        .setPlaceholder('Select a role to add to Master Whitelist...')
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(roleSelect);
      await interaction.reply({
        content: `${EMOJIS.SHIELD} Select a server role to grant **Antinuke Role Whitelist Immunity**:`,
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 15. Role Selected to Add (with Governance & Safety Checks)
    if (customId === 'wl:select_add_role') {
      const roleId = interaction.values[0];
      const role = interaction.guild.roles?.cache?.get(roleId);

      // Governance Safety Checks: Refuse @everyone and Managed roles
      if (roleId === interaction.guild.id || role?.name === '@everyone') {
        await interaction.update({
          content: `${EMOJIS.CROSS} **Security Restriction**: The **@everyone** role cannot be whitelisted. Whitelisting @everyone would disarm security protections for the entire server.`,
          components: []
        });
        return true;
      }
      if (role?.managed) {
        await interaction.update({
          content: `${EMOJIS.CROSS} **Security Restriction**: Managed bot integration roles cannot be whitelisted.`,
          components: []
        });
        return true;
      }

      const alreadyWhitelisted = Boolean(sdb.prepare('SELECT 1 FROM whitelisted_roles WHERE guild_id = ? AND role_id = ?').get(interaction.guild.id, roleId));
      if (!alreadyWhitelisted) {
        const roleCount = sdb.prepare('SELECT COUNT(DISTINCT role_id) as cnt FROM whitelisted_roles WHERE guild_id = ?').get(interaction.guild.id)?.cnt || 0;
        if (roleCount >= 10) {
          await interaction.update({
            content: `${EMOJIS.CROSS} **Whitelist Limit Reached**: Maximum limit of **10 whitelisted roles** reached for this server.`,
            components: []
          });
          return true;
        }
      }

      const nowSec = Math.floor(Date.now() / 1000);
      sdb.prepare(`
        INSERT OR REPLACE INTO whitelisted_roles (guild_id, role_id, action, expires_at, added_by)
        VALUES (?, ?, 'all', NULL, ?)
      `).run(interaction.guild.id, roleId, interaction.user.id);

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(interaction.guild.id, 'role', roleId, 'all', interaction.user.id, 'whitelist', nowSec);

      clearImmunityCache(interaction.guild.id);
      const isEphemeral = isEphemeralInteraction(interaction);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'role', roleId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 16. Remove Role Trigger & Pagination
    if (customId === 'wl:remove_role' || customId.startsWith('wl:remove_role:page:')) {
      const page = customId.startsWith('wl:remove_role:page:') ? (parseInt(customId.split(':')[3], 10) || 1) : 1;
      const rows = sdb.prepare('SELECT DISTINCT role_id FROM whitelisted_roles WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        const emptyPayload = { content: `${EMOJIS.INFO} No whitelisted roles found to remove.`, flags: MessageFlags.Ephemeral };
        if (customId.startsWith('wl:remove_role:page:')) await interaction.update(emptyPayload);
        else await interaction.reply(emptyPayload);
        return true;
      }

      const PAGE_SIZE = 10;
      const totalPages = Math.ceil(rows.length / PAGE_SIZE) || 1;
      const currentPage = Math.max(1, Math.min(page, totalPages));
      const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

      const selectOptions = pageRows.map(r => {
        const role = interaction.guild.roles?.cache?.get(r.role_id);
        const name = role ? role.name : `Role ${r.role_id}`;
        return {
          label: name.slice(0, 100),
          description: `ID: ${r.role_id}`,
          value: r.role_id
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('wl:select_remove_role')
        .setPlaceholder(`Select role to remove (Page ${currentPage}/${totalPages})...`)
        .addOptions(selectOptions);
      const rowsComponents = [new ActionRowBuilder().addComponents(select)];

      const navRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`wl:remove_role:page:${currentPage - 1}`)
          .setLabel('Previous')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(EMOJIS.ARROW_LEFT)
          .setDisabled(currentPage <= 1),
        new ButtonBuilder()
          .setCustomId('wl_page_info_role')
          .setLabel(`Page ${currentPage}/${totalPages}`)
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(true),
        new ButtonBuilder()
          .setCustomId(`wl:remove_role:page:${currentPage + 1}`)
          .setLabel('Next')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(EMOJIS.ARROW_RIGHT)
          .setDisabled(currentPage >= totalPages)
      );
      rowsComponents.push(navRow);

      const responsePayload = {
        content: `${EMOJIS.SHIELD} Select a role to revoke from the **Antinuke Whitelist** (Page ${currentPage}/${totalPages}):`,
        components: rowsComponents,
        flags: MessageFlags.Ephemeral
      };

      if (customId.startsWith('wl:remove_role:page:')) {
        await interaction.update(responsePayload);
      } else {
        await interaction.reply(responsePayload);
      }
      return true;
    }

    // 17. Role Selected to Remove
    if (customId === 'wl:select_remove_role') {
      const roleId = interaction.values[0];
      revokeWhitelistTarget(interaction.guild.id, sdb, 'role', roleId, interaction.user.id);
      await interaction.update({
        content: `${EMOJIS.SUCCESS} Role <@&${roleId}> has been removed from the whitelist.\n*Click **Refresh Panel** on the main studio to view updated roster.*`,
        components: []
      });
      return true;
    }

    // 18. Manage Role Trigger
    if (customId === 'wl:manage_role') {
      const rows = sdb.prepare('SELECT DISTINCT role_id FROM whitelisted_roles WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        return interaction.reply({ content: `${EMOJIS.INFO} No whitelisted roles found. Click **Add Role** first.`, flags: MessageFlags.Ephemeral });
      }

      const selectOptions = rows.slice(0, 25).map(r => {
        const role = interaction.guild.roles?.cache?.get(r.role_id);
        const name = role ? role.name : `Role ${r.role_id}`;
        return {
          label: name.slice(0, 100),
          description: `ID: ${r.role_id}`,
          value: r.role_id
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('wl:select_manage_role')
        .setPlaceholder('Select a role to inspect permissions...')
        .addOptions(selectOptions);
      const row = new ActionRowBuilder().addComponents(select);

      await interaction.reply({
        content: `${EMOJIS.SHIELD} Select a whitelisted role to view or manage bypass scopes:`,
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 19. Role Selected to Manage
    if (customId === 'wl:select_manage_role') {
      const roleId = interaction.values[0];
      const isEphemeral = isEphemeralInteraction(interaction);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'role', roleId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 20. Add Channel Trigger
    if (customId === 'wl:add_channel') {
      const chanCount = sdb.prepare('SELECT COUNT(DISTINCT channel_id) as cnt FROM whitelisted_channels WHERE guild_id = ?').get(interaction.guild.id)?.cnt || 0;
      if (chanCount >= 30) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} **Whitelist Limit Reached**: Maximum limit of **30 whitelisted channels** reached for this server. Remove an existing channel first.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const chanSelect = new ChannelSelectMenuBuilder()
        .setCustomId('wl:select_add_channel')
        .setPlaceholder('Select a channel to add to Master Whitelist...')
        .setChannelTypes([ChannelType.GuildText, ChannelType.GuildVoice, ChannelType.GuildAnnouncement, ChannelType.GuildForum])
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(chanSelect);
      await interaction.reply({
        content: `${EMOJIS.SHIELD} Select a server channel to grant **Whitelist & Automod Immunity**:`,
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 21. Channel Selected to Add
    if (customId === 'wl:select_add_channel') {
      const chId = interaction.values[0];

      const alreadyWhitelisted = Boolean(sdb.prepare('SELECT 1 FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').get(interaction.guild.id, chId));
      if (!alreadyWhitelisted) {
        const chanCount = sdb.prepare('SELECT COUNT(DISTINCT channel_id) as cnt FROM whitelisted_channels WHERE guild_id = ?').get(interaction.guild.id)?.cnt || 0;
        if (chanCount >= 30) {
          await interaction.update({
            content: `${EMOJIS.CROSS} **Whitelist Limit Reached**: Maximum limit of **30 whitelisted channels** reached for this server.`,
            components: []
          });
          return true;
        }
      }

      const nowSec = Math.floor(Date.now() / 1000);
      sdb.prepare(`
        INSERT OR REPLACE INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at)
        VALUES (?, ?, 'all', ?, ?)
      `).run(interaction.guild.id, chId, interaction.user.id, nowSec);

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(interaction.guild.id, 'channel', chId, 'all', interaction.user.id, 'whitelist', nowSec);

      clearImmunityCache(interaction.guild.id);
      const isEphemeral = isEphemeralInteraction(interaction);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'channel', chId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 22. Remove Channel Trigger & Pagination
    if (customId === 'wl:remove_channel' || customId.startsWith('wl:remove_channel:page:')) {
      const page = customId.startsWith('wl:remove_channel:page:') ? (parseInt(customId.split(':')[3], 10) || 1) : 1;
      const rows = sdb.prepare('SELECT DISTINCT channel_id FROM whitelisted_channels WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        const emptyPayload = { content: `${EMOJIS.WARN} No whitelisted channels found to remove.`, flags: MessageFlags.Ephemeral };
        if (customId.startsWith('wl:remove_channel:page:')) await interaction.update(emptyPayload);
        else await interaction.reply(emptyPayload);
        return true;
      }

      const PAGE_SIZE = 10;
      const totalPages = Math.ceil(rows.length / PAGE_SIZE) || 1;
      const currentPage = Math.max(1, Math.min(page, totalPages));
      const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

      const selectOptions = pageRows.map(r => {
        const ch = interaction.guild.channels?.cache?.get(r.channel_id);
        const name = ch ? ch.name : `Channel ${r.channel_id}`;
        return {
          label: `#${name}`.slice(0, 100),
          description: `ID: ${r.channel_id}`,
          value: r.channel_id
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('wl:select_remove_channel')
        .setPlaceholder(`Select channel to remove (Page ${currentPage}/${totalPages})...`)
        .addOptions(selectOptions);
      const rowsComponents = [new ActionRowBuilder().addComponents(select)];

      const navRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`wl:remove_channel:page:${currentPage - 1}`)
          .setLabel('Previous')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(EMOJIS.ARROW_LEFT)
          .setDisabled(currentPage <= 1),
        new ButtonBuilder()
          .setCustomId('wl_page_info_channel')
          .setLabel(`Page ${currentPage}/${totalPages}`)
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(true),
        new ButtonBuilder()
          .setCustomId(`wl:remove_channel:page:${currentPage + 1}`)
          .setLabel('Next')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(EMOJIS.ARROW_RIGHT)
          .setDisabled(currentPage >= totalPages)
      );
      rowsComponents.push(navRow);

      const responsePayload = {
        content: `${EMOJIS.SHIELD} Select a channel to revoke from the **Master Whitelist** (Page ${currentPage}/${totalPages}):`,
        components: rowsComponents,
        flags: MessageFlags.Ephemeral
      };

      if (customId.startsWith('wl:remove_channel:page:')) {
        await interaction.update(responsePayload);
      } else {
        await interaction.reply(responsePayload);
      }
      return true;
    }

    // 23. Channel Selected to Remove
    if (customId === 'wl:select_remove_channel') {
      const chId = interaction.values[0];
      revokeWhitelistTarget(interaction.guild.id, sdb, 'channel', chId, interaction.user.id);
      await interaction.update({
        content: `${EMOJIS.SUCCESS} Channel <#${chId}> has been removed from the whitelist.\n*Click **Refresh Panel** on the main studio to view updated roster.*`,
        components: []
      });
      return true;
    }

    // 24. Manage Channel Trigger
    if (customId === 'wl:manage_channel') {
      const rows = sdb.prepare('SELECT DISTINCT channel_id FROM whitelisted_channels WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        return interaction.reply({ content: `${EMOJIS.WARN} No whitelisted channels found. Click **Add Channel** first.`, flags: MessageFlags.Ephemeral });
      }

      const selectOptions = rows.slice(0, 25).map(r => {
        const ch = interaction.guild.channels?.cache?.get(r.channel_id);
        const name = ch ? ch.name : `Channel ${r.channel_id}`;
        return {
          label: `#${name}`.slice(0, 100),
          description: `ID: ${r.channel_id}`,
          value: r.channel_id
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('wl:select_manage_channel')
        .setPlaceholder('Select a channel to inspect...')
        .addOptions(selectOptions);
      const row = new ActionRowBuilder().addComponents(select);

      await interaction.reply({
        content: 'Select a whitelisted channel to view policy and bypass details:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 25. Channel Selected to Manage
    if (customId === 'wl:select_manage_channel') {
      const chId = interaction.values[0];
      const isEphemeral = isEphemeralInteraction(interaction);
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'channel', chId, prefix, { isEphemeral });
      await interaction.update(payload);
      return true;
    }

    // 26. Extra Owners Studio
    if (customId === 'wl:open_eo') {
      const payload = buildExtraOwnerStudioPayload(interaction.guild, sdb, prefix, interaction.user.username);
      try {
        await interaction.update(payload);
      } catch (e) {
        await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }
      return true;
    }

    return false;
  }
};
