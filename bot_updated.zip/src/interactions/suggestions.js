/**
 * Tungsten Suggestions Interaction Handler (Node.js)
 * Processes interactive voting buttons with persistent SQLite deduplication,
 * live vote switching, and status validation.
 */
const { MessageFlags, EmbedBuilder } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { buildSuggestionButtons } = require('../commands/utility/suggest');

module.exports = {
  prefix: 'sugg',

  async handle(interaction, client) {
    if (!interaction.isButton()) return false;
    const parts = interaction.customId.split(':');
    // Expected: sugg:up:<id> or sugg:down:<id>
    if (parts.length < 3) return false;

    const action = parts[1]; // 'up' or 'down'
    const suggId = parseInt(parts[2], 10);
    if (isNaN(suggId)) return false;

    if (!interaction.guild) {
      await interaction.reply({ content: 'Voting is only available within a server.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const sdb = getServerDb(interaction.guild.id);
    const sugg = sdb.prepare('SELECT * FROM suggestions WHERE guild_id = ? AND id = ?').get(interaction.guild.id, suggId);

    if (!sugg) {
      await interaction.reply({ content: 'This suggestion no longer exists.', flags: MessageFlags.Ephemeral });
      return true;
    }

    if (sugg.status !== 'PENDING') {
      await interaction.reply({
        content: `Voting is closed for this suggestion (Status: **${sugg.status}**).`,
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    const voteType = action === 'up' ? 'UP' : 'DOWN';
    const now = Math.floor(Date.now() / 1000);

    const voteTx = sdb.transaction(() => {
      const freshSugg = sdb.prepare('SELECT status FROM suggestions WHERE guild_id = ? AND id = ?').get(interaction.guild.id, suggId);
      if (!freshSugg || freshSugg.status !== 'PENDING') {
        return { closed: true, status: freshSugg?.status || 'UNKNOWN' };
      }

      const existingVote = sdb.prepare('SELECT vote_type FROM suggestion_votes WHERE guild_id = ? AND suggestion_id = ? AND user_id = ?')
        .get(interaction.guild.id, suggId, interaction.user.id);

      let msg = '';
      if (existingVote) {
        if (existingVote.vote_type === voteType) {
          // Toggle off vote
          sdb.prepare('DELETE FROM suggestion_votes WHERE guild_id = ? AND suggestion_id = ? AND user_id = ?')
            .run(interaction.guild.id, suggId, interaction.user.id);
          msg = 'Removed your vote from this suggestion.';
        } else {
          // Switch vote
          sdb.prepare('UPDATE suggestion_votes SET vote_type = ?, timestamp = ? WHERE guild_id = ? AND suggestion_id = ? AND user_id = ?')
            .run(voteType, now, interaction.guild.id, suggId, interaction.user.id);
          msg = `Switched your vote to **${voteType === 'UP' ? 'Upvote <a:tungsten_tick:1567242779908636802>' : 'Downvote <a:tungsten_close:1567234632905138206>'}**.`;
        }
      } else {
        // New vote
        sdb.prepare(`
          INSERT INTO suggestion_votes (guild_id, suggestion_id, user_id, vote_type, timestamp)
          VALUES (?, ?, ?, ?, ?)
        `).run(interaction.guild.id, suggId, interaction.user.id, voteType, now);
        msg = `Recorded your **${voteType === 'UP' ? 'Upvote <a:tungsten_tick:1567242779908636802>' : 'Downvote <a:tungsten_close:1567234632905138206>'}**.`;
      }

      // Atomic recount to guarantee exact vote accuracy
      const upCount = sdb.prepare("SELECT COUNT(*) as c FROM suggestion_votes WHERE guild_id = ? AND suggestion_id = ? AND vote_type = 'UP'")
        .get(interaction.guild.id, suggId)?.c || 0;
      const downCount = sdb.prepare("SELECT COUNT(*) as c FROM suggestion_votes WHERE guild_id = ? AND suggestion_id = ? AND vote_type = 'DOWN'")
        .get(interaction.guild.id, suggId)?.c || 0;

      sdb.prepare('UPDATE suggestions SET upvotes = ?, downvotes = ?, updated_at = ? WHERE id = ? AND guild_id = ?')
        .run(upCount, downCount, now, suggId, interaction.guild.id);

      return { closed: false, msg, upCount, downCount };
    });

    const txResult = voteTx();

    if (txResult.closed) {
      await interaction.reply({
        content: `Voting is closed for this suggestion (Status: **${txResult.status}**).`,
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    const { msg: feedbackMsg, upCount, downCount } = txResult;

    // Update message UI
    try {
      if (interaction.message && interaction.message.embeds.length > 0) {
        const oldEmbed = interaction.message.embeds[0];
        const newEmbed = EmbedBuilder.from(oldEmbed);

        // Update Votes field
        const fields = oldEmbed.fields ? [...oldEmbed.fields] : [];
        const voteFieldIndex = fields.findIndex(f => f.name === 'Votes');
        const newVoteFieldValue = `<a:tungsten_tick:1567242779908636802> **${upCount}**  •  <a:tungsten_close:1567234632905138206> **${downCount}**`;

        if (voteFieldIndex !== -1) {
          fields[voteFieldIndex] = { name: 'Votes', value: newVoteFieldValue, inline: true };
        } else {
          fields.push({ name: 'Votes', value: newVoteFieldValue, inline: true });
        }
        newEmbed.setFields(fields);

        const newButtons = buildSuggestionButtons(suggId, upCount, downCount, false);
        await interaction.message.edit({ embeds: [newEmbed], components: [newButtons] }).catch(() => null);
      }
    } catch (err) {
      console.warn(`[Suggestions Interaction] Error updating message UI: ${err.message}`);
    }

    await interaction.reply({ content: feedbackMsg, flags: MessageFlags.Ephemeral });
    return true;
  }
};
