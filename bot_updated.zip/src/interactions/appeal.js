/**
 * Ban Appeal Interaction Handler (Node.js)
 * Implements the Ban Appeal lifecycle:
 * 1. "Appeal Ban" button in ban notification DM opens submission Modal.
 * 2. Modal submission posts Appeal Card to configured appeals_channel.
 * 3. Staff can click "Accept (Unban)" or "Deny Appeal" with automated unban and mod_cases logging via createCase.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
  MessageFlags
} = require('discord.js');
const { hasPerm } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { createV2Card } = require('../utils/componentsV2');
const { createCase } = require('../utils/modlog');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefix: 'appeal',

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!customId.startsWith('appeal:')) return false;

    const parts = customId.split(':');
    const action = parts[1]; // 'open', 'submit', 'accept', or 'deny'

    // ─────────────────────────────────────────────────────────────
    // 1. Open Appeal Modal (Triggered from DM button)
    // ─────────────────────────────────────────────────────────────
    if (action === 'open') {
      const guildId = parts[2];
      const modal = new ModalBuilder()
        .setCustomId(`appeal:submit:${guildId}`)
        .setTitle('Ban Appeal');

      const reasonInput = new TextInputBuilder()
        .setCustomId('reason')
        .setLabel('Why should your ban be lifted?')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Explain why you believe your ban should be rescinded...')
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(1000);

      const explanationInput = new TextInputBuilder()
        .setCustomId('explanation')
        .setLabel('What happened leading to the ban?')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Describe the circumstances and what you will do differently...')
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(1000);

      modal.addComponents(
        new ActionRowBuilder().addComponents(reasonInput),
        new ActionRowBuilder().addComponents(explanationInput)
      );

      await interaction.showModal(modal);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Submit Appeal Modal
    // ─────────────────────────────────────────────────────────────
    if (action === 'submit') {
      const guildId = parts[2];
      const reason = interaction.fields.getTextInputValue('reason');
      const explanation = interaction.fields.getTextInputValue('explanation');

      let guild = client.guilds.cache.get(guildId);
      if (!guild && typeof client.guilds.fetch === 'function') {
        guild = await client.guilds.fetch(guildId).catch(() => null);
      }

      if (!guild) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Could not locate the server associated with this appeal.',
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      const sdb = getServerDb(guild.id);
      const row = sdb.prepare(
        "SELECT value FROM server_settings WHERE key = 'appeals_channel' OR key = 'moderation.appeals.channel' OR key = 'audit_log_channel'"
      ).get();
      const channelId = row?.value;

      let appealsChannel = channelId ? guild.channels.cache.get(channelId) : null;
      if (!appealsChannel && channelId && typeof guild.channels.fetch === 'function') {
        appealsChannel = await guild.channels.fetch(channelId).catch(() => null);
      }
      if (!appealsChannel) {
        appealsChannel = guild.systemChannel || null;
      }

      if (!appealsChannel) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> This server does not have an active appeals channel configured. Please contact server administration directly.',
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      const appealCard = createV2Card({
        color: 0x5865f2,
        title: `${EMOJIS.DOCUMENT} Ban Appeal Submitted`,
        description:
          `A banned member has submitted an official appeal for staff review.\n\n` +
          `• **User:** <@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\` — \`${interaction.user.id}\`)\n` +
          `• **Submitted At:** <t:${Math.floor(Date.now() / 1000)}:R>\n\n` +
          `**Why should the ban be lifted?**\n> ${reason.replace(/\n/g, '\n> ')}\n\n` +
          `**What happened leading to the ban?**\n> ${explanation.replace(/\n/g, '\n> ')}`,
        footerText: 'Tungsten Appeals System'
      });

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`appeal:accept:${guild.id}:${interaction.user.id}`)
          .setLabel('Accept (Unban)')
          .setStyle(ButtonStyle.Success)
          .setEmoji('<a:tungsten_success:1567242523468890274>'),
        new ButtonBuilder()
          .setCustomId(`appeal:deny:${guild.id}:${interaction.user.id}`)
          .setLabel('Deny Appeal')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('<a:tungsten_close:1567234632905138206>')
      );

      try {
        await appealsChannel.send({ embeds: [appealCard], components: [buttons] });
        await interaction.reply({
          content: '<a:tungsten_success:1567242523468890274> Your appeal has been submitted to the staff team for review.',
          flags: MessageFlags.Ephemeral
        });
      } catch (err) {
        await interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> Could not deliver appeal to staff channel: ${err.message}`,
          flags: MessageFlags.Ephemeral
        });
      }
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Accept Appeal (Unban user + createCase)
    // ─────────────────────────────────────────────────────────────
    if (action === 'accept') {
      const guildId = parts[2];
      const targetUserId = parts[3];
      const guild = interaction.guild || client.guilds.cache.get(guildId);

      if (!guild) {
        await interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Guild context missing.', flags: MessageFlags.Ephemeral });
        return true;
      }

      if (!hasPerm(interaction.member, PermissionsBitField.Flags.BanMembers)) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You need `Ban Members` permission to action ban appeals.',
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      const sdb = getServerDb(guild.id);

      // Attempt to unban
      let unbanned = false;
      let unbanError = null;
      try {
        await guild.bans.remove(targetUserId, `Appeal accepted by ${interaction.user.tag || interaction.user.username}`);
        unbanned = true;
      } catch (e) {
        unbanError = e.message;
      }

      // Log mod case via createCase
      const caseNum = createCase(guild.id, sdb, {
        action: 'unban',
        targetId: targetUserId,
        moderatorId: interaction.user.id,
        reason: `Ban appeal accepted by ${interaction.user.tag || interaction.user.username}`
      });

      const updatedCard = createV2Card({
        color: 0x57f287,
        title: '<a:tungsten_success:1567242523468890274> Ban Appeal Accepted',
        description:
          `This ban appeal was accepted and resolved.\n\n` +
          `• **User:** <@${targetUserId}> (\`${targetUserId}\`)\n` +
          `• **Decision:** Unbanned${unbanned ? ' (Ban removed)' : ` (Ban removal notice: ${unbanError || 'already unbanned'})`}\n` +
          `• **Reviewed By:** <@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\`)\n` +
          `• **Mod Case:** #${caseNum}`,
        footerText: 'Tungsten Appeals System • Resolved'
      });

      await interaction.update({ embeds: [updatedCard], components: [] });

      // Notify target user via DM if possible
      try {
        const targetUser = await client.users.fetch(targetUserId).catch(() => null);
        if (targetUser) {
          await targetUser.send(`<a:tungsten_success:1567242523468890274> Your ban appeal in **${guild.name}** has been accepted! You have been unbanned.`).catch(() => {});
        }
      } catch (_) {}

      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Deny Appeal (createCase)
    // ─────────────────────────────────────────────────────────────
    if (action === 'deny') {
      const guildId = parts[2];
      const targetUserId = parts[3];
      const guild = interaction.guild || client.guilds.cache.get(guildId);

      if (!guild) {
        await interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Guild context missing.', flags: MessageFlags.Ephemeral });
        return true;
      }

      if (!hasPerm(interaction.member, PermissionsBitField.Flags.BanMembers)) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You need `Ban Members` permission to action ban appeals.',
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      const sdb = getServerDb(guild.id);

      // Log mod case via createCase
      const caseNum = createCase(guild.id, sdb, {
        action: 'appeal_denied',
        targetId: targetUserId,
        moderatorId: interaction.user.id,
        reason: `Ban appeal denied by ${interaction.user.tag || interaction.user.username}`
      });

      const updatedCard = createV2Card({
        color: 0xed4245,
        title: '<a:tungsten_close:1567234632905138206> Ban Appeal Denied',
        description:
          `This ban appeal was denied by moderation staff.\n\n` +
          `• **User:** <@${targetUserId}> (\`${targetUserId}\`)\n` +
          `• **Reviewed By:** <@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\`)\n` +
          `• **Mod Case:** #${caseNum}`,
        footerText: 'Tungsten Appeals System • Resolved'
      });

      await interaction.update({ embeds: [updatedCard], components: [] });

      // Notify target user via DM if possible
      try {
        const targetUser = await client.users.fetch(targetUserId).catch(() => null);
        if (targetUser) {
          await targetUser.send(`<a:tungsten_close:1567234632905138206> Your ban appeal in **${guild.name}** has been reviewed and denied.`).catch(() => {});
        }
      } catch (_) {}

      return true;
    }

    return false;
  }
};
