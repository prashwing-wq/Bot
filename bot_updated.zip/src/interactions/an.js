/**
 * Antinuke Interaction Router (Node.js)
 * Modern Components V2 Type 17 Container interactions for Antinuke Studio,
 * grouped protections, vector configuration, rate limits, and two-step confirmations.
 */
const { MessageFlags, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { isNpManager, isOwner, getConfig } = require('../utils/tools');
const { getServerDb, getGuildAccent, syncServerDataToMaster } = require('../utils/serverDb');
const {
  setAntinukeStatus,
  createAntinukeButtons,
  buildMemberRequirementCard,
  buildAntinukeStudioPayload,
  buildVectorDetailPayload,
  buildGroupVectorsPayload,
  buildPresetsPayload
} = require('../commands/security/antinuke');
const { buildWhitelistStudioPayload } = require('../commands/security/whitelist');
const { createV2Card } = require('../utils/componentsV2');
const kit = require('../ui/kit');
const { getStateAccent, COLORS } = require('../ui/tokens');

module.exports = {
  prefixes: ['an'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    const isBotOwner = isOwner(interaction.user.id);
    const isServerOwner = interaction.user.id === interaction.guild.ownerId;
    const isManager = isNpManager(interaction.user.id);
    let isExtraOwner = false;
    try {
      const sdb = getServerDb(interaction.guild.id);
      isExtraOwner = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(interaction.guild.id, interaction.user.id));
    } catch (e) {}
    const isGuildAdmin = Boolean(interaction.member?.permissions?.has?.(PermissionsBitField.Flags.Administrator));
    const hasModPerms = isServerOwner || isExtraOwner || isGuildAdmin || isBotOwner;

    if (!hasModPerms && !isManager) {
      return interaction.reply({
        content: 'Access Denied: Only the server owner, administrators, or extra owners can use antinuke controls.',
        flags: MessageFlags.Ephemeral
      });
    }

    // NP Manager without moderation roles: allowed ONLY to view studio panel or turn ON Antinuke
    if (!hasModPerms && isManager && !isBotOwner) {
      const isTurnOn = customId === 'an:arm' || customId === 'an:enable' || customId === 'an:vec_back' || customId === 'an:back';
      const isToggle = customId.startsWith('an:vec_toggle:') || customId.startsWith('an:vector:toggle:');
      const isSelectVector = customId === 'an:select_vector' || customId.startsWith('an:vector:') || customId.startsWith('an:group:');

      if (!isTurnOn && !isToggle && !isSelectVector) {
        return interaction.reply({
          content: 'Access Denied: NP Managers cannot disable Antinuke. Only the Server Owner or Bot Owner can turn it off.',
          flags: MessageFlags.Ephemeral
        });
      }
    }

    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    // ─────────────────────────────────────────────────────────────
    // 0. Close Studio
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:close') {
      await interaction.deferUpdate().catch(() => null);
      if (interaction.message?.deletable) {
        await interaction.message.delete().catch(() => null);
      } else if (typeof interaction.editReply === 'function') {
        await interaction.editReply({ content: 'Antinuke console closed.', components: [] }).catch(() => null);
      }
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 1. Arm Antinuke (an:arm, an:enable)
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:arm' || customId === 'an:enable') {
      if (!isManager && (interaction.guild.memberCount || 0) < 50) {
        const card = buildMemberRequirementCard(interaction.guild);
        return interaction.reply({ embeds: [card], flags: MessageFlags.Ephemeral });
      }

      await interaction.deferUpdate().catch(() => null);

      setAntinukeStatus(interaction.guild.id, true);
      const sdb = getServerDb(interaction.guild.id);
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('backup_roles_enabled', '1')").run();
      syncServerDataToMaster(interaction.guild.id);

      const { setAntinukeRule, ANTINUKE_VECTORS, cacheChannelSnapshot, cacheRoleSnapshot, ensureDualBackupRoles } = require('../utils/antinukeEngine');
      for (const vKey of Object.keys(ANTINUKE_VECTORS)) {
        setAntinukeRule(interaction.guild.id, vKey, { enabled: true, limit_count: 1, action: 'ban', auto_heal: 1 });
      }
      if (interaction.guild.channels?.cache) {
        for (const ch of interaction.guild.channels.cache.values()) cacheChannelSnapshot(ch);
      }
      if (interaction.guild.roles?.cache) {
        for (const r of interaction.guild.roles.cache.values()) cacheRoleSnapshot(r);
      }
      ensureDualBackupRoles(interaction.guild, { force: true }).catch(() => null);

      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) {
        await interaction.message.edit(payload).catch(() => null);
      } else if (typeof interaction.editReply === 'function') {
        await interaction.editReply(payload).catch(() => null);
      }
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Disarm Antinuke (Two-step confirmation dialog)
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:disarm') {
      if (isManager && !isServerOwner && !isBotOwner) {
        return interaction.reply({
          content: 'Access Denied: NP Managers cannot disable Antinuke. Only the Server Owner can turn it off.',
          flags: MessageFlags.Ephemeral
        });
      }

      const confirmDialog = kit.confirm({
        title: 'Disarm Antinuke',
        message: 'Disarming antinuke will pause real-time protection sentinels and auto-healing. Are you sure you want to disarm protections?',
        confirmId: 'an:disarm:confirm',
        cancelId: 'an:disarm:cancel',
        confirmLabel: 'Disarm',
        cancelLabel: 'Cancel',
        danger: true
      });

      await interaction.deferUpdate().catch(() => null);
      if (interaction.message?.edit) {
        await interaction.message.edit(confirmDialog).catch(() => null);
      } else if (typeof interaction.editReply === 'function') {
        await interaction.editReply(confirmDialog).catch(() => null);
      }
      return true;
    }

    if (customId === 'an:disarm:confirm' || customId === 'an:disable') {
      if (isManager && !isServerOwner && !isBotOwner) {
        return interaction.reply({
          content: 'Access Denied: NP Managers cannot disable Antinuke. Only the Server Owner can turn it off.',
          flags: MessageFlags.Ephemeral
        });
      }

      await interaction.deferUpdate().catch(() => null);
      setAntinukeStatus(interaction.guild.id, false);
      try {
        const sdb = getServerDb(interaction.guild.id);
        sdb.prepare("DELETE FROM server_settings WHERE key = 'backup_roles_enabled'").run();
      } catch (_) {}
      syncServerDataToMaster(interaction.guild.id);

      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) {
        await interaction.message.edit(payload).catch(() => null);
      } else if (typeof interaction.editReply === 'function') {
        await interaction.editReply(payload).catch(() => null);
      }
      return true;
    }

    if (customId === 'an:disarm:cancel') {
      await interaction.deferUpdate().catch(() => null);
      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) {
        await interaction.message.edit(payload).catch(() => null);
      } else if (typeof interaction.editReply === 'function') {
        await interaction.editReply(payload).catch(() => null);
      }
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Panic & Reset Confirmation Dialogs
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:panic') {
      const confirmDialog = kit.confirm({
        title: 'Emergency Server Panic',
        message: 'Activating panic will lock down all server channels, revoke active invites, and contain untrusted accounts. Are you sure you want to proceed?',
        confirmId: 'an:panic:confirm',
        cancelId: 'an:panic:cancel',
        confirmLabel: 'Activate Panic',
        cancelLabel: 'Cancel',
        danger: true
      });
      await interaction.deferUpdate().catch(() => null);
      if (interaction.message?.edit) await interaction.message.edit(confirmDialog).catch(() => null);
      else await interaction.editReply(confirmDialog).catch(() => null);
      return true;
    }

    if (customId === 'an:panic:confirm') {
      await interaction.deferUpdate().catch(() => null);
      const panicCmd = client.commands?.get('panic');
      if (panicCmd && typeof panicCmd.execute === 'function') {
        await panicCmd.execute({ guild: interaction.guild, author: interaction.user, reply: () => {} }, [], client, prefix).catch(() => null);
      }
      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    if (customId === 'an:panic:cancel') {
      await interaction.deferUpdate().catch(() => null);
      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    if (customId === 'an:reset') {
      if (!isServerOwner) {
        return interaction.reply({
          content: 'Access denied: Only the server owner can reset antinuke configuration.',
          flags: MessageFlags.Ephemeral
        });
      }
      const confirmDialog = kit.confirm({
        title: 'Reset Antinuke Settings',
        message: 'Resetting will restore all vector thresholds, limits, and enforcement actions to factory defaults and disarm protection. Are you sure you want to proceed?',
        confirmId: 'an:reset:confirm',
        cancelId: 'an:reset:cancel',
        confirmLabel: 'Reset Settings',
        cancelLabel: 'Cancel',
        danger: true
      });
      await interaction.deferUpdate().catch(() => null);
      if (interaction.message?.edit) await interaction.message.edit(confirmDialog).catch(() => null);
      else await interaction.editReply(confirmDialog).catch(() => null);
      return true;
    }

    if (customId === 'an:reset:confirm') {
      if (!isServerOwner) {
        return interaction.reply({
          content: 'Access denied: Only the server owner can reset antinuke configuration.',
          flags: MessageFlags.Ephemeral
        });
      }
      await interaction.deferUpdate().catch(() => null);
      const { ANTINUKE_VECTORS, setAntinukeRule } = require('../utils/antinukeEngine');
      for (const [vecKey, meta] of Object.entries(ANTINUKE_VECTORS)) {
        setAntinukeRule(interaction.guild.id, vecKey, {
          enabled: meta.defaultEnabled !== undefined ? meta.defaultEnabled : true,
          limit_count: meta.defaultLimit || 1,
          time_window: meta.defaultWindow || 10,
          action: meta.defaultAction || 'ban',
          auto_heal: meta.defaultHeal ? true : false
        });
      }
      setAntinukeStatus(interaction.guild.id, false);
      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    if (customId === 'an:reset:cancel') {
      await interaction.deferUpdate().catch(() => null);
      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Open Whitelist Studio
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:whitelist' || customId === 'wl:studio') {
      const sdb = getServerDb(interaction.guild.id);
      const payload = buildWhitelistStudioPayload(interaction.guild, sdb, prefix, interaction.user.username);
      return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. Presets Menu & Apply Preset
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:presets_menu') {
      await interaction.deferUpdate().catch(() => null);
      const payload = buildPresetsPayload(interaction.guild);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    if (customId.startsWith('an:preset:')) {
      const mode = customId.split(':')[2];
      const { applyAntinukePreset } = require('../utils/antinukeEngine');
      applyAntinukePreset(interaction.guild.id, mode);
      await interaction.deferUpdate().catch(() => null);
      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Group Protections Submenu (an:group:<key>)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('an:group:')) {
      const groupKey = customId.split(':')[2];
      await interaction.deferUpdate().catch(() => null);
      const payload = buildGroupVectorsPayload(interaction.guild, groupKey, prefix);
      if (payload) {
        if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
        else await interaction.editReply(payload).catch(() => null);
      }
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 7. Vector Configuration Screen (an:vector:<key> or select)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('an:vector:')) {
      const vector = customId.split(':')[2];
      await interaction.deferUpdate().catch(() => null);
      const payload = buildVectorDetailPayload(interaction.guild, vector, prefix);
      if (payload) {
        if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
        else await interaction.editReply(payload).catch(() => null);
      }
      return true;
    }

    if (customId === 'an:select_vector') {
      await interaction.deferUpdate().catch(() => null);
      const vector = interaction.values[0];
      const payload = buildVectorDetailPayload(interaction.guild, vector, prefix);
      if (payload) {
        if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
        else await interaction.editReply(payload).catch(() => null);
      }
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 8. Vector Action Controls (Toggle, Action, Limit, Auto-Heal)
    // ─────────────────────────────────────────────────────────────
    const { getAntinukeRule, setAntinukeRule, listServerSnapshots } = require('../utils/antinukeEngine');

    if (customId.startsWith('an:vec_toggle:')) {
      const vector = customId.split(':')[2];
      const cur = getAntinukeRule(interaction.guild.id, vector);
      const targetEnabled = !cur.enabled;

      if (targetEnabled) {
        if (!isManager && (interaction.guild.memberCount || 0) < 50) {
          const card = buildMemberRequirementCard(interaction.guild);
          return interaction.reply({ embeds: [card], flags: MessageFlags.Ephemeral });
        }
      } else {
        if (isManager && !isServerOwner && !isBotOwner) {
          return interaction.reply({
            content: 'Access denied: NP Managers cannot turn off antinuke protections. Only the Server Owner can turn it off.',
            flags: MessageFlags.Ephemeral
          });
        }
        if (!hasModPerms) {
          return interaction.reply({
            content: 'Access denied: Only administrators can modify protection settings.',
            flags: MessageFlags.Ephemeral
          });
        }
      }

      await interaction.deferUpdate().catch(() => null);
      setAntinukeRule(interaction.guild.id, vector, { enabled: targetEnabled });
      const payload = buildVectorDetailPayload(interaction.guild, vector, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    if (customId.startsWith('an:vec_action:')) {
      if (!hasModPerms) {
        return interaction.reply({
          content: 'Access denied: Only administrators can configure protection actions.',
          flags: MessageFlags.Ephemeral
        });
      }
      await interaction.deferUpdate().catch(() => null);
      const vector = customId.split(':')[2];
      const actions = ['ban', 'kick', 'strip', 'quarantine'];
      const cur = getAntinukeRule(interaction.guild.id, vector);
      const nextAction = actions[(actions.indexOf(cur.action) + 1) % actions.length];
      setAntinukeRule(interaction.guild.id, vector, { action: nextAction });
      const payload = buildVectorDetailPayload(interaction.guild, vector, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    if (customId.startsWith('an:vec_limit:')) {
      if (!hasModPerms) {
        return interaction.reply({
          content: 'Access denied: Only administrators can configure rate limits.',
          flags: MessageFlags.Ephemeral
        });
      }
      await interaction.deferUpdate().catch(() => null);
      const vector = customId.split(':')[2];
      const limits = [{ limit: 1, window: 10 }, { limit: 2, window: 10 }, { limit: 3, window: 10 }, { limit: 5, window: 60 }];
      const cur = getAntinukeRule(interaction.guild.id, vector);
      const curIdx = limits.findIndex(l => l.limit === cur.limit_count);
      const next = limits[(curIdx + 1) % limits.length];
      setAntinukeRule(interaction.guild.id, vector, { limit_count: next.limit, time_window: next.window });
      const payload = buildVectorDetailPayload(interaction.guild, vector, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    if (customId.startsWith('an:vec_heal:')) {
      if (!hasModPerms) {
        return interaction.reply({
          content: 'Access denied: Only administrators can toggle auto-heal on protections.',
          flags: MessageFlags.Ephemeral
        });
      }
      await interaction.deferUpdate().catch(() => null);
      const vector = customId.split(':')[2];
      const cur = getAntinukeRule(interaction.guild.id, vector);
      setAntinukeRule(interaction.guild.id, vector, { auto_heal: !cur.auto_heal });
      const payload = buildVectorDetailPayload(interaction.guild, vector, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 9. Back to Main Studio (an:vec_back, an:back)
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:vec_back' || customId === 'an:back') {
      await interaction.deferUpdate().catch(() => null);
      const payload = buildAntinukeStudioPayload(interaction.guild, prefix);
      if (interaction.message?.edit) await interaction.message.edit(payload).catch(() => null);
      else await interaction.editReply(payload).catch(() => null);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 10. Disaster Recovery Snapshots
    // ─────────────────────────────────────────────────────────────
    if (customId === 'an:snapshots') {
      const snaps = listServerSnapshots(interaction.guild.id);
      const factList = snaps.length > 0
        ? snaps.slice(0, 5).map(s => ({
            label: `ID #${s.id} (${s.name})`,
            value: `Captured <t:${s.created_at}:R> by <@${s.created_by}>`
          }))
        : [{ label: 'Snapshots', value: 'No snapshots recorded yet.' }];

      const card = kit.panel({
        title: 'Antinuke · Disaster Recovery Registry',
        status: `${snaps.length} snapshot${snaps.length === 1 ? '' : 's'} recorded`,
        description: '-# Use snapshots to restore channel and role structures after an incident.',
        facts: factList,
        rows: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('an:vec_back').setLabel('Back to Studio').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('an:close').setLabel('Close').setStyle(ButtonStyle.Secondary)
          )
        ]
      });

      return interaction.reply({ ...card, flags: MessageFlags.Ephemeral });
    }

    // ─────────────────────────────────────────────────────────────
    // 11. Undo Punishment (an:undo:<id>)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('an:undo:')) {
      const isAuthorized = isServerOwner || isExtraOwner;
      if (!isAuthorized) {
        return interaction.reply({
          content: 'Access Denied: Only the server owner or extra owners can undo antinuke punishments.',
          flags: MessageFlags.Ephemeral
        });
      }

      const incidentId = customId.slice('an:undo:'.length);
      const sdb = getServerDb(interaction.guild.id);
      let logEntry = null;
      try {
        logEntry = sdb.prepare(`
          SELECT * FROM audit_logs
          WHERE reason LIKE ? OR details LIKE ?
          ORDER BY COALESCE(created_at, timestamp, 0) DESC
          LIMIT 1
        `).get(`%${incidentId}%`, `%${incidentId}%`);
      } catch (e) {}

      let incidentDetails = null;
      if (logEntry) {
        try {
          incidentDetails = JSON.parse(logEntry.reason || logEntry.details);
        } catch (_) {
          try {
            incidentDetails = JSON.parse(logEntry.details);
          } catch (_) {}
        }
      }

      const actorId = incidentDetails?.actorId || logEntry?.target_id;
      const rawAction = (incidentDetails?.action || logEntry?.action || '').toLowerCase();

      if (!actorId) {
        return interaction.reply({
          content: `Could not locate incident records for incident #${incidentId}.`,
          flags: MessageFlags.Ephemeral
        });
      }

      let undoResult = '';
      const operatorTag = interaction.user?.tag || interaction.user?.username || interaction.user?.id;

      if (rawAction.includes('ban')) {
        try {
          if (interaction.guild.bans?.remove) {
            await interaction.guild.bans.remove(actorId, 'Antinuke incident undone by ' + operatorTag);
          }
          undoResult = 'Ban revoked.';
        } catch (err) {
          undoResult = `Ban revocation failed: ${err.message}`;
        }
      } else if (rawAction.includes('quarantine')) {
        const { unquarantineUser } = require('../utils/antinukeEngine');
        const qRes = await unquarantineUser(interaction.guild, actorId, client);
        undoResult = qRes?.success ? 'Quarantine lifted and roles restored.' : `Quarantine lift failed: ${qRes?.reason || qRes?.error}`;
      } else if (rawAction.includes('strip')) {
        let restored = false;
        try {
          const { unquarantineUser } = require('../utils/antinukeEngine');
          const qRes = await unquarantineUser(interaction.guild, actorId, client);
          if (qRes && qRes.success) restored = true;
        } catch (_) {}

        if (!restored) {
          const strippedRoles = incidentDetails?.strippedRoles || [];
          const member = interaction.guild.members?.cache?.get(actorId)
            || (interaction.guild.members?.fetch ? await interaction.guild.members.fetch(actorId).catch(() => null) : null);
          if (member && strippedRoles.length > 0 && typeof member.roles?.add === 'function') {
            await member.roles.add(strippedRoles, 'Antinuke incident undone by ' + operatorTag).catch(() => null);
            restored = true;
          }
        }
        undoResult = restored ? 'Stripped roles restored.' : 'Roles restored from snapshot.';
      } else {
        try {
          if (interaction.guild.bans?.remove) {
            await interaction.guild.bans.remove(actorId, 'Antinuke incident undone by ' + operatorTag);
          }
        } catch (_) {}
        try {
          const { unquarantineUser } = require('../utils/antinukeEngine');
          await unquarantineUser(interaction.guild, actorId, client).catch(() => null);
        } catch (_) {}
        undoResult = 'Sanctions lifted.';
      }

      let buttonUpdated = false;
      try {
        if (interaction.message?.components?.length > 0) {
          const updatedComponents = interaction.message.components.map(row => {
            const newRow = ActionRowBuilder.from(row);
            newRow.components = newRow.components.map(btn => {
              const btnCustomId = btn.data?.custom_id || btn.data?.customId || btn.customId || btn.custom_id || btn.data?.data?.custom_id;
              if (btnCustomId === customId) {
                const targetBtn = (btn.data && btn.data.data) ? btn.data.data : btn;
                return ButtonBuilder.from(targetBtn)
                  .setDisabled(true)
                  .setLabel('Punishment undone')
                  .setStyle(ButtonStyle.Secondary);
              }
              return btn;
            });
            return newRow;
          });
          if (typeof interaction.update === 'function') {
            await interaction.update({ components: updatedComponents });
            buttonUpdated = true;
          }
        }
      } catch (err) {}

      if (buttonUpdated) {
        if (typeof interaction.followUp === 'function') {
          await interaction.followUp({
            content: `Punishment for incident ${incidentId} (<@${actorId}>) undone by <@${interaction.user.id}>: **${undoResult}**`,
            flags: MessageFlags.Ephemeral
          }).catch(() => null);
        }
        return true;
      }

      if (typeof interaction.reply === 'function') {
        return interaction.reply({
          content: `Punishment for incident ${incidentId} (<@${actorId}>) undone by <@${interaction.user.id}>: **${undoResult}**`,
          flags: MessageFlags.Ephemeral
        });
      }

      return true;
    }

    return false;
  }
};
