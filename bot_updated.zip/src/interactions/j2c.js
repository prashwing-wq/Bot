/**
 * Join-to-Create Sentinel Studio & Room Controls Interaction Router (Node.js)
 * Handles interactive controls for both J2C Studio Configuration (staff)
 * and Voice Room Controls (room owners & staff).
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  UserSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags,
  PermissionsBitField
} = require('discord.js');

const { getServerDb } = require('../utils/serverDb');
const { getConfig, hasPerm } = require('../utils/tools');
const {
  buildJ2CStudioPayload,
  buildJ2CRoomPayload
} = require('../commands/media/j2c');

const STUDIO_ACTIONS = new Set([
  'j2c:setup_auto',
  'j2c:toggle',
  'j2c:limit_studio',
  'j2c:modal_limit_studio',
  'j2c:reset',
  'j2c:select_hub'
]);

const ROOM_ACTIONS = new Set([
  'j2c:lock',
  'j2c:unlock',
  'j2c:limit',
  'j2c:modal_limit',
  'j2c:rename',
  'j2c:modal_rename',
  'j2c:kick',
  'j2c:select_kick',
  'j2c:claim',
  'j2c:refresh'
]);

module.exports = {
  prefixes: ['j2c'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild || !customId || !customId.startsWith('j2c:')) return false;

    const sdb = getServerDb(interaction.guild.id);
    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig?.prefix || client?.config?.DEFAULT_PREFIX || '!';

    // ─────────────────────────────────────────────────────────────
    // 1. Studio Configuration Interactions (Staff Admin Only)
    // ─────────────────────────────────────────────────────────────
    if (STUDIO_ACTIONS.has(customId)) {
      if (!hasPerm(interaction.member, 'ManageChannels')) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You need the `Manage Channels` permission to configure Join-to-Create.',
          flags: MessageFlags.Ephemeral
        });
      }

      // A. Capacity Modal Launcher (Do NOT defer before modal!)
      if (customId === 'j2c:limit_studio') {
        let curLimit = '0';
        try {
          const rowLim = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_user_limit'").get();
          if (rowLim?.value) curLimit = rowLim.value;
        } catch (_) {}

        const modal = new ModalBuilder()
          .setCustomId('j2c:modal_limit_studio')
          .setTitle('Default Room Capacity');

        const input = new TextInputBuilder()
          .setCustomId('user_limit')
          .setLabel('Member Capacity (0 for unlimited)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Enter limit (0-99)')
          .setRequired(true)
          .setMinLength(1)
          .setMaxLength(2)
          .setValue(curLimit);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);
        return true;
      }

      // B. Capacity Modal Submit
      if (customId === 'j2c:modal_limit_studio') {
        const inputVal = interaction.fields?.getTextInputValue('user_limit')?.trim();
        let parsed = parseInt(inputVal, 10);
        if (isNaN(parsed) || parsed < 0) parsed = 0;
        parsed = Math.min(99, parsed);

        sdb.prepare(`
          INSERT INTO server_settings (key, value, updated_at)
          VALUES ('j2c_user_limit', ?, strftime('%s', 'now'))
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).run(String(parsed));

        const payload = buildJ2CStudioPayload(interaction.guild, prefix);
        if (interaction.message && typeof interaction.message.edit === 'function') {
          await interaction.message.edit(payload).catch(() => null);
        }

        return interaction.reply({
          content: `<a:tungsten_success:1567242523468890274> Default dynamic room capacity set to **${parsed === 0 ? 'Unlimited (0)' : `${parsed} members`}**.`,
          flags: MessageFlags.Ephemeral
        });
      }

      // C. 1-Click Auto Setup
      if (customId === 'j2c:setup_auto') {
        const botMember = interaction.guild.members.me;
        if (botMember?.permissions && !botMember.permissions.has([PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.MoveMembers])) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> I need the **Manage Channels** and **Move Members** permissions to set up Join-to-Create.',
            flags: MessageFlags.Ephemeral
          });
        }

        await interaction.deferUpdate().catch(() => null);

        const findChannel = (predicate) => {
          if (typeof interaction.guild.channels?.cache?.find === 'function') {
            return interaction.guild.channels.cache.find(predicate);
          }
          if (interaction.guild.channels?.cache?.values) {
            for (const c of interaction.guild.channels.cache.values()) {
              if (predicate(c)) return c;
            }
          }
          return null;
        };

        let category = findChannel(c => c.type === ChannelType.GuildCategory && c.name?.toLowerCase().includes('join to create'));
        if (!category && typeof interaction.guild.channels?.create === 'function') {
          category = await interaction.guild.channels.create({
            name: '🔊 Join To Create',
            type: ChannelType.GuildCategory
          }).catch(() => null);
        }

        let hubChannel = findChannel(c => c.type === ChannelType.GuildVoice && c.name?.toLowerCase().includes('join to create'));
        if (!hubChannel && typeof interaction.guild.channels?.create === 'function') {
          hubChannel = await interaction.guild.channels.create({
            name: '➕ Join to Create',
            type: ChannelType.GuildVoice,
            parent: category?.id,
            userLimit: 0
          }).catch(() => null);
        }

        if (hubChannel) {
          // Explicitly ensure bot has ViewChannel, Connect, MoveMembers, ManageChannels on the hub channel
          if (botMember && typeof hubChannel.permissionOverwrites?.edit === 'function') {
            await hubChannel.permissionOverwrites.edit(botMember.id, {
              ViewChannel: true,
              Connect: true,
              MoveMembers: true,
              ManageChannels: true
            }).catch(() => null);
          }

          sdb.prepare(`
            INSERT INTO server_settings (key, value, updated_at)
            VALUES ('j2c_hub_channel', ?, strftime('%s', 'now'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
          `).run(hubChannel.id);
        }

        if (category) {
          sdb.prepare(`
            INSERT INTO server_settings (key, value, updated_at)
            VALUES ('j2c_category', ?, strftime('%s', 'now'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
          `).run(category.id);
        }

        sdb.prepare(`
          INSERT INTO server_settings (key, value, updated_at)
          VALUES ('j2c_enabled', '1', strftime('%s', 'now'))
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).run();

        const payload = buildJ2CStudioPayload(interaction.guild, prefix);
        await interaction.editReply(payload).catch(() => null);
        return true;
      }

      // D. Defer Update for other studio actions
      await interaction.deferUpdate().catch(() => null);

      // E. Toggle Enable / Disable
      if (customId === 'j2c:toggle') {
        const curRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_enabled'").get();
        const willEnable = !(curRow?.value === '1');
        sdb.prepare(`
          INSERT INTO server_settings (key, value, updated_at)
          VALUES ('j2c_enabled', ?, strftime('%s', 'now'))
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).run(willEnable ? '1' : '0');
      }

      // F. Reset All Settings
      else if (customId === 'j2c:reset') {
        sdb.prepare(`
          DELETE FROM server_settings
          WHERE key IN ('j2c_hub_channel', 'j2c_category', 'j2c_control_panel_channel', 'j2c_user_limit', 'j2c_bitrate', 'j2c_name_template', 'j2c_enabled')
        `).run();
      }

      // G. Select Generator Voice Hub Channel
      else if (customId === 'j2c:select_hub') {
        const selectedId = interaction.values?.[0];
        if (selectedId) {
          sdb.prepare(`
            INSERT INTO server_settings (key, value, updated_at)
            VALUES ('j2c_hub_channel', ?, strftime('%s', 'now'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
          `).run(selectedId);

          sdb.prepare(`
            INSERT INTO server_settings (key, value, updated_at)
            VALUES ('j2c_enabled', '1', strftime('%s', 'now'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
          `).run();
        }
      }

      const payload = buildJ2CStudioPayload(interaction.guild, prefix);
      await interaction.editReply(payload).catch(() => null);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Room Controls Interactions (Room Owner & Staff)
    // ─────────────────────────────────────────────────────────────
    if (ROOM_ACTIONS.has(customId)) {
      const isVoiceChannel = typeof interaction.channel?.isVoiceBased === 'function'
        ? interaction.channel.isVoiceBased()
        : (interaction.channel?.type === ChannelType.GuildVoice || interaction.channel?.type === 2);

      const voiceChannel = (isVoiceChannel ? interaction.channel : null) || interaction.member?.voice?.channel;

      if (!voiceChannel) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You must be connected to this voice lounge to use room controls.',
          flags: MessageFlags.Ephemeral
        });
      }

      const roomRecord = sdb.prepare('SELECT owner_id FROM voice_rooms WHERE channel_id = ?').get(voiceChannel.id);

      const isRoomOwner = Boolean(roomRecord && roomRecord.owner_id === interaction.user.id);
      const isServerOwner = interaction.user.id === interaction.guild.ownerId;
      const isStaff = hasPerm(interaction.member, 'ManageChannels');
      const isAuthorized = isRoomOwner || isServerOwner || isStaff;

      // A. Claim Room Ownership
      if (customId === 'j2c:claim') {
        if (roomRecord && roomRecord.owner_id === interaction.user.id) {
          return interaction.reply({
            content: '<a:tungsten_crown:1567238355463176334> You already own this voice room.',
            flags: MessageFlags.Ephemeral
          });
        }

        if (roomRecord && voiceChannel.members?.has(roomRecord.owner_id)) {
          return interaction.reply({
            content: `<a:tungsten_close:1567234632905138206> The current room owner (<@${roomRecord.owner_id}>) is still connected. You can only claim the room if the owner has left.`,
            flags: MessageFlags.Ephemeral
          });
        }

        sdb.prepare(`
          INSERT INTO voice_rooms (channel_id, owner_id, guild_id, created_at)
          VALUES (?, ?, ?, strftime('%s', 'now'))
          ON CONFLICT(channel_id) DO UPDATE SET owner_id = excluded.owner_id
        `).run(voiceChannel.id, interaction.user.id, interaction.guild.id);

        if (typeof voiceChannel.permissionOverwrites?.edit === 'function') {
          await voiceChannel.permissionOverwrites.edit(interaction.user.id, {
            ViewChannel: true,
            Connect: true,
            Speak: true,
            MoveMembers: true,
            MuteMembers: true,
            DeafenMembers: true,
            ManageChannels: true
          }).catch(() => null);
        }

        if (typeof voiceChannel.send === 'function') {
          await voiceChannel.send({
            content: `<a:tungsten_crown:1567238355463176334> <@${interaction.user.id}> has claimed ownership of this voice lounge!`
          }).catch(() => null);
        }

        return interaction.reply({
          content: `<a:tungsten_crown:1567238355463176334> You are now the owner of **${voiceChannel.name}**!`,
          flags: MessageFlags.Ephemeral
        });
      }

      // B. Refresh Room Payload
      if (customId === 'j2c:refresh') {
        const everyoneId = interaction.guild.roles?.everyone?.id || interaction.guild.id;
        const everyoneOverwrite = voiceChannel.permissionOverwrites?.cache?.get(everyoneId);
        const isLocked = Boolean(everyoneOverwrite?.deny?.has(PermissionsBitField.Flags.Connect));

        const ownerId = roomRecord?.owner_id;
        const ownerMember = ownerId
          ? (interaction.guild.members.cache.get(ownerId)
              || (typeof interaction.guild.members?.fetch === 'function' ? await interaction.guild.members.fetch(ownerId).catch(() => null) : null))
          : null;

        const payload = buildJ2CRoomPayload(voiceChannel, ownerMember, isLocked, voiceChannel.userLimit || 0);

        if (typeof interaction.isButton === 'function' && interaction.isButton()) {
          try {
            await interaction.update(payload);
            return true;
          } catch (_) {
            return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral }).catch(() => null);
          }
        }
        return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral }).catch(() => null);
      }

      // C. Authority Check for Rest of Room Controls
      if (!isAuthorized) {
        return interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> Only the room owner (<@${roomRecord ? roomRecord.owner_id : 'Unknown'}>) or staff can manage this room.`,
          flags: MessageFlags.Ephemeral
        });
      }

      // D. Lock Room: Edit @everyone permission overwrite { Connect: false }
      if (customId === 'j2c:lock') {
        try {
          const everyoneRole = interaction.guild.roles?.everyone || interaction.guild.id;
          await voiceChannel.permissionOverwrites.edit(everyoneRole, { Connect: false });
          return interaction.reply({
            content: `<a:tungsten_lock:1567241079030550668> **${voiceChannel.name}** has been locked. Only permitted members can connect.`,
            flags: MessageFlags.Ephemeral
          });
        } catch (err) {
          return interaction.reply({
            content: `<a:tungsten_close:1567234632905138206> Failed to lock room: ${err.message}`,
            flags: MessageFlags.Ephemeral
          });
        }
      }

      // E. Unlock Room: Edit @everyone permission overwrite { Connect: true }
      if (customId === 'j2c:unlock') {
        try {
          const everyoneRole = interaction.guild.roles?.everyone || interaction.guild.id;
          await voiceChannel.permissionOverwrites.edit(everyoneRole, { Connect: true });
          return interaction.reply({
            content: `<a:tungsten_unlock:1567246515209117968> **${voiceChannel.name}** has been unlocked. Anyone can join.`,
            flags: MessageFlags.Ephemeral
          });
        } catch (err) {
          return interaction.reply({
            content: `<a:tungsten_close:1567234632905138206> Failed to unlock room: ${err.message}`,
            flags: MessageFlags.Ephemeral
          });
        }
      }

      // F. Capacity Limit Button -> Show Modal
      if (customId === 'j2c:limit') {
        const modal = new ModalBuilder()
          .setCustomId('j2c:modal_limit')
          .setTitle('Room Capacity Limit');

        const input = new TextInputBuilder()
          .setCustomId('user_limit')
          .setLabel('Member Capacity (0 for unlimited)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Enter limit (0-99)')
          .setRequired(true)
          .setMinLength(1)
          .setMaxLength(2)
          .setValue(String(voiceChannel.userLimit || '0'));

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);
        return true;
      }

      // G. Capacity Modal Submit
      if (customId === 'j2c:modal_limit') {
        const inputVal = interaction.fields?.getTextInputValue('user_limit')?.trim();
        let parsed = parseInt(inputVal, 10);
        if (isNaN(parsed) || parsed < 0) parsed = 0;
        parsed = Math.min(99, parsed);

        try {
          await voiceChannel.setUserLimit(parsed);
          return interaction.reply({
            content: `<a:tungsten_success:1567242523468890274> Room capacity set to **${parsed === 0 ? 'Unlimited (0)' : `${parsed} members`}**.`,
            flags: MessageFlags.Ephemeral
          });
        } catch (err) {
          return interaction.reply({
            content: `<a:tungsten_close:1567234632905138206> Failed to update capacity: ${err.message}`,
            flags: MessageFlags.Ephemeral
          });
        }
      }

      // H. Rename Button -> Show Modal
      if (customId === 'j2c:rename') {
        const modal = new ModalBuilder()
          .setCustomId('j2c:modal_rename')
          .setTitle('Rename Voice Lounge');

        const input = new TextInputBuilder()
          .setCustomId('room_name')
          .setLabel('Room Name (1-50 characters)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Enter new room name...')
          .setRequired(true)
          .setMinLength(1)
          .setMaxLength(50)
          .setValue(voiceChannel.name ? voiceChannel.name.slice(0, 50) : '');

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);
        return true;
      }

      // I. Rename Modal Submit
      if (customId === 'j2c:modal_rename') {
        const newName = interaction.fields?.getTextInputValue('room_name')?.trim();
        if (!newName) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> Room name cannot be empty.',
            flags: MessageFlags.Ephemeral
          });
        }

        try {
          await voiceChannel.setName(newName.slice(0, 50));
          return interaction.reply({
            content: `<a:tungsten_success:1567242523468890274> Voice room renamed to **${newName.slice(0, 50)}**.`,
            flags: MessageFlags.Ephemeral
          });
        } catch (err) {
          const isRateLimit = err?.message?.toLowerCase().includes('rate limit') || err?.code === 50035;
          const msg = isRateLimit
            ? '<a:tungsten_close:1567234632905138206> Discord rate limits channel renames to 2 changes every 10 minutes. Please wait before renaming again.'
            : `<a:tungsten_close:1567234632905138206> Failed to rename room: ${err.message}`;
          return interaction.reply({
            content: msg,
            flags: MessageFlags.Ephemeral
          });
        }
      }

      // J. Kick Member Button -> Show User Select Menu
      if (customId === 'j2c:kick') {
        const kickMenu = new UserSelectMenuBuilder()
          .setCustomId('j2c:select_kick')
          .setPlaceholder('Select a member to disconnect...')
          .setMinValues(1)
          .setMaxValues(1);

        const row = new ActionRowBuilder().addComponents(kickMenu);
        return interaction.reply({
          content: '<a:tungsten_boot:1567233502418575501> Choose a member to disconnect from your voice lounge:',
          components: [row],
          flags: MessageFlags.Ephemeral
        });
      }

      // K. Kick Member Selection
      if (customId === 'j2c:select_kick') {
        const targetId = interaction.values?.[0];
        if (!targetId) return false;

        if (targetId === interaction.user.id) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You cannot kick yourself from the voice lounge.',
            flags: MessageFlags.Ephemeral
          });
        }

        const targetMember = interaction.guild.members.cache.get(targetId)
          || (typeof interaction.guild.members?.fetch === 'function' ? await interaction.guild.members.fetch(targetId).catch(() => null) : null);

        if (!targetMember || targetMember.voice?.channelId !== voiceChannel.id) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> That member is not currently connected to this voice lounge.',
            flags: MessageFlags.Ephemeral
          });
        }

        try {
          if (typeof targetMember.voice?.disconnect === 'function') {
            await targetMember.voice.disconnect('Disconnected by room owner');
          } else if (typeof targetMember.voice?.setChannel === 'function') {
            await targetMember.voice.setChannel(null);
          }
          return interaction.reply({
            content: `<a:tungsten_success:1567242523468890274> Disconnected <@${targetId}> from **${voiceChannel.name}**.`,
            flags: MessageFlags.Ephemeral
          });
        } catch (err) {
          return interaction.reply({
            content: `<a:tungsten_close:1567234632905138206> Failed to disconnect member: ${err.message}`,
            flags: MessageFlags.Ephemeral
          });
        }
      }
    }

    return false;
  }
};
