/**
 * Tungsten Modules Interaction Handler (Node.js)
 * Processes interactive select menu and button controls for server feature toggles.
 */
const { PermissionsBitField, MessageFlags } = require('discord.js');
const {
  AVAILABLE_MODULES,
  setModuleStatus,
  toggleModule
} = require('../utils/modulesHelper');
const { buildModulesDashboardPayload } = require('../commands/utility/modules');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefix: 'modtgl',

  async handle(interaction, client) {
    if (!interaction.guild) {
      await interaction.reply({ content: 'Module management is only available inside servers.', flags: MessageFlags.Ephemeral });
      return true;
    }

    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild) && !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      await interaction.reply({
        content: `${EMOJIS.ERROR} You need \`Manage Server\` or \`Administrator\` permission to change server modules.`,
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    const customId = interaction.customId;

    // 1. SELECT MENU
    if (interaction.isStringSelectMenu() && customId === 'modtgl:select') {
      if (typeof interaction.deferUpdate === 'function') await interaction.deferUpdate().catch(() => null);
      const selectedId = interaction.values[0];
      const match = AVAILABLE_MODULES.find(m => m.id === selectedId);

      if (match) {
        toggleModule(interaction.guild.id, match.id);
      }

      const updatedPayload = buildModulesDashboardPayload(interaction.guild.id, client);
      await interaction.update(updatedPayload);
      return true;
    }

    // 2. BUTTONS
    if (interaction.isButton()) {
      if (typeof interaction.deferUpdate === 'function') await interaction.deferUpdate().catch(() => null);
      if (customId === 'modtgl:btn:enable_all') {
        for (const m of AVAILABLE_MODULES) {
          setModuleStatus(interaction.guild.id, m.id, true);
        }
      } else if (customId === 'modtgl:btn:disable_all') {
        for (const m of AVAILABLE_MODULES) {
          setModuleStatus(interaction.guild.id, m.id, false);
        }
      }

      const updatedPayload = buildModulesDashboardPayload(interaction.guild.id, client);
      await interaction.update(updatedPayload);
      return true;
    }

    return false;
  }
};
