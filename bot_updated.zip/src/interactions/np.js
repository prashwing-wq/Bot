/**
 * No-Prefix Hub & NP Manager Studio Interaction Router (Node.js)
 */
const { MessageFlags } = require('discord.js');
const { isOwner, isNpManager, getConfig } = require('../utils/tools');
const { buildNpHubPayload, buildNpManagerStudioPayload } = require('../commands/security/np');
const { EMOJIS } = require('../utils/emojis');
const { createV2Card } = require('../utils/componentsV2');

module.exports = {
  prefixes: ['np', 'npm_btn'],
  async handle(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: 'This command can be executed only by Bot Owner.', flags: MessageFlags.Ephemeral });
    }
    const customId = interaction.customId;
    const guildPrefix = interaction.guild ? (getConfig(interaction.guild.id).prefix || '!') : '!';
    const isBotOwner = isOwner(interaction.user.id);
    const isManager = isNpManager(interaction.user.id);

    if (customId === 'np:close' || customId === 'npm_btn_close') {
      return interaction.message.delete().catch(() => {
        const card = createV2Card({
          title: `${EMOJIS.TRASH} No-Prefix Studio Dismissed`,
          description: `This interactive session was dismissed by <@${interaction.user.id}>.`
        });
        return interaction.update({ embeds: [card], components: [] });
      });
    }

    if (customId === 'np:btn_add') {
      return interaction.reply({
        content: `${EMOJIS.PLUS} **To grant No-Prefix authorization:**\nType \`${guildPrefix}np add <@user|id> [duration]\`\n*Example durations:* \`30d\`, \`1w\`, \`24h\`, or \`lifetime\`.`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId === 'np:btn_remove') {
      return interaction.reply({
        content: `${EMOJIS.MINUS} **To revoke No-Prefix authorization:**\nType \`${guildPrefix}np remove <@user|id>\``,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId === 'np:btn_list') {
      await interaction.deferUpdate().catch(() => null);
      const payload = buildNpHubPayload(interaction.guild, interaction.user, guildPrefix);
      return interaction.update(payload).catch(() => null);
    }

    if (customId === 'np:btn_mgr_studio') {
      if (!isBotOwner && !isManager) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> **Access Denied:** Only Bot Owners and NP Managers can access the NP Manager Studio.',
          flags: MessageFlags.Ephemeral
        });
      }
      await interaction.deferUpdate().catch(() => null);
      const payload = buildNpManagerStudioPayload(interaction.user, guildPrefix);
      return interaction.update(payload).catch(() => null);
    }

    if (customId === 'npm_btn_add') {
      if (!isBotOwner) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Only **Tungsten Bot Owners and Master Authorities** can appoint NP Managers.',
          flags: MessageFlags.Ephemeral
        });
      }
      return interaction.reply({
        content: `${EMOJIS.PLUS} **To appoint an NP Manager:**\nType \`${guildPrefix}np manager add <@user|id>\``,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId === 'npm_btn_remove') {
      if (!isBotOwner) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Only **Tungsten Bot Owners and Master Authorities** can revoke NP Managers.',
          flags: MessageFlags.Ephemeral
        });
      }
      return interaction.reply({
        content: `${EMOJIS.MINUS} **To revoke an NP Manager:**\nType \`${guildPrefix}np manager remove <@user|id>\``,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId === 'npm_btn_list' || customId === 'npm_btn_refresh') {
      if (!isBotOwner && !isManager) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Access Denied: NP Manager Studio is restricted to authorized personnel.',
          flags: MessageFlags.Ephemeral
        });
      }
      const payload = buildNpManagerStudioPayload(interaction.user, guildPrefix);
      return interaction.update(payload).catch(() => null);
    }

    return false;
  }
};
