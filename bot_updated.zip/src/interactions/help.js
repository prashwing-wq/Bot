/**
 * Tungsten Help Interactive Router (Node.js)
 * Manages category selection dropdown, fast module shortcuts, 5-button category pagination,
 * in-embed buttons, and Components V2 showcase demo.
 */
const { ButtonStyle, MessageFlags } = require('discord.js');
const {
  CATEGORIES,
  resolveCategoryCommands,
  buildHomePayload,
  buildCategoryPayload
} = require('../utils/helpUi');
const { createV2Card, createButtonRow } = require('../utils/componentsV2');
const { EMOJIS } = require('../utils/emojis');
const { isOwner, getConfig } = require('../utils/tools');

/**
 * Safely updates an interaction in-place, falling back to editReply if already acknowledged.
 */
async function safeUpdate(interaction, payload) {
  try {
    if (interaction.deferred || interaction.replied) {
      if (typeof interaction.editReply === 'function') {
        return await interaction.editReply(payload);
      }
    }
    if (typeof interaction.update === 'function') {
      try {
        return await interaction.update(payload);
      } catch (err) {
        if (typeof interaction.editReply === 'function') {
          return await interaction.editReply(payload);
        }
      }
    } else if (typeof interaction.editReply === 'function') {
      return await interaction.editReply(payload);
    }
  } catch (err) {
    console.error('[Help safeUpdate Error]', err?.message || err);
    return null;
  }
}

module.exports = {
  prefix: 'help',
  prefixes: ['help'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!customId || !customId.startsWith('help:')) return false;

    const guildConfig = interaction.guild ? getConfig(interaction.guild.id) : { prefix: client?.config?.DEFAULT_PREFIX || '!' };
    const prefix = guildConfig.prefix || client?.config?.DEFAULT_PREFIX || '!';

    // 1. Dismiss / Close Help Hub
    if (customId === 'help:close') {
      try {
        await interaction.deferUpdate().catch(() => null);
        if (interaction.message?.deletable) {
          await interaction.message.delete().catch(() => null);
          return true;
        }
        if (typeof interaction.deleteReply === 'function') {
          const deleted = await interaction.deleteReply().then(() => true).catch(() => false);
          if (deleted) return true;
        }
      } catch (_) {}
      const closeCard = createV2Card({
        title: `${EMOJIS.TRASH || '🗑️'} Help Hub Closed`,
        description: `This interactive help session was dismissed by <@${interaction.user.id}>.`
      });
      await safeUpdate(interaction, { embeds: [closeCard], components: [] });
      return true;
    }

    // 2. Return to Main Category Selection Hub (Home)
    if (customId === 'help:home') {
      await interaction.deferUpdate().catch(() => null);
      const payload = buildHomePayload(client, prefix, interaction.user, interaction.guild?.id);
      await safeUpdate(interaction, payload);
      return true;
    }

    // 3. Components V2 Interactive Showcase Demo
    if (customId === 'help:componentsv2_demo') {
      const card = createV2Card({
        color: 0x00FF88,
        title: `${EMOJIS.ZAP} Discord Components V2 Showcase`,
        description:
          `You are viewing a native **Discord Components V2** card layout with subtext formatting and interactive controls.\n\n` +
          `• **Layout Engine:** Type 17 modular container wrapping\n` +
          `• **Visual Anchors:** Accent-colored cards with responsive button rows\n` +
          `• **Zero-Latency Dispatch:** In-memory caching & statement reuse\n\n` +
          `-# Interactive Components V2 Demo • Engine Active`
      });

      const buttons = createButtonRow([
        { customId: 'v2_demo_pulse', label: 'Live Pulse', style: ButtonStyle.Success, emoji: EMOJIS.SUCCESS },
        { customId: 'v2_demo_telemetry', label: 'Telemetry', style: ButtonStyle.Primary, emoji: EMOJIS.CHART },
        { customId: 'v2_demo_dismiss', label: 'Dismiss', style: ButtonStyle.Secondary, emoji: EMOJIS.CLOSE }
      ]);

      await interaction.reply({ embeds: [card], components: [buttons], flags: MessageFlags.Ephemeral });
      return true;
    }

    // 4. 5-Button Pagination Controls (help:cat_first:, help:cat_prev:, help:cat_next:, help:cat_last:)
    if (
      customId.startsWith('help:cat_first:') ||
      customId.startsWith('help:cat_prev:') ||
      customId.startsWith('help:cat_next:') ||
      customId.startsWith('help:cat_last:')
    ) {
      await interaction.deferUpdate().catch(() => null);
      const parts = customId.split(':');
      const action = parts[1];
      const currentIdx = parseInt(parts[2], 10) || 0;
      let targetIdx = 0;

      if (action === 'cat_first') {
        targetIdx = 0;
      } else if (action === 'cat_prev') {
        targetIdx = Math.max(0, currentIdx - 1);
      } else if (action === 'cat_next') {
        targetIdx = Math.min(CATEGORIES.length - 1, currentIdx + 1);
      } else if (action === 'cat_last') {
        targetIdx = CATEGORIES.length - 1;
      }

      const targetCat = CATEGORIES[targetIdx] || CATEGORIES[0];
      const payload = buildCategoryPayload(targetCat, targetIdx, client, prefix, interaction.user);
      await safeUpdate(interaction, payload);
      return true;
    }

    // 5. Dropdown Category Selection
    if (customId === 'help:category_select' || customId === 'help:select_category') {
      await interaction.deferUpdate().catch(() => null);
      const selectedVal = interaction.values?.[0] || 'home';

      if (selectedVal === 'owner' && !isOwner(interaction.user.id)) {
        if (typeof interaction.followUp === 'function') {
          await interaction.followUp({
            content: 'Access Denied: Owner commands are private and exclusively restricted to Bot Owners via `ownerhelp`.',
            flags: MessageFlags.Ephemeral
          }).catch(() => null);
        } else if (typeof interaction.reply === 'function') {
          await interaction.reply({
            content: 'Access Denied: Owner commands are private and exclusively restricted to Bot Owners via `ownerhelp`.',
            flags: MessageFlags.Ephemeral
          }).catch(() => null);
        }
        return true;
      }

      if (selectedVal === 'home') {
        const payload = buildHomePayload(client, prefix, interaction.user, interaction.guild?.id);
        await safeUpdate(interaction, payload);
        return true;
      }

      const catIndex = CATEGORIES.findIndex(
        c => c.id === selectedVal || c.value === selectedVal || c.label?.toLowerCase() === selectedVal.toLowerCase()
      );
      const targetIdx = catIndex >= 0 ? catIndex : 0;
      const targetCat = CATEGORIES[targetIdx];

      const payload = buildCategoryPayload(targetCat, targetIdx, client, prefix, interaction.user);
      await safeUpdate(interaction, payload);
      return true;
    }

    // 6. Category Button Selection (help:category:<id>, help:cat:<id>, help:cat_<id>)
    if (customId.startsWith('help:category:') || customId.startsWith('help:cat:') || customId.startsWith('help:cat_')) {
      await interaction.deferUpdate().catch(() => null);
      let catId = '';
      if (customId.startsWith('help:category:')) {
        catId = customId.slice('help:category:'.length);
      } else if (customId.startsWith('help:cat:')) {
        catId = customId.slice('help:cat:'.length);
      } else {
        catId = customId.slice('help:cat_'.length);
      }

      if (catId === 'owner' && !isOwner(interaction.user.id)) {
        if (typeof interaction.followUp === 'function') {
          await interaction.followUp({
            content: 'Access Denied: Owner commands are private and exclusively restricted to Bot Owners via `ownerhelp`.',
            flags: MessageFlags.Ephemeral
          }).catch(() => null);
        } else if (typeof interaction.reply === 'function') {
          await interaction.reply({
            content: 'Access Denied: Owner commands are private and exclusively restricted to Bot Owners via `ownerhelp`.',
            flags: MessageFlags.Ephemeral
          }).catch(() => null);
        }
        return true;
      }

      const catIndex = CATEGORIES.findIndex(
        c => c.id === catId || c.value === catId || c.label?.toLowerCase() === catId.toLowerCase()
      );
      const targetIdx = catIndex >= 0 ? catIndex : 0;
      const targetCat = CATEGORIES[targetIdx];

      const payload = buildCategoryPayload(targetCat, targetIdx, client, prefix, interaction.user);
      await safeUpdate(interaction, payload);
      return true;
    }

    // 7. Legacy Pagination Controls (help:prev: / help:next:)
    if (customId.startsWith('help:prev:') || customId.startsWith('help:next:')) {
      await interaction.deferUpdate().catch(() => null);
      const parts = customId.split(':');
      const isNext = parts[1] === 'next';
      const catId = parts[2];
      const currPage = parseInt(parts[3], 10) || 0;
      const newPage = isNext ? currPage + 1 : Math.max(0, currPage - 1);

      const catIndex = CATEGORIES.findIndex(c => c.id === catId);
      const targetIdx = catIndex >= 0 ? catIndex : 0;
      const targetCat = CATEGORIES[targetIdx];

      const payload = buildCategoryPayload(targetCat, targetIdx, client, prefix, interaction.user);
      await safeUpdate(interaction, payload);
      return true;
    }

    return false;
  }
};
