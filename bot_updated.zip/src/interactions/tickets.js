/**
 * Ticket System Interaction Router (Node.js)
 * Implements category selection, question modals, claim/unclaim workflow,
 * and automated transcript generation on close (Roadmap Feature F).
 */
const {
  MessageFlags,
  ChannelType,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { hasPerm, getConfig } = require('../utils/tools');
const { createV2Card } = require('../utils/componentsV2');
const { EMOJIS } = require('../utils/emojis');
const { getTicketCategories, closeTicketWithTranscript } = require('../utils/ticketTranscript');
const { scheduleTask } = require('../utils/scheduler');

function buildTicketControls(isClaimed, _claimerId) {
  const row = new ActionRowBuilder();
  if (isClaimed) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('ticket:unclaim_btn')
        .setLabel('Unclaim Ticket')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji(EMOJIS.ARROW_LEFT || '↩️'),
      new ButtonBuilder()
        .setCustomId('ticket:close_btn')
        .setLabel('Close Ticket')
        .setStyle(ButtonStyle.Danger)
        .setEmoji(EMOJIS.LOCK)
    );
  } else {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('ticket:claim_btn')
        .setLabel('Claim Ticket')
        .setStyle(ButtonStyle.Success)
        .setEmoji(EMOJIS.TARGET),
      new ButtonBuilder()
        .setCustomId('ticket:close_btn')
        .setLabel('Close Ticket')
        .setStyle(ButtonStyle.Danger)
        .setEmoji(EMOJIS.LOCK)
    );
  }
  return row;
}

module.exports = {
  prefixes: ['ticket'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;
    if (!customId.startsWith('ticket:')) return false;

    const sdb = getServerDb(interaction.guild.id);

    // ─────────────────────────────────────────────────────────────
    // 1. Category Selection -> Open Modal
    // ─────────────────────────────────────────────────────────────
    if (customId === 'ticket:category_select' || customId.startsWith('ticket:select_cat:')) {
      const selectedCatId = interaction.values?.[0] || customId.split(':')[2] || 'general';
      const categories = getTicketCategories(interaction.guild.id, sdb);
      const cat = categories.find(c => c.id === selectedCatId) || categories[0];

      // Check existing ticket for user
      const existing = sdb.prepare("SELECT * FROM server_tickets WHERE user_id = ? AND status = 'open'").get(interaction.user.id);
      if (existing) {
        const chan = interaction.guild.channels.cache.get(existing.channel_id);
        if (chan) {
          return interaction.reply({
            content: `<a:tungsten_close:1567234632905138206> You already have an active ticket open in ${chan}. Please resolve it before opening another.`,
            flags: MessageFlags.Ephemeral
          });
        }
      }

      const modal = new ModalBuilder()
        .setCustomId(`ticket:modal_submit:${cat.id}`)
        .setTitle(`Support: ${cat.name}`.slice(0, 45));

      const questions = cat.questions || [
        { id: 'q1', label: 'What do you need assistance with?', placeholder: 'Describe your issue...', required: true }
      ];

      for (const q of questions.slice(0, 3)) {
        const input = new TextInputBuilder()
          .setCustomId(q.id)
          .setLabel(q.label.slice(0, 45))
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder((q.placeholder || '').slice(0, 100))
          .setRequired(Boolean(q.required))
          .setMaxLength(1000);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
      }

      await interaction.showModal(modal);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Modal Submission -> Provision Ticket Channel
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('ticket:modal_submit:')) {
      const catId = customId.split(':')[2] || 'general';
      const categories = getTicketCategories(interaction.guild.id, sdb);
      const cat = categories.find(c => c.id === catId) || categories[0];

      const answers = [];
      const questions = cat.questions || [{ id: 'q1', label: 'Inquiry' }];
      for (const q of questions.slice(0, 3)) {
        try {
          const ans = interaction.fields.getTextInputValue(q.id);
          if (ans) answers.push({ label: q.label, value: ans });
        } catch (_) {}
      }

      const cleanUsername = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 10) || 'user';
      const channelName = `ticket-${cat.id.slice(0, 7)}-${cleanUsername}`;

      const overwrites = [
        {
          id: interaction.guild.roles.everyone.id,
          deny: [PermissionsBitField.Flags.ViewChannel]
        },
        {
          id: interaction.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.AttachFiles
          ]
        },
        {
          id: client.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ManageChannels,
            PermissionsBitField.Flags.EmbedLinks
          ]
        }
      ];

      // Add staff role overwrite if configured
      if (cat.staff_role_id) {
        overwrites.push({
          id: cat.staff_role_id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.AttachFiles
          ]
        });
      }

      try {
        const ticketChannel = await interaction.guild.channels.create({
          name: channelName,
          type: ChannelType.GuildText,
          permissionOverwrites: overwrites
        });

        sdb.prepare(`
          INSERT INTO server_tickets (channel_id, user_id, guild_id, created_at, status, category, last_activity)
          VALUES (?, ?, ?, ?, 'open', ?, ?)
        `).run(ticketChannel.id, interaction.user.id, interaction.guild.id, Date.now(), cat.name, Date.now());

        let answersText = '';
        if (answers.length > 0) {
          answersText = answers.map(a => `**${a.label}**\n> ${a.value.replace(/\n/g, '\n> ')}`).join('\n\n');
        } else {
          answersText = '> General support inquiry.';
        }

        const welcomeEmbed = createV2Card({
          color: 0x5865f2,
          title: `${EMOJIS.TICKET} ${cat.name} • Ticket Opened`,
          description:
            `Welcome <@${interaction.user.id}>! Staff has been notified and will assist you shortly.\n\n` +
            `• **Category:** \`${cat.name}\`\n` +
            `• **Ticket Creator:** <@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\`)\n\n` +
            `**Submitted Details:**\n${answersText}\n\n` +
            `*Staff can claim this ticket using the button below. Click Close when resolved.*`,
          footerText: 'Tungsten Support System'
        });

        const controls = buildTicketControls(false, null);
        await ticketChannel.send({ content: `<@${interaction.user.id}>`, embeds: [welcomeEmbed], components: [controls] });

        // Schedule auto-close check after 24h of inactivity
        try {
          scheduleTask(interaction.guild.id, 'ticket_autoclose', Date.now() + 24 * 3600 * 1000, {
            guildId: interaction.guild.id,
            channelId: ticketChannel.id
          });
        } catch (_) {}

        return interaction.reply({ content: `<a:tungsten_success:1567242523468890274> Your ticket has been generated: <#${ticketChannel.id}>`, flags: MessageFlags.Ephemeral });
      } catch (e) {
        return interaction.reply({ content: `<a:tungsten_close:1567234632905138206> Failed to create ticket channel: ${e.message}`, flags: MessageFlags.Ephemeral });
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Fallback Legacy Create Button
    // ─────────────────────────────────────────────────────────────
    if (customId === 'ticket:create_btn') {
      const categories = getTicketCategories(interaction.guild.id, sdb);
      const cat = categories[0];

      const modal = new ModalBuilder()
        .setCustomId(`ticket:modal_submit:${cat.id}`)
        .setTitle(`Support: ${cat.name}`.slice(0, 45));

      const questions = cat.questions || [
        { id: 'q1', label: 'What do you need assistance with?', placeholder: 'Describe your issue...', required: true }
      ];

      for (const q of questions.slice(0, 3)) {
        const input = new TextInputBuilder()
          .setCustomId(q.id)
          .setLabel(q.label.slice(0, 45))
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder((q.placeholder || '').slice(0, 100))
          .setRequired(Boolean(q.required))
          .setMaxLength(1000);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
      }

      await interaction.showModal(modal);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Claim Ticket Button
    // ─────────────────────────────────────────────────────────────
    if (customId === 'ticket:claim_btn') {
      const ticketRow = sdb.prepare('SELECT * FROM server_tickets WHERE channel_id = ?').get(interaction.channel.id);
      if (!ticketRow) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Not an active ticket channel.', flags: MessageFlags.Ephemeral });
      }

      if (!hasPerm(interaction.member, PermissionsBitField.Flags.ManageChannels) && !hasPerm(interaction.member, PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need staff permissions to claim tickets.', flags: MessageFlags.Ephemeral });
      }

      sdb.prepare('UPDATE server_tickets SET claimed_by = ? WHERE channel_id = ?').run(interaction.user.id, interaction.channel.id);

      const controls = buildTicketControls(true, interaction.user.id);
      await interaction.update({ components: [controls] });
      await interaction.followUp({ content: `${EMOJIS.SUCCESS} **Ticket Claimed:** <@${interaction.user.id}> has claimed this ticket and will be assisting.` });
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 5. Unclaim Ticket Button
    // ─────────────────────────────────────────────────────────────
    if (customId === 'ticket:unclaim_btn') {
      const ticketRow = sdb.prepare('SELECT * FROM server_tickets WHERE channel_id = ?').get(interaction.channel.id);
      if (!ticketRow) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Not an active ticket channel.', flags: MessageFlags.Ephemeral });
      }

      if (ticketRow.claimed_by && ticketRow.claimed_by !== interaction.user.id && !hasPerm(interaction.member, PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Only the staff member who claimed this ticket (or an admin) can unclaim it.', flags: MessageFlags.Ephemeral });
      }

      sdb.prepare('UPDATE server_tickets SET claimed_by = NULL WHERE channel_id = ?').run(interaction.channel.id);

      const controls = buildTicketControls(false, null);
      await interaction.update({ components: [controls] });
      await interaction.followUp({ content: `↩️ **Ticket Unclaimed:** This ticket has been released and is open for any staff member.` });
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Close Ticket with Transcript
    // ─────────────────────────────────────────────────────────────
    if (customId === 'ticket:close_btn') {
      const ticketRow = sdb.prepare('SELECT * FROM server_tickets WHERE channel_id = ?').get(interaction.channel.id);
      if (!ticketRow) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> This channel is not an active support ticket.', flags: MessageFlags.Ephemeral });
      }

      await interaction.reply('<a:tungsten_lock:1567241079030550668> **Generating transcripts and closing ticket in 3 seconds...**');

      setTimeout(async () => {
        try {
          await closeTicketWithTranscript({
            guild: interaction.guild,
            channel: interaction.channel,
            closerUser: interaction.user,
            reason: 'Ticket closed by staff',
            client,
            sdb
          });
        } catch (_) {}
      }, 3000);

      return true;
    }

    if (customId === 'ticket:help_btn') {
      const guildConfig = getConfig(interaction.guild.id);
      const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';
      return interaction.reply({
        content: `${EMOJIS.TICKET} **Ticket Commands:**\n• \`${prefix}ticket create [reason]\` — Open a private support channel\n• \`${prefix}ticket close\` — Close current ticket channel\n• \`${prefix}ticket panel\` — Deploy the interactive panel`,
        flags: MessageFlags.Ephemeral
      });
    }

    return true;
  }
};
