/**
 * Moderation Panel & Tungsten Mod Hub Interaction Router (Node.js)
 */
const { MessageFlags, PermissionsBitField } = require('discord.js');
const { getConfig } = require('../utils/tools');
const { EMOJIS } = require('../utils/emojis');
const { isAntinukeArmed } = require('../utils/antinukeEngine');

module.exports = {
  prefixes: ['modpanel', 'celmod', 'tungmod'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    // ─────────────────────────────────────────────────────────────
    // Tungsten Mod Hub Interactive Controls (celmod:select_hub, celmod:btn:*)
    // ─────────────────────────────────────────────────────────────
    if (customId === 'celmod:select_hub' || customId === 'tungmod:select_hub' || customId.startsWith('celmod:btn:') || customId.startsWith('tungmod:btn:')) {
      if (!interaction.member?.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Moderate Members` permission to browse Tungsten Mod.', flags: MessageFlags.Ephemeral });
      }

      let celmod;
      try {
        celmod = require('../commands/moderation/tungmod');
      } catch (e) {
        celmod = require('../commands/moderation/celmod');
      }
      const guildConfig = getConfig(interaction.guild.id);
      const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

      let targetHub = 'overview';
      if (customId === 'celmod:select_hub' || customId === 'tungmod:select_hub') {
        targetHub = interaction.values?.[0] || 'overview';
      } else if (customId.startsWith('celmod:btn:') || customId.startsWith('tungmod:btn:')) {
        targetHub = customId.replace(/^(celmod|tungmod):btn:/, '');
      }

      await interaction.deferUpdate().catch(() => null);
      const buildCard = celmod.buildTungmodHubCard || celmod.buildCelmodHubCard;
      const hubPayload = buildCard(interaction.guild, targetHub, prefix);
      await interaction.editReply(hubPayload).catch(() => null);
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // Moderation Panel Interactions (modpanel:select & modpanel:btn)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('modpanel:select:') || customId.startsWith('modpanel:btn:')) {
      if (!isAntinukeArmed(interaction.guild.id)) {
        return interaction.reply({
          content: '<a:tungsten_warn:1567242784535085148> Moderation actions are locked because Antinuke is **disabled** on this server. To execute moderations, please enable Antinuke first (`!antinuke enable`).',
          flags: MessageFlags.Ephemeral
        });
      }

      const modpanelModule = require('../commands/moderation/modpanel');
      const guildConfig = getConfig(interaction.guild.id);
      const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

      // 1. Dropdown Category Selection
      if (customId.startsWith('modpanel:select:')) {
        const authorId = customId.split(':')[2];
        if (interaction.user.id !== authorId && !interaction.member?.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
          return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> This moderation panel belongs to another moderator.', flags: MessageFlags.Ephemeral });
        }

        await interaction.deferUpdate().catch(() => null);

        const selectedCategory = interaction.values[0] || 'overview';
        const embed = modpanelModule.getPanelEmbed(selectedCategory, interaction.guild, interaction.user, client, prefix);
        const selectMenu = modpanelModule.buildCategorySelect(selectedCategory, authorId);
        const buttons = modpanelModule.buildCategoryButtons(selectedCategory, authorId);

        return interaction.editReply({ embeds: [embed], components: [selectMenu, ...buttons] });
      }

      // 2. Button Actions
      if (customId.startsWith('modpanel:btn:')) {
        const parts = customId.split(':');
        const action = parts[2];
        const subaction = parts[3];
        const authorId = parts[parts.length - 1];

        if (interaction.user.id !== authorId && !interaction.member?.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
          return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> This moderation panel belongs to another moderator.', flags: MessageFlags.Ephemeral });
        }

        // Close button
        if (action === 'close') {
          try {
            await interaction.deferUpdate().catch(() => null);
            await interaction.message.delete().catch(() => null);
          } catch (e) {
            try {
              await interaction.editReply({ components: [] }).catch(() => null);
            } catch (err) {}
          }
          return true;
        }

        // Return to Overview
        if (action === 'overview' && (!subaction || subaction === authorId)) {
          await interaction.deferUpdate().catch(() => null);
          const embed = modpanelModule.getPanelEmbed('overview', interaction.guild, interaction.user, client, prefix);
          const selectMenu = modpanelModule.buildCategorySelect('overview', authorId);
          const buttons = modpanelModule.buildCategoryButtons('overview', authorId);
          return interaction.editReply({ embeds: [embed], components: [selectMenu, ...buttons] });
        }

        // Shortcut to specific category from overview
        if (action === 'overview' && subaction && subaction !== authorId) {
          await interaction.deferUpdate().catch(() => null);
          const embed = modpanelModule.getPanelEmbed(subaction, interaction.guild, interaction.user, client, prefix);
          const selectMenu = modpanelModule.buildCategorySelect(subaction, authorId);
          const buttons = modpanelModule.buildCategoryButtons(subaction, authorId);
          return interaction.editReply({ embeds: [embed], components: [selectMenu, ...buttons] });
        }

        // Quick Purge buttons (10, 25, 50, 100, bots)
        if (action === 'purge') {
          if (!interaction.member?.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You require `Manage Messages` permission.', flags: MessageFlags.Ephemeral });
          }
          if (!interaction.guild.members.me?.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> I lack `Manage Messages` permission in this channel.', flags: MessageFlags.Ephemeral });
          }

          const count = parseInt(subaction, 10) || 10;
          try {
            const messages = await interaction.channel.messages.fetch({ limit: count });
            const filtered = subaction === 'bots' ? messages.filter(m => m.author.bot) : messages;
            const deleted = await interaction.channel.bulkDelete(filtered, true);
            return interaction.reply({
              content: `${EMOJIS.SWEEP} Cleanly purged **${deleted.size}** message(s).`,
              flags: MessageFlags.Ephemeral
            });
          } catch (err) {
            return interaction.reply({
              content: `<a:tungsten_close:1567234632905138206> Purge error: ${err.message}`,
              flags: MessageFlags.Ephemeral
            });
          }
        }

        // Channel Lock / Unlock / Hide / Unhide
        if (action === 'channel') {
          if (!interaction.member?.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You require `Manage Channels` permission.', flags: MessageFlags.Ephemeral });
          }

          const ch = interaction.channel;
          const everyoneRole = interaction.guild.roles.everyone;

          try {
            if (subaction === 'lock') {
              await ch.permissionOverwrites.edit(everyoneRole, { SendMessages: false });
              return interaction.reply({ content: `<a:tungsten_lock:1567241079030550668> Channel <#${ch.id}> is now locked.`, flags: MessageFlags.Ephemeral });
            } else if (subaction === 'unlock') {
              await ch.permissionOverwrites.edit(everyoneRole, { SendMessages: null });
              return interaction.reply({ content: `<a:tungsten_unlock:1567246515209117968> Channel <#${ch.id}> is now unlocked.`, flags: MessageFlags.Ephemeral });
            } else if (subaction === 'hide') {
              await ch.permissionOverwrites.edit(everyoneRole, { ViewChannel: false });
              return interaction.reply({ content: `<a:tungsten_eye:1567238862042833088> Channel <#${ch.id}> is now hidden from members.`, flags: MessageFlags.Ephemeral });
            } else if (subaction === 'unhide') {
              await ch.permissionOverwrites.edit(everyoneRole, { ViewChannel: null });
              return interaction.reply({ content: `<a:tungsten_eye:1567238862042833088> Channel <#${ch.id}> is now visible.`, flags: MessageFlags.Ephemeral });
            }
          } catch (err) {
            return interaction.reply({ content: `<a:tungsten_close:1567234632905138206> Channel action failed: ${err.message}`, flags: MessageFlags.Ephemeral });
          }
        }

        // Syntax guides for subactions
        const guideMap = {
          'ban:help': `<a:tungsten_hammer:1567240140277944350> **Ban Member Syntax:** \`${prefix}ban @user [reason]\` or \`${prefix}softban @user [reason]\``,
          'ban:unbanhelp': `<a:tungsten_unlock:1567246515209117968> **Unban Member Syntax:** \`${prefix}unban <user_id> [reason]\``,
          'kick:help': `<a:tungsten_boot:1567233502418575501> **Kick Member Syntax:** \`${prefix}kick @user [reason]\``,
          'warn:warnhelp': `<a:tungsten_warn:1567246685082746940> **Issue Warning Syntax:** \`${prefix}warn @user <reason>\``,
          'warn:checkhelp': `<a:tungsten_clipboard:1567234610176204900> **Check Warnings Syntax:** \`${prefix}warnings @user\``,
          'warn:clearhelp': `<a:tungsten_sweep:1567242656281657414> **Clear Warnings Syntax:** \`${prefix}clearwarns @user\``,
          'roles:addhelp': `<a:tungsten_plus:1567241846453833840> **Add Role Syntax:** \`${prefix}giverole @user @role\``,
          'roles:removehelp': `<a:tungsten_minus:1567241276057849856> **Remove Role Syntax:** \`${prefix}removerole @user @role\``,
          'roles:nickhelp': `<a:tungsten_gear:1567239932970406012> **Change Nickname Syntax:** \`${prefix}setnick @user <new_nickname>\``,
          'timeout:unmute': `<a:tungsten_sound:1567242242127568958> **Remove Timeout Syntax:** \`${prefix}unmute @user\``
        };

        const key = `${action}:${subaction}`;
        if (guideMap[key]) {
          return interaction.reply({ content: guideMap[key], flags: MessageFlags.Ephemeral });
        }

        // Timeout presets
        if (action === 'timeout') {
          return interaction.reply({
            content: `<a:tungsten_loading:1567241050567876698> **Apply Timeout Preset (${subaction}):**\nRun \`${prefix}mute @user ${subaction} [reason]\` to timeout with this duration.`,
            flags: MessageFlags.Ephemeral
          });
        }
      }
      return true;
    }

    return false;
  }
};
