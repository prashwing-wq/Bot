/**
 * EmojiPack Interaction Router (Node.js)
 */
const { MessageFlags } = require('discord.js');
const { getConfig } = require('../utils/tools');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefixes: ['emojipack'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (customId === 'emojipack:info') {
      const prefix = interaction.guild ? (getConfig(interaction.guild.id)?.prefix || '!') : '!';
      return interaction.reply({
        content: `${EMOJIS.PACKAGE} **Emoji Pack Auto-Installer:**\n• Run \`${prefix}emojipack install\` in chat to upload all animated & static emojis directly to this server.\n• Make sure Tungsten has **Manage Emojis and Stickers** permission and your server has free slots!`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId === 'emojipack:view_emojis') {
      if (!interaction.guild) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Must be run in a server.', flags: MessageFlags.Ephemeral });
      }
      const total = interaction.guild.emojis.cache.size;
      const anim = interaction.guild.emojis.cache.filter(e => e.animated).size;
      const stat = total - anim;
      return interaction.reply({
        content: `${EMOJIS.SPARKLES} **${interaction.guild.name} Emojis:**\n• **Total:** ${total}\n• **Animated:** ${anim}\n• **Static:** ${stat}`,
        flags: MessageFlags.Ephemeral
      });
    }

    return false;
  }
};
