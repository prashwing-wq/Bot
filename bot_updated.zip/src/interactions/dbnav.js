/**
 * Database Navigation Component Router (Node.js)
 * Handles interactive pagination, table switching, document inspection,
 * direct file export, and quota telemetry from the !db control suite.
 * Strictly restricted to verified Bot Owners.
 * 100% Colorless UI conforming to Celestia / Tungsten Design Standards.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  EmbedBuilder,
  AttachmentBuilder
} = require('discord.js');
const path = require('node:path');
const fs = require('node:fs');
const { isOwner, createEmbed } = require('../utils/tools');
const { getMongoDb, initMongo, isMongoConnected } = require('../utils/mongoClient');
const { getMasterDb, getServerDb } = require('../utils/serverDb');

/**
 * Ensures MongoDB connection is active and returns the database handle
 */
async function ensureDb() {
  let db = getMongoDb();
  if (!db && !isMongoConnected()) {
    try {
      await initMongo();
      db = getMongoDb();
    } catch (_) {}
  }
  return db;
}

/**
 * Redacts sensitive tokens, passwords, and secrets from documents
 */
function redactSensitive(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(redactSensitive);
  const clean = {};
  for (const [k, v] of Object.entries(obj)) {
    const lowerKey = k.toLowerCase();
    if (
      lowerKey.includes('token') ||
      lowerKey.includes('secret') ||
      lowerKey.includes('password') ||
      lowerKey.includes('auth') ||
      lowerKey.includes('webhook_url')
    ) {
      clean[k] = '[REDACTED]';
    } else if (typeof v === 'string') {
      clean[k] = v.replace(/[\w-]{24,26}\.[\w-]{6}\.[\w-]{27,38}/g, '[REDACTED_TOKEN]');
    } else if (typeof v === 'object' && v !== null) {
      clean[k] = redactSensitive(v);
    } else {
      clean[k] = v;
    }
  }
  return clean;
}

/**
 * Generates interactive navigation button rows for !db contents
 */
function buildNavigationButtons(category, page, maxPages = 1) {
  const normCategory = (category || 'all').toLowerCase();
  const currentPage = Math.max(1, page || 1);
  const totalPages = Math.max(1, maxPages || 1);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dbnav:contents:all:1')
      .setLabel('Overview')
      .setStyle(normCategory === 'all' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dbnav:contents:master:1')
      .setLabel('Master Tables')
      .setStyle(normCategory === 'master' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dbnav:contents:guild:1')
      .setLabel('Guild Tables')
      .setStyle(normCategory === 'guild' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dbnav:contents:quota:1')
      .setLabel('Storage Quota')
      .setStyle(normCategory === 'quota' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`dbnav:contents:refresh:${normCategory}:${currentPage}`)
      .setLabel('Refresh')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Secondary)
  );

  const rows = [row1];

  // Add pagination control row for multipage categories
  if (normCategory === 'master' || normCategory === 'guild') {
    const prevPage = Math.max(1, currentPage - 1);
    const nextPage = Math.min(totalPages, currentPage + 1);

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:${normCategory}:1`)
        .setLabel('First')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage <= 1),
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:${normCategory}:${prevPage}`)
        .setLabel('Previous')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage <= 1),
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:${normCategory}:${currentPage}`)
        .setLabel(`Page ${currentPage} / ${totalPages}`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:${normCategory}:${nextPage}`)
        .setLabel('Next')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage >= totalPages),
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:${normCategory}:${totalPages}`)
        .setLabel('Last')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage >= totalPages)
    );
    rows.push(row2);
  }

  return rows;
}

/**
 * Parses customId tokens into action, scope, table, and page
 */
function parseTargetAndPage(parts) {
  let scope = null;
  let table = null;
  let page = 1;

  if (parts.length >= 5) {
    scope = parts[2];
    table = parts[3];
    page = parseInt(parts[4], 10) || 1;
  } else if (parts.length === 4) {
    if (!isNaN(Number(parts[3]))) {
      table = parts[2];
      page = parseInt(parts[3], 10) || 1;
    } else {
      scope = parts[2];
      table = parts[3];
      page = 1;
    }
  } else if (parts.length === 3) {
    table = parts[2];
    page = 1;
  }

  return { scope, table, page };
}

/**
 * Builds fallback contents payload if database command does not export one
 */
async function buildContentsPayloadFallback(category = 'all', page = 1, db = null, client = null) {
  const normCategory = (category || 'all').toLowerCase();
  const currentPage = Math.max(1, parseInt(page, 10) || 1);
  const pageSize = 12;

  let mongoDb = db;
  if (!mongoDb) {
    mongoDb = await ensureDb();
  }

  let masterTables = [];
  let guildTables = [];
  let storageStats = null;

  if (mongoDb) {
    try {
      masterTables = await mongoDb.collection('master_records').aggregate([
        { $group: { _id: '$table', count: { $sum: 1 } } },
        { $sort: { _id: 1 } }
      ]).toArray();

      guildTables = await mongoDb.collection('guild_records').aggregate([
        { $group: { _id: '$table', count: { $sum: 1 } } },
        { $sort: { _id: 1 } }
      ]).toArray();

      const rawStats = await mongoDb.command({ dbStats: 1 }).catch(() => null);
      if (rawStats) {
        const quotaBytes = 512 * 1024 * 1024; // 512 MB
        const storageBytes = rawStats.storageSize || 0;
        const indexBytes = rawStats.indexSize || 0;
        const totalUsedBytes = storageBytes + indexBytes;
        const usedMB = (totalUsedBytes / (1024 * 1024)).toFixed(2);
        const freeMB = Math.max(0, 512 - parseFloat(usedMB)).toFixed(2);
        const percent = ((totalUsedBytes / quotaBytes) * 100).toFixed(2);

        const totalBlocks = 16;
        const filledBlocks = Math.min(totalBlocks, Math.max(parseFloat(usedMB) > 0 ? 1 : 0, Math.round((percent / 100) * totalBlocks)));
        const progressBar = '█'.repeat(filledBlocks) + '░'.repeat(totalBlocks - filledBlocks);

        storageStats = {
          usedMB,
          freeMB,
          percent,
          progressBar,
          collections: rawStats.collections || 0,
          objects: rawStats.objects || 0,
          avgObjSize: rawStats.avgObjSize ? (rawStats.avgObjSize / 1024).toFixed(2) + ' KB' : 'N/A'
        };
      }
    } catch (_) {}
  }

  // Fallback to SQLite in-memory tables if MongoDB has 0 or is disconnected
  if (masterTables.length === 0 && guildTables.length === 0) {
    const targetDb = getMasterDb();
    const tables = targetDb.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).all();
    const tableList = tables.map(t => {
      let count = 0;
      try { count = targetDb.prepare(`SELECT COUNT(*) as c FROM "${t.name}"`).get()?.c || 0; } catch (_) {}
      return `• \`${t.name.padEnd(26)}\` — **${count}** rows`;
    });

    const maxP = Math.max(1, Math.ceil(tableList.length / pageSize));
    const startIdx = (currentPage - 1) * pageSize;
    const pageItems = tableList.slice(startIdx, startIdx + pageSize);

    const embed = createEmbed()
      .setTitle('Database Tables & Contents Overview (In-Memory RAM)')
      .setDescription(
        `**In-Memory Storage Cache:**\n` +
        `• **Active Tables:** \`${tables.length}\` tables in RAM\n` +
        `• **Local Disk Files:** \`0\` (Zero disk footprint)\n\n` +
        `### Tables (Page ${currentPage} / ${maxP}):\n` +
        (pageItems.join('\n') || 'No tables found.')
      )
      .setFooter({ text: `Page ${currentPage} of ${maxP} • Read-Only Diagnostic Sentinel` });

    return {
      embeds: [embed],
      components: buildNavigationButtons('all', currentPage, maxP)
    };
  }

  const quotaBlock = storageStats
    ? `**Storage Quota Consumption (MongoDB Atlas M0 Free Tier):**\n` +
      `\`[${storageStats.progressBar}]\` **${storageStats.usedMB} MB** / **512.00 MB** (**${storageStats.percent}%**)\n` +
      `• **Remaining Headroom:** \`${storageStats.freeMB} MB\` free space available\n` +
      `• **Total Documents:** \`${storageStats.objects.toLocaleString()}\` across \`${storageStats.collections}\` collections\n\n`
    : `**Storage Quota:** \`< 1.50 MB\` / \`512.00 MB\` (< 0.3% consumed)\n\n`;

  // 1. MASTER TABLES CATEGORY
  if (normCategory === 'master') {
    const maxP = Math.max(1, Math.ceil(masterTables.length / pageSize));
    const safePage = Math.min(currentPage, maxP);
    const startIdx = (safePage - 1) * pageSize;
    const pageItems = masterTables.slice(startIdx, startIdx + pageSize);
    const lines = pageItems.map(t => `• \`${t._id.padEnd(28)}\` — **${t.count}** documents`);

    const embed = createEmbed()
      .setTitle('MongoDB Atlas Cloud — Master Tables')
      .setDescription(
        quotaBlock +
        `### Master Tables Collection (\`${masterTables.length}\` tables total):\n` +
        (lines.join('\n') || 'No master tables recorded.') +
        `\n\n*Page ${safePage} of ${maxP}. Use buttons below to navigate.*`
      )
      .setFooter({ text: `Category: Master Tables • Page ${safePage} of ${maxP}` });

    return {
      embeds: [embed],
      components: buildNavigationButtons('master', safePage, maxP)
    };
  }

  // 2. GUILD TABLES CATEGORY
  if (normCategory === 'guild') {
    const maxP = Math.max(1, Math.ceil(guildTables.length / pageSize));
    const safePage = Math.min(currentPage, maxP);
    const startIdx = (safePage - 1) * pageSize;
    const pageItems = guildTables.slice(startIdx, startIdx + pageSize);
    const lines = pageItems.map(t => `• \`${t._id.padEnd(28)}\` — **${t.count}** documents`);

    const embed = createEmbed()
      .setTitle('MongoDB Atlas Cloud — Guild Tables')
      .setDescription(
        quotaBlock +
        `### Guild Tables Collection (\`${guildTables.length}\` tables across servers):\n` +
        (lines.join('\n') || 'No guild tables recorded.') +
        `\n\n*Page ${safePage} of ${maxP}. Use buttons below to navigate.*`
      )
      .setFooter({ text: `Category: Guild Tables • Page ${safePage} of ${maxP}` });

    return {
      embeds: [embed],
      components: buildNavigationButtons('guild', safePage, maxP)
    };
  }

  // 3. STORAGE QUOTA CATEGORY
  if (normCategory === 'quota') {
    const embed = createEmbed()
      .setTitle('MongoDB Atlas Cloud — Storage Quota & Capacity')
      .setDescription(
        `### Atlas Free-Tier Storage Allocation\n` +
        `• **Allocation Limit:** \`512.00 MB\`\n` +
        `• **Current Consumed:** \`${storageStats?.usedMB || '< 1.50'} MB\`\n` +
        `• **Free Headroom:** \`${storageStats?.freeMB || '510.50'} MB\`\n` +
        `• **Consumption Rate:** \`${storageStats?.percent || '0.25'}%\` utilized\n\n` +
        `### Visual Meter\n` +
        `\`[${storageStats?.progressBar || '█░░░░░░░░░░░░░░░'}]\` **${storageStats?.percent || '0.25'}%**\n\n` +
        `### Infrastructure Topology\n` +
        `• **Cloud Cluster:** MongoDB Atlas Cloud (Shared Free Tier M0)\n` +
        `• **Local Disk Files:** \`0\` (Zero disk database files)\n` +
        `• **Master Tables Registered:** \`${masterTables.length}\` tables\n` +
        `• **Guild Tables Registered:** \`${guildTables.length}\` tables\n` +
        `• **Total Objects:** \`${storageStats?.objects || (masterTables.length + guildTables.length)}\`\n` +
        `• **Average Document Size:** \`${storageStats?.avgObjSize || '~1.20 KB'}\`\n\n` +
        `*Continuous cloud mirroring and in-memory caching ensures 100% zero data loss.*`
      )
      .setFooter({ text: 'Storage Quota Telemetry • Read-Only Sentinel' });

    return {
      embeds: [embed],
      components: buildNavigationButtons('quota', 1, 1)
    };
  }

  // 4. OVERVIEW / ALL (DEFAULT)
  const masterTop = masterTables.slice(0, 8).map(t => `• \`${t._id.padEnd(24)}\` — **${t.count}**`);
  const guildTop = guildTables.slice(0, 8).map(t => `• \`${t._id.padEnd(24)}\` — **${t.count}**`);

  const embed = createEmbed()
    .setTitle('MongoDB Atlas Cloud — Database Contents & Quota')
    .setDescription(
      quotaBlock +
      `### Master Tables Overview (\`${masterTables.length}\` tables total):\n` +
      (masterTop.join('\n') || 'None recorded') +
      (masterTables.length > 8 ? `\n*...and ${masterTables.length - 8} more master tables (Click "Master Tables" to browse)*` : '') +
      `\n\n### Guild Tables Overview (\`${guildTables.length}\` tables across servers):\n` +
      (guildTop.join('\n') || 'None recorded') +
      (guildTables.length > 8 ? `\n*...and ${guildTables.length - 8} more guild tables (Click "Guild Tables" to browse)*` : '')
    )
    .setFooter({ text: 'Click buttons below to switch categories or view full table listings' });

  return {
    embeds: [embed],
    components: buildNavigationButtons('all', 1, 1)
  };
}

/**
 * Fallback inspector payload builder with pagination & download button
 */
async function buildInspectPayloadFallback(scope, table, page = 1, db = null, guildId = null) {
  let mongoDb = db;
  if (!mongoDb) {
    mongoDb = await ensureDb();
  }

  const targetTable = (table || 'bot_owners').trim();
  const isMaster = scope === 'master' || scope === 'global' || !guildId;
  const collName = isMaster ? 'master_records' : 'guild_records';
  const query = { table: targetTable };
  if (!isMaster && (scope || guildId)) {
    query.guild_id = String(scope || guildId);
  }

  const pageSize = 5;
  let docs = [];
  let total = 0;

  if (mongoDb) {
    try {
      total = await mongoDb.collection(collName).countDocuments(query);
      if (total > 0) {
        const totalPages = Math.max(1, Math.ceil(total / pageSize));
        const safePage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
        docs = await mongoDb.collection(collName)
          .find(query)
          .skip((safePage - 1) * pageSize)
          .limit(pageSize)
          .toArray();
      }
    } catch (_) {}
  }

  if (total === 0) {
    try {
      const targetDb = isMaster ? getMasterDb() : (scope || guildId ? getServerDb(scope || guildId) : getMasterDb());
      const cRes = targetDb.prepare(`SELECT COUNT(*) as c FROM "${targetTable}"`).get();
      total = cRes?.c || 0;
      if (total > 0) {
        const totalPages = Math.max(1, Math.ceil(total / pageSize));
        const safePage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
        const offset = (safePage - 1) * pageSize;
        const rows = targetDb.prepare(`SELECT * FROM "${targetTable}" LIMIT ? OFFSET ?`).all(pageSize, offset);
        docs = rows.map(r => ({ table: targetTable, ...r }));
      }
    } catch (_) {}
  }

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
  const targetKey = isMaster ? `master:${targetTable}` : `${scope || guildId}:${targetTable}`;

  if (total === 0 || docs.length === 0) {
    const embed = createEmbed()
      .setTitle(`MongoDB Atlas Document Inspector — Table: ${targetTable}`)
      .setDescription(`No documents found in \`${collName}\` matching table \`${targetTable}\`.`)
      .setFooter({ text: `Scope: ${collName} • Table: ${targetTable} • Read-Only` });
    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('dbnav:contents:all:1').setLabel('Overview').setStyle(ButtonStyle.Secondary)
        )
      ]
    };
  }

  const formatted = docs.map((doc, idx) => {
    const clean = redactSensitive({ ...doc });
    const docId = clean._id || `row_${(safePage - 1) * pageSize + idx + 1}`;
    delete clean._id;
    delete clean._synced_at;
    delete clean.table;
    if (!isMaster) delete clean.guild_id;
    const docNum = (safePage - 1) * pageSize + idx + 1;
    return `/* Document #${docNum} of ${total} | ID: ${docId} */\n${JSON.stringify(clean, null, 2)}`;
  }).join('\n\n');

  let textBlock = formatted.length > 1850 ? formatted.slice(0, 1800) + '\n\n... [Truncated]' : formatted;

  const embed = createEmbed()
    .setTitle(`MongoDB Atlas Document Inspector — ${isMaster ? 'Master DB' : `Server ${scope || guildId}`}`)
    .setDescription(
      `Table: \`${targetTable}\` • Showing **${docs.length}** of **${total}** documents (Page ${safePage}/${totalPages}):\n\`\`\`json\n${textBlock}\n\`\`\``
    )
    .setFooter({ text: `Scope: ${collName} • Page ${safePage} of ${totalPages} • Total: ${total} docs • Read-Only` });

  const prevPage = Math.max(1, safePage - 1);
  const nextPage = Math.min(totalPages, safePage + 1);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`dbnav:inspect:${targetKey}:${prevPage}`)
      .setLabel('◀ Prev')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(safePage <= 1),
    new ButtonBuilder()
      .setCustomId(`dbnav:inspect:${targetKey}:${safePage}`)
      .setLabel(`Page ${safePage} / ${totalPages}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`dbnav:inspect:${targetKey}:${nextPage}`)
      .setLabel('Next ▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(safePage >= totalPages),
    new ButtonBuilder()
      .setCustomId(`dbnav:export:${targetKey}:1`)
      .setLabel('📥 Download JSON File')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

/**
 * Fallback table export generator if database command export is unavailable
 */
async function exportTableDataFallback(scope, table, db = null, guildId = null) {
  let mongoDb = db;
  if (!mongoDb) {
    mongoDb = await ensureDb();
  }

  let targetTable = table ? String(table).trim() : 'bot_owners';
  let targetScope = scope ? String(scope).trim() : null;

  // Master export
  if (targetTable === 'master' || (targetScope === 'master' && (!targetTable || targetTable === 'all' || targetTable === 'master'))) {
    let docs = [];
    if (mongoDb) {
      try { docs = await mongoDb.collection('master_records').find({}).toArray(); } catch (_) {}
    }
    if (docs.length === 0) {
      try {
        const mDb = getMasterDb();
        const tables = mDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
        for (const t of tables) {
          const rows = mDb.prepare(`SELECT * FROM "${t.name}"`).all();
          for (const r of rows) docs.push({ table: t.name, ...r });
        }
      } catch (_) {}
    }
    const cleanDocs = docs.map(d => redactSensitive({ ...d }));
    const jsonStr = JSON.stringify(cleanDocs, null, 2);
    const buffer = Buffer.from(jsonStr, 'utf-8');
    const fileName = 'master_database.json';
    const attachment = new AttachmentBuilder(buffer, { name: fileName });
    const embed = createEmbed()
      .setTitle('Database Export — Master Database')
      .setDescription(
        `📦 Exported **${cleanDocs.length}** documents from master database as a downloadable JSON file.\n` +
        `• **File:** \`${fileName}\`\n` +
        `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\`\n` +
        `• **Scope:** \`master_records\` (Atlas Cloud & RAM)`
      )
      .setFooter({ text: 'MongoDB Atlas Cloud Export • Authorized Bot Owner' });
    return { buffer, fileName, docCount: cleanDocs.length, embed, attachment, files: [attachment], embeds: [embed] };
  }

  // Server export
  const isServer = (targetTable === 'server' && targetScope) || (/^\d{16,21}$/.test(targetTable) && !targetScope) || (/^\d{16,21}$/.test(targetScope) && (!targetTable || targetTable === 'all' || targetTable === 'server'));
  if (isServer) {
    const sId = /^\d{16,21}$/.test(targetTable) ? targetTable : (targetScope || guildId);
    let docs = [];
    if (mongoDb) {
      try { docs = await mongoDb.collection('guild_records').find({ guild_id: String(sId) }).toArray(); } catch (_) {}
    }
    if (docs.length === 0) {
      try {
        const gDb = getServerDb(sId);
        const tables = gDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
        for (const t of tables) {
          const rows = gDb.prepare(`SELECT * FROM "${t.name}"`).all();
          for (const r of rows) docs.push({ guild_id: sId, table: t.name, ...r });
        }
      } catch (_) {}
    }
    const cleanDocs = docs.map(d => redactSensitive({ ...d }));
    const jsonStr = JSON.stringify(cleanDocs, null, 2);
    const buffer = Buffer.from(jsonStr, 'utf-8');
    const fileName = `server_${sId}.json`;
    const attachment = new AttachmentBuilder(buffer, { name: fileName });
    const embed = createEmbed()
      .setTitle(`Database Export — Server ${sId}`)
      .setDescription(
        `📦 Exported **${cleanDocs.length}** documents for server \`${sId}\` as a downloadable JSON file.\n` +
        `• **File:** \`${fileName}\`\n` +
        `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\`\n` +
        `• **Scope:** \`guild_records\` (Server: ${sId})`
      )
      .setFooter({ text: `Guild ID: ${sId} • Export Complete` });
    return { buffer, fileName, docCount: cleanDocs.length, embed, attachment, files: [attachment], embeds: [embed] };
  }

  // Disk file export from db/
  const dbDir = path.resolve(process.cwd(), 'db');
  const potentialFile = targetTable ? path.resolve(dbDir, targetTable.replace(/^[/\\]+/, '')) : null;
  if (potentialFile && potentialFile.startsWith(dbDir) && (fs.existsSync(potentialFile) || fs.existsSync(potentialFile + '.json'))) {
    const realFile = fs.existsSync(potentialFile) && fs.statSync(potentialFile).isFile()
      ? potentialFile
      : potentialFile + '.json';
    if (fs.existsSync(realFile) && fs.statSync(realFile).isFile()) {
      const baseName = path.basename(realFile);
      let raw = fs.readFileSync(realFile, 'utf-8');
      if (baseName.endsWith('.json')) {
        try {
          raw = JSON.stringify(redactSensitive(JSON.parse(raw)), null, 2);
        } catch (_) {}
      }
      const buffer = Buffer.from(raw, 'utf-8');
      const attachment = new AttachmentBuilder(buffer, { name: baseName });
      const embed = createEmbed()
        .setTitle(`Database File Export — ${baseName}`)
        .setDescription(
          `📦 Exported file \`${baseName}\` from \`db/\` directory.\n` +
          `• **File:** \`${baseName}\`\n` +
          `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\``
        )
        .setFooter({ text: `File: db/${baseName} • Read-Only` });
      return { buffer, fileName: baseName, docCount: 1, embed, attachment, files: [attachment], embeds: [embed] };
    }
  }

  // Standard table export
  const isMaster = targetScope === 'master' || targetScope === 'global' || !guildId;
  const collName = isMaster ? 'master_records' : 'guild_records';
  const query = { table: targetTable };
  if (!isMaster && (targetScope || guildId)) {
    query.guild_id = String(targetScope || guildId);
  }

  let docs = [];
  if (mongoDb) {
    try {
      docs = await mongoDb.collection(collName).find(query).toArray();
      if (docs.length === 0 && !isMaster) {
        docs = await mongoDb.collection('guild_records').find({ table: targetTable }).toArray();
      }
    } catch (_) {}
  }

  if (docs.length === 0) {
    try {
      const targetDb = isMaster ? getMasterDb() : (targetScope || guildId ? getServerDb(targetScope || guildId) : getMasterDb());
      const rows = targetDb.prepare(`SELECT * FROM "${targetTable}"`).all();
      docs = rows.map(r => ({ table: targetTable, ...r }));
    } catch (_) {}
  }

  const cleanDocs = docs.map(d => redactSensitive({ ...d }));
  const jsonStr = JSON.stringify(cleanDocs, null, 2);
  const buffer = Buffer.from(jsonStr, 'utf-8');
  const fileName = `${targetTable}.json`;
  const attachment = new AttachmentBuilder(buffer, { name: fileName });
  const embed = createEmbed()
    .setTitle(`Database Table Export — ${targetTable}`)
    .setDescription(
      `📦 Exported **${cleanDocs.length}** documents from \`${targetTable}\` as a downloadable JSON file.\n` +
      `• **File:** \`${fileName}\`\n` +
      `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\`\n` +
      `• **Table:** \`${targetTable}\` (${collName})`
    )
    .setFooter({ text: `Scope: ${collName} • Table: ${targetTable} • Export Complete` });

  return { buffer, fileName, docCount: cleanDocs.length, embed, attachment, files: [attachment], embeds: [embed] };
}

module.exports = {
  prefixes: ['dbnav', 'db_nav'],

  /**
   * Main interaction router handler
   * @param {import('discord.js').ButtonInteraction} interaction
   * @param {import('discord.js').Client} client
   */
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!customId) return false;

    // Verify customId prefix
    if (!customId.startsWith('dbnav:') && !customId.startsWith('db_nav:')) {
      return false;
    }

    // 1. Strictly Owner-Only check
    if (!isOwner(interaction.user.id)) {
      if (interaction.deferred || interaction.replied) {
        return interaction.followUp({
          content: 'Access Denied: This control panel is strictly restricted to Bot Owners.',
          flags: MessageFlags.Ephemeral
        });
      }
      return interaction.reply({
        content: 'Access Denied: This control panel is strictly restricted to Bot Owners.',
        flags: MessageFlags.Ephemeral
      });
    }

    // 2. Parse Custom ID: dbnav:<action>:<arg1>:<arg2>:<arg3>
    const parts = customId.split(':');
    const action = (parts[1] || 'contents').toLowerCase();

    // Obtain Database instance
    const db = await ensureDb();

    // ─────────────────────────────────────────────────────────────
    // A. DIRECT TABLE & FILE EXPORT ACTION (dbnav:export:<target>)
    // ─────────────────────────────────────────────────────────────
    if (action === 'export' || action === 'download') {
      const { scope, table } = parseTargetAndPage(parts);

      // Defer reply to allow time for file serialization
      if (!interaction.deferred && !interaction.replied) {
        if (typeof interaction.deferReply === 'function') {
          await interaction.deferReply().catch(() => null);
        }
      }

      let exportPayload = null;
      try {
        const databaseCmd = require('../commands/security/database');
        if (typeof databaseCmd.exportTableData === 'function') {
          exportPayload = await databaseCmd.exportTableData({
            scope,
            table,
            db,
            client,
            guildId: (scope && scope !== 'master') ? scope : interaction.guildId
          });
        }
      } catch (err) {
        console.warn('[dbNavInteraction] Notice calling database.exportTableData:', err.message);
      }

      if (!exportPayload) {
        exportPayload = await exportTableDataFallback(scope, table, db, interaction.guildId);
      }

      const responsePayload = {
        embeds: [exportPayload.embed || exportPayload.embeds?.[0]],
        files: exportPayload.files || (exportPayload.attachment ? [exportPayload.attachment] : [])
      };

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(responsePayload).catch(async () => {
          await interaction.followUp(responsePayload).catch(() => null);
        });
      } else {
        await interaction.reply(responsePayload).catch(() => null);
      }

      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // B. PAGINATED DOCUMENT INSPECT ACTION (dbnav:inspect:<target>:<page>)
    // ─────────────────────────────────────────────────────────────
    if (action === 'inspect') {
      const { scope, table, page } = parseTargetAndPage(parts);

      // Defer update defensively to update current message in-place
      if (!interaction.deferred && !interaction.replied) {
        if (typeof interaction.deferUpdate === 'function') {
          await interaction.deferUpdate().catch(() => null);
        }
      }

      let inspectPayload = null;
      try {
        const databaseCmd = require('../commands/security/database');
        if (typeof databaseCmd.buildInspectPayload === 'function') {
          inspectPayload = await databaseCmd.buildInspectPayload({
            scope,
            table,
            page,
            db,
            client,
            guildId: (scope && scope !== 'master') ? scope : interaction.guildId
          });
        }
      } catch (err) {
        console.warn('[dbNavInteraction] Notice calling database.buildInspectPayload:', err.message);
      }

      if (!inspectPayload) {
        inspectPayload = await buildInspectPayloadFallback(scope, table, page, db, interaction.guildId);
      }

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(inspectPayload).catch(err => {
          console.error('[dbNavInteraction] Error updating inspect reply:', err);
        });
      } else {
        await interaction.update(inspectPayload).catch(err => {
          console.error('[dbNavInteraction] Error updating inspect interaction:', err);
        });
      }

      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // C. CONTENTS OVERVIEW & CATEGORY SWITCHING ACTION (dbnav:contents:<category>:<page>)
    // ─────────────────────────────────────────────────────────────
    let category = (parts[2] || 'all').toLowerCase();
    let page = 1;

    if (category === 'refresh') {
      if (parts[3] && isNaN(Number(parts[3]))) {
        category = parts[3].toLowerCase();
        page = parseInt(parts[4], 10) || 1;
      } else {
        category = 'all';
        page = parseInt(parts[3], 10) || 1;
      }
    } else {
      page = parseInt(parts[3], 10) || 1;
    }

    if (isNaN(page) || page < 1) page = 1;

    // Defer update defensively to prevent Discord 3s interaction timeouts
    if (!interaction.deferred && !interaction.replied) {
      if (typeof interaction.deferUpdate === 'function') {
        await interaction.deferUpdate().catch(() => null);
      }
    }

    // Try importing builder function from database command
    let payload = null;
    try {
      const databaseCmd = require('../commands/security/database');
      const builderFn =
        databaseCmd.buildContentsPayload ||
        databaseCmd.buildContents ||
        databaseCmd.buildContentsEmbed;

      if (typeof builderFn === 'function') {
        if (builderFn.length === 1) {
          payload = await builderFn({ category, page, db, client, guildId: interaction.guildId });
        } else {
          try {
            payload = await builderFn(category, page, db, client, interaction.guildId);
          } catch (posErr) {
            payload = await builderFn({ category, page, db, client, guildId: interaction.guildId });
          }
        }
      }
    } catch (importErr) {
      console.warn('[dbNavInteraction] Notice calling database.buildContentsPayload:', importErr.message);
    }

    // Use robust built-in fallback payload if external builder is unavailable
    if (!payload) {
      payload = await buildContentsPayloadFallback(category, page, db, client);
    }

    // Normalize payload structure
    let finalPayload = payload;
    if (payload instanceof EmbedBuilder || (payload && payload.data && !payload.embeds)) {
      finalPayload = {
        embeds: [payload],
        components: buildNavigationButtons(category, page)
      };
    }

    // Update the interaction response
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(finalPayload).catch(err => {
        console.error('[dbNavInteraction] Error updating reply:', err);
      });
    } else {
      await interaction.update(finalPayload).catch(err => {
        console.error('[dbNavInteraction] Error updating interaction:', err);
      });
    }

    return true;
  },

  buildNavigationButtons,
  buildContentsPayloadFallback,
  buildInspectPayloadFallback,
  exportTableDataFallback,
  parseTargetAndPage
};
