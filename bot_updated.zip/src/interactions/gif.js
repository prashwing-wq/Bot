/**
 * GIF Interactive Actions Router (Node.js)
 */
const { EmbedBuilder } = require('discord.js');

module.exports = {
  prefixes: ['gif', 'gif_dismiss', 'gif_reroll'],
  async handle(interaction, client) {
    const customId = interaction.customId;

    if (customId === 'gif_dismiss') {
      try {
        await interaction.deferUpdate().catch(() => null);
        await interaction.message.delete().catch(() => {
          return interaction.editReply({ components: [] }).catch(() => null);
        });
      } catch (e) {}
      return true;
    }

    if (customId === 'gif_reroll' || customId.startsWith('gif_reroll:')) {
      try {
        await interaction.deferUpdate().catch(() => null);
        const gifModule = require('../commands/fun/gif');
        const queryPart = customId.includes(':') ? customId.slice(customId.indexOf(':') + 1) : null;
        const query = queryPart || 'dance';
        const newUrl = await gifModule.resolveGif(query);

        const oldEmbed = interaction.message.embeds[0];
        const newEmbed = new EmbedBuilder()
          .setColor(oldEmbed?.color || 0x000001)
          .setTitle(oldEmbed?.title || '<a:tungsten_sparkle:1567242264311369839>  Tungsten GIF Studio')
          .setImage(newUrl)
          .setFooter({ text: `Requested by ${interaction.user.username} • Re-rolled` });

        if (oldEmbed?.description) {
          newEmbed.setDescription(oldEmbed.description);
        }

        const newButtons = gifModule.createGifActionRow(newUrl, query);
        await interaction.editReply({ embeds: [newEmbed], components: [newButtons] });
      } catch (e) {}
      return true;
    }

    return false;
  }
};
