/**
 * Context Menu Commands Handler (Node.js)
 * Implements Discord User and Message context menu commands:
 * 1. "Warn author" (Message context menu)
 * 2. "Report message" (Message context menu with Accept/Dismiss workflow)
 * 3. "View infractions" (User context menu)
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  MessageFlags
} = require('discord.js');
const { hasPerm, createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { EMOJIS } = require('../utils/emojis');
const { handleWarn } = require('../commands/moderation/warn');
const { buildWarningsPayload } = require('../commands/moderation/warnings');
const { createV2Card } = require('../utils/componentsV2');

const CONTEXT_MENUS = [
  {
    name: 'Warn author',
    type: 3 // ApplicationCommandType.Message
  },
  {
    name: 'Report message',
    type: 3 // ApplicationCommandType.Message
  },
  {
    name: 'View infractions',
    type: 2 // ApplicationCommandType.User
  }
];

async function handleContextMenu(interaction, client) {
  if (!interaction.guild) {
    return interaction.reply({
      content: 'Context menu commands can only be used in a server.',
      flags: MessageFlags.Ephemeral
    });
  }

  const name = interaction.commandName;

  // ─────────────────────────────────────────────────────────────
  // 1. "Warn author" (Message Context Menu)
  // ─────────────────────────────────────────────────────────────
  if (name === 'Warn author') {
    if (!hasPerm(interaction.member, PermissionsBitField.Flags.ModerateMembers)) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> You need `Moderate Members` permission to warn authors.',
        flags: MessageFlags.Ephemeral
      });
    }

    const targetMsg = interaction.targetMessage;
    if (!targetMsg || !targetMsg.author) {
      return interaction.reply({ content: 'Could not fetch the target message.', flags: MessageFlags.Ephemeral });
    }

    let targetMember;
    try {
      targetMember = await interaction.guild.members.fetch(targetMsg.author.id).catch(() => null);
    } catch (_) {}

    const snippet = targetMsg.content ? `"${targetMsg.content.slice(0, 100)}"` : 'Message content';
    const reason = `Flagged message in #${targetMsg.channel?.name || 'chat'}: ${snippet}`;

    const res = await handleWarn({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetMember: targetMember || { id: targetMsg.author.id, user: targetMsg.author, displayName: targetMsg.author.username },
      reason,
      client
    });

    if (res.error) {
      return interaction.reply({ content: res.error, flags: MessageFlags.Ephemeral });
    }

    return interaction.reply({
      content: `<a:tungsten_warn:1567246685082746940> Successfully warned <@${targetMsg.author.id}> for message: ${snippet}`,
      flags: MessageFlags.Ephemeral
    });
  }

  // ─────────────────────────────────────────────────────────────
  // 2. "Report message" (Message Context Menu)
  // ─────────────────────────────────────────────────────────────
  if (name === 'Report message') {
    const targetMsg = interaction.targetMessage;
    if (!targetMsg || !targetMsg.author) {
      return interaction.reply({ content: 'Could not fetch the target message.', flags: MessageFlags.Ephemeral });
    }

    const sdb = getServerDb(interaction.guild.id);
    const getSetting = (k) => sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(k)?.value;

    const reportChannelId = getSetting('log_messages') || getSetting('report_channel') || getSetting('audit_log_channel');
    let reportChannel = reportChannelId ? interaction.guild.channels.cache.get(reportChannelId) : null;
    if (!reportChannel) {
      reportChannel = interaction.guild.systemChannel || interaction.channel;
    }

    const snippet = targetMsg.content ? targetMsg.content.slice(0, 400) : '*[No text content / embed or attachment]*';
    const cleanMid = targetMsg.id;
    const cleanCid = targetMsg.channelId;
    const cleanAid = targetMsg.author.id;

    const reportCard = createV2Card({
      color: 0xED4245,
      title: '<a:tungsten_siren:1567242157725712555> Message Report Flagged',
      description:
        `A message has been reported for moderator review.\n\n` +
        `• **Author:** <@${cleanAid}> (\`${cleanAid}\`)\n` +
        `• **Channel:** <#${cleanCid}>\n` +
        `• **Reporter:** <@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\`)\n` +
        `• **Reported Message:**\n> ${snippet.replace(/\n/g, '\n> ')}\n\n` +
        `[Jump to Message](${targetMsg.url})`,
      footerText: `Tungsten Message Report System`
    });

    const actionRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`report:accept:${cleanCid}:${cleanMid}:${cleanAid}`)
        .setLabel('Accept (Delete & Warn)')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('<a:tungsten_shield:1567242104923627574>'),
      new ButtonBuilder()
        .setCustomId(`report:dismiss:${cleanMid}`)
        .setLabel('Dismiss Report')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji(EMOJIS.CLOSE)
    );

    try {
      await reportChannel.send({ embeds: [reportCard], components: [actionRow] });
      return interaction.reply({
        content: '<a:tungsten_success:1567242523468890274> Thank you for reporting this message. The server moderation team has been notified.',
        flags: MessageFlags.Ephemeral
      });
    } catch (e) {
      return interaction.reply({
        content: `<a:tungsten_close:1567234632905138206> Could not deliver report to mod channel: ${e.message}`,
        flags: MessageFlags.Ephemeral
      });
    }
  }

  // ─────────────────────────────────────────────────────────────
  // 3. "View infractions" (User Context Menu)
  // ─────────────────────────────────────────────────────────────
  if (name === 'View infractions') {
    if (!hasPerm(interaction.member, PermissionsBitField.Flags.ModerateMembers)) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> You need `Moderate Members` permission to inspect user infractions.',
        flags: MessageFlags.Ephemeral
      });
    }

    const targetUser = interaction.targetUser;
    let targetMember = interaction.targetMember;
    if (!targetMember && targetUser) {
      targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    }

    const payload = buildWarningsPayload(interaction.guild, targetMember || targetUser, client);
    return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
  }

  return interaction.reply({ content: 'Unrecognized context menu command.', flags: MessageFlags.Ephemeral });
}

module.exports = {
  CONTEXT_MENUS,
  handleContextMenu
};
