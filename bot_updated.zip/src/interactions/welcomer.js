/**
 * Welcomer & Leave Interaction Router (Node.js)
 * Manages buttons, modals, channel selectors, and live previews for Welcome and Leave studios.
 */
const {
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
  PermissionFlagsBits
} = require('discord.js');
const { getConfig } = require('../utils/tools');
const {
  getWelcomeConfig,
  saveWelcomeConfig,
  buildWelcomeStudioPayload,
  buildWelcomePreviewCard
} = require('../commands/welcomer/welcome');
const {
  getLeaveConfig,
  saveLeaveConfig,
  buildLeaveStudioPayload,
  buildLeavePreviewCard
} = require('../commands/welcomer/leave');

module.exports = {
  prefixes: ['welcome', 'leave'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    // Permissions Guard: ManageGuild
    if (!interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild)) {
      const errReply = {
        content: '<a:tungsten_close:1567234632905138206> Access Denied: You need the **Manage Server** permission to configure welcome and leave announcements.',
        flags: MessageFlags.Ephemeral
      };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errReply).catch(() => null);
      } else {
        await interaction.reply(errReply).catch(() => null);
      }
      return true;
    }

    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    // ─────────────────────────────────────────────────────────────
    // 1. WELCOME STUDIO INTERACTIONS (welcome:*)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('welcome:')) {
      const currentCfg = getWelcomeConfig(interaction.guild.id);

      // A. Open Modal: Edit Content (Title & Description)
      if (customId === 'welcome:edit_content') {
        const modal = new ModalBuilder()
          .setCustomId('welcome:modal_content')
          .setTitle('Customize Welcome Card Content');

        const titleInput = new TextInputBuilder()
          .setCustomId('cv2_title')
          .setLabel('Embed Title')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Welcome to {server.name}!')
          .setValue(currentCfg.cv2_title || 'Welcome to {server.name}!')
          .setMaxLength(256)
          .setRequired(false);

        const descInput = new TextInputBuilder()
          .setCustomId('cv2_description')
          .setLabel('Embed Message / Description')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Hey {user.mention}, welcome to {server.name}! Member #{memberCount}.')
          .setValue(currentCfg.cv2_description || '')
          .setMaxLength(2000)
          .setRequired(true);

        modal.addComponents(
          new ActionRowBuilder().addComponents(titleInput),
          new ActionRowBuilder().addComponents(descInput)
        );

        await interaction.showModal(modal);
        return true;
      }

      // B. Open Modal: Edit Media (Banner & Thumbnail)
      if (customId === 'welcome:edit_media') {
        const modal = new ModalBuilder()
          .setCustomId('welcome:modal_media')
          .setTitle('Customize Welcome Media');

        const bannerInput = new TextInputBuilder()
          .setCustomId('cv2_banner')
          .setLabel('Banner / Image URL (or none)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('https://example.com/banner.png or none')
          .setValue(currentCfg.cv2_banner || '')
          .setMaxLength(512)
          .setRequired(false);

        const thumbInput = new TextInputBuilder()
          .setCustomId('cv2_thumbnail')
          .setLabel('Thumbnail Mode or URL')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('avatar | server | none | https://.../thumb.png')
          .setValue(currentCfg.cv2_thumbnail || 'avatar')
          .setMaxLength(512)
          .setRequired(false);

        modal.addComponents(
          new ActionRowBuilder().addComponents(bannerInput),
          new ActionRowBuilder().addComponents(thumbInput)
        );

        await interaction.showModal(modal);
        return true;
      }

      // C. Open Modal: Edit DM Greeting
      if (customId === 'welcome:edit_dm') {
        const modal = new ModalBuilder()
          .setCustomId('welcome:modal_dm')
          .setTitle('Customize Welcome Direct Message');

        const dmInput = new TextInputBuilder()
          .setCustomId('dm_message')
          .setLabel('DM Greeting Message')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Hey {user.name}, welcome to {server.name}! Enjoy your stay!')
          .setValue(currentCfg.dm_message || '')
          .setMaxLength(2000)
          .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(dmInput));

        await interaction.showModal(modal);
        return true;
      }

      // D. Live Preview Card
      if (customId === 'welcome:preview') {
        const previewCard = buildWelcomePreviewCard(interaction.guild, interaction.member, currentCfg);
        await interaction.reply({
          content: '<a:tungsten_sparkle:1567242264311369839> **Live Welcome Card Preview (This is how it appears to joining members):**',
          embeds: [previewCard],
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      // E. Channel Selection via ChannelSelectMenu
      if (customId === 'welcome:select_channel') {
        await interaction.deferUpdate().catch(() => null);
        const chanId = interaction.values[0];
        currentCfg.channel_id = chanId;
        currentCfg.status = 1;
        saveWelcomeConfig(interaction.guild.id, currentCfg);

        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        await interaction.followUp({
          content: `<a:tungsten_success:1567242523468890274> Welcome announcement channel bound to <#${chanId}>. Welcome announcements **enabled**!`,
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      // F. Thumbnail Selection via StringSelectMenu
      if (customId === 'welcome:select_thumbnail') {
        const val = interaction.values[0];
        if (val === 'custom') {
          const modal = new ModalBuilder()
            .setCustomId('welcome:modal_custom_thumb')
            .setTitle('Custom Thumbnail Image URL');

          const urlInput = new TextInputBuilder()
            .setCustomId('custom_thumb_url')
            .setLabel('Image URL (PNG, JPG, GIF)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('https://example.com/icon.png')
            .setValue(currentCfg.cv2_thumbnail?.startsWith('http') ? currentCfg.cv2_thumbnail : '')
            .setMaxLength(512)
            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(urlInput));
          await interaction.showModal(modal);
          return true;
        }

        await interaction.deferUpdate().catch(() => null);
        currentCfg.cv2_thumbnail = val;
        saveWelcomeConfig(interaction.guild.id, currentCfg);
        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        return true;
      }

      // G. Toggle Status (Active / Off)
      if (customId === 'welcome:toggle_status') {
        await interaction.deferUpdate().catch(() => null);
        currentCfg.status = currentCfg.status === 1 ? 0 : 1;
        saveWelcomeConfig(interaction.guild.id, currentCfg);
        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        return true;
      }

      // H. Toggle DM (Active / Off)
      if (customId === 'welcome:toggle_dm') {
        await interaction.deferUpdate().catch(() => null);
        currentCfg.dm_enabled = currentCfg.dm_enabled === 1 ? 0 : 1;
        saveWelcomeConfig(interaction.guild.id, currentCfg);
        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        return true;
      }

      // I. Test Dispatch to Configured Channel
      if (customId === 'welcome:test') {
        const chanId = currentCfg.channel_id;
        const targetChannel = chanId && chanId !== '0' ? interaction.guild.channels.cache.get(String(chanId)) : interaction.channel;
        if (!targetChannel) {
          await interaction.reply({
            content: '<a:tungsten_warn:1567246685082746940> No valid welcome announcement channel configured. Select one from the menu first.',
            flags: MessageFlags.Ephemeral
          });
          return true;
        }

        const previewCard = buildWelcomePreviewCard(interaction.guild, interaction.member, currentCfg);
        await targetChannel.send({ embeds: [previewCard] });
        await interaction.reply({
          content: `<a:tungsten_success:1567242523468890274> Sent a test welcome announcement card to ${targetChannel}!`,
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      // J. Test DM
      if (customId === 'welcome:test_dm') {
        try {
          const { formatPlaceholders } = require('../utils/placeholders');
          const dmMsg = formatPlaceholders(currentCfg.dm_message || 'Welcome to {server.name}!', interaction.member, interaction.guild);
          await interaction.user.send(dmMsg);
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Sent welcome DM test preview to your DMs!',
            flags: MessageFlags.Ephemeral
          });
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> Unable to send DM. Please ensure your DMs are open.',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }

      // K. Reset Config
      if (customId === 'welcome:reset') {
        const resetCfg = {
          guild_id: String(interaction.guild.id),
          status: 0,
          channel_id: '0',
          format: 'Components V2',
          dm_enabled: 0,
          dm_message: 'Hey {user.name}, welcome to **{server.name}**! Enjoy your stay!',
          cv2_title: 'Welcome to {server.name}!',
          cv2_description: 'Hey {user.mention}, welcome to **{server.name}**! Member #{memberCount}.',
          cv2_thumbnail: 'avatar',
          cv2_banner: ''
        };
        saveWelcomeConfig(interaction.guild.id, resetCfg);
        const payload = buildWelcomeStudioPayload(interaction.guild, resetCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        return true;
      }

      // L. Modal Submission: Content
      if (customId === 'welcome:modal_content') {
        const title = interaction.fields.getTextInputValue('cv2_title')?.trim();
        const desc = interaction.fields.getTextInputValue('cv2_description')?.trim();
        if (title !== undefined) currentCfg.cv2_title = title;
        if (desc) currentCfg.cv2_description = desc;
        saveWelcomeConfig(interaction.guild.id, currentCfg);

        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Welcome card content updated successfully!',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }

      // M. Modal Submission: Media
      if (customId === 'welcome:modal_media') {
        const banner = interaction.fields.getTextInputValue('cv2_banner')?.trim();
        const thumb = interaction.fields.getTextInputValue('cv2_thumbnail')?.trim();
        currentCfg.cv2_banner = !banner || banner.toLowerCase() === 'none' || banner.toLowerCase() === 'clear' ? '' : banner;
        if (thumb) currentCfg.cv2_thumbnail = thumb;
        saveWelcomeConfig(interaction.guild.id, currentCfg);

        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Welcome media and banner updated successfully!',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }

      // N. Modal Submission: DM
      if (customId === 'welcome:modal_dm') {
        const dm = interaction.fields.getTextInputValue('dm_message')?.trim();
        if (dm) {
          currentCfg.dm_message = dm;
          currentCfg.dm_enabled = 1;
          saveWelcomeConfig(interaction.guild.id, currentCfg);
        }

        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Welcome direct message greeting updated!',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }

      // O. Modal Submission: Custom Thumbnail URL
      if (customId === 'welcome:modal_custom_thumb') {
        const url = interaction.fields.getTextInputValue('custom_thumb_url')?.trim();
        if (url) {
          currentCfg.cv2_thumbnail = url;
          saveWelcomeConfig(interaction.guild.id, currentCfg);
        }

        const payload = buildWelcomeStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Custom thumbnail URL saved!',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 2. LEAVE / FAREWELL STUDIO INTERACTIONS (leave:*)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('leave:')) {
      const currentCfg = getLeaveConfig(interaction.guild.id);

      // A. Open Modal: Edit Content (Title & Description)
      if (customId === 'leave:edit_content') {
        const modal = new ModalBuilder()
          .setCustomId('leave:modal_content')
          .setTitle('Customize Farewell Card Content');

        const titleInput = new TextInputBuilder()
          .setCustomId('leave_title')
          .setLabel('Embed Title')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Goodbye • {server.name}')
          .setValue(currentCfg.title || 'Goodbye • {server.name}')
          .setMaxLength(256)
          .setRequired(false);

        const descInput = new TextInputBuilder()
          .setCustomId('leave_message')
          .setLabel('Message Template / Description')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('**{user.name}** has left **{server.name}**. We now have {memberCount} members.')
          .setValue(currentCfg.message || '')
          .setMaxLength(2000)
          .setRequired(true);

        modal.addComponents(
          new ActionRowBuilder().addComponents(titleInput),
          new ActionRowBuilder().addComponents(descInput)
        );

        await interaction.showModal(modal);
        return true;
      }

      // B. Open Modal: Edit Media (Banner & Thumbnail)
      if (customId === 'leave:edit_media') {
        const modal = new ModalBuilder()
          .setCustomId('leave:modal_media')
          .setTitle('Customize Farewell Media');

        const bannerInput = new TextInputBuilder()
          .setCustomId('leave_banner')
          .setLabel('Banner / Image URL (or none)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('https://example.com/banner.png or none')
          .setValue(currentCfg.banner || '')
          .setMaxLength(512)
          .setRequired(false);

        const thumbInput = new TextInputBuilder()
          .setCustomId('leave_thumbnail')
          .setLabel('Thumbnail Mode or URL')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('avatar | server | none | https://.../thumb.png')
          .setValue(currentCfg.thumbnail || 'avatar')
          .setMaxLength(512)
          .setRequired(false);

        modal.addComponents(
          new ActionRowBuilder().addComponents(bannerInput),
          new ActionRowBuilder().addComponents(thumbInput)
        );

        await interaction.showModal(modal);
        return true;
      }

      // C. Live Preview Card
      if (customId === 'leave:preview') {
        const previewCard = buildLeavePreviewCard(interaction.guild, interaction.member, currentCfg);
        await interaction.reply({
          content: '<a:tungsten_sparkle:1567242264311369839> **Live Farewell Card Preview (This is how it appears to departing members):**',
          embeds: [previewCard],
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      // D. Channel Selection via ChannelSelectMenu
      if (customId === 'leave:select_channel') {
        await interaction.deferUpdate().catch(() => null);
        const chanId = interaction.values[0];
        currentCfg.channel_id = chanId;
        currentCfg.status = true;
        saveLeaveConfig(interaction.guild.id, currentCfg);

        const payload = buildLeaveStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        await interaction.followUp({
          content: `<a:tungsten_success:1567242523468890274> Farewell announcements channel bound to <#${chanId}>!`,
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      // E. Thumbnail Selection via StringSelectMenu
      if (customId === 'leave:select_thumbnail') {
        const val = interaction.values[0];
        if (val === 'custom') {
          const modal = new ModalBuilder()
            .setCustomId('leave:modal_custom_thumb')
            .setTitle('Custom Thumbnail Image URL');

          const urlInput = new TextInputBuilder()
            .setCustomId('custom_thumb_url')
            .setLabel('Image URL (PNG, JPG, GIF)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('https://example.com/icon.png')
            .setValue(currentCfg.thumbnail?.startsWith('http') ? currentCfg.thumbnail : '')
            .setMaxLength(512)
            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(urlInput));
          await interaction.showModal(modal);
          return true;
        }

        await interaction.deferUpdate().catch(() => null);
        currentCfg.thumbnail = val;
        saveLeaveConfig(interaction.guild.id, currentCfg);
        const payload = buildLeaveStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        return true;
      }

      // F. Toggle Status
      if (customId === 'leave:toggle_status') {
        await interaction.deferUpdate().catch(() => null);
        currentCfg.status = !currentCfg.status;
        saveLeaveConfig(interaction.guild.id, currentCfg);
        const payload = buildLeaveStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        return true;
      }

      // G. Test Dispatch to Configured Channel
      if (customId === 'leave:test') {
        const targetChannel = currentCfg.channel_id ? interaction.guild.channels.cache.get(String(currentCfg.channel_id)) : interaction.channel;
        if (!targetChannel) {
          await interaction.reply({
            content: '<a:tungsten_warn:1567246685082746940> No valid leave channel configured. Select one from the menu first.',
            flags: MessageFlags.Ephemeral
          });
          return true;
        }

        const previewCard = buildLeavePreviewCard(interaction.guild, interaction.member, currentCfg);
        await targetChannel.send({ embeds: [previewCard] });
        await interaction.reply({
          content: `<a:tungsten_success:1567242523468890274> Sent test farewell notice to ${targetChannel}!`,
          flags: MessageFlags.Ephemeral
        });
        return true;
      }

      // H. Reset Config
      if (customId === 'leave:reset') {
        currentCfg.channel_id = null;
        currentCfg.status = false;
        currentCfg.message = '**{user.name}** has left **{server.name}**. We now have {memberCount} members.';
        currentCfg.title = 'Goodbye • {server.name}';
        currentCfg.banner = '';
        currentCfg.thumbnail = 'avatar';
        saveLeaveConfig(interaction.guild.id, currentCfg);

        const payload = buildLeaveStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        await interaction.update(payload);
        return true;
      }

      // I. Modal Submission: Content
      if (customId === 'leave:modal_content') {
        const title = interaction.fields.getTextInputValue('leave_title')?.trim();
        const desc = interaction.fields.getTextInputValue('leave_message')?.trim();
        if (title !== undefined) currentCfg.title = title;
        if (desc) currentCfg.message = desc;
        saveLeaveConfig(interaction.guild.id, currentCfg);

        const payload = buildLeaveStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Farewell card content updated successfully!',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }

      // J. Modal Submission: Media
      if (customId === 'leave:modal_media') {
        const banner = interaction.fields.getTextInputValue('leave_banner')?.trim();
        const thumb = interaction.fields.getTextInputValue('leave_thumbnail')?.trim();
        currentCfg.banner = !banner || banner.toLowerCase() === 'none' || banner.toLowerCase() === 'clear' ? '' : banner;
        if (thumb) currentCfg.thumbnail = thumb;
        saveLeaveConfig(interaction.guild.id, currentCfg);

        const payload = buildLeaveStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Farewell media and banner updated successfully!',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }

      // K. Modal Submission: Custom Thumbnail URL
      if (customId === 'leave:modal_custom_thumb') {
        const url = interaction.fields.getTextInputValue('custom_thumb_url')?.trim();
        if (url) {
          currentCfg.thumbnail = url;
          saveLeaveConfig(interaction.guild.id, currentCfg);
        }

        const payload = buildLeaveStudioPayload(interaction.guild, currentCfg, prefix, interaction.user.username);
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({
            content: '<a:tungsten_success:1567242523468890274> Custom farewell thumbnail URL saved!',
            flags: MessageFlags.Ephemeral
          });
        }
        return true;
      }
    }

    return false;
  }
};
