/**
 * Verification Gateway Interaction Router (Node.js)
 */
const { MessageFlags } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefixes: ['verify'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (customId === 'verify:gate_pass') {
      if (!interaction.guild || !interaction.member) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Verification can only be performed inside a server.', flags: MessageFlags.Ephemeral });
      }
      const sdb = getServerDb(interaction.guild.id);
      const row = sdb.prepare('SELECT * FROM verification_settings WHERE guild_id = ?').get(interaction.guild.id);
      if (!row || !row.enabled || !row.role_id) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Verification is not configured or disabled in this server.', flags: MessageFlags.Ephemeral });
      }
      const role = interaction.guild.roles.cache.get(row.role_id);
      if (!role) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> The configured verification role no longer exists.', flags: MessageFlags.Ephemeral });
      }
      if (interaction.member.roles.cache.has(role.id)) {
        return interaction.reply({ content: `${EMOJIS.SUCCESS} You are already verified in this server!`, flags: MessageFlags.Ephemeral });
      }
      try {
        await interaction.member.roles.add(role.id, 'Tungsten Verification Gateway pass');
        return interaction.reply({
          content: `<a:tungsten_success:1567242523468890274> **Verification successful!** You have been granted the **${role.name}** role. Welcome to **${interaction.guild.name}**!`,
          flags: MessageFlags.Ephemeral
        });
      } catch (err) {
        return interaction.reply({
          content: `<a:tungsten_warn:1567246685082746940> Failed to assign role: ${err.message}. Make sure Tungsten's highest role is positioned above the verification role!`,
          flags: MessageFlags.Ephemeral
        });
      }
    }
    return false;
  }
};
