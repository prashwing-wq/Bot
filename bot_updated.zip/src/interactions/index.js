/**
 * Tungsten Interaction Modular Router (Node.js)
 * Routes component and modal interactions to dedicated panel modules.
 */
const fs = require('fs');
const path = require('path');

const _routes = new Map();

function initInteractions() {
  _routes.clear();
  const dir = __dirname;
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.js') && f !== 'index.js');

  for (const file of files) {
    try {
      const mod = require(path.join(dir, file));
      if (mod && Array.isArray(mod.prefixes)) {
        for (const p of mod.prefixes) {
          _routes.set(p, mod);
        }
      } else if (mod && typeof mod.prefix === 'string') {
        _routes.set(mod.prefix, mod);
      }
    } catch (err) {
      console.error(`[InteractionRouter] Error loading module ${file}:`, err);
    }
  }
}

initInteractions();

/**
 * Match a customId to its registered interaction module.
 * Supports exact match, colon-delimited prefix ('prefix:action'), and underscore prefix ('prefix_action').
 */
function findHandler(customId) {
  if (!customId) return null;
  const head = customId.split(':')[0];
  if (_routes.has(head)) return _routes.get(head);

  for (const [p, mod] of _routes) {
    if (customId === p || customId.startsWith(p + ':') || customId.startsWith(p + '_')) {
      return mod;
    }
  }
  return null;
}

/**
 * Route an interaction to its specialized module.
 * @returns {Promise<boolean>} True if handled by router, false otherwise.
 */
async function routeInteraction(interaction, client) {
  if (!interaction.customId) return false;
  const handler = findHandler(interaction.customId);

  if (handler && typeof handler.handle === 'function') {
    try {
      const handled = await handler.handle(interaction, client);
      return handled !== false;
    } catch (err) {
      const code = err?.code || err?.rawError?.code;
      if (code === 10062 || code === 40060) {
        return true;
      }
      console.error(`[InteractionRouter] Handler error for customId "${interaction.customId}":`, err);
      if (!interaction.deferred && !interaction.replied) {
        interaction.reply({ content: '<a:tungsten_warn:1567246685082746940> An error occurred processing this interaction.', flags: 64 }).catch(() => null);
      }
      return true;
    }
  }

  return false;
}

module.exports = {
  routeInteraction,
  findHandler,
  initInteractions,
  _routes
};
