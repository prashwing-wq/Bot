/**
 * Server Boost Overview Interaction Router (Node.js)
 */
const { MessageFlags } = require('discord.js');
const { getConfig } = require('../utils/tools');

module.exports = {
  prefixes: ['boost'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    if (customId === 'boost:refresh') {
      const { buildBoostPayload } = require('../commands/utility/boost');
      const guildConfig = getConfig(interaction.guild.id);
      const prefix = guildConfig?.prefix || client.config?.DEFAULT_PREFIX || '!';
      const payload = buildBoostPayload(interaction.guild, interaction.user, prefix);
      try {
        await interaction.update(payload);
      } catch (e) {
        await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }
      return true;
    }

    return false;
  }
};
