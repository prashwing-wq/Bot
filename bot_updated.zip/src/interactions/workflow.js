/**
 * Tungsten Workflow Interactions Router (Node.js)
 * Handles interactive buttons for workflow list, toggle, delete, and refresh.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm } = require('../utils/tools');
const { getWorkflows, toggleWorkflow } = require('../utils/workflowEngine');
const { buildWorkflowListPanel } = require('../commands/automation/workflow');

module.exports = {
  prefixes: ['wf'],

  async handle(interaction, client) {
    if (!interaction.customId || !interaction.customId.startsWith('wf')) {
      return false;
    }

    if (!interaction.guild) {
      await interaction.reply({ content: 'Workflows are only manageable within servers.', flags: 64 }).catch(() => null);
      return true;
    }

    // Permission Sentinel: ManageGuild required
    if (!hasPerm(interaction.member, PermissionsBitField.Flags.ManageGuild)) {
      await interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> You require `Manage Server` permission to interact with workflows.',
        flags: 64
      }).catch(() => null);
      return true;
    }

    const parts = interaction.customId.split(':');
    const action = parts[1];
    const targetId = parts[2] ? parseInt(parts[2], 10) : null;
    const prefix = client.config?.DEFAULT_PREFIX || '!';

    if (action === 'refresh') {
      const workflows = getWorkflows(interaction.guild.id);
      const panel = buildWorkflowListPanel(interaction.guild, workflows, prefix);
      await interaction.update(panel).catch(() => null);
      return true;
    }

    if (action === 'toggle' && targetId) {
      toggleWorkflow(interaction.guild.id, targetId);
      const workflows = getWorkflows(interaction.guild.id);
      const panel = buildWorkflowListPanel(interaction.guild, workflows, prefix);
      await interaction.update(panel).catch(() => null);
      return true;
    }

    return false;
  }
};
