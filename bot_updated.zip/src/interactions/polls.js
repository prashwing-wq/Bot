/**
 * Tungsten Polls Interaction Router (Node.js)
 * Processes interactive poll votes and staff closure with atomic SQLite persistence.
 */
const { PermissionsBitField, MessageFlags } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { renderPollEmbed, buildPollComponents } = require('../commands/utility/poll');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefix: 'poll',

  async handle(interaction, client) {
    if (!interaction.isButton()) return false;
    const parts = interaction.customId.split(':');
    // Expected: poll:vote:<pollId>:<optionIdx> or poll:end:<pollId>
    if (parts.length < 3) return false;

    const action = parts[1]; // 'vote' or 'end'
    const pollId = parseInt(parts[2], 10);
    if (isNaN(pollId)) return false;

    if (!interaction.guild) {
      await interaction.reply({ content: 'Poll voting is only available inside servers.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const sdb = getServerDb(interaction.guild.id);
    const poll = sdb.prepare('SELECT * FROM polls WHERE guild_id = ? AND id = ?').get(interaction.guild.id, pollId);

    if (!poll) {
      await interaction.reply({ content: 'This poll no longer exists.', flags: MessageFlags.Ephemeral });
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 1. END POLL ACTION
    // ─────────────────────────────────────────────────────────────
    if (action === 'end') {
      const isStaff = interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild) ||
        interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers);

      if (poll.author_id !== interaction.user.id && !isStaff) {
        await interaction.reply({ content: `${EMOJIS.ERROR} Only the poll author or server staff can end this poll.`, flags: MessageFlags.Ephemeral });
        return true;
      }

      if (poll.status === 'CLOSED') {
        await interaction.reply({ content: 'This poll is already closed.', flags: MessageFlags.Ephemeral });
        return true;
      }

      const now = Math.floor(Date.now() / 1000);
      sdb.prepare("UPDATE polls SET status = 'CLOSED', updated_at = ? WHERE id = ?").run(now, poll.id);

      const options = JSON.parse(poll.options_json);
      const votes = sdb.prepare('SELECT option_index, COUNT(*) as c FROM poll_votes WHERE guild_id = ? AND poll_id = ? GROUP BY option_index').all(interaction.guild.id, poll.id);
      const voteCounts = options.map((_, i) => votes.find(v => v.option_index === i)?.c || 0);
      const total = voteCounts.reduce((a, b) => a + b, 0);

      const closedEmbed = renderPollEmbed(poll.id, poll.question, options, voteCounts, total, 'CLOSED', client);
      const closedRows = buildPollComponents(poll.id, options, true);

      try {
        if (interaction.message) {
          await interaction.message.edit({ embeds: [closedEmbed], components: closedRows }).catch(() => null);
        }
      } catch (_) {}

      await interaction.reply({ content: `<a:tungsten_success:1567242523468890274> Poll #${poll.id} has been concluded.`, flags: MessageFlags.Ephemeral });
      return true;
    }

    // ─────────────────────────────────────────────────────────────
    // 2. VOTE ACTION
    // ─────────────────────────────────────────────────────────────
    if (action === 'vote') {
      const optIdx = parseInt(parts[3], 10);
      if (isNaN(optIdx)) return false;

      const options = JSON.parse(poll.options_json);
      if (optIdx < 0 || optIdx >= options.length) return false;

      const now = Math.floor(Date.now() / 1000);

      const voteTx = sdb.transaction(() => {
        const freshPoll = sdb.prepare('SELECT status FROM polls WHERE guild_id = ? AND id = ?').get(interaction.guild.id, pollId);
        if (!freshPoll || freshPoll.status !== 'OPEN') {
          return { closed: true };
        }

        const existing = sdb.prepare('SELECT option_index FROM poll_votes WHERE guild_id = ? AND poll_id = ? AND user_id = ?')
          .get(interaction.guild.id, pollId, interaction.user.id);

        let msg = '';
        if (existing) {
          if (existing.option_index === optIdx) {
            // Unvote / toggle off
            sdb.prepare('DELETE FROM poll_votes WHERE guild_id = ? AND poll_id = ? AND user_id = ?')
              .run(interaction.guild.id, pollId, interaction.user.id);
            msg = `Removed your vote for **${options[optIdx]}**.`;
          } else {
            // Switch vote
            sdb.prepare('UPDATE poll_votes SET option_index = ?, timestamp = ? WHERE guild_id = ? AND poll_id = ? AND user_id = ?')
              .run(optIdx, now, interaction.guild.id, pollId, interaction.user.id);
            msg = `Switched your vote to **${options[optIdx]}**.`;
          }
        } else {
          // New vote
          sdb.prepare(`
            INSERT INTO poll_votes (guild_id, poll_id, user_id, option_index, timestamp)
            VALUES (?, ?, ?, ?, ?)
          `).run(interaction.guild.id, pollId, interaction.user.id, optIdx, now);
          msg = `Recorded your vote for **${options[optIdx]}**.`;
        }

        // Tally all votes
        const votes = sdb.prepare('SELECT option_index, COUNT(*) as c FROM poll_votes WHERE guild_id = ? AND poll_id = ? GROUP BY option_index').all(interaction.guild.id, pollId);
        const voteCounts = options.map((_, i) => votes.find(v => v.option_index === i)?.c || 0);
        const total = voteCounts.reduce((a, b) => a + b, 0);

        sdb.prepare('UPDATE polls SET updated_at = ? WHERE id = ?').run(now, pollId);

        return { closed: false, msg, voteCounts, total };
      });

      const res = voteTx();

      if (res.closed) {
        await interaction.reply({ content: 'This poll has ended. Voting is no longer accepted.', flags: MessageFlags.Ephemeral });
        return true;
      }

      // Update message UI live
      try {
        if (interaction.message) {
          const updatedEmbed = renderPollEmbed(poll.id, poll.question, options, res.voteCounts, res.total, 'OPEN', client);
          const updatedRows = buildPollComponents(poll.id, options, false);
          await interaction.message.edit({ embeds: [updatedEmbed], components: updatedRows }).catch(() => null);
        }
      } catch (err) {
        console.warn(`[Poll Interaction] Notice updating poll message: ${err.message}`);
      }

      await interaction.reply({ content: res.msg, flags: MessageFlags.Ephemeral });
      return true;
    }

    return false;
  }
};
