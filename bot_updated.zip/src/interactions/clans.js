/**
 * Tungsten Clans Interaction Router (Node.js)
 * Handles interactive clan invitation decisions and clan disband confirmations.
 * Uses bespoke HQ emojis: <a:tungsten_clan:1569329312774103142> and <a:tungsten_cat_clans:1569329279701884928>
 */
const { MessageFlags } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { createV2Card } = require('../utils/componentsV2');

module.exports = {
  prefixes: ['clan_acc', 'clan_dec', 'clan_disband_cfm', 'clan_disband_cnc', 'clan'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild || !customId) return false;

    // 1. Clan Invitation Accept
    if (customId.startsWith('clan_acc_')) {
      const parts = customId.split('_'); // clan_acc_<clanId>_<targetUserId>
      const clanId = parts[2];
      const targetUserId = parts[3];

      if (interaction.user.id !== targetUserId) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> This invitation was not sent to you.',
          flags: MessageFlags.Ephemeral
        }).catch(() => null);
        return true;
      }

      const db = getServerDb(interaction.guild.id);
      const clan = db.prepare('SELECT * FROM clans WHERE id = ? AND guild_id = ?').get(clanId, interaction.guild.id);
      if (!clan) {
        await interaction.update({
          embeds: [createV2Card({
            title: '<a:tungsten_close:1567234632905138206> Clan Not Found',
            color: 0xED4245,
            description: 'This clan no longer exists.'
          })],
          components: []
        }).catch(() => null);
        return true;
      }

      // Check existing clan membership
      const existing = db.prepare(`
        SELECT c.* FROM clans c
        JOIN clan_members cm ON c.id = cm.clan_id
        WHERE c.guild_id = ? AND cm.user_id = ?
      `).get(interaction.guild.id, targetUserId);

      if (existing) {
        await interaction.update({
          embeds: [createV2Card({
            title: '<a:tungsten_close:1567234632905138206> Invitation Failed',
            color: 0xED4245,
            description: `You are already a member of clan **[${existing.tag}] ${existing.name}**.`
          })],
          components: []
        }).catch(() => null);
        return true;
      }

      // Check capacity
      const countRow = db.prepare('SELECT COUNT(*) as count FROM clan_members WHERE clan_id = ?').get(clanId);
      if (countRow.count >= 50) {
        await interaction.update({
          embeds: [createV2Card({
            title: '<a:tungsten_close:1567234632905138206> Clan Full',
            color: 0xED4245,
            description: `Clan **[${clan.tag}] ${clan.name}** has reached capacity (50 members).`
          })],
          components: []
        }).catch(() => null);
        return true;
      }

      db.prepare('INSERT INTO clan_members (clan_id, user_id, joined_at) VALUES (?, ?, ?)').run(clanId, targetUserId, Date.now());

      await interaction.update({
        embeds: [createV2Card({
          title: '<a:tungsten_party:1567241769593339988>  Welcome to the Clan!',
          color: 0x57F287,
          description: `<@${targetUserId}> has accepted the invitation and joined **[${clan.tag}] ${clan.name}**!`,
          footerText: 'Tungsten Clans'
        })],
        components: []
      }).catch(() => null);
      return true;
    }

    // 2. Clan Invitation Decline
    if (customId.startsWith('clan_dec_')) {
      const parts = customId.split('_');
      const clanId = parts[2];
      const targetUserId = parts[3];

      if (interaction.user.id !== targetUserId) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> This invitation was not sent to you.',
          flags: MessageFlags.Ephemeral
        }).catch(() => null);
        return true;
      }

      const db = getServerDb(interaction.guild.id);
      const clan = db.prepare('SELECT * FROM clans WHERE id = ? AND guild_id = ?').get(clanId, interaction.guild.id);
      const clanName = clan ? `[${clan.tag}] ${clan.name}` : 'the clan';

      await interaction.update({
        embeds: [createV2Card({
          title: '<a:tungsten_heart_broken:1567240285053001738>  Invitation Declined',
          color: 0xED4245,
          description: `<@${targetUserId}> declined the invitation to join **${clanName}**.`,
          footerText: 'Tungsten Clans'
        })],
        components: []
      }).catch(() => null);
      return true;
    }

    // 3. Clan Disband Confirmation
    if (customId.startsWith('clan_disband_cfm_')) {
      const clanId = customId.split('_')[3];
      const db = getServerDb(interaction.guild.id);
      const clan = db.prepare('SELECT * FROM clans WHERE id = ? AND guild_id = ?').get(clanId, interaction.guild.id);

      if (!clan) {
        await interaction.update({
          embeds: [createV2Card({
            title: '<a:tungsten_close:1567234632905138206> Clan Not Found',
            color: 0xED4245,
            description: 'This clan no longer exists.'
          })],
          components: []
        }).catch(() => null);
        return true;
      }

      if (interaction.user.id !== clan.leader_id) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can confirm disbanding the clan.',
          flags: MessageFlags.Ephemeral
        }).catch(() => null);
        return true;
      }

      db.prepare('DELETE FROM clan_members WHERE clan_id = ?').run(clanId);
      db.prepare('DELETE FROM clan_wars WHERE challenger_id = ? OR defender_id = ?').run(clanId, clanId);
      db.prepare('DELETE FROM clans WHERE id = ?').run(clanId);

      await interaction.update({
        embeds: [createV2Card({
          title: '<a:tungsten_explosion:1567238834343911554>  Clan Disbanded',
          color: 0xED4245,
          description: `Clan **[${clan.tag}] ${clan.name}** has been permanently dissolved.`,
          footerText: 'Tungsten Clans'
        })],
        components: []
      }).catch(() => null);
      return true;
    }

    // 4. Clan Disband Cancellation
    if (customId.startsWith('clan_disband_cnc_')) {
      const clanId = customId.split('_')[3];
      const db = getServerDb(interaction.guild.id);
      const clan = db.prepare('SELECT * FROM clans WHERE id = ? AND guild_id = ?').get(clanId, interaction.guild.id);

      if (clan && interaction.user.id !== clan.leader_id) {
        await interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can cancel disbanding.',
          flags: MessageFlags.Ephemeral
        }).catch(() => null);
        return true;
      }

      await interaction.update({
        embeds: [createV2Card({
          title: '<a:tungsten_clan:1569329312774103142>  Disband Canceled',
          color: 0x57F287,
          description: `Clan disbanding has been canceled. Long live **[${clan ? clan.tag : ''}] ${clan ? clan.name : 'the clan'}**!`,
          footerText: 'Tungsten Clans'
        })],
        components: []
      }).catch(() => null);
      return true;
    }

    return false;
  }
};
