const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { createEmbed, hasPerm } = require('../utils/tools');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefixes: ['apply', 'app'],
  async handle(interaction, client) {
    const { customId, guild, user, member } = interaction;
    if (!guild) return false;

    const sdb = getServerDb(guild.id);

    // 1. Open Application Questionnaire Modal
    if (customId === 'apply:open') {
      const modal = new ModalBuilder()
        .setCustomId('apply:submit')
        .setTitle('Staff Application Questionnaire');

      const q1 = new TextInputBuilder()
        .setCustomId('q1')
        .setLabel('Why do you want to join our staff team?')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMaxLength(500);

      const q2 = new TextInputBuilder()
        .setCustomId('q2')
        .setLabel('What moderation experience do you have?')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMaxLength(500);

      const q3 = new TextInputBuilder()
        .setCustomId('q3')
        .setLabel('How many hours weekly can you contribute?')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(50);

      modal.addComponents(
        new ActionRowBuilder().addComponents(q1),
        new ActionRowBuilder().addComponents(q2),
        new ActionRowBuilder().addComponents(q3)
      );

      await interaction.showModal(modal);
      return true;
    }

    // 2. Process Submitted Application Modal
    if (interaction.isModalSubmit() && customId === 'apply:submit') {
      const q1 = interaction.fields.getTextInputValue('q1');
      const q2 = interaction.fields.getTextInputValue('q2');
      const q3 = interaction.fields.getTextInputValue('q3');

      const answers = {
        'Why join staff?': q1,
        'Experience': q2,
        'Weekly Hours': q3
      };

      const now = Math.floor(Date.now() / 1000);
      const res = sdb.prepare(`
        INSERT INTO applications_submissions (guild_id, user_id, answers_json, status, created_at)
        VALUES (?, ?, ?, 'pending', ?)
      `).run(guild.id, user.id, JSON.stringify(answers), now);

      const subId = res.lastInsertRowid;

      await interaction.reply({
        content: '<a:tungsten_success:1567242523468890274> Your staff application has been submitted successfully! The administration team will review it soon.',
        flags: 64
      });

      // Dispatch review card to log channel
      const cfg = sdb.prepare('SELECT log_channel_id FROM applications_config WHERE guild_id = ?').get(guild.id);
      if (cfg?.log_channel_id) {
        const logCh = guild.channels?.cache?.get(cfg.log_channel_id)
          || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(cfg.log_channel_id).catch(() => null) : null);

        if (logCh && logCh.isTextBased && logCh.isTextBased()) {
          const reviewEmbed = createEmbed({
            title: `${EMOJIS.DOCUMENT} New Staff Application #${subId}`,
            description: `**Applicant:** <@${user.id}> (${user.tag})\n**Submitted:** <t:${now}:R>`,
            thumbnail: { url: user.displayAvatarURL() },
            fields: [
              { name: '1. Why join our staff?', value: q1 },
              { name: '2. Previous Experience', value: q2 },
              { name: '3. Weekly Availability', value: q3 }
            ],
            color: 0xFEE75C,
            footer: { text: `Submission ID: ${subId} • Tungsten Applications` }
          });

          const actionRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(`app:accept:${subId}`)
              .setLabel('Accept Application')
              .setStyle(ButtonStyle.Success)
              .setEmoji('<a:tungsten_success:1567242523468890274>'),
            new ButtonBuilder()
              .setCustomId(`app:deny:${subId}`)
              .setLabel('Deny Application')
              .setStyle(ButtonStyle.Danger)
              .setEmoji('<a:tungsten_close:1567234632905138206>')
          );

          await logCh.send({ embeds: [reviewEmbed], components: [actionRow] }).catch(() => null);
        }
      }
      return true;
    }

    // 3. Admin Decision: Accept Application
    if (customId.startsWith('app:accept:')) {
      if (!hasPerm(member, PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Only Administrators can review staff applications.', flags: 64 });
      }

      const subId = customId.split(':')[2];
      sdb.prepare('UPDATE applications_submissions SET status = "accepted", reviewer_id = ? WHERE id = ?').run(user.id, subId);

      const sub = sdb.prepare('SELECT user_id FROM applications_submissions WHERE id = ?').get(subId);
      if (sub?.user_id) {
        const applicant = await client.users.fetch(sub.user_id).catch(() => null);
        if (applicant) {
          applicant.send(`${EMOJIS.SUCCESS} Congratulations! Your staff application in **${guild.name}** has been **Accepted** by <@${user.id}>.`).catch(() => null);
        }
      }

      const updatedEmbed = createEmbed({
        title: `<a:tungsten_success:1567242523468890274> Staff Application #${subId} Accepted`,
        description: `This application was reviewed and **Accepted** by <@${user.id}>.`,
        color: 0x57F287
      });

      await interaction.update({ embeds: [updatedEmbed], components: [] });
      return true;
    }

    // 4. Admin Decision: Deny Application
    if (customId.startsWith('app:deny:')) {
      if (!hasPerm(member, PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Only Administrators can review staff applications.', flags: 64 });
      }

      const subId = customId.split(':')[2];
      sdb.prepare('UPDATE applications_submissions SET status = "denied", reviewer_id = ? WHERE id = ?').run(user.id, subId);

      const sub = sdb.prepare('SELECT user_id FROM applications_submissions WHERE id = ?').get(subId);
      if (sub?.user_id) {
        const applicant = await client.users.fetch(sub.user_id).catch(() => null);
        if (applicant) {
          applicant.send(`<a:tungsten_info:1567240890748248084> Your staff application in **${guild.name}** was reviewed and has been **Denied**.`).catch(() => null);
        }
      }

      const updatedEmbed = createEmbed({
        title: `<a:tungsten_close:1567234632905138206> Staff Application #${subId} Denied`,
        description: `This application was reviewed and **Denied** by <@${user.id}>.`,
        color: 0xED4245
      });

      await interaction.update({ embeds: [updatedEmbed], components: [] });
      return true;
    }

    return false;
  }
};
