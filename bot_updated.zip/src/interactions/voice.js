/**
 * Voice & J2C Control Center Interaction Router (Node.js)
 */
const {
  MessageFlags,
  PermissionsBitField,
  PermissionFlagsBits,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { getConfig, isExtraOwner, hasPerm } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { buildVoiceStudioPayload } = require('../commands/media/voice');
const { buildHomeVcPanel, buildAdvancedVcStatusPanel } = require('../commands/media/vcstatuspanel');
const { replaceEmojis } = require('../utils/emojis');

module.exports = {
  prefixes: ['vc', 'homevc', 'vcs', 'homevc_refresh', 'homevc_disconnect'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    // ─────────────────────────────────────────────────────────────
    // Advanced VC Status Control Panel Interactive Actions (vcs:*)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('vcs:')) {
      const parts = customId.split(':');
      const action = parts[1];

      // Robust target channel and ID resolution
      let resolvedChannelId = parts[2];
      if (!resolvedChannelId) {
        const footerText = interaction.message?.embeds?.[0]?.footer?.text;
        if (footerText) {
          const match = footerText.match(/Channel ID:\s*(\d{17,20})/);
          if (match) resolvedChannelId = match[1];
        }
      }
      if (!resolvedChannelId && interaction.member?.voice?.channelId) {
        resolvedChannelId = interaction.member.voice.channelId;
      }
      if (!resolvedChannelId) {
        try {
          const sdb = getServerDb(interaction.guild.id);
          const row = sdb.prepare('SELECT channel_id FROM home_voice_channels WHERE guild_id = ?').get(interaction.guild.id);
          if (row?.channel_id) resolvedChannelId = row.channel_id;
        } catch (_) {}
      }

      let targetChannel = resolvedChannelId ? interaction.guild.channels.cache.get(resolvedChannelId) : (interaction.member?.voice?.channel || null);
      if (!targetChannel && resolvedChannelId) {
        targetChannel = await interaction.guild.channels.fetch(resolvedChannelId).catch(() => null);
      }
      if (!targetChannel) {
        targetChannel = interaction.guild.channels.cache.find(c => c.isVoiceBased?.() || c.type === 2) || null;
      }
      if (targetChannel && !resolvedChannelId) {
        resolvedChannelId = targetChannel.id;
      }

      const guildConfig = getConfig(interaction.guild.id);
      const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

      const canManage = interaction.member?.permissions?.has(PermissionsBitField.Flags.ManageChannels) ||
                        interaction.user.id === interaction.guild.ownerId ||
                        isExtraOwner(interaction.guild.id, interaction.user.id);

      // A. Modal Submissions
      if (interaction.isModalSubmit()) {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to modify voice status.',
            flags: MessageFlags.Ephemeral
          });
        }

        if (action === 'modal_status') {
          const rawStatus = (interaction.fields.getTextInputValue('status_text') || interaction.fields.getTextInputValue('status_input') || '').trim();
          const statusText = replaceEmojis(interaction.guild, rawStatus);
          if (resolvedChannelId) {
            try {
              if (typeof client.rest?.put === 'function') {
                await client.rest.put(`/channels/${resolvedChannelId}/voice-status`, {
                  body: { status: statusText }
                });
              }
            } catch (e) {
              if (targetChannel && typeof targetChannel.setTopic === 'function') {
                await targetChannel.setTopic(statusText).catch(() => null);
              }
            }

            if (targetChannel) {
              try { targetChannel.status = statusText; } catch (_) {}
            }

            try {
              const sdb = getServerDb(interaction.guild.id);
              const exists = sdb.prepare('SELECT 1 FROM home_voice_channels WHERE guild_id = ?').get(interaction.guild.id);
              if (exists) {
                sdb.prepare("UPDATE home_voice_channels SET status_text = ?, updated_at = strftime('%s', 'now') WHERE guild_id = ?").run(statusText, interaction.guild.id);
              }
            } catch (_) {}
          }

          const panel = buildAdvancedVcStatusPanel(interaction.guild, targetChannel, client, prefix);
          try {
            await interaction.update(panel);
          } catch (_) {
            await interaction.reply({ content: `<a:tungsten_success:1567242523468890274> Voice status updated: **${statusText}**`, flags: MessageFlags.Ephemeral });
          }
          return true;
        }

        if (action === 'modal_limit') {
          const rawLimit = interaction.fields.getTextInputValue('user_limit') || interaction.fields.getTextInputValue('limit_input') || '0';
          const limit = Math.min(Math.max(parseInt(rawLimit, 10) || 0, 0), 99);
          if (targetChannel && typeof targetChannel.setUserLimit === 'function') {
            await targetChannel.setUserLimit(limit).catch(() => null);
          }

          const panel = buildAdvancedVcStatusPanel(interaction.guild, targetChannel, client, prefix);
          try {
            await interaction.update(panel);
          } catch (_) {
            await interaction.reply({ content: `<a:tungsten_success:1567242523468890274> User limit set to: **${limit > 0 ? limit : 'Unlimited'}**`, flags: MessageFlags.Ephemeral });
          }
          return true;
        }
      }

      // B. Buttons that open Modals
      if (action === 'set_status') {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to set voice status text.',
            flags: MessageFlags.Ephemeral
          });
        }

        const modal = new ModalBuilder()
          .setCustomId(`vcs:modal_status:${resolvedChannelId || ''}`)
          .setTitle('Set Voice Channel Status');

        const input = new TextInputBuilder()
          .setCustomId('status_text')
          .setLabel('Voice Status Text')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('e.g. Gaming Lounge • Chill Vibes')
          .setMaxLength(500)
          .setRequired(true);

        const currentStatus = (targetChannel && (targetChannel.status || targetChannel.topic)) || '';
        if (currentStatus) {
          input.setValue(currentStatus.slice(0, 500));
        }

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);
        return true;
      }

      if (action === 'set_limit') {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to adjust user limits.',
            flags: MessageFlags.Ephemeral
          });
        }

        const modal = new ModalBuilder()
          .setCustomId(`vcs:modal_limit:${resolvedChannelId || ''}`)
          .setTitle('Set Channel User Limit');

        const input = new TextInputBuilder()
          .setCustomId('user_limit')
          .setLabel('User Limit (0-99, 0 = Unlimited)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('0')
          .setMaxLength(2)
          .setRequired(true);

        if (targetChannel && typeof targetChannel.userLimit === 'number') {
          input.setValue(String(targetChannel.userLimit));
        }

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);
        return true;
      }

      // C. Action: Clear Status Text
      if (action === 'clear_status') {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to clear voice status.',
            flags: MessageFlags.Ephemeral
          });
        }

        if (resolvedChannelId) {
          try {
            if (typeof client.rest?.put === 'function') {
              await client.rest.put(`/channels/${resolvedChannelId}/voice-status`, {
                body: { status: '' }
              });
            }
          } catch (e) {
            if (targetChannel && typeof targetChannel.setTopic === 'function') {
              await targetChannel.setTopic('').catch(() => null);
            }
          }

          try {
            const sdb = getServerDb(interaction.guild.id);
            sdb.prepare("UPDATE home_voice_channels SET status_text = '', updated_at = strftime('%s', 'now') WHERE guild_id = ?").run(interaction.guild.id);
          } catch (_) {}
        }

        const panel = buildAdvancedVcStatusPanel(interaction.guild, targetChannel, client, prefix);
        await interaction.update(panel).catch(() => null);
        return true;
      }

      // D. Action: Toggle Lock
      if (action === 'toggle_lock') {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to lock/unlock voice channels.',
            flags: MessageFlags.Ephemeral
          });
        }

        if (targetChannel) {
          const everyoneOverwrite = targetChannel.permissionOverwrites?.cache?.get(interaction.guild.roles.everyone.id);
          const isLocked = Boolean(everyoneOverwrite && everyoneOverwrite.deny.has(PermissionFlagsBits.Connect));
          try {
            await targetChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
              Connect: isLocked ? null : false
            }, { reason: `[VC Status] VC ${isLocked ? 'unlocked' : 'locked'} by ${interaction.user.tag}` });
          } catch (err) {
            return interaction.reply({
              content: `<a:tungsten_close:1567234632905138206> Failed to modify permissions: ${err.message}`,
              flags: MessageFlags.Ephemeral
            });
          }
        }

        const panel = buildAdvancedVcStatusPanel(interaction.guild, targetChannel, client, prefix);
        await interaction.update(panel).catch(() => null);
        return true;
      }

      // Action: Choose VC
      if (action === 'choose_vc') {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to switch voice channels.',
            flags: MessageFlags.Ephemeral
          });
        }

        const { ChannelSelectMenuBuilder, ChannelType } = require('discord.js');
        const selectRow = new ActionRowBuilder().addComponents(
          new ChannelSelectMenuBuilder()
            .setCustomId('vcs:select_channel')
            .setPlaceholder('🎙️ Choose Voice Channel to manage...')
            .setChannelTypes([ChannelType.GuildVoice, ChannelType.GuildStageVoice])
        );

        return interaction.reply({
          content: '🎙️ **Choose Target Voice Channel**\nSelect the voice channel in which you want to put the status and manage:',
          components: [selectRow],
          flags: MessageFlags.Ephemeral
        });
      }

      // Action: Select Channel
      if (action === 'select_channel') {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to configure voice channels.',
            flags: MessageFlags.Ephemeral
          });
        }

        const selectedId = interaction.values?.[0];
        let selectedChannel = selectedId ? interaction.guild.channels.cache.get(selectedId) : null;
        if (!selectedChannel && selectedId) {
          selectedChannel = await interaction.guild.channels.fetch(selectedId).catch(() => null);
        }

        const panel = buildAdvancedVcStatusPanel(interaction.guild, selectedChannel, client, prefix);
        if (interaction.isChannelSelectMenu && interaction.isChannelSelectMenu()) {
          await interaction.reply({ content: `<a:tungsten_success:1567242523468890274> Switched active panel target to ${selectedChannel || selectedId}.`, ...panel });
        } else {
          await interaction.update(panel).catch(async () => {
            await interaction.reply({ content: `<a:tungsten_success:1567242523468890274> Switched active panel target to ${selectedChannel || selectedId}.`, ...panel });
          });
        }
        return true;
      }

      // E. Action: Select Bitrate
      if (action === 'select_bitrate') {
        if (!canManage) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to modify audio bitrate.',
            flags: MessageFlags.Ephemeral
          });
        }

        const bitrateVal = parseInt(interaction.values?.[0], 10);
        if (targetChannel && bitrateVal && typeof targetChannel.setBitrate === 'function') {
          try {
            await targetChannel.setBitrate(bitrateVal, `[VC Status] Bitrate set by ${interaction.user.tag}`);
          } catch (err) {
            return interaction.reply({
              content: `<a:tungsten_warn:1567246685082746940> Could not set bitrate to ${bitrateVal / 1000} kbps: ${err.message}. Server boost tier may limit maximum bitrate.`,
              flags: MessageFlags.Ephemeral
            });
          }
        }

        const panel = buildAdvancedVcStatusPanel(interaction.guild, targetChannel, client, prefix);
        await interaction.update(panel).catch(() => null);
        return true;
      }

      // F. Action: Refresh
      if (action === 'refresh') {
        const panel = buildAdvancedVcStatusPanel(interaction.guild, targetChannel, client, prefix);
        await interaction.update(panel).catch(() => null);
        return true;
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 24/7 Home Voice Channel Interactive Actions (homevc:*, homevc_*)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('homevc:') || customId.startsWith('homevc_')) {
      if (!interaction.member?.permissions?.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to manage 24/7 Voice.',
          flags: MessageFlags.Ephemeral
        });
      }

      await interaction.deferUpdate().catch(() => null);
      const sdb = getServerDb(interaction.guild.id);

      if (customId === 'homevc_disconnect' || customId === 'homevc:disconnect') {
        try {
          interaction.guild.shard.send({
            op: 4,
            d: { guild_id: interaction.guild.id, channel_id: null, self_mute: false, self_deaf: false }
          });
        } catch (e) {}
        sdb.prepare('DELETE FROM home_voice_channels WHERE guild_id = ?').run(interaction.guild.id);
      } else if (customId === 'homevc:reconnect') {
        const row = sdb.prepare('SELECT channel_id FROM home_voice_channels WHERE guild_id = ?').get(interaction.guild.id);
        if (row && interaction.guild.shard) {
          try {
            interaction.guild.shard.send({
              op: 4,
              d: { guild_id: interaction.guild.id, channel_id: row.channel_id, self_mute: false, self_deaf: true }
            });
          } catch (e) {}
        }
      }

      const guildConfig = getConfig(interaction.guild.id);
      const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';
      const panel = buildHomeVcPanel(interaction.guild, client, prefix);
      return await interaction.editReply(panel).catch(() => null);
    }

    // ─────────────────────────────────────────────────────────────
    // Voice & J2C Control Center Interactive Actions (vc:*)
    // ─────────────────────────────────────────────────────────────
    if (customId.startsWith('vc:')) {
      const guildConfig = getConfig(interaction.guild.id);
      const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

      // 1. Refresh Voice Studio
      if (customId === 'vc:refresh') {
        let roleTitle = null;
        const inVc = Boolean(interaction.member?.voice?.channelId || interaction.member?.voice?.channel);
        if (inVc) {
          if (interaction.user.id === interaction.guild.ownerId) {
            roleTitle = 'Server Owner';
          } else if (isExtraOwner(interaction.guild.id, interaction.user.id)) {
            roleTitle = 'Extra Owner';
          }
        }
        const payload = buildVoiceStudioPayload(interaction.guild, interaction.member, prefix, roleTitle ? { roleTitle } : {});
        try {
          await interaction.update(payload);
        } catch (e) {
          await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
        }
        return true;
      }

      const userVoice = interaction.member?.voice?.channel;
      if (!userVoice) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to use these room controls.',
          flags: MessageFlags.Ephemeral
        });
      }

      // Enforce room ownership or ManageChannels permission
      let canManageVoice = false;
      if (interaction.user.id === interaction.guild.ownerId || isExtraOwner(interaction.guild.id, interaction.user.id)) {
        canManageVoice = true;
      } else if (interaction.member?.permissions?.has(PermissionsBitField.Flags.ManageChannels)) {
        canManageVoice = true;
      } else {
        try {
          const sdb = getServerDb(interaction.guild.id);
          const room = sdb.prepare('SELECT 1 FROM voice_rooms WHERE channel_id = ? AND owner_id = ?').get(userVoice.id, interaction.user.id);
          if (room) canManageVoice = true;
        } catch (e) {}
      }

      if (!canManageVoice && ['vc:lock', 'vc:unlock', 'vc:hide', 'vc:unhide'].includes(customId)) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You must be the owner of this voice room or hold `Manage Channels` permission to modify room privacy.',
          flags: MessageFlags.Ephemeral
        });
      }

      // 2. Lock VC
      if (customId === 'vc:lock') {
        try {
          await userVoice.permissionOverwrites.edit(interaction.guild.roles.everyone, {
            Connect: false
          });
          return interaction.reply({ content: `<a:tungsten_lock:1567241079030550668> **${userVoice.name}** has been locked for everyone else.`, flags: MessageFlags.Ephemeral });
        } catch (err) {
          return interaction.reply({ content: `<a:tungsten_close:1567234632905138206> Failed to lock VC: ${err.message}`, flags: MessageFlags.Ephemeral });
        }
      }

      // 3. Unlock VC
      if (customId === 'vc:unlock') {
        try {
          await userVoice.permissionOverwrites.edit(interaction.guild.roles.everyone, {
            Connect: null
          });
          return interaction.reply({ content: `<a:tungsten_unlock:1567246515209117968> **${userVoice.name}** has been unlocked.`, flags: MessageFlags.Ephemeral });
        } catch (err) {
          return interaction.reply({ content: `<a:tungsten_close:1567234632905138206> Failed to unlock VC: ${err.message}`, flags: MessageFlags.Ephemeral });
        }
      }

      // 4. Hide VC
      if (customId === 'vc:hide') {
        try {
          await userVoice.permissionOverwrites.edit(interaction.guild.roles.everyone, {
            ViewChannel: false
          });
          return interaction.reply({ content: `<a:tungsten_ghost:1567240021692518512> **${userVoice.name}** is now hidden from public view.`, flags: MessageFlags.Ephemeral });
        } catch (err) {
          return interaction.reply({ content: `<a:tungsten_close:1567234632905138206> Failed to hide VC: ${err.message}`, flags: MessageFlags.Ephemeral });
        }
      }

      // 5. Unhide VC
      if (customId === 'vc:unhide') {
        try {
          await userVoice.permissionOverwrites.edit(interaction.guild.roles.everyone, {
            ViewChannel: null
          });
          return interaction.reply({ content: `<a:tungsten_eye:1567238862042833088> **${userVoice.name}** is now visible to everyone.`, flags: MessageFlags.Ephemeral });
        } catch (err) {
          return interaction.reply({ content: `<a:tungsten_close:1567234632905138206> Failed to unhide VC: ${err.message}`, flags: MessageFlags.Ephemeral });
        }
      }

      // 6. Mute All
      if (customId === 'vc:muteall') {
        const canMute = hasPerm(interaction.member, 'MuteMembers') || isExtraOwner(interaction.guild.id, interaction.user.id);
        if (!canMute) {
          return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Mute Members` permission to mute all in VC.', flags: MessageFlags.Ephemeral });
        }
        let count = 0;
        for (const member of userVoice.members.values()) {
          if (member.id !== client.user.id && member.id !== interaction.user.id) {
            try {
              await member.voice.setMute(true, `[Voice Studio] Mute All by ${interaction.user.tag}`);
              count++;
            } catch (e) {}
          }
        }
        return interaction.reply({ content: `<a:tungsten_mute:1567241451992121647> Server-muted **${count} members** in ${userVoice}.`, flags: MessageFlags.Ephemeral });
      }

      // 7. Unmute All
      if (customId === 'vc:unmuteall') {
        const canMute = hasPerm(interaction.member, 'MuteMembers') || isExtraOwner(interaction.guild.id, interaction.user.id);
        if (!canMute) {
          return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Mute Members` permission to unmute all in VC.', flags: MessageFlags.Ephemeral });
        }
        let count = 0;
        for (const member of userVoice.members.values()) {
          if (member.id !== client.user.id) {
            try {
              await member.voice.setMute(false, `[Voice Studio] Unmute All by ${interaction.user.tag}`);
              count++;
            } catch (e) {}
          }
        }
        return interaction.reply({ content: `<a:tungsten_sound:1567242242127568958> Server-unmuted **${count} members** in ${userVoice}.`, flags: MessageFlags.Ephemeral });
      }

      return true;
    }

    return false;
  }
};
