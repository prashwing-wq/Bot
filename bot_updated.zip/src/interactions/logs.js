/**
 * Logs Interaction Router (Node.js)
 * Handles interactive components on the Log Routing Matrix panel,
 * including 22-channel and 6-channel auto-provisioning, deletion confirmation,
 * matrix inspection, and manual channel allocation.
 */
const {
  PermissionsBitField,
  MessageFlags,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const { hasPerm } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const {
  buildLogsPanelPayload,
  buildLogsMatrixPayload,
  buildLogsManualAllocatorPayload
} = require('../commands/logging/logs');
const { createV2Card } = require('../utils/componentsV2');

module.exports = {
  prefix: 'logs',

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!customId.startsWith('logs:')) return false;

    if (!interaction.guild) {
      await interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> Can only be used in a server.',
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    if (!hasPerm(interaction.member, PermissionsBitField.Flags.ManageGuild)) {
      await interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure log routing.',
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    const parts = customId.split(':');
    const action = parts[1];
    const sdb = getServerDb(interaction.guild.id);

    // Auto-provision 22 comprehensive channels
    if (action === 'auto_all') {
      await interaction.deferUpdate().catch(() => {});
      const { autoProvisionAllLogChannels } = require('../utils/autoLogging');
      const res = await autoProvisionAllLogChannels(interaction.guild, sdb, 'all');
      const payload = buildLogsPanelPayload(interaction.guild);
      const card = createV2Card({
        color: undefined,
        title: '✨ 22-Channel Comprehensive Logging Active',
        description:
          res.success
            ? `<a:tungsten_success:1567242523468890274> **All 22 dedicated log channels have been successfully created and configured with initial announcements!**\n\n` +
              `• Newly created channels: **${res.newlyCreatedCount}**\n` +
              `• Click **22-Channel Matrix** to view all active routes.`
            : `<a:tungsten_close:1567234632905138206> Auto-provisioning failed: ${res.error || 'Unknown error'}`,
        footerText: 'Tungsten Auto-Logging Engine'
      });
      payload.embeds = [card];
      payload.content = res.success
        ? '<a:tungsten_success:1567242523468890274> **All 22 comprehensive log channels have been automatically created and configured with initial announcements!**'
        : `<a:tungsten_close:1567234632905138206> Auto-provisioning failed: ${res.error}`;

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Auto-provision essential 6 standard channels (auto_standard or legacy auto_setup)
    if (action === 'auto_standard' || action === 'auto_setup') {
      await interaction.deferUpdate().catch(() => {});
      const { autoProvisionAllLogChannels } = require('../utils/autoLogging');
      const res = await autoProvisionAllLogChannels(interaction.guild, sdb, 'standard');
      const payload = buildLogsPanelPayload(interaction.guild);
      const card = createV2Card({
        color: undefined,
        title: '📦 Essential 6-Channel Logging Active',
        description:
          res.success
            ? `<a:tungsten_success:1567242523468890274> **All designated log channels have been automatically created and configured with initial announcements!**\n\n` +
              `• Newly created channels: **${res.newlyCreatedCount}**\n` +
              `• Essential logging channels are ready and active.`
            : `<a:tungsten_close:1567234632905138206> Auto-provisioning failed: ${res.error || 'Unknown error'}`,
        footerText: 'Tungsten Auto-Logging Engine'
      });
      payload.embeds = [card];
      if (res.success) {
        payload.content = '<a:tungsten_success:1567242523468890274> **All designated log channels have been automatically created and configured with initial announcements!**';
      } else {
        payload.content = `<a:tungsten_close:1567234632905138206> Auto-provisioning failed: ${res.error}`;
      }
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Prompt danger confirmation card before deleting all log channels
    if (action === 'confirm_delete') {
      const card = createV2Card({
        color: undefined,
        title: '⚠️ Confirm Deletion of All Log Channels',
        description:
          '⚠️ **Confirm Deletion of All Log Channels**\n' +
          'This will permanently delete all provisioned log channels and the `SERVER LOGS` category from Discord, and reset all logging routes.\n\n' +
          '*This action cannot be undone. Are you sure you wish to proceed?*',
        footerText: 'Tungsten Log Management'
      });

      const buttonRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`logs:execute_delete:${interaction.guild.id}`)
          .setLabel('Confirm Delete All Channels')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('🔴'),
        new ButtonBuilder()
          .setCustomId(`logs:cancel_delete:${interaction.guild.id}`)
          .setLabel('Cancel')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('✖️')
      );

      const payload = { embeds: [card], components: [buttonRow] };
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Execute deletion of all log channels and clean database routes
    if (action === 'execute_delete') {
      await interaction.deferUpdate().catch(() => {});
      const { deleteAllLogChannels } = require('../utils/autoLogging');
      const res = await deleteAllLogChannels(interaction.guild, sdb);
      const panelPayload = buildLogsPanelPayload(interaction.guild);
      const card = createV2Card({
        color: undefined,
        title: '🗑️ Log Channels Deleted',
        description:
          res.success
            ? `<a:tungsten_success:1567242523468890274> **Successfully deleted ${res.deletedCount || 0} log channels and removed the \`SERVER LOGS\` category!**\n\n` +
              `All log routing settings have been reset. You can auto-provision channels at any time using the buttons below.`
            : `<a:tungsten_close:1567234632905138206> Failed to delete log channels: ${res.error || 'Unknown error'}`,
        footerText: 'Tungsten Log Management'
      });
      const payload = { embeds: [card], components: panelPayload.components };
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Cancel deletion or back to main panel
    if (action === 'cancel_delete' || action === 'back_to_panel') {
      const payload = buildLogsPanelPayload(interaction.guild);
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Display 22-channel matrix
    if (action === 'matrix') {
      const payload = buildLogsMatrixPayload(interaction.guild);
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Display manual allocator menu
    if (action === 'manual_menu') {
      const payload = buildLogsManualAllocatorPayload(interaction.guild);
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Refresh panel
    if (action === 'refresh') {
      const payload = buildLogsPanelPayload(interaction.guild);
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Reset all specific routes to master fallback
    if (action === 'reset_all') {
      sdb.prepare(
        "DELETE FROM server_settings WHERE key IN ('log_messages', 'log_members', 'log_voice', 'log_server', 'log_mod')"
      ).run();
      const payload = buildLogsPanelPayload(interaction.guild);
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.update(payload);
      }
      return true;
    }

    // Select category dropdown guidance
    if (action === 'select_category') {
      const selected = interaction.values?.[0];
      if (!selected) return true;

      const LABELS = {
        audit_log_channel: 'Master Fallback Channel',
        log_mod: 'Moderation Actions & Cases',
        log_bans: 'Ban & Unban Sentinel',
        log_timeouts: 'Member Timeout & Restraints',
        log_nicknames: 'Member Nickname & Display Updates',
        log_messages: 'Message Events (Edits, Deletions, Purges)',
        log_voice: 'Voice Events (State & Transitions)',
        log_channels: 'Channel Structure & Hierarchy',
        log_roles: 'Role & Permission Logs',
        log_emojis: 'Custom Emoji Logs',
        log_guildupdate: 'Server Configuration Logs',
        log_security: 'Antinuke & Threat Security Logs',
        log_bots: 'Bot Addition & Permission Logs',
        log_webhooks: 'Webhook Management Logs',
        log_secure_wl: 'Security Whitelist Logs',
        log_memberjoin: 'Member Join & Leave Logs',
        log_invites: 'Invite Link & Attribution Logs',
        log_manual: 'Manual Staff Audit Notes',
        log_tickets: 'Ticket Transcripts & Resolution Logs',
        log_quarantine: 'Threat Quarantine Logs',
        log_threads: 'Thread & Forum Logs',
        log_stickers: 'Custom Sticker Logs',
        log_scheduled_events: 'Scheduled Guild Event Logs'
      };

      const shortName = selected.replace('log_', '');
      await interaction.reply({
        content:
          `⚙️ **Configuring ${LABELS[selected] || selected}**\n\n` +
          `• **Target Database Key:** \`${selected}\`\n` +
          `• **Assign channel:** \`!logs set ${shortName} #channel\`\n` +
          `• **Reset to fallback:** \`!logs set ${shortName} off\`\n\n` +
          `*Events for this category will automatically inherit from parent or master fallback if unset.*`,
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    return false;
  }
};
