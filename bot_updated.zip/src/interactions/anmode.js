/**
 * Antinuke Mode Studio Interaction Router (Node.js)
 */
const { MessageFlags } = require('discord.js');
const { getConfig } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');

module.exports = {
  prefixes: ['anmode'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;
    if (!customId.startsWith('anmode:')) return false;

    const isServerOwner = interaction.user.id === interaction.guild.ownerId;
    const sdb = getServerDb(interaction.guild.id);
    const isExtraOwner = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(interaction.guild.id, interaction.user.id);

    if (!isServerOwner && !isExtraOwner) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> Only the **Server Owner** or **Extra Owners** can configure Antinuke Defense Modes.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId === 'anmode:dismiss') {
      try {
        await interaction.deferUpdate().catch(() => null);
        await interaction.message.delete().catch(() => null);
      } catch (e) {}
      return true;
    }

    await interaction.deferUpdate().catch(() => null);
    const anmode = require('../commands/security/anmode');
    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    anmode.setAntinukeMode(interaction.guild.id, 'ULTRA');
    const panel = anmode.buildAnmodePanel(interaction.guild, 'ULTRA', prefix, true);
    await interaction.editReply(panel).catch(() => null);
    return true;
  }
};
