/**
 * Server Doctor Interaction Handler (Node.js)
 * Handles interactive button events for Server Doctor diagnostic re-scans.
 */
const { PermissionFlagsBits } = require('discord.js');
const { hasPerm } = require('../utils/tools');
const { runServerDoctorScan } = require('../commands/utility/serverdoctor');

module.exports = {
  prefixes: ['doctor', 'serverdoctor'],

  async handle(interaction, client) {
    if (!interaction.guild) return false;

    // Gate staff-only action inside interaction handler
    if (!hasPerm(interaction.member, 'ManageGuild')) {
      if (typeof interaction.reply === 'function') {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to trigger diagnostic re-scans.',
          ephemeral: true
        });
      }
      return false;
    }

    const action = interaction.customId.split(':')[1];
    if (action === 'rescan' || action === 'scan' || action === 'refresh') {
      try {
        const { card, buttons } = await runServerDoctorScan(interaction.guild, client, '/');
        await interaction.update({ embeds: [card], components: [buttons] });
        return true;
      } catch (err) {
        console.error('[DoctorInteraction] Re-scan error:', err);
        return interaction.reply({ content: '<a:tungsten_warn:1567246685082746940> Failed to complete diagnostic re-scan.', ephemeral: true }).catch(() => null);
      }
    }

    return false;
  }
};
