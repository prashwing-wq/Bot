/**
 * Tungsten Custom Moderation Interaction Router (Node.js)
 * Modular interaction handler for CM Dashboard, Category Setup & Role Delegations.
 */
const {
  MessageFlags,
  RoleSelectMenuBuilder,
  StringSelectMenuBuilder,
  ActionRowBuilder,
  PermissionsBitField
} = require('discord.js');
const { getConfig } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { buildCMDashboardPayload, provisionCMChannels, CM_ACTIONS, ACTION_META } = require('../commands/moderation/cm');
const { createV2Card } = require('../utils/componentsV2');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefixes: ['cm'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    const sdb = getServerDb(interaction.guild.id);
    const isServerOwner = interaction.user.id === interaction.guild.ownerId;
    const isExtraOwner = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(interaction.guild.id, interaction.user.id));
    const hasAdmin = interaction.member?.permissions?.has(PermissionsBitField.Flags.Administrator);

    if (!isServerOwner && !isExtraOwner && !hasAdmin) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> **Access Denied**: Only the **Server Owner**, **Extra Owners**, or **Administrators** can configure Custom Moderation.',
        flags: MessageFlags.Ephemeral
      });
    }

    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    // 1. Refresh CM Dashboard
    if (customId === 'cm:refresh') {
      const payload = buildCMDashboardPayload(interaction.guild, sdb, prefix, interaction.user.username);
      try {
        await interaction.update(payload);
      } catch (e) {
        await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }
      return true;
    }

    // 2. Setup Category and 17 Channels
    if (customId === 'cm:setup') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        await provisionCMChannels(interaction.guild, sdb);
        const payload = buildCMDashboardPayload(interaction.guild, sdb, prefix, interaction.user.username);
        try {
          await interaction.message.edit(payload);
        } catch (e) {}

        await interaction.editReply({
          content: `<a:tungsten_success:1567242523468890274> **Custom Moderation Setup Complete!**\n• Synchronized **17/17 dedicated log channels** under locked category \`Custom Mods Logs\`.\n• Security: Fully hidden from \`@everyone\`.`
        });
      } catch (err) {
        await interaction.editReply({
          content: `<a:tungsten_close:1567234632905138206> Failed to setup channels: ${err.message}`
        });
      }
      return true;
    }

    // 3. Assign Action Delegation Trigger
    if (customId === 'cm:assign') {
      const selectOptions = CM_ACTIONS.map(act => {
        const meta = ACTION_META[act] || { emoji: EMOJIS.ZAP, desc: act };
        return {
          label: act.toUpperCase(),
          value: act,
          description: meta.desc.slice(0, 100),
          emoji: meta.emoji
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('cm:select_action')
        .setPlaceholder('Select an action to delegate to a role...')
        .addOptions(selectOptions);
      const row = new ActionRowBuilder().addComponents(select);

      await interaction.reply({
        content: 'Select which **Custom Moderation Action** you want to delegate:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 4. Action Selected -> Prompt Role Selection
    if (customId === 'cm:select_action') {
      const action = interaction.values[0];
      const roleSelect = new RoleSelectMenuBuilder()
        .setCustomId(`cm:select_role:${action}`)
        .setPlaceholder(`Select role to delegate ${action.toUpperCase()} to...`)
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(roleSelect);

      await interaction.update({
        content: `Now select which **Role** should be authorized to execute **\`${action.toUpperCase()}\`**:`,
        components: [row]
      });
      return true;
    }

    // 5. Role Selected for Action -> Save Mapping
    if (customId.startsWith('cm:select_role:')) {
      const action = customId.split(':')[2];
      const roleId = interaction.values[0];

      sdb.prepare(`
        INSERT INTO cm_mappings (guild_id, action, target_type, target_id, daily_limit)
        VALUES (?, ?, 'role', ?, 0)
        ON CONFLICT(guild_id, action) DO UPDATE SET
          target_type = 'role',
          target_id = excluded.target_id,
          daily_limit = 0
      `).run(interaction.guild.id, action, roleId);

      const payload = buildCMDashboardPayload(interaction.guild, sdb, prefix, interaction.user.username);
      try {
        await interaction.message.edit(payload);
      } catch (e) {}

      await interaction.update({
        content: `<a:tungsten_success:1567242523468890274> Action **\`${action.toUpperCase()}\`** is now delegated to role <@&${roleId}>!\n*Role members can now execute this command with zero native administrator permissions.*`,
        components: []
      });
      return true;
    }

    // 6. Remove Delegation Trigger
    if (customId === 'cm:remove') {
      const mappings = sdb.prepare('SELECT action, target_type, target_id FROM cm_mappings WHERE guild_id = ?').all(interaction.guild.id);
      if (mappings.length === 0) {
        return interaction.reply({
          content: '<a:tungsten_info:1567240890748248084> No active action delegations found to remove.',
          flags: MessageFlags.Ephemeral
        });
      }

      const selectOptions = mappings.map(m => {
        const meta = ACTION_META[m.action] || { emoji: EMOJIS.ZAP };
        const target = m.target_type === 'role' ? `Role: ${m.target_id}` : `User: ${m.target_id}`;
        return {
          label: m.action.toUpperCase(),
          value: m.action,
          description: target.slice(0, 100),
          emoji: meta.emoji
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('cm:select_remove')
        .setPlaceholder('Select an action delegation to revoke...')
        .addOptions(selectOptions);
      const row = new ActionRowBuilder().addComponents(select);

      await interaction.reply({
        content: 'Select an action delegation to revoke from the server:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 7. Remove Action Selected
    if (customId === 'cm:select_remove') {
      const action = interaction.values[0];
      sdb.prepare('DELETE FROM cm_mappings WHERE guild_id = ? AND action = ?').run(interaction.guild.id, action);

      const payload = buildCMDashboardPayload(interaction.guild, sdb, prefix, interaction.user.username);
      try {
        await interaction.message.edit(payload);
      } catch (e) {}

      await interaction.update({
        content: `<a:tungsten_success:1567242523468890274> Revoked delegation for action **\`${action.toUpperCase()}\`**.\n*Click **Refresh** on the dashboard to view updated roster.*`,
        components: []
      });
      return true;
    }

    // 8. Daily Usage Breakdown
    if (customId === 'cm:usage') {
      const today = new Date().toISOString().slice(0, 10);
      const rows = sdb.prepare('SELECT action, target_id, count FROM cm_usage WHERE guild_id = ? AND usage_date = ?').all(interaction.guild.id, today);

      let usageText = '*No custom moderation actions executed today yet.*';
      if (rows.length > 0) {
        usageText = rows.map(r => {
          const meta = ACTION_META[r.action] || { emoji: EMOJIS.ZAP };
          return `• ${meta.emoji} **\`${r.action.toUpperCase()}\`** — Executed by <@${r.target_id}>: \`${r.count}\` time(s)`;
        }).join('\n');
      }

      const card = createV2Card({
        color: 0x000000,
        title: `${EMOJIS.CHART}  Custom Moderation Usage • Today (${today})`,
        description:
          `> Real-time monitoring of delegated custom moderation actions.\n\n` +
          usageText,
        footerText: `Tungsten CM Analytics • ${interaction.guild.name}`
      });

      await interaction.reply({
        embeds: [card],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 9. Reset Limits
    if (customId === 'cm:reset') {
      const today = new Date().toISOString().slice(0, 10);
      sdb.prepare('DELETE FROM cm_usage WHERE guild_id = ? AND usage_date = ?').run(interaction.guild.id, today);

      const payload = buildCMDashboardPayload(interaction.guild, sdb, prefix, interaction.user.username);
      try {
        await interaction.message.edit(payload);
      } catch (e) {}

      await interaction.reply({
        content: '<a:tungsten_success:1567242523468890274> All Custom Moderation daily counters for today have been reset to zero.',
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    return false;
  }
};
