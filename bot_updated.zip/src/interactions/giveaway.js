/**
 * Giveaway Interaction Handler (Node.js)
 * Implements Join Button entry, requirement verification, and live entry counter.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefixes: ['ga', 'giveaway'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild || !customId) return false;

    const parts = customId.split(':');
    const action = parts[1];
    const messageId = parts[2];

    if (action !== 'join') {
      return false;
    }

    if (!messageId) {
      await interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Invalid giveaway interaction.', ephemeral: true }).catch(() => null);
      return true;
    }

    const sdb = getServerDb(interaction.guild.id);
    const ga = sdb.prepare('SELECT * FROM server_giveaways WHERE message_id = ?').get(messageId);

    if (!ga || ga.ended === 1) {
      await interaction.reply({ content: '<a:tungsten_close:1567234632905138206> This giveaway has already ended.', ephemeral: true }).catch(() => null);
      return true;
    }

    if (ga.paused === 1) {
      await interaction.reply({ content: `${EMOJIS.WARN} This giveaway is currently paused.`, ephemeral: true }).catch(() => null);
      return true;
    }

    // 1. Requirement: Required Role
    if (ga.required_role_id) {
      const hasRequiredRole = interaction.member?.roles?.cache?.has(ga.required_role_id);
      if (!hasRequiredRole) {
        await interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> You do not meet the role requirement for this giveaway. You must have the <@&${ga.required_role_id}> role.`,
          ephemeral: true
        }).catch(() => null);
        return true;
      }
    }

    // 2. Requirement: Minimum Level
    if (ga.min_level && ga.min_level > 0) {
      const userLevelRow = sdb.prepare('SELECT level FROM leveling_users WHERE guild_id = ? AND user_id = ?')
        .get(interaction.guild.id, interaction.user.id);
      const userLevel = userLevelRow ? userLevelRow.level : 0;
      if (userLevel < ga.min_level) {
        await interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> You do not meet the level requirement for this giveaway. Required: **Level ${ga.min_level}** (Your Level: **Level ${userLevel}**).`,
          ephemeral: true
        }).catch(() => null);
        return true;
      }
    }

    // 3. Requirement: Minimum Server Age (Days)
    if (ga.min_server_age && ga.min_server_age > 0) {
      const joinedTs = interaction.member?.joinedTimestamp || Date.now();
      const ageDays = Math.floor((Date.now() - joinedTs) / (1000 * 60 * 60 * 24));
      if (ageDays < ga.min_server_age) {
        await interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> You do not meet the server membership age requirement. Required: **${ga.min_server_age} days** in this server (Current: **${ageDays} days**).`,
          ephemeral: true
        }).catch(() => null);
        return true;
      }
    }

    // Toggle Entry: Check if already entered
    const existingEntry = sdb.prepare('SELECT entered_at FROM server_giveaway_entries WHERE message_id = ? AND user_id = ?')
      .get(messageId, interaction.user.id);

    if (existingEntry) {
      sdb.prepare('DELETE FROM server_giveaway_entries WHERE message_id = ? AND user_id = ?')
        .run(messageId, interaction.user.id);

      const countRow = sdb.prepare('SELECT COUNT(*) as cnt FROM server_giveaway_entries WHERE message_id = ?').get(messageId);
      const entryCount = countRow ? countRow.cnt : 0;

      await interaction.reply({
        content: `${EMOJIS.LOGS || EMOJIS.LEAVE || EMOJIS.TRASH} You have left the giveaway. (Total entries: **${entryCount}**)`,
        ephemeral: true
      }).catch(() => null);

      // Update message button counter
      if (interaction.message && typeof interaction.message.edit === 'function') {
        const updatedRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`ga:join:${messageId}`)
            .setLabel(`Join Giveaway (${entryCount})`)
            .setStyle(ButtonStyle.Primary)
            .setEmoji(EMOJIS.GIVEAWAY)
        );
        interaction.message.edit({ components: [updatedRow] }).catch(() => null);
      }
      return true;
    }

    // Add entry
    sdb.prepare(`
      INSERT INTO server_giveaway_entries (message_id, user_id, entered_at)
      VALUES (?, ?, ?)
    `).run(messageId, interaction.user.id, Math.floor(Date.now() / 1000));

    const countRow = sdb.prepare('SELECT COUNT(*) as cnt FROM server_giveaway_entries WHERE message_id = ?').get(messageId);
    const entryCount = countRow ? countRow.cnt : 1;

    await interaction.reply({
      content: `${EMOJIS.GIVEAWAY} You have successfully entered the giveaway! Good luck! (Total entries: **${entryCount}**)`,
      ephemeral: true
    }).catch(() => null);

    // Update message button counter
    if (interaction.message && typeof interaction.message.edit === 'function') {
      const updatedRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`ga:join:${messageId}`)
          .setLabel(`Join Giveaway (${entryCount})`)
          .setStyle(ButtonStyle.Primary)
          .setEmoji(EMOJIS.GIVEAWAY)
      );
      interaction.message.edit({ components: [updatedRow] }).catch(() => null);
    }

    return true;
  }
};
