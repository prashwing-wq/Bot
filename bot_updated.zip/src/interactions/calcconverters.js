/**
 * Calculators & Converters Interaction Router (Node.js)
 * Handles interactive Controls (dismiss/delete) for Slice 5.2 commands.
 */
const { MessageFlags } = require('discord.js');
const { isOwner } = require('../utils/tools');

module.exports = {
  prefixes: ['calc', 'convert', 'conv', 'base', 'hash'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!customId) return false;

    if (customId.includes(':delete:') || customId.includes(':dismiss:')) {
      const parts = customId.split(':');
      // Format: <prefix>:(delete|dismiss):<authorId>
      const authorId = parts[2] || '';

      const isRequester = authorId && interaction.user.id === authorId;
      const hasStaffPerms = interaction.memberPermissions?.has('ManageMessages') ||
        interaction.member?.permissions?.has?.('ManageMessages');
      const isBotOwner = isOwner(interaction.user.id);

      if (!isRequester && !hasStaffPerms && !isBotOwner) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Only the member who requested this computation or a moderator can dismiss this card.',
          flags: MessageFlags.Ephemeral
        });
      }

      try {
        await interaction.deferUpdate().catch(() => null);
        if (interaction.message && typeof interaction.message.delete === 'function') {
          await interaction.message.delete().catch(async () => {
            await interaction.editReply({ components: [] }).catch(() => null);
          });
        }
      } catch (_) {}

      return true;
    }

    return false;
  }
};
