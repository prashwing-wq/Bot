/**
 * Achievements & Badges Interaction Router (Node.js)
 * Handles interactive buttons on achievements cards and leaderboards.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { EMOJIS } = require('../utils/emojis');
const {
  getUserAchievements,
  getBadgeLeaderboard,
  checkAndAwardAchievements
} = require('../utils/achievementEngine');

module.exports = {
  prefixes: ['ach'],

  async handle(interaction, client) {
    const customId = interaction.customId || '';
    if (!customId.startsWith('ach:')) return false;

    if (!interaction.guild) {
      await interaction.reply({ content: 'Achievements are only available in servers.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const parts = customId.split(':');
    const action = parts[1];
    const targetUserId = parts[2] || interaction.user.id;
    const sdb = getServerDb(interaction.guild.id);

    if (action === 'lb') {
      const topRows = getBadgeLeaderboard(interaction.guild.id, sdb, 10);
      const medals = [EMOJIS.GOLD, EMOJIS.SILVER, EMOJIS.BRONZE];
      const lines = topRows.length > 0
        ? topRows.map((r, i) => `${medals[i] || `\`#${i + 1}\``} <@${r.user_id}> — **${r.badge_count}** badges`)
        : ['*No badges recorded in this server yet.*'];

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`ach:user:${interaction.user.id}`)
          .setLabel('My Badges')
          .setEmoji(EMOJIS.SCROLL)
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('ach:lb')
          .setLabel('Refresh')
          .setEmoji(EMOJIS.REFRESH)
          .setStyle(ButtonStyle.Secondary)
      );

      const embed = createEmbed({
        color: client.config?.COLORS?.GOLD || 0xf1c40f,
        title: `${EMOJIS.TROPHY} ${interaction.guild.name} • Badge Leaderboard`,
        description: lines.join('\n\n'),
        footer: 'Top members with the most badges earned'
      });

      await interaction.update({ embeds: [embed], components: [row] }).catch(() => null);
      return true;
    }

    if (action === 'user' || action === 'refresh') {
      const targetUser = await client.users.fetch(targetUserId).catch(() => interaction.user);
      const targetMember = interaction.guild.members.cache.get(targetUser.id) ||
        await interaction.guild.members.fetch(targetUser.id).catch(() => null);

      if (targetMember) {
        checkAndAwardAchievements(interaction.guild, targetMember, sdb);
      }

      const { earned, locked, totalEarned, totalAvailable } = getUserAchievements(interaction.guild.id, targetUser.id, sdb);

      let earnedSection = '*No achievements earned yet.*';
      if (earned && earned.length > 0) {
        earnedSection = earned.map(a => {
          const timeStr = a.earned_at ? ` <t:${a.earned_at}:R>` : '';
          const tag = a.isCustom ? ' `[Guild Badge]`' : '';
          return `${a.emoji} **${a.name}**${tag}${timeStr}\n-# ${a.description}`;
        }).join('\n\n');
      }

      let lockedSection = '';
      if (locked && locked.length > 0) {
        const lockedNames = locked.map(l => `${l.emoji} ${l.name}`).join(' • ');
        lockedSection = `\n\n<a:tungsten_lock:1567241079030550668> **Locked Achievements (${locked.length}):**\n-# ${lockedNames}`;
      }

      const embed = createEmbed({
        color: client.config?.COLORS?.PRIMARY || 0x5865f2,
        author: {
          name: `${targetUser.username}'s Achievements & Badges`,
          icon_url: targetUser.displayAvatarURL ? targetUser.displayAvatarURL({ dynamic: true }) : null
        },
        title: `${EMOJIS.BADGE} Badges Earned: ${totalEarned} / ${totalAvailable}`,
        description: `${earnedSection}${lockedSection}`,
        footer: `Server: ${interaction.guild.name}`
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ach:lb')
          .setLabel('Leaderboard')
          .setEmoji(EMOJIS.TROPHY)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`ach:refresh:${targetUser.id}`)
          .setLabel('Refresh')
          .setEmoji(EMOJIS.REFRESH)
          .setStyle(ButtonStyle.Primary)
      );

      await interaction.update({ embeds: [embed], components: [row] }).catch(() => null);
      return true;
    }

    return false;
  }
};
