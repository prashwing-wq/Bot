/**
 * Tungsten Extra Owner Interaction Router (Node.js)
 * Modular interaction handler for Extra Owner Studio & Executive Governance.
 */
const {
  MessageFlags,
  UserSelectMenuBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder
} = require('discord.js');
const { getConfig, createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { clearImmunityCache } = require('../utils/antinukeEngine');
const { buildExtraOwnerStudioPayload } = require('../commands/security/extraowner');
const { buildWhitelistStudioPayload } = require('../commands/security/whitelist');
const { buildTargetWhitelistPayload, revokeWhitelistTarget } = require('../utils/whitelistUi');
const { createV2Card } = require('../utils/componentsV2');
const { EMOJIS } = require('../utils/emojis');

async function notifyServerOwner(guild, actionType, targetId, actorId) {
  try {
    const ownerUser = await guild.client.users.fetch(guild.ownerId).catch(() => null);
    if (!ownerUser) return;
    const nowSec = Math.floor(Date.now() / 1000);
    const isAdd = actionType === 'added';
    const isAll = typeof targetId === 'string' && targetId.startsWith('All');
    const embed = createEmbed({
      color: 0x000000,
      title: `${isAdd ? EMOJIS.SUCCESS : EMOJIS.WARN} Extra Owner ${isAdd ? 'Added' : 'Removed'} • ${guild.name}`,
      description:
        `> An Extra Owner status was **${isAdd ? 'granted' : 'revoked'}** in **${guild.name}**.\n\n` +
        `**Target:** ${isAll ? targetId : `<@${targetId}> (\`${targetId}\`)`}\n` +
        `**Action By:** <@${actorId}> (\`${actorId}\`)\n` +
        `**Timestamp:** <t:${nowSec}:F> (<t:${nowSec}:R>)`,
      footerText: 'Tungsten Executive Governance Sentinel'
    });
    await ownerUser.send({ embeds: [embed] }).catch(() => null);
  } catch (_) {}
}

module.exports = {
  prefixes: ['eo'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;

    const sdb = getServerDb(interaction.guild.id);
    const isServerOwner = interaction.user.id === interaction.guild.ownerId;
    const isExtraOwner = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(interaction.guild.id, interaction.user.id));

    if (!isServerOwner && !isExtraOwner) {
      return interaction.reply({
        content: `${EMOJIS.CROSS} **Access Denied**: Only the **Server Owner** or **Extra Owners** can configure Extra Owners.`,
        flags: MessageFlags.Ephemeral
      });
    }

    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    // 1. Refresh Studio
    if (customId === 'eo:refresh') {
      const payload = buildExtraOwnerStudioPayload(interaction.guild, sdb, prefix, interaction.user.username);
      try {
        await interaction.update(payload);
      } catch (e) {
        await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }
      return true;
    }

    // 2. Add Extra Owner Trigger (Only Server Owner / Bot Owner)
    if (customId === 'eo:add') {
      if (!isServerOwner) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} Only the **Primary Server Owner** can add new Extra Owners.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const userSelect = new UserSelectMenuBuilder()
        .setCustomId('eo:select_add_user')
        .setPlaceholder('Select a user to promote to Extra Owner...')
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(userSelect);

      await interaction.reply({
        content: `${EMOJIS.SHIELD} Select a member to grant **Executive Extra Owner Privileges** (Max 10):`,
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 3. User Selected to Add as Extra Owner
    if (customId === 'eo:select_add_user') {
      const targetId = interaction.values[0];
      if (targetId === interaction.guild.ownerId) {
        await interaction.update({ content: `${EMOJIS.CROSS} The Server Owner already holds primary ownership.`, components: [] });
        return true;
      }

      const nowSec = Math.floor(Date.now() / 1000);
      const recentRemoval = sdb.prepare(`
        SELECT timestamp FROM audit_logs
        WHERE target_id = ? AND action IN ('extraowner_remove', 'whitelist_revoke')
        ORDER BY timestamp DESC LIMIT 1
      `).get(targetId);

      if (recentRemoval && (nowSec - Number(recentRemoval.timestamp)) < 86400) {
        const unlockTime = Number(recentRemoval.timestamp) + 86400;
        await interaction.update({
          content: `${EMOJIS.CROSS} **Security Cooldown Active**: <@${targetId}> was recently removed as an Extra Owner. A **24-hour cooldown** is enforced before they can be re-added.\nTry again <t:${unlockTime}:R> (<t:${unlockTime}:F>).`,
          components: []
        });
        return true;
      }

      const count = sdb.prepare('SELECT COUNT(*) as cnt FROM extraowners WHERE guild_id = ?').get(interaction.guild.id).cnt;
      if (count >= 10) {
        await interaction.update({ content: `${EMOJIS.CROSS} Maximum limit of 10 Extra Owners reached for this server.`, components: [] });
        return true;
      }

      sdb.prepare(`
        INSERT OR REPLACE INTO extraowners (guild_id, owner_id, added_at, added_by)
        VALUES (?, ?, ?, ?)
      `).run(interaction.guild.id, targetId, nowSec, interaction.user.id);

      clearImmunityCache(interaction.guild.id);
      await notifyServerOwner(interaction.guild, 'added', targetId, interaction.user.id);

      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'extraowner', targetId, prefix);
      await interaction.update(payload);
      return true;
    }

    // 3b. Manage Extra Owner Trigger
    if (customId === 'eo:manage') {
      const rows = sdb.prepare('SELECT owner_id FROM extraowners WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        return interaction.reply({ content: `${EMOJIS.INFO} No Extra Owners currently assigned to manage. Click **Add Extra Owner** first.`, flags: MessageFlags.Ephemeral });
      }

      const options = rows.map(r => {
        const m = interaction.guild.members?.cache?.get(r.owner_id);
        const name = m ? m.displayName : `User ${r.owner_id}`;
        return {
          label: name.slice(0, 100),
          description: `ID: ${r.owner_id}`,
          value: r.owner_id,
          emoji: '<a:tungsten_crown:1567238355463176334>'
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('eo:select_manage_user')
        .setPlaceholder('Select an Extra Owner to manage...')
        .addOptions(options);
      const row = new ActionRowBuilder().addComponents(select);

      await interaction.reply({
        content: `${EMOJIS.GEAR} Select an Extra Owner to inspect and configure authorization matrix:`,
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 3c. Extra Owner Selected to Manage -> Shows Action Panel
    if (customId === 'eo:select_manage_user') {
      const targetId = interaction.values[0];
      const payload = buildTargetWhitelistPayload(interaction.guild, sdb, 'extraowner', targetId, prefix);
      await interaction.update(payload);
      return true;
    }

    // 3d. Revoke Extra Owner from Action Panel
    if (customId.startsWith('eo:revoke:')) {
      const targetId = customId.split(':')[2];
      if (!isServerOwner && targetId !== interaction.user.id) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} **Access Denied**: Extra Owners cannot revoke other Extra Owners. You can only relinquish your own Extra Owner status.`,
          flags: MessageFlags.Ephemeral
        });
      }

      revokeWhitelistTarget(interaction.guild.id, sdb, 'extraowner', targetId, interaction.user.id);
      await notifyServerOwner(interaction.guild, 'removed', targetId, interaction.user.id);

      const payload = buildExtraOwnerStudioPayload(interaction.guild, sdb, prefix, interaction.user.username);
      await interaction.update(payload);
      return true;
    }

    // 4. Remove Extra Owner Trigger
    if (customId === 'eo:remove') {
      const rows = sdb.prepare('SELECT owner_id FROM extraowners WHERE guild_id = ?').all(interaction.guild.id);
      const selectableRows = !isServerOwner ? rows.filter(r => r.owner_id === interaction.user.id) : rows;

      if (selectableRows.length === 0) {
        return interaction.reply({
          content: `${EMOJIS.INFO} ${!isServerOwner ? 'You are not currently registered as an Extra Owner.' : 'No Extra Owners currently assigned to remove.'}`,
          flags: MessageFlags.Ephemeral
        });
      }

      const options = selectableRows.map(r => {
        const m = interaction.guild.members?.cache?.get(r.owner_id);
        const name = m ? m.displayName : `User ${r.owner_id}`;
        return {
          label: name.slice(0, 100),
          description: `ID: ${r.owner_id}`,
          value: r.owner_id,
          emoji: '<a:tungsten_crown:1567238355463176334>'
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('eo:select_remove_user')
        .setPlaceholder('Select an Extra Owner to revoke...')
        .addOptions(options);
      const row = new ActionRowBuilder().addComponents(select);

      await interaction.reply({
        content: `${EMOJIS.SHIELD} Select an Extra Owner to remove:`,
        components: [row],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 5. User Selected to Remove from Extra Owners
    if (customId === 'eo:select_remove_user') {
      const targetId = interaction.values[0];
      if (!isServerOwner && targetId !== interaction.user.id) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} **Access Denied**: Extra Owners cannot revoke other Extra Owners. You can only relinquish your own status.`,
          flags: MessageFlags.Ephemeral
        });
      }

      revokeWhitelistTarget(interaction.guild.id, sdb, 'extraowner', targetId, interaction.user.id);
      await notifyServerOwner(interaction.guild, 'removed', targetId, interaction.user.id);

      await interaction.update({
        content: `${EMOJIS.SUCCESS} <@${targetId}> has been removed from Extra Owners.\n*Click **Refresh** on the studio to update the roster.*`,
        components: []
      });
      return true;
    }

    // 6. Manage Whitelists Button
    if (customId === 'eo:manage_wl') {
      const payload = buildWhitelistStudioPayload(interaction.guild, sdb, prefix, interaction.user.username);
      await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      return true;
    }

    // 7. View Privileges
    if (customId === 'eo:privileges') {
      const card = createV2Card({
        color: 0x000000,
        title: `${EMOJIS.ZAP} Extra Owner Executive Superpowers`,
        description:
          `> **1. Absolute Antinuke Bypass**\n` +
          `Extra Owners can perform administrative actions (channels, roles, webhooks, bans, kicks) without triggering antinuke rate limits or bot punishments.\n\n` +
          `> **2. Emergency Lockdown Controls**\n` +
          `Can engage and lift server-wide emergency lockdowns using \`${prefix}panic trigger\` and \`${prefix}panic unlock\`.\n\n` +
          `> **3. Whitelist & Security Management**\n` +
          `Full authority to configure member & role whitelists (\`${prefix}wl\`) and manage server defense thresholds.\n\n` +
          `> **4. AutoMod & Anti-Raid Bypass**\n` +
          `Exempt from automated word filters, mention limits, and spam filters.`,
        footerText: 'Tungsten Antinuke Security Matrix'
      });

      await interaction.reply({ embeds: [card], flags: MessageFlags.Ephemeral });
      return true;
    }

    // 8. Reset All Extra Owners (Step 1: Two-Step Confirmation Prompt)
    if (customId === 'eo:reset') {
      if (!isServerOwner) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} Only the **Primary Server Owner** can reset all Extra Owners.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const count = sdb.prepare('SELECT COUNT(*) as cnt FROM extraowners WHERE guild_id = ?').get(interaction.guild.id).cnt;
      if (count === 0) {
        return interaction.reply({
          content: `${EMOJIS.INFO} There are no Extra Owners currently assigned to reset.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const confirmCard = createV2Card({
        color: 0x000000,
        title: `${EMOJIS.WARN} Confirm Reset All Extra Owners`,
        description:
          `> **Are you sure you want to revoke all Extra Owners in ${interaction.guild.name}?**\n\n` +
          `• All **${count}** designated Extra Owners will immediately lose Antinuke immunity and emergency powers.\n` +
          `• A 24-hour security cooldown will be placed on re-adding them.\n\n` +
          `*This executive action is irreversible. Click **Confirm Reset All** to proceed.*`,
        footerText: 'Tungsten Security Safeguard'
      });

      const confirmRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('eo:reset_confirm')
          .setLabel('Confirm Reset All')
          .setStyle(ButtonStyle.Danger)
          .setEmoji(EMOJIS.WARN),
        new ButtonBuilder()
          .setCustomId('eo:refresh')
          .setLabel('Cancel')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(EMOJIS.CROSS)
      );

      await interaction.reply({
        embeds: [confirmCard],
        components: [confirmRow],
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    // 8b. Step 2: Confirmed Reset of All Extra Owners
    if (customId === 'eo:reset_confirm') {
      if (!isServerOwner) {
        return interaction.reply({
          content: `${EMOJIS.CROSS} Only the **Primary Server Owner** can reset all Extra Owners.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const eoList = sdb.prepare('SELECT owner_id FROM extraowners WHERE guild_id = ?').all(interaction.guild.id);
      const nowSec = Math.floor(Date.now() / 1000);
      for (const eo of eoList) {
        try {
          sdb.prepare(`
            INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
            VALUES ('extraowner_remove', ?, ?, 'Reset all extra owners', ?)
          `).run(interaction.user.id, eo.owner_id, nowSec);
        } catch (e) {}
      }

      sdb.prepare('DELETE FROM extraowners WHERE guild_id = ?').run(interaction.guild.id);
      clearImmunityCache(interaction.guild.id);

      await notifyServerOwner(interaction.guild, 'removed', `All Extra Owners (${eoList.length})`, interaction.user.id);

      await interaction.update({
        content: `${EMOJIS.SUCCESS} **All Extra Owners have been reset and removed for this server.**\n*Click **Refresh** on the Extra Owner Studio to view the updated roster.*`,
        embeds: [],
        components: []
      });
      return true;
    }

    return false;
  }
};
