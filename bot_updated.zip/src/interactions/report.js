/**
 * Message Report Interaction Handler
 * Handles "Accept Report" (delete message, warn author) and "Dismiss Report"
 */
const { PermissionsBitField, MessageFlags } = require('discord.js');
const { hasPerm, createEmbed } = require('../utils/tools');
const { handleWarn } = require('../commands/moderation/warn');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefix: 'report',

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!customId.startsWith('report:')) return false;

    if (!hasPerm(interaction.member, PermissionsBitField.Flags.ManageMessages)) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission to action message reports.',
        flags: MessageFlags.Ephemeral
      });
    }

    const parts = customId.split(':');
    const action = parts[1]; // 'accept' or 'dismiss'

    if (action === 'accept') {
      const channelId = parts[2];
      const messageId = parts[3];
      const authorId = parts[4];

      // Try deleting reported message
      let msgDeleted = false;
      try {
        const ch = interaction.guild.channels.cache.get(channelId);
        if (ch) {
          const msg = await ch.messages.fetch(messageId).catch(() => null);
          if (msg) {
            await msg.delete().catch(() => {});
            msgDeleted = true;
          }
        }
      } catch (_) {}

      // Warn author
      let targetMember;
      try {
        targetMember = await interaction.guild.members.fetch(authorId).catch(() => null);
      } catch (_) {}

      if (targetMember) {
        await handleWarn({
          guild: interaction.guild,
          member: interaction.member,
          author: interaction.user,
          targetMember,
          reason: `Reported message accepted by ${interaction.user.username}`,
          client
        });
      }

      const updatedEmbed = createEmbed({
        color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: '<a:tungsten_shield:1567242104923627574> Message Report Accepted',
        description:
          `• **Action Taken:** Message ${msgDeleted ? 'deleted' : 'not found'}, Author warned\n` +
          `• **Moderator:** <@${interaction.user.id}>\n` +
          `• **Target:** <@${authorId}>\n` +
          `• **Status:** RESOLVED`
      });

      await interaction.update({ embeds: [updatedEmbed], components: [] });
      return true;
    }

    if (action === 'dismiss') {
      const updatedEmbed = createEmbed({
        color: 0x95a5a6,
        title: `${EMOJIS.CLOSE || '<a:tungsten_close:1567234632905138206>'} Message Report Dismissed`,
        description:
          `• **Action Taken:** No action taken\n` +
          `• **Dismissed By:** <@${interaction.user.id}>\n` +
          `• **Status:** DISMISSED`
      });

      await interaction.update({ embeds: [updatedEmbed], components: [] });
      return true;
    }

    return false;
  }
};
