/**
 * Quests Interaction Router (Node.js)
 * Handles interactive buttons on daily quest cards.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { EMOJIS } = require('../utils/emojis');
const {
  getUserQuests,
  getUserStreak,
  claimQuestRewards,
  renderProgressBar,
  getUtcDateString
} = require('../utils/questEngine');

module.exports = {
  prefixes: ['quest'],

  async handle(interaction, client) {
    const customId = interaction.customId || '';
    if (!customId.startsWith('quest:')) return false;

    if (!interaction.guild) {
      await interaction.reply({ content: 'Daily quests are only available in servers.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const parts = customId.split(':');
    const action = parts[1];
    const targetUserId = parts[2] || interaction.user.id;

    // Security: Only card owner can interact
    if (interaction.user.id !== targetUserId) {
      await interaction.reply({
        content: '<a:tungsten_warn:1567246685082746940> This is not your daily quest panel. Use `!quests` to view your own quests.',
        flags: MessageFlags.Ephemeral
      });
      return true;
    }

    const sdb = getServerDb(interaction.guild.id);
    const today = getUtcDateString();

    if (action === 'claim') {
      const claimRes = claimQuestRewards(interaction.guild.id, targetUserId, sdb);
      if (claimRes.claimedCoins === 0 && claimRes.claimedXp === 0) {
        await interaction.reply({
          content: '<a:tungsten_info:1567240890748248084> No unclaimed quest rewards waiting right now. Keep completing quests!',
          flags: MessageFlags.Ephemeral
        });
      } else {
        await interaction.reply({
          content: `${EMOJIS.SUCCESS} Successfully claimed **+${claimRes.claimedCoins.toLocaleString()} ${EMOJIS.COIN} Coins** and **+${claimRes.claimedXp.toLocaleString()} ${EMOJIS.ZAP} XP**!`,
          flags: MessageFlags.Ephemeral
        });
      }
    }

    // Refresh view
    const quests = getUserQuests(interaction.guild.id, targetUserId, today, sdb);
    const streakInfo = getUserStreak(interaction.guild.id, targetUserId, sdb);

    const now = new Date();
    const midnightUtc = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
    const midnightTimestamp = Math.floor(midnightUtc.getTime() / 1000);

    const typeIcons = {
      chat: EMOJIS.CHAT || EMOJIS.DOCUMENT,
      work: EMOJIS.BRIEFCASE || EMOJIS.TOOLS,
      beg: EMOJIS.CASH || EMOJIS.COIN,
      fish: EMOJIS.TROPHY || EMOJIS.STAR,
      hunt: EMOJIS.SWORDS || EMOJIS.TARGET,
      daily: EMOJIS.GIFT || EMOJIS.GIVEAWAY,
      gamble: EMOJIS.COIN || EMOJIS.STAR,
      deposit: EMOJIS.BANK || EMOJIS.ATM
    };

    const questLines = quests.map((q, idx) => {
      const icon = typeIcons[q.type] || EMOJIS.DOCUMENT;
      let statusStr = '<a:tungsten_loading:1567241050567876698> In Progress';
      if (q.completed && q.claimed) {
        statusStr = '<a:tungsten_success:1567242523468890274> Completed';
      } else if (q.completed && !q.claimed) {
        statusStr = `${EMOJIS.GIFT || EMOJIS.GIVEAWAY} Claim Ready!`;
      }

      const bar = renderProgressBar(q.progress || 0, q.target || 1, 10);
      return (
        `**${idx + 1}. ${icon} ${q.title}** • ${statusStr}\n` +
        `> ${q.desc}\n` +
        `> ${bar}\n` +
        `> **Reward:** +${q.rewardCoins.toLocaleString()} ${EMOJIS.COIN} Coins • +${q.rewardXp} ${EMOJIS.ZAP} XP`
      );
    });

    const allDone = quests.every(q => q.completed);
    let streakText = `${EMOJIS.FIRE || EMOJIS.ZAP} **Daily Quest Streak:** **${streakInfo.streak}** day(s)`;
    if (allDone) {
      streakText += ' • <a:tungsten_success:1567242523468890274> *All quests completed for today!*';
    } else {
      const nextStreak = (streakInfo.streak || 0) + 1;
      const nextCoins = 500 + (nextStreak * 100);
      const nextXp = 100 + (nextStreak * 25);
      streakText += `\n-# Complete all 3 quests today to reach streak **${nextStreak}** (+${nextCoins} ${EMOJIS.COIN} / +${nextXp} ${EMOJIS.ZAP} XP bonus)!`;
    }

    const embed = createEmbed({
      color: client.config?.COLORS?.PRIMARY || 0x5865f2,
      author: {
        name: `${interaction.user.username}'s Daily Quests`,
        icon_url: interaction.user.displayAvatarURL ? interaction.user.displayAvatarURL({ dynamic: true }) : null
      },
      title: `${EMOJIS.QUESTS || EMOJIS.DOCUMENT} Daily Quests (${today})`,
      description:
        `${streakText}\n\n` +
        `${questLines.join('\n\n')}\n\n` +
        `${EMOJIS.CLOCK || EMOJIS.TIMER} **Resets:** <t:${midnightTimestamp}:R> (UTC Midnight)`,
      footer: 'Tip: Use !quests claim if rewards are waiting'
    });

    const hasUnclaimed = quests.some(q => q.completed && !q.claimed);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`quest:claim:${targetUserId}`)
        .setLabel('Claim Rewards')
        .setEmoji(EMOJIS.GIFT)
        .setStyle(hasUnclaimed ? ButtonStyle.Success : ButtonStyle.Secondary)
        .setDisabled(!hasUnclaimed && allDone),
      new ButtonBuilder()
        .setCustomId(`quest:refresh:${targetUserId}`)
        .setLabel('Refresh')
        .setEmoji(EMOJIS.REFRESH)
        .setStyle(ButtonStyle.Primary)
    );

    if (action === 'claim') {
      // Followup or edit original message
      await interaction.message.edit({ embeds: [embed], components: [row] }).catch(() => null);
    } else {
      await interaction.update({ embeds: [embed], components: [row] }).catch(() => null);
    }

    return true;
  }
};
