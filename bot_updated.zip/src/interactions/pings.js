/**
 * Mention Alert Interaction Router (Node.js)
 */
const { MessageFlags } = require('discord.js');
const { setMentionAlertsEnabled } = require('../utils/pingsDb');

module.exports = {
  prefixes: ['pings'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (customId && customId.startsWith('pings:disable')) {
      setMentionAlertsEnabled(interaction.user.id, false, interaction.guild?.id || null);
      const text = '<a:tungsten_bell:1567233316925612173> You have disabled DM mention alerts from Tungsten. You can re-enable alerts anytime by typing `!pings on` in any server.';

      try {
        if (!interaction.guild) {
          // In DMs, ephemeral flags are invalid and cause Discord API error 50006.
          // Edit the message or reply directly without MessageFlags.Ephemeral.
          if (typeof interaction.update === 'function') {
            await interaction.update({
              content: text,
              embeds: interaction.message?.embeds || [],
              components: []
            });
          } else {
            await interaction.reply({ content: text });
          }
          return true;
        }

        await interaction.reply({
          content: text,
          flags: MessageFlags.Ephemeral
        });
        return true;
      } catch (err) {
        try {
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: text });
          }
        } catch (innerErr) {
          // Ignore
        }
        return true;
      }
    }
    return false;
  }
};
