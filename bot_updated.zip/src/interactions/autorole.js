/**
 * Autorole Studio Interaction Router (Node.js)
 */
const {
  MessageFlags,
  PermissionsBitField,
  RoleSelectMenuBuilder,
  StringSelectMenuBuilder,
  ActionRowBuilder
} = require('discord.js');
const { getConfig } = require('../utils/tools');
const { EMOJIS } = require('../utils/emojis');

module.exports = {
  prefixes: ['autorole'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;
    if (!customId.startsWith('autorole:')) return false;

    const autorole = require('../commands/roles/autorole');
    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    if (!interaction.member?.permissions?.has(PermissionsBitField.Flags.ManageRoles)) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Manage Roles` permission to manage autoroles.', flags: MessageFlags.Ephemeral });
    }

    // 1. Add Human Role Trigger -> RoleSelectMenu
    if (customId === 'autorole:add:human' || customId === 'autorole:guide:human') {
      const roleSelect = new RoleSelectMenuBuilder()
        .setCustomId('autorole:select_role:humans')
        .setPlaceholder('Select Human Autorole...')
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(roleSelect);
      return interaction.reply({
        content: 'Select a server role to automatically assign to new human members upon joining:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
    }

    // 2. Add Bot Role Trigger -> RoleSelectMenu
    if (customId === 'autorole:add:bot' || customId === 'autorole:guide:bot') {
      const roleSelect = new RoleSelectMenuBuilder()
        .setCustomId('autorole:select_role:bots')
        .setPlaceholder('Select Bot Autorole...')
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(roleSelect);
      return interaction.reply({
        content: 'Select a server role to automatically assign to new bot accounts upon authorization:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
    }

    // 3. Role Selected to Add (humans or bots)
    if (customId.startsWith('autorole:select_role:')) {
      const targetType = customId.split(':')[2]; // 'humans' or 'bots'
      const roleId = interaction.values[0];
      const data = autorole.getAutoroleData(interaction.guild.id);

      const role = interaction.guild.roles?.cache?.get(roleId);

      // Verify @everyone role check
      if ((role && role.id === interaction.guild.id) || roleId === interaction.guild.id) {
        return interaction.update({
          content: '<a:tungsten_close:1567234632905138206> The `@everyone` role cannot be set as an autorole.',
          components: []
        });
      }

      // Verify hierarchy check
      if (role && interaction.guild.members?.me?.roles?.highest?.position !== undefined && interaction.guild.members.me.roles.highest.position <= role.position) {
        return interaction.update({
          content: `<a:tungsten_close:1567234632905138206> I cannot manage ${role} because it is positioned higher than or equal to my highest role.`,
          components: []
        });
      }

      // Administrator safeguard check
      if (role?.permissions?.has(PermissionsBitField.Flags.Administrator) || role?.permissions?.has('Administrator')) {
        return interaction.update({
          content: '<a:tungsten_warn:1567242784535085148> That role cannot be used as an autorole because **Administrator** is enabled for that role. For security, administrative roles can never be automatically assigned to joining members.',
          components: []
        });
      }

      if (!data[targetType]) data[targetType] = [];
      if (!data[targetType].includes(roleId)) {
        if (data[targetType].length >= 10) {
          return interaction.update({ content: `<a:tungsten_close:1567234632905138206> Maximum limit of 10 ${targetType} autoroles reached.`, components: [] });
        }
        data[targetType].push(roleId);
        autorole.saveAutoroleData(interaction.guild.id, data);
      }

      const studio = autorole.buildAutoroleStudio(interaction.guild, data, prefix);
      try {
        await interaction.message.edit(studio);
      } catch (e) {}

      return interaction.update({
        content: `<a:tungsten_success:1567242523468890274> Successfully added <@&${roleId}> to **${targetType.toUpperCase()} Autoroles**!\n*Click **Refresh** on the studio to view.*`,
        components: []
      });
    }

    // 4. Remove Role Trigger -> StringSelectMenu
    if (customId === 'autorole:remove') {
      const data = autorole.getAutoroleData(interaction.guild.id);
      const allRoles = [
        ...data.humans.map(id => ({ id, type: 'Human' })),
        ...data.bots.map(id => ({ id, type: 'Bot' }))
      ];

      if (allRoles.length === 0) {
        return interaction.reply({ content: '<a:tungsten_info:1567240890748248084> No autoroles currently configured to remove.', flags: MessageFlags.Ephemeral });
      }

      const options = allRoles.slice(0, 25).map(item => {
        const r = interaction.guild.roles?.cache?.get(item.id);
        const name = r ? r.name : `Role ${item.id}`;
        return {
          label: `${name} (${item.type})`.slice(0, 100),
          value: `${item.type.toLowerCase()}:${item.id}`,
          description: `ID: ${item.id}`,
          emoji: item.type === 'Human' ? EMOJIS.USER : EMOJIS.BOT
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('autorole:select_remove')
        .setPlaceholder('Select an autorole to remove...')
        .addOptions(options);
      const row = new ActionRowBuilder().addComponents(select);

      return interaction.reply({
        content: 'Select an autorole to remove from automated join assignment:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
    }

    // 5. Role Selected to Remove
    if (customId === 'autorole:select_remove') {
      const [type, roleId] = interaction.values[0].split(':');
      const data = autorole.getAutoroleData(interaction.guild.id);
      const targetKey = type === 'human' ? 'humans' : 'bots';
      data[targetKey] = data[targetKey].filter(id => id !== roleId);
      autorole.saveAutoroleData(interaction.guild.id, data);

      const studio = autorole.buildAutoroleStudio(interaction.guild, data, prefix);
      try {
        await interaction.message.edit(studio);
      } catch (e) {}

      return interaction.update({
        content: `<a:tungsten_success:1567242523468890274> Removed <@&${roleId}> from **${targetKey.toUpperCase()} Autoroles**!`,
        components: []
      });
    }

    // 6. Reset All
    if (customId === 'autorole:reset') {
      await interaction.deferUpdate().catch(() => null);
      autorole.saveAutoroleData(interaction.guild.id, { bots: [], humans: [] });
      const studio = autorole.buildAutoroleStudio(interaction.guild, { bots: [], humans: [] }, prefix);
      return await interaction.update(studio).catch(() => null);
    }

    // 7. Refresh
    if (customId === 'autorole:refresh') {
      await interaction.deferUpdate().catch(() => null);
      const data = autorole.getAutoroleData(interaction.guild.id);
      const studio = autorole.buildAutoroleStudio(interaction.guild, data, prefix);
      return await interaction.update(studio).catch(() => null);
    }

    return true;
  }
};
