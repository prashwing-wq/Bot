/**
 * Reaction Roles Interaction Router (Node.js)
 * Handles interactive Reaction Role Studio controls and self-role button toggles.
 */
const {
  MessageFlags,
  PermissionFlagsBits,
  ActionRowBuilder,
  RoleSelectMenuBuilder,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { hasPerm, getConfig } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const {
  buildReactionRoleStudio,
  deployReactionRolePanel,
  hasDangerousPerms
} = require('../commands/roles/reactionrole');

module.exports = {
  prefixes: ['rr'],

  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild || !interaction.member) return false;
    if (!customId.startsWith('rr:')) return false;

    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client?.config?.DEFAULT_PREFIX || '!';

    // 1. Toggle self-assignable role (public member action)
    if (customId.startsWith('rr:toggle:')) {
      const roleId = customId.split(':')[2];
      const role = interaction.guild.roles.cache.get(roleId);
      if (!role) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> This role no longer exists on the server.',
          flags: MessageFlags.Ephemeral
        });
      }

      // Role hierarchy safety check
      const botMember = interaction.guild.members.me;
      if (botMember && role.position >= botMember.roles.highest.position) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Cannot assign this role: its position is equal to or higher than Tungsten\'s highest role.',
          flags: MessageFlags.Ephemeral
        });
      }

      // Dangerous permissions safety check
      if (hasDangerousPerms(role)) {
        return interaction.reply({
          content: '<a:tungsten_warn:1567242784535085148> That role cannot be added to a reaction role panel because it has dangerous administrative permissions (**Administrator**, **Manage Server**, **Manage Roles**, etc.). For security, roles with dangerous permissions can never be self-assigned.',
          flags: MessageFlags.Ephemeral
        });
      }

      // Verify role is registered in reaction_roles table
      try {
        const sdb = getServerDb(interaction.guild.id);
        const registered = sdb.prepare('SELECT 1 FROM reaction_roles WHERE guild_id = ? AND role_id = ?').get(interaction.guild.id, role.id);
        if (!registered) {
          return interaction.reply({
            content: '<a:tungsten_close:1567234632905138206> This role is not registered in the verified reaction roles catalog.',
            flags: MessageFlags.Ephemeral
          });
        }
      } catch (_) {}

      try {
        if (interaction.member.roles.cache.has(role.id)) {
          await interaction.member.roles.remove(role.id, 'Tungsten Reaction Role toggle');
          return interaction.reply({
            content: `<a:tungsten_trash:1567242891276062872> Removed role **${role.name}** from your profile.`,
            flags: MessageFlags.Ephemeral
          });
        } else {
          await interaction.member.roles.add(role.id, 'Tungsten Reaction Role toggle');
          return interaction.reply({
            content: `<a:tungsten_success:1567242523468890274> Added role **${role.name}** to your profile!`,
            flags: MessageFlags.Ephemeral
          });
        }
      } catch (err) {
        return interaction.reply({
          content: `<a:tungsten_warn:1567246685082746940> Could not modify role: ${err.message}. Please check role hierarchy.`,
          flags: MessageFlags.Ephemeral
        });
      }
    }

    // Permission check for all studio management actions
    if (!hasPerm(interaction.member, PermissionFlagsBits.ManageRoles)) {
      if (typeof interaction.reply === 'function' && !interaction.replied && !interaction.deferred) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> You need `Manage Roles` permission to manage reaction roles.',
          flags: MessageFlags.Ephemeral
        });
      }
      return false;
    }

    const sdb = getServerDb(interaction.guild.id);

    // 2. Button: Add Role -> RoleSelectMenu
    if (customId === 'rr:btn_add') {
      const roleSelect = new RoleSelectMenuBuilder()
        .setCustomId('rr:select_add')
        .setPlaceholder('Select a role to add to the panel...')
        .setMaxValues(1);
      const row = new ActionRowBuilder().addComponents(roleSelect);
      return interaction.reply({
        content: 'Select a server role to add to the reaction role panel:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
    }

    // 3. Select: Role Selected to Add
    if (customId === 'rr:select_add') {
      const roleId = interaction.values?.[0];
      const role = interaction.guild.roles?.cache?.get(roleId);

      if (!role) {
        return interaction.update({
          content: '<a:tungsten_close:1567234632905138206> This role could not be found.',
          components: []
        });
      }

      // Check @everyone
      if (role.id === interaction.guild.id || roleId === interaction.guild.id) {
        return interaction.update({
          content: '<a:tungsten_close:1567234632905138206> The `@everyone` role cannot be added to a reaction role panel.',
          components: []
        });
      }

      // Hierarchy check
      const botMember = interaction.guild.members?.me;
      if (botMember?.roles?.highest?.position !== undefined && role.position >= botMember.roles.highest.position) {
        return interaction.update({
          content: `<a:tungsten_close:1567234632905138206> Cannot add that role: its position is equal to or higher than Tungsten's highest role.`,
          components: []
        });
      }

      // Check dangerous permissions
      if (hasDangerousPerms(role)) {
        return interaction.update({
          content: '<a:tungsten_warn:1567242784535085148> That role cannot be added to a reaction role panel because it has dangerous administrative permissions (**Administrator**, **Manage Server**, **Manage Roles**, etc.). For security, roles with dangerous permissions can never be self-assigned.',
          components: []
        });
      }

      // Check if already registered
      const existing = sdb.prepare('SELECT 1 FROM reaction_roles WHERE guild_id = ? AND role_id = ?').get(interaction.guild.id, role.id);
      if (existing) {
        return interaction.update({
          content: `<a:tungsten_warn:1567242784535085148> <@&${role.id}> is already registered in the reaction role panel.`,
          components: []
        });
      }

      // Insert mapping
      sdb.prepare(`
        INSERT INTO reaction_roles (guild_id, message_id, channel_id, emoji, role_id)
        VALUES (?, 'pending', 'pending', ?, ?)
      `).run(interaction.guild.id, `🎭:${role.name}`, role.id);

      const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
      const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
      try {
        await interaction.message.edit(studio);
      } catch (_) {}

      return interaction.update({
        content: `<a:tungsten_success:1567242523468890274> Added reaction role mapping for ${role} with label \`${role.name}\` and emoji 🎭.\n*Click **Refresh** on the studio to view.*`,
        components: []
      });
    }

    // 4. Button: Remove Role -> StringSelectMenu
    if (customId === 'rr:btn_remove') {
      const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) {
        return interaction.reply({
          content: '<a:tungsten_info:1567240890748248084> No reaction roles currently configured to remove.',
          flags: MessageFlags.Ephemeral
        });
      }

      const options = rows.slice(0, 25).map(r => {
        const parts = (r.emoji || '').split(':');
        const role = interaction.guild.roles?.cache?.get(r.role_id);
        const name = role ? role.name : (parts[1] || `Role ${r.role_id}`);
        return {
          label: name.slice(0, 100),
          value: r.role_id,
          description: `ID: ${r.role_id}`.slice(0, 100)
        };
      });

      const select = new StringSelectMenuBuilder()
        .setCustomId('rr:select_remove')
        .setPlaceholder('Select a reaction role to remove...')
        .addOptions(options);
      const row = new ActionRowBuilder().addComponents(select);

      return interaction.reply({
        content: 'Select a reaction role to remove from the panel:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
    }

    // 5. Select: Role Selected to Remove
    if (customId === 'rr:select_remove') {
      const roleId = interaction.values?.[0];
      sdb.prepare('DELETE FROM reaction_roles WHERE guild_id = ? AND role_id = ?').run(interaction.guild.id, roleId);

      const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
      const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
      try {
        await interaction.message.edit(studio);
      } catch (_) {}

      return interaction.update({
        content: `<a:tungsten_success:1567242523468890274> Removed <@&${roleId}> from the reaction role panel!`,
        components: []
      });
    }

    // 6. Button: Deploy Panel to Current Channel
    if (customId === 'rr:btn_deploy') {
      const res = await deployReactionRolePanel(interaction.guild, interaction.channel, sdb);
      if (res.error) {
        return interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> ${res.error}`,
          flags: MessageFlags.Ephemeral
        });
      }
      return interaction.reply({
        content: `<a:tungsten_success:1567242523468890274> Reaction role panel successfully deployed to ${interaction.channel}!`,
        flags: MessageFlags.Ephemeral
      });
    }

    // 7. Button: Clear All Mappings
    if (customId === 'rr:btn_clear') {
      sdb.prepare('DELETE FROM reaction_roles WHERE guild_id = ?').run(interaction.guild.id);
      const studio = buildReactionRoleStudio(interaction.guild, [], prefix);
      return interaction.update(studio);
    }

    // 8. Button: Refresh Studio
    if (customId === 'rr:btn_refresh') {
      const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
      const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
      return interaction.update(studio);
    }

    // ─────────────────────────────────────────────────────────────
    // Customization Window Buttons
    // ─────────────────────────────────────────────────────────────
    // 9. Button: Set Title -> Modal
    if (customId === 'rr:btn_edit_title') {
      const current = sdb.prepare("SELECT value FROM server_settings WHERE key = 'rr_panel_title'").get()?.value || '';
      const modal = new ModalBuilder()
        .setCustomId('rr:modal_title')
        .setTitle('Set Reaction Role Title');
      const input = new TextInputBuilder()
        .setCustomId('title_input')
        .setLabel('Panel Title')
        .setStyle(TextInputStyle.Short)
        .setMaxLength(256)
        .setRequired(true);
      if (current) input.setValue(current);
      modal.addComponents(new ActionRowBuilder().addComponents(input));
      await interaction.showModal(modal);
      return true;
    }

    // 10. Button: Set Description -> Modal
    if (customId === 'rr:btn_edit_desc') {
      const current = sdb.prepare("SELECT value FROM server_settings WHERE key = 'rr_panel_description'").get()?.value || '';
      const modal = new ModalBuilder()
        .setCustomId('rr:modal_desc')
        .setTitle('Set Reaction Role Description');
      const input = new TextInputBuilder()
        .setCustomId('desc_input')
        .setLabel('Panel Description')
        .setStyle(TextInputStyle.Paragraph)
        .setMaxLength(2000)
        .setRequired(true);
      if (current) input.setValue(current);
      modal.addComponents(new ActionRowBuilder().addComponents(input));
      await interaction.showModal(modal);
      return true;
    }

    // 11. Button: Set Banner -> Modal
    if (customId === 'rr:btn_edit_banner') {
      const current = sdb.prepare("SELECT value FROM server_settings WHERE key = 'rr_panel_banner'").get()?.value || '';
      const modal = new ModalBuilder()
        .setCustomId('rr:modal_banner')
        .setTitle('Set Reaction Role Banner Image');
      const input = new TextInputBuilder()
        .setCustomId('banner_input')
        .setLabel('Banner Image URL (HTTPS)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('https://...')
        .setMaxLength(512)
        .setRequired(false);
      if (current) input.setValue(current);
      modal.addComponents(new ActionRowBuilder().addComponents(input));
      await interaction.showModal(modal);
      return true;
    }

    // 12. Button: Set Avatar -> Modal
    if (customId === 'rr:btn_edit_avatar') {
      const current = sdb.prepare("SELECT value FROM server_settings WHERE key = 'rr_panel_avatar'").get()?.value || '';
      const modal = new ModalBuilder()
        .setCustomId('rr:modal_avatar')
        .setTitle('Set Reaction Role Avatar/Thumbnail');
      const input = new TextInputBuilder()
        .setCustomId('avatar_input')
        .setLabel('Avatar/Thumbnail Image URL (HTTPS)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('https://...')
        .setMaxLength(512)
        .setRequired(false);
      if (current) input.setValue(current);
      modal.addComponents(new ActionRowBuilder().addComponents(input));
      await interaction.showModal(modal);
      return true;
    }

    // 13. Button: Reset Customizations
    if (customId === 'rr:btn_reset_custom') {
      sdb.prepare("DELETE FROM server_settings WHERE key IN ('rr_panel_title', 'rr_panel_description', 'rr_panel_banner', 'rr_panel_avatar')").run();
      const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
      const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
      return interaction.update(studio);
    }

    // ─────────────────────────────────────────────────────────────
    // Modal Submissions: Panel Customizations
    // ─────────────────────────────────────────────────────────────
    if (interaction.isModalSubmit && interaction.isModalSubmit()) {
      if (customId === 'rr:modal_title') {
        const val = interaction.fields.getTextInputValue('title_input')?.trim();
        if (val) {
          sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('rr_panel_title', val);
        } else {
          sdb.prepare("DELETE FROM server_settings WHERE key = 'rr_panel_title'").run();
        }
        const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
        const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
        try {
          return await interaction.update(studio);
        } catch (_) {
          try {
            if (interaction.message && typeof interaction.message.edit === 'function') {
              await interaction.message.edit(studio);
            }
          } catch (__) {}
          if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: '<a:tungsten_success:1567242523468890274> Reaction role panel title updated!', flags: MessageFlags.Ephemeral });
          }
          return true;
        }
      }

      if (customId === 'rr:modal_desc') {
        const val = interaction.fields.getTextInputValue('desc_input')?.trim();
        if (val) {
          sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('rr_panel_description', val);
        } else {
          sdb.prepare("DELETE FROM server_settings WHERE key = 'rr_panel_description'").run();
        }
        const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
        const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
        try {
          return await interaction.update(studio);
        } catch (_) {
          try {
            if (interaction.message && typeof interaction.message.edit === 'function') {
              await interaction.message.edit(studio);
            }
          } catch (__) {}
          if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: '<a:tungsten_success:1567242523468890274> Reaction role panel description updated!', flags: MessageFlags.Ephemeral });
          }
          return true;
        }
      }

      if (customId === 'rr:modal_banner') {
        const val = interaction.fields.getTextInputValue('banner_input')?.trim();
        if (val && !val.startsWith('http://') && !val.startsWith('https://')) {
          return interaction.reply({
            content: '<a:tungsten_warn:1567242784535085148> Invalid Banner URL: Must begin with `http://` or `https://`.',
            flags: MessageFlags.Ephemeral
          });
        }
        if (val) {
          sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('rr_panel_banner', val);
        } else {
          sdb.prepare("DELETE FROM server_settings WHERE key = 'rr_panel_banner'").run();
        }
        const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
        const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
        try {
          return await interaction.update(studio);
        } catch (_) {
          try {
            if (interaction.message && typeof interaction.message.edit === 'function') {
              await interaction.message.edit(studio);
            }
          } catch (__) {}
          if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: '<a:tungsten_success:1567242523468890274> Reaction role panel banner updated!', flags: MessageFlags.Ephemeral });
          }
          return true;
        }
      }

      if (customId === 'rr:modal_avatar') {
        const val = interaction.fields.getTextInputValue('avatar_input')?.trim();
        if (val && !val.startsWith('http://') && !val.startsWith('https://')) {
          return interaction.reply({
            content: '<a:tungsten_warn:1567242784535085148> Invalid Avatar URL: Must begin with `http://` or `https://`.',
            flags: MessageFlags.Ephemeral
          });
        }
        if (val) {
          sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('rr_panel_avatar', val);
        } else {
          sdb.prepare("DELETE FROM server_settings WHERE key = 'rr_panel_avatar'").run();
        }
        const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(interaction.guild.id);
        const studio = buildReactionRoleStudio(interaction.guild, rows, prefix);
        try {
          return await interaction.update(studio);
        } catch (_) {
          try {
            if (interaction.message && typeof interaction.message.edit === 'function') {
              await interaction.message.edit(studio);
            }
          } catch (__) {}
          if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: '<a:tungsten_success:1567242523468890274> Reaction role panel avatar/thumbnail updated!', flags: MessageFlags.Ephemeral });
          }
          return true;
        }
      }
    }

    return false;
  }
};
