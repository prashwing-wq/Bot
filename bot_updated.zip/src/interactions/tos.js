/**
 * Terms of Service & Security Charter Interaction Router (Node.js)
 * Handles interactive button events for ToS and live security guarantees.
 */
const { MessageFlags, EmbedBuilder } = require('discord.js');
const { isAntinukeArmed } = require('../utils/antinukeEngine');
const { EMOJIS } = require('../utils/emojis');
const config = require('../config');

module.exports = {
  prefixes: ['tos'],

  async handle(interaction, client) {
    if (!interaction.customId) return false;
    if (!interaction.customId.startsWith('tos:')) return false;

    const action = interaction.customId.split(':')[1];

    if (action === 'security') {
      const botName = client?.user?.username || 'Tungsten';
      const guild = interaction.guild;
      let armed = true;
      if (guild) {
        try {
          armed = isAntinukeArmed(guild.id);
        } catch (_) {
          armed = true;
        }
      }

      const boltIcon = EMOJIS.TUNGSTEN_BOLT || '<a:tungsten_bolt:1567233430570405968>';
      const refreshIcon = EMOJIS.TUNGSTEN_REFRESH || '<a:tungsten_refresh:1567241907116187658>';
      const shieldIcon = EMOJIS.TUNGSTEN_SHIELD || '<a:tungsten_shield:1567242104923627574>';
      const targetIcon = EMOJIS.TUNGSTEN_TARGET || '<a:tungsten_target:1567242733997789205>';
      const lockIcon = EMOJIS.TUNGSTEN_LOCK || '<a:tungsten_lock:1567241079030550668>';
      const successIcon = EMOJIS.SUCCESS || '<a:tungsten_success:1567242523468890274>';
      const warnIcon = EMOJIS.WARN || '<a:tungsten_warn:1567246685082746940>';

      const statusBadge = armed ? `${successIcon} \`ACTIVE & ARMED\`` : `${warnIcon} \`STANDBY\``;

      const securityEmbed = new EmbedBuilder()
        .setTitle(`${botName} • Live Security Guarantees & Defense Status`)
        .setDescription(
          `> Enterprise-grade protection guarantees actively enforced for **${guild ? guild.name : 'Your Server'}**.\n\n` +
          `### ${boltIcon} Sub-Second Threat Interception\n` +
          `• Real-time sentinel monitoring across 14+ gateway attack vectors.\n` +
          `• Immediate neutralization of mass channel deletion, role stripping, bot injection, and webhook spam in < 500ms.\n\n` +
          `### ${refreshIcon} Automated Defacement Auto-Healing\n` +
          `• Automated state restoration for destroyed channels, deleted roles, and stripped server settings.\n` +
          `• Prevents irreversible defacement and maintains server structure.\n\n` +
          `### ${shieldIcon} Dual Backup Roles Defense\n` +
          `• Active \`${botName} Backup Tier I\` & \`${botName} Backup Tier II\` administrator roles continuously anchored below ${botName}.\n` +
          `• Zero-bypass administrative defense preserving server governance.\n\n` +
          `### ${targetIcon} Attribution & Anti-False-Ban Protection\n` +
          `• Multi-source audit log reconciliation verifies attacker identity before applying sanctions.\n` +
          `• Whitelist and server owner immunities are authoritatively enforced with zero friendly fire.\n\n` +
          `### ${lockIcon} Privacy & Data Minimization\n` +
          `• Server-isolated SQLite databases with strict zero data commercialization.\n` +
          `• Instant permanent data purge upon bot removal.`
        )
        .addFields(
          { name: 'Antinuke Status', value: statusBadge, inline: true },
          { name: 'Defense Engine', value: '`v3.0 Sentinel`', inline: true },
          { name: 'Compliance Tier', value: '`Discord Certified`', inline: true }
        )
        .setFooter({ text: `${botName} Security Operations • Zero False Bans Guarantee` })
        .setTimestamp();

      const botAvatar = client?.user && typeof client.user.displayAvatarURL === 'function' ? client.user.displayAvatarURL({ dynamic: true }) : null;
      if (botAvatar && typeof botAvatar === 'string' && botAvatar.startsWith('http')) {
        securityEmbed.setThumbnail(botAvatar);
      }

      if (interaction.deferred || interaction.replied) {
        await interaction.followUp({ embeds: [securityEmbed], flags: MessageFlags.Ephemeral });
      } else {
        await interaction.reply({ embeds: [securityEmbed], flags: MessageFlags.Ephemeral });
      }
      return true;
    }

    return false;
  }
};
