/**
 * Automod Studio Interaction Router (Node.js)
 */
const { MessageFlags, PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { getConfig } = require('../utils/tools');

module.exports = {
  prefixes: ['am'],
  async handle(interaction, client) {
    const customId = interaction.customId;
    if (!interaction.guild) return false;
    if (!customId.startsWith('am:')) return false;

    const sdb = getServerDb(interaction.guild.id);
    const guildConfig = getConfig(interaction.guild.id);
    const prefix = guildConfig.prefix || client.config?.DEFAULT_PREFIX || '!';

    // Incident Log Action Buttons
    if (customId.startsWith('am:pardon:')) {
      if (!interaction.member?.permissions.has(PermissionsBitField.Flags.ManageGuild) &&
          !interaction.member?.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Manage Server` or `Moderate Members` permission to pardon strikes.', flags: MessageFlags.Ephemeral });
      }
      const targetUserId = customId.split(':')[2];
      sdb.prepare('DELETE FROM automod_strikes WHERE guild_id = ? AND user_id = ?').run(interaction.guild.id, targetUserId);
      return interaction.reply({
        content: `<a:tungsten_success:1567242523468890274> Automod strikes cleared for <@${targetUserId}> by <@${interaction.user.id}>.`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId.startsWith('am:timeout:')) {
      if (!interaction.member?.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Moderate Members` permission to timeout users.', flags: MessageFlags.Ephemeral });
      }
      const targetUserId = customId.split(':')[2];
      const member = interaction.guild.members.cache.get(targetUserId) || await interaction.guild.members.fetch(targetUserId).catch(() => null);
      if (!member || !member.moderatable) {
        return interaction.reply({ content: '<a:tungsten_warn:1567246685082746940> Cannot timeout this user (missing permissions or higher hierarchy).', flags: MessageFlags.Ephemeral });
      }
      await member.timeout(24 * 60 * 60 * 1000, `Automod incident intervention by ${interaction.user.tag}`).catch(() => null);
      return interaction.reply({
        content: `<a:tungsten_success:1567242523468890274> Member <@${targetUserId}> has been timed out for 24 hours.`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId.startsWith('am:ban:')) {
      if (!interaction.member?.permissions.has(PermissionsBitField.Flags.BanMembers)) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Ban Members` permission to ban users.', flags: MessageFlags.Ephemeral });
      }
      const targetUserId = customId.split(':')[2];
      try {
        await interaction.guild.members.ban(targetUserId, { reason: `Automod incident intervention by ${interaction.user.tag}` });
        return interaction.reply({
          content: `<a:tungsten_success:1567242523468890274> Member <@${targetUserId}> has been banned from the server.`,
          flags: MessageFlags.Ephemeral
        });
      } catch (err) {
        return interaction.reply({ content: `<a:tungsten_warn:1567246685082746940> Failed to ban user: ${err.message}`, flags: MessageFlags.Ephemeral });
      }
    }

    // Automod Studio Filter Toggles & Configuration
    if (!interaction.member?.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure Automod.', flags: MessageFlags.Ephemeral });
    }

    const automod = require('../commands/automation/automod');
    const { setAutomodBypass } = require('../utils/automodEngine');
    await interaction.deferUpdate().catch(() => null);

    // 1. Navigation: Go to Ignores & Honeypot Studio
    if (customId === 'am:page:ignores') {
      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 2. Navigation: Back to Filters / Refresh
    if (customId === 'am:nav:filters' || customId === 'am:panel:refresh') {
      const statuses = automod.getFilterStatuses(sdb);
      const panel = automod.buildAutomodPanel(interaction.guild, statuses, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 3. Multi-Select Ignored Roles
    if (customId === 'am:select_ignore_roles') {
      const selectedRoles = interaction.values || [];
      for (const rid of selectedRoles) {
        setAutomodBypass(interaction.guild.id, 'role', rid, 'all', interaction.user.id);
      }
      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 4. Multi-Select Ignored Channels
    if (customId === 'am:select_ignore_channels') {
      const selectedChannels = interaction.values || [];
      for (const cid of selectedChannels) {
        setAutomodBypass(interaction.guild.id, 'channel', cid, 'all', interaction.user.id);
      }
      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 5. Select Honeypot Channel (with Automatic Announcement)
    if (customId === 'am:select_honeypot') {
      const selectedChanId = interaction.values?.[0];
      if (selectedChanId) {
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_honeypot_channel', ?)").run(selectedChanId);
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_honeypot_action', ?)").run('timeout');

        const chan = interaction.guild.channels.cache.get(selectedChanId)
          || await interaction.guild.channels.fetch(selectedChanId).catch(() => null);

        if (chan) {
          await automod.postHoneypotAnnouncement(chan, interaction.guild, 'timeout');
        }
      }
      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 6. Disable Honeypot
    if (customId === 'am:honeypot:disable') {
      sdb.prepare("DELETE FROM server_settings WHERE key IN ('automod_honeypot_channel', 'automod_honeypot_action')").run();
      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 7. Clear All Ignored Roles
    if (customId === 'am:clear_ignored_roles') {
      sdb.prepare("DELETE FROM automod_bypasses WHERE guild_id = ? AND target_type = 'role'").run(interaction.guild.id);
      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 8. Clear All Ignored Channels
    if (customId === 'am:clear_ignored_channels') {
      sdb.prepare("DELETE FROM automod_bypasses WHERE guild_id = ? AND target_type = 'channel'").run(interaction.guild.id);
      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 9. Select Automod Punishment Policy (Separate from Honeypot)
    if (customId === 'am:select_action') {
      const chosen = interaction.values?.[0] || 'escalation';
      sdb.prepare(`
        INSERT INTO server_settings (key, value)
        VALUES ('automod_action', ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
      `).run(chosen);
      const statuses = automod.getFilterStatuses(sdb);
      const panel = automod.buildAutomodPanel(interaction.guild, statuses, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 10. Select Honeypot Punishment Action (Separate from Automod)
    if (customId === 'am:select_hp_action') {
      const chosen = interaction.values?.[0] || 'timeout_1h';
      sdb.prepare(`
        INSERT INTO server_settings (key, value)
        VALUES ('automod_honeypot_action', ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
      `).run(chosen);

      // Refresh honeypot announcement if channel is active
      const hpRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_channel'").get();
      if (hpRow?.value) {
        const chan = interaction.guild.channels.cache.get(hpRow.value)
          || await interaction.guild.channels.fetch(hpRow.value).catch(() => null);
        if (chan) {
          await automod.postHoneypotAnnouncement(chan, interaction.guild, chosen);
        }
      }

      const panel = automod.buildAutomodIgnoresPanel(interaction.guild, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 11. Clear Banned Words Confirmation
    if (customId === 'am:confirm_clear_words') {
      const confirmCard = automod.buildConfirmClearWordsCard(interaction.guild);
      await interaction.editReply(confirmCard).catch(() => null);
      return true;
    }

    if (customId === 'am:do_clear_words') {
      const { clearBannedWords } = require('../utils/automodEngine');
      clearBannedWords(interaction.guild.id);
      const statuses = automod.getFilterStatuses(sdb, interaction.guild.id);
      const panel = automod.buildAutomodPanel(interaction.guild, statuses, prefix);
      await interaction.editReply(panel).catch(() => null);
      return true;
    }

    // 12. Standard Filter Toggles & Group Controls
    if (customId === 'am:all:enable') {
      for (const k of Object.keys(automod.FILTER_KEYS)) {
        automod.setFilterStatus(sdb, k, true, interaction.guild.id);
      }
    } else if (customId === 'am:all:disable') {
      for (const k of Object.keys(automod.FILTER_KEYS)) {
        automod.setFilterStatus(sdb, k, false, interaction.guild.id);
      }
    } else if (customId === 'am:select_filter' && interaction.values && interaction.values.length > 0) {
      const filterKey = interaction.values[0];
      const cur = automod.getFilterStatuses(sdb, interaction.guild.id)[filterKey];
      automod.setFilterStatus(sdb, filterKey, !cur, interaction.guild.id);
    } else if (customId === 'am:grp:chat') {
      const chatKeys = ['anti_spam', 'anti_caps', 'anti_mention', 'anti_emoji', 'anti_newlines'];
      const statusesNow = automod.getFilterStatuses(sdb, interaction.guild.id);
      const allActive = chatKeys.every(k => statusesNow[k]);
      for (const k of chatKeys) {
        automod.setFilterStatus(sdb, k, !allActive, interaction.guild.id);
      }
    } else if (customId === 'am:grp:links') {
      const linkKeys = ['anti_invite', 'anti_link', 'anti_scam', 'anti_token', 'anti_selfbot'];
      const statusesNow = automod.getFilterStatuses(sdb, interaction.guild.id);
      const allActive = linkKeys.every(k => statusesNow[k]);
      for (const k of linkKeys) {
        automod.setFilterStatus(sdb, k, !allActive, interaction.guild.id);
      }
    } else if (customId === 'am:grp:content') {
      const contentKeys = ['anti_nsfw', 'anti_zalgo', 'anti_spoiler', 'banned_words'];
      const statusesNow = automod.getFilterStatuses(sdb, interaction.guild.id);
      const allActive = contentKeys.every(k => statusesNow[k]);
      for (const k of contentKeys) {
        automod.setFilterStatus(sdb, k, !allActive, interaction.guild.id);
      }
    } else if (customId.startsWith('am:toggle:')) {
      const filterKey = customId.split(':')[2];
      const cur = automod.getFilterStatuses(sdb, interaction.guild.id)[filterKey];
      automod.setFilterStatus(sdb, filterKey, !cur, interaction.guild.id);
    }

    const statuses = automod.getFilterStatuses(sdb, interaction.guild.id);
    const panel = automod.buildAutomodPanel(interaction.guild, statuses, prefix);
    await interaction.editReply(panel).catch(() => null);
    return true;
  }
};
