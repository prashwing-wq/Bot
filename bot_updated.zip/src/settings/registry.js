/**
 * Tungsten Declarative Settings Registry (Node.js)
 * Single source of truth for all bot configuration schemas, validation, defaults,
 * per-guild cached snapshots, and audit logging.
 */
const { EventEmitter } = require('events');
const { getServerDb, getMasterDb } = require('../utils/serverDb');
const { isOwner } = require('../utils/tools');
const config = require('../config');

const settingsEvents = new EventEmitter();
const _GUILD_SETTINGS_CACHE = new Map(); // key: guildId -> { data: Map, ts: number }
const CACHE_TTL_MS = 60000;

/**
 * 3.4 Unified Permission Tier Validator
 * @param {import('discord.js').GuildMember} member
 * @param {'botOwner'|'owner'|'admin'|'manager'|'mod'} requiredTier
 * @returns {boolean}
 */
function can(member, requiredTier = 'admin') {
  if (!member) return false;
  const uid = String(member.id);
  const guild = member.guild;
  const gid = guild ? String(guild.id) : null;

  // 1. Bot Owners have absolute highest authority
  if (isOwner(uid)) return true;
  if (requiredTier === 'botOwner') return false;

  // 2. Server Owner has full owner authority
  if (guild && guild.ownerId === uid) return true;

  // 3. Extra Owners
  if (gid) {
    try {
      const sdb = getServerDb(gid);
      const eo = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(gid, uid);
      if (eo) return true;
    } catch (_) {}
  }
  if (requiredTier === 'owner') return false;

  // 4. Admin Tier
  const perms = member.permissions;
  if (perms && perms.has('Administrator')) return true;
  if (requiredTier === 'admin') return false;

  // 5. Manager Tier
  if (perms && perms.has('ManageGuild')) return true;
  if (requiredTier === 'manager') return false;

  // 6. Moderator Tier
  if (perms && (perms.has('ModerateMembers') || perms.has('ManageMessages') || perms.has('KickMembers') || perms.has('BanMembers'))) {
    return true;
  }

  // Check configured staff/mod roles in guild
  if (gid) {
    try {
      const modRole = getSetting(gid, 'general.mod_role');
      if (modRole && member.roles && member.roles.cache && member.roles.cache.has(String(modRole))) {
        return true;
      }
    } catch (_) {}
  }

  return false;
}

// ─────────────────────────────────────────────────────────────
// Declarative Settings Schema Registry
// ─────────────────────────────────────────────────────────────
const REGISTRY = new Map();

function registerSetting(def) {
  if (!def.key || !def.page || !def.type) {
    throw new Error(`Invalid setting definition: ${JSON.stringify(def)}`);
  }
  REGISTRY.set(def.key, {
    scope: 'guild',
    group: 'General',
    tier: 'admin',
    legacyKeys: [],
    affects: [],
    ...def
  });
}

// 4.1 General
registerSetting({
  key: 'general.prefix',
  page: 'general',
  group: 'Core',
  type: 'text',
  default: '!',
  label: 'Command Prefix',
  help: 'Trigger prefix for text commands',
  tier: 'manager',
  legacyKeys: ['prefix']
});
registerSetting({
  key: 'general.accent_color',
  page: 'general',
  group: 'Theme',
  type: 'color',
  default: 0x2b2d31,
  label: 'Accent Color',
  help: 'Hex color used for bot embeds and cards',
  tier: 'manager'
});
registerSetting({
  key: 'general.components_v2',
  page: 'general',
  group: 'Theme',
  type: 'bool',
  default: true,
  label: 'Components V2 Layout',
  help: 'Enable Discord Type 17 Containers and sleek styling',
  tier: 'manager',
  legacyKeys: ['components_v2_enabled']
});
registerSetting({
  key: 'general.ui_style',
  page: 'general',
  group: 'Theme',
  type: 'enum',
  options: ['clean', 'expressive'],
  default: 'clean',
  label: 'UI Style',
  help: 'Display mode: clean (subtle, restrained, professional) or expressive (animated emojis)',
  tier: 'manager',
  legacyKeys: ['ui_style']
});
registerSetting({
  key: 'general.mod_role',
  page: 'general',
  group: 'Permissions',
  type: 'role',
  default: null,
  label: 'Moderator Role',
  help: 'Default staff role granted mod panel access',
  tier: 'admin'
});
registerSetting({
  key: 'general.reply_with_errors',
  page: 'general',
  group: 'System',
  type: 'bool',
  default: false,
  label: 'Verbose Error Reporting',
  help: 'Whether to show internal error strings to users',
  tier: 'owner'
});

// 4.2 Antinuke
registerSetting({
  key: 'antinuke.enabled',
  page: 'antinuke',
  group: 'Master',
  type: 'bool',
  default: false,
  label: 'Antinuke Master Arm',
  help: 'Master switch for all threat sentinels',
  tier: 'owner',
  legacyKeys: ['antinuke_status'],
  affects: ['antinuke']
});
registerSetting({
  key: 'antinuke.mode',
  page: 'antinuke',
  group: 'Master',
  type: 'enum',
  options: ['ultra'],
  default: 'ultra',
  label: 'Defense Mode Preset',
  help: 'Preset sensitivity for attack thresholds (Locked to Ultra Zero-Tolerance)',
  tier: 'owner',
  legacyKeys: ['antinuke_mode'],
  affects: ['antinuke']
});
registerSetting({
  key: 'antinuke.action',
  page: 'antinuke',
  group: 'Punishment',
  type: 'enum',
  options: ['ban', 'kick', 'strip'],
  default: 'ban',
  label: 'Default Punishment',
  help: 'Primary action taken against unauthorized attackers',
  tier: 'owner',
  legacyKeys: ['antinuke_action'],
  affects: ['antinuke']
});
registerSetting({
  key: 'antinuke.dedupe_window',
  page: 'antinuke',
  group: 'Punishment',
  type: 'int',
  min: 10,
  max: 300,
  default: 60,
  label: 'Dedupe Window (Seconds)',
  help: 'Collapse window for collapsing rapid violations',
  tier: 'owner'
});
registerSetting({
  key: 'antinuke.backup_roles',
  page: 'antinuke',
  group: 'Safeguard',
  type: 'bool',
  default: false,
  label: 'Dual Backup Roles Safeguard',
  help: 'Opt-in redundant Tungsten Administrator backup roles',
  tier: 'owner',
  legacyKeys: ['backup_roles_enabled']
});
registerSetting({
  key: 'antinuke.channel_create_threshold',
  page: 'antinuke',
  group: 'Thresholds',
  type: 'int',
  min: 1,
  max: 20,
  default: 2,
  label: 'Channel Create: Limit',
  help: 'Max channels allowed within 10s',
  tier: 'owner'
});
registerSetting({
  key: 'antinuke.role_create_threshold',
  page: 'antinuke',
  group: 'Thresholds',
  type: 'int',
  min: 1,
  max: 20,
  default: 2,
  label: 'Role Create: Limit',
  help: 'Max roles allowed within 10s',
  tier: 'owner'
});

// 4.3 Anti-Raid
registerSetting({
  key: 'antiraid.enabled',
  page: 'antiraid',
  group: 'Master',
  type: 'bool',
  default: true,
  label: 'Anti-Raid Shield',
  help: 'Detects and mitigates mass user join floods',
  tier: 'admin'
});
registerSetting({
  key: 'antiraid.join_limit',
  page: 'antiraid',
  group: 'Rules',
  type: 'int',
  min: 3,
  max: 50,
  default: 8,
  label: 'Join Flood Limit',
  help: 'Allowed accounts within the time window',
  tier: 'admin'
});
registerSetting({
  key: 'antiraid.window_seconds',
  page: 'antiraid',
  group: 'Rules',
  type: 'int',
  min: 3,
  max: 60,
  default: 10,
  label: 'Detection Window (Sec)',
  help: 'Sliding window in seconds',
  tier: 'admin'
});
registerSetting({
  key: 'antiraid.action',
  page: 'antiraid',
  group: 'Rules',
  type: 'enum',
  options: ['kick', 'ban', 'timeout'],
  default: 'kick',
  label: 'Mitigation Action',
  help: 'Action applied to raid accounts',
  tier: 'admin'
});

// 4.4 Automod
registerSetting({
  key: 'automod.invite.enabled',
  page: 'automod',
  group: 'Filters',
  type: 'bool',
  default: false,
  label: 'Anti-Invite Filter',
  help: 'Blocks unauthorized Discord invite links',
  tier: 'admin',
  legacyKeys: ['automod_anti_invite'],
  affects: ['automod']
});
registerSetting({
  key: 'automod.link.enabled',
  page: 'automod',
  group: 'Filters',
  type: 'bool',
  default: false,
  label: 'Anti-Link Filter',
  help: 'Blocks all unauthorized HTTP/HTTPS URLs',
  tier: 'admin',
  legacyKeys: ['automod_anti_link'],
  affects: ['automod']
});
registerSetting({
  key: 'automod.caps.enabled',
  page: 'automod',
  group: 'Filters',
  type: 'bool',
  default: false,
  label: 'Anti-Caps Filter',
  help: 'Blocks messages with > 70% uppercase letters',
  tier: 'admin',
  legacyKeys: ['automod_anti_caps'],
  affects: ['automod']
});
registerSetting({
  key: 'automod.mention.enabled',
  page: 'automod',
  group: 'Filters',
  type: 'bool',
  default: false,
  label: 'Anti-Mass Mention Filter',
  help: 'Blocks messages containing > 5 user mentions',
  tier: 'admin',
  legacyKeys: ['automod_anti_mention'],
  affects: ['automod']
});
registerSetting({
  key: 'automod.spam.enabled',
  page: 'automod',
  group: 'Filters',
  type: 'bool',
  default: false,
  label: 'Anti-Message Spam Filter',
  help: 'Blocks users sending messages faster than 5 in 4s',
  tier: 'admin',
  legacyKeys: ['automod_anti_spam'],
  affects: ['automod']
});

// 4.6 Logging
registerSetting({
  key: 'logging.mod.channel',
  page: 'logging',
  group: 'Channels',
  type: 'channel',
  default: null,
  label: 'Master Moderation Log',
  help: 'Channel where moderation cases and alerts are sent',
  tier: 'admin',
  legacyKeys: ['audit_log_channel', 'log_channel', 'modlog_channel', 'log_mod']
});
registerSetting({
  key: 'logging.messages.channel',
  page: 'logging',
  group: 'Channels',
  type: 'channel',
  default: null,
  label: 'Message Events Log',
  help: 'Channel where message edits, deletes, and bulk purges are sent',
  tier: 'admin',
  legacyKeys: ['log_messages']
});
registerSetting({
  key: 'logging.members.channel',
  page: 'logging',
  group: 'Channels',
  type: 'channel',
  default: null,
  label: 'Member Events Log',
  help: 'Channel where member joins, leaves, and role/nickname updates are sent',
  tier: 'admin',
  legacyKeys: ['log_members']
});
registerSetting({
  key: 'logging.voice.channel',
  page: 'logging',
  group: 'Channels',
  type: 'channel',
  default: null,
  label: 'Voice Events Log',
  help: 'Channel where voice state transitions are sent',
  tier: 'admin',
  legacyKeys: ['log_voice']
});
registerSetting({
  key: 'logging.server.channel',
  page: 'logging',
  group: 'Channels',
  type: 'channel',
  default: null,
  label: 'Server Events Log',
  help: 'Channel where server channel, role, emoji, and thread changes are sent',
  tier: 'admin',
  legacyKeys: ['log_server']
});
registerSetting({
  key: 'logging.appeals.channel',
  page: 'logging',
  group: 'Channels',
  type: 'channel',
  default: null,
  label: 'Ban Appeals Channel',
  help: 'Channel where user ban appeals are posted for staff review',
  tier: 'admin',
  legacyKeys: ['appeals_channel']
});
registerSetting({
  key: 'logging.ghostping.enabled',
  page: 'logging',
  group: 'Ghostping',
  type: 'bool',
  default: false,
  label: 'Anti-Ghostping Alerts',
  help: 'Alerts channels when a mention is deleted within 60s',
  tier: 'admin',
  legacyKeys: ['antighostping_status']
});
registerSetting({
  key: 'logging.snipe.enabled',
  page: 'logging',
  group: 'Snipe',
  type: 'bool',
  default: true,
  label: 'Snipe Cache Enabled',
  help: 'Stores recently deleted messages for !snipe',
  tier: 'admin'
});

// 4.7 Welcome & Leave
registerSetting({
  key: 'welcomer.welcome.enabled',
  page: 'welcome',
  group: 'Welcome',
  type: 'bool',
  default: false,
  label: 'Welcome Greetings',
  help: 'Announces new member joins in designated channel',
  tier: 'admin'
});
registerSetting({
  key: 'welcomer.welcome.channel',
  page: 'welcome',
  group: 'Welcome',
  type: 'channel',
  default: null,
  label: 'Welcome Channel',
  help: 'Target channel for welcome cards',
  tier: 'admin'
});
registerSetting({
  key: 'welcomer.leave.enabled',
  page: 'leave',
  group: 'Leave',
  type: 'bool',
  default: false,
  label: 'Leave Announcements',
  help: 'Announces member departures',
  tier: 'admin'
});
registerSetting({
  key: 'welcomer.leave.channel',
  page: 'leave',
  group: 'Leave',
  type: 'channel',
  default: null,
  label: 'Leave Channel',
  help: 'Target channel for farewell messages',
  tier: 'admin',
  legacyKeys: ['leave_channel']
});

// 4.9 Leveling
registerSetting({
  key: 'leveling.enabled',
  page: 'leveling',
  group: 'Core',
  type: 'bool',
  default: false,
  label: 'Leveling & XP System',
  help: 'Awards chat XP and announces level ups',
  tier: 'admin',
  legacyKeys: ['leveling_enabled']
});

// 4.10 Economy
registerSetting({
  key: 'economy.enabled',
  page: 'economy',
  group: 'Core',
  type: 'bool',
  default: true,
  label: 'Economy System Active',
  help: 'Enables virtual currency, work, and rob commands',
  tier: 'admin'
});
registerSetting({
  key: 'economy.currency_symbol',
  page: 'economy',
  group: 'Currency',
  type: 'text',
  default: '$',
  label: 'Currency Symbol',
  help: 'Symbol shown in balances and payouts',
  tier: 'admin'
});

// 4.14 Voice
registerSetting({
  key: 'voice.homevc_channel',
  page: 'voice',
  group: 'HomeVC',
  type: 'channel',
  default: null,
  label: '24/7 Home Voice Channel',
  help: 'Persistent voice channel for Tungsten node',
  tier: 'admin'
});
registerSetting({
  key: 'voice.vcrole',
  page: 'voice',
  group: 'VCRole',
  type: 'role',
  default: null,
  label: 'Voice Active Role',
  help: 'Role automatically assigned while in voice channels',
  tier: 'admin',
  legacyKeys: ['vcrole_id']
});

// 4.15 Utility
registerSetting({
  key: 'utility.mention_alerts_enabled',
  page: 'utility',
  group: 'Mentions',
  type: 'bool',
  default: true, // Active by default with 5-min per-user anti-spam protection
  label: 'Mention Alert DMs',
  help: 'DMs users when they are tagged in messages (with 5-minute anti-spam)',
  tier: 'admin'
});

// ─────────────────────────────────────────────────────────────
// Registry Methods: getSetting, setSetting, migration & cache
// ─────────────────────────────────────────────────────────────

function getSettingDefinition(key) {
  return REGISTRY.get(key) || null;
}

function getAllDefinitions() {
  return Array.from(REGISTRY.values());
}

function getDefinitionsForPage(pageId) {
  return Array.from(REGISTRY.values()).filter(d => d.page === pageId);
}

/**
 * Retrieves the effective setting value for a guild.
 * Derives from DB, falling back to legacy keys, then schema default.
 */
function getSetting(guildId, key) {
  const gid = String(guildId);
  const def = REGISTRY.get(key);
  if (!def) return null;

  const now = Date.now();
  let cached = _GUILD_SETTINGS_CACHE.get(gid);
  if (cached && (now - cached.ts < CACHE_TTL_MS) && cached.data.has(key)) {
    return cached.data.get(key);
  }

  let val = null;
  try {
    const sdb = getServerDb(gid);

    // 1. Check exact key
    const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(key);
    if (row && row.value !== undefined && row.value !== null) {
      val = parseValue(row.value, def.type);
    } else if (def.legacyKeys && def.legacyKeys.length > 0) {
      // 2. Check legacy keys
      for (const lk of def.legacyKeys) {
        const legacyRow = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(lk);
        if (legacyRow && legacyRow.value !== undefined && legacyRow.value !== null) {
          val = parseValue(legacyRow.value, def.type);
          break;
        }
      }
    }
  } catch (e) {}

  if (val === null || val === undefined) {
    val = def.default;
  }

  if (!cached) {
    cached = { data: new Map(), ts: now };
    _GUILD_SETTINGS_CACHE.set(gid, cached);
  }
  cached.data.set(key, val);
  return val;
}

/**
 * Updates a setting for a guild with type validation, persistence, audit logging,
 * and immediate cache invalidation.
 */
function setSetting(guildId, key, value, actorId = 'system') {
  const gid = String(guildId);
  const def = REGISTRY.get(key);
  if (!def) {
    throw new Error(`Unknown setting key: ${key}`);
  }

  const validatedVal = validateAndCoerce(value, def);
  const strVal = stringifyValue(validatedVal, def.type);

  const sdb = getServerDb(gid);
  const oldVal = getSetting(gid, key);
  const now = Math.floor(Date.now() / 1000);

  // 1. Write to server_settings
  sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES (?, ?, ?)')
    .run(key, strVal, now);

  // 2. Write to settings_audit
  try {
    sdb.prepare(`
      INSERT INTO settings_audit (guild_id, key, old_val, new_val, actor_id, timestamp)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(gid, key, stringifyValue(oldVal, def.type), strVal, String(actorId), now);
  } catch (e) {}

  // 3. Invalidate memory cache
  const cached = _GUILD_SETTINGS_CACHE.get(gid);
  if (cached) {
    cached.data.set(key, validatedVal);
  }

  // 4. Emit event for live reload in running sentinels
  settingsEvents.emit('settingsChanged', { guildId: gid, key, oldValue: oldVal, newValue: validatedVal, actorId });

  return validatedVal;
}

function invalidateGuildSettings(guildId) {
  _GUILD_SETTINGS_CACHE.delete(String(guildId));
}

// Helper serializers & parsers
function parseValue(raw, type) {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  switch (type) {
    case 'bool':
      return s === '1' || s.toLowerCase() === 'true';
    case 'int':
      return parseInt(s, 10) || 0;
    case 'float':
      return parseFloat(s) || 0.0;
    case 'color':
      return parseInt(s.replace(/^#/, ''), 16) || 0x2b2d31;
    case 'roleList':
    case 'channelList':
    case 'stringList':
      try { return JSON.parse(s); } catch (_) { return []; }
    default:
      return s;
  }
}

function stringifyValue(val, type) {
  if (val === null || val === undefined) return '';
  switch (type) {
    case 'bool':
      return val ? '1' : '0';
    case 'roleList':
    case 'channelList':
    case 'stringList':
      return JSON.stringify(Array.isArray(val) ? val : []);
    default:
      return String(val);
  }
}

function validateAndCoerce(val, def) {
  switch (def.type) {
    case 'bool':
      return Boolean(val);
    case 'int': {
      let num = parseInt(val, 10);
      if (isNaN(num)) num = def.default;
      if (def.min !== undefined && num < def.min) num = def.min;
      if (def.max !== undefined && num > def.max) num = def.max;
      return num;
    }
    case 'enum': {
      const s = String(val).toLowerCase();
      if (def.options && !def.options.includes(s)) {
        throw new Error(`Invalid value for ${def.key}. Must be one of: ${def.options.join(', ')}`);
      }
      return s;
    }
    default:
      return val;
  }
}

module.exports = {
  can,
  REGISTRY,
  registerSetting,
  getSetting,
  setSetting,
  getSettingDefinition,
  getAllDefinitions,
  getDefinitionsForPage,
  invalidateGuildSettings,
  settingsEvents
};
