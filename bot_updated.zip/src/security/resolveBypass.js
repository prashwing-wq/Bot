/**
 * Tungsten Security Framework - Unified Bypass Resolver
 * Single resolution engine for all antinuke, security, and automod bypass queries.
 *
 * Precedence Order:
 * 1. Guild Owner (guild.ownerId)
 * 2. Extra Owner (extraowners table)
 * 3. User Whitelist Grant (whitelisted_users table)
 * 4. Role Whitelist Grant (whitelisted_roles table)
 * 5. Channel Whitelist Grant (whitelisted_channels table)
 */

const { getServerDb } = require('../utils/serverDb');
const { mapVectorToScope, mapAutomodToScope } = require('./scopes');

// High-speed in-memory resolution cache (TTL: 15 seconds)
const _BYPASS_CACHE = new Map();
const BYPASS_CACHE_TTL = 15000;

/**
 * Resolves whether a subject (user, member, or role) has bypass permission for a given scope.
 *
 * @param {Object} guild - Discord Guild instance or { id, ownerId }
 * @param {Object|string} subject - GuildMember, User, or Snowflake ID
 * @param {string} [requestedScope='all'] - Scope or threat vector to check
 * @param {Object} [options={}] - Options: bypassCache, channelId
 * @returns {Object} { bypassed: boolean, reason: string, expiresAt: number|null }
 */
function resolveBypass(guild, subject, requestedScope = 'all', options = {}) {
  if (!guild || !guild.id) {
    return { bypassed: false, reason: 'no_guild', expiresAt: null };
  }

  const gid = String(guild.id);
  const userId = typeof subject === 'string'
    ? subject
    : (subject?.id || subject?.user?.id);

  if (!userId) {
    return { bypassed: false, reason: 'no_user_id', expiresAt: null };
  }

  const scope = String(requestedScope || 'all').toLowerCase();
  const cacheKey = `${gid}:${userId}:${scope}:${options.channelId || 'none'}`;
  const nowMs = Date.now();
  const nowSec = Math.floor(nowMs / 1000);

  // 1. Fast Cache Check
  if (!options.bypassCache) {
    const cached = _BYPASS_CACHE.get(cacheKey);
    if (cached && nowMs < cached.expires) {
      return cached.result;
    }
  }

  let result = null;

  try {
    // 2. Precedence 1: Guild Owner (Absolute Server Authority)
    if (guild.ownerId && String(guild.ownerId) === String(userId)) {
      result = { bypassed: true, reason: 'guild_owner', expiresAt: null };
    }

    // 3. Precedence 2: Extra Owner (Trusted Executive Authority)
    else {
      const sdb = getServerDb(gid);
      const isExtra = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(gid, userId);
      if (isExtra) {
        result = { bypassed: true, reason: 'extra_owner', expiresAt: null };
      }
    }

    if (!result) {
      const sdb = getServerDb(gid);

      // Determine matching scope keys: exact scope, 'all', or mapped vector scope
      const candidateScopes = new Set([scope, 'all', '*']);
      const mappedScope = mapVectorToScope(scope);
      if (mappedScope) candidateScopes.add(mappedScope);
      const mappedAutomod = mapAutomodToScope(scope);
      if (mappedAutomod) candidateScopes.add(mappedAutomod);

      const scopeList = Array.from(candidateScopes);
      const placeholders = scopeList.map(() => '?').join(',');

      // 5. Precedence 4: Explicit User Whitelist Grant
      const userGrant = sdb.prepare(`
        SELECT action, expires_at
        FROM whitelisted_users
        WHERE guild_id = ? AND user_id = ? AND action IN (${placeholders})
        ORDER BY CASE WHEN action = 'all' THEN 1 ELSE 0 END DESC
        LIMIT 1
      `).get(gid, userId, ...scopeList);

      if (userGrant) {
        if (!userGrant.expires_at || userGrant.expires_at > nowSec) {
          result = {
            bypassed: true,
            reason: 'user_grant',
            action: userGrant.action,
            expiresAt: userGrant.expires_at || null
          };
        }
      }

      // 6. Precedence 5: Role Whitelist Grant
      if (!result && subject && typeof subject === 'object' && subject.roles?.cache) {
        const memberRoleIds = Array.from(subject.roles.cache.keys());
        if (memberRoleIds.length > 0) {
          const rolePlaceholders = memberRoleIds.map(() => '?').join(',');
          const roleGrant = sdb.prepare(`
            SELECT role_id, action, expires_at
            FROM whitelisted_roles
            WHERE guild_id = ? AND role_id IN (${rolePlaceholders}) AND action IN (${placeholders})
            ORDER BY CASE WHEN action = 'all' THEN 1 ELSE 0 END DESC
            LIMIT 1
          `).get(gid, ...memberRoleIds, ...scopeList);

          if (roleGrant) {
            if (!roleGrant.expires_at || roleGrant.expires_at > nowSec) {
              result = {
                bypassed: true,
                reason: 'role_grant',
                roleId: roleGrant.role_id,
                action: roleGrant.action,
                expiresAt: roleGrant.expires_at || null
              };
            }
          }
        }
      }

      // 7. Precedence 6: Channel Whitelist Scope
      if (!result && options.channelId) {
        const channelGrant = sdb.prepare(`
          SELECT channel_id, scope
          FROM whitelisted_channels
          WHERE guild_id = ? AND channel_id = ? AND scope IN (${placeholders})
          LIMIT 1
        `).get(gid, String(options.channelId), ...scopeList);

        if (channelGrant) {
          result = {
            bypassed: true,
            reason: 'channel_grant',
            channelId: channelGrant.channel_id,
            action: channelGrant.scope,
            expiresAt: null
          };
        }
      }
    }
  } catch (err) {
    console.error(`[resolveBypass Error] in guild ${gid} for user ${userId}:`, err.message);
    // Fail-safe closed: on DB exception, return false (never grant unauthorized bypass)
    result = { bypassed: false, reason: 'error', error: err.message, expiresAt: null };
  }

  if (!result) {
    result = { bypassed: false, reason: 'unauthorized', expiresAt: null };
  }

  // Cache resolution
  _BYPASS_CACHE.set(cacheKey, {
    result,
    expires: nowMs + BYPASS_CACHE_TTL
  });

  return result;
}

/**
 * Invalidates cached bypass resolutions for a guild or specific user.
 *
 * @param {string} guildId
 * @param {string} [userId=null]
 */
function invalidateBypassCache(guildId, userId = null) {
  if (!guildId) {
    _BYPASS_CACHE.clear();
    return;
  }
  const gidPrefix = `${guildId}:`;
  const targetPrefix = userId ? `${guildId}:${userId}:` : gidPrefix;

  for (const key of _BYPASS_CACHE.keys()) {
    if (key.startsWith(targetPrefix)) {
      _BYPASS_CACHE.delete(key);
    }
  }
}

/**
 * Clean up expired grants from the database and invalidate affected caches.
 * Called periodically by unified scheduler.
 *
 * @param {string} guildId
 * @returns {number} count of purged records
 */
function purgeExpiredGrants(guildId) {
  if (!guildId) return 0;
  const gid = String(guildId);
  const nowSec = Math.floor(Date.now() / 1000);
  let purged = 0;

  try {
    const sdb = getServerDb(gid);

    // 1. Audit and purge expired users
    const expiredUsers = sdb.prepare(`
      SELECT user_id, action
      FROM whitelisted_users
      WHERE guild_id = ? AND expires_at IS NOT NULL AND expires_at <= ?
    `).all(gid, nowSec);

    for (const u of expiredUsers) {
      try {
        sdb.prepare(`
          INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp)
          VALUES (?, 'user', ?, ?, 'system_purge', 'expired', ?)
        `).run(gid, u.user_id, u.action, nowSec);
      } catch (_) {}
    }

    const delUsers = sdb.prepare(`
      DELETE FROM whitelisted_users
      WHERE guild_id = ? AND expires_at IS NOT NULL AND expires_at <= ?
    `).run(gid, nowSec);
    purged += delUsers.changes || 0;

    // 2. Audit and purge expired roles
    const expiredRoles = sdb.prepare(`
      SELECT role_id, action
      FROM whitelisted_roles
      WHERE guild_id = ? AND expires_at IS NOT NULL AND expires_at <= ?
    `).all(gid, nowSec);

    for (const r of expiredRoles) {
      try {
        sdb.prepare(`
          INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp)
          VALUES (?, 'role', ?, ?, 'system_purge', 'expired', ?)
        `).run(gid, r.role_id, r.action, nowSec);
      } catch (_) {}
    }

    const delRoles = sdb.prepare(`
      DELETE FROM whitelisted_roles
      WHERE guild_id = ? AND expires_at IS NOT NULL AND expires_at <= ?
    `).run(gid, nowSec);
    purged += delRoles.changes || 0;

    if (purged > 0) {
      invalidateBypassCache(gid);
    }
  } catch (err) {
    console.warn(`[purgeExpiredGrants Exception] in ${gid}:`, err.message);
  }

  return purged;
}

module.exports = {
  resolveBypass,
  invalidateBypassCache,
  purgeExpiredGrants,
  _BYPASS_CACHE
};
