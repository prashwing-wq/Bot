/**
 * Tungsten Security Framework - Unified Scopes Registry
 * Single source of truth for all security, antinuke, and automod bypass scopes.
 */

const DANGER_TIERS = Object.freeze({
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high'
});

const WHITELIST_SCOPES = Object.freeze({
  all: {
    key: 'all',
    label: 'Full Bypass (All Vectors)',
    description: 'Total bypass across all antinuke threat vectors and automod filters.',
    dangerTier: DANGER_TIERS.HIGH,
    vectors: [
      'bot_add',
      'channel_delete',
      'channel_create',
      'channel_update',
      'role_delete',
      'role_create',
      'role_update',
      'ban',
      'kick',
      'prune',
      'webhook',
      'emoji',
      'sticker',
      'server_update',
      'vanity',
      'everyone_ping'
    ],
    automodFilters: ['*']
  },
  channels: {
    key: 'channels',
    label: 'Channels Management',
    description: 'Bypass for channel deletion, creation, and configuration updates.',
    dangerTier: DANGER_TIERS.HIGH,
    vectors: ['channel_delete', 'channel_create', 'channel_update'],
    automodFilters: []
  },
  roles: {
    key: 'roles',
    label: 'Roles Management',
    description: 'Bypass for role deletion, creation, permission updates, and escalation.',
    dangerTier: DANGER_TIERS.HIGH,
    vectors: ['role_delete', 'role_create', 'role_update'],
    automodFilters: []
  },
  members: {
    key: 'members',
    label: 'Member Moderation',
    description: 'Bypass for member bans, kicks, and member pruning.',
    dangerTier: DANGER_TIERS.HIGH,
    vectors: ['ban', 'kick', 'prune'],
    automodFilters: []
  },
  bots: {
    key: 'bots',
    label: 'Bot Integration',
    description: 'Bypass for adding authorized bots and server integrations.',
    dangerTier: DANGER_TIERS.HIGH,
    vectors: ['bot_add'],
    automodFilters: []
  },
  webhooks: {
    key: 'webhooks',
    label: 'Webhooks Management',
    description: 'Bypass for creating and executing webhooks.',
    dangerTier: DANGER_TIERS.MEDIUM,
    vectors: ['webhook'],
    automodFilters: []
  },
  server: {
    key: 'server',
    label: 'Server Configuration',
    description: 'Bypass for server settings modifications and vanity URL changes.',
    dangerTier: DANGER_TIERS.HIGH,
    vectors: ['server_update', 'vanity'],
    automodFilters: []
  },
  emojis: {
    key: 'emojis',
    label: 'Emojis & Stickers',
    description: 'Bypass for creating and deleting server emojis and stickers.',
    dangerTier: DANGER_TIERS.LOW,
    vectors: ['emoji', 'sticker'],
    automodFilters: []
  },
  ping: {
    key: 'ping',
    label: 'Mass Mentions (@everyone / @here)',
    description: 'Bypass for mass @everyone and @here pings.',
    dangerTier: DANGER_TIERS.MEDIUM,
    vectors: ['everyone_ping'],
    automodFilters: ['mass_mentions']
  },
  automod_links: {
    key: 'automod_links',
    label: 'Automod: Links & Invites',
    description: 'Bypass automod link filtering, Discord invites, and URL shortener blockers.',
    dangerTier: DANGER_TIERS.MEDIUM,
    vectors: [],
    automodFilters: ['invites', 'links', 'shorteners']
  },
  automod_spam: {
    key: 'automod_spam',
    label: 'Automod: Anti-Spam & Flooding',
    description: 'Bypass message spam, repeat messages, caps flooding, and fast typing filters.',
    dangerTier: DANGER_TIERS.LOW,
    vectors: [],
    automodFilters: ['spam', 'duplicates', 'caps', 'fast_typing']
  },
  automod_words: {
    key: 'automod_words',
    label: 'Automod: Banned Words & Leet',
    description: 'Bypass banned words, leetspeak, and filtered phrases.',
    dangerTier: DANGER_TIERS.LOW,
    vectors: [],
    automodFilters: ['banned_words', 'profanity', 'zalgo']
  }
});

/**
 * Validates whether a scope key is recognized.
 * @param {string} key
 * @returns {boolean}
 */
const SCOPE_ALIASES = Object.freeze({
  channel: 'channels',
  role: 'roles',
  ban: 'members',
  kick: 'members',
  prune: 'members',
  member: 'members',
  bot: 'bots',
  webhook: 'webhooks',
  emoji: 'emojis',
  sticker: 'emojis',
  stickers: 'emojis',
  everyone: 'ping',
  pings: 'ping',
  everyone_ping: 'ping',
  link: 'automod_links',
  links: 'automod_links',
  shorteners: 'automod_links',
  spam: 'automod_spam',
  flooding: 'automod_spam',
  word: 'automod_words',
  words: 'automod_words',
  profanity: 'automod_words',
  automod: 'automod_links'
});

/**
 * Normalizes a scope string, resolving aliases if needed.
 * @param {string} key
 * @returns {string}
 */
function normalizeScope(key) {
  if (!key || typeof key !== 'string') return '';
  const lower = key.trim().toLowerCase();
  if (WHITELIST_SCOPES[lower]) return lower;
  return SCOPE_ALIASES[lower] || lower;
}

function isValidScope(key) {
  if (!key || typeof key !== 'string') return false;
  const normalized = normalizeScope(key);
  return Boolean(WHITELIST_SCOPES[normalized]);
}

/**
 * Retrieves scope definition by key.
 * @param {string} key
 * @returns {Object|null}
 */
function getScope(key) {
  if (!key || typeof key !== 'string') return null;
  const normalized = normalizeScope(key);
  return WHITELIST_SCOPES[normalized] || null;
}

/**
 * Checks if a scope has high danger tier.
 * @param {string} key
 * @returns {boolean}
 */
function isHighDangerScope(key) {
  const scope = getScope(key);
  return Boolean(scope && scope.dangerTier === DANGER_TIERS.HIGH);
}

/**
 * Returns list of scopes filtered by danger tier.
 * @param {string} tier ('low'|'medium'|'high')
 * @returns {Array<Object>}
 */
function getScopesByTier(tier) {
  return Object.values(WHITELIST_SCOPES).filter(s => s.dangerTier === tier);
}

/**
 * Maps an antinuke threat vector key to its corresponding scope.
 * @param {string} vector
 * @returns {string} scope key
 */
function mapVectorToScope(vector) {
  const v = String(vector || '').toLowerCase();
  for (const [scopeKey, def] of Object.entries(WHITELIST_SCOPES)) {
    if (scopeKey === 'all') continue;
    if (def.vectors && def.vectors.includes(v)) {
      return scopeKey;
    }
  }
  return 'all';
}

/**
 * Maps an automod filter key to its corresponding scope.
 * @param {string} filter
 * @returns {string} scope key
 */
function mapAutomodToScope(filter) {
  const f = String(filter || '').toLowerCase();
  for (const [scopeKey, def] of Object.entries(WHITELIST_SCOPES)) {
    if (scopeKey === 'all') continue;
    if (def.automodFilters && def.automodFilters.includes(f)) {
      return scopeKey;
    }
  }
  return 'all';
}

module.exports = {
  DANGER_TIERS,
  WHITELIST_SCOPES,
  SCOPES: WHITELIST_SCOPES,
  SCOPE_ALIASES,
  normalizeScope,
  isValidScope,
  getScope,
  isHighDangerScope,
  getScopesByTier,
  mapVectorToScope,
  mapAutomodToScope
};
