/**
 * Tungsten UI Design System - Components V2 Kit
 * Modern, calm, dense Type 17 Container architecture using discord.js builders.
 */

const {
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  SeparatorBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  StringSelectMenuBuilder,
  ButtonStyle,
  MessageFlags
} = require('discord.js');

const { COLORS, getStateAccent, sanitizeAccent } = require('./tokens');
const { ICONS, getIcon } = require('./icons');
const { badge } = require('./copy');
const { isSelectMenuRow, isSelectMenuComponent } = require('../utils/patchComponentsV2');

// Discord Components V2 Flag
const IS_COMPONENTS_V2 = MessageFlags.IsComponentsV2 || 32768;

/**
 * Creates standard panel header text component.
 * e.g. "## Antinuke\nArmed · 14 of 16 protections on"
 *
 * @param {string} title
 * @param {string} [status]
 * @returns {TextDisplayBuilder}
 */
function header(title, status = null) {
  const cleanTitle = String(title || '').trim();
  const text = status ? `## ${cleanTitle}\n${String(status).trim()}` : `## ${cleanTitle}`;
  const builder = new TextDisplayBuilder().setContent(text);
  builder.toString = () => text;
  return builder;
}

/**
 * Formats a list of facts as clean, compact key-value bullet points.
 *
 * @param {Array<Object|string>|Object} factList
 * @returns {TextDisplayBuilder|null}
 */
function facts(factList) {
  if (!factList) return null;
  const lines = [];

  if (Array.isArray(factList)) {
    for (const item of factList) {
      if (!item) continue;
      if (typeof item === 'string') {
        lines.push(item.startsWith('•') || item.startsWith('-') ? item : `• ${item}`);
      } else if (typeof item === 'object') {
        const label = item.label || item.name || item.key;
        const val = item.value || item.val || '';
        if (label) {
          lines.push(`• **${label}:** ${val}`);
        }
      }
    }
  } else if (typeof factList === 'object') {
    for (const [key, val] of Object.entries(factList)) {
      if (val !== undefined && val !== null) {
        lines.push(`• **${key}:** ${val}`);
      }
    }
  } else if (typeof factList === 'string') {
    lines.push(factList);
  }

  if (lines.length === 0) return null;
  const text = lines.join('\n');
  const builder = new TextDisplayBuilder().setContent(text);
  builder.toString = () => text;
  return builder;
}

/**
 * Formats a clean list of items.
 *
 * @param {string[]} items
 * @param {Object} [options]
 * @param {boolean} [options.numbered=false]
 * @returns {TextDisplayBuilder|null}
 */
function list(items, { numbered = false } = {}) {
  if (!items || !Array.isArray(items) || items.length === 0) return null;
  const lines = items.map((item, idx) => {
    const prefix = numbered ? `${idx + 1}.` : '•';
    return `${prefix} ${item}`;
  });
  const text = lines.join('\n');
  const builder = new TextDisplayBuilder().setContent(text);
  builder.toString = () => text;
  return builder;
}

/**
 * Creates a Discord Components V2 Section component with a text display and an accessory button.
 *
 * @param {Object} options
 * @param {string} options.title - Section title / label
 * @param {string} [options.hint] - Optional subtext or hint
 * @param {ButtonBuilder|Object} [options.accessory] - Button accessory
 * @returns {SectionBuilder}
 */
function section({ title, hint = null, accessory = null }) {
  let content = String(title || '').trim();
  if (hint) {
    const hintText = String(hint).trim();
    const formattedHint = hintText.startsWith('-#') ? hintText : `-# ${hintText}`;
    content = content ? `${content}\n${formattedHint}` : formattedHint;
  }

  if (!accessory) {
    return new TextDisplayBuilder().setContent(content);
  }

  const sec = new SectionBuilder();
  sec.addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

  if (accessory instanceof ButtonBuilder) {
    sec.setButtonAccessory(accessory);
  } else if (typeof accessory === 'object') {
    const btn = new ButtonBuilder()
      .setCustomId(accessory.customId || 'btn_action')
      .setLabel(accessory.label || 'Action')
      .setStyle(accessory.style || ButtonStyle.Secondary);
    if (accessory.emoji) btn.setEmoji(accessory.emoji);
    if (accessory.disabled !== undefined) btn.setDisabled(Boolean(accessory.disabled));
    sec.setButtonAccessory(btn);
  }

  return sec;
}

/**
 * Creates a toggle row with an accessory button (e.g. On/Off or Allow/Revoke).
 *
 * @param {Object} options
 * @param {string} options.label - Feature or scope label
 * @param {string} [options.hint] - Subtext or setting explanation
 * @param {boolean} options.enabled - Current active state
 * @param {string} options.customId - Action ID for the button
 * @param {boolean} [options.allowRevoke=false] - If true, uses Allow/Revoke labels instead of On/Off
 * @param {string} [options.onLabel] - Custom label when turned on
 * @param {string} [options.offLabel] - Custom label when turned off
 * @param {boolean} [options.showBadge=true] - Whether to include state badge in label
 * @returns {SectionBuilder}
 */
function toggleRow({
  label,
  hint = null,
  enabled,
  customId,
  allowRevoke = false,
  onLabel = null,
  offLabel = null,
  showBadge = true
}) {
  const isEnabled = Boolean(enabled);

  let activeLabel;
  let inactiveLabel;

  if (allowRevoke) {
    activeLabel = offLabel || 'Revoke';
    inactiveLabel = onLabel || 'Allow';
  } else {
    activeLabel = offLabel || 'Off';
    inactiveLabel = onLabel || 'On';
  }

  const btnLabel = isEnabled ? activeLabel : inactiveLabel;
  const btnStyle = isEnabled ? ButtonStyle.Danger : ButtonStyle.Secondary;

  const btn = new ButtonBuilder()
    .setCustomId(customId)
    .setLabel(btnLabel)
    .setStyle(btnStyle);

  const title = showBadge
    ? `${label}  ${badge(isEnabled ? 'On' : 'Off')}`
    : label;

  return section({ title, hint, accessory: btn });
}

/**
 * Creates a warning, danger, or info notice block.
 *
 * @param {Object} options
 * @param {'info'|'warning'|'danger'|'success'} [options.type='info']
 * @param {string} options.title - Notice title
 * @param {string} [options.body] - Notice body or instructions
 * @param {ButtonBuilder|Object} [options.action] - Optional button action
 * @returns {SectionBuilder|TextDisplayBuilder}
 */
function notice({ type = 'info', title, body = null, action = null }) {
  let icon = ICONS.info;
  if (type === 'danger') icon = ICONS.danger;
  else if (type === 'warning') icon = ICONS.warning;
  else if (type === 'success') icon = ICONS.check;

  let text = `### ${icon} ${title}`;
  if (body) {
    text += `\n${body}`;
  }

  if (action) {
    const sec = new SectionBuilder();
    sec.addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
    if (action instanceof ButtonBuilder) {
      sec.setButtonAccessory(action);
    } else if (typeof action === 'object') {
      const btn = new ButtonBuilder()
        .setCustomId(action.customId || 'btn_notice')
        .setLabel(action.label || 'Action')
        .setStyle(action.style || (type === 'danger' ? ButtonStyle.Danger : ButtonStyle.Secondary));
      if (action.emoji) btn.setEmoji(action.emoji);
      sec.setButtonAccessory(btn);
    }
    return sec;
  }

  const builder = new TextDisplayBuilder().setContent(text);
  builder.toString = () => text;
  return builder;
}

/**
 * Creates a two-step confirmation dialog with Confirm and Cancel buttons.
 *
 * @param {Object} options
 * @param {string} [options.title='Confirm Action']
 * @param {string} options.body - Warning and explanation of consequences
 * @param {string} options.confirmId - CustomId for confirm button
 * @param {string} options.cancelId - CustomId for cancel button
 * @param {string} [options.confirmLabel='Confirm']
 * @param {string} [options.cancelLabel='Cancel']
 * @param {boolean} [options.danger=true] - Whether action is destructive
 * @returns {Object} Discord Components V2 Container message payload
 */
function confirm({
  title = 'Confirm Action',
  body,
  message,
  confirmId,
  cancelId,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  danger = true
}) {
  const container = new ContainerBuilder();
  container.setAccentColor(danger ? COLORS.danger : COLORS.warning);

  const icon = danger ? ICONS.danger : ICONS.warning;
  const headerContent = `## ${icon} ${title}`;
  const textContent = message || body;
  const fullBody = textContent ? `${headerContent}\n${textContent}` : headerContent;
  container.addTextDisplayComponents(new TextDisplayBuilder().setContent(fullBody));

  const cancelBtn = new ButtonBuilder()
    .setCustomId(cancelId)
    .setLabel(cancelLabel)
    .setStyle(ButtonStyle.Secondary);

  const confirmBtn = new ButtonBuilder()
    .setCustomId(confirmId)
    .setLabel(confirmLabel)
    .setStyle(danger ? ButtonStyle.Danger : ButtonStyle.Primary);

  const row = new ActionRowBuilder().addComponents(cancelBtn, confirmBtn);
  container.addActionRowComponents(row);

  return {
    flags: IS_COMPONENTS_V2,
    components: [container]
  };
}

/**
 * Creates standard navigation pagination ActionRow (Back, [Page/Total], Next, Home, Close).
 *
 * @param {Object} options
 * @param {number} [options.page]
 * @param {number} [options.totalPages]
 * @param {string} [options.prevId]
 * @param {string} [options.nextId]
 * @param {string} [options.homeId]
 * @param {string} [options.closeId]
 * @returns {ActionRowBuilder}
 */
function pager({ page, totalPages, prevId, nextId, homeId, closeId }) {
  const row = new ActionRowBuilder();

  if (prevId) {
    const isFirst = typeof page === 'number' && page <= 1;
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(prevId)
        .setLabel('Back')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji(ICONS.arrowLeft)
        .setDisabled(isFirst)
    );
  }

  if (typeof page === 'number' && typeof totalPages === 'number') {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('pager_indicator')
        .setLabel(`${page} / ${totalPages}`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );
  }

  if (nextId) {
    const isLast = typeof page === 'number' && typeof totalPages === 'number' && page >= totalPages;
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(nextId)
        .setLabel('Next')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji(ICONS.arrowRight)
        .setDisabled(isLast)
    );
  }

  if (homeId) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(homeId)
        .setLabel('Home')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji(ICONS.home)
    );
  }

  if (closeId) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(closeId)
        .setLabel('Close')
        .setStyle(ButtonStyle.Danger)
        .setEmoji(ICONS.cross)
    );
  }

  return row;
}

/**
 * Creates an empty state card inviting action.
 *
 * @param {Object} options
 * @param {string} [options.title='No items found']
 * @param {string} [options.hint]
 * @param {ButtonBuilder|Object} [options.actionButton]
 * @returns {SectionBuilder|TextDisplayBuilder}
 */
function empty({ title = 'No items found', hint = null, actionButton = null }) {
  if (actionButton) {
    return section({
      title: `**${title}**`,
      hint,
      accessory: actionButton
    });
  }

  const content = hint ? `**${title}**\n-# ${hint}` : `**${title}**`;
  const builder = new TextDisplayBuilder().setContent(content);
  builder.toString = () => content;
  return builder;
}

/**
 * Creates standard footer subtext (-# text).
 *
 * @param {string} text
 * @returns {TextDisplayBuilder}
 */
function footer(text) {
  const clean = String(text || '').trim();
  const content = clean.startsWith('-#') ? clean : `-# ${clean}`;
  const builder = new TextDisplayBuilder().setContent(content);
  builder.toString = () => content;
  return builder;
}

/**
 * Creates a standard Separator component.
 *
 * @param {Object} [options]
 * @param {boolean} [options.divider=true]
 * @param {number} [options.spacing]
 * @returns {SeparatorBuilder}
 */
function separator({ divider = true, spacing = null } = {}) {
  const sep = new SeparatorBuilder().setDivider(Boolean(divider));
  if (spacing !== null && spacing !== undefined) {
    sep.setSpacing(spacing);
  }
  return sep;
}

/**
 * Builds a complete Components V2 Type 17 Container payload.
 *
 * @param {Object} options
 * @param {string} [options.title] - Header title
 * @param {string} [options.status] - Status line beneath title
 * @param {string} [options.description] - Main body text
 * @param {number|string} [options.color] - Container accent color override
 * @param {Array<SectionBuilder|Object>} [options.sections] - Sections with accessories
 * @param {Array|Object} [options.facts] - Key/value facts list
 * @param {string} [options.footer] - Footer subtext
 * @param {Array<ActionRowBuilder|ButtonBuilder>} [options.rows] - ActionRows or button lists
 * @param {Array} [options.containerComponents] - Custom raw container components
 * @returns {Object} Discord API message payload { flags: 32768, components: [container] }
 */
function panel({
  title = null,
  status = null,
  description = null,
  color = null,
  sections = null,
  facts: factList = null,
  footer: footerText = null,
  rows = null,
  containerComponents = null
} = {}) {
  const container = new ContainerBuilder();
  const selectRows = [];

  // 1. Accent color
  const accent = sanitizeAccent(color !== null && color !== undefined ? color : getStateAccent(status));
  container.setAccentColor(accent);

  // 2. Header
  if (title) {
    container.addTextDisplayComponents(header(title, status));
  } else if (status) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(String(status)));
  }

  // 3. Description
  if (description) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(String(description)));
  }

  // 4. Facts
  if (factList) {
    const f = factList instanceof TextDisplayBuilder ? factList : facts(factList);
    if (f) container.addTextDisplayComponents(f);
  }

  // 5. Sections
  if (Array.isArray(sections)) {
    for (const s of sections) {
      if (!s) continue;
      if (s instanceof SectionBuilder) {
        container.addSectionComponents(s);
      } else if (s instanceof TextDisplayBuilder) {
        container.addTextDisplayComponents(s);
      } else if (typeof s === 'object' && s.title) {
        const built = section(s);
        if (built instanceof SectionBuilder) {
          container.addSectionComponents(built);
        } else if (built instanceof TextDisplayBuilder) {
          container.addTextDisplayComponents(built);
        }
      }
    }
  }

  // 6. Additional container components (Separators, raw sections, etc.)
  if (Array.isArray(containerComponents)) {
    for (const c of containerComponents) {
      if (!c) continue;
      if (c instanceof SectionBuilder) container.addSectionComponents(c);
      else if (c instanceof TextDisplayBuilder) container.addTextDisplayComponents(c);
      else if (c instanceof SeparatorBuilder) container.addSeparatorComponents(c);
      else if (c instanceof ActionRowBuilder) {
        if (isSelectMenuRow(c)) {
          selectRows.push(c);
        } else {
          container.addActionRowComponents(c);
        }
      }
    }
  }

  // 7. Footer
  if (footerText) {
    const foot = footerText instanceof TextDisplayBuilder ? footerText : footer(footerText);
    container.addTextDisplayComponents(foot);
  }

  // 8. ActionRows
  if (Array.isArray(rows) && rows.length > 0) {
    const actionRows = [];
    let pendingButtons = [];

    for (const item of rows) {
      if (!item) continue;
      if (item instanceof ActionRowBuilder || (item.components && Array.isArray(item.components))) {
        if (pendingButtons.length > 0) {
          actionRows.push(new ActionRowBuilder().addComponents(pendingButtons));
          pendingButtons = [];
        }
        if (isSelectMenuRow(item)) {
          selectRows.push(item);
        } else {
          actionRows.push(item);
        }
      } else if (isSelectMenuComponent(item)) {
        if (pendingButtons.length > 0) {
          actionRows.push(new ActionRowBuilder().addComponents(pendingButtons));
          pendingButtons = [];
        }
        selectRows.push(new ActionRowBuilder().addComponents(item));
      } else if (item instanceof ButtonBuilder || item.customId) {
        const btn = item instanceof ButtonBuilder ? item : new ButtonBuilder(item);
        pendingButtons.push(btn);
        if (pendingButtons.length === 5) {
          actionRows.push(new ActionRowBuilder().addComponents(pendingButtons));
          pendingButtons = [];
        }
      }
    }

    if (pendingButtons.length > 0) {
      actionRows.push(new ActionRowBuilder().addComponents(pendingButtons));
    }

    if (actionRows.length > 0) {
      container.addActionRowComponents(...actionRows.slice(0, 5));
    }
  }

  return {
    flags: IS_COMPONENTS_V2,
    components: [container, ...selectRows].slice(0, 5)
  };
}

module.exports = {
  panel,
  header,
  facts,
  list,
  section,
  toggleRow,
  notice,
  confirm,
  pager,
  empty,
  footer,
  separator
};
