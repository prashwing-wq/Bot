/**
 * Tungsten UI Design System - Icons
 * Curated set of semantic custom animated icons from E (Discord animated custom emojis).
 * High-contrast, brand-aligned bespoke animated emojis with resilient fallbacks.
 */
const { E } = require('../utils/emojis');

const ICONS = Object.freeze({
  shield: E.tungsten_shield || E.tungsten_cat_security || '<a:tungsten_shield:1567242104923627574>',
  channel: E.tungsten_cat_channels || E.tungsten_chat || '<a:tungsten_cat_channels:1567233777024110652>',
  role: E.tungsten_cat_roles || '<a:tungsten_cat_roles:1567234100975378512>',
  ban: E.tungsten_an_ban || '<a:tungsten_an_ban:1567232483743895684>',
  kick: E.tungsten_an_kick || '<a:tungsten_an_kick:1567232757330083940>',
  settings: E.tungsten_gear || '<a:tungsten_gear:1567239932970406012>',
  check: E.tungsten_success || '<a:tungsten_success:1567242523468890274>',
  cross: E.tungsten_close || '<a:tungsten_close:1567234632905138206>',
  info: E.tungsten_info || '<a:tungsten_info:1567240890748248084>',
  warning: E.tungsten_warn || '<a:tungsten_warn:1567246685082746940>',
  danger: E.tungsten_siren || E.tungsten_alarm || '<a:tungsten_siren:1567242157725712555>',
  undo: E.tungsten_refresh || '<a:tungsten_refresh:1567241907116187658>',
  history: E.tungsten_scroll || '<a:tungsten_scroll:1567242059708899381>',
  clock: E.tungsten_stopwatch || '<a:tungsten_stopwatch:1567242453562687558>',
  user: E.tungsten_user || '<a:tungsten_user:1567246556778995802>',
  search: E.tungsten_search || '<a:tungsten_search:1567242081167216771>',
  lock: E.tungsten_lock || '<a:tungsten_lock:1567241079030550668>',
  unlock: E.tungsten_unlock || '<a:tungsten_unlock:1567246515209117968>',
  refresh: E.tungsten_refresh || '<a:tungsten_refresh:1567241907116187658>',
  stats: E.tungsten_chart || '<a:tungsten_chart:1567234342701367357>',
  bot: E.tungsten_bot || '<a:tungsten_bot:1567233522635247781>',
  link: E.tungsten_link || '<a:tungsten_link:1567241025813086210>',
  sparkles: E.tungsten_sparkle || '<a:tungsten_sparkle:1567242264311369839>',
  home: E.tungsten_home || '<a:tungsten_home:1567240545661620387>',
  arrowLeft: E.tungsten_arrow_left || '<a:tungsten_arrow_left:1567233111601844267>',
  arrowRight: E.tungsten_arrow_right || '<a:tungsten_arrow_right:1567233126143361135>',

  // Ergonomic aliases
  success: E.tungsten_success || '<a:tungsten_success:1567242523468890274>',
  error: E.tungsten_close || '<a:tungsten_close:1567234632905138206>',
  alert: E.tungsten_siren || E.tungsten_alarm || '<a:tungsten_siren:1567242157725712555>',
  caution: E.tungsten_warn || '<a:tungsten_warn:1567246685082746940>',
  audit: E.tungsten_scroll || '<a:tungsten_scroll:1567242059708899381>',
  config: E.tungsten_gear || '<a:tungsten_gear:1567239932970406012>',
  member: E.tungsten_user || '<a:tungsten_user:1567246556778995802>',
  time: E.tungsten_stopwatch || '<a:tungsten_stopwatch:1567242453562687558>',
  prev: E.tungsten_arrow_left || '<a:tungsten_arrow_left:1567233111601844267>',
  next: E.tungsten_arrow_right || '<a:tungsten_arrow_right:1567233126143361135>',
  back: E.tungsten_arrow_left || '<a:tungsten_arrow_left:1567233111601844267>'
});

// Fast normalized lookup map (handles casing, underscores, and hyphens)
const _NORMALIZED_ICONS = new Map();
for (const [key, icon] of Object.entries(ICONS)) {
  _NORMALIZED_ICONS.set(key, icon);
  _NORMALIZED_ICONS.set(key.toLowerCase(), icon);
  _NORMALIZED_ICONS.set(key.toLowerCase().replace(/[-_]/g, ''), icon);
}

/**
 * Retrieves a semantic icon by key.
 *
 * @param {string} name - Name of semantic icon (e.g. 'shield', 'check', 'arrow_left', 'arrowLeft')
 * @param {string} [style='clean'] - 'clean' (default) or 'expressive'
 * @returns {string} - Animated custom emoji string or empty string if not found
 */
function getIcon(name, style = 'clean') {
  if (!name || typeof name !== 'string') return '';
  const trimmed = name.trim();
  
  if (_NORMALIZED_ICONS.has(trimmed)) {
    return _NORMALIZED_ICONS.get(trimmed);
  }

  const normalized = trimmed.toLowerCase().replace(/[-_]/g, '');
  if (_NORMALIZED_ICONS.has(normalized)) {
    return _NORMALIZED_ICONS.get(normalized);
  }

  return '';
}

module.exports = {
  ICONS,
  getIcon
};
