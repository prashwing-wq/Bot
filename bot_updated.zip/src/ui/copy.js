/**
 * Tungsten UI Design System - Copy & Voice Helpers
 * Restrained, plain-language, sentence case, no marketing fluff or shouting ALL-CAPS.
 */

/**
 * Converts timestamp (seconds or milliseconds) to Discord relative timestamp format.
 *
 * @param {number|Date|string} timestampSecOrMs
 * @returns {string} e.g. `<t:1700000000:R>`
 */
function timeAgo(timestampSecOrMs) {
  if (timestampSecOrMs === null || timestampSecOrMs === undefined || timestampSecOrMs === '') {
    return 'never';
  }

  let sec;
  if (timestampSecOrMs instanceof Date) {
    sec = Math.floor(timestampSecOrMs.getTime() / 1000);
  } else {
    const num = Number(timestampSecOrMs);
    if (Number.isNaN(num) || num <= 0) {
      return String(timestampSecOrMs);
    }
    // If timestamp is in milliseconds (> 1e11), convert to seconds
    sec = num > 1e11 ? Math.floor(num / 1000) : Math.floor(num);
  }

  return `<t:${sec}:R>`;
}

/**
 * Converts timestamp to Discord full format (<t:timestamp:F>).
 *
 * @param {number|Date|string} timestampSecOrMs
 * @returns {string} e.g. `<t:1700000000:F>`
 */
function timeFull(timestampSecOrMs) {
  if (timestampSecOrMs === null || timestampSecOrMs === undefined || timestampSecOrMs === '') {
    return 'never';
  }

  let sec;
  if (timestampSecOrMs instanceof Date) {
    sec = Math.floor(timestampSecOrMs.getTime() / 1000);
  } else {
    const num = Number(timestampSecOrMs);
    if (Number.isNaN(num) || num <= 0) {
      return String(timestampSecOrMs);
    }
    sec = num > 1e11 ? Math.floor(num / 1000) : Math.floor(num);
  }

  return `<t:${sec}:F>`;
}

/**
 * Constructs a clean, dense status line.
 * e.g. "Armed · 14 of 16 protections on · last incident 3 days ago"
 *
 * @param {boolean|string} armed - Armed/Disarmed state or custom status label
 * @param {number} [count] - Number of active protections or items
 * @param {number} [total] - Total number of protections or items
 * @param {number|string} [lastIncident] - Timestamp or relative string of last incident
 * @returns {string}
 */
function statusLine(armed, count, total, lastIncident) {
  const parts = [];

  // 1. Primary Status
  if (typeof armed === 'boolean') {
    parts.push(armed ? 'Armed' : 'Disarmed');
  } else if (typeof armed === 'string' && armed.trim()) {
    parts.push(armed.trim());
  }

  // 2. Count / Total
  if (count !== undefined && count !== null && total !== undefined && total !== null) {
    parts.push(`${count} of ${total} protections on`);
  } else if (count !== undefined && count !== null) {
    parts.push(`${count} protections on`);
  }

  // 3. Last incident
  if (lastIncident !== undefined && lastIncident !== null && lastIncident !== '') {
    if (typeof lastIncident === 'number' || lastIncident instanceof Date) {
      parts.push(`last incident ${timeAgo(lastIncident)}`);
    } else if (typeof lastIncident === 'string') {
      const trimmed = lastIncident.trim();
      if (trimmed.toLowerCase().startsWith('last incident')) {
        parts.push(trimmed);
      } else {
        parts.push(`last incident ${trimmed}`);
      }
    }
  }

  return parts.join(' · ');
}

/**
 * Generates setup health subtext line with Discord subtext markdown (-#).
 * e.g. "-# Setup health: all checks passed"
 *
 * @param {boolean|number|string} passed - Boolean, count passed, or status string
 * @param {number} [count] - Total count of checks if passed is a number
 * @returns {string}
 */
function healthSubtext(passed, count) {
  if (passed === true || (typeof count === 'number' && passed === count)) {
    return '-# Setup health: all checks passed';
  }
  if (passed === false) {
    return '-# Setup health: action required';
  }
  if (typeof passed === 'number' && typeof count === 'number') {
    return `-# Setup health: ${passed} of ${count} checks passed`;
  }
  if (typeof passed === 'string') {
    return passed.startsWith('-#') ? passed : `-# Setup health: ${passed}`;
  }
  return '-# Setup health: normal';
}

/**
 * Generates a clean text badge for toggles and scopes.
 * e.g. [On], [Off], [Allow], [Revoke], [Deny]
 *
 * @param {boolean|string} state
 * @returns {string}
 */
function badge(state) {
  if (typeof state === 'boolean') {
    return state ? '[On]' : '[Off]';
  }
  if (!state || typeof state !== 'string') {
    return '[Off]';
  }

  const s = state.trim().toLowerCase();
  switch (s) {
    case 'on':
    case 'enabled':
    case 'armed':
    case 'active':
      return '[On]';
    case 'off':
    case 'disabled':
    case 'disarmed':
    case 'inactive':
      return '[Off]';
    case 'allow':
    case 'allowed':
      return '[Allow]';
    case 'revoke':
    case 'revoked':
      return '[Revoke]';
    case 'deny':
    case 'denied':
      return '[Deny]';
    case 'warn':
    case 'warning':
      return '[Warn]';
    case 'review':
      return '[Review]';
    default: {
      const clean = state.trim();
      return `[${clean.charAt(0).toUpperCase() + clean.slice(1)}]`;
    }
  }
}

/**
 * Strips Discord custom emoji markup (<a:...:id> or <:...:id>) from text for clean mode.
 *
 * @param {string} text
 * @returns {string}
 */
function stripEmojis(text) {
  if (!text || typeof text !== 'string') return '';
  return text
    .replace(/<a?:[a-zA-Z0-9_]+:\d+>/g, '')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

/**
 * Converts text into clean sentence case.
 *
 * @param {string} text
 * @returns {string}
 */
function sentenceCase(text) {
  if (!text || typeof text !== 'string') return '';
  const trimmed = text.trim();
  if (!trimmed) return '';
  return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
}

module.exports = {
  statusLine,
  healthSubtext,
  timeAgo,
  timeFull,
  badge,
  stripEmojis,
  sentenceCase
};
