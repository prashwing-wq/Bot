/**
 * Tungsten UI Design System - Tokens
 * Semantic color palette, contrast checking, and state accents.
 */

const COLORS = Object.freeze({
  brand: 0x5865F2,        // Tungsten Blurple
  neutral: 0x2B2D31,      // Dark theme container background
  neutralLight: 0x313338, // Card element / secondary background
  info: 0x5865F2,         // Informational / guidance
  success: 0x57F287,      // Mint / armed / active / verified
  warning: 0xFEE75C,      // Amber / review / partial / attention
  danger: 0xED4245        // Crimson / alert / disarmed / attack
});

// Colors that lack sufficient contrast against Discord dark theme containers
const LOW_CONTRAST_COLORS = new Set([
  0,
  0x000000,
  0x000001,
  0x2B2D31,
  0x313338
]);

/**
 * Normalizes and checks color to ensure it has safe contrast on Discord dark themes.
 * Replaces 0x000001, 0, null, undefined, or invisible blacks with brand color (0x5865F2).
 *
 * @param {number|string} color 
 * @param {number} [fallback=COLORS.brand]
 * @returns {number}
 */
function sanitizeAccent(color, fallback = COLORS.brand) {
  if (color === null || color === undefined) return fallback;
  let num;
  if (typeof color === 'string') {
    const clean = color.trim().replace(/^#/, '');
    num = parseInt(clean, 16);
  } else if (typeof color === 'number') {
    num = color;
  } else {
    return fallback;
  }

  if (Number.isNaN(num) || num < 0 || num > 0xFFFFFF) {
    return fallback;
  }

  // Pure black or near-black fails contrast on dark containers
  if (LOW_CONTRAST_COLORS.has(num) || num <= 0x050505) {
    return fallback;
  }

  return num;
}

/**
 * Returns the semantic accent color corresponding to a system state.
 *
 * @param {string|boolean} status
 * @returns {number}
 */
function getStateAccent(status) {
  if (status === true) return COLORS.success;
  if (status === false) return COLORS.danger;
  if (!status || typeof status !== 'string') return COLORS.brand;

  const s = status.trim().toLowerCase();

  // Success / Armed / Healthy / Active
  if (
    s === 'armed' ||
    s === 'active' ||
    s === 'healthy' ||
    s === 'enabled' ||
    s === 'on' ||
    s === 'safe' ||
    s === 'passed' ||
    s.startsWith('armed') ||
    s.startsWith('active') ||
    s.startsWith('healthy')
  ) {
    return COLORS.success;
  }

  // Warning / Partial / Review / Pending / Attention
  if (
    s === 'warning' ||
    s === 'partial' ||
    s === 'review' ||
    s === 'pending' ||
    s === 'attention' ||
    s === 'caution' ||
    s === 'degraded' ||
    s.includes('partial') ||
    s.includes('warning')
  ) {
    return COLORS.warning;
  }

  // Danger / Disarmed / Attack / Alert / Panic / Error / Off
  if (
    s === 'danger' ||
    s === 'disarmed' ||
    s === 'disabled' ||
    s === 'alert' ||
    s === 'panic' ||
    s === 'attack' ||
    s === 'under attack' ||
    s === 'failed' ||
    s === 'error' ||
    s === 'off' ||
    s.startsWith('disarmed') ||
    s.includes('attack') ||
    s.includes('alert')
  ) {
    return COLORS.danger;
  }

  return COLORS.brand;
}

module.exports = {
  COLORS,
  getStateAccent,
  sanitizeAccent
};
