/**
 * Tungsten UI Design System
 * Unified entry point re-exporting tokens, icons, copy helpers, and Components V2 kit.
 */

const tokens = require('./tokens');
const icons = require('./icons');
const copy = require('./copy');
const kit = require('./kit');

module.exports = {
  // Direct named exports
  ...tokens,
  ...icons,
  ...copy,
  ...kit,

  // Module namespaces
  tokens,
  icons,
  copy,
  kit
};
