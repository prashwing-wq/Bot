/**
 * Tungsten Panel Framework Index (Node.js)
 */
const { buildHubPayload } = require('./hub');
const { buildPagePayload, PAGE_METADATA } = require('./page');
const { handlePanelInteraction } = require('./dispatcher');

module.exports = {
  buildHubPayload,
  buildPagePayload,
  handlePanelInteraction,
  PAGE_METADATA
};
