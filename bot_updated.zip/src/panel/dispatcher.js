/**
 * Tungsten Panel Component Dispatcher (Node.js)
 * High-speed router for all `p:<page>:<action>:<arg>:<userId>` interaction components.
 * Enforces strict user locking, permission tier verification, and sub-3-second defer deadlines.
 */
const { MessageFlags } = require('discord.js');
const { getSetting, setSetting, getSettingDefinition, can } = require('../settings/registry');
const { buildPagePayload, PAGE_METADATA } = require('./page');
const { buildHubPayload } = require('./hub');
const { getServerDb } = require('../utils/serverDb');
const { EMOJIS } = require('../utils/emojis');

async function handlePanelInteraction(interaction, client) {
  const parts = interaction.customId.split(':');
  // Format: p:<page>:<action>:<arg>:<userId>
  const pageId = parts[1];
  const action = parts[2];
  const arg = parts[3];
  const authorizedUserId = parts[4];

  // 1. User lock enforcement
  if (authorizedUserId && interaction.user.id !== authorizedUserId) {
    return interaction.reply({
      content: `${EMOJIS.ERROR} This interactive settings panel belongs to another administrator. Run \`!panel\` to open your own.`,
      flags: MessageFlags.Ephemeral
    });
  }

  // 2. Dismiss / Close button
  if (action === 'dismiss') {
    try {
      await interaction.deferUpdate();
      await interaction.message.delete();
    } catch (_) {}
    return;
  }

  // 3. Return to Main Hub
  if (pageId === 'hub' || action === 'open_hub') {
    await interaction.deferUpdate();
    const payload = buildHubPayload(interaction.guild.id, interaction.user.id);
    return interaction.editReply(payload).catch(() => null);
  }

  // 4. Switch Page via Select Menu or Button
  if (action === 'switch_page') {
    await interaction.deferUpdate();
    const targetPage = interaction.values ? interaction.values[0] : arg;
    const payload = buildPagePayload(interaction.guild.id, targetPage, interaction.user.id);
    return interaction.editReply(payload).catch(() => null);
  }

  // 5. Refresh Page
  if (action === 'refresh') {
    await interaction.deferUpdate();
    const payload = buildPagePayload(interaction.guild.id, pageId, interaction.user.id);
    return interaction.editReply(payload).catch(() => null);
  }

  // 6. Undo Last Setting Change (backed by settings_audit)
  if (action === 'undo') {
    await interaction.deferUpdate();
    try {
      const sdb = getServerDb(interaction.guild.id);
      const lastAudit = sdb.prepare(`
        SELECT key, old_val FROM settings_audit
        WHERE guild_id = ?
        ORDER BY id DESC LIMIT 1
      `).get(interaction.guild.id);

      if (lastAudit && lastAudit.key) {
        setSetting(interaction.guild.id, lastAudit.key, lastAudit.old_val, `${interaction.user.id}:undo`);
      }
    } catch (e) {}

    const payload = buildPagePayload(interaction.guild.id, pageId, interaction.user.id);
    return interaction.editReply(payload).catch(() => null);
  }

  // 7. Modifying a Setting: Check permissions
  const def = getSettingDefinition(arg);
  if (!def) {
    await interaction.deferUpdate();
    const payload = buildPagePayload(interaction.guild.id, pageId, interaction.user.id);
    return interaction.editReply(payload).catch(() => null);
  }

  if (!can(interaction.member, def.tier)) {
    return interaction.reply({
      content: `${EMOJIS.ERROR} Permission Denied: You need \`${def.tier.toUpperCase()}\` tier authority to modify **${def.label}**.`,
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferUpdate();

  // Execute modifications
  if (action === 'toggle') {
    const cur = getSetting(interaction.guild.id, def.key);
    setSetting(interaction.guild.id, def.key, !cur, interaction.user.id);
  } else if (action === 'step_inc') {
    const cur = getSetting(interaction.guild.id, def.key);
    setSetting(interaction.guild.id, def.key, cur + 1, interaction.user.id);
  } else if (action === 'step_dec') {
    const cur = getSetting(interaction.guild.id, def.key);
    setSetting(interaction.guild.id, def.key, Math.max(def.min || 0, cur - 1), interaction.user.id);
  } else if (action === 'set_enum') {
    const chosen = interaction.values ? interaction.values[0] : null;
    if (chosen) {
      setSetting(interaction.guild.id, def.key, chosen, interaction.user.id);
    }
  } else if (action === 'set_channel' || action === 'set_role' || action === 'set_user') {
    const chosen = interaction.values ? interaction.values[0] : null;
    if (chosen) {
      setSetting(interaction.guild.id, def.key, chosen, interaction.user.id);
    }
  }

  const payload = buildPagePayload(interaction.guild.id, pageId, interaction.user.id);
  return interaction.editReply(payload).catch(() => null);
}

module.exports = {
  handlePanelInteraction
};
