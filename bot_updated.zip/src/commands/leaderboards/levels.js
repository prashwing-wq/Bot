/**
 * Leveling & Rank Command (Node.js)
 * Displays user level, XP progress, server experience leaderboard,
 * and handles manual activation/deactivation of chat leveling.
 * STRICT DEFAULT: Leveling is OFF by default and must be explicitly enabled.
 */
const { PermissionsBitField, ButtonStyle } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const { isOwner, hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'levels',
  aliases: ['rank', 'level', 'xp', 'levelup'],
  category: 'leaderboards',
  description: 'View your server level, experience progress, or enable/disable server chat leveling.',
  usage: '[on | off | status | @user | top | set <@user> <level>]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase();

    // 1. Manual Enable Leveling (!levels on / !levels enable)
    if (sub === 'on' || sub === 'enable' || sub === 'activate') {
      const isAuthorized = hasPerm(message.member, PermissionsBitField.Flags.ManageGuild);

      if (!isAuthorized) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure chat leveling.');
      }

      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('leveling_enabled', '1')").run();

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_chart:1567234342701367357> Chat Activity & Leveling Enabled',
        description:
          `> Chat leveling system is now **ACTIVATED** for **${message.guild.name}**.\n\n` +
          `• **Status:** <a:tungsten_success:1567242523468890274> **Active & Operational**\n` +
          `• **XP Distribution:** \`15 - 25 XP\` per active minute\n` +
          `• **Level Up Announcements:** Active in chat\n\n` +
          `-# Disable anytime with \`${prefix}levels off\` • View rank with \`${prefix}levels\``,
        buttons: [
          { label: 'View Leaderboard', style: ButtonStyle.Primary, emoji: '<a:tungsten_warn:1567246685082746940>' },
          { label: 'Check Rank', style: ButtonStyle.Secondary, emoji: '<a:tungsten_chart:1567234342701367357>' },
          { label: 'Disable System', style: ButtonStyle.Danger, emoji: '<a:tungsten_unlock:1567246515209117968>' }
        ],
        buttonTitle: 'Leveling Controls',
        footer: { text: `Activated by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // 2. Manual Disable Leveling (!levels off / !levels disable)
    if (sub === 'off' || sub === 'disable' || sub === 'deactivate') {
      const isAuthorized = hasPerm(message.member, PermissionsBitField.Flags.ManageGuild);

      if (!isAuthorized) {
        return message.reply('<a:tungsten_error:1567238753284653106> You need `Manage Server` permission to configure chat leveling.');
      }

      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('leveling_enabled', '0')").run();

      const card = createV2Card({
        color: 0xED4245,
        title: '<a:tungsten_unlock:1567246515209117968> Chat Activity & Leveling Disabled',
        description:
          `> Chat leveling system has been **DEACTIVATED** for **${message.guild.name}**.\n\n` +
          `• **Status:** <a:tungsten_error:1567238753284653106> **Strictly Disabled (Zero XP Earned)**\n` +
          `• **Database Operations:** Halted\n` +
          `• **Existing Member XP:** Preserved safely in database\n\n` +
          `-# Re-enable anytime using \`${prefix}levels on\``,
        buttons: [
          { label: 'Enable System', style: ButtonStyle.Success, emoji: '<a:tungsten_unlock:1567246515209117968>' },
          { label: 'Leaderboard History', style: ButtonStyle.Secondary, emoji: '<a:tungsten_refresh:1567241907116187658>' }
        ],
        buttonTitle: 'Leveling Controls',
        footer: { text: `Disabled by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // 3. Status Check (!levels status)
    if (sub === 'status') {
      const enabledRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leveling_enabled'").get();
      const isEnabled = enabledRow ? (enabledRow.value === '1' || enabledRow.value === 'true') : false;
      const countRow = sdb.prepare('SELECT COUNT(*) as count FROM leveling_users WHERE guild_id = ?').get(message.guild.id);
      const topUser = sdb.prepare('SELECT user_id, level, xp FROM leveling_users WHERE guild_id = ? ORDER BY xp DESC LIMIT 1').get(message.guild.id);

      const card = createV2Card({
        color: isEnabled ? 0x2ECC71 : 0xFEE75C,
        title: `<a:tungsten_chart:1567234342701367357> Leveling System Status • ${message.guild.name}`,
        description:
          `> Operational state of the server chat leveling engine.\n\n` +
          `• **State:** ${isEnabled ? '<a:tungsten_success:1567242523468890274> **Enabled (Manually Activated)**' : '<a:tungsten_error:1567238753284653106> **Disabled by Default (Manual Activation Required)**'}\n` +
          `• **Ranked Members:** \`${countRow?.count || 0}\` members\n` +
          `• **Server Leader:** ${topUser ? `<@${topUser.user_id}> (Level ${topUser.level} • ${topUser.xp} XP)` : '*None yet*'}\n\n` +
          `-# To toggle leveling: \`${prefix}levels on\` or \`${prefix}levels off\``,
        buttons: isEnabled
          ? [
              { label: 'Disable System', style: ButtonStyle.Danger, emoji: '<a:tungsten_unlock:1567246515209117968>' },
              { label: 'Top Leaderboard', style: ButtonStyle.Primary, emoji: '<a:tungsten_warn:1567246685082746940>' }
            ]
          : [
              { label: 'Enable System', style: ButtonStyle.Success, emoji: '<a:tungsten_unlock:1567246515209117968>' }
            ],
        buttonTitle: 'Leveling Controls',
        footer: { text: `Requested by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // 4. Admin Set Level
    if (sub === 'set' || sub === 'setlevel') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to manually adjust member levels.');
      }

      const target = message.mentions?.members?.first() || (args[1] ? await message.guild.members.fetch(args[1]).catch(() => null) : null);
      const newLevel = parseInt(args[2], 10);

      if (!target || isNaN(newLevel) || newLevel < 0) {
        return message.reply(`Usage: \`${prefix}levels set <@user> <level>\``);
      }

      // level = 0.1 * sqrt(xp) => sqrt(xp) = level / 0.1 = level * 10 => xp = (level * 10)^2
      const requiredXp = Math.pow(newLevel * 10, 2);

      sdb.prepare(`
        INSERT INTO leveling_users (guild_id, user_id, xp, level, last_xp_time)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET
          xp = excluded.xp,
          level = excluded.level
      `).run(message.guild.id, target.id, requiredXp, newLevel, Math.floor(Date.now() / 1000));

      return message.reply(`<a:tungsten_success:1567242523468890274> Set **${target.user.username}**'s rank to **Level ${newLevel}** (\`${requiredXp} XP\`).`);
    }

    // Configurable Level-Up Announcement Channel
    if (sub === 'channel' || sub === 'levelupchannel') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure the level-up channel.');
      }
      const opt = args[1]?.toLowerCase();
      if (!opt) {
        const curRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'level_up_channel'").get();
        const curVal = curRow ? curRow.value : 'current';
        return message.reply(`<a:tungsten_info:1567240890748248084> Current level-up channel: **${curVal}**.\nUsage: \`${prefix}levels channel <#channel | dm | none | current>\``);
      }
      if (opt === 'none') {
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('level_up_channel', 'none')").run();
        return message.reply('<a:tungsten_success:1567242523468890274> Level-up announcement messages are now **disabled**.');
      }
      if (opt === 'dm') {
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('level_up_channel', 'dm')").run();
        return message.reply('<a:tungsten_success:1567242523468890274> Level-up announcements will now be delivered via **Direct Message**.');
      }
      if (opt === 'current' || opt === 'default') {
        sdb.prepare("DELETE FROM server_settings WHERE key = 'level_up_channel'").run();
        return message.reply('<a:tungsten_success:1567242523468890274> Level-up announcements will be posted in the **active chat channel**.');
      }
      const targetChannel = message.mentions?.channels?.first() || message.guild.channels.cache.get(opt.replace(/[<#>]/g, ''));
      if (!targetChannel) {
        return message.reply('<a:tungsten_close:1567234632905138206> Invalid channel specified. Usage: `!levels channel <#channel | dm | none | current>`');
      }
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('level_up_channel', ?)").run(targetChannel.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Level-up announcements will now be sent to <#${targetChannel.id}>.`);
    }

    // Delegations to sub-feature modules
    if (sub === 'role' || sub === 'levelrole') {
      const levelroleCmd = require('./levelrole');
      return levelroleCmd.execute(message, args.slice(1), client, prefix);
    }
    if (sub === 'noxp' || sub === 'ignore') {
      const noxpCmd = require('./noxp');
      return noxpCmd.execute(message, args.slice(1), client, prefix);
    }
    if (sub === 'multiplier' || sub === 'multi') {
      const xpmultiCmd = require('./xpmulti');
      return xpmultiCmd.execute(message, args.slice(1), client, prefix);
    }

    // 5. Server XP Leaderboard
    if (sub === 'top' || sub === 'leaderboard' || sub === 'lb') {
      const rows = sdb.prepare('SELECT user_id, xp, level FROM leveling_users WHERE guild_id = ? ORDER BY xp DESC LIMIT 10').all(message.guild.id);

      let listText = '';
      if (rows.length === 0) {
        listText = '*No members have earned chat XP yet. Start chatting to gain XP!*';
      } else {
        const medals = ['🥇', '🥈', '🥉'];
        listText = rows.map((r, i) => {
          const badge = medals[i] || `\`#${i + 1}\``;
          return `${badge} <@${r.user_id}> — **Level ${r.level}** (\`${r.xp} XP\`)`;
        }).join('\n');
      }

      const card = createV2Card({
        color: 0x2b2d31,
        title: `<a:tungsten_warn:1567246685082746940> Chat Activity Leaderboard • ${message.guild.name}`,
        description:
          `> Top members ranked by messages and experience points.\n\n` +
          listText +
          `\n\n-# Gain 15-25 XP every minute by sending messages in text channels.`,
        buttons: [
          { label: 'Check My Rank', style: ButtonStyle.Primary, emoji: '<a:tungsten_chart:1567234342701367357>' },
          { label: 'Leveling Status', style: ButtonStyle.Secondary, emoji: '<a:tungsten_refresh:1567241907116187658>' }
        ],
        buttonTitle: 'Navigation',
        footer: { text: `Requested by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // 6. User Rank Card
    const targetMember = message.mentions?.members?.first() || (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : message.member);
    if (!targetMember) return message.reply('<a:tungsten_close:1567234632905138206> Could not find that member.');

    const userData = sdb.prepare('SELECT xp, level FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(message.guild.id, targetMember.id) || {
      xp: 0,
      level: 0
    };

    // Calculate progress to next level
    const currentLvlXp = Math.pow(userData.level * 10, 2);
    const nextLvlXp = Math.pow((userData.level + 1) * 10, 2);
    const xpDiff = nextLvlXp - currentLvlXp;
    const progressXp = Math.max(0, userData.xp - currentLvlXp);
    const percentage = Math.min(100, Math.floor((progressXp / (xpDiff || 1)) * 100));

    // Visual progress bar (10 blocks)
    const filledBlocks = Math.round(percentage / 10);
    const progressBar = '▰'.repeat(filledBlocks) + '▱'.repeat(10 - filledBlocks);

    // Calculate leaderboard rank
    const higherRows = sdb.prepare('SELECT COUNT(*) as count FROM leveling_users WHERE guild_id = ? AND xp > ?').get(message.guild.id, userData.xp);
    const rank = (higherRows ? higherRows.count : 0) + 1;

    const card = createV2Card({
      color: 0x00FF88,
      title: `📊  Rank & Experience • ${targetMember.displayName || targetMember.user.username}`,
      description:
        `• **Server Rank:** \`#${rank}\`\n` +
        `• **Current Level:** 🚀 **Level ${userData.level}**\n` +
        `• **Total XP:** \`${userData.xp} XP\`\n\n` +
        `**Level Progress:**\n` +
        `\`${progressBar}\` **${percentage}%**\n` +
        `*${userData.xp} / ${nextLvlXp} XP to Level ${userData.level + 1}*\n\n` +
        `-# Chat actively to level up • Type ${prefix}levels top for leaderboard`,
      buttons: [
        { label: 'View Leaderboard', style: ButtonStyle.Primary, emoji: '<a:tungsten_warn:1567246685082746940>' },
        { label: 'Server Status', style: ButtonStyle.Secondary, emoji: '<a:tungsten_refresh:1567241907116187658>' }
      ],
      buttonTitle: 'Rank Actions',
      footer: { text: `Member: ${targetMember.user.tag}` }
    });

    if (targetMember.user.displayAvatarURL) {
      card.setThumbnail(targetMember.user.displayAvatarURL({ dynamic: true }));
    }

    return message.reply({ embeds: [card] });
  }
};
