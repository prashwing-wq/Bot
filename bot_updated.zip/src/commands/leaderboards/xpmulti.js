/**
 * XP Multiplier Configuration Command (Prefix)
 * Configure XP rate multipliers for channels or roles.
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'xpmulti',
  description: 'Configure XP rate multipliers for channels or roles.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  category: 'leaderboards',
  usage: 'xpmulti <add <#channel|@role> <multiplier> | remove <#channel|@role> | list>',
  aliases: ['xpmultiplier'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to configure XP multipliers.');
    }

    const sub = args[0]?.toLowerCase();
    const sdb = getServerDb(message.guild.id);

    if (sub === 'add') {
      const channel = message.mentions?.channels?.first() || (args[1] ? message.guild.channels.cache.get(args[1].replace(/[<#>]/g, '')) : null);
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1].replace(/[<@&>]/g, '')) : null);
      const multi = parseFloat(args[2]);

      if (isNaN(multi) || multi <= 0) {
        return message.reply(`Usage: \`${prefix}xpmulti add <#channel|@role> <multiplier: e.g. 1.5, 2.0>\``);
      }

      if (channel) {
        sdb.prepare(`
          INSERT INTO leveling_multipliers (guild_id, target_id, type, multiplier)
          VALUES (?, ?, 'channel', ?)
          ON CONFLICT(guild_id, target_id) DO UPDATE SET multiplier = excluded.multiplier
        `).run(message.guild.id, channel.id, multi);
        return message.reply(`<a:tungsten_success:1567242523468890274> Configured **${multi}x** XP multiplier for channel <#${channel.id}>.`);
      }

      if (role) {
        sdb.prepare(`
          INSERT INTO leveling_multipliers (guild_id, target_id, type, multiplier)
          VALUES (?, ?, 'role', ?)
          ON CONFLICT(guild_id, target_id) DO UPDATE SET multiplier = excluded.multiplier
        `).run(message.guild.id, role.id, multi);
        return message.reply(`<a:tungsten_success:1567242523468890274> Configured **${multi}x** XP multiplier for role <@&${role.id}>.`);
      }

      return message.reply(`Usage: \`${prefix}xpmulti add <#channel|@role> <multiplier>\``);
    }

    if (sub === 'remove' || sub === 'del') {
      const targetId = args[1] ? args[1].replace(/[<#@&>]/g, '') : null;
      if (!targetId) return message.reply(`Usage: \`${prefix}xpmulti remove <#channel|@role>\``);

      const res = sdb.prepare('DELETE FROM leveling_multipliers WHERE guild_id = ? AND target_id = ?').run(message.guild.id, targetId);
      if (res.changes === 0) return message.reply('<a:tungsten_close:1567234632905138206> No multiplier configured for that target.');

      return message.reply('<a:tungsten_success:1567242523468890274> Removed multiplier for that target.');
    }

    if (sub === 'list' || !sub) {
      const rows = sdb.prepare('SELECT target_id, type, multiplier FROM leveling_multipliers WHERE guild_id = ?').all(message.guild.id);
      if (rows.length === 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> No custom XP multipliers configured for this server.');
      }

      const list = rows.map(r => {
        const mention = r.type === 'channel' ? `<#${r.target_id}>` : `<@&${r.target_id}>`;
        return `• ${mention} ➔ **${r.multiplier}x** XP`;
      }).join('\n');

      const embed = createEmbed({
        color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
        title: `⚡ Active XP Multipliers • ${message.guild.name}`,
        description: list
      });

      return message.reply({ embeds: [embed] });
    }

    return message.reply(`Usage: \`${prefix}xpmulti <add|remove|list>\``);
  }
};
