/**
 * Level Role Rewards Command (Prefix)
 * Configure role rewards given when members reach specific levels.
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'levelrole',
  description: 'Configure and list level role rewards.',
  permissions: ['ManageGuild'],
  botPermissions: ['ManageRoles', 'SendMessages', 'EmbedLinks'],
  category: 'leaderboards',
  usage: 'levelrole <add <level> @role | remove <level|@role> | list>',
  aliases: ['levelroles', 'lvlrole'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to configure level roles.');
    }

    const sub = args[0]?.toLowerCase();
    const sdb = getServerDb(message.guild.id);

    if (sub === 'add') {
      const level = parseInt(args[1], 10);
      const role = message.mentions?.roles?.first() || (args[2] ? message.guild.roles.cache.get(args[2].replace(/[<@&>]/g, '')) : null);

      if (isNaN(level) || level <= 0 || !role) {
        return message.reply(`Usage: \`${prefix}levelrole add <level> @role\``);
      }

      sdb.prepare(`
        INSERT INTO leveling_roles (guild_id, level, role_id)
        VALUES (?, ?, ?)
        ON CONFLICT(guild_id, level) DO UPDATE SET role_id = excluded.role_id
      `).run(message.guild.id, level, role.id);

      return message.reply(`<a:tungsten_success:1567242523468890274> Successfully linked **Level ${level}** reward to role <@&${role.id}>.`);
    }

    if (sub === 'remove' || sub === 'delete' || sub === 'del') {
      const level = parseInt(args[1], 10);
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1].replace(/[<@&>]/g, '')) : null);

      if (!isNaN(level) && level > 0) {
        const res = sdb.prepare('DELETE FROM leveling_roles WHERE guild_id = ? AND level = ?').run(message.guild.id, level);
        if (res.changes === 0) return message.reply(`<a:tungsten_close:1567234632905138206> No reward role found for Level ${level}.`);
        return message.reply(`<a:tungsten_success:1567242523468890274> Removed reward role for **Level ${level}**.`);
      } else if (role) {
        const res = sdb.prepare('DELETE FROM leveling_roles WHERE guild_id = ? AND role_id = ?').run(message.guild.id, role.id);
        if (res.changes === 0) return message.reply(`<a:tungsten_close:1567234632905138206> Role <@&${role.id}> is not configured as a level reward.`);
        return message.reply(`<a:tungsten_success:1567242523468890274> Removed reward role <@&${role.id}>.`);
      }

      return message.reply(`Usage: \`${prefix}levelrole remove <level|@role>\``);
    }

    if (sub === 'list' || !sub) {
      const rows = sdb.prepare('SELECT level, role_id FROM leveling_roles WHERE guild_id = ? ORDER BY level ASC').all(message.guild.id);
      if (rows.length === 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> No level role rewards configured yet.');
      }

      const list = rows.map(r => `• **Level ${r.level}** ➔ <@&${r.role_id}>`).join('\n');
      const embed = createEmbed({
        color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
        title: `🏆 Level Role Rewards • ${message.guild.name}`,
        description: `Members automatically receive these roles when leveling up:\n\n${list}`,
        footer: `Configured Rewards: ${rows.length}`
      });

      return message.reply({ embeds: [embed] });
    }

    return message.reply(`Usage: \`${prefix}levelrole <add <level> @role | remove <level|@role> | list>\``);
  }
};
