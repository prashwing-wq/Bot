const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

module.exports = {
  name: 'vcstats',
  aliases: ['dailyvoice', 'weeklyvoice', 'monthlyvoice', 'voicestats', 'myvoice'],
  category: 'leaderboards',
  description: 'View your or another member\'s detailed voice activity statistics',
  usage: '[@member|id]',
  cooldown: 3,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    let target = message.author;
    if (message.mentions.users.first()) {
      target = message.mentions.users.first();
    } else if (args[0] && /^\d{17,20}$/.test(args[0])) {
      target = await client.users.fetch(args[0]).catch(() => message.author);
    }

    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare('SELECT total_seconds, daily_seconds, weekly_seconds, monthly_seconds, last_joined FROM voice_activity WHERE guild_id = ? AND user_id = ?').get(message.guild.id, target.id);

    const total = row?.total_seconds || 0;
    const daily = row?.daily_seconds || 0;
    const weekly = row?.weekly_seconds || 0;
    const monthly = row?.monthly_seconds || 0;

    const rankRow = sdb.prepare('SELECT COUNT(*) as rank FROM voice_activity WHERE guild_id = ? AND total_seconds > ?').get(message.guild.id, total);
    const rank = (rankRow?.rank || 0) + 1;

    const embed = createEmbed({
      title: `🎙️ Voice Statistics — ${target.username}`,
      thumbnail: { url: target.displayAvatarURL() },
      fields: [
        { name: '🏆 Server Rank', value: `\`#${rank}\``, inline: true },
        { name: '<a:tungsten_loading:1567241050567876698> Total Voice Time', value: `**${formatDuration(total)}**`, inline: true },
        { name: '📅 Daily Voice Time', value: formatDuration(daily), inline: true },
        { name: '🗓️ Weekly Voice Time', value: formatDuration(weekly), inline: true },
        { name: '📊 Monthly Voice Time', value: formatDuration(monthly), inline: true },
        { name: '🕒 Last Session', value: row?.last_joined ? `<t:${row.last_joined}:R>` : 'Never', inline: true }
      ],
      color: 0x5865F2,
      footer: { text: `Guild ID: ${message.guild.id}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
