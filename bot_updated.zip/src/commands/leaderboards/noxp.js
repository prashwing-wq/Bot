/**
 * No-XP Channels & Roles Configuration Command (Prefix)
 * Prevent members from gaining chat or voice XP in specific channels or roles.
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'noxp',
  description: 'Manage channels and roles excluded from earning XP.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  category: 'leaderboards',
  usage: 'noxp <add <#channel|@role> | remove <#channel|@role> | list>',
  aliases: ['ignorexp'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to configure ignored XP targets.');
    }

    const sub = args[0]?.toLowerCase();
    const sdb = getServerDb(message.guild.id);

    if (sub === 'add') {
      const channel = message.mentions?.channels?.first() || (args[1] ? message.guild.channels.cache.get(args[1].replace(/[<#>]/g, '')) : null);
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1].replace(/[<@&>]/g, '')) : null);

      if (channel) {
        sdb.prepare("INSERT OR IGNORE INTO leveling_ignored (guild_id, target_id, type) VALUES (?, ?, 'channel')")
          .run(message.guild.id, channel.id);
        return message.reply(`<a:tungsten_success:1567242523468890274> Added channel <#${channel.id}> to the XP ignore list.`);
      }

      if (role) {
        sdb.prepare("INSERT OR IGNORE INTO leveling_ignored (guild_id, target_id, type) VALUES (?, ?, 'role')")
          .run(message.guild.id, role.id);
        return message.reply(`<a:tungsten_success:1567242523468890274> Added role <@&${role.id}> to the XP ignore list.`);
      }

      return message.reply(`Usage: \`${prefix}noxp add <#channel|@role>\``);
    }

    if (sub === 'remove' || sub === 'del') {
      const channel = message.mentions?.channels?.first() || (args[1] ? message.guild.channels.cache.get(args[1].replace(/[<#>]/g, '')) : null);
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1].replace(/[<@&>]/g, '')) : null);

      const targetId = channel?.id || role?.id || (args[1] ? args[1].replace(/[<#@&>]/g, '') : null);
      if (!targetId) return message.reply(`Usage: \`${prefix}noxp remove <#channel|@role>\``);

      const res = sdb.prepare('DELETE FROM leveling_ignored WHERE guild_id = ? AND target_id = ?').run(message.guild.id, targetId);
      if (res.changes === 0) return message.reply('<a:tungsten_close:1567234632905138206> That channel or role is not in the ignore list.');

      return message.reply(`<a:tungsten_success:1567242523468890274> Removed target from the XP ignore list.`);
    }

    if (sub === 'list' || !sub) {
      const rows = sdb.prepare('SELECT target_id, type FROM leveling_ignored WHERE guild_id = ?').all(message.guild.id);
      if (rows.length === 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> No channels or roles are currently excluded from earning XP.');
      }

      const channels = rows.filter(r => r.type === 'channel').map(r => `<#${r.target_id}>`);
      const roles = rows.filter(r => r.type === 'role').map(r => `<@&${r.target_id}>`);

      const embed = createEmbed({
        color: client?.config?.COLORS?.INFO || 0x3498DB,
        title: `🚫 Excluded XP Channels & Roles • ${message.guild.name}`,
        description:
          `**Ignored Channels (${channels.length}):**\n${channels.length ? channels.join(', ') : '*None*'}\n\n` +
          `**Ignored Roles (${roles.length}):**\n${roles.length ? roles.join(', ') : '*None*'}`
      });

      return message.reply({ embeds: [embed] });
    }

    return message.reply(`Usage: \`${prefix}noxp <add|remove|list> <#channel|@role>\``);
  }
};
