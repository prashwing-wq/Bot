const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'addvctime',
  aliases: ['givevctime'],
  category: 'leaderboards',
  description: 'Add voice activity time in minutes to a member',
  usage: '<@member|id> <minutes>',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need **Manage Server** permission to adjust voice time.');
    }

    const target = message.mentions.users.first() || (args[0] && /^\d{17,20}$/.test(args[0]) ? await client.users.fetch(args[0]).catch(() => null) : null);
    if (!target) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid member. Usage: \`${prefix}addvctime @member <minutes>\``);
    }

    const mins = parseInt(args[1], 10);
    if (isNaN(mins) || mins <= 0) {
      return message.reply('<a:tungsten_close:1567234632905138206> Provide a positive number of minutes to add.');
    }

    const secondsToAdd = mins * 60;
    const now = Math.floor(Date.now() / 1000);
    const sdb = getServerDb(message.guild.id);

    sdb.prepare(`
      INSERT INTO voice_activity (guild_id, user_id, total_seconds, daily_seconds, weekly_seconds, monthly_seconds, last_joined, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET
        total_seconds = voice_activity.total_seconds + excluded.total_seconds,
        daily_seconds = voice_activity.daily_seconds + excluded.daily_seconds,
        weekly_seconds = voice_activity.weekly_seconds + excluded.weekly_seconds,
        monthly_seconds = voice_activity.monthly_seconds + excluded.monthly_seconds,
        updated_at = excluded.updated_at
    `).run(message.guild.id, target.id, secondsToAdd, secondsToAdd, secondsToAdd, secondsToAdd, now, now);

    const embed = createEmbed({
      title: '<a:tungsten_success:1567242523468890274> Voice Time Added',
      description: `Added **${mins} minutes** of voice activity to <@${target.id}>.`,
      color: 0x57F287
    });

    return message.reply({ embeds: [embed] });
  }
};
