/**
 * Server Leaderboard & Activity Ranks Command (Node.js)
 * Supports wealth, voice time, messages/xp, and invites leaderboards.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'leaderboard',
  aliases: ['lb', 'top', 'levels', 'voicelb', 'msglb', 'invitelb'],
  category: 'leaderboards',
  description: 'View server economy, voice, messages, and activity leaderboards.',
  usage: '[economy | voice | messages | invites | top]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sub = (args[0] || '').toLowerCase();
    const db = getServerDb(message.guild.id);
    const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

    // ─────────────────────────────────────────────────────────────
    // Voice Leaderboard
    // ─────────────────────────────────────────────────────────────
    if (sub === 'voice' || sub === 'vc') {
      let voiceRows = [];
      try {
        voiceRows = db.prepare(`
          SELECT user_id, total_seconds
          FROM voice_activity
          WHERE guild_id = ?
          ORDER BY total_seconds DESC
          LIMIT 10
        `).all(message.guild.id);
      } catch (_) {}

      let listText = '';
      if (!voiceRows || voiceRows.length === 0) {
        listText = '*No voice activity recorded yet. Join a voice channel to start logging time!*';
      } else {
        listText = voiceRows.map((r, i) => {
          const medal = medals[i] || `${i + 1}.`;
          const hrs = Math.floor(r.total_seconds / 3600);
          const mins = Math.floor((r.total_seconds % 3600) / 60);
          return `${medal} <@${r.user_id}> — **${hrs}h ${mins}m** (${r.total_seconds.toLocaleString()}s)`;
        }).join('\n');
      }

      const embed = createEmbed({
        title: `🎙️  ${message.guild.name} • Voice Leaderboard`,
        description: `> Top members by cumulative voice channel time.\n\n${listText}`,
        footer: { text: `Requested by ${message.author.username}` }
      });
      if (message.guild.iconURL) embed.setThumbnail(message.guild.iconURL());
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // Messages / XP Leaderboard
    // ─────────────────────────────────────────────────────────────
    if (sub === 'messages' || sub === 'msg' || sub === 'chat') {
      let msgRows = [];
      try {
        msgRows = db.prepare(`
          SELECT user_id, level, xp, messages
          FROM leveling_users
          ORDER BY xp DESC
          LIMIT 10
        `).all();
      } catch (_) {}

      let listText = '';
      if (!msgRows || msgRows.length === 0) {
        listText = '*No chat activity recorded yet. Send messages to climb the ranks!*';
      } else {
        listText = msgRows.map((r, i) => {
          const medal = medals[i] || `${i + 1}.`;
          const msgCount = r.messages ? `${r.messages.toLocaleString()} msgs` : `${r.xp.toLocaleString()} XP`;
          return `${medal} <@${r.user_id}> — **Level ${r.level || 0}** • \`${msgCount}\``;
        }).join('\n');
      }

      const embed = createEmbed({
        title: `💬  ${message.guild.name} • Message & Level Leaderboard`,
        description: `> Top members by message activity and experience.\n\n${listText}`,
        footer: { text: `Requested by ${message.author.username}` }
      });
      if (message.guild.iconURL) embed.setThumbnail(message.guild.iconURL());
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // Invites Leaderboard
    // ─────────────────────────────────────────────────────────────
    if (sub === 'invites' || sub === 'invite' || sub === 'inv') {
      let invitesList = [];
      try {
        const fetchedInvites = await message.guild.invites.fetch().catch(() => null);
        if (fetchedInvites) {
          const inviteCounts = new Map();
          for (const inv of fetchedInvites.values()) {
            if (inv.inviterId) {
              inviteCounts.set(inv.inviterId, (inviteCounts.get(inv.inviterId) || 0) + (inv.uses || 0));
            }
          }
          invitesList = Array.from(inviteCounts.entries())
            .map(([userId, uses]) => ({ user_id: userId, uses }))
            .sort((a, b) => b.uses - a.uses)
            .slice(0, 10);
        }
      } catch (_) {}

      let listText = '';
      if (invitesList.length === 0) {
        listText = '*No invite data recorded in this server.*';
      } else {
        listText = invitesList.map((r, i) => {
          const medal = medals[i] || `${i + 1}.`;
          return `${medal} <@${r.user_id}> — **${r.uses.toLocaleString()}** invite(s)`;
        }).join('\n');
      }

      const embed = createEmbed({
        title: `✉️  ${message.guild.name} • Invites Leaderboard`,
        description: `> Top server recruiters by invite uses.\n\n${listText}`,
        footer: { text: `Requested by ${message.author.username}` }
      });
      if (message.guild.iconURL) embed.setThumbnail(message.guild.iconURL());
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // Wealth / Economy / Top Leaderboard (Default)
    // ─────────────────────────────────────────────────────────────
    let topRows = [];
    try {
      topRows = db.prepare(`
        SELECT user_id, wallet, bank, (wallet + bank) as net_worth
        FROM economy_users
        ORDER BY net_worth DESC
        LIMIT 10
      `).all();
    } catch (_) {}

    let listText = '';
    if (!topRows || topRows.length === 0) {
      listText = '*No economy activity recorded yet. Start with `!daily` or `!balance`!*';
    } else {
      listText = topRows.map((r, i) => {
        const medal = medals[i] || `${i + 1}.`;
        return `${medal} <@${r.user_id}> — **$${r.net_worth.toLocaleString()}** *(Wallet: $${r.wallet.toLocaleString()} • Bank: $${r.bank.toLocaleString()})*`;
      }).join('\n');
    }

    const embed = createEmbed({
      title: `🏆  ${message.guild.name} • Top Wealth Leaderboard`,
      description:
        `> Top server wealth rankings and member standings.\n\n` +
        listText +
        `\n\n-# Type \`${prefix}daily\` to claim your daily credits!`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    if (message.guild.iconURL) {
      embed.setThumbnail(message.guild.iconURL());
    }

    return message.reply({ embeds: [embed] });
  }
};
