const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

module.exports = {
  name: 'vclb',
  aliases: ['voicelb', 'voiceleaderboard', 'vctop'],
  category: 'leaderboards',
  description: 'Displays the server top voice activity leaderboard',
  usage: '',
  cooldown: 5,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const rows = sdb.prepare('SELECT user_id, total_seconds FROM voice_activity WHERE guild_id = ? ORDER BY total_seconds DESC LIMIT 10').all(message.guild.id);

    if (!rows || rows.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> No voice activity records found for this server yet.');
    }

    const lines = rows.map((r, i) => {
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `\`#${i + 1}\``;
      return `${medal} <@${r.user_id}> — **${formatDuration(r.total_seconds)}**`;
    });

    const embed = createEmbed({
      title: '🎙️ Voice Activity Leaderboard',
      description: lines.join('\n'),
      color: 0x5865F2,
      footer: { text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() }
    });

    return message.reply({ embeds: [embed] });
  }
};
