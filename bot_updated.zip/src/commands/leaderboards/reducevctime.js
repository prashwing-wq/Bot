const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'reducevctime',
  aliases: ['removevctime', 'subvctime'],
  category: 'leaderboards',
  description: 'Reduce voice activity time in minutes from a member',
  usage: '<@member|id> <minutes>',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need **Manage Server** permission to adjust voice time.');
    }

    const target = message.mentions.users.first() || (args[0] && /^\d{17,20}$/.test(args[0]) ? await client.users.fetch(args[0]).catch(() => null) : null);
    if (!target) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid member. Usage: \`${prefix}reducevctime @member <minutes>\``);
    }

    const mins = parseInt(args[1], 10);
    if (isNaN(mins) || mins <= 0) {
      return message.reply('<a:tungsten_close:1567234632905138206> Provide a positive number of minutes to deduct.');
    }

    const secondsToSub = mins * 60;
    const now = Math.floor(Date.now() / 1000);
    const sdb = getServerDb(message.guild.id);

    sdb.prepare(`
      UPDATE voice_activity
      SET total_seconds = MAX(0, total_seconds - ?),
          daily_seconds = MAX(0, daily_seconds - ?),
          weekly_seconds = MAX(0, weekly_seconds - ?),
          monthly_seconds = MAX(0, monthly_seconds - ?),
          updated_at = ?
      WHERE guild_id = ? AND user_id = ?
    `).run(secondsToSub, secondsToSub, secondsToSub, secondsToSub, now, message.guild.id, target.id);

    const embed = createEmbed({
      title: '<a:tungsten_success:1567242523468890274> Voice Time Reduced',
      description: `Deducted **${mins} minutes** of voice activity from <@${target.id}>.`,
      color: 0xED4245
    });

    return message.reply({ embeds: [embed] });
  }
};
