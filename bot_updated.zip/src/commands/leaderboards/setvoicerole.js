const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'setvoicerole',
  aliases: ['voicerole', 'addvoicerole', 'vcrolereward'],
  category: 'leaderboards',
  description: 'Configure automated milestone role rewards for voice activity',
  usage: '<minutes|list|remove> [@role|id]',
  cooldown: 3,
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageRoles)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need **Manage Roles** permission to configure voice milestone roles.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'list').toLowerCase();

    if (sub === 'list') {
      const rows = sdb.prepare('SELECT required_seconds, role_id FROM voice_roles WHERE guild_id = ? ORDER BY required_seconds ASC').all(message.guild.id);
      if (!rows || rows.length === 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> No voice milestone roles configured for this server yet.');
      }
      const lines = rows.map(r => `• **${Math.floor(r.required_seconds / 60)} mins:** <@&${r.role_id}>`);
      const embed = createEmbed({
        title: '🎖️ Voice Activity Milestone Roles',
        description: lines.join('\n') + `\n\n• **Add:** \`${prefix}setvoicerole <minutes> @role\`\n• **Remove:** \`${prefix}setvoicerole remove <minutes>\``,
        color: 0x5865F2
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'remove' || sub === 'del') {
      const mins = parseInt(args[1], 10);
      if (isNaN(mins)) return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}setvoicerole remove <minutes>\``);
      sdb.prepare('DELETE FROM voice_roles WHERE guild_id = ? AND required_seconds = ?').run(message.guild.id, mins * 60);
      return message.reply(`<a:tungsten_success:1567242523468890274> Removed voice milestone role reward for **${mins} minutes**.`);
    }

    const mins = parseInt(args[0], 10);
    const roleId = args[1]?.replace(/[^0-9]/g, '');
    const role = message.mentions?.roles?.first ? message.mentions.roles.first() : (roleId ? message.guild?.roles?.cache?.get(roleId) || { id: roleId, name: 'MilestoneRole' } : null);

    if (isNaN(mins) || mins <= 0 || !role) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}setvoicerole <minutes> <@role>\`\nExample: \`${prefix}setvoicerole 60 @ActiveSpeaker\``);
    }

    sdb.prepare(`
      INSERT OR REPLACE INTO voice_roles (guild_id, required_seconds, role_id)
      VALUES (?, ?, ?)
    `).run(message.guild.id, mins * 60, role.id);

    const embed = createEmbed({
      title: '<a:tungsten_success:1567242523468890274> Voice Milestone Configured',
      description: `Members who spend **${mins} minutes** in voice channels will automatically receive ${role}.`,
      color: 0x57F287
    });

    return message.reply({ embeds: [embed] });
  }
};
