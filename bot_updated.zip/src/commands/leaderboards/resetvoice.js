const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'resetvoice',
  aliases: ['clearvoice', 'resetvoicestats'],
  category: 'leaderboards',
  description: 'Reset voice activity stats for a specific member or all server members',
  usage: '[all | @member]',
  cooldown: 5,
  permissions: ['Administrator'],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.Administrator)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Administrator** permission to reset voice activity statistics.');
    }

    const sdb = getServerDb(message.guild.id);
    const target = message.mentions.users.first();

    if (target) {
      sdb.prepare('DELETE FROM voice_activity WHERE guild_id = ? AND user_id = ?').run(message.guild.id, target.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Voice activity statistics reset for <@${target.id}>.`);
    }

    if (args[0]?.toLowerCase() === 'all') {
      sdb.prepare('DELETE FROM voice_activity WHERE guild_id = ?').run(message.guild.id);
      const embed = createEmbed({
        title: '<a:tungsten_trash:1567242891276062872> Voice Stats Reset',
        description: 'All server voice activity statistics have been cleared.',
        color: 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }

    return message.reply(`<a:tungsten_close:1567234632905138206> Specify a member or type \`${prefix}resetvoice all\` to clear all server voice stats.`);
  }
};
