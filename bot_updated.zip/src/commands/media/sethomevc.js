const { PermissionFlagsBits, Routes, GatewayOpcodes } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'sethomevc',
  aliases: ['homevc', 'resethomevc', 'sethomevcstatus', 'homevcset', 'set247vc', '247vc', 'homevc_set'],
  category: 'media',
  description: 'Set the 24/7 Home Voice Channel where Tungsten remains permanently connected',
  usage: '<#channel|ID> [status text]',
  cooldown: 5,
  permissions: ['ManageChannels'],
  botPermissions: ['Connect', 'Speak'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to configure the 24/7 Home Voice Channel.');
    }

    const sdb = getServerDb(message.guild.id);
    const invokedName = message.content?.slice(prefix?.length || 1).trim().split(/\s+/)[0]?.toLowerCase() || 'sethomevc';

    // 1. Reset / Clear handler
    if (invokedName === 'resethomevc' || args[0]?.toLowerCase() === 'clear' || args[0]?.toLowerCase() === 'disable') {
      sdb.prepare('DELETE FROM home_voice_channels WHERE guild_id = ?').run(message.guild.id);
      if (message.guild.shard) {
        try {
          message.guild.shard.send({
            op: GatewayOpcodes?.VoiceStateUpdate || 4,
            d: {
              guild_id: message.guild.id,
              channel_id: null,
              self_mute: false,
              self_deaf: false
            }
          });
        } catch (_) {}
      }
      const embed = createEmbed({
        title: '<a:tungsten_ui_toggle_off:1569329677187678368> 24/7 Home Voice Channel Disabled',
        description: 'Tungsten has been disconnected and the 24/7 persistent voice anchor has been cleared.',
        color: 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }

    // 2. Info / Status View handler
    if (invokedName === 'homevc' || args[0]?.toLowerCase() === 'info' || args[0]?.toLowerCase() === 'status') {
      const row = sdb.prepare('SELECT channel_id, status_text, enabled, reconnect_count FROM home_voice_channels WHERE guild_id = ?').get(message.guild.id);
      if (!row || !row.enabled) {
        return message.reply(`<a:tungsten_info:1567240890748248084> 24/7 Home Voice is not configured for this server. Use \`${prefix}sethomevc <#channel>\` to set it up.`);
      }
      const embed = createEmbed({
        title: '<a:tungsten_presence:1569329536875888711> 24/7 Home Voice Channel Status',
        description: `Target Channel: <#${row.channel_id}>\nStatus: <a:tungsten_ui_toggle_on:1569329685110849576> **Enabled**\nTopic: \`${row.status_text || 'Default'}\``,
        color: 0x5865F2
      });
      return message.reply({ embeds: [embed] });
    }

    // 3. Status text update handler
    if (invokedName === 'sethomevcstatus') {
      const statusText = args.join(' ').trim();
      sdb.prepare("UPDATE home_voice_channels SET status_text = ?, updated_at = strftime('%s', 'now') WHERE guild_id = ?")
        .run(statusText, message.guild.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Updated 24/7 Home Voice status text to: **${statusText}**`);
    }

    // 4. Configuration handler
    const rawId = args[0]?.replace(/[^0-9]/g, '');
    let channel = message.mentions?.channels?.first?.()
      || (rawId ? message.guild.channels.cache.get(rawId) : null)
      || (message.member?.voice?.channelId ? message.member.voice.channel : null);

    if (!channel && rawId && typeof message.guild.channels.fetch === 'function') {
      channel = await message.guild.channels.fetch(rawId).catch(() => null);
    }

    if (!channel || !channel.isVoiceBased?.()) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid voice channel or join one. Usage: \`${prefix}sethomevc <#channel|ID> [status]\``);
    }

    const customStatus = args.slice(1).join(' ').trim();
    const statusTemplate = customStatus || '24/7 Tungsten Node • Ping: {ping}ms';
    const now = Math.floor(Date.now() / 1000);

    sdb.prepare(`
      INSERT INTO home_voice_channels (guild_id, channel_id, status_text, enabled, reconnect_count, updated_at)
      VALUES (?, ?, ?, 1, 0, ?)
      ON CONFLICT(guild_id) DO UPDATE SET
        channel_id = excluded.channel_id,
        status_text = excluded.status_text,
        enabled = 1,
        updated_at = excluded.updated_at
    `).run(message.guild.id, channel.id, statusTemplate, now);

    // Send OP 4 VoiceStateUpdate
    if (message.guild.shard) {
      try {
        message.guild.shard.send({
          op: GatewayOpcodes?.VoiceStateUpdate || 4,
          d: {
            guild_id: message.guild.id,
            channel_id: channel.id,
            self_mute: false,
            self_deaf: true
          }
        });
      } catch (_) {}
    }

    // Update voice channel status via REST
    if (client?.rest?.put) {
      const ping = Math.round(client?.ws?.ping || 24);
      const formattedStatus = statusTemplate
        .replace(/\{ping\}/gi, `${ping}ms`)
        .replace(/\{latency\}/gi, `${ping}ms`)
        .replace(/\{server\}/gi, message.guild.name);

      try {
        const route = Routes.channelVoiceStatus ? Routes.channelVoiceStatus(channel.id) : `/channels/${channel.id}/voice-status`;
        await client.rest.put(route, {
          body: { status: formattedStatus }
        }).catch(() => null);
      } catch (_) {}
    }

    const embed = createEmbed({
      title: '<a:tungsten_presence:1569329536875888711> 24/7 Home Voice Channel Configured',
      description: `Successfully anchored Tungsten to ${channel}.\n\n` +
        `• **Channel:** ${channel.name} (\`${channel.id}\`)\n` +
        `• **Auto-Reconnect:** <a:tungsten_ui_toggle_on:1569329685110849576> **Enabled** (Resilient 24/7 Sentinel)\n` +
        `• **Status Topic:** \`${statusTemplate}\``,
      color: 0x57F287
    });

    return message.reply({ embeds: [embed] });
  }
};
