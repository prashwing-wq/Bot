const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'homevc',
  aliases: ['homevcinfo', '247status', '247info'],
  category: 'media',
  description: 'View current 24/7 Home Voice Channel status and connection health',
  usage: '',
  cooldown: 3,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare('SELECT channel_id, status_text, enabled, reconnect_count, updated_at FROM home_voice_channels WHERE guild_id = ?').get(message.guild.id);

    if (!row || !row.enabled) {
      return message.reply(`<a:tungsten_info:1567240890748248084> 24/7 Home Voice is not configured for this server. Use \`${prefix}sethomevc <#channel>\` to set it up.`);
    }

    const channel = message.guild.channels.cache.get(row.channel_id)
      || await message.guild.channels.fetch(row.channel_id).catch(() => null);

    const isConnected = message.guild.members.me?.voice?.channelId === row.channel_id;
    const ping = Math.round(client.ws.ping) || 0;

    const embed = createEmbed({
      title: '<a:tungsten_presence:1569329536875888711> 24/7 Home Voice Channel Status',
      thumbnail: { url: client.user.displayAvatarURL() },
      fields: [
        { name: 'Channel', value: channel ? `${channel.name} (\`${channel.id}\`)` : `\`${row.channel_id}\` *(Not found)*`, inline: true },
        { name: 'Connection State', value: isConnected ? '<a:tungsten_ui_toggle_on:1569329685110849576> **Connected (24/7 Active)**' : '<a:tungsten_ui_toggle_off:1569329677187678368> **Reconnecting...**', inline: true },
        { name: 'WebSocket Ping', value: `\`${ping}ms\``, inline: true },
        { name: 'Reconnect Count', value: `\`${row.reconnect_count || 0}\``, inline: true },
        { name: 'Topic Template', value: `\`${row.status_text || 'Default'}\``, inline: false }
      ],
      color: isConnected ? 0x57F287 : 0xFEE75C,
      footer: { text: `Configure with ${prefix}sethomevc or disable with ${prefix}resethomevc` }
    });

    return message.reply({ embeds: [embed] });
  }
};
