const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { replaceEmojis } = require('../../utils/emojis');

module.exports = {
  name: 'setvcstatus',
  aliases: ['setvstatus', 'vcsset', 'voicechannelstatus'],
  category: 'media',
  description: 'Set custom voice status text on a voice channel',
  usage: '<#channel|ID> <status text>',
  cooldown: 5,
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to set voice channel statuses.');
    }

    let channel = message.mentions.channels.first();
    let textArgIndex = 1;

    if (!channel && args[0] && /^\d{17,20}$/.test(args[0])) {
      channel = message.guild.channels.cache.get(args[0]) || await message.guild.channels.fetch(args[0]).catch(() => null);
      textArgIndex = 1;
    } else if (!channel && message.member.voice.channelId) {
      channel = message.member.voice.channel;
      textArgIndex = 0;
    }

    if (!channel || !channel.isVoiceBased()) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid voice channel. Usage: \`${prefix}setvcstatus <#channel|ID> <status text>\``);
    }

    let statusText = args.slice(textArgIndex).join(' ').trim();
    if (!statusText) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Provide status text to set. Example: \`${prefix}setvcstatus #${channel.name} Gaming Lounge • Chill Vibes\``);
    }
    statusText = replaceEmojis(message.guild, statusText);

    // Set Discord voice channel status via REST API endpoint
    try {
      if (typeof client.rest?.put === 'function') {
        await client.rest.put(`/channels/${channel.id}/voice-status`, {
          body: { status: statusText }
        });
      }
    } catch (e) {
      // Fallback: update channel topic
      await channel.setTopic(statusText).catch(() => null);
    }

    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare('SELECT 1 FROM home_voice_channels WHERE guild_id = ? AND channel_id = ?').get(message.guild.id, channel.id);
    if (row) {
      sdb.prepare("UPDATE home_voice_channels SET status_text = ?, updated_at = strftime('%s', 'now') WHERE guild_id = ?").run(statusText, message.guild.id);
    }

    const embed = createEmbed({
      title: '🎙️ Voice Channel Status Updated',
      description: `Updated status for ${channel}:\n> **${statusText}**`,
      color: 0x57F287
    });

    return message.reply({ embeds: [embed] });
  }
};
