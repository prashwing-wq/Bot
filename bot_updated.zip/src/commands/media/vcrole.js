/**
 * Voice Channel Auto-Role Command (Node.js)
 * Automatically grants a role while a member is connected to VC and strips it on disconnect.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'vcrole',
  aliases: ['invcrole', 'voicerole'],
  category: 'media',
  description: 'Automatically grant a temporary role to members while active in a voice channel.',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  usage: '[set <@role> | remove | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Roles` permission to configure voice roles.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase() || 'status';

    if (sub === 'set') {
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1]) : null);
      if (!role) return message.reply(`Usage: \`${prefix}vcrole set @Role\``);

      if (message.guild.members.me.roles.highest.position <= role.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot assign this role because it is higher than or equal to my top role.');
      }

      sdb.prepare(`
        INSERT OR REPLACE INTO server_settings (key, value)
        VALUES ('vcrole_id', ?)
      `).run(role.id);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '🎙️  Voice Auto-Role Configured',
        description: `> Members connecting to any voice channel will automatically receive ${role} and lose it upon disconnecting.`
      });

      return message.reply({ embeds: [embed] });
    }

    if (sub === 'remove' || sub === 'disable') {
      sdb.prepare("DELETE FROM server_settings WHERE key = 'vcrole_id'").run();
      return message.reply('<a:tungsten_success:1567242523468890274> Voice auto-role has been **DISABLED**.');
    }

    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'vcrole_id'").get();
    const roleId = row ? row.value : null;

    const embed = createEmbed({
      title: '🎙️  Voice Auto-Role Configuration',
      description:
        `> Temporary role binding for voice-connected members.\n\n` +
        `• **Active Voice Role:** ${roleId ? `<@&${roleId}>` : '`Not configured (Disabled)`'}\n\n` +
        `**Commands:**\n` +
        `• \`${prefix}vcrole set @Role\` — Bind voice role\n` +
        `• \`${prefix}vcrole remove\` — Disable voice role`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
