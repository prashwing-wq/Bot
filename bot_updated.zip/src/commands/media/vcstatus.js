/**
 * Voice Channel Status Command (Node.js)
 * Displays the Advanced Voice Status Control Panel with real-time telemetry & controls.
 */
const { SlashCommandBuilder, ChannelType } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { buildAdvancedVcStatusPanel } = require('./vcstatuspanel');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'vcstatus',
  aliases: ['voiceinfo', 'vcinfo2', 'vcstatuspanel2'],
  category: 'media',
  description: 'View advanced voice channel telemetry, status text, bitrate, capacity, and interactive controls',
  usage: '[#channel|ID|help]',
  cooldown: 3,

  slash: new SlashCommandBuilder()
    .setName('vcstatus')
    .setDescription('View advanced voice channel telemetry and interactive status controls')
    .addChannelOption(opt =>
      opt
        .setName('channel')
        .setDescription('Optional voice channel to inspect')
        .addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice)
        .setRequired(false)
    ),

  async execute(message, args, client, prefix) {
    if (args[0]?.toLowerCase() === 'help' || args[0]?.toLowerCase() === '--help') {
      const helpEmbed = createEmbed({
        title: '🎙️ Voice Status Command Guide',
        description:
          `> Advanced real-time voice channel telemetry and management panel.\n\n` +
          `• **Usage:** \`${prefix}vcstatus [#channel|ID]\`\n` +
          `• **Aliases:** \`${prefix}voiceinfo\`\n` +
          `• **Interactive Controls:**\n` +
          `  - 🎙️ **Set Status Text:** Configure custom voice channel status modal\n` +
          `  - 🗑️ **Clear Status:** Clear Discord voice status text\n` +
          `  - 🔒 **Lock / Unlock:** Toggle public Connect permission\n` +
          `  - 🎚️ **Bitrate Selector:** Switch between 64, 96, 128, 256, 384 kbps\n` +
          `  - 👥 **Set User Limit:** Adjust channel capacity limits (0-99)\n` +
          `  - 🔄 **Refresh:** Poll real-time audio/member telemetry\n` +
          `  - 🔌 **24/7 Controls:** Connect or disconnect persistent voice sentinel`,
        color: undefined,
        footer: { text: `Requested by ${message.author.username}` }
      });
      return message.reply({ embeds: [helpEmbed] });
    }

    // Resolve target voice channel
    let channel = message.member?.voice?.channel || message.mentions?.channels?.first?.();

    if (!channel && args[0] && /^\d{17,20}$/.test(args[0])) {
      channel = message.guild.channels.cache.get(args[0]) || (await message.guild.channels.fetch(args[0]).catch(() => null));
    }

    if (!channel) {
      const sdb = getServerDb(message.guild.id);
      const row = sdb.prepare('SELECT channel_id FROM home_voice_channels WHERE guild_id = ?').get(message.guild.id);
      if (row?.channel_id) {
        channel = message.guild.channels.cache.get(row.channel_id);
      }
    }

    if (!channel) {
      channel = message.guild.channels.cache.find(c => c.isVoiceBased?.() || c.type === 2) || null;
    }

    if (!channel) {
      return message.reply(
        `<a:tungsten_close:1567234632905138206> No voice channel found. Join a voice channel or specify one. Usage: \`${prefix}vcstatus [#channel|ID]\``
      );
    }

    const payload = buildAdvancedVcStatusPanel(message.guild, channel, client, prefix);
    return message.reply(payload);
  },

  async executeSlash(interaction, client) {
    const channelOpt = interaction.options.getChannel('channel');
    let channel = channelOpt || interaction.member?.voice?.channel;

    if (!channel) {
      const sdb = getServerDb(interaction.guild.id);
      const row = sdb.prepare('SELECT channel_id FROM home_voice_channels WHERE guild_id = ?').get(interaction.guild.id);
      if (row?.channel_id) {
        channel = interaction.guild.channels.cache.get(row.channel_id);
      }
    }

    if (!channel) {
      channel = interaction.guild.channels.cache.find(c => c.isVoiceBased?.() || c.type === 2) || null;
    }

    if (!channel) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> No voice channel found. Connect to a voice channel or select one.',
        flags: 64
      });
    }

    const payload = buildAdvancedVcStatusPanel(interaction.guild, channel, client, '/');
    return interaction.reply(payload);
  }
};
