/**
 * Soundboard Management Command (Node.js)
 * Manage server soundboard sounds (list, info, delete).
 */
const { PermissionsBitField, PermissionFlagsBits, Routes } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

// Helper to fetch soundboard sounds with fallback across Discord.js versions and environments
async function getSoundboardSounds(guild) {
  if (guild.soundboardSounds && typeof guild.soundboardSounds.fetch === 'function') {
    try {
      const fetched = await guild.soundboardSounds.fetch();
      if (fetched && typeof fetched.values === 'function') {
        return Array.from(fetched.values());
      }
      if (Array.isArray(fetched)) return fetched;
    } catch (_) {}
  }

  // REST API fallback
  const restClient = guild.client?.rest;
  if (restClient && Routes?.guildSoundboardSounds) {
    try {
      const res = await restClient.get(Routes.guildSoundboardSounds(guild.id));
      const items = res?.items || (Array.isArray(res) ? res : []);
      return items.map(s => ({
        id: s.sound_id || s.id,
        soundId: s.sound_id || s.id,
        name: s.name,
        volume: s.volume,
        emojiId: s.emoji_id,
        emojiName: s.emoji_name,
        userId: s.user_id,
        user: s.user,
        available: s.available
      }));
    } catch (_) {}
  }

  return [];
}

// Helper to find a sound by ID, exact name, or partial name
function findSound(sounds, query) {
  if (!query) return null;
  const clean = query.trim().toLowerCase();

  // 1. Direct ID match
  const byId = sounds.find(s => (s.soundId || s.id) === query.trim());
  if (byId) return byId;

  // 2. Exact name match (case-insensitive)
  const byExact = sounds.find(s => s.name && s.name.toLowerCase() === clean);
  if (byExact) return byExact;

  // 3. Partial name match
  return sounds.find(s => s.name && s.name.toLowerCase().includes(clean)) || null;
}

// Helper to delete a soundboard sound
async function removeSound(guild, sound, reason) {
  const soundId = sound.soundId || sound.id;

  if (typeof sound.delete === 'function') {
    return await sound.delete(reason);
  }
  if (guild.soundboardSounds && typeof guild.soundboardSounds.delete === 'function') {
    return await guild.soundboardSounds.delete(soundId, reason);
  }
  const restClient = guild.client?.rest;
  if (restClient && Routes?.guildSoundboardSound) {
    return await restClient.delete(Routes.guildSoundboardSound(guild.id, soundId), { reason });
  }
  throw new Error('Soundboard sound deletion is not supported in this runtime.');
}

module.exports = {
  name: 'soundboard',
  aliases: ['sound', 'sounds', 'sb'],
  category: 'media',
  description: 'Manage server soundboard sounds (list, info, delete).',
  permissions: ['ManageGuildExpressions'],
  botPermissions: ['ManageGuildExpressions'],
  usage: '<list | info <sound_name> | delete <sound_name>>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    // Check user permissions
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuildExpressions)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the **Manage Expressions** permission to manage soundboard sounds.'
          })
        ]
      });
    }

    // Check bot permissions
    const botMember = message.guild.members.me;
    if (botMember && !botMember.permissions.has(PermissionFlagsBits.ManageGuildExpressions)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Bot Missing Permissions',
            description: '<a:tungsten_close:1567234632905138206> I require the **Manage Expressions** permission to configure soundboard sounds.'
          })
        ]
      });
    }

    const sub = args[0]?.toLowerCase();

    // Subcommand: list
    if (sub === 'list') {
      const sounds = await getSoundboardSounds(message.guild);

      if (!sounds || sounds.length === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.INFO,
              title: '<a:tungsten_soundboard:1569329593561780354> Server Soundboard Sounds',
              description: 'This server currently has no custom soundboard sounds uploaded.'
            })
          ]
        });
      }

      const listLines = sounds.slice(0, 25).map((s, idx) => {
        const soundId = s.soundId || s.id;
        const emojiDisplay = s.emojiName ? `\`${s.emojiName}\` ` : '';
        const vol = Math.round((s.volume ?? 1) * 100);
        return `**${idx + 1}.** ${emojiDisplay}**${s.name}** — Volume: \`${vol}%\` (ID: \`${soundId}\`)`;
      });

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: `<a:tungsten_soundboard:1569329593561780354> Server Soundboard Sounds (${sounds.length})`,
            description:
              `> Custom sounds available for soundboard playback in this server.\n\n` +
              listLines.join('\n') +
              (sounds.length > 25 ? `\n\n*-# Showing first 25 sounds.*` : '')
          })
        ]
      });
    }

    // Subcommand: info <sound_name>
    if (sub === 'info') {
      const query = args.slice(1).join(' ').trim();
      if (!query) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Sound Name',
              description: `Usage: \`${prefix}soundboard info <sound_name|sound_id>\``
            })
          ]
        });
      }

      const sounds = await getSoundboardSounds(message.guild);
      const sound = findSound(sounds, query);

      if (!sound) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Sound Not Found',
              description: `<a:tungsten_close:1567234632905138206> No soundboard sound found matching "${query}".`
            })
          ]
        });
      }

      const soundId = sound.soundId || sound.id;
      const volumePercent = Math.round((sound.volume ?? 1) * 100);
      const emoji = sound.emojiName ? `\`${sound.emojiName}\`` : 'None';
      const creator = sound.user ? `<@${sound.user.id}>` : (sound.userId ? `<@${sound.userId}>` : 'Unknown');
      const cdnUrl = sound.url || `https://cdn.discordapp.com/soundboard-sounds/${soundId}`;

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: `<a:tungsten_soundboard:1569329593561780354> Soundboard Sound: ${sound.name}`,
            description:
              `• **Name:** **${sound.name}**\n` +
              `• **Sound ID:** \`${soundId}\`\n` +
              `• **Default Volume:** \`${volumePercent}%\`\n` +
              `• **Associated Emoji:** ${emoji}\n` +
              `• **Uploaded By:** ${creator}\n` +
              `• **Audio URL:** [Direct Sound File](${cdnUrl})\n\n` +
              `-# To delete this sound, use \`${prefix}soundboard delete ${soundId}\``
          })
        ]
      });
    }

    // Subcommand: delete <sound_name>
    if (sub === 'delete') {
      const query = args.slice(1).join(' ').trim();
      if (!query) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Sound Name',
              description: `Usage: \`${prefix}soundboard delete <sound_name|sound_id>\``
            })
          ]
        });
      }

      const sounds = await getSoundboardSounds(message.guild);
      const sound = findSound(sounds, query);

      if (!sound) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Sound Not Found',
              description: `<a:tungsten_close:1567234632905138206> No soundboard sound found matching "${query}".`
            })
          ]
        });
      }

      try {
        await removeSound(message.guild, sound, `[Soundboard] Deleted by ${message.author.tag}`);
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_trash:1567242891276062872> Soundboard Sound Deleted',
              description:
                `> Successfully deleted sound **${sound.name}** (\`${sound.soundId || sound.id}\`).\n\n` +
                `• **Moderator:** <@${message.author.id}>`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to Delete Sound',
              description: `<a:tungsten_close:1567234632905138206> Could not delete sound: ${err.message}`
            })
          ]
        });
      }
    }

    // Default: Help Guide
    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.PRIMARY,
          title: '<a:tungsten_soundboard:1569329593561780354> Soundboard Management',
          description:
            `Manage custom audio files in your server's soundboard.\n\n` +
            `• \`${prefix}soundboard list\` — View all server soundboard sounds\n` +
            `• \`${prefix}soundboard info <sound_name>\` — View details of a specific sound\n` +
            `• \`${prefix}soundboard delete <sound_name>\` — Delete a soundboard sound by name or ID\n\n` +
            `-# Tip: You can pass either the sound's name or its numeric ID.`
        })
      ]
    });
  }
};
