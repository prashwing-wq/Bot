/**
 * Voice & Media Controls Studio (Node.js)
 * High-performance voice tracking, J2C room controls, and live channel management.
 * Provides a live interactive studio with Discord Components V2 and live ActionRows.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const { createEmbed, isOwner } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

/**
 * Builds the interactive Voice Control Center payload.
 */
function buildVoiceStudioPayload(guild, member, prefix = '!', options = {}) {
  const allChannels = guild.channels?.cache
    ? (typeof guild.channels.cache.values === 'function' ? Array.from(guild.channels.cache.values()) : (Array.isArray(guild.channels.cache) ? guild.channels.cache : []))
    : [];
  const voiceChannels = allChannels.filter(c => c && typeof c.isVoiceBased === 'function' && c.isVoiceBased());
  let activeMembers = 0;
  voiceChannels.forEach(c => {
    activeMembers += c.members ? c.members.size : 0;
  });

  const userVoice = member?.voice?.channel;
  const userVoiceStatus = userVoice ? `Connected to ${userVoice} (\`${userVoice.name}\`)` : '`Not connected to VC`';

  let title = `<a:tungsten_sound:1567242242127568958>  Voice & J2C Control Center • ${guild.name}`;
  let desc =
    `> Real-time voice telemetry and automated room management.\n\n` +
    `• **Active Voice Channels:** \`${voiceChannels.length}\` channels\n` +
    `• **Active Voice Members:** \`${activeMembers}\` members listening/speaking\n` +
    `• **Your Voice Status:** ${userVoiceStatus}\n\n` +
    `**Quick Commands:**\n` +
    `• \`${prefix}vcstatus\` — View active VC bitrate, region & telemetry\n` +
    `• \`${prefix}voicemod muteall\` — Mute all members in your current VC\n` +
    `• \`${prefix}voicemod unmuteall\` — Unmute all members in your current VC\n` +
    `• \`${prefix}sethomevc\` — Configure 24/7 Home Voice Channel\n\n` +
    `*Click the buttons below to control your connected voice channel.*`;

  if (options.roleTitle) {
    title = `<a:tungsten_crown:1567238355463176334>  ${options.roleTitle} Voice Control Panel • ${guild.name}`;
    desc =
      `> Welcome <@${member?.id}>. Voice controls automatically deployed for your channel.\n\n` +
      `• **Connected Channel:** ${userVoice ? `${userVoice} (\`${userVoice.name}\`)` : '`Active VC`'}\n` +
      `• **Channel Bitrate:** \`${userVoice?.bitrate ? Math.round(userVoice.bitrate / 1000) : 64} kbps\`\n` +
      `• **Active Members in VC:** \`${userVoice?.members ? userVoice.members.size : 1}\` member(s)\n\n` +
      `**Interactive Channel Controls:**\n` +
      `• **Lock / Unlock:** Control whether @everyone can connect to this VC\n` +
      `• **Hide / Unhide:** Control whether this VC is visible in the server list\n` +
      `• **Mute / Unmute All:** Instantly server-mute or unmute all other members\n\n` +
      `*Click the buttons below to manage this voice channel in real time.*`;
  }

  const card = createV2Card({
    color: 0x2b2d31,
    title,
    description: desc,
    footerText: options.roleTitle
      ? `${options.roleTitle}: ${member?.displayName || member?.user?.username || 'Owner'} • Auto Voice Sentinel`
      : (member?.user ? `Requested by ${member.user.username}` : `Tungsten Voice Studio • ${guild.name}`)
  });

  const row0 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('vc:lock').setLabel('Lock VC').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_lock:1567241079030550668>'),
    new ButtonBuilder().setCustomId('vc:unlock').setLabel('Unlock VC').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_unlock:1567246515209117968>'),
    new ButtonBuilder().setCustomId('vc:hide').setLabel('Hide VC').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_ghost:1567240021692518512>'),
    new ButtonBuilder().setCustomId('vc:unhide').setLabel('Unhide VC').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_eye:1567238862042833088>')
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('vc:muteall').setLabel('Mute All').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_mute:1567241451992121647>'),
    new ButtonBuilder().setCustomId('vc:unmuteall').setLabel('Unmute All').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_sound:1567242242127568958>'),
    new ButtonBuilder().setCustomId('vc:refresh').setLabel('Refresh').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [card], components: [row0, row1] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'voice',
  aliases: ['vc', 'voicepanel', 'vcpanel'],
  category: 'media',
  description: 'View active voice channels, member counts, and Join-to-Create status with interactive studio.',
  usage: '[info | status | panel | j2c <#channel> [category]]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sub = args[0]?.toLowerCase();

    // ─────────────────────────────────────────────────────────────
    // Join-to-Create (J2C) Hub Configuration
    // ─────────────────────────────────────────────────────────────
    if (sub === 'j2c' || sub === 'setj2c' || sub === 'setup') {
      const { hasPerm } = require('../../utils/tools');
      if (!hasPerm(message.member, 'ManageChannels')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to configure Join-to-Create hubs.');
      }

      const targetChannel = message.mentions.channels.first()
        || message.guild.channels.cache.get(args[1])
        || message.guild.channels.cache.find(c => c.name.toLowerCase() === args.slice(1).join(' ').toLowerCase())
        || (message.member?.voice?.channel);

      if (!targetChannel || typeof targetChannel.isVoiceBased !== 'function' || !targetChannel.isVoiceBased()) {
        return message.reply(
          `<a:tungsten_warn:1567246685082746940> **Join-to-Create (J2C) Configuration**\n` +
          `• **Usage:** \`${prefix}voice j2c <#channel|ID> [category ID]\`\n` +
          `• **Example:** \`${prefix}voice j2c #Create-Voice\`\n` +
          `*Or simply join the desired voice channel and run \`${prefix}voice j2c\`.*`
        );
      }

      const categoryId = args[2] || targetChannel.parentId || null;
      const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');
      const sdb = getServerDb(message.guild.id);

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_hub_channel', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%s', 'now')
      `).run(targetChannel.id);

      if (categoryId) {
        sdb.prepare(`
          INSERT INTO server_settings (key, value, updated_at)
          VALUES ('j2c_category', ?, strftime('%s', 'now'))
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%s', 'now')
        `).run(String(categoryId));
      }

      syncServerDataToMaster(message.guild.id);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '<a:tungsten_sound:1567242242127568958>  Join-to-Create (J2C) Hub Configured',
        description:
          `> Successfully designated ${targetChannel} as this server's **Join-to-Create (J2C) Hub**.\n\n` +
          `• **Generator Channel:** ${targetChannel} (\`${targetChannel.id}\`)\n` +
          `• **Spawn Category:** ${categoryId ? `<#${categoryId}> (\`${categoryId}\`)` : '`Same Category as Hub`'}\n\n` +
          `*When any member joins this voice channel, Tungsten will automatically provision a temporary private room and move them into it with full room controls.*`
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'disablej2c' || sub === 'resetj2c') {
      const { hasPerm } = require('../../utils/tools');
      if (!hasPerm(message.member, 'ManageChannels')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission.');
      }
      const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');
      const sdb = getServerDb(message.guild.id);
      sdb.prepare("DELETE FROM server_settings WHERE key IN ('j2c_hub_channel', 'j2c_category')").run();
      syncServerDataToMaster(message.guild.id);
      return message.reply('<a:tungsten_sweep:1567242656281657414> Join-to-Create (J2C) hub has been disabled for this server.');
    }

    // ─────────────────────────────────────────────────────────────
    // Voice Channel Management Subcommands
    // ─────────────────────────────────────────────────────────────
    const { hasPerm } = require('../../utils/tools');
    const userVoice = message.member?.voice?.channel;

    const checkVoiceAccess = (perm) => {
      if (hasPerm(message.member, perm) || message.author.id === message.guild.ownerId || isOwner(message.author.id)) {
        return true;
      }
      if (userVoice) {
        try {
          const { getServerDb } = require('../../utils/serverDb');
          const sdb = getServerDb(message.guild.id);
          const room = sdb.prepare('SELECT 1 FROM voice_rooms WHERE channel_id = ? AND owner_id = ?').get(userVoice.id, message.author.id);
          if (room) return true;
        } catch (_) {}
      }
      return false;
    };

    if (sub === 'kickall' || sub === 'disconnectall') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('MoveMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Move Members** permission or room ownership.');
      }
      const targets = userVoice.members ? Array.from(userVoice.members.values()).filter(m => m.id !== client.user?.id) : [];
      let count = 0;
      for (const m of targets) {
        try {
          if (typeof m.voice.disconnect === 'function') {
            await m.voice.disconnect(`Voice kickall by ${message.author.tag}`);
            count++;
          }
        } catch (e) {}
      }
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🔌  Voice Disconnect All',
            description: `Successfully disconnected **${count}** member(s) from ${userVoice}.`
          })
        ]
      });
    }

    if (sub === 'muteall') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('MuteMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Mute Members** permission or room ownership.');
      }
      const targets = userVoice.members ? Array.from(userVoice.members.values()).filter(m => m.id !== client.user?.id && m.id !== message.author.id) : [];
      let count = 0;
      for (const m of targets) {
        try {
          await m.voice.setMute(true, `Voice muteall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🔇  Voice Mute All',
            description: `Successfully server-muted **${count}** member(s) in ${userVoice}.`
          })
        ]
      });
    }

    if (sub === 'unmuteall') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('MuteMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Mute Members** permission or room ownership.');
      }
      const targets = userVoice.members ? Array.from(userVoice.members.values()).filter(m => m.id !== client.user?.id) : [];
      let count = 0;
      for (const m of targets) {
        try {
          await m.voice.setMute(false, `Voice unmuteall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🔊  Voice Unmute All',
            description: `Successfully server-unmuted **${count}** member(s) in ${userVoice}.`
          })
        ]
      });
    }

    if (sub === 'deafenall') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('DeafenMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Deafen Members** permission or room ownership.');
      }
      const targets = userVoice.members ? Array.from(userVoice.members.values()).filter(m => m.id !== client.user?.id && m.id !== message.author.id) : [];
      let count = 0;
      for (const m of targets) {
        try {
          await m.voice.setDeaf(true, `Voice deafenall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🔕  Voice Deafen All',
            description: `Successfully server-deafened **${count}** member(s) in ${userVoice}.`
          })
        ]
      });
    }

    if (sub === 'undeafenall') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('DeafenMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Deafen Members** permission or room ownership.');
      }
      const targets = userVoice.members ? Array.from(userVoice.members.values()).filter(m => m.id !== client.user?.id) : [];
      let count = 0;
      for (const m of targets) {
        try {
          await m.voice.setDeaf(false, `Voice undeafenall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🔔  Voice Undeafen All',
            description: `Successfully server-undeafened **${count}** member(s) in ${userVoice}.`
          })
        ]
      });
    }

    if (sub === 'moveall') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('MoveMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Move Members** permission.');
      }
      const targetChanInput = args[1];
      const targetChan = message.mentions.channels.first()
        || (targetChanInput ? message.guild.channels.cache.get(targetChanInput.replace(/[<#>]/g, '')) : null)
        || message.guild.channels.cache.find(c => c.isVoiceBased?.() && c.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());

      if (!targetChan || !targetChan.isVoiceBased?.()) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Please provide a valid destination voice channel: \`${prefix}voice moveall <#channel|ID>\``);
      }
      const targets = userVoice.members ? Array.from(userVoice.members.values()).filter(m => m.id !== client.user?.id) : [];
      let count = 0;
      for (const m of targets) {
        try {
          await m.voice.setChannel(targetChan, `Voice moveall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '✈️  Voice Move All',
            description: `Successfully moved **${count}** member(s) from ${userVoice} to ${targetChan}.`
          })
        ]
      });
    }

    if (sub === 'pull') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to pull members into it.');
      }
      if (!checkVoiceAccess('MoveMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Move Members** permission.');
      }
      const targetInput = args[1];
      if (!targetInput) {
        return message.reply(`Usage: \`${prefix}voice pull <@member|id>\``);
      }
      const targetMember = await message.guild.members.fetch(targetInput.replace(/[<@!>]/g, '')).catch(() => null);
      if (!targetMember || !targetMember.voice?.channel) {
        return message.reply('<a:tungsten_close:1567234632905138206> Member is not connected to any voice channel.');
      }
      try {
        await targetMember.voice.setChannel(userVoice, `Pulled into voice by ${message.author.tag}`);
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '🧲  Member Pulled',
              description: `Successfully moved ${targetMember} into ${userVoice}.`
            })
          ]
        });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to move member: ${err.message}`);
      }
    }

    if (sub === 'pullall') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to pull members.');
      }
      if (!checkVoiceAccess('MoveMembers')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Move Members** permission.');
      }
      const allVcMembers = [];
      const channels = message.guild.channels.cache.values ? Array.from(message.guild.channels.cache.values()) : [];
      for (const c of channels) {
        if (c && c.isVoiceBased?.() && c.id !== userVoice.id && c.members) {
          for (const m of c.members.values()) {
            if (m.id !== client.user?.id) allVcMembers.push(m);
          }
        }
      }
      let count = 0;
      for (const m of allVcMembers) {
        try {
          await m.voice.setChannel(userVoice, `Voice pullall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🧲  Voice Pull All',
            description: `Successfully pulled **${count}** member(s) across the server into ${userVoice}.`
          })
        ]
      });
    }

    if (sub === 'lock') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('ManageChannels')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission or room ownership.');
      }
      try {
        await userVoice.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: false });
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_lock:1567241079030550668>  Voice Channel Locked',
              description: `**${userVoice.name}** is now locked. No additional members can connect.`
            })
          ]
        });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to lock voice channel: ${err.message}`);
      }
    }

    if (sub === 'unlock') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('ManageChannels')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission or room ownership.');
      }
      try {
        await userVoice.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: null });
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_unlock:1567246515209117968>  Voice Channel Unlocked',
              description: `**${userVoice.name}** is now unlocked. Members can connect freely.`
            })
          ]
        });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to unlock voice channel: ${err.message}`);
      }
    }

    if (sub === 'private') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('ManageChannels')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission or room ownership.');
      }
      try {
        await userVoice.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: false, Connect: false });
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_ghost:1567240021692518512>  Voice Channel Made Private',
              description: `**${userVoice.name}** is now private and hidden from public view.`
            })
          ]
        });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to make voice channel private: ${err.message}`);
      }
    }

    if (sub === 'unprivate') {
      if (!userVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel.');
      }
      if (!checkVoiceAccess('ManageChannels')) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission or room ownership.');
      }
      try {
        await userVoice.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: null, Connect: null });
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_eye:1567238862042833088>  Voice Channel Made Public',
              description: `**${userVoice.name}** is now public and visible in the channel list.`
            })
          ]
        });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to make voice channel public: ${err.message}`);
      }
    }

    let roleTitle = null;
    const inVc = Boolean(message.member?.voice?.channelId || message.member?.voice?.channel);
    if (inVc) {
      if (message.author.id === message.guild.ownerId) {
        roleTitle = 'Server Owner';
      } else if (isOwner(message.author.id)) {
        roleTitle = 'Bot Owner';
      } else {
        try {
          const { getServerDb } = require('../../utils/serverDb');
          const sdb = getServerDb(message.guild.id);
          const row = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id);
          if (row) roleTitle = 'Extra Owner';
        } catch (e) {}
      }
    }

    const payload = buildVoiceStudioPayload(message.guild, message.member, prefix, roleTitle ? { roleTitle } : {});
    return message.reply(payload);
  },

  buildVoiceStudioPayload
};
