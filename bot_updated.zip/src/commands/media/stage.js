/**
 * Stage Channel Management Command (Node.js)
 * Manage Stage channels & live stage instances (start, end, settopic, muteall, unmuteall).
 */
const { PermissionsBitField, PermissionFlagsBits, ChannelType, StageInstancePrivacyLevel } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'stage',
  aliases: ['stageinstance', 'stagechannel', 'stages'],
  category: 'media',
  description: 'Manage Stage channels and stage instances (start, end, settopic, muteall, unmuteall).',
  permissions: ['ManageChannels', 'MuteMembers'],
  botPermissions: ['ManageChannels', 'MuteMembers'],
  usage: '<start <topic> | end | settopic <topic> | muteall | unmuteall>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    // Check user permissions
    const canManageChannels = hasPerm(message.member, PermissionFlagsBits.ManageChannels);
    const canMuteMembers = hasPerm(message.member, PermissionFlagsBits.MuteMembers);
    if (!canManageChannels || !canMuteMembers) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the **Manage Channels** and **Mute Members** permissions to use stage controls.'
          })
        ]
      });
    }

    // Check bot permissions
    const botMember = message.guild.members.me;
    if (botMember && (!botMember.permissions.has(PermissionFlagsBits.ManageChannels) || !botMember.permissions.has(PermissionFlagsBits.MuteMembers))) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Bot Missing Permissions',
            description: '<a:tungsten_close:1567234632905138206> I require **Manage Channels** and **Mute Members** permissions to manage stage channels.'
          })
        ]
      });
    }

    const sub = args[0]?.toLowerCase();

    // Helper: Resolve the target Stage Channel
    function resolveStageChannel() {
      // 1. If caller is in a stage channel
      const memberChannel = message.member?.voice?.channel;
      if (memberChannel && (memberChannel.type === ChannelType.GuildStageVoice || memberChannel.type === 13)) {
        return memberChannel;
      }
      // 2. Mentioned channel or channel ID in arguments
      const mentionedChannel = message.mentions?.channels?.first() ||
        (args[1] ? message.guild.channels.cache.get(args[1]) : null) ||
        (args[2] ? message.guild.channels.cache.get(args[2]) : null);
      if (mentionedChannel && (mentionedChannel.type === ChannelType.GuildStageVoice || mentionedChannel.type === 13)) {
        return mentionedChannel;
      }
      // 3. Stage channel with active stage instance
      const activeInstance = message.guild.stageInstances?.cache?.first();
      if (activeInstance) {
        const ch = message.guild.channels.cache.get(activeInstance.channelId);
        if (ch) return ch;
      }
      // 4. Any stage channel in guild
      return message.guild.channels.cache.find(c => c.type === ChannelType.GuildStageVoice || c.type === 13) || null;
    }

    // Subcommand: start <topic>
    if (sub === 'start') {
      const topic = args.slice(1).join(' ').trim();
      if (!topic) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Stage Topic',
              description: `Usage: \`${prefix}stage start <topic>\`\nExample: \`${prefix}stage start Community Town Hall\``
            })
          ]
        });
      }

      const stageChannel = resolveStageChannel();
      if (!stageChannel) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Stage Channel Not Found',
              description: '<a:tungsten_close:1567234632905138206> No Stage Channel found. Please join a Stage Channel or create one first.'
            })
          ]
        });
      }

      // Check for existing active instance
      const existing = stageChannel.stageInstance ||
        message.guild.stageInstances?.cache?.find(si => si.channelId === stageChannel.id);
      if (existing) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.WARNING,
              title: 'Stage Already Active',
              description: `<a:tungsten_warn:1567246685082746940> A Stage instance is already active in ${stageChannel}: **"${existing.topic || 'Untitled'}"**`
            })
          ]
        });
      }

      try {
        let instance = null;
        if (message.guild.stageInstances && typeof message.guild.stageInstances.create === 'function') {
          instance = await message.guild.stageInstances.create({
            channel: stageChannel.id,
            topic: topic.slice(0, 120),
            privacyLevel: StageInstancePrivacyLevel?.GuildOnly || 2,
            sendStartNotification: false
          });
        } else if (typeof stageChannel.createStageInstance === 'function') {
          instance = await stageChannel.createStageInstance({
            topic: topic.slice(0, 120),
            privacyLevel: StageInstancePrivacyLevel?.GuildOnly || 2
          });
        }

        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '🎙️ Stage Started',
              description:
                `> Successfully started stage instance in ${stageChannel}!\n\n` +
                `• **Topic:** ${instance?.topic || topic.slice(0, 120)}\n` +
                `• **Moderator:** <@${message.author.id}>\n` +
                `• **Privacy:** Server Members Only`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to Start Stage',
              description: `<a:tungsten_close:1567234632905138206> Could not start stage instance: ${err.message}`
            })
          ]
        });
      }
    }

    // Subcommand: end
    if (sub === 'end') {
      const stageChannel = resolveStageChannel();
      if (!stageChannel) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Stage Channel Not Found',
              description: '<a:tungsten_close:1567234632905138206> No Stage Channel found in this server.'
            })
          ]
        });
      }

      const instance = stageChannel.stageInstance ||
        message.guild.stageInstances?.cache?.find(si => si.channelId === stageChannel.id);
      if (!instance) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'No Active Stage',
              description: `<a:tungsten_close:1567234632905138206> There is no active stage instance in ${stageChannel}.`
            })
          ]
        });
      }

      try {
        const oldTopic = instance.topic || 'Stage';
        await instance.delete(`[Stage] Ended by ${message.author.tag}`);
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '⏹️ Stage Ended',
              description:
                `> The stage in ${stageChannel} has been ended.\n\n` +
                `• **Topic Was:** ${oldTopic}\n` +
                `• **Moderator:** <@${message.author.id}>`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to End Stage',
              description: `<a:tungsten_close:1567234632905138206> Could not end stage instance: ${err.message}`
            })
          ]
        });
      }
    }

    // Subcommand: settopic <topic>
    if (sub === 'settopic') {
      const topic = args.slice(1).join(' ').trim();
      if (!topic) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Stage Topic',
              description: `Usage: \`${prefix}stage settopic <new_topic>\``
            })
          ]
        });
      }

      const stageChannel = resolveStageChannel();
      if (!stageChannel) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Stage Channel Not Found',
              description: '<a:tungsten_close:1567234632905138206> No Stage Channel found in this server.'
            })
          ]
        });
      }

      const instance = stageChannel.stageInstance ||
        message.guild.stageInstances?.cache?.find(si => si.channelId === stageChannel.id);
      if (!instance) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'No Active Stage',
              description: `<a:tungsten_close:1567234632905138206> No active stage instance found in ${stageChannel}. Start one first with \`${prefix}stage start <topic>\`.`
            })
          ]
        });
      }

      try {
        const newTopic = topic.slice(0, 120);
        if (typeof instance.setTopic === 'function') {
          await instance.setTopic(newTopic);
        } else if (typeof instance.edit === 'function') {
          await instance.edit({ topic: newTopic });
        }
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '📝 Stage Topic Updated',
              description:
                `> Successfully updated the stage topic in ${stageChannel}!\n\n` +
                `• **New Topic:** ${newTopic}\n` +
                `• **Moderator:** <@${message.author.id}>`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to Update Topic',
              description: `<a:tungsten_close:1567234632905138206> Could not update stage topic: ${err.message}`
            })
          ]
        });
      }
    }

    // Subcommand: muteall
    if (sub === 'muteall') {
      const stageChannel = resolveStageChannel();
      if (!stageChannel) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Stage Channel Not Found',
              description: '<a:tungsten_close:1567234632905138206> Please join a Stage Channel or specify one to mute members.'
            })
          ]
        });
      }

      const members = stageChannel.members ? [...stageChannel.members.values()] : [];
      let mutedCount = 0;

      for (const m of members) {
        if (m.id === client.user.id || m.id === message.author.id) continue;
        try {
          if (m.voice && !m.voice.serverMute && typeof m.voice.setMute === 'function') {
            await m.voice.setMute(true, `[Stage] Mass mute by ${message.author.tag}`);
            mutedCount++;
          }
        } catch (_) {}
      }

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🔇 Stage Members Muted',
            description:
              `> Server-muted **${mutedCount}** members in ${stageChannel}.\n\n` +
              `• **Moderator:** <@${message.author.id}>\n` +
              `-# Use \`${prefix}stage unmuteall\` to unmute.`
          })
        ]
      });
    }

    // Subcommand: unmuteall
    if (sub === 'unmuteall') {
      const stageChannel = resolveStageChannel();
      if (!stageChannel) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Stage Channel Not Found',
              description: '<a:tungsten_close:1567234632905138206> Please join a Stage Channel or specify one to unmute members.'
            })
          ]
        });
      }

      const members = stageChannel.members ? [...stageChannel.members.values()] : [];
      let unmutedCount = 0;

      for (const m of members) {
        if (m.id === client.user.id || m.id === message.author.id) continue;
        try {
          if (m.voice && m.voice.serverMute && typeof m.voice.setMute === 'function') {
            await m.voice.setMute(false, `[Stage] Mass unmute by ${message.author.tag}`);
            unmutedCount++;
          }
        } catch (_) {}
      }

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🔊 Stage Members Unmuted',
            description:
              `> Server-unmuted **${unmutedCount}** members in ${stageChannel}.\n\n` +
              `• **Moderator:** <@${message.author.id}>`
          })
        ]
      });
    }

    // Default: Help Guide
    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.PRIMARY,
          title: '🎙️ Stage Channel Controls',
          description:
            `Manage Discord Stage Channels and live stage sessions.\n\n` +
            `• \`${prefix}stage start <topic>\` — Start a live stage session with a topic\n` +
            `• \`${prefix}stage end\` — End the active stage session\n` +
            `• \`${prefix}stage settopic <topic>\` — Update the topic of the current stage\n` +
            `• \`${prefix}stage muteall\` — Server-mute all stage members\n` +
            `• \`${prefix}stage unmuteall\` — Server-unmute all stage members\n\n` +
            `-# Tip: Join the stage channel or mention it to execute controls.`
        })
      ]
    });
  }
};
