const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'resethomevc',
  aliases: ['removehomevc', 'clearhomevc', 'disablehomevc', 'disable247vc'],
  category: 'media',
  description: 'Disable the 24/7 Home Voice Channel and disconnect Tungsten',
  usage: '',
  cooldown: 5,
  permissions: ['ManageChannels'],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to disable 24/7 Home Voice.');
    }

    const sdb = getServerDb(message.guild.id);
    sdb.prepare('DELETE FROM home_voice_channels WHERE guild_id = ?').run(message.guild.id);

    // Disconnect bot from current voice
    try {
      if (message.guild.shard) {
        message.guild.shard.send({
          op: 4,
          d: {
            guild_id: message.guild.id,
            channel_id: null,
            self_mute: false,
            self_deaf: false
          }
        });
      }
    } catch (_) {}

    const embed = createEmbed({
      title: '🔌 24/7 Home Voice Channel Disabled',
      description: 'Tungsten has been disconnected and the 24/7 persistent voice anchor has been cleared.',
      color: 0xED4245
    });

    return message.reply({ embeds: [embed] });
  }
};
