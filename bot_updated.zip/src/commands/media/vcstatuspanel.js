const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits
} = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

/**
 * Build Advanced Voice Channel Status & Control Panel payload
 * 100% Colorless UI (color: undefined)
 *
 * @param {import('discord.js').Guild} guild
 * @param {import('discord.js').VoiceBasedChannel|null} channel
 * @param {import('discord.js').Client} client
 * @param {string} prefix
 * @returns {{ embeds: any[], components: any[] }}
 */
function buildAdvancedVcStatusPanel(guild, channel, client, prefix = '!') {
  if (!guild) {
    throw new Error('Guild is required to build VC status panel');
  }

  // Parameter shift fallback if called as (guild, client, prefix)
  if (channel && (channel.ws || channel.user || !channel.id)) {
    prefix = client || '!';
    client = channel;
    channel = null;
  }

  let row = null;
  try {
    const sdb = getServerDb(guild.id);
    row = sdb.prepare('SELECT channel_id, status_text, enabled, reconnect_count FROM home_voice_channels WHERE guild_id = ?').get(guild.id);
  } catch (_) {}

  // If channel is not provided or is an ID string, resolve it
  if (typeof channel === 'string') {
    channel = guild.channels.cache.get(channel) || null;
  }

  if (!channel) {
    if (row?.channel_id) {
      channel = guild.channels.cache.get(row.channel_id) || null;
    }
  }

  if (!channel) {
    channel = guild.members?.me?.voice?.channel || guild.channels.cache.find(c => c.isVoiceBased?.() || c.type === 2) || null;
  }

  // Channel privacy / lock status check
  let isLocked = false;
  if (channel && channel.permissionOverwrites?.cache) {
    const everyoneRole = guild.roles.everyone;
    const overwrites = channel.permissionOverwrites.cache.get(everyoneRole?.id);
    isLocked = Boolean(overwrites?.deny?.has(PermissionFlagsBits.Connect));
  }

  // 24/7 Home VC Sentinel status
  const isHomeConfigured = Boolean(row && row.enabled);
  const isHomeConnected = Boolean(channel && guild.members?.me?.voice?.channelId === channel.id);
  const reconnectCount = row?.reconnect_count || 0;
  const homeStatusText = isHomeConnected
    ? `🟢 **Connected** (${reconnectCount} reconnects)`
    : isHomeConfigured
      ? `🔴 **Disconnected** (${reconnectCount} reconnects)`
      : `⚪ **Inactive**`;

  // Voice status text resolution
  const voiceStatusText = (channel && (channel.status || channel.topic)) || row?.status_text || 'None set';

  // Bitrate resolution
  const bitrateKbps = channel?.bitrate ? Math.round(channel.bitrate / 1000) : 64;
  const bitrateText = `${bitrateKbps} kbps`;

  // User limit & capacity
  let memberCount = 0;
  let memberDisplay = '*None connected*';
  if (channel?.members && channel.members.size > 0) {
    memberCount = channel.members.size;
    const memberList = Array.from(channel.members.values()).map(m => {
      const isMuted = m.voice?.selfMute || m.voice?.serverMute;
      const isDeaf = m.voice?.selfDeaf || m.voice?.serverDeaf;
      const muteBadge = isMuted ? '🔇' : '🎙️';
      const deafBadge = isDeaf ? '🎧' : '';
      return `• **${m.displayName || m.user?.username || m.id}** [${muteBadge}${deafBadge}]`;
    });
    if (memberList.length > 8) {
      memberDisplay = memberList.slice(0, 8).join('\n') + `\n*...and ${memberList.length - 8} more*`;
    } else {
      memberDisplay = memberList.join('\n');
    }
  }

  const userLimit = channel?.userLimit || 0;
  const capacityText = userLimit > 0
    ? `${memberCount} / ${userLimit} members`
    : `${memberCount} / Unlimited (0)`;

  // RTC Region & Video quality
  const rtcRegionText = channel?.rtcRegion ? String(channel.rtcRegion).toUpperCase() : 'Automatic';
  const videoQualityText = channel?.videoQualityMode === 2 ? '720p 60fps' : 'Auto (Full)';

  // Build 100% Colorless Embed (color: undefined)
  const embed = createEmbed({
    title: `🎙️ Advanced Voice Status Control: ${channel ? channel.name : 'Voice Sentinel'}`,
    description: channel
      ? `> Real-time telemetry and operational controls for ${channel}.\n\n` +
        `• **Channel ID:** \`${channel.id}\`\n` +
        `• **Voice Status:** \`${voiceStatusText}\`\n` +
        `• **Real-time Bitrate:** \`${bitrateText}\`\n` +
        `• **Capacity & Limit:** \`${capacityText}\`\n` +
        `• **RTC Region:** \`${rtcRegionText}\`\n` +
        `• **Video Quality:** \`${videoQualityText}\`\n` +
        `• **24/7 Sentinel State:** ${homeStatusText}\n` +
        `• **Channel Privacy:** ${isLocked ? '🔒 **Locked** (@everyone denied)' : '🔓 **Open** (Public connect)'}`
      : `> No voice channel currently active or configured. Join a voice channel or configure 24/7 Home VC.`,
    fields: channel ? [
      {
        name: `Connected Members (${memberCount})`,
        value: memberDisplay,
        inline: false
      }
    ] : [],
    color: undefined,
    footer: { text: `Voice Sentinel • Channel ID: ${channel ? channel.id : 'N/A'} • ${prefix}vcstatus` }
  });

  // ActionRow 1: Status & Lock Controls
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('vcs:set_status')
      .setLabel('Set Status Text')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🎙️')
      .setDisabled(!channel),
    new ButtonBuilder()
      .setCustomId('vcs:clear_status')
      .setLabel('Clear Status')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🗑️')
      .setDisabled(!channel),
    new ButtonBuilder()
      .setCustomId('vcs:toggle_lock')
      .setLabel(isLocked ? 'Unlock VC' : 'Lock VC')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔒')
      .setDisabled(!channel),
    new ButtonBuilder()
      .setCustomId('vcs:choose_vc')
      .setLabel('Choose VC')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔀')
  );

  // ActionRow 2: Bitrate StringSelectMenu
  const currentBitrate = channel?.bitrate || 64000;
  const row2 = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('vcs:select_bitrate')
      .setPlaceholder(channel ? `Bitrate: ${bitrateKbps} kbps (Select to change)` : 'Select Voice Channel Bitrate')
      .setDisabled(!channel)
      .addOptions([
        {
          label: '64 kbps',
          description: 'Standard Audio Quality (Mobile Friendly)',
          value: '64000',
          emoji: '📻',
          default: currentBitrate === 64000
        },
        {
          label: '96 kbps',
          description: 'High Quality Audio (Discord Default)',
          value: '96000',
          emoji: '🎙️',
          default: currentBitrate === 96000
        },
        {
          label: '128 kbps',
          description: 'Very High Quality (Nitro Tier 1)',
          value: '128000',
          emoji: '🔊',
          default: currentBitrate === 128000
        },
        {
          label: '256 kbps',
          description: 'Broadcast Studio Quality (Nitro Tier 2)',
          value: '256000',
          emoji: '🎧',
          default: currentBitrate === 256000
        },
        {
          label: '384 kbps',
          description: 'Lossless Master Audio (Nitro Tier 3)',
          value: '384000',
          emoji: '🎚️',
          default: currentBitrate === 384000
        }
      ])
  );

  // ActionRow 3: Limit, Refresh & 24/7 Controls
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('vcs:set_limit')
      .setLabel('Set User Limit')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('👥')
      .setDisabled(!channel),
    new ButtonBuilder()
      .setCustomId('vcs:refresh')
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔄'),
    new ButtonBuilder()
      .setCustomId('homevc:reconnect')
      .setLabel('24/7 Reconnect')
      .setStyle(ButtonStyle.Success)
      .setEmoji('🔌'),
    new ButtonBuilder()
      .setCustomId('homevc:disconnect')
      .setLabel('24/7 Disconnect')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('⏹️')
  );

  return { embeds: [embed], components: [row1, row2, row3] };
}

// Backward compatible alias
function buildHomeVcPanel(guild, client, prefix) {
  return buildAdvancedVcStatusPanel(guild, null, client, prefix);
}

module.exports = {
  name: 'vcstatuspanel',
  aliases: ['vspanel', 'voicepanel247', 'vcpanel'],
  category: 'media',
  description: 'Deploy an advanced interactive control panel for Voice Channel status, bitrate, telemetry, and 24/7 sentinel',
  usage: '[#channel|ID]',
  cooldown: 5,
  permissions: ['ManageChannels'],
  botPermissions: ['Connect', 'Speak'],
  buildAdvancedVcStatusPanel,
  buildHomeVcPanel,
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to deploy the VC Status Panel.');
    }

    // Resolve target voice channel
    let channel = message.member?.voice?.channel || message.mentions?.channels?.first?.();

    if (!channel && args[0] && /^\d{17,20}$/.test(args[0])) {
      channel = message.guild.channels.cache.get(args[0]) || (await message.guild.channels.fetch(args[0]).catch(() => null));
    }

    if (!channel) {
      const sdb = getServerDb(message.guild.id);
      const row = sdb.prepare('SELECT channel_id FROM home_voice_channels WHERE guild_id = ?').get(message.guild.id);
      if (row?.channel_id) {
        channel = message.guild.channels.cache.get(row.channel_id);
      }
    }

    if (!channel) {
      channel = message.guild.channels.cache.find(c => c.isVoiceBased?.() || c.type === 2) || null;
    }

    const payload = buildAdvancedVcStatusPanel(message.guild, channel, client, prefix);
    return message.reply(payload);
  }
};
