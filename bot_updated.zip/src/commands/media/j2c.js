/**
 * Tungsten Dynamic Join-to-Create (J2C) Sentinel Studio (Node.js)
 * Streamlined temporary voice channel generator with automated 1-click provisioning,
 * configurable capacity thresholds, and interactive in-room voice lounge controls.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  PermissionsBitField,
  SlashCommandBuilder
} = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm } = require('../../utils/tools');

/**
 * Builds the interactive Master J2C Room Controls Payload for dynamic voice lounges.
 */
function buildJ2CRoomPayload(channel, ownerMember, isLocked = false, userLimit = 0) {
  const memberCount = channel?.members ? channel.members.size : 1;
  const ownerName = ownerMember?.displayName || ownerMember?.user?.username || 'Owner';
  const ownerMention = ownerMember ? `<@${ownerMember.id}>` : 'Owner';

  const card = createV2Card({
    color: 0x5865F2,
    title: `<a:tungsten_sound:1567242242127568958> Voice Lounge • ${channel?.name || 'Dynamic Voice'}`,
    description:
      `> Welcome ${ownerMention}! You have full control over your temporary voice room.\n\n` +
      `• **Room Owner:** ${ownerMention}\n` +
      `• **Privacy:** ${isLocked ? '<a:tungsten_lock:1567241079030550668> **Locked** (Friends only)' : '<a:tungsten_unlock:1567246515209117968> **Public** (Anyone can join)'}\n` +
      `• **Capacity:** \`${userLimit === 0 ? 'Unlimited' : `${userLimit} users`}\`\n` +
      `• **Connected Members:** \`${memberCount}\` member(s)\n\n` +
      `<a:tungsten_gear:1567239932970406012> **Room Management Controls:**\n` +
      `• <a:tungsten_lock:1567241079030550668> **Lock / Unlock** — Restrict or allow connection access\n` +
      `• <a:tungsten_user:1567246556778995802> **Capacity** — Set maximum member limit (0-99)\n` +
      `• <a:tungsten_memo:1567241226577780957> **Rename** — Give your lounge a custom title\n` +
      `• <a:tungsten_boot:1567233502418575501> **Kick** — Disconnect an unwelcome member\n` +
      `• <a:tungsten_crown:1567238355463176334> **Claim** — Take ownership if the creator departs`,
    footerText: `Tungsten J2C • Room Owner: ${ownerName}`
  });

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('j2c:lock')
      .setLabel('Lock')
      .setEmoji('<a:tungsten_lock:1567241079030550668>')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('j2c:unlock')
      .setLabel('Unlock')
      .setEmoji('<a:tungsten_unlock:1567246515209117968>')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('j2c:limit')
      .setLabel('Capacity')
      .setEmoji('<a:tungsten_user:1567246556778995802>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('j2c:rename')
      .setLabel('Rename')
      .setEmoji('<a:tungsten_memo:1567241226577780957>')
      .setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('j2c:kick')
      .setLabel('Kick Member')
      .setEmoji('<a:tungsten_boot:1567233502418575501>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('j2c:claim')
      .setLabel('Claim Ownership')
      .setEmoji('<a:tungsten_crown:1567238355463176334>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('j2c:refresh')
      .setLabel('Refresh')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [card], components: [row1, row2] };
}

/**
 * Builds the interactive Master J2C Studio Payload.
 */
function buildJ2CStudioPayload(guild, prefix = '!') {
  const sdb = getServerDb(guild.id);

  let hubId = null;
  let catId = null;
  let userLimit = 'Unlimited (0)';
  let template = "🔊・{user}'s Lounge";
  let isEnabled = true;

  try {
    const rowHub = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_hub_channel'").get();
    if (rowHub?.value) hubId = rowHub.value;

    const rowCat = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_category'").get();
    if (rowCat?.value) catId = rowCat.value;

    const rowLim = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_user_limit'").get();
    if (rowLim?.value) userLimit = rowLim.value === '0' ? 'Unlimited (0)' : `${rowLim.value} users`;

    const rowTmpl = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_name_template'").get();
    if (rowTmpl?.value) template = rowTmpl.value;

    const rowEn = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_enabled'").get();
    if (rowEn) isEnabled = rowEn.value === '1';
    else isEnabled = Boolean(hubId);
  } catch (_) {}

  let activeRoomsCount = 0;
  try {
    const rRow = sdb.prepare('SELECT COUNT(*) as cnt FROM voice_rooms WHERE guild_id = ?').get(guild.id);
    activeRoomsCount = rRow?.cnt || 0;
  } catch (_) {}

  const hubStr = hubId ? `<#${hubId}>` : '`<NOT CONFIGURED>`';
  const catStr = catId ? `<#${catId}>` : '`Auto-Inherit from Hub`';
  const statusBadge = isEnabled && hubId
    ? '<a:tungsten_ui_toggle_on:1569329685110849576> **ARMED & OPERATIONAL**'
    : '<a:tungsten_ui_toggle_off:1569329677187678368> **DISARMED / INACTIVE**';

  const card = createV2Card({
    color: 0x5865F2,
    title: `<a:tungsten_sound:1567242242127568958> Join-to-Create Sentinel Studio • ${guild.name}`,
    description:
      `> Automated dynamic voice channel engine with instant room provisioning,\n` +
      `> custom capacity thresholds, category routing, and dedicated voice lounge controls.\n\n` +
      `• **System Status:** ${statusBadge}\n` +
      `• **Generator Hub Voice:** ${hubStr}\n` +
      `• **Creation Category:** ${catStr}\n` +
      `• **Default Room Capacity:** \`${userLimit}\`\n` +
      `• **Room Title Template:** \`${template}\`\n` +
      `• **Active Temporary Rooms:** \`${activeRoomsCount}\` channels\n\n` +
      `**<a:tungsten_bolt:1567233430570405968> Quick Management Commands:**\n` +
      `• \`${prefix}j2c setup\` — 1-click automated setup (creates Category & Hub)\n` +
      `• \`${prefix}j2c hub <#channel>\` — Assign generator hub voice channel\n` +
      `• \`${prefix}j2c limit <0-99>\` — Set default member capacity\n` +
      `• \`${prefix}j2c template <name>\` — Customize channel naming template\n` +
      `• \`${prefix}j2c toggle\` — Enable or disable the dynamic voice generator\n` +
      `• \`${prefix}j2c reset\` — Wipe all dynamic voice configuration`,
    footerText: `Tungsten Voice Architecture • Use interactive controls below`
  });

  // Top Action Row 1 (Buttons)
  const btnRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('j2c:setup_auto')
      .setLabel('1-Click Setup')
      .setEmoji('<a:tungsten_gear:1567239932970406012>')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('j2c:toggle')
      .setLabel(isEnabled ? 'Disarm J2C' : 'Arm J2C')
      .setEmoji(isEnabled ? '<a:tungsten_ui_toggle_off:1569329677187678368>' : '<a:tungsten_ui_toggle_on:1569329685110849576>')
      .setStyle(isEnabled ? ButtonStyle.Secondary : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('j2c:limit_studio')
      .setLabel('Set Limit')
      .setEmoji('<a:tungsten_user:1567246556778995802>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('j2c:reset')
      .setLabel('Reset')
      .setEmoji('<a:tungsten_trash:1567242891276062872>')
      .setStyle(ButtonStyle.Danger)
  );

  // Action Row 2 (Optional single Voice Channel Select Menu)
  const selectHub = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId('j2c:select_hub')
      .setPlaceholder('Select Generator Voice Channel (Hub)...')
      .setChannelTypes(ChannelType.GuildVoice)
      .setMinValues(1)
      .setMaxValues(1)
  );

  return { embeds: [card], components: [btnRow, selectHub] };
}

module.exports = {
  name: 'j2c',
  aliases: ['jointocreate', 'j2cpanel', 'dynamicvc', 'j2chub'],
  category: 'media',
  description: 'Join-to-Create dynamic voice channels hub and management studio.',
  usage: '[setup | panel | hub <#channel> | limit <0-99> | template <name> | toggle | reset]',
  cooldown: 3,
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels', 'MoveMembers'],

  slash: new SlashCommandBuilder()
    .setName('j2c')
    .setDescription('Configure Join-to-Create dynamic voice channel generator.')
    .addSubcommand(sub =>
      sub.setName('setup').setDescription('1-click auto-setup: creates category & voice hub automatically.')
    )
    .addSubcommand(sub =>
      sub.setName('auto').setDescription('1-click auto-setup: creates category & voice hub automatically.')
    )
    .addSubcommand(sub =>
      sub.setName('quicksetup').setDescription('1-click auto-setup: creates category & voice hub automatically.')
    )
    .addSubcommand(sub =>
      sub.setName('panel').setDescription('Open the interactive J2C Sentinel Studio.')
    )
    .addSubcommand(sub =>
      sub
        .setName('hub')
        .setDescription('Set the voice channel members join to create private rooms.')
        .addChannelOption(opt =>
          opt
            .setName('channel')
            .setDescription('The generator voice channel')
            .addChannelTypes(ChannelType.GuildVoice)
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('limit')
        .setDescription('Set the default member capacity for generated rooms (0-99).')
        .addIntegerOption(opt =>
          opt
            .setName('limit')
            .setDescription('Member capacity (0 for unlimited)')
            .setMinValue(0)
            .setMaxValue(99)
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('template')
        .setDescription('Set the naming template for generated rooms.')
        .addStringOption(opt =>
          opt
            .setName('name')
            .setDescription('Channel name template (use {user} for username)')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('toggle')
        .setDescription('Enable or disable the dynamic voice room generator.')
    )
    .addSubcommand(sub =>
      sub
        .setName('reset')
        .setDescription('Reset all Join-to-Create settings.')
    ),

  buildJ2CStudioPayload,
  buildJ2CRoomPayload,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, 'ManageChannels')) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to configure Join-to-Create.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || '').toLowerCase();

    // ─────────────────────────────────────────────────────────────
    // 1. Quick 1-Click Auto Setup
    // ─────────────────────────────────────────────────────────────
    if (sub === 'setup' || sub === 'auto' || sub === 'quicksetup') {
      const botMember = message.guild.members.me;
      if (!botMember?.permissions.has([PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.MoveMembers])) {
        return message.reply('<a:tungsten_close:1567234632905138206> I need the **Manage Channels** and **Move Members** permissions to set up Join-to-Create.');
      }

      const findChannel = (predicate) => {
        if (typeof message.guild.channels?.cache?.find === 'function') {
          return message.guild.channels.cache.find(predicate);
        }
        if (message.guild.channels?.cache?.values) {
          for (const c of message.guild.channels.cache.values()) {
            if (predicate(c)) return c;
          }
        }
        return null;
      };

      let category = findChannel(c => c.type === ChannelType.GuildCategory && c.name?.toLowerCase().includes('join to create'));
      if (!category && typeof message.guild.channels?.create === 'function') {
        category = await message.guild.channels.create({
          name: '🔊 Join To Create',
          type: ChannelType.GuildCategory
        }).catch(() => null);
      }

      let hubChannel = findChannel(c => c.type === ChannelType.GuildVoice && c.name?.toLowerCase().includes('join to create'));
      if (!hubChannel && typeof message.guild.channels?.create === 'function') {
        hubChannel = await message.guild.channels.create({
          name: '➕ Join to Create',
          type: ChannelType.GuildVoice,
          parent: category?.id,
          userLimit: 0
        }).catch(() => null);
      }

      if (!hubChannel) {
        return message.reply('<a:tungsten_close:1567234632905138206> Failed to create J2C channels. Ensure my role is high enough and has **Manage Channels**.');
      }

      // Explicitly ensure bot has ViewChannel, Connect, MoveMembers, ManageChannels on the hub channel
      if (botMember && typeof hubChannel.permissionOverwrites?.edit === 'function') {
        await hubChannel.permissionOverwrites.edit(botMember.id, {
          ViewChannel: true,
          Connect: true,
          MoveMembers: true,
          ManageChannels: true
        }).catch(() => null);
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_hub_channel', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(hubChannel.id);

      if (category) {
        sdb.prepare(`
          INSERT INTO server_settings (key, value, updated_at)
          VALUES ('j2c_category', ?, strftime('%s', 'now'))
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).run(category.id);
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_enabled', '1', strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run();

      const card = createV2Card({
        color: 0x5865F2,
        title: '<a:tungsten_sound:1567242242127568958> Join-to-Create • 1-Click Setup Complete',
        description:
          `> <a:tungsten_success:1567242523468890274> **Join-to-Create is now armed and operational!**\n\n` +
          `• **Hub Channel:** <#${hubChannel.id}>\n` +
          `${category ? `• **Creation Category:** **${category.name}** (\`${category.id}\`)\n` : ''}` +
          `• **System Status:** <a:tungsten_ui_toggle_on:1569329685110849576> **Armed**\n\n` +
          `Simply connect to <#${hubChannel.id}> to automatically generate your personal temporary voice lounge with full in-room controls.`,
        footerText: 'Tungsten Voice Architecture • 1-Click Auto Setup'
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Interactive Studio Panel
    // ─────────────────────────────────────────────────────────────
    if (!sub || sub === 'panel' || sub === 'studio' || sub === 'menu') {
      const payload = buildJ2CStudioPayload(message.guild, prefix);
      return message.reply(payload);
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Generator Hub Binding
    // ─────────────────────────────────────────────────────────────
    if (sub === 'hub' || sub === 'sethub' || sub === 'channel') {
      const chan = (typeof message.mentions.channels?.first === 'function' ? message.mentions.channels.first() : (message.mentions.channels?.values ? [...message.mentions.channels.values()][0] : null))
        || message.guild.channels.cache.get(args[1]?.replace(/[<#>]/g, ''))
        || message.member?.voice?.channel;

      if (!chan || chan.type !== ChannelType.GuildVoice) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please mention a valid **voice channel** or join one before running this command.');
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_hub_channel', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(chan.id);

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_enabled', '1', strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run();

      return message.reply(`<a:tungsten_success:1567242523468890274> Join-to-Create generator hub bound to <#${chan.id}>. Members joining this channel will receive an automated private room.`);
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Member Capacity Limit
    // ─────────────────────────────────────────────────────────────
    if (sub === 'limit' || sub === 'userlimit' || sub === 'capacity') {
      const limit = parseInt(args[1], 10);
      if (isNaN(limit) || limit < 0 || limit > 99) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please provide a valid capacity limit between `0` (unlimited) and `99`.');
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_user_limit', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(String(limit));

      return message.reply(`<a:tungsten_success:1567242523468890274> Default dynamic room limit set to **${limit === 0 ? 'Unlimited (0)' : `${limit} members`}**.`);
    }

    // ─────────────────────────────────────────────────────────────
    // 5. Channel Name Template
    // ─────────────────────────────────────────────────────────────
    if (sub === 'template' || sub === 'name' || sub === 'nametemplate') {
      const tmpl = args.slice(1).join(' ').trim();
      if (!tmpl) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please provide a name template. Use \`{user}\` for the member's name.\nExample: \`${prefix}j2c template 🔊・{user}'s Lounge\``);
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_name_template', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(tmpl.slice(0, 60));

      return message.reply(`<a:tungsten_success:1567242523468890274> Dynamic channel naming template set to: \`${tmpl.slice(0, 60)}\``);
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Toggle System Enable / Disable
    // ─────────────────────────────────────────────────────────────
    if (sub === 'toggle' || sub === 'enable' || sub === 'disable') {
      const curRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_enabled'").get();
      let willEnable = sub === 'enable' ? true : (sub === 'disable' ? false : !(curRow?.value === '1'));

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_enabled', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(willEnable ? '1' : '0');

      return message.reply(
        willEnable
          ? '<a:tungsten_success:1567242523468890274> <a:tungsten_ui_toggle_on:1569329685110849576> Join-to-Create dynamic generator is now **ENABLED**.'
          : '<a:tungsten_success:1567242523468890274> <a:tungsten_ui_toggle_off:1569329677187678368> Join-to-Create dynamic generator is now **DISABLED**.'
      );
    }

    // ─────────────────────────────────────────────────────────────
    // 7. Reset Configuration
    // ─────────────────────────────────────────────────────────────
    if (sub === 'reset' || sub === 'clear') {
      sdb.prepare(`
        DELETE FROM server_settings
        WHERE key IN ('j2c_hub_channel', 'j2c_category', 'j2c_control_panel_channel', 'j2c_user_limit', 'j2c_bitrate', 'j2c_name_template', 'j2c_enabled')
      `).run();
      return message.reply('<a:tungsten_success:1567242523468890274> All Join-to-Create settings have been cleanly reset.');
    }

    return message.reply(`Unknown subcommand. Use \`${prefix}j2c panel\` to launch the interactive studio.`);
  },

  async executeSlash(interaction, client) {
    if (!interaction.guild) return interaction.reply({ content: 'Servers only.', ephemeral: true });
    if (!hasPerm(interaction.member, 'ManageChannels')) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Missing `Manage Channels` permission.', ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    const sdb = getServerDb(interaction.guild.id);
    const prefix = client.config?.DEFAULT_PREFIX || '!';

    if (sub === 'setup' || sub === 'auto' || sub === 'quicksetup') {
      const botMember = interaction.guild.members.me;
      if (!botMember?.permissions.has([PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.MoveMembers])) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> I need `Manage Channels` and `Move Members` permissions.', ephemeral: true });
      }

      let category = interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes('join to create'));
      if (!category && typeof interaction.guild.channels.create === 'function') {
        category = await interaction.guild.channels.create({
          name: '🔊 Join To Create',
          type: ChannelType.GuildCategory
        }).catch(() => null);
      }

      let hubChannel = interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildVoice && c.name.toLowerCase().includes('join to create'));
      if (!hubChannel && typeof interaction.guild.channels.create === 'function') {
        hubChannel = await interaction.guild.channels.create({
          name: '➕ Join to Create',
          type: ChannelType.GuildVoice,
          parent: category?.id,
          userLimit: 0
        }).catch(() => null);
      }

      if (!hubChannel) {
        return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Failed to create J2C channels.', ephemeral: true });
      }

      // Explicitly ensure bot has ViewChannel, Connect, MoveMembers, ManageChannels on the hub channel
      if (botMember && typeof hubChannel.permissionOverwrites?.edit === 'function') {
        await hubChannel.permissionOverwrites.edit(botMember.id, {
          ViewChannel: true,
          Connect: true,
          MoveMembers: true,
          ManageChannels: true
        }).catch(() => null);
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_hub_channel', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(hubChannel.id);

      if (category) {
        sdb.prepare(`
          INSERT INTO server_settings (key, value, updated_at)
          VALUES ('j2c_category', ?, strftime('%s', 'now'))
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).run(category.id);
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_enabled', '1', strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run();

      const card = createV2Card({
        color: 0x5865F2,
        title: '<a:tungsten_sound:1567242242127568958> Join-to-Create • 1-Click Setup Complete',
        description:
          `> <a:tungsten_success:1567242523468890274> **Join-to-Create is now armed and operational!**\n\n` +
          `• **Hub Channel:** <#${hubChannel.id}>\n` +
          `${category ? `• **Creation Category:** **${category.name}** (\`${category.id}\`)\n` : ''}` +
          `• **System Status:** <a:tungsten_ui_toggle_on:1569329685110849576> **Armed**\n\n` +
          `Simply connect to <#${hubChannel.id}> to automatically generate your personal temporary voice lounge with full in-room controls.`,
        footerText: 'Tungsten Voice Architecture • 1-Click Auto Setup'
      });

      return interaction.reply({ embeds: [card], ephemeral: true });
    }

    if (sub === 'panel') {
      const payload = buildJ2CStudioPayload(interaction.guild, prefix);
      return interaction.reply(payload);
    }

    if (sub === 'hub') {
      const chan = interaction.options.getChannel('channel');
      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_hub_channel', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(chan.id);
      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_enabled', '1', strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run();
      return interaction.reply({ content: `<a:tungsten_success:1567242523468890274> J2C Generator hub set to <#${chan.id}>.`, ephemeral: true });
    }

    if (sub === 'limit') {
      const limit = interaction.options.getInteger('limit');
      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_user_limit', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(String(limit));
      return interaction.reply({
        content: `<a:tungsten_success:1567242523468890274> Default dynamic room limit set to **${limit === 0 ? 'Unlimited (0)' : `${limit} members`}**.`,
        ephemeral: true
      });
    }

    if (sub === 'template') {
      const tmpl = interaction.options.getString('name');
      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_name_template', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(tmpl.slice(0, 60));
      return interaction.reply({
        content: `<a:tungsten_success:1567242523468890274> Dynamic channel naming template set to: \`${tmpl.slice(0, 60)}\``,
        ephemeral: true
      });
    }

    if (sub === 'toggle') {
      const curRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_enabled'").get();
      const willEnable = !(curRow?.value === '1');
      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('j2c_enabled', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(willEnable ? '1' : '0');

      return interaction.reply({
        content: willEnable
          ? '<a:tungsten_success:1567242523468890274> <a:tungsten_ui_toggle_on:1569329685110849576> Dynamic J2C generator enabled.'
          : '<a:tungsten_success:1567242523468890274> <a:tungsten_ui_toggle_off:1569329677187678368> Dynamic J2C generator disabled.',
        ephemeral: true
      });
    }

    if (sub === 'reset') {
      sdb.prepare(`
        DELETE FROM server_settings
        WHERE key IN ('j2c_hub_channel', 'j2c_category', 'j2c_control_panel_channel', 'j2c_user_limit', 'j2c_bitrate', 'j2c_name_template', 'j2c_enabled')
      `).run();
      return interaction.reply({
        content: '<a:tungsten_success:1567242523468890274> All Join-to-Create settings have been cleanly reset.',
        ephemeral: true
      });
    }
  }
};
