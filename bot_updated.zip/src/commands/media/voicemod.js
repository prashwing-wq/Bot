/**
 * Voice Channel Moderation Command (Node.js)
 * Mass voice moderation: moveall, muteall, unmuteall, deafenall.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');

module.exports = {
  name: 'voicemod',
  aliases: ['vcm', 'vcmuteall', 'vcmoveall'],
  category: 'media',
  description: 'Mass moderation controls for voice channels (muteall, unmuteall, moveall).',
  permissions: ['MuteMembers'],
  botPermissions: ['MuteMembers'],
  usage: '[muteall | unmuteall | deafenall | moveall <#new_vc>]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.MuteMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Mute Members` permission to use voice moderation.');
    }

    const voiceChannel = message.member.voice.channel;
    if (!voiceChannel) {
      return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to execute mass voice moderation.');
    }

    const sub = args[0]?.toLowerCase();
    const members = voiceChannel.members.filter(m => m.id !== client.user.id && m.id !== message.author.id);

    if (sub === 'muteall') {
      let count = 0;
      for (const member of members.values()) {
        try {
          await member.voice.setMute(true, `[VoiceMod] Muteall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply(`<a:tungsten_mute:1567241451992121647> Server muted **${count} members** in ${voiceChannel}.`);
    }

    if (sub === 'unmuteall') {
      let count = 0;
      for (const member of members.values()) {
        try {
          await member.voice.setMute(false, `[VoiceMod] Unmuteall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply(`<a:tungsten_sound:1567242242127568958> Server unmuted **${count} members** in ${voiceChannel}.`);
    }

    if (sub === 'moveall') {
      const targetChannel = message.mentions?.channels?.first() || (args[1] ? message.guild.channels.cache.get(args[1]) : null);
      if (!targetChannel || !targetChannel.isVoiceBased()) {
        return message.reply(`Usage: \`${prefix}voicemod moveall #target_vc\``);
      }

      let count = 0;
      for (const member of voiceChannel.members.values()) {
        try {
          await member.voice.setChannel(targetChannel, `[VoiceMod] Moveall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply(`✈️ Moved **${count} members** from ${voiceChannel} to ${targetChannel}.`);
    }

    if (sub === 'deafenall') {
      let count = 0;
      for (const member of members.values()) {
        try {
          await member.voice.setDeaf(true, `[VoiceMod] Deafenall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply(`🔇 Server deafened **${count} members** in ${voiceChannel}.`);
    }

    if (sub === 'undeafenall') {
      let count = 0;
      for (const member of members.values()) {
        try {
          await member.voice.setDeaf(false, `[VoiceMod] Undeafenall by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }
      return message.reply(`🔊 Server undeafened **${count} members** in ${voiceChannel}.`);
    }

    return message.reply(
      `Usage:\n` +
      `• \`${prefix}voicemod muteall\` — Mute everyone in current VC\n` +
      `• \`${prefix}voicemod unmuteall\` — Unmute everyone in current VC\n` +
      `• \`${prefix}voicemod deafenall\` — Deafen everyone in current VC\n` +
      `• \`${prefix}voicemod undeafenall\` — Undeafen everyone in current VC\n` +
      `• \`${prefix}voicemod moveall #target_vc\` — Move all voice members`
    );
  }
};
