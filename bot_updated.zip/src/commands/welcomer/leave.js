/**
 * Farewell & Leave Announcement Studio (Node.js)
 * Configures goodbye announcements when members depart from the server.
 * Full customization: channel, message template, card title, banner, thumbnail, and live testing.
 * Provides a live interactive studio with Discord Components V2, ChannelSelectMenu, StringSelectMenu, Modals, and ActionRows.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  EmbedBuilder,
  ModalBuilder,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb, syncServerDataToMaster, getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const { formatPlaceholders } = require('../../utils/placeholders');

function getLeaveConfig(guildId) {
  const sdb = getServerDb(guildId);
  const chRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_channel'").get();
  const statusRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_status'").get();
  const msgRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_message'").get();
  const titleRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_title'").get();
  const bannerRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_banner'").get();
  const thumbRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_thumbnail'").get();

  return {
    channel_id: chRow ? chRow.value : null,
    status: statusRow ? statusRow.value === '1' : Boolean(chRow && chRow.value),
    message: msgRow ? msgRow.value : '**{user.name}** has left **{server.name}**. We now have {memberCount} members.',
    title: titleRow ? titleRow.value : 'Goodbye • {server.name}',
    banner: bannerRow ? bannerRow.value : '',
    thumbnail: thumbRow ? thumbRow.value : 'avatar'
  };
}

function saveLeaveConfig(guildId, cfg) {
  const sdb = getServerDb(guildId);
  if (cfg.channel_id !== undefined) {
    if (cfg.channel_id) {
      sdb.prepare(`
        INSERT INTO server_settings (key, value) VALUES ('leave_channel', ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
      `).run(String(cfg.channel_id));
    } else {
      sdb.prepare("DELETE FROM server_settings WHERE key = 'leave_channel'").run();
    }
  }
  if (cfg.status !== undefined) {
    sdb.prepare(`
      INSERT INTO server_settings (key, value) VALUES ('leave_status', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(cfg.status ? '1' : '0');
  }
  if (cfg.message !== undefined) {
    sdb.prepare(`
      INSERT INTO server_settings (key, value) VALUES ('leave_message', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(cfg.message || '');
  }
  if (cfg.title !== undefined) {
    sdb.prepare(`
      INSERT INTO server_settings (key, value) VALUES ('leave_title', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(cfg.title || '');
  }
  if (cfg.banner !== undefined) {
    sdb.prepare(`
      INSERT INTO server_settings (key, value) VALUES ('leave_banner', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(cfg.banner || '');
  }
  if (cfg.thumbnail !== undefined) {
    sdb.prepare(`
      INSERT INTO server_settings (key, value) VALUES ('leave_thumbnail', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(cfg.thumbnail || 'avatar');
  }
  syncServerDataToMaster(guildId);
}

/**
 * Builds the rendered departure card for production delivery or live preview.
 */
function buildLeavePreviewCard(guild, member, cfg) {
  const accent = getGuildAccent(guild.id);
  const title = formatPlaceholders(cfg.title || 'Goodbye • {server.name}', member, guild);
  const text = formatPlaceholders(
    cfg.message || '**{user.name}** has left **{server.name}**. We now have {memberCount} members.',
    member,
    guild
  );

  const card = createV2Card({
    color: accent,
    title,
    description: text,
    footerText: `Server Population: ${guild.memberCount}`
  });

  const thumb = cfg.thumbnail || 'avatar';
  if (thumb === 'server' && guild.iconURL) {
    card.setThumbnail(guild.iconURL());
  } else if (typeof thumb === 'string' && thumb.startsWith('http')) {
    card.setThumbnail(thumb);
  } else if (thumb !== 'none' && member?.user?.displayAvatarURL) {
    card.setThumbnail(member.user.displayAvatarURL());
  } else if (thumb !== 'none' && member?.displayAvatarURL) {
    card.setThumbnail(member.displayAvatarURL());
  }

  if (cfg.banner && typeof cfg.banner === 'string' && cfg.banner.startsWith('http')) {
    card.setImage(cfg.banner);
  }

  return card;
}

/**
 * Builds the interactive Leave Studio payload.
 */
function buildLeaveStudioPayload(guild, cfg, prefix = '!', username = '') {
  const channelObj = cfg.channel_id ? guild.channels.cache.get(String(cfg.channel_id)) : null;
  const isEnabled = Boolean(cfg.status && channelObj);
  const statusBadge = isEnabled
    ? '<a:tungsten_ui_toggle_on:1569329685110849576> `Active & Enabled`'
    : '<a:tungsten_ui_toggle_off:1569329677187678368> `Disabled`';
  const channelText = channelObj ? `${channelObj} (\`${channelObj.name}\`)` : '`Not Configured`';
  const accent = getGuildAccent(guild.id);

  const card = createV2Card({
    color: accent,
    title: `<a:tungsten_sweep:1567242656281657414>  Farewell & Leave Studio • ${guild.name}`,
    description:
      `> Automatically announces member departures and updates server roster tracking.\n\n` +
      `• **Farewell Status:** ${statusBadge}\n` +
      `• **Announcement Channel:** ${channelText}\n` +
      `• **Card Title:** \`${cfg.title || 'Goodbye • {server.name}'}\`\n` +
      `• **Message Template:** \`${cfg.message}\`\n` +
      `• **Thumbnail Mode:** \`${cfg.thumbnail || 'avatar'}\`\n` +
      `• **Banner / Image URL:** \`${cfg.banner ? (cfg.banner.length > 45 ? cfg.banner.slice(0, 42) + '...' : cfg.banner) : 'None'}\`\n\n` +
      `### <a:tungsten_terminal:1567242755040878664> Customization Commands:\n` +
      `• \`${prefix}leave channel <#ch>\` — Set farewell announcement channel\n` +
      `• \`${prefix}leave title <text>\` — Customize card title\n` +
      `• \`${prefix}leave message <text>\` — Customize departure message\n` +
      `• \`${prefix}leave banner <url|none>\` — Set card banner / image URL\n` +
      `• \`${prefix}leave thumbnail <mode|url>\` — Set avatar, server, none, or URL\n` +
      `• \`${prefix}leave preview\` / \`${prefix}leave test\` — Live preview & test dispatch\n\n` +
      `### <a:tungsten_shield:1567242104923627574> Available Placeholders:\n` +
      `\`{user}\` \`{user.name}\` \`{user.tag}\` \`{user.id}\` \`{server.name}\` \`{memberCount}\``,
    footerText: username ? `Configured by ${username}` : `Tungsten Farewell Engine • ${guild.name}`
  });

  if (cfg.banner && typeof cfg.banner === 'string' && cfg.banner.startsWith('http')) {
    card.setImage(cfg.banner);
  }

  // Row 0: Channel Selector
  const chanSelect = new ChannelSelectMenuBuilder()
    .setCustomId('leave:select_channel')
    .setPlaceholder('Select Goodbye Announcement Channel...')
    .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]);
  const row0 = new ActionRowBuilder().addComponents(chanSelect);

  // Row 1: Thumbnail Mode Dropdown
  const currentThumb = cfg.thumbnail || 'avatar';
  const thumbSelect = new StringSelectMenuBuilder()
    .setCustomId('leave:select_thumbnail')
    .setPlaceholder('Configure Thumbnail Mode...')
    .addOptions([
      {
        label: 'Member Avatar',
        value: 'avatar',
        description: "Display departing member's avatar",
        emoji: '<a:tungsten_user:1567246556778995802>',
        default: currentThumb === 'avatar'
      },
      {
        label: 'Server Icon',
        value: 'server',
        description: "Display this server's icon",
        emoji: '<a:tungsten_castle:1567233687332982844>',
        default: currentThumb === 'server'
      },
      {
        label: 'No Thumbnail',
        value: 'none',
        description: 'Disable thumbnail on farewell card',
        emoji: '<a:tungsten_close:1567234632905138206>',
        default: currentThumb === 'none'
      },
      {
        label: 'Custom Image URL...',
        value: 'custom',
        description: 'Input a bespoke image URL via modal',
        emoji: '<a:tungsten_link:1567241025813086210>',
        default: currentThumb.startsWith('http')
      }
    ]);
  const row1 = new ActionRowBuilder().addComponents(thumbSelect);

  // Row 2: Customization Modals & Live Preview Buttons
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('leave:edit_content')
      .setLabel('Edit Content')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_memo:1567241226577780957>'),
    new ButtonBuilder()
      .setCustomId('leave:edit_media')
      .setLabel('Edit Media')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sparkle:1567242264311369839>'),
    new ButtonBuilder()
      .setCustomId('leave:preview')
      .setLabel('Live Preview')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_eye:1567238862042833088>'),
    new ButtonBuilder()
      .setCustomId('leave:test')
      .setLabel('Test Channel')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_bolt:1567233430570405968>')
  );

  // Row 3: Control Buttons (Active = Green/Success, Inactive = Black/Secondary)
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('leave:toggle_status')
      .setLabel(isEnabled ? 'Status: Active' : 'Status: Off')
      .setStyle(isEnabled ? ButtonStyle.Success : ButtonStyle.Secondary)
      .setEmoji(isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>'),
    new ButtonBuilder()
      .setCustomId('leave:reset')
      .setLabel('Reset')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sweep:1567242656281657414>'),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Dismiss')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_close:1567234632905138206>')
  );

  return { embeds: [card], components: [row0, row1, row2, row3] };
}

module.exports = {
  name: 'leave',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  aliases: ['farewell', 'goodbye', 'leavepanel', 'leavesetup', 'leavestudio'],
  category: 'welcome',
  description: 'Configure goodbye announcements when members leave the server with full customization.',
  usage: '[channel <#ch> | title <text> | message <text> | banner <url> | thumbnail <mode> | preview | test | reset]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: You need the **Manage Server** permission to configure leave announcements.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'leave').toLowerCase();
    const sub = args[0]?.toLowerCase() || (invoked.includes('panel') || invoked.includes('setup') ? 'panel' : 'status');
    const currentCfg = getLeaveConfig(message.guild.id);

    // 1. Panel / Status / Studio Overview
    if (!sub || ['config', 'status', 'panel', 'setup', 'studio'].includes(sub)) {
      const payload = buildLeaveStudioPayload(message.guild, currentCfg, prefix, message.author.username);
      return message.reply(payload);
    }

    // 2. Set Channel
    if (sub === 'channel' || sub === 'setchannel') {
      const channel = message.mentions?.channels?.first() || (args[1] ? message.guild.channels.cache.get(args[1]) : null);
      if (!channel) return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}leave channel #general\``);

      currentCfg.channel_id = channel.id;
      currentCfg.status = true;
      saveLeaveConfig(message.guild.id, currentCfg);

      return message.reply(`<a:tungsten_success:1567242523468890274> Leave announcements will be sent to ${channel}. Status: **Enabled**.`);
    }

    // 3. Customize Card Title
    if (sub === 'title' || sub === 'settitle') {
      const titleText = args.slice(1).join(' ').trim();
      if (!titleText) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}leave title <text>\``);
      }

      currentCfg.title = titleText;
      saveLeaveConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Leave card title updated to: **${titleText}**`);
    }

    // 4. Customize Message Template
    if (sub === 'message' || sub === 'desc' || sub === 'description' || sub === 'setmessage') {
      const text = args.slice(1).join(' ').trim();
      if (!text) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}leave message <text>\`\n\nPlaceholders: \`{user}\`, \`{user.name}\`, \`{user.tag}\`, \`{server.name}\`, \`{memberCount}\``);
      }

      currentCfg.message = text;
      saveLeaveConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Leave message template updated successfully:\n>>> ${text}`);
    }

    // 5. Banner Image / Image URL
    if (sub === 'banner' || sub === 'image' || sub === 'img' || sub === 'setbanner' || sub === 'setimage') {
      const bannerUrl = args[1]?.toLowerCase() === 'none' || args[1]?.toLowerCase() === 'clear' ? '' : (args[1] || (message.attachments.first() ? message.attachments.first().url : ''));
      currentCfg.banner = bannerUrl;
      saveLeaveConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Leave banner / image ${bannerUrl ? `set to: ${bannerUrl}` : 'cleared'}.`);
    }

    // 6. Thumbnail Mode / Custom URL
    if (sub === 'thumbnail' || sub === 'thumb' || sub === 'setthumb') {
      const thumb = args[1]?.toLowerCase() || 'avatar';
      if (!['avatar', 'server', 'none'].includes(thumb) && !thumb.startsWith('http')) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}leave thumbnail <avatar | server | <url> | none>\``);
      }

      currentCfg.thumbnail = thumb;
      saveLeaveConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Leave thumbnail mode set to: \`${thumb}\`.`);
    }

    // 7. Disable / Off
    if (sub === 'off' || sub === 'disable') {
      currentCfg.status = false;
      saveLeaveConfig(message.guild.id, currentCfg);
      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Leave announcements have been **Disabled**.');
    }

    // 8. Enable / On
    if (sub === 'on' || sub === 'enable') {
      currentCfg.status = true;
      saveLeaveConfig(message.guild.id, currentCfg);
      return message.reply('<a:tungsten_ui_toggle_on:1569329685110849576> Leave announcements have been **Enabled**.');
    }

    // 9. Live Preview
    if (sub === 'preview') {
      const previewCard = buildLeavePreviewCard(message.guild, message.member, currentCfg);
      return message.reply({
        content: '<a:tungsten_sparkle:1567242264311369839> **Live Farewell Card Preview (This is how it will appear to departing members):**',
        embeds: [previewCard]
      });
    }

    // 10. Test message to Configured Channel
    if (sub === 'test') {
      const targetChannel = currentCfg.channel_id ? message.guild.channels.cache.get(String(currentCfg.channel_id)) : message.channel;
      if (!targetChannel) return message.reply('<a:tungsten_warn:1567246685082746940> No valid leave channel configured.');

      const previewCard = buildLeavePreviewCard(message.guild, message.member, currentCfg);
      await targetChannel.send({ embeds: [previewCard] });
      return message.reply(`<a:tungsten_success:1567242523468890274> Sent test departure notice to ${targetChannel}.`);
    }

    // 11. Reset
    if (sub === 'reset' || sub === 'clear') {
      currentCfg.channel_id = null;
      currentCfg.status = false;
      currentCfg.message = '**{user.name}** has left **{server.name}**. We now have {memberCount} members.';
      currentCfg.title = 'Goodbye • {server.name}';
      currentCfg.banner = '';
      currentCfg.thumbnail = 'avatar';
      saveLeaveConfig(message.guild.id, currentCfg);
      return message.reply('<a:tungsten_success:1567242523468890274> Leave configuration has been reset to defaults.');
    }

    const payload = buildLeaveStudioPayload(message.guild, currentCfg, prefix, message.author.username);
    return message.reply(payload);
  },

  buildLeaveStudioPayload,
  buildLeavePreviewCard,
  getLeaveConfig,
  saveLeaveConfig
};
