/**
 * Welcome Command & Interactive Studio (Node.js)
 * Configures per-server welcome announcements, channels, DMs, custom messages, titles, banners, and thumbnails.
 * Provides a live interactive studio with Discord Components V2, ChannelSelectMenu, StringSelectMenu, Modals, and ActionRows.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  EmbedBuilder,
  ModalBuilder,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { getServerDb, syncServerDataToMaster, getGuildAccent } = require('../../utils/serverDb');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');
const { formatPlaceholders } = require('../../utils/placeholders');

function getWelcomeConfig(guildId) {
  const sdb = getServerDb(guildId);
  const row = sdb.prepare('SELECT * FROM welcome_panel WHERE guild_id = ?').get(String(guildId));
  if (row) return row;
  return {
    guild_id: String(guildId),
    status: 0,
    channel_id: '0',
    format: 'Components V2',
    dm_enabled: 0,
    dm_message: 'Hey {user.name}, welcome to **{server.name}**! Enjoy your stay!',
    cv2_title: 'Welcome to {server.name}!',
    cv2_description: 'Hey {user.mention}, welcome to **{server.name}**! Member #{memberCount}.',
    cv2_thumbnail: 'avatar',
    cv2_banner: ''
  };
}

function saveWelcomeConfig(guildId, cfg) {
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const validCols = [
    'guild_id', 'status', 'channel_id', 'format', 'dm_enabled',
    'dm_message', 'ping_mode', 'auto_delete', 'action_buttons',
    'cv2_title', 'cv2_description', 'cv2_thumbnail', 'cv2_banner'
  ];

  const filtered = {};
  for (const c of validCols) {
    if (cfg[c] !== undefined) filtered[c] = cfg[c];
  }
  filtered.guild_id = gid;

  const cols = Object.keys(filtered);
  const placeholders = cols.map(() => '?').join(', ');
  const colsStr = cols.join(', ');
  const updates = cols.filter(c => c !== 'guild_id').map(c => `${c} = excluded.${c}`).join(', ');

  sdb.prepare(`
    INSERT INTO welcome_panel (${colsStr})
    VALUES (${placeholders})
    ON CONFLICT(guild_id) DO UPDATE SET ${updates}
  `).run(...Object.values(filtered));

  syncServerDataToMaster(gid);
}

/**
 * Builds the rendered welcome card for production delivery or live preview.
 */
function buildWelcomePreviewCard(guild, member, cfg) {
  const accent = getGuildAccent(guild.id);
  const title = formatPlaceholders(cfg.cv2_title || 'Welcome to {server.name}!', member, guild);
  const desc = formatPlaceholders(
    cfg.cv2_description || 'Hey {user.mention}, welcome to **{server.name}**! Member #{memberCount}.',
    member,
    guild
  );

  const card = createV2Card({
    color: accent,
    title,
    description: desc,
    footerText: `Server Population: ${guild.memberCount}`
  });

  const thumb = cfg.cv2_thumbnail || 'avatar';
  if (thumb === 'server' && guild.iconURL) {
    card.setThumbnail(guild.iconURL());
  } else if (typeof thumb === 'string' && thumb.startsWith('http')) {
    card.setThumbnail(thumb);
  } else if (thumb !== 'none' && member?.user?.displayAvatarURL) {
    card.setThumbnail(member.user.displayAvatarURL());
  } else if (thumb !== 'none' && member?.displayAvatarURL) {
    card.setThumbnail(member.displayAvatarURL());
  }

  if (cfg.cv2_banner && typeof cfg.cv2_banner === 'string' && cfg.cv2_banner.startsWith('http')) {
    card.setImage(cfg.cv2_banner);
  }

  return card;
}

/**
 * Builds the interactive Welcome Studio payload with live Menus and ActionRows.
 */
function buildWelcomeStudioPayload(guild, cfg, prefix = '!', username = '') {
  const channelObj = cfg.channel_id && cfg.channel_id !== '0' ? guild.channels.cache.get(String(cfg.channel_id)) : null;
  const isEnabled = cfg.status === 1;
  const statusBadge = isEnabled
    ? '<a:tungsten_ui_toggle_on:1569329685110849576> `Active & Enabled`'
    : '<a:tungsten_ui_toggle_off:1569329677187678368> `Disabled`';
  const channelText = channelObj ? `${channelObj} (\`${channelObj.name}\`)` : '`Not Configured`';
  const dmBadge = cfg.dm_enabled === 1
    ? '<a:tungsten_ui_toggle_on:1569329685110849576> `Enabled`'
    : '<a:tungsten_ui_toggle_off:1569329677187678368> `Disabled`';
  const accent = getGuildAccent(guild.id);

  const card = createV2Card({
    color: accent,
    title: `<a:tungsten_welcomescreen:1569329748486787085>  Welcome Automation Studio • ${guild.name}`,
    description:
      `> Real-time member greeting, media customization, and direct message automation.\n\n` +
      `• **Announcements Status:** ${statusBadge}\n` +
      `• **Announcement Channel:** ${channelText}\n` +
      `• **Direct Message (DM):** ${dmBadge}\n` +
      `• **Card Title:** \`${cfg.cv2_title || 'Welcome to {server.name}!'}\`\n` +
      `• **Card Message:** \`${cfg.cv2_description || 'Hey {user.mention}, welcome to {server.name}!'}\`\n` +
      `• **DM Message:** \`${cfg.dm_message || 'None'}\`\n` +
      `• **Thumbnail Mode:** \`${cfg.cv2_thumbnail || 'avatar'}\`\n` +
      `• **Banner / Image URL:** \`${cfg.cv2_banner ? (cfg.cv2_banner.length > 45 ? cfg.cv2_banner.slice(0, 42) + '...' : cfg.cv2_banner) : 'None'}\`\n\n` +
      `### <a:tungsten_terminal:1567242755040878664> Customization Commands:\n` +
      `• \`${prefix}welcome channel <#ch>\` — Set greeting channel\n` +
      `• \`${prefix}welcome title <text>\` — Customize card title\n` +
      `• \`${prefix}welcome message <text>\` — Customize card message description\n` +
      `• \`${prefix}welcome banner <url|none>\` — Set card banner / image URL\n` +
      `• \`${prefix}welcome thumbnail <mode|url>\` — Set avatar, server, none, or URL\n` +
      `• \`${prefix}welcome dm <text>\` — Set direct message greeting\n` +
      `• \`${prefix}welcome preview\` / \`${prefix}welcome test\` — Live preview & test dispatch\n\n` +
      `### <a:tungsten_shield:1567242104923627574> Available Placeholders:\n` +
      `\`{user}\` \`{user.mention}\` \`{user.name}\` \`{user.tag}\` \`{user.id}\` \`{server.name}\` \`{memberCount}\` \`{account.age}\``,
    footerText: username ? `Configured by ${username}` : `Tungsten Welcomer Engine • ${guild.name}`
  });

  if (cfg.cv2_banner && typeof cfg.cv2_banner === 'string' && cfg.cv2_banner.startsWith('http')) {
    card.setImage(cfg.cv2_banner);
  }

  // Row 0: Channel Selector
  const chanSelect = new ChannelSelectMenuBuilder()
    .setCustomId('welcome:select_channel')
    .setPlaceholder('Select Welcome Announcement Channel...')
    .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]);
  const row0 = new ActionRowBuilder().addComponents(chanSelect);

  // Row 1: Thumbnail Mode Dropdown
  const currentThumb = cfg.cv2_thumbnail || 'avatar';
  const thumbSelect = new StringSelectMenuBuilder()
    .setCustomId('welcome:select_thumbnail')
    .setPlaceholder('Configure Thumbnail Mode...')
    .addOptions([
      {
        label: 'Member Avatar',
        value: 'avatar',
        description: "Display joining member's avatar",
        emoji: '<a:tungsten_user:1567246556778995802>',
        default: currentThumb === 'avatar'
      },
      {
        label: 'Server Icon',
        value: 'server',
        description: "Display this server's icon",
        emoji: '<a:tungsten_castle:1567233687332982844>',
        default: currentThumb === 'server'
      },
      {
        label: 'No Thumbnail',
        value: 'none',
        description: 'Disable thumbnail on welcome card',
        emoji: '<a:tungsten_close:1567234632905138206>',
        default: currentThumb === 'none'
      },
      {
        label: 'Custom Image URL...',
        value: 'custom',
        description: 'Input a bespoke image URL via modal',
        emoji: '<a:tungsten_link:1567241025813086210>',
        default: currentThumb.startsWith('http')
      }
    ]);
  const row1 = new ActionRowBuilder().addComponents(thumbSelect);

  // Row 2: Customization Modals & Live Preview Buttons
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('welcome:edit_content')
      .setLabel('Edit Content')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_memo:1567241226577780957>'),
    new ButtonBuilder()
      .setCustomId('welcome:edit_media')
      .setLabel('Edit Media')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sparkle:1567242264311369839>'),
    new ButtonBuilder()
      .setCustomId('welcome:edit_dm')
      .setLabel('Edit DM')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_chat:1567234399450177665>'),
    new ButtonBuilder()
      .setCustomId('welcome:preview')
      .setLabel('Live Preview')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_eye:1567238862042833088>')
  );

  // Row 3: Control & Toggle Buttons (Active = Green/Success, Inactive = Black/Secondary)
  const isDmEnabled = cfg.dm_enabled === 1;
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('welcome:toggle_status')
      .setLabel(isEnabled ? 'Status: Active' : 'Status: Off')
      .setStyle(isEnabled ? ButtonStyle.Success : ButtonStyle.Secondary)
      .setEmoji(isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>'),
    new ButtonBuilder()
      .setCustomId('welcome:toggle_dm')
      .setLabel(isDmEnabled ? 'DM: Active' : 'DM: Off')
      .setStyle(isDmEnabled ? ButtonStyle.Success : ButtonStyle.Secondary)
      .setEmoji(isDmEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>'),
    new ButtonBuilder()
      .setCustomId('welcome:test')
      .setLabel('Test Channel')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_bolt:1567233430570405968>'),
    new ButtonBuilder()
      .setCustomId('welcome:reset')
      .setLabel('Reset')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sweep:1567242656281657414>'),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Dismiss')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_close:1567234632905138206>')
  );

  return { embeds: [card], components: [row0, row1, row2, row3] };
}

module.exports = {
  name: 'welcome',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  aliases: ['welcomer', 'greet', 'welcomepanel', 'welcomesetup', 'welcomestudio'],
  category: 'welcome',
  description: 'Manage automated server welcome announcements, custom messages, titles, banners, and DMs.',
  usage: '[channel <#ch> | title <text> | message <text> | banner <url> | thumbnail <mode> | dm <text> | preview | test | reset]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    // Permissions: ManageGuild or Bot Owner
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: You need the **Manage Server** permission to configure welcome messages.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'welcome').toLowerCase();
    const sub = args[0]?.toLowerCase() || (invoked.includes('panel') || invoked.includes('setup') ? 'panel' : 'status');
    const currentCfg = getWelcomeConfig(message.guild.id);

    // 1. Panel / Status / Studio Overview
    if (!sub || ['config', 'status', 'panel', 'setup', 'studio'].includes(sub)) {
      const payload = buildWelcomeStudioPayload(message.guild, currentCfg, prefix, message.author.username);
      return message.reply(payload);
    }

    // 2. Set Channel
    if (sub === 'channel' || sub === 'setchannel') {
      const channel = message.mentions?.channels?.first() || (args[1] ? message.guild.channels.cache.get(args[1]) : null);
      if (!channel) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}welcome channel #general\``);
      }

      currentCfg.channel_id = channel.id;
      currentCfg.status = 1;
      saveWelcomeConfig(message.guild.id, currentCfg);

      return message.reply(`<a:tungsten_success:1567242523468890274> Welcome announcement channel set to ${channel}. Welcome announcements are now **Enabled**.`);
    }

    // 3. Customize Card Title
    if (sub === 'title' || sub === 'settitle') {
      const titleText = args.slice(1).join(' ').trim();
      if (!titleText) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}welcome title <text>\``);
      }

      currentCfg.cv2_title = titleText;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Welcome card title updated to: **${titleText}**`);
    }

    // 4. Customize Description / Message
    if (sub === 'message' || sub === 'desc' || sub === 'description' || sub === 'setmessage') {
      const text = args.slice(1).join(' ').trim();
      if (!text) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}welcome message <text>\`\n\nPlaceholders: \`{user}\`, \`{user.mention}\`, \`{user.name}\`, \`{user.tag}\`, \`{server.name}\`, \`{memberCount}\``);
      }

      currentCfg.cv2_description = text;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Welcome message template updated successfully:\n>>> ${text}`);
    }

    // 5. Banner Image / Image URL
    if (sub === 'banner' || sub === 'image' || sub === 'img' || sub === 'setbanner' || sub === 'setimage') {
      const bannerUrl = args[1]?.toLowerCase() === 'none' || args[1]?.toLowerCase() === 'clear' ? '' : (args[1] || (message.attachments.first() ? message.attachments.first().url : ''));
      currentCfg.cv2_banner = bannerUrl;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Welcome banner / image ${bannerUrl ? `set to: ${bannerUrl}` : 'cleared'}.`);
    }

    // 6. Thumbnail Mode / Custom URL
    if (sub === 'thumbnail' || sub === 'thumb' || sub === 'setthumb') {
      const thumb = args[1]?.toLowerCase() || 'avatar';
      if (!['avatar', 'server', 'none'].includes(thumb) && !thumb.startsWith('http')) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}welcome thumbnail <avatar | server | <url> | none>\``);
      }

      currentCfg.cv2_thumbnail = thumb;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Welcome card thumbnail mode set to: \`${thumb}\`.`);
    }

    // 7. Customize DM Greeting
    if (sub === 'dm' || sub === 'setdm' || sub === 'dmmessage') {
      const dmText = args.slice(1).join(' ').trim();
      if (!dmText) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}welcome dm <text>\``);
      }

      currentCfg.dm_message = dmText;
      currentCfg.dm_enabled = 1;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply(`<a:tungsten_success:1567242523468890274> Welcome DM message updated and **Enabled**:\n>>> ${dmText}`);
    }

    // 8. DM Toggles
    if (sub === 'dmenable' || (sub === 'dm' && ['on', 'enable'].includes(args[1]?.toLowerCase()))) {
      currentCfg.dm_enabled = 1;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply('<a:tungsten_ui_toggle_on:1569329685110849576> Welcome direct messages (DMs) have been **Enabled**.');
    }

    if (sub === 'dmdisable' || (sub === 'dm' && ['off', 'disable'].includes(args[1]?.toLowerCase()))) {
      currentCfg.dm_enabled = 0;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Welcome direct messages (DMs) have been **Disabled**.');
    }

    // 9. Enable / Disable Status
    if (sub === 'enable' || sub === 'on') {
      currentCfg.status = 1;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply('<a:tungsten_ui_toggle_on:1569329685110849576> Welcome announcements are now **Enabled**.');
    }

    if (sub === 'disable' || sub === 'off') {
      currentCfg.status = 0;
      saveWelcomeConfig(message.guild.id, currentCfg);
      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Welcome announcements have been **Disabled**.');
    }

    // 10. Live Preview
    if (sub === 'preview') {
      const previewCard = buildWelcomePreviewCard(message.guild, message.member, currentCfg);
      return message.reply({
        content: '<a:tungsten_sparkle:1567242264311369839> **Live Welcome Card Preview (This is how it will appear to joining members):**',
        embeds: [previewCard]
      });
    }

    // 11. Test Welcome to Configured Channel
    if (sub === 'test') {
      const chanId = currentCfg.channel_id;
      const targetChannel = chanId && chanId !== '0' ? message.guild.channels.cache.get(String(chanId)) : message.channel;
      if (!targetChannel) return message.reply('<a:tungsten_warn:1567246685082746940> No valid announcement channel configured.');

      const previewCard = buildWelcomePreviewCard(message.guild, message.member, currentCfg);
      await targetChannel.send({ embeds: [previewCard] });
      return message.reply(`<a:tungsten_success:1567242523468890274> Dispatched test welcome card to ${targetChannel}.`);
    }

    // 12. Test DM
    if (sub === 'testdm') {
      const dmMsg = formatPlaceholders(currentCfg.dm_message || 'Welcome to {server.name}!', message.member, message.guild);
      try {
        await message.author.send(dmMsg);
        return message.reply('<a:tungsten_success:1567242523468890274> Sent test welcome direct message to your DMs.');
      } catch (e) {
        return message.reply('<a:tungsten_close:1567234632905138206> Unable to send DM. Your DMs may be closed.');
      }
    }

    // 13. Reset
    if (sub === 'reset' || sub === 'clear') {
      const resetCfg = {
        guild_id: String(message.guild.id),
        status: 0,
        channel_id: '0',
        format: 'Components V2',
        dm_enabled: 0,
        dm_message: 'Hey {user.name}, welcome to **{server.name}**! Enjoy your stay!',
        cv2_title: 'Welcome to {server.name}!',
        cv2_description: 'Hey {user.mention}, welcome to **{server.name}**! Member #{memberCount}.',
        cv2_thumbnail: 'avatar',
        cv2_banner: ''
      };
      saveWelcomeConfig(message.guild.id, resetCfg);
      return message.reply('<a:tungsten_success:1567242523468890274> Welcome configuration has been reset to defaults.');
    }

    // Fallback: Show studio panel
    const payload = buildWelcomeStudioPayload(message.guild, currentCfg, prefix, message.author.username);
    return message.reply(payload);
  },

  buildWelcomeStudioPayload,
  buildWelcomePreviewCard,
  getWelcomeConfig,
  saveWelcomeConfig
};
