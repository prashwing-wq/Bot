/**
 * Autoresponder Command
 * Set custom trigger words and automatic responses in server.db
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { replaceEmojis } = require('../../utils/emojis');

module.exports = {
  name: 'autoresponder',
  description: 'Manage automated chat trigger responses.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'automation',
  usage: 'autoresponder <add|remove|list> [trigger] [response]',
  aliases: ['ar', 'autoresponse'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Manage Server` permission to configure autoresponders.'
          })
        ]
      });
    }

    const sub = args[0]?.toLowerCase();
    const sdb = getServerDb(message.guild.id);

    if (sub === 'add') {
      const trigger = args[1]?.toLowerCase();
      const response = args.slice(2).join(' ');

      if (!trigger || !response) {
        return message.reply(`**Usage:** \`${prefix}autoresponder add <trigger> <response>\``);
      }

      if (trigger.length > 50) {
        return message.reply('<a:tungsten_close:1567234632905138206> Trigger word must be 50 characters or fewer.');
      }

      if (response.length > 1900) {
        return message.reply('<a:tungsten_close:1567234632905138206> Response must be 1,900 characters or fewer.');
      }

      sdb.prepare(`
        INSERT INTO autoresponders (guild_id, trigger_word, response_text, creator_id)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(guild_id, trigger_word) DO UPDATE SET response_text = excluded.response_text, creator_id = excluded.creator_id
      `).run(message.guild.id, trigger, response, message.author.id);

      const preview = replaceEmojis(message.guild, response);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🤖 Autoresponder Created',
            description: `Trigger: \`${trigger}\`\nResponse: ${preview}`
          })
        ]
      });
    }

    if (sub === 'remove' || sub === 'delete') {
      const trigger = args[1]?.toLowerCase();
      if (!trigger) return message.reply(`Usage: \`${prefix}autoresponder remove <trigger>\``);

      const res = sdb.prepare('DELETE FROM autoresponders WHERE trigger_word = ? AND guild_id = ?').run(trigger, message.guild.id);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: 'Autoresponder Deleted',
            description: res.changes > 0
              ? `Successfully removed trigger \`${trigger}\`.`
              : `Trigger \`${trigger}\` was not found.`
          })
        ]
      });
    }

    if (sub === 'list') {
      const rows = sdb.prepare('SELECT trigger_word, response_text FROM autoresponders WHERE guild_id = ?').all(message.guild.id);
      if (!rows || rows.length === 0) {
        return message.reply('No active autoresponders found for this server.');
      }

      const listStr = rows.map(r => {
        const preview = replaceEmojis(message.guild, r.response_text);
        return `• \`${r.trigger_word}\` ➔ ${preview.length > 100 ? preview.slice(0, 97) + '...' : preview}`;
      }).join('\n');

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: `🤖 Autoresponders [${rows.length}]`,
            description: listStr
          })
        ]
      });
    }

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.INFO,
          title: '🤖 Autoresponder Automation',
          description: `• \`${prefix}autoresponder add <trigger> <response>\` — Add a trigger\n` +
            `• \`${prefix}autoresponder remove <trigger>\` — Remove a trigger\n` +
            `• \`${prefix}autoresponder list\` — View server triggers`
        })
      ]
    });
  }
};
