/**
 * Anti-Ghostping Protection Command (Node.js)
 * Automatically detects and exposes users who mention members and delete their message.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'antighostping',
  aliases: ['ghostping', 'antighost'],
  category: 'automation',
  description: 'Toggle automatic ghostping detection and exposure for the server.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[on | off | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure Anti-Ghostping.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase() || 'status';

    if (sub === 'on' || sub === 'enable') {
      sdb.prepare(`
        INSERT INTO server_settings (key, value)
        VALUES ('antighostping_status', '1')
        ON CONFLICT(key) DO UPDATE SET value = '1'
      `).run();

      const embed = createEmbed({
        color: 0x00FF88,
        title: '<a:tungsten_cmd_antighostping:1567234715549835435> Anti-Ghostping Protection Active',
        description:
          `> Ghostping detection has been **ENABLED** for **${message.guild.name}**.\n\n` +
          `• When someone pings a user or role and deletes the message within 15 seconds, Tungsten will expose the ghostping in real-time.\n` +
          `• Protects staff and members against harassment and stealth pings.`
      });

      return message.reply({ embeds: [embed] });
    }

    if (sub === 'off' || sub === 'disable') {
      sdb.prepare(`
        INSERT INTO server_settings (key, value)
        VALUES ('antighostping_status', '0')
        ON CONFLICT(key) DO UPDATE SET value = '0'
      `).run();

      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Anti-Ghostping protection has been **DISABLED**.');
    }

    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antighostping_status'").get();
    const isArmed = row ? row.value === '1' : false;

    const embed = createEmbed({
      title: '<a:tungsten_cmd_antighostping:1567234715549835435> Anti-Ghostping Sentinel Status',
      description:
        `> Stealth ping detection & exposure engine.\n\n` +
        `• **Status:** ${isArmed ? '<a:tungsten_ui_toggle_on:1569329685110849576> `ACTIVE & MONITORING`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `DISABLED`'}\n\n` +
        `**Commands:**\n` +
        `• \`${prefix}antighostping on\` — Enable ghostping detection\n` +
        `• \`${prefix}antighostping off\` — Disable ghostping detection`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
