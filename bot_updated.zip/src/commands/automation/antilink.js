const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getAutomodRule, setAutomodRule } = require('../../utils/automodEngine');

module.exports = {
  name: 'antilink',
  aliases: ['anti-link', 'linkfilter', 'blocklinks'],
  category: 'automation',
  description: 'Toggle or view Anti-Link unauthorized URL protection',
  usage: '[enable | disable | status]',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: ['ManageMessages'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need **Manage Server** permission to configure Anti-Link.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'status').toLowerCase();

    if (sub === 'enable' || sub === 'on' || sub === '1') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_anti_link', '1', strftime('%s', 'now'))").run();
      setAutomodRule(message.guild.id, { filter_type: 'anti_link', enabled: true });
      const embed = createEmbed({
        title: '<a:tungsten_shield:1567242104923627574> Anti-Link Enabled',
        description: 'Unauthorized HTTP/HTTPS links will now be automatically deleted unless domain is whitelisted.',
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'disable' || sub === 'off' || sub === '0') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_anti_link', '0', strftime('%s', 'now'))").run();
      setAutomodRule(message.guild.id, { filter_type: 'anti_link', enabled: false });
      const embed = createEmbed({
        title: '<a:tungsten_warn:1567246685082746940> Anti-Link Disabled',
        description: 'Anti-Link protection has been deactivated for this server.',
        color: 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }

    const rule = getAutomodRule(message.guild.id, 'anti_link');
    const isEnabled = Boolean(rule?.enabled);

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574> Anti-Link Status',
      description: `Current Status: **${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}**\n\n` +
        `• **Enable:** \`${prefix}antilink enable\`\n` +
        `• **Disable:** \`${prefix}antilink disable\`\n` +
        `• **Automod Studio:** \`${prefix}automod\``,
      color: isEnabled ? 0x57F287 : 0xED4245
    });
    return message.reply({ embeds: [embed] });
  }
};
