const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { addBannedWord, removeBannedWord, getBannedWords, getAutomodRule, setAutomodRule } = require('../../utils/automodEngine');

module.exports = {
  name: 'antibadwords',
  aliases: ['badwordsfilter', 'bannedwords', 'badwords', 'filterwords'],
  category: 'automation',
  description: 'Manage or toggle custom server banned words filter',
  usage: '[enable | disable | add <word> | remove <word> | list]',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: ['ManageMessages'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need **Manage Server** permission to configure Banned Words.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'list').toLowerCase();

    if (sub === 'enable' || sub === 'on' || sub === '1') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_banned_words_enabled', '1', strftime('%s', 'now'))").run();
      setAutomodRule(message.guild.id, { filter_type: 'banned_words', enabled: true });
      const embed = createEmbed({
        title: '<a:tungsten_shield:1567242104923627574> Bad Words Filter Enabled',
        description: 'Server banned words list is now active and filtering chat.',
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'disable' || sub === 'off' || sub === '0') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_banned_words_enabled', '0', strftime('%s', 'now'))").run();
      setAutomodRule(message.guild.id, { filter_type: 'banned_words', enabled: false });
      const embed = createEmbed({
        title: '<a:tungsten_warn:1567246685082746940> Bad Words Filter Disabled',
        description: 'Server banned words filter is now deactivated.',
        color: 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'add') {
      const word = args.slice(1).join(' ').trim().toLowerCase();
      if (!word) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Provide a word or phrase to blacklist. Example: \`${prefix}antibadwords add badphrase\``);
      }
      addBannedWord(message.guild.id, word, message.author.id, 1);
      const embed = createEmbed({
        title: '<a:tungsten_success:1567242523468890274> Banned Word Added',
        description: `Successfully added \`${word}\` to the server blacklist.`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'remove' || sub === 'del') {
      const word = args.slice(1).join(' ').trim().toLowerCase();
      if (!word) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Provide a word to remove from the blacklist. Example: \`${prefix}antibadwords remove badphrase\``);
      }
      removeBannedWord(message.guild.id, word);
      const embed = createEmbed({
        title: '<a:tungsten_trash:1567242891276062872> Banned Word Removed',
        description: `Successfully removed \`${word}\` from the server blacklist.`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    const words = getBannedWords(message.guild.id);
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_banned_words_enabled'").get();
    const isEnabled = row ? row.value === '1' : true;

    const listText = words.length > 0
      ? words.slice(0, 30).map(w => `• \`${w.word}\``).join('\n') + (words.length > 30 ? `\n*...and ${words.length - 30} more*` : '')
      : '*No custom banned words configured yet.*';

    const embed = createEmbed({
      title: '<a:tungsten_policy:1569329528851927131> Server Blacklisted Words',
      description: `Status: **${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}** (${words.length} words)\n\n${listText}\n\n` +
        `• **Add:** \`${prefix}antibadwords add <word>\`\n` +
        `• **Remove:** \`${prefix}antibadwords remove <word>\`\n` +
        `• **Toggle:** \`${prefix}antibadwords <enable|disable>\``,
      color: 0x5865F2
    });
    return message.reply({ embeds: [embed] });
  }
};
