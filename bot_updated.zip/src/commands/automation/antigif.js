const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'antigif',
  aliases: ['anti-gif', 'nogif', 'blockgif'],
  category: 'automation',
  description: 'Toggle or view Anti-GIF Tenor and Giphy attachment filter',
  usage: '[enable | disable | status]',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: ['ManageMessages'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need **Manage Server** permission to configure Anti-GIF.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'status').toLowerCase();

    if (sub === 'enable' || sub === 'on' || sub === '1') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_anti_gif', '1', strftime('%s', 'now'))").run();
      const embed = createEmbed({
        title: '<a:tungsten_shield:1567242104923627574> Anti-GIF Enabled',
        description: 'Tenor, Giphy, and .gif embeds will now be automatically filtered in chat.',
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'disable' || sub === 'off' || sub === '0') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_anti_gif', '0', strftime('%s', 'now'))").run();
      const embed = createEmbed({
        title: '<a:tungsten_warn:1567246685082746940> Anti-GIF Disabled',
        description: 'Anti-GIF filtering has been deactivated for this server.',
        color: 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }

    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_anti_gif'").get();
    const isEnabled = row ? row.value === '1' : false;

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574> Anti-GIF Status',
      description: `Current Status: **${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}**\n\n` +
        `• **Enable:** \`${prefix}antigif enable\`\n` +
        `• **Disable:** \`${prefix}antigif disable\`\n` +
        `• **Automod Studio:** \`${prefix}automod\``,
      color: isEnabled ? 0x57F287 : 0xED4245
    });
    return message.reply({ embeds: [embed] });
  }
};
