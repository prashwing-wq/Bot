/**
 * Tungsten Automoderation Suite & Interactive Studio (Node.js)
 * Master chat filtering engine:
 * Anti-Invite, Anti-Link, Anti-Spam, Anti-Caps, Anti-Mention, Anti-Emoji,
 * Anti-Zalgo, Anti-Newlines, Anti-Spoiler, Anti-Token, Anti-Scam/Phishing, Anti-NSFW, and Banned Words.
 * Features native Components V2 layout, live toggle buttons, word blacklisting, domain whitelisting,
 * ignore/bypass management, and dedicated incident dispatch logging.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const { createV2Card, createButtonRow } = require('../../utils/componentsV2');
const { getServerDb } = require('../../utils/serverDb');
const { isOwner, hasPerm, createEmbed } = require('../../utils/tools');
const {
  addBannedWord,
  removeBannedWord,
  getBannedWords,
  clearBannedWords,
  addAllowedDomain,
  removeAllowedDomain,
  getAllowedDomains,
  setAutomodBypass,
  removeAutomodBypass,
  getAutomodBypasses,
  getAutomodRule,
  setAutomodRule
} = require('../../utils/automodEngine');
const { panel, section, header, toggleRow, confirm, notice, facts } = require('../../ui/kit');
const { getStateAccent, COLORS } = require('../../ui/tokens');

const FILTER_KEYS = {
  anti_invite: { key: 'automod_anti_invite', label: 'Anti-invite', desc: 'Discord invites and shortlinks' },
  anti_link: { key: 'automod_anti_link', label: 'Anti-link', desc: 'Unauthorized HTTP and HTTPS links' },
  anti_spam: { key: 'automod_anti_spam', label: 'Anti-spam', desc: 'Rapid message flooding and duplicates' },
  anti_caps: { key: 'automod_anti_caps', label: 'Anti-caps', desc: 'Excessive uppercase / caps lock' },
  anti_mention: { key: 'automod_anti_mention', label: 'Anti-mention', desc: 'Mass ping and mention limits' },
  anti_emoji: { key: 'automod_anti_emoji', label: 'Anti-emoji', desc: 'Mass emoji spam (>6 emojis)' },
  anti_zalgo: { key: 'automod_anti_zalgo', label: 'Anti-zalgo', desc: 'Glitch text and combining diacritics' },
  anti_newlines: { key: 'automod_anti_newlines', label: 'Anti-newlines', desc: 'Stacked blank lines and chat hides' },
  anti_spoiler: { key: 'automod_anti_spoiler', label: 'Anti-spoiler', desc: 'Excessive spoiler tag flood' },
  anti_token: { key: 'automod_anti_token', label: 'Anti-token', desc: 'Leaked Discord bot API keys' },
  anti_scam: { key: 'automod_anti_scam', label: 'Anti-scam', desc: 'Nitro and Steam gift phishing links' },
  anti_nsfw: { key: 'automod_anti_nsfw', label: 'Anti-nsfw', desc: 'Explicit keywords in normal channels' },
  banned_words: { key: 'automod_banned_words_enabled', label: 'Banned words', desc: 'Custom server word blacklist' },
  anti_selfbot: { key: 'automod_selfbot', label: 'Anti-selfbot', desc: 'Automated user account activity' }
};

function getFilterStatuses(sdb, guildId = null) {
  const statuses = {};
  for (const [name, cfg] of Object.entries(FILTER_KEYS)) {
    if (guildId) {
      const rule = getAutomodRule(guildId, name);
      statuses[name] = Boolean(rule?.enabled);
    } else {
      try {
        const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(cfg.key);
        // Default anti_token, anti_scam and banned_words to enabled
        if (['anti_token', 'anti_scam', 'banned_words'].includes(name) && !row) {
          statuses[name] = true;
        } else {
          statuses[name] = row ? (row.value === '1' || row.value === 'true' || row.value === 1) : false;
        }
      } catch (e) {
        statuses[name] = false;
      }
    }
  }
  return statuses;
}

function setFilterStatus(sdb, filterName, enabled, guildId = null) {
  const cfg = FILTER_KEYS[filterName];
  if (!cfg) return false;
  sdb.prepare(`
    INSERT INTO server_settings (key, value)
    VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(cfg.key, enabled ? '1' : '0');

  if (guildId) {
    setAutomodRule(guildId, { filter_type: filterName, enabled: Boolean(enabled) });
  }
  return true;
}

function buildAutomodPanel(guild, statuses = null, prefix = '!') {
  const guildId = typeof guild === 'string' ? guild : (guild?.id || String(guild));
  const sdb = getServerDb(guildId);
  const activeStatuses = (statuses && typeof statuses === 'object') ? statuses : getFilterStatuses(sdb);
  const totalActive = Object.values(activeStatuses).filter(Boolean).length;
  const totalFilters = Object.keys(FILTER_KEYS).length;
  const bannedWordsCount = getBannedWords(guild.id).length;
  const allowedDomainsCount = getAllowedDomains(guild.id).length;
  const bypasses = getAutomodBypasses(guild.id);

  const logRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_log_channel'").get();
  const logChannelStr = logRow?.value ? `<#${logRow.value}>` : 'None (disabled)';

  const hpRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_channel'").get();
  const hpActRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_action'").get();
  const hpChannelStr = hpRow?.value ? `<#${hpRow.value}> (${(hpActRow?.value || 'timeout_1h').toUpperCase()})` : 'None (disabled)';

  const actRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_action'").get();
  const actPolicyStr = (actRow?.value || 'escalation').toUpperCase();

  const statusText = `Active · ${totalActive} of ${totalFilters} protections on`;

  const chatKeys = ['anti_spam', 'anti_caps', 'anti_mention', 'anti_emoji', 'anti_newlines'];
  const linkKeys = ['anti_invite', 'anti_link', 'anti_scam', 'anti_token', 'anti_selfbot'];
  const contentKeys = ['anti_nsfw', 'anti_zalgo', 'anti_spoiler', 'banned_words'];

  const activeChat = chatKeys.filter(k => statuses[k]).length;
  const activeLinks = linkKeys.filter(k => statuses[k]).length;
  const activeContent = contentKeys.filter(k => statuses[k]).length;

  const sections = [
    section({
      title: 'Chat Flooding & Spam Defense',
      hint: `${activeChat}/${chatKeys.length} active · Spam, caps, mentions, emojis, newlines`,
      accessory: new ButtonBuilder()
        .setCustomId('am:grp:chat')
        .setLabel(activeChat === chatKeys.length ? 'Disable Group' : 'Enable Group')
        .setStyle(activeChat === chatKeys.length ? ButtonStyle.Danger : ButtonStyle.Secondary)
    }),
    section({
      title: 'Links, Invites & Token Protection',
      hint: `${activeLinks}/${linkKeys.length} active · Invites, HTTP links, token leaks, scams`,
      accessory: new ButtonBuilder()
        .setCustomId('am:grp:links')
        .setLabel(activeLinks === linkKeys.length ? 'Disable Group' : 'Enable Group')
        .setStyle(activeLinks === linkKeys.length ? ButtonStyle.Danger : ButtonStyle.Secondary)
    }),
    section({
      title: 'Content & Prohibited Words Guard',
      hint: `${activeContent}/${contentKeys.length} active · NSFW keywords, zalgo, spoilers, word blacklist`,
      accessory: new ButtonBuilder()
        .setCustomId('am:grp:content')
        .setLabel(activeContent === contentKeys.length ? 'Disable Group' : 'Enable Group')
        .setStyle(activeContent === contentKeys.length ? ButtonStyle.Danger : ButtonStyle.Secondary)
    }),
    section({
      title: 'Database Rules & Sentinel Configuration',
      hint: `${bannedWordsCount} banned words · ${allowedDomainsCount} allowed domains · ${bypasses.length} exemptions\n-# Action policy: ${actPolicyStr} · Log channel: ${logChannelStr}`,
      accessory: new ButtonBuilder()
        .setCustomId('am:panel:refresh')
        .setLabel('Refresh')
        .setStyle(ButtonStyle.Secondary)
    })
  ];

  // Individual Filter Toggle Select Menu
  const filterOptions = Object.entries(FILTER_KEYS).map(([k, cfg]) => {
    const isOn = Boolean(statuses[k]);
    return {
      label: `${cfg.label} (${isOn ? 'ON' : 'OFF'})`.slice(0, 100),
      value: k,
      description: cfg.desc.slice(0, 100)
    };
  });

  const filterSelectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('am:select_filter')
      .setPlaceholder('Click to toggle individual filters on/off...')
      .addOptions(filterOptions)
  );

  const actSelectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('am:select_action')
      .setPlaceholder(`Action policy: ${actPolicyStr} (Click to change)...`)
      .addOptions([
        { label: 'Escalation ladder', value: 'escalation', description: 'Progressive: Notice -> Warn -> 10m Timeout -> 1h Timeout -> Kick -> Ban' },
        { label: 'Immediate 10m timeout', value: 'timeout_10m', description: 'Quarantine member for 10 minutes on every trigger' },
        { label: 'Immediate 1h timeout', value: 'timeout_1h', description: 'Quarantine member for 1 hour on every trigger' },
        { label: 'Immediate 24h timeout', value: 'timeout_24h', description: 'Quarantine member for 24 hours on every trigger' },
        { label: 'Immediate kick', value: 'kick', description: 'Kick member from server on every trigger' },
        { label: 'Permanent ban', value: 'ban', description: 'Ban member from server on every trigger' },
        { label: 'Formal warn only', value: 'warn', description: 'Record infraction warning without timeouts or kicks' }
      ])
  );

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('am:all:enable')
      .setLabel('Enable all')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('am:all:disable')
      .setLabel('Disable all')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('am:page:ignores')
      .setLabel('Exemptions')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('am:confirm_clear_words')
      .setLabel('Clear words')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );

  return panel({
    title: 'Automod Studio',
    status: statusText,
    description: `Deep real-time packet inspection & automatic chat defense for ${guild.name}.`,
    color: getStateAccent(totalActive > 0 ? 'armed' : 'disarmed'),
    sections,
    rows: [filterSelectRow, actSelectRow, navRow]
  });
}

function buildRuleDetailCard(guild, filterType) {
  const rule = getAutomodRule(guild.id, filterType);
  if (!rule) return null;

  const cfg = FILTER_KEYS[filterType] || { label: filterType, desc: 'Automod protection filter' };
  const isEnabled = Boolean(rule.enabled);
  const statusStr = isEnabled ? 'Enabled' : 'Disabled';

  const sections = [
    section({
      title: `Rule Configuration: ${cfg.label}`,
      hint: `${statusStr} · Action: ${String(rule.action).toUpperCase()} · Strike weight: ${rule.strike_weight}`,
      accessory: new ButtonBuilder()
        .setCustomId(`am:toggle:${filterType}`)
        .setLabel(isEnabled ? 'Disable' : 'Enable')
        .setStyle(isEnabled ? ButtonStyle.Danger : ButtonStyle.Success)
    }),
    section({
      title: 'Rate Limits & Thresholds',
      hint: rule.limit_count > 0 ? `Limit: ${rule.limit_count} incidents in ${rule.time_window}s` : 'Real-time packet inspection',
      accessory: new ButtonBuilder()
        .setCustomId(`am:limits:${filterType}`)
        .setLabel('Limits')
        .setStyle(ButtonStyle.Secondary)
    }),
    section({
      title: 'Active Exemptions',
      hint: `${rule.exemptions?.length || 0} channels/roles exempt from this filter`,
      accessory: new ButtonBuilder()
        .setCustomId('am:page:ignores')
        .setLabel('Exemptions')
        .setStyle(ButtonStyle.Secondary)
    })
  ];

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('am:nav:filters')
      .setLabel('Back to studio')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );

  return panel({
    title: `Automod · ${cfg.label}`,
    status: `${statusStr} · ${cfg.desc}`,
    description: `Filter details and enforcement settings for ${cfg.label}.`,
    color: getStateAccent(isEnabled ? 'armed' : 'disarmed'),
    sections,
    rows: [navRow]
  });
}

function buildConfirmClearWordsCard(guild) {
  const count = getBannedWords(guild.id).length;
  return confirm({
    title: 'Clear Banned Words',
    body: `Are you sure you want to remove all ${count} custom banned words for ${guild.name}? This action cannot be undone.`,
    confirmId: 'am:do_clear_words',
    cancelId: 'am:nav:filters',
    confirmLabel: 'Clear all words',
    cancelLabel: 'Cancel',
    danger: true
  });
}

/**
 * Dispatches an automated warning announcement in the designated Honeypot channel.
 */
async function postHoneypotAnnouncement(channel, guild, action = 'timeout') {
  if (!channel || typeof channel.send !== 'function') return null;

  const embed = createEmbed({
    color: 0xED4245,
    title: 'Restricted Automated Sentinel Channel',
    description:
      `> **Notice to all server members:**\n` +
      `> This channel is an automated security sentry channel maintained by Tungsten.\n\n` +
      `**Do not send messages, links, or attachments in this channel.**\n\n` +
      `• **Enforcement:** Any unauthorized user activity will be instantly intercepted and purged.\n` +
      `• **Disciplinary Action:** \`${action.toUpperCase()}\` immediately applied upon message transmission.\n\n` +
      `-# Server Security Sentinel • Zero Tolerance Area`,
    footer: { text: `Tungsten Defense Matrix • ${guild.name}` }
  });

  const msg = await channel.send({ embeds: [embed] }).catch(() => null);
  if (msg && typeof msg.pin === 'function') {
    await msg.pin().catch(() => null);
  }
  return msg;
}

/**
 * Builds the interactive Automod Ignores & Honeypot Studio Payload.
 */
function buildAutomodIgnoresPanel(guild, prefix = '!') {
  const sdb = getServerDb(guild.id);
  const bypasses = getAutomodBypasses(guild.id);
  const chList = bypasses.filter(b => b.target_type === 'channel').map(b => `<#${b.target_id}>`).join(', ') || 'None';
  const roleList = bypasses.filter(b => b.target_type === 'role').map(b => `<@&${b.target_id}>`).join(', ') || 'None';

  const hpRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_channel'").get();
  const hpActRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_action'").get();
  const hpStr = hpRow?.value ? `<#${hpRow.value}> (Penalty: ${(hpActRow?.value || 'timeout_1h').toUpperCase()})` : 'None (disabled)';

  const sections = [
    section({
      title: 'Honeypot Trap Channel',
      hint: hpStr,
      accessory: new ButtonBuilder()
        .setCustomId('am:honeypot:disable')
        .setLabel('Disable trap')
        .setStyle(ButtonStyle.Danger)
    }),
    section({
      title: `Ignored Roles (${bypasses.filter(b => b.target_type === 'role').length})`,
      hint: roleList,
      accessory: new ButtonBuilder()
        .setCustomId('am:clear_ignored_roles')
        .setLabel('Clear roles')
        .setStyle(ButtonStyle.Secondary)
    }),
    section({
      title: `Ignored Channels (${bypasses.filter(b => b.target_type === 'channel').length})`,
      hint: chList,
      accessory: new ButtonBuilder()
        .setCustomId('am:clear_ignored_channels')
        .setLabel('Clear channels')
        .setStyle(ButtonStyle.Secondary)
    })
  ];

  const roleSelectRow = new ActionRowBuilder().addComponents(
    new RoleSelectMenuBuilder()
      .setCustomId('am:select_ignore_roles')
      .setPlaceholder('Select roles to ignore from Automod (multi-select)...')
      .setMinValues(1)
      .setMaxValues(25)
  );

  const chanSelectRow = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId('am:select_ignore_channels')
      .setPlaceholder('Select channels to ignore from Automod (multi-select)...')
      .setMinValues(1)
      .setMaxValues(25)
  );

  const hpSelectRow = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId('am:select_honeypot')
      .setPlaceholder('Select Honeypot restricted trap channel (Single)...')
      .setChannelTypes(ChannelType.GuildText)
      .setMinValues(1)
      .setMaxValues(1)
  );

  const hpActionSelectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('am:select_hp_action')
      .setPlaceholder(`Honeypot Penalty: ${(hpActRow?.value || 'timeout_1h').toUpperCase()}...`)
      .addOptions([
        { label: 'Timeout 1 hour', value: 'timeout_1h', description: 'Quarantine for 1 hour on honeypot trigger' },
        { label: 'Timeout 24 hours', value: 'timeout_24h', description: 'Quarantine for 24 hours on honeypot trigger' },
        { label: 'Timeout 10 minutes', value: 'timeout_10m', description: 'Brief 10-minute quarantine timeout' },
        { label: 'Immediate kick', value: 'kick', description: 'Kick member from server on honeypot trigger' },
        { label: 'Permanent ban', value: 'ban', description: 'Ban member from server on honeypot trigger' },
        { label: 'Strip all roles', value: 'strip', description: 'Remove all manageable roles on honeypot trigger' }
      ])
  );

  const btnRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('am:nav:filters')
      .setLabel('Back to studio')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('am:clear_ignored_roles')
      .setLabel('Clear roles')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('am:clear_ignored_channels')
      .setLabel('Clear channels')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('am:honeypot:disable')
      .setLabel('Disable honeypot')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );

  const rows = [roleSelectRow, chanSelectRow, hpSelectRow, hpActionSelectRow, btnRow];
  const fallbackEmbed = new EmbedBuilder()
    .setTitle('Automod Exemptions & Honeypot')
    .setDescription(`Configure multi-role / multi-channel exclusions and automated Honeypot traps for ${guild.name}.`);

  return {
    embeds: [fallbackEmbed],
    components: rows
  };
}

module.exports = {
  name: 'automod',
  aliases: [
    'am',
    'filter',
    'automodpanel',
    'automod_panel',
    'automoddashboard',
    'antispam',
    'antilink',
    'antiinvite',
    'anticaps',
    'antimassmention',
    'antiemojispam',
    'antinsfw'
  ],
  category: 'automation',
  description: 'Interactive Automod Control Studio with 12 filters, word blacklist, link whitelist, and bypasses.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[panel | words | allowlink | ignore | log | strikes | enable | disable | toggle <filter>]',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const isAuthorized = hasPerm(message.member, PermissionFlagsBits.ManageGuild);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure Automod.');
    }

    const sdb = getServerDb(message.guild.id);
    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'automod').toLowerCase();
    const sub = args[0]?.toLowerCase();

    // Direct filter shortcuts: !antispam, !antilink, !antiinvite, !anticaps, !antimassmention, !antinsfw, !antiemojispam
    const directMap = {
      antispam: 'anti_spam',
      antilink: 'anti_link',
      antiinvite: 'anti_invite',
      anticaps: 'anti_caps',
      antimassmention: 'anti_mention',
      antiemojispam: 'anti_emoji',
      antinsfw: 'anti_nsfw'
    };

    if (directMap[invoked]) {
      const filterKey = directMap[invoked];
      let targetState = null;
      if (sub === 'on' || sub === 'enable' || sub === 'true' || sub === '1') targetState = true;
      if (sub === 'off' || sub === 'disable' || sub === 'false' || sub === '0') targetState = false;

      const current = getFilterStatuses(sdb)[filterKey];
      const next = targetState !== null ? targetState : !current;
      setFilterStatus(sdb, filterKey, next);

      const filterLabel = FILTER_KEYS[filterKey]?.label || filterKey;
      const card = createV2Card({
        color: next ? 0x2ECC71 : 0xED4245,
        title: `<a:tungsten_cmd_automod:1567234793022689290> Automod Sentinel • ${filterLabel}`,
        description:
          `> Real-time filter policy updated for **${message.guild.name}**.\n\n` +
          `• **Filter:** \`${filterLabel}\`\n` +
          `• **Status:** ${next ? '<a:tungsten_ui_toggle_on:1569329685110849576> **ENABLED**' : '<a:tungsten_ui_toggle_off:1569329677187678368> **DISABLED**'}\n` +
          `• **Action:** Delete offending message & apply escalation strike\n\n` +
          `-# Manage all filters with \`${prefix}automod\` or open the interactive panel.`,
        footerText: `Executed by ${message.author.username}`
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: words (Banned Words Management)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'words' || sub === 'badwords' || sub === 'blacklist') {
      const action = args[1]?.toLowerCase();
      const targetWord = args.slice(2).join(' ').trim();

      if (action === 'add' && targetWord) {
        addBannedWord(message.guild.id, targetWord, message.author.id, 1);
        return message.reply(`<a:tungsten_success:1567242523468890274> Added \`${targetWord}\` to the **Banned Words blacklist**.`);
      }

      if (action === 'remove' && targetWord) {
        const removed = removeBannedWord(message.guild.id, targetWord);
        return message.reply(removed
          ? `<a:tungsten_success:1567242523468890274> Removed \`${targetWord}\` from the **Banned Words blacklist**.`
          : `<a:tungsten_info:1567240890748248084> \`${targetWord}\` was not found in the blacklist.`);
      }

      if (action === 'clear') {
        clearBannedWords(message.guild.id);
        return message.reply('<a:tungsten_trash:1567242891276062872> Successfully cleared all custom banned words for this server.');
      }

      // Default: List words
      const wordsList = getBannedWords(message.guild.id);
      const formatted = wordsList.length > 0
        ? wordsList.map((w, idx) => `\`${idx + 1}.\` ||${w.word}||`).join(', ')
        : '*No custom banned words configured.*';

      const card = createV2Card({
        color: 0x2b2d31,
        title: `<a:tungsten_policy:1569329528851927131> Banned Words Roster • ${message.guild.name}`,
        description:
          `> Messages containing these phrases are automatically intercepted.\n\n` +
          `**Configured Keywords (${wordsList.length}):**\n${formatted}\n\n` +
          `**Management Commands:**\n` +
          `• \`${prefix}automod words add <phrase>\` — Blacklist keyword\n` +
          `• \`${prefix}automod words remove <phrase>\` — Remove keyword\n` +
          `• \`${prefix}automod words clear\` — Wipe all keywords`,
        footerText: `Requested by ${message.author.username}`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: allowlink / domain (Link Whitelist)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'allowlink' || sub === 'allowdomain' || sub === 'links') {
      const action = args[1]?.toLowerCase();
      const targetDomain = args[2]?.toLowerCase();

      if (action === 'add' && targetDomain) {
        addAllowedDomain(message.guild.id, targetDomain, message.author.id);
        return message.reply(`<a:tungsten_success:1567242523468890274> Added \`${targetDomain}\` to the **Allowed Domains whitelist** (bypasses Anti-Link).`);
      }

      if (action === 'remove' && targetDomain) {
        const removed = removeAllowedDomain(message.guild.id, targetDomain);
        return message.reply(removed
          ? `<a:tungsten_success:1567242523468890274> Removed \`${targetDomain}\` from the **Allowed Domains whitelist**.`
          : `<a:tungsten_info:1567240890748248084> \`${targetDomain}\` was not found in the allowed domains.`);
      }

      const domainsList = getAllowedDomains(message.guild.id);
      const formatted = domainsList.length > 0
        ? domainsList.map((d, idx) => `\`${idx + 1}.\` **${d.domain}**`).join('\n')
        : '*No custom allowed domains configured (Default: Discord, Tenor, Giphy).*';

      const card = createV2Card({
        color: 0x2b2d31,
        title: `<a:tungsten_link:1567241025813086210> Allowed Domains Whitelist • ${message.guild.name}`,
        description:
          `> Links from these domains are permitted even when Anti-Link is active.\n\n` +
          `**Authorized Domains (${domainsList.length}):**\n${formatted}\n\n` +
          `**Management Commands:**\n` +
          `• \`${prefix}automod allowlink add <domain>\` — Whitelist domain\n` +
          `• \`${prefix}automod allowlink remove <domain>\` — Remove domain`,
        footerText: `Requested by ${message.author.username}`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: setaction / action (Configure Automod Punishment Policy)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'setaction' || sub === 'action' || sub === 'policy') {
      const act = (args[1] || '').toLowerCase();
      const valid = ['escalation', 'warn', 'timeout', 'timeout_1m', 'timeout_5m', 'timeout_10m', 'timeout_1h', 'timeout_24h', 'kick', 'ban'];
      if (!act || !valid.includes(act)) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Invalid Automod action. Choose from: \`escalation\`, \`warn\`, \`timeout_10m\`, \`timeout_1h\`, \`timeout_24h\`, \`kick\`, \`ban\`.\nExample: \`${prefix}automod setaction timeout_10m\``);
      }
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_action', ?)").run(act);
      return message.reply(`<a:tungsten_success:1567242523468890274> Automod general punishment policy set to **${act.toUpperCase()}** *(configured separately from Honeypot)*.`);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: honeypot (Restricted Trap Channel with Automatic Warning)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'honeypot' || sub === 'trap') {
      const target = args[1]?.toLowerCase();
      if (!target) {
        const hpRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_channel'").get();
        const hpActRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_action'").get();
        return message.reply(
          hpRow?.value
            ? `<a:tungsten_shield:1567242104923627574> Honeypot is active in <#${hpRow.value}> (Penalty: \`${(hpActRow?.value || 'timeout_1h').toUpperCase()}\`).\nDisable with: \`${prefix}automod honeypot off\`\nChange penalty with: \`${prefix}automod honeypot action <timeout_10m|timeout_1h|timeout_24h|kick|ban|strip>\``
            : `No honeypot channel configured. Set one with: \`${prefix}automod honeypot <#channel> [action]\``
        );
      }

      if (target === 'action' || target === 'setaction' || target === 'penalty') {
        const chosenAct = (args[2] || '').toLowerCase();
        const valid = ['timeout', 'timeout_10m', 'timeout_1h', 'timeout_24h', 'kick', 'ban', 'strip'];
        if (!chosenAct || !valid.includes(chosenAct)) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Invalid Honeypot action. Choose from: \`timeout_10m\`, \`timeout_1h\`, \`timeout_24h\`, \`kick\`, \`ban\`, \`strip\`.\nExample: \`${prefix}automod honeypot action ban\``);
        }
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_honeypot_action', ?)").run(chosenAct);

        // Refresh honeypot channel announcement if channel is set
        const hpRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_channel'").get();
        if (hpRow?.value) {
          const chan = message.guild.channels.cache.get(hpRow.value);
          if (chan) await postHoneypotAnnouncement(chan, message.guild, chosenAct);
        }

        return message.reply(`<a:tungsten_success:1567242523468890274> Honeypot punishment action set to **${chosenAct.toUpperCase()}** *(configured separately from Automod)*.`);
      }

      if (target === 'off' || target === 'disable' || target === 'clear') {
        sdb.prepare("DELETE FROM server_settings WHERE key IN ('automod_honeypot_channel', 'automod_honeypot_action')").run();
        return message.reply('<a:tungsten_success:1567242523468890274> Automod Honeypot channel disabled.');
      }

      const chan = (typeof message.mentions.channels?.first === 'function' ? message.mentions.channels.first() : (message.mentions.channels?.values ? [...message.mentions.channels.values()][0] : null)) || message.guild.channels.cache.get(target.replace(/[<#>]/g, ''));
      if (!chan || chan.type !== ChannelType.GuildText) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please mention a valid **text channel** for the Honeypot.');
      }

      const validActions = ['timeout', 'timeout_10m', 'timeout_1h', 'timeout_24h', 'kick', 'ban', 'strip'];
      const action = validActions.includes(args[2]?.toLowerCase()) ? args[2].toLowerCase() : 'timeout_1h';
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_honeypot_channel', ?)").run(chan.id);
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_honeypot_action', ?)").run(action);

      await postHoneypotAnnouncement(chan, message.guild, action);
      return message.reply(`<a:tungsten_success:1567242523468890274> Honeypot sentry armed in <#${chan.id}> with action \`${action.toUpperCase()}\`. Automated warning announcement posted!`);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: ignorerole (Multi-Role Ignore Set)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'ignorerole' || sub === 'ignoreroles' || (sub === 'ignore' && args[1]?.toLowerCase() === 'role')) {
      const rawTokens = sub.startsWith('ignorerole') ? args.slice(1) : args.slice(2);
      const roleIds = new Set();
      if (message.mentions.roles?.size) {
        for (const r of message.mentions.roles.values()) roleIds.add(r.id);
      }
      for (const tok of rawTokens) {
        const clean = tok.replace(/[<@&>]/g, '');
        if (message.guild.roles.cache.has(clean)) roleIds.add(clean);
      }
      if (!roleIds.size) {
        return message.reply(`Usage: \`${prefix}automod ignorerole <@role1> [@role2...]\``);
      }
      for (const rid of roleIds) {
        setAutomodBypass(message.guild.id, 'role', rid, 'all', message.author.id);
      }
      const mentionsStr = [...roleIds].map(id => `<@&${id}>`).join(', ');
      return message.reply(`<a:tungsten_success:1567242523468890274> Added ${roleIds.size} role(s) to Automod ignore list: ${mentionsStr}`);
    }

    if (sub === 'unignorerole' || sub === 'unignoreroles' || (sub === 'unignore' && args[1]?.toLowerCase() === 'role')) {
      const rawTokens = sub.startsWith('unignorerole') ? args.slice(1) : args.slice(2);
      const roleIds = new Set();
      if (message.mentions.roles?.size) {
        for (const r of message.mentions.roles.values()) roleIds.add(r.id);
      }
      for (const tok of rawTokens) {
        const clean = tok.replace(/[<@&>]/g, '');
        if (clean) roleIds.add(clean);
      }
      if (!roleIds.size) return message.reply(`Usage: \`${prefix}automod unignorerole <@role1> [@role2...]\``);
      for (const rid of roleIds) {
        removeAutomodBypass(message.guild.id, 'role', rid, 'all');
      }
      return message.reply(`<a:tungsten_success:1567242523468890274> Removed ${roleIds.size} role(s) from Automod ignore list.`);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: ignorechannel (Multi-Channel Ignore Set)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'ignorechannel' || sub === 'ignorechannels' || (sub === 'ignore' && args[1]?.toLowerCase() === 'channel')) {
      const rawTokens = sub.startsWith('ignorechannel') ? args.slice(1) : args.slice(2);
      const chanIds = new Set();
      if (message.mentions.channels?.size) {
        for (const c of message.mentions.channels.values()) chanIds.add(c.id);
      }
      for (const tok of rawTokens) {
        const clean = tok.replace(/[<#>]/g, '');
        if (message.guild.channels.cache.has(clean)) chanIds.add(clean);
      }
      if (!chanIds.size) {
        return message.reply(`Usage: \`${prefix}automod ignorechannel <#chan1> [#chan2...]\``);
      }
      for (const cid of chanIds) {
        setAutomodBypass(message.guild.id, 'channel', cid, 'all', message.author.id);
      }
      const mentionsStr = [...chanIds].map(id => `<#${id}>`).join(', ');
      return message.reply(`<a:tungsten_success:1567242523468890274> Added ${chanIds.size} channel(s) to Automod ignore list: ${mentionsStr}`);
    }

    if (sub === 'unignorechannel' || sub === 'unignorechannels' || (sub === 'unignore' && args[1]?.toLowerCase() === 'channel')) {
      const rawTokens = sub.startsWith('unignorechannel') ? args.slice(1) : args.slice(2);
      const chanIds = new Set();
      if (message.mentions.channels?.size) {
        for (const c of message.mentions.channels.values()) chanIds.add(c.id);
      }
      for (const tok of rawTokens) {
        const clean = tok.replace(/[<#>]/g, '');
        if (clean) chanIds.add(clean);
      }
      if (!chanIds.size) return message.reply(`Usage: \`${prefix}automod unignorechannel <#chan1> [#chan2...]\``);
      for (const cid of chanIds) {
        removeAutomodBypass(message.guild.id, 'channel', cid, 'all');
      }
      return message.reply(`<a:tungsten_success:1567242523468890274> Removed ${chanIds.size} channel(s) from Automod ignore list.`);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: ignore / bypass (Channel & Role Bypass)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'ignore' || sub === 'bypass') {
      const type = args[1]?.toLowerCase();
      const target = args[2];
      const filterScope = args[3]?.toLowerCase() || 'all';

      if (type === 'channel' && (message.mentions.channels?.first() || target)) {
        const chan = (typeof message.mentions.channels?.first === 'function' ? message.mentions.channels.first() : (message.mentions.channels?.values ? [...message.mentions.channels.values()][0] : null)) || message.guild.channels.cache.get(target.replace(/[<#>]/g, ''));
        if (!chan) return message.reply('<a:tungsten_close:1567234632905138206> Please mention a valid channel.');
        setAutomodBypass(message.guild.id, 'channel', chan.id, filterScope, message.author.id);
        return message.reply(`<a:tungsten_success:1567242523468890274> Channel <#${chan.id}> is now exempted from Automod filter: \`${filterScope}\`.`);
      }

      if (type === 'role' && (message.mentions.roles?.first() || target)) {
        const role = message.mentions.roles?.first() || message.guild.roles.cache.get(target.replace(/[<@&>]/g, ''));
        if (!role) return message.reply('<a:tungsten_close:1567234632905138206> Please mention a valid role.');
        setAutomodBypass(message.guild.id, 'role', role.id, filterScope, message.author.id);
        return message.reply(`<a:tungsten_success:1567242523468890274> Role <@&${role.id}> is now exempted from Automod filter: \`${filterScope}\`.`);
      }

      return message.reply(`Usage: \`${prefix}automod ignore <channel|role> <#channel|@role> [filterScope]\``);
    }

    if (sub === 'unignore' || sub === 'unbypass') {
      const type = args[1]?.toLowerCase();
      const target = args[2];
      if (!type || !target) return message.reply(`Usage: \`${prefix}automod unignore <channel|role> <#channel|@role>\``);

      const cleanId = target.replace(/[<#@&>]/g, '');
      const removed = removeAutomodBypass(message.guild.id, type, cleanId, 'all');
      return message.reply(removed ? `<a:tungsten_success:1567242523468890274> Removed bypass for ${type} \`${cleanId}\`.` : `<a:tungsten_info:1567240890748248084> No active bypass found for that ${type}.`);
    }

    if (sub === 'ignored' || sub === 'bypasses' || sub === 'ignores') {
      const panel = buildAutomodIgnoresPanel(message.guild, prefix);
      return message.reply(panel);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: log (Incident Log Channel)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'log' || sub === 'logs' || sub === 'logchannel') {
      const targetChan = message.mentions.channels?.first() || (args[1] === 'off' ? 'off' : message.guild.channels.cache.get(args[1]?.replace(/[<#>]/g, '')));
      if (!targetChan) {
        const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_log_channel'").get();
        return message.reply(`Automod Incident Log Channel: ${row?.value ? `<#${row.value}>` : '*Not configured*'}.\nSet with: \`${prefix}automod log <#channel|off>\``);
      }

      if (targetChan === 'off') {
        sdb.prepare("DELETE FROM server_settings WHERE key = 'automod_log_channel'").run();
        return message.reply('<a:tungsten_success:1567242523468890274> Automod incident logging disabled.');
      }

      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_log_channel', ?)").run(targetChan.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Automod incident log channel set to <#${targetChan.id}>.`);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: strikes / clearstrikes
    // ─────────────────────────────────────────────────────────────
    if (sub === 'strikes' || sub === 'infractions') {
      const targetUser = message.mentions.users?.first() || (args[1] ? await client.users.fetch(args[1].replace(/[<@!>]/g, '')).catch(() => null) : message.author);
      if (!targetUser) return message.reply('<a:tungsten_close:1567234632905138206> User not found.');

      const strikeRow = sdb.prepare('SELECT strikes, last_strike_at FROM automod_strikes WHERE guild_id = ? AND user_id = ?').get(message.guild.id, targetUser.id);
      const strikes = strikeRow?.strikes || 0;
      const lastAt = strikeRow?.last_strike_at ? `<t:${strikeRow.last_strike_at}:R>` : 'Never';

      const recentLogs = sdb.prepare('SELECT violation, action_taken, timestamp FROM automod_logs WHERE guild_id = ? AND user_id = ? ORDER BY id DESC LIMIT 5')
        .all(message.guild.id, targetUser.id);
      const logLines = recentLogs.length > 0
        ? recentLogs.map(l => `• \`${l.violation}\` — Action: \`${l.action_taken}\` (<t:${l.timestamp}:R>)`).join('\n')
        : '*No recent violations on record.*';

      const card = createV2Card({
        color: strikes > 0 ? 0xE67E22 : 0x2ECC71,
        title: `<a:tungsten_warn:1567246685082746940>  Automod Strikes • ${targetUser.username}`,
        description:
          `• **Current Active Strikes:** \`${strikes} / 5\`\n` +
          `• **Last Infraction:** ${lastAt}\n\n` +
          `**Recent Intercepted Violations:**\n${logLines}\n\n` +
          `-# Reset strikes using \`${prefix}automod clearstrikes <@user>\``,
        footerText: `Target User ID: ${targetUser.id}`
      });
      return message.reply({ embeds: [card] });
    }

    if (sub === 'clearstrikes' || sub === 'resetstrikes' || sub === 'pardon') {
      const targetUser = message.mentions.users?.first() || (args[1] ? await client.users.fetch(args[1].replace(/[<@!>]/g, '')).catch(() => null) : null);
      if (!targetUser) return message.reply(`Usage: \`${prefix}automod clearstrikes <@user>\``);

      sdb.prepare('DELETE FROM automod_strikes WHERE guild_id = ? AND user_id = ?').run(message.guild.id, targetUser.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Successfully reset automod strikes for <@${targetUser.id}>.`);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommands: enable all / disable all
    // ─────────────────────────────────────────────────────────────
    if (sub === 'enable' || sub === 'all_on' || sub === 'start') {
      for (const k of Object.keys(FILTER_KEYS)) {
        setFilterStatus(sdb, k, true);
      }
      const statuses = getFilterStatuses(sdb);
      const panel = buildAutomodPanel(message.guild, statuses, prefix);
      return message.reply(panel);
    }

    if (sub === 'disable' || sub === 'all_off' || sub === 'stop') {
      for (const k of Object.keys(FILTER_KEYS)) {
        setFilterStatus(sdb, k, false);
      }
      const statuses = getFilterStatuses(sdb);
      const panel = buildAutomodPanel(message.guild, statuses, prefix);
      return message.reply(panel);
    }

    // ─────────────────────────────────────────────────────────────
    // Subcommand: toggle <filter>
    // ─────────────────────────────────────────────────────────────
    if (sub === 'toggle' && args[1]) {
      const target = args[1].toLowerCase().replace(/-/g, '_');
      const normalized = target.startsWith('anti_') ? target : (FILTER_KEYS[target] ? target : `anti_${target}`);
      if (!FILTER_KEYS[normalized]) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Invalid filter. Available filters: ${Object.keys(FILTER_KEYS).map(f => `\`${f}\``).join(', ')}`);
      }

      const current = getFilterStatuses(sdb)[normalized];
      const next = !current;
      setFilterStatus(sdb, normalized, next);

      const statuses = getFilterStatuses(sdb);
      const panel = buildAutomodPanel(message.guild, statuses, prefix);
      return message.reply(panel);
    }

    // Default: Open the full Interactive Automod Studio Panel
    const statuses = getFilterStatuses(sdb);
    const panel = buildAutomodPanel(message.guild, statuses, prefix);
    return message.reply(panel);
  },

  getFilterStatuses,
  setFilterStatus,
  buildAutomodPanel,
  buildRuleDetailCard,
  buildConfirmClearWordsCard,
  buildAutomodIgnoresPanel,
  postHoneypotAnnouncement,
  FILTER_KEYS
};
