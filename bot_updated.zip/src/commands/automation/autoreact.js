/**
 * Autoreact Command
 * Set custom trigger words and automatic emoji reactions in server.db
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'autoreact',
  description: 'Manage automated emoji reactions to specific words.',
  permissions: ['ManageGuild'],
  botPermissions: ['AddReactions','SendMessages','EmbedLinks'],
  category: 'automation',
  usage: 'autoreact <add|remove|list> [word] [emoji]',
  aliases: ['reactrule'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Manage Server` permission to configure auto-reactions.'
          })
        ]
      });
    }

    const sub = args[0]?.toLowerCase();
    const sdb = getServerDb(message.guild.id);

    if (sub === 'add') {
      const trigger = args[1]?.toLowerCase();
      const emoji = args[2];

      if (!trigger || !emoji) {
        return message.reply(`**Usage:** \`${prefix}autoreact add <word> <emoji>\``);
      }

      if (trigger.length > 50) {
        return message.reply('<a:tungsten_close:1567234632905138206> Trigger word must be 50 characters or fewer.');
      }

      if (emoji.length > 64) {
        return message.reply('<a:tungsten_close:1567234632905138206> Emoji must be 64 characters or fewer.');
      }

      sdb.prepare(`
        INSERT INTO autoreactions (guild_id, trigger_word, emoji)
        VALUES (?, ?, ?)
        ON CONFLICT(guild_id, trigger_word) DO UPDATE SET emoji = excluded.emoji
      `).run(message.guild.id, trigger, emoji);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🤖 Auto-Reaction Created',
            description: `Trigger word: \`${trigger}\`\nReaction: ${emoji}`
          })
        ]
      });
    }

    if (sub === 'remove') {
      const trigger = args[1]?.toLowerCase();
      if (!trigger) return message.reply(`Usage: \`${prefix}autoreact remove <word>\``);

      const res = sdb.prepare('DELETE FROM autoreactions WHERE trigger_word = ? AND guild_id = ?').run(trigger, message.guild.id);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: 'Auto-Reaction Removed',
            description: res.changes > 0
              ? `Successfully removed trigger \`${trigger}\`.`
              : `Trigger \`${trigger}\` was not found.`
          })
        ]
      });
    }

    if (sub === 'list') {
      const rows = sdb.prepare('SELECT trigger_word, emoji FROM autoreactions WHERE guild_id = ?').all(message.guild.id);
      if (!rows || rows.length === 0) {
        return message.reply('No active auto-reactions found for this server.');
      }

      const listStr = rows.map(r => `• \`${r.trigger_word}\` ➔ ${r.emoji}`).join('\n');

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: `🤖 Auto-Reactions [${rows.length}]`,
            description: listStr
          })
        ]
      });
    }

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.INFO,
          title: '🤖 Auto-Reaction Automation',
          description: `• \`${prefix}autoreact add <word> <emoji>\` — Add a reaction rule\n` +
            `• \`${prefix}autoreact remove <word>\` — Remove a reaction rule\n` +
            `• \`${prefix}autoreact list\` — View server reaction rules`
        })
      ]
    });
  }
};
