/**
 * FastRules Command (Node.js)
 * 1-click AutoMod preset deployment for rapid guild protection.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'fastrules',
  aliases: ['quickrules', 'quickautomod'],
  category: 'automation',
  description: 'Fast 1-click AutoMod rule deployment and threat filter setup.',
  permissions: ['ManageGuild'],
  botPermissions: ['ManageGuild'],
  usage: '[deploy | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const isAuthorized = hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) ||
                         message.author.id === message.guild.ownerId ||
                         client.config.OWNER_IDS.includes(message.author.id);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You require **Manage Server** permission to deploy fast AutoMod rules.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase() || 'deploy';

    if (sub === 'deploy' || sub === 'enable' || sub === 'apply') {
      const keys = [
        ['automod_anti_invite', '1'],
        ['automod_anti_link', '1'],
        ['automod_anti_spam', '1'],
        ['automod_anti_caps', '1'],
        ['automod_anti_massmention', '1'],
        ['automod_anti_emoji', '1'],
        ['automod_anti_nsfw', '1'],
        ['automod_anti_badwords', '1']
      ];

      const stmt = sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)');
      for (const [k, v] of keys) {
        stmt.run(k, v);
      }

      const card = createV2Card({
        color: 0x00FF88,
        title: '<a:tungsten_bolt:1567233430570405968> Fast AutoMod Rules Deployed',
        description:
          `> Deployed 1-Click AutoMod Rules suite to **${message.guild.name}**.\n\n` +
          `• <a:tungsten_ui_toggle_on:1569329685110849576> **Anti-Invite Filter:** \`ENABLED (Blocks unauthorized server invites)\`\n` +
          `• <a:tungsten_ui_toggle_on:1569329685110849576> **Anti-Link Filter:** \`ENABLED (Blocks scam/malicious links)\`\n` +
          `• <a:tungsten_ui_toggle_on:1569329685110849576> **Anti-Spam Filter:** \`ENABLED (5 msgs / 5s threshold)\`\n` +
          `• <a:tungsten_ui_toggle_on:1569329685110849576> **Anti-Caps Filter:** \`ENABLED (>70% uppercase threshold)\`\n` +
          `• <a:tungsten_ui_toggle_on:1569329685110849576> **Anti-Mass Mention:** \`ENABLED (Max 4 mentions/message)\`\n` +
          `• <a:tungsten_ui_toggle_on:1569329685110849576> **Anti-Emoji Flood:** \`ENABLED (Max 6 emojis/message)\`\n` +
          `• <a:tungsten_ui_toggle_on:1569329685110849576> **Bad Words Filter:** \`ENABLED\`\n\n` +
          `-# Reconfigure individual filters anytime with \`${prefix}automod\` or standalone shortcuts.`,
        footer: { text: `FastRules deployed by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // Status view
    const rows = sdb.prepare("SELECT key, value FROM server_settings WHERE key LIKE 'automod_%'").all();
    const config = Object.fromEntries(rows.map(r => [r.key, r.value === '1']));

    const card = createV2Card({
      color: 0x5865F2,
      title: `<a:tungsten_bolt:1567233430570405968> AutoMod Quick Rules Status • ${message.guild.name}`,
      description:
        `> Quick overview of active AutoMod protection rules.\n\n` +
        `• **Anti-Invite:** ${config.automod_anti_invite ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Inactive'}\n` +
        `• **Anti-Link:** ${config.automod_anti_link ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Inactive'}\n` +
        `• **Anti-Spam:** ${config.automod_anti_spam ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Inactive'}\n` +
        `• **Anti-Caps:** ${config.automod_anti_caps ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Inactive'}\n` +
        `• **Anti-Mass Mention:** ${config.automod_anti_massmention ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Inactive'}\n\n` +
        `Deploy instant defense with \`${prefix}fastrules deploy\`.`
    });

    return message.reply({ embeds: [card] });
  }
};
