/**
 * Custom Commands Engine (Node.js)
 * Allows server admins to create custom prefix commands with placeholder substitution.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'customcmd',
  aliases: ['cc', 'ccmd', 'customcommand'],
  category: 'automation',
  description: 'Create and manage custom server prefix commands.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[add <name> <response> | delete <name> | list | view <name>]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase() || 'list';

    // 1. Add Custom Command
    if (sub === 'add' || sub === 'create') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to add custom commands.');
      }

      const name = args[1]?.toLowerCase();
      const response = args.slice(2).join(' ');

      if (!name || !response) {
        return message.reply(`Usage: \`${prefix}customcmd add <name> <response text>\``);
      }

      if (name.length > 50) {
        return message.reply('<a:tungsten_close:1567234632905138206> Command name must be 50 characters or fewer.');
      }

      if (response.length > 1900) {
        return message.reply('<a:tungsten_close:1567234632905138206> Response must be 1,900 characters or fewer.');
      }

      // Check collision with built-in commands
      if (client.commands.has(name) || client.aliases.has(name)) {
        return message.reply(`<a:tungsten_close:1567234632905138206> \`${name}\` is a built-in Tungsten system command and cannot be overridden.`);
      }

      sdb.prepare(`
        INSERT INTO custom_commands (guild_id, name, content, created_by, created_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(guild_id, name) DO UPDATE SET content = excluded.content
      `).run(message.guild.id, name, response, message.author.id, Math.floor(Date.now() / 1000));

      const embed = createEmbed({
        color: 0x00FF88,
        title: '⚙️  Custom Command Created',
        description:
          `> Command **\`${prefix}${name}\`** has been successfully registered!\n\n` +
          `**Response Output:**\n${response}\n\n` +
          `• Supports placeholders: \`{user.mention}\`, \`{user.name}\`, \`{server.name}\`, \`{member.count}\``
      });

      return message.reply({ embeds: [embed] });
    }

    // 2. Delete Custom Command
    if (sub === 'delete' || sub === 'remove') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to delete custom commands.');
      }

      const name = args[1]?.toLowerCase();
      if (!name) return message.reply(`Usage: \`${prefix}customcmd delete <name>\``);

      sdb.prepare('DELETE FROM custom_commands WHERE guild_id = ? AND name = ?').run(message.guild.id, name);
      return message.reply(`<a:tungsten_success:1567242523468890274> Deleted custom command \`${prefix}${name}\`.`);
    }

    // 3. List Custom Commands
    const rows = sdb.prepare('SELECT name, created_by, created_at FROM custom_commands WHERE guild_id = ?').all(message.guild.id);

    let listText = '';
    if (rows.length === 0) {
      listText = '*No custom commands registered yet. Create one with `' + prefix + 'customcmd add <name> <response>`!*';
    } else {
      listText = rows.map((r, i) => `\`#${i + 1}\` **\`${prefix}${r.name}\`** — Created by <@${r.created_by}>`).join('\n');
    }

    const embed = createEmbed({
      title: `⚙️  Custom Server Commands • ${message.guild.name}`,
      description:
        `> User-defined dynamic prefix triggers.\n\n` +
        listText +
        `\n\n**Commands:**\n` +
        `• \`${prefix}customcmd add <name> <response>\` — Create custom command\n` +
        `• \`${prefix}customcmd delete <name>\` — Remove custom command`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
