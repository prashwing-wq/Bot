const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getAutomodRule, setAutomodRule } = require('../../utils/automodEngine');

module.exports = {
  name: 'antispam',
  aliases: ['anti-spam', 'spamfilter', 'blockspam'],
  category: 'automation',
  description: 'Toggle or view Anti-Spam rapid message rate limiting',
  usage: '[enable | disable | status]',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: ['ManageMessages'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need **Manage Server** permission to configure Anti-Spam.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'status').toLowerCase();

    if (sub === 'enable' || sub === 'on' || sub === '1') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_anti_spam', '1', strftime('%s', 'now'))").run();
      setAutomodRule(message.guild.id, { filter_type: 'anti_spam', enabled: true });
      const embed = createEmbed({
        title: '<a:tungsten_shield:1567242104923627574> Anti-Spam Enabled',
        description: 'Rapid message flooding and duplicate message spam will now be automatically intercepted.',
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'disable' || sub === 'off' || sub === '0') {
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value, updated_at) VALUES ('automod_anti_spam', '0', strftime('%s', 'now'))").run();
      setAutomodRule(message.guild.id, { filter_type: 'anti_spam', enabled: false });
      const embed = createEmbed({
        title: '<a:tungsten_warn:1567246685082746940> Anti-Spam Disabled',
        description: 'Anti-Spam rate limiting has been deactivated for this server.',
        color: 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }

    const rule = getAutomodRule(message.guild.id, 'anti_spam');
    const isEnabled = Boolean(rule?.enabled);

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574> Anti-Spam Status',
      description: `Current Status: **${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}**\n\n` +
        `• **Enable:** \`${prefix}antispam enable\`\n` +
        `• **Disable:** \`${prefix}antispam disable\`\n` +
        `• **Automod Studio:** \`${prefix}automod\``,
      color: isEnabled ? 0x57F287 : 0xED4245
    });
    return message.reply({ embeds: [embed] });
  }
};
