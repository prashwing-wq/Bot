/**
 * Sticky Message Command (Node.js)
 * Automatically keeps essential notices pinned at the bottom of the chat channel.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'stickymessage',
  aliases: ['sticky', 'stickynote'],
  category: 'automation',
  description: 'Pin an automatic sticky notice that reposts itself at the bottom of the channel.',
  permissions: ['ManageMessages'],
  botPermissions: ['ManageMessages','SendMessages','EmbedLinks'],
  usage: '[set <text> | remove | list]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageMessages)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission to configure sticky messages.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase();

    if (sub === 'set') {
      const text = args.slice(1).join(' ');
      if (!text) return message.reply(`Usage: \`${prefix}stickymessage set <your announcement or rules here>\``);

      sdb.prepare(`
        INSERT INTO sticky_messages (channel_id, guild_id, content, last_message_id)
        VALUES (?, ?, ?, NULL)
        ON CONFLICT(channel_id) DO UPDATE SET content = excluded.content
      `).run(message.channel.id, message.guild.id, text);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '📌  Sticky Notice Armed',
        description:
          `> A sticky notice has been anchored to ${message.channel}.\n\n` +
          `**Content:**\n${text}\n\n` +
          `• *Tungsten will automatically ensure this notice remains visible at the bottom of the channel.*`
      });

      return message.reply({ embeds: [embed] });
    }

    if (sub === 'remove' || sub === 'delete' || sub === 'clear') {
      sdb.prepare('DELETE FROM sticky_messages WHERE channel_id = ?').run(message.channel.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Sticky notice removed from ${message.channel}.`);
    }

    // List all sticky messages in guild
    const rows = sdb.prepare('SELECT channel_id, content FROM sticky_messages WHERE guild_id = ?').all(message.guild.id);

    let listText = '';
    if (rows.length === 0) {
      listText = '*No sticky notices currently active.*';
    } else {
      listText = rows.map((r, i) => `\`#${i + 1}\` <#${r.channel_id}> — "${r.content.length > 50 ? r.content.slice(0, 47) + '...' : r.content}"`).join('\n');
    }

    const embed = createEmbed({
      title: `📌  Active Sticky Notices • ${message.guild.name}`,
      description:
        `> Auto-reposting channel notices.\n\n` +
        listText +
        `\n\n**Commands:**\n` +
        `• \`${prefix}stickymessage set <text>\` — Anchor a notice to current channel\n` +
        `• \`${prefix}stickymessage remove\` — Remove notice from current channel`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
