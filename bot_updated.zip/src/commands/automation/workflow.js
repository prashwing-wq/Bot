/**
 * Tungsten Workflow Command (Node.js)
 * Implements Slice 3.3 Event Sequence Automation:
 * Allows server administrators to manage automated event-driven workflows.
 * Supported triggers: member_join, member_leave, member_ban, keyword
 * Supported actions: send_message, add_role, remove_role, timeout
 *
 * SAFETY INVARIANT: Workflows cannot ban, kick or grant Administrator!
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField
} = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { hasPerm } = require('../../utils/tools');
const {
  VALID_TRIGGERS,
  VALID_ACTIONS,
  normalizeTrigger,
  normalizeAction,
  getWorkflows,
  getWorkflow,
  createWorkflow,
  toggleWorkflow,
  deleteWorkflow,
  parseDuration
} = require('../../utils/workflowEngine');

/**
 * Summarizes action list for display cards.
 */
function summarizeActions(actions) {
  if (!actions || actions.length === 0) return '*(No actions)*';
  return actions.map((a, i) => {
    if (a.type === 'send_message') {
      const chText = a.channel_id ? `<#${a.channel_id}>` : '*Event Channel*';
      return `\`${i + 1}.\` <a:tungsten_chat:1567234399450177665> **Send Message** <a:tungsten_arrow_small:1567233140357988574> ${chText}`;
    }
    if (a.type === 'add_role') {
      return `\`${i + 1}.\` <a:tungsten_ui_role_add:1567245019587411968> **Add Role** <a:tungsten_arrow_small:1567233140357988574> <@&${a.role_id}>`;
    }
    if (a.type === 'remove_role') {
      return `\`${i + 1}.\` <a:tungsten_ui_role_remove:1567245052009255103> **Remove Role** <a:tungsten_arrow_small:1567233140357988574> <@&${a.role_id}>`;
    }
    if (a.type === 'timeout') {
      return `\`${i + 1}.\` 🕒 **Timeout** → \`${a.duration_raw || Math.round(a.duration_ms / 1000) + 's'}\``;
    }
    return `\`${i + 1}.\` <a:tungsten_gear:1567239932970406012> **${a.type}**`;
  }).join('\n');
}

/**
 * Builds the V2 card and buttons for workflow list.
 */
function buildWorkflowListPanel(guild, workflows, prefix) {
  let listText = '';
  if (workflows.length === 0) {
    listText =
      `*No workflows currently configured in **${guild.name}**.*\n\n` +
      `**Quick Start Examples:**\n` +
      `• Welcome Message:\n  \`${prefix}workflow create WelcomeMsg join message #general Welcome {user.mention}!\`\n` +
      `• Autorole on Join:\n  \`${prefix}workflow create AutoRole join addrole @Member\`\n` +
      `• Keyword Timeout:\n  \`${prefix}workflow create FilterBad keyword scam timeout 60s Prohibited keyword\`\n` +
      `• Farewell Notice:\n  \`${prefix}workflow create ByeMsg leave message #general Goodbye {user.name}!\``;
  } else {
    listText = workflows.map((wf) => {
      const statusIcon = wf.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>';
      const triggerIcon = wf.trigger_type === 'keyword' ? '<a:tungsten_search:1567242081167216771>' : (wf.trigger_type === 'member_join' ? '<a:tungsten_ui_user_add:1567246155706929205>' : (wf.trigger_type === 'member_leave' ? '<a:tungsten_cmd_leave:1567235657783447573>' : '<a:tungsten_cmd_ban:1567234887503585321>'));
      const triggerDetails = wf.trigger_type === 'keyword' ? `(keyword: \`${wf.trigger_config?.keyword || 'none'}\`)` : '';
      return (
        `**#${wf.id}** • ${statusIcon} **${wf.name}**\n` +
        `> ${triggerIcon} Trigger: \`${wf.trigger_type}\` ${triggerDetails}\n` +
        `> <a:tungsten_bolt:1567233430570405968> Actions: \`${wf.actions.length}\` | Executions: \`${wf.run_count || 0}\`\n` +
        `> <a:tungsten_info:1567240890748248084> Status: ${wf.enabled ? '`Active`' : '`Paused`'}`
      );
    }).join('\n\n');
  }

  const card = createV2Card({
    color: 0x5865F2,
    title: `<a:tungsten_workflow:1569329772520018061> Event Sequence Workflows • ${guild.name}`,
    description:
      `> Automated event-driven triggers and action sequences.\n\n` +
      listText +
      `\n\n**Management Commands:**\n` +
      `• \`${prefix}workflow create <name> <trigger> <action> [args...]\`\n` +
      `• \`${prefix}workflow toggle <id>\` — Pause / Resume workflow\n` +
      `• \`${prefix}workflow delete <id>\` — Delete workflow\n` +
      `• \`${prefix}workflow info <id>\` — View detailed action steps`,
    footerText: `Total Workflows: ${workflows.length} • Tungsten Automation`
  });

  const rows = [];
  const topRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('wf:refresh')
      .setLabel('Refresh')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Close')
      .setEmoji('<a:tungsten_sweep:1567242656281657414>')
      .setStyle(ButtonStyle.Secondary)
  );
  rows.push(topRow);

  // If there are workflows (up to 4), add quick toggle buttons
  if (workflows.length > 0 && workflows.length <= 4) {
    const toggleRow = new ActionRowBuilder();
    for (const wf of workflows) {
      toggleRow.addComponents(
        new ButtonBuilder()
          .setCustomId(`wf:toggle:${wf.id}`)
          .setLabel(`#${wf.id} ${wf.enabled ? 'Pause' : 'Resume'}`)
          .setStyle(wf.enabled ? ButtonStyle.Primary : ButtonStyle.Secondary)
      );
    }
    rows.push(toggleRow);
  }

  return { embeds: [card], components: rows };
}

module.exports = {
  name: 'workflow',
  aliases: ['workflows', 'wf'],
  category: 'automation',
  description: 'Create and manage automated server event workflows.',
  usage: '[list | create <args...> | toggle <id> | delete <id> | info <id>]',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: ['ManageRoles', 'ModerateMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure workflows.');
    }

    const sub = args[0]?.toLowerCase() || 'list';

    // ─────────────────────────────────────────────────────────────
    // 1. List Workflows
    // ─────────────────────────────────────────────────────────────
    if (sub === 'list') {
      const workflows = getWorkflows(message.guild.id);
      const panel = buildWorkflowListPanel(message.guild, workflows, prefix);
      return message.reply(panel);
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Toggle Workflow (Pause / Resume)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'toggle') {
      const id = parseInt(args[1], 10);
      if (isNaN(id) || id <= 0) {
        return message.reply(`Usage: \`${prefix}workflow toggle <id>\` (Run \`${prefix}workflow list\` to find IDs)`);
      }

      const updated = toggleWorkflow(message.guild.id, id);
      if (!updated) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Workflow with ID \`#${id}\` was not found in this server.`);
      }

      const card = createV2Card({
        color: updated.enabled ? 0x00FF88 : 0xFF3B30,
        title: `<a:tungsten_workflow:1569329772520018061> Workflow ${updated.enabled ? 'Resumed' : 'Paused'} • #${updated.id}`,
        description:
          `> Workflow **\`${updated.name}\`** has been **${updated.enabled ? 'ENABLED' : 'PAUSED'}**.\n\n` +
          `• **Trigger:** \`${updated.trigger_type}\`\n` +
          `• **Actions:** \`${updated.actions.length}\` configured step(s)\n` +
          `• **Status:** ${updated.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active (listening for events)' : '<a:tungsten_ui_toggle_off:1569329677187678368> Paused (inactive)'}\n` +
          `• **Total Runs:** \`${updated.run_count}\``,
        footerText: `Executed by ${message.author.username}`
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Delete Workflow
    // ─────────────────────────────────────────────────────────────
    if (sub === 'delete' || sub === 'remove' || sub === 'del') {
      const id = parseInt(args[1], 10);
      if (isNaN(id) || id <= 0) {
        return message.reply(`Usage: \`${prefix}workflow delete <id>\``);
      }

      const deleted = deleteWorkflow(message.guild.id, id);
      if (!deleted) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Workflow with ID \`#${id}\` was not found in this server.`);
      }

      const card = createV2Card({
        color: 0x00FF88,
        title: `<a:tungsten_workflow:1569329772520018061> Workflow Deleted • #${id}`,
        description: `> Workflow \`#${id}\` has been permanently removed from server automation rules.`,
        footerText: `Executed by ${message.author.username}`
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. View Workflow Details
    // ─────────────────────────────────────────────────────────────
    if (sub === 'info' || sub === 'view') {
      const id = parseInt(args[1], 10);
      if (isNaN(id) || id <= 0) {
        return message.reply(`Usage: \`${prefix}workflow info <id>\``);
      }

      const wf = getWorkflow(message.guild.id, id);
      if (!wf) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Workflow with ID \`#${id}\` was not found in this server.`);
      }

      const actionsSummary = summarizeActions(wf.actions);
      const card = createV2Card({
        color: 0x5865F2,
        title: `<a:tungsten_workflow:1569329772520018061> Workflow Details • #${wf.id} ${wf.name}`,
        description:
          `• **Name:** \`${wf.name}\`\n` +
          `• **Status:** ${wf.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Paused'}\n` +
          `• **Trigger Type:** \`${wf.trigger_type}\`\n` +
          `• **Trigger Config:** \`${JSON.stringify(wf.trigger_config)}\`\n` +
          `• **Run Count:** \`${wf.run_count}\` execution(s)\n\n` +
          `**Configured Actions Sequence:**\n${actionsSummary}\n\n` +
          `-# Manage with \`${prefix}workflow toggle ${wf.id}\` or \`${prefix}workflow delete ${wf.id}\``,
        footerText: `Tungsten Workflow Engine • Guild ${message.guild.name}`
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. Create Workflow
    // ─────────────────────────────────────────────────────────────
    if (sub === 'create' || sub === 'add') {
      const name = args[1];
      if (!name) {
        const helpCard = createV2Card({
          color: 0x5865F2,
          title: '<a:tungsten_workflow:1569329772520018061> Workflow Creator Guide',
          description:
            `> Define automated sequences reacting to server events.\n\n` +
            `**Syntax:**\n` +
            `\`${prefix}workflow create <name> <trigger> <action> [options...]\`\n\n` +
            `**Triggers:**\n` +
            `• \`join\` / \`member_join\` — When a user joins\n` +
            `• \`leave\` / \`member_leave\` — When a user leaves\n` +
            `• \`ban\` / \`member_ban\` — When a user is banned\n` +
            `• \`keyword <word>\` — When a chat message contains keyword\n\n` +
            `**Actions:**\n` +
            `• \`message <#channel> <text>\` — Send notification message\n` +
            `• \`addrole <@role|roleId>\` — Grant role to member\n` +
            `• \`removerole <@role|roleId>\` — Remove role from member\n` +
            `• \`timeout <duration> [reason]\` — Timeout member\n\n` +
            `**Examples:**\n` +
            `• \`${prefix}workflow create Welcome join message #general Welcome {user.mention}!\`\n` +
            `• \`${prefix}workflow create Autorole join addrole @Member\`\n` +
            `• \`${prefix}workflow create SpamWatch keyword nitro timeout 10m Nitro link scam\`\n\n` +
            `*<a:tungsten_shield:1567242104923627574> Hard Safety Invariant: Workflows cannot ban, kick or grant Administrator permission.*`
        });
        return message.reply({ embeds: [helpCard] });
      }

      // Check if user provided advanced JSON payload
      const remainingText = args.slice(2).join(' ').trim();
      let newWf = null;

      if (remainingText.startsWith('{') && remainingText.endsWith('}')) {
        try {
          const payload = JSON.parse(remainingText);
          newWf = createWorkflow(message.guild.id, {
            name,
            trigger_type: payload.trigger || payload.trigger_type,
            trigger_config: payload.trigger_config || {},
            actions: payload.actions || []
          }, message.guild);
        } catch (e) {
          return message.reply(`<a:tungsten_close:1567234632905138206> JSON creation error: ${e.message}`);
        }
      } else {
        // Natural CLI argument parsing
        const rawTrigger = args[2]?.toLowerCase();
        if (!rawTrigger) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a trigger. Supported triggers: \`${VALID_TRIGGERS.join(', ')}\``);
        }

        const normTrigger = normalizeTrigger(rawTrigger);
        if (!normTrigger) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Invalid trigger \`${rawTrigger}\`. Supported: \`${VALID_TRIGGERS.join(', ')}\``);
        }

        let triggerConfig = {};
        let actionStartIndex = 3;

        if (normTrigger === 'keyword') {
          const kw = args[3];
          if (!kw) {
            return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a keyword to match: \`${prefix}workflow create ${name} keyword <word> <action> ...\``);
          }
          triggerConfig = { keyword: kw, match_type: 'contains' };
          actionStartIndex = 4;
        }

        const rawAction = args[actionStartIndex]?.toLowerCase();
        if (!rawAction) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Please specify an action. Supported actions: \`${VALID_ACTIONS.join(', ')}\``);
        }

        const normAction = normalizeAction(rawAction);
        if (!normAction) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Invalid action \`${rawAction}\`. Supported actions: \`${VALID_ACTIONS.join(', ')}\``);
        }

        const actionArgs = args.slice(actionStartIndex + 1);
        let actionObj = null;

        if (normAction === 'send_message') {
          let channelId = null;
          let text = '';
          const firstArg = actionArgs[0];
          if (firstArg && (firstArg.startsWith('<#') || /^\d{17,20}$/.test(firstArg))) {
            channelId = firstArg.replace(/[<#>]/g, '');
            text = actionArgs.slice(1).join(' ');
          } else {
            text = actionArgs.join(' ');
          }

          if (!text) {
            return message.reply(`<a:tungsten_close:1567234632905138206> Please specify the message text: \`${prefix}workflow create ${name} ${rawTrigger} message [#channel] <text>\``);
          }

          actionObj = { type: 'send_message', channel_id: channelId, message: text };
        } else if (normAction === 'add_role') {
          const roleArg = actionArgs[0];
          const roleId = roleArg ? roleArg.replace(/[<@&>]/g, '') : null;
          if (!roleId || !/^\d{17,20}$/.test(roleId)) {
            return message.reply(`<a:tungsten_close:1567234632905138206> Please mention or provide the Role ID: \`${prefix}workflow create ${name} ${rawTrigger} addrole <@role>\``);
          }
          actionObj = { type: 'add_role', role_id: roleId };
        } else if (normAction === 'remove_role') {
          const roleArg = actionArgs[0];
          const roleId = roleArg ? roleArg.replace(/[<@&>]/g, '') : null;
          if (!roleId || !/^\d{17,20}$/.test(roleId)) {
            return message.reply(`<a:tungsten_close:1567234632905138206> Please mention or provide the Role ID: \`${prefix}workflow create ${name} ${rawTrigger} removerole <@role>\``);
          }
          actionObj = { type: 'remove_role', role_id: roleId };
        } else if (normAction === 'timeout') {
          const durArg = actionArgs[0];
          if (!durArg) {
            return message.reply(`<a:tungsten_close:1567234632905138206> Please specify duration (e.g. 60s, 5m, 1h): \`${prefix}workflow create ${name} ${rawTrigger} timeout <duration> [reason]\``);
          }
          const reason = actionArgs.slice(1).join(' ') || 'Tungsten Automated Workflow';
          actionObj = { type: 'timeout', duration: durArg, reason };
        }

        try {
          newWf = createWorkflow(message.guild.id, {
            name,
            trigger_type: normTrigger,
            trigger_config: triggerConfig,
            actions: [actionObj]
          }, message.guild);
        } catch (err) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Workflow creation rejected: ${err.message}`);
        }
      }

      const actionsSummary = summarizeActions(newWf.actions);
      const card = createV2Card({
        color: 0x00FF88,
        title: `<a:tungsten_workflow:1569329772520018061> Workflow Created • #${newWf.id} ${newWf.name}`,
        description:
          `> Event-triggered sequence successfully registered!\n\n` +
          `• **ID:** \`#${newWf.id}\`\n` +
          `• **Name:** \`${newWf.name}\`\n` +
          `• **Trigger:** \`${newWf.trigger_type}\` ${newWf.trigger_config?.keyword ? `(keyword: \`${newWf.trigger_config.keyword}\`)` : ''}\n` +
          `• **Status:** <a:tungsten_ui_toggle_on:1569329685110849576> Enabled\n\n` +
          `**Action Steps:**\n${actionsSummary}\n\n` +
          `-# Test by triggering the event or run \`${prefix}workflow list\` to manage.`,
        footerText: `Configured by ${message.author.username}`
      });

      return message.reply({ embeds: [card] });
    }

    return message.reply(`Usage: \`${prefix}workflow [list | create | toggle <id> | delete <id> | info <id>]\``);
  },

  buildWorkflowListPanel,
  summarizeActions
};
