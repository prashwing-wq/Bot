/**
 * Tungsten Server Tags System (Node.js)
 * High-performance tag engine supporting embed syntax and dynamic variable substitution.
 *
 * Variables supported:
 * {user}        - Mention the invoking user (<@id>)
 * {user.name}   - Username of invoking user
 * {channel}     - Mention the channel (<#id>)
 * {server}      - Server name
 * {count}       - Total guild member count
 * {args}        - Additional arguments supplied when invoking the tag
 */
const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

const RESERVED_SUBCOMMANDS = [
  'add', 'create',
  'edit', 'update',
  'delete', 'del', 'remove',
  'list', 'all',
  'raw', 'view', 'source',
  'alias',
  'help'
];

/**
 * Escapes mass mentions and role pings to prevent injection attacks.
 */
function sanitizeVar(val) {
  if (typeof val !== 'string') return String(val ?? '');
  return val
    .replace(/@everyone/g, '@\u200beveryone')
    .replace(/@here/g, '@\u200bhere')
    .replace(/<@&/g, '<@&\u200b');
}

/**
 * Single-pass variable replacer. Immune to recursive template injection.
 */
function applyVariables(text, vars) {
  if (!text || typeof text !== 'string') return '';
  return text.replace(/\{(user(?:\.name|\.mention)?|channel(?:\.name)?|server(?:\.name)?|count|member\.count|membercount|args)\}/gi, (match, token) => {
    const k = token.toLowerCase();
    if (k === 'user' || k === 'user.mention') return vars.user;
    if (k === 'user.name') return vars['user.name'];
    if (k === 'channel' || k === 'channel.name') return vars.channel;
    if (k === 'server' || k === 'server.name') return vars.server;
    if (k === 'count' || k === 'member.count' || k === 'membercount') return vars.count;
    if (k === 'args') return vars.args;
    return match;
  });
}

/**
 * Extracts balanced {embed ...} block from template string respecting quotes.
 */
function findEmbedBlock(str) {
  if (!str) return null;
  const match = str.match(/\{embed\b/i);
  if (!match) return null;

  const startIndex = match.index;
  let inDouble = false;
  let inSingle = false;
  let escaped = false;
  let braceDepth = 1;
  let endIndex = -1;

  for (let i = startIndex + match[0].length; i < str.length; i++) {
    const ch = str[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      escaped = true;
      continue;
    }
    if (ch === '"' && !inSingle) {
      inDouble = !inDouble;
      continue;
    }
    if (ch === "'" && !inDouble) {
      inSingle = !inSingle;
      continue;
    }
    if (!inDouble && !inSingle) {
      if (ch === '{') {
        braceDepth++;
      } else if (ch === '}') {
        braceDepth--;
        if (braceDepth === 0) {
          endIndex = i;
          break;
        }
      }
    }
  }

  if (endIndex === -1) return null;

  return {
    raw: str.slice(startIndex, endIndex + 1),
    content: str.slice(startIndex + match[0].length, endIndex).trim(),
    startIndex,
    endIndex: endIndex + 1
  };
}

/**
 * Parses key="value" or JSON embed syntax.
 */
function parseEmbedProps(raw) {
  if (!raw) return {};
  raw = raw.trim();

  // Support direct JSON embed definition
  if (raw.startsWith('{') && raw.endsWith('}')) {
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    } catch (_) {}
  }

  const props = {};
  const attrRegex = /([a-zA-Z_.-]+)\s*=\s*(?:"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|([^\s>]+))/g;
  let m;
  while ((m = attrRegex.exec(raw)) !== null) {
    const key = m[1].toLowerCase();
    let val = m[2] !== undefined ? m[2] : (m[3] !== undefined ? m[3] : m[4]);
    val = val.replace(/\\"/g, '"').replace(/\\'/g, "'").replace(/\\n/g, '\n');
    props[key] = val;
  }

  if (Object.keys(props).length === 0 && raw.length > 0) {
    props.description = raw;
  }

  return props;
}

/**
 * Safely parses color strings (hex, int, etc.).
 */
function parseColor(col) {
  if (!col) return 0x5865F2;
  if (typeof col === 'number') return col;
  const s = String(col).trim().replace(/^#/, '');
  const parsed = parseInt(s, 16);
  return isNaN(parsed) ? 0x5865F2 : parsed;
}

/**
 * Renders a tag template given execution context.
 */
function renderTag(template, context) {
  const vars = {
    user: `<@${context.authorId}>`,
    'user.name': sanitizeVar(context.authorUsername),
    channel: `<#${context.channelId}>`,
    server: sanitizeVar(context.guildName),
    count: String(context.memberCount || 0),
    args: sanitizeVar(context.extraArgs || '')
  };

  const block = findEmbedBlock(template);
  if (!block) {
    const rendered = applyVariables(template, vars);
    return { content: rendered, embed: null };
  }

  // Separate outside text and embed content
  const outsideRaw = (template.slice(0, block.startIndex) + ' ' + template.slice(block.endIndex)).trim();
  const outsideText = applyVariables(outsideRaw, vars);

  const embedProps = parseEmbedProps(block.content);

  // Apply variables to all embed text fields
  for (const k of Object.keys(embedProps)) {
    if (typeof embedProps[k] === 'string') {
      embedProps[k] = applyVariables(embedProps[k], vars);
    }
  }

  const embed = new EmbedBuilder();
  embed.setColor(parseColor(embedProps.color));

  if (embedProps.title) {
    embed.setTitle(String(embedProps.title).slice(0, 256));
  }

  const desc = embedProps.description || embedProps.desc;
  if (desc) {
    embed.setDescription(String(desc).slice(0, 4096));
  }

  if (embedProps.footer || embedProps['footer.text']) {
    const fText = String(embedProps.footer || embedProps['footer.text']).slice(0, 2048);
    const fIcon = embedProps.footer_icon || embedProps['footer.icon_url'];
    embed.setFooter({
      text: fText,
      iconURL: typeof fIcon === 'string' && fIcon.startsWith('http') ? fIcon : undefined
    });
  }

  if (typeof embedProps.thumbnail === 'string' && embedProps.thumbnail.startsWith('http')) {
    embed.setThumbnail(embedProps.thumbnail);
  }

  if (typeof embedProps.image === 'string' && embedProps.image.startsWith('http')) {
    embed.setImage(embedProps.image);
  }

  if (typeof embedProps.url === 'string' && embedProps.url.startsWith('http')) {
    embed.setURL(embedProps.url);
  }

  if (embedProps.author || embedProps['author.name']) {
    const aName = String(embedProps.author || embedProps['author.name']).slice(0, 256);
    const aIcon = embedProps.author_icon || embedProps['author.icon_url'];
    embed.setAuthor({
      name: aName,
      iconURL: typeof aIcon === 'string' && aIcon.startsWith('http') ? aIcon : undefined
    });
  }

  return { content: outsideText, embed };
}

/**
 * Finds tag by name or alias in guild DB.
 */
function findTag(sdb, guildId, targetName) {
  if (!targetName) return null;
  const lower = targetName.toLowerCase();

  // Try direct primary name match
  let row = sdb.prepare('SELECT * FROM guild_tags WHERE guild_id = ? AND LOWER(name) = ?').get(guildId, lower);
  if (row) return row;

  // Search aliases
  const allTags = sdb.prepare('SELECT * FROM guild_tags WHERE guild_id = ?').all(guildId);
  return allTags.find(t => {
    try {
      const aliases = JSON.parse(t.aliases_json || '[]');
      return Array.isArray(aliases) && aliases.some(a => String(a).toLowerCase() === lower);
    } catch (_) {
      return false;
    }
  }) || null;
}

module.exports = {
  name: 'tag',
  aliases: ['tags', 't'],
  category: 'automation',
  description: 'Create, display, and manage server tags with variables and embed syntax.',
  permissions: [], // Public command for regular members; staff subcommands check inside
  botPermissions: ['SendMessages', 'EmbedLinks'],
  usage: '<name> [args] | add <name> <content> | edit <name> <content> | delete <name> | list | raw <name> | alias <name> <alias>',
  cooldown: 2,

  // Export helpers for testing & external reuse
  renderTag,
  applyVariables,
  sanitizeVar,
  findEmbedBlock,
  parseEmbedProps,
  findTag,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || '').toLowerCase();

    // ─────────────────────────────────────────────────────────────
    // 1. Tag List (default when no args, or !tag list)
    // ─────────────────────────────────────────────────────────────
    if (!sub || sub === 'list' || sub === 'all') {
      const rows = sdb.prepare('SELECT name, aliases_json, uses, author_id FROM guild_tags WHERE guild_id = ? ORDER BY name ASC').all(message.guild.id);

      if (rows.length === 0) {
        const embed = createEmbed({
          color: 0x5865F2,
          title: `🏷️ Tags • ${message.guild.name}`,
          description:
            `*No tags registered in this server yet.*\n\n` +
            `**Create your first tag:**\n` +
            `• \`${prefix}tag add <name> <content>\` — Create a tag\n` +
            `• \`${prefix}tag <name>\` — Display a tag\n\n` +
            `**Variables:** \`{user}\`, \`{user.name}\`, \`{channel}\`, \`{server}\`, \`{count}\`, \`{args}\`\n` +
            `**Embeds:** \`{embed title="..." description="..." color="#5865F2"}\``
        });
        return message.reply({ embeds: [embed] });
      }

      const lines = rows.map((t, idx) => {
        let aliasesStr = '';
        try {
          const arr = JSON.parse(t.aliases_json || '[]');
          if (Array.isArray(arr) && arr.length > 0) {
            aliasesStr = ` *(aliases: ${arr.map(a => `\`${a}\``).join(', ')})*`;
          }
        } catch (_) {}
        return `\`#${idx + 1}\` **\`${t.name}\`**${aliasesStr} — \`${t.uses}\` uses`;
      });

      let listText = lines.join('\n');
      if (listText.length > 3800) {
        listText = listText.slice(0, 3800) + '\n...and more';
      }

      const embed = createEmbed({
        color: 0x5865F2,
        title: `🏷️ Server Tags • ${message.guild.name} (${rows.length}/100)`,
        description:
          `> Quick-response automated snippets and templates.\n\n` +
          listText +
          `\n\n**Commands:**\n` +
          `• \`${prefix}tag <name> [args]\` — Run tag\n` +
          `• \`${prefix}tag raw <name>\` — View source\n` +
          `• \`${prefix}tag add <name> <content>\` — Create tag *(staff)*\n` +
          `• \`${prefix}tag edit <name> <content>\` — Edit tag *(staff)*\n` +
          `• \`${prefix}tag delete <name>\` — Delete tag *(staff)*\n` +
          `• \`${prefix}tag alias <name> <alias>\` — Add alias *(staff)*`,
        footer: { text: `Requested by ${message.author.username}` }
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Help
    // ─────────────────────────────────────────────────────────────
    if (sub === 'help') {
      const embed = createEmbed({
        color: 0x5865F2,
        title: '🏷️ Tungsten Tags Documentation',
        description:
          `**Tag Subcommands:**\n` +
          `• \`${prefix}tag <name> [args]\` — Post a tag in the channel\n` +
          `• \`${prefix}tag list\` — View all server tags\n` +
          `• \`${prefix}tag raw <name>\` — View unrendered source code\n` +
          `• \`${prefix}tag add <name> <content>\` — Create a new tag\n` +
          `• \`${prefix}tag edit <name> <content>\` — Edit an existing tag\n` +
          `• \`${prefix}tag delete <name>\` — Delete a tag\n` +
          `• \`${prefix}tag alias <name> <alias>\` — Create an alternate alias\n\n` +
          `**Supported Variables:**\n` +
          `• \`{user}\` — Mention invoking user\n` +
          `• \`{user.name}\` — Username\n` +
          `• \`{channel}\` — Current channel mention\n` +
          `• \`{server}\` — Server name\n` +
          `• \`{count}\` — Member count\n` +
          `• \`{args}\` — User arguments passed after tag name\n\n` +
          `**Embed Syntax:**\n` +
          `\`{embed title="..." description="..." color="#HEX" footer="..." image="..." thumbnail="..."}\``
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Add Tag (ManageMessages)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'add' || sub === 'create') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageMessages)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission to create tags.');
      }

      const tagName = args[1]?.toLowerCase();
      const content = args.slice(2).join(' ');

      if (!tagName || !content) {
        return message.reply(`Usage: \`${prefix}tag add <name> <content>\``);
      }

      if (!/^[a-zA-Z0-9-]{2,32}$/.test(tagName)) {
        return message.reply('<a:tungsten_close:1567234632905138206> Tag names must be 2-32 characters long and contain only alphanumeric characters and hyphens.');
      }

      if (RESERVED_SUBCOMMANDS.includes(tagName)) {
        return message.reply(`<a:tungsten_close:1567234632905138206> \`${tagName}\` is a reserved subcommand keyword and cannot be used as a tag name.`);
      }

      const countRow = sdb.prepare('SELECT COUNT(*) AS count FROM guild_tags WHERE guild_id = ?').get(message.guild.id);
      if ((countRow?.count || 0) >= 100) {
        return message.reply('<a:tungsten_close:1567234632905138206> Tag limit reached (maximum 100 tags per server). Please delete unused tags first.');
      }

      const existing = findTag(sdb, message.guild.id, tagName);
      if (existing) {
        return message.reply(`<a:tungsten_close:1567234632905138206> A tag or alias named \`${tagName}\` already exists.`);
      }

      if (content.length > 2000) {
        return message.reply('<a:tungsten_close:1567234632905138206> Tag content must be 2,000 characters or fewer.');
      }

      sdb.prepare(`
        INSERT INTO guild_tags (guild_id, name, aliases_json, content, author_id, uses, created_at)
        VALUES (?, ?, '[]', ?, ?, 0, ?)
      `).run(message.guild.id, tagName, content, message.author.id, Math.floor(Date.now() / 1000));

      const embed = createEmbed({
        color: 0x00FF88,
        title: '🏷️ Tag Created',
        description:
          `Tag **\`${tagName}\`** has been successfully registered!\n\n` +
          `• Run tag: \`${prefix}tag ${tagName}\`\n` +
          `• View source: \`${prefix}tag raw ${tagName}\`\n` +
          `• Add alias: \`${prefix}tag alias ${tagName} <alias>\``
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Edit Tag (ManageMessages)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'edit' || sub === 'update') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageMessages)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission to edit tags.');
      }

      const tagName = args[1]?.toLowerCase();
      const newContent = args.slice(2).join(' ');

      if (!tagName || !newContent) {
        return message.reply(`Usage: \`${prefix}tag edit <name> <new content>\``);
      }

      const tag = findTag(sdb, message.guild.id, tagName);
      if (!tag) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Tag \`${tagName}\` not found.`);
      }

      if (newContent.length > 2000) {
        return message.reply('<a:tungsten_close:1567234632905138206> Tag content must be 2,000 characters or fewer.');
      }

      sdb.prepare('UPDATE guild_tags SET content = ? WHERE guild_id = ? AND name = ?')
        .run(newContent, message.guild.id, tag.name);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '🏷️ Tag Updated',
        description: `Tag **\`${tag.name}\`** has been updated successfully.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. Delete Tag (ManageMessages)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'delete' || sub === 'del' || sub === 'remove') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageMessages)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission to delete tags.');
      }

      const tagName = args[1]?.toLowerCase();
      if (!tagName) {
        return message.reply(`Usage: \`${prefix}tag delete <name>\``);
      }

      const tag = findTag(sdb, message.guild.id, tagName);
      if (!tag) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Tag \`${tagName}\` not found.`);
      }

      sdb.prepare('DELETE FROM guild_tags WHERE guild_id = ? AND name = ?')
        .run(message.guild.id, tag.name);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '<a:tungsten_trash:1567242891276062872> Tag Deleted',
        description: `Tag **\`${tag.name}\`** has been permanently deleted.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Add Tag Alias (ManageMessages)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'alias') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageMessages)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission to create tag aliases.');
      }

      const tagName = args[1]?.toLowerCase();
      const aliasName = args[2]?.toLowerCase();

      if (!tagName || !aliasName) {
        return message.reply(`Usage: \`${prefix}tag alias <name> <alias>\``);
      }

      if (!/^[a-zA-Z0-9-]{2,32}$/.test(aliasName)) {
        return message.reply('<a:tungsten_close:1567234632905138206> Alias must be 2-32 characters long and contain only alphanumeric characters and hyphens.');
      }

      if (RESERVED_SUBCOMMANDS.includes(aliasName)) {
        return message.reply(`<a:tungsten_close:1567234632905138206> \`${aliasName}\` is a reserved subcommand keyword and cannot be used as an alias.`);
      }

      const tag = findTag(sdb, message.guild.id, tagName);
      if (!tag) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Tag \`${tagName}\` not found.`);
      }

      const existingConflict = findTag(sdb, message.guild.id, aliasName);
      if (existingConflict) {
        return message.reply(`<a:tungsten_close:1567234632905138206> The name or alias \`${aliasName}\` is already taken.`);
      }

      let aliases = [];
      try {
        aliases = JSON.parse(tag.aliases_json || '[]');
        if (!Array.isArray(aliases)) aliases = [];
      } catch (_) {
        aliases = [];
      }

      if (!aliases.includes(aliasName)) {
        aliases.push(aliasName);
      }

      sdb.prepare('UPDATE guild_tags SET aliases_json = ? WHERE guild_id = ? AND name = ?')
        .run(JSON.stringify(aliases), message.guild.id, tag.name);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '🏷️ Tag Alias Added',
        description: `Successfully assigned alias **\`${aliasName}\`** to tag **\`${tag.name}\`**.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 7. Raw Source View (Public)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'raw' || sub === 'view' || sub === 'source') {
      const tagName = args[1]?.toLowerCase();
      if (!tagName) {
        return message.reply(`Usage: \`${prefix}tag raw <name>\``);
      }

      const tag = findTag(sdb, message.guild.id, tagName);
      if (!tag) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Tag \`${tagName}\` not found.`);
      }

      const escapedContent = tag.content.replace(/```/g, '`\u200b`\u200b`');
      return message.reply({
        content: `📄 **Raw source for \`${tag.name}\`:**\n\`\`\`text\n${escapedContent}\n\`\`\``,
        allowedMentions: { parse: [] }
      });
    }

    // ─────────────────────────────────────────────────────────────
    // 8. Tag Execution (!tag <name> [args])
    // ─────────────────────────────────────────────────────────────
    const tag = findTag(sdb, message.guild.id, sub);
    if (!tag) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Tag \`${args[0]}\` not found. Use \`${prefix}tag list\` to view available tags.`);
    }

    // Increment tag use count
    try {
      sdb.prepare('UPDATE guild_tags SET uses = uses + 1 WHERE guild_id = ? AND name = ?')
        .run(message.guild.id, tag.name);
    } catch (_) {}

    const extraArgs = args.slice(1).join(' ');
    const rendered = renderTag(tag.content, {
      authorId: message.author.id,
      authorUsername: message.author.username,
      channelId: message.channel.id,
      guildName: message.guild.name,
      memberCount: message.guild.memberCount,
      extraArgs
    });

    const sendOptions = {
      allowedMentions: { parse: ['users'], roles: [] }
    };

    if (rendered.embed) {
      sendOptions.embeds = [rendered.embed];
      if (rendered.content) {
        sendOptions.content = rendered.content;
      }
    } else {
      sendOptions.content = rendered.content || '*(empty tag)*';
    }

    return message.channel.send(sendOptions).catch(() => null);
  }
};
