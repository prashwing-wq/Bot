/**
 * Giveaway Reroll Command (Prefix & Standalone)
 * Reroll winner for a finished or active giveaway.
 */
const { handleGiveaway } = require('./giveaway');

module.exports = {
  name: 'greroll',
  description: 'Reroll the winner of a giveaway.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  category: 'giveaways',
  usage: 'greroll <message_id>',
  aliases: ['giveawayreroll', 'g_reroll'],
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const targetMsgId = args[0];
    const winnersCount = parseInt(args[1], 10) || 1;
    if (!targetMsgId) {
      return message.reply(`Usage: \`${prefix}greroll <message_id> [winners_count]\``);
    }

    const res = await handleGiveaway({
      guild: message.guild,
      channel: message.channel,
      member: message.member,
      author: message.author,
      action: 'reroll',
      targetMsgId,
      winnersCount,
      client,
      prefix
    });

    if (res.error) return message.reply(res.error);
    if (res.embed) return message.reply({ embeds: [res.embed] });
  }
};
