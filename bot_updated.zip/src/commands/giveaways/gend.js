/**
 * Giveaway End Command (Prefix & Standalone)
 * Immediately end an active giveaway and pick winners.
 */
const { handleGiveaway } = require('./giveaway');

module.exports = {
  name: 'gend',
  description: 'Immediately end an active giveaway.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  category: 'giveaways',
  usage: 'gend <message_id>',
  aliases: ['giveawayend', 'g_end'],
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const targetMsgId = args[0];
    if (!targetMsgId) {
      return message.reply(`Usage: \`${prefix}gend <message_id>\``);
    }

    const res = await handleGiveaway({
      guild: message.guild,
      channel: message.channel,
      member: message.member,
      author: message.author,
      action: 'end',
      targetMsgId,
      client,
      prefix
    });

    if (res.error) return message.reply(res.error);
    if (res.embed) return message.reply({ embeds: [res.embed] });
  }
};
