/**
 * Giveaway Command (Prefix & Slash)
 * Start, reroll, end, pause, or resume server giveaways
 * Includes button entry and optional role, level, and server age requirements.
 */
const { PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getServerDb, getMasterDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { scheduleTask } = require('../../utils/scheduler');
const { EMOJIS } = require('../../utils/emojis');

function parseDuration(str) {
  if (!str) return null;
  const match = str.match(/^(\d+)([smhd])$/i);
  if (!match) return null;
  const num = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  if (unit === 's') return num * 1000;
  if (unit === 'm') return num * 60 * 1000;
  if (unit === 'h') return num * 60 * 60 * 1000;
  if (unit === 'd') return num * 24 * 60 * 60 * 1000;
  return null;
}

async function handleGiveaway({
  guild,
  channel,
  member,
  author,
  action,
  durationStr,
  winnersCount = 1,
  prize,
  targetMsgId,
  requiredRole,
  minLevel = 0,
  minServerAge = 0,
  client,
  prefix = '!'
}) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  if (!hasPerm(member, PermissionsBitField.Flags.ManageGuild)) {
    return {
      error: 'Permission Denied',
      embed: createEmbed({
        color: client?.config?.COLORS?.DANGER || 0xED4245,
        title: 'Permission Denied',
        description: 'You need the `Manage Server` permission to manage giveaways.'
      })
    };
  }

  const sub = (action || 'help').toLowerCase();
  const sdb = getServerDb(guild.id);

  if (sub === 'start') {
    const durationMs = durationStr ? parseDuration(durationStr) : null;
    if (!durationMs || !prize) {
      return {
        error: `**Usage:** \`${prefix}giveaway start <duration: e.g. 10m, 1h, 1d> <winners> <prize> [--role @role] [--level N] [--age days]\``
      };
    }

    const endsAt = Date.now() + durationMs;
    const endTimestamp = `<t:${Math.floor(endsAt / 1000)}:R>`;

    let reqDescription = '';
    const reqRoleId = requiredRole?.id || (typeof requiredRole === 'string' ? requiredRole.replace(/[<@&>]/g, '') : null);
    if (reqRoleId) {
      reqDescription += `\n• **Required Role:** <@&${reqRoleId}>`;
    }
    if (minLevel > 0) {
      reqDescription += `\n• **Minimum Level:** \`Level ${minLevel}\``;
    }
    if (minServerAge > 0) {
      reqDescription += `\n• **Min Server Age:** \`${minServerAge} days\``;
    }

    const embed = createEmbed({
      color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
      title: `${EMOJIS.GIVEAWAY} GIVEAWAY: ${prize} ${EMOJIS.GIVEAWAY}`,
      description:
        `Click the button below or react with ${EMOJIS.GIVEAWAY} to enter!\n\n` +
        `• **Winners:** \`${winnersCount}\`\n` +
        `• **Hosted By:** ${author}\n` +
        `• **Ends:** ${endTimestamp}` +
        reqDescription,
      footer: 'Tungsten Giveaway System'
    });

    // Temporary placeholder message to obtain Snowflake ID
    const initialRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('ga:join:pending')
        .setLabel('Join Giveaway (0)')
        .setStyle(ButtonStyle.Primary)
        .setEmoji(EMOJIS.GIVEAWAY)
    );

    const gMsg = await channel.send({ embeds: [embed], components: [initialRow] });

    // Update with concrete message Snowflake ID
    const activeRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`ga:join:${gMsg.id}`)
        .setLabel('Join Giveaway (0)')
        .setStyle(ButtonStyle.Primary)
        .setEmoji(EMOJIS.GIVEAWAY)
    );
    await gMsg.edit({ components: [activeRow] }).catch(() => null);
    await gMsg.react('🎉').catch(() => {});

    sdb.prepare(`
      INSERT INTO server_giveaways (message_id, channel_id, prize, winners_count, ends_at, host_id, ended, required_role_id, min_level, min_server_age, paused, pause_remaining_ms)
      VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, 0, NULL)
    `).run(gMsg.id, channel.id, prize, winnersCount, endsAt, author.id, reqRoleId || null, minLevel || 0, minServerAge || 0);

    scheduleTask(guild.id, 'giveaway_end', endsAt, {
      guildId: guild.id,
      channelId: channel.id,
      messageId: gMsg.id
    });

    return { success: true, messageId: gMsg.id, message: `${EMOJIS.GIVEAWAY} Giveaway started in ${channel}!` };
  }

  if (sub === 'reroll') {
    if (!targetMsgId) return { error: `Usage: \`${prefix}giveaway reroll <message_id>\`` };

    const row = sdb.prepare('SELECT * FROM server_giveaways WHERE message_id = ?').get(targetMsgId);
    if (!row) return { error: 'Giveaway not found in this server.' };

    const gChannel = guild.channels?.cache?.get(row.channel_id) || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(row.channel_id).catch(() => null) : null);
    if (!gChannel) return { error: 'Giveaway channel no longer exists.' };

    const gMsg = await gChannel.messages.fetch(row.message_id).catch(() => null);
    if (!gMsg) return { error: 'Giveaway message not found.' };

    // 1. Button entries
    const buttonEntries = sdb.prepare('SELECT user_id FROM server_giveaway_entries WHERE message_id = ?').all(targetMsgId).map(r => r.user_id);

    // 2. Reaction entries
    const reaction = gMsg.reactions?.cache?.get('🎉');
    const reactionUsers = reaction ? (await reaction.users.fetch().catch(() => new Map())) : new Map();
    const reactionUserIds = [...reactionUsers.values()].filter(u => !u.bot).map(u => u.id);

    const allUserIds = Array.from(new Set([...buttonEntries, ...reactionUserIds]));

    const eligible = [];
    for (const uid of allUserIds) {
      if (client?.user && uid === client.user.id) continue;
      let ok = true;
      if (row.required_role_id || row.min_level > 0 || row.min_server_age > 0) {
        const memberObj = guild.members?.cache?.get(uid) || (typeof guild.members?.fetch === 'function' ? await guild.members.fetch(uid).catch(() => null) : null);
        if (!memberObj) {
          ok = false;
        } else {
          if (row.required_role_id && !memberObj.roles?.cache?.has(row.required_role_id)) ok = false;
          if (ok && row.min_level > 0) {
            const lvlRow = sdb.prepare('SELECT level FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(guild.id, uid);
            if ((lvlRow?.level || 0) < row.min_level) ok = false;
          }
          if (ok && row.min_server_age > 0) {
            const joined = memberObj.joinedTimestamp || Date.now();
            const ageDays = (Date.now() - joined) / (86400000);
            if (ageDays < row.min_server_age) ok = false;
          }
        }
      }
      if (ok) eligible.push(uid);
    }

    if (eligible.length === 0) {
      return { error: 'No eligible participants entered the giveaway.' };
    }

    const countToRoll = Math.min(eligible.length, Math.max(1, winnersCount > 1 ? winnersCount : (row.winners_count || 1)));
    const winners = [];
    const pool = [...eligible];
    for (let i = 0; i < countToRoll; i++) {
      const idx = Math.floor(Math.random() * pool.length);
      winners.push(pool.splice(idx, 1)[0]);
    }
    const winnersText = winners.map(w => `<@${w}>`).join(', ');
    const label = countToRoll > 1 ? 'New winners' : 'New winner';
    await channel.send(`${EMOJIS.GIVEAWAY} ${label} for **${row.prize}**: ${winnersText}! Congratulations!`).catch(() => null);
    return { success: true, message: `${EMOJIS.GIVEAWAY} ${label} rolled: ${winnersText}` };
  }

  if (sub === 'end') {
    if (!targetMsgId) return { error: `Usage: \`${prefix}giveaway end <message_id>\`` };

    const row = sdb.prepare('SELECT * FROM server_giveaways WHERE message_id = ?').get(targetMsgId);
    if (!row) return { error: 'Giveaway not found in this server.' };
    if (row.ended === 1) return { error: 'Giveaway has already ended.' };

    const mdb = getMasterDb();
    mdb.prepare("UPDATE scheduled_tasks SET done = 1 WHERE guild_id = ? AND kind = 'giveaway_end' AND payload LIKE ? AND done = 0")
      .run(guild.id, `%"messageId":"${targetMsgId}"%`);

    const scheduler = require('../../utils/scheduler');
    if (typeof scheduler.handleGiveawayEnd === 'function') {
      await scheduler.handleGiveawayEnd(null, { guild, guildId: guild.id, channelId: row.channel_id, messageId: targetMsgId }, client);
    } else {
      sdb.prepare('UPDATE server_giveaways SET ended = 1 WHERE message_id = ?').run(targetMsgId);
    }

    return { success: true, message: `Giveaway #${targetMsgId} has been marked as ended.` };
  }

  if (sub === 'pause') {
    if (!targetMsgId) return { error: `Usage: \`${prefix}giveaway pause <message_id>\`` };

    const row = sdb.prepare('SELECT * FROM server_giveaways WHERE message_id = ?').get(targetMsgId);
    if (!row) return { error: 'Giveaway not found in this server.' };
    if (row.ended === 1) return { error: 'Giveaway has already ended.' };
    if (row.paused === 1) return { error: 'Giveaway is already paused.' };

    const remainingMs = Math.max(0, row.ends_at - Date.now());
    sdb.prepare('UPDATE server_giveaways SET paused = 1, pause_remaining_ms = ? WHERE message_id = ?').run(remainingMs, targetMsgId);

    const mdb = getMasterDb();
    mdb.prepare("UPDATE scheduled_tasks SET done = 1 WHERE guild_id = ? AND kind = 'giveaway_end' AND payload LIKE ? AND done = 0")
      .run(guild.id, `%"messageId":"${targetMsgId}"%`);

    const gChannel = guild.channels?.cache?.get(row.channel_id) || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(row.channel_id).catch(() => null) : null);
    if (gChannel) {
      const gMsg = await gChannel.messages.fetch(row.message_id).catch(() => null);
      if (gMsg) {
        const pauseEmbed = createEmbed({
          color: 0xFEE75C,
          title: `${EMOJIS.LOCK} GIVEAWAY PAUSED: ${row.prize}`,
          description: `This giveaway has been paused by staff.\n\n• **Prize:** **${row.prize}**\n• **Winners:** \`${row.winners_count}\`\n• **Status:** ${EMOJIS.LOCK} **Paused**`,
          footer: 'Tungsten Giveaway System'
        });
        const pausedRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`ga:paused:${targetMsgId}`)
            .setLabel('Giveaway Paused')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji(EMOJIS.LOCK)
            .setDisabled(true)
        );
        await gMsg.edit({ embeds: [pauseEmbed], components: [pausedRow] }).catch(() => null);
      }
    }

    return { success: true, message: `${EMOJIS.LOCK} Giveaway #${targetMsgId} has been paused.` };
  }

  if (sub === 'resume') {
    if (!targetMsgId) return { error: `Usage: \`${prefix}giveaway resume <message_id>\`` };

    const row = sdb.prepare('SELECT * FROM server_giveaways WHERE message_id = ?').get(targetMsgId);
    if (!row) return { error: 'Giveaway not found in this server.' };
    if (row.ended === 1) return { error: 'Giveaway has already ended.' };
    if (row.paused !== 1) return { error: 'Giveaway is not currently paused.' };

    const durationMs = row.pause_remaining_ms && row.pause_remaining_ms > 0 ? row.pause_remaining_ms : 60000;
    const endsAt = Date.now() + durationMs;
    sdb.prepare('UPDATE server_giveaways SET paused = 0, pause_remaining_ms = NULL, ends_at = ? WHERE message_id = ?').run(endsAt, targetMsgId);

    scheduleTask(guild.id, 'giveaway_end', endsAt, {
      guildId: guild.id,
      channelId: row.channel_id,
      messageId: row.message_id
    });

    const countRow = sdb.prepare('SELECT COUNT(*) as cnt FROM server_giveaway_entries WHERE message_id = ?').get(targetMsgId);
    const entryCount = countRow ? countRow.cnt : 0;

    const gChannel = guild.channels?.cache?.get(row.channel_id) || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(row.channel_id).catch(() => null) : null);
    if (gChannel) {
      const gMsg = await gChannel.messages.fetch(row.message_id).catch(() => null);
      if (gMsg) {
        let reqDescription = '';
        if (row.required_role_id) reqDescription += `\n• **Required Role:** <@&${row.required_role_id}>`;
        if (row.min_level > 0) reqDescription += `\n• **Minimum Level:** \`Level ${row.min_level}\``;
        if (row.min_server_age > 0) reqDescription += `\n• **Min Server Age:** \`${row.min_server_age} days\``;

        const resumeEmbed = createEmbed({
          color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
          title: `${EMOJIS.GIVEAWAY} GIVEAWAY: ${row.prize} ${EMOJIS.GIVEAWAY}`,
          description:
            `Click the button below or react with ${EMOJIS.GIVEAWAY} to enter!\n\n` +
            `• **Winners:** \`${row.winners_count}\`\n` +
            `• **Ends:** <t:${Math.floor(endsAt / 1000)}:R>` +
            reqDescription,
          footer: 'Tungsten Giveaway System'
        });
        const resumeRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`ga:join:${targetMsgId}`)
            .setLabel(`Join Giveaway (${entryCount})`)
            .setStyle(ButtonStyle.Primary)
            .setEmoji(EMOJIS.GIVEAWAY)
        );
        await gMsg.edit({ embeds: [resumeEmbed], components: [resumeRow] }).catch(() => null);
      }
    }

    return { success: true, message: `${EMOJIS.SUCCESS} Giveaway #${targetMsgId} has been resumed. Ends <t:${Math.floor(endsAt / 1000)}:R>.` };
  }

  if (sub === 'list') {
    const active = sdb.prepare('SELECT * FROM server_giveaways WHERE ended = 0 ORDER BY ends_at ASC').all();
    if (active.length === 0) {
      return {
        embed: createEmbed({
          color: 0x2b2d31,
          title: `${EMOJIS.GIVEAWAY} Active Server Giveaways`,
          description: '*There are currently no active giveaways running in this server.*'
        })
      };
    }
    const lines = active.map((g, i) => {
      const remaining = g.paused ? `${EMOJIS.LOCK} **Paused**` : `<t:${Math.floor(g.ends_at / 1000)}:R>`;
      return `\`${i + 1}.\` **${g.prize}** (${g.winners_count} winner${g.winners_count > 1 ? 's' : ''})\n> Channel: <#${g.channel_id}> • Ends: ${remaining} • ID: \`${g.message_id}\``;
    });
    return {
      embed: createEmbed({
        color: 0xFEE75C,
        title: `${EMOJIS.GIVEAWAY} Active Server Giveaways (${active.length})`,
        description: lines.join('\n\n')
      })
    };
  }

  if (sub === 'staff') {
    if (targetMsgId) {
      const roleId = targetMsgId.replace(/[<@&>]/g, '');
      const role = guild.roles.cache.get(roleId);
      if (!role) return { error: 'Role not found.' };
      sdb.prepare(`
        INSERT INTO server_settings (key, value, updated_at)
        VALUES ('giveaway_staff_role', ?, strftime('%s', 'now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%s', 'now')
      `).run(role.id);
      return {
        embed: createEmbed({
          color: client?.config?.COLORS?.SUCCESS || 0x57F287,
          title: `${EMOJIS.GIVEAWAY} Giveaway Staff Configured`,
          description: `Successfully set <@&${role.id}> as the Giveaway Manager role.`
        })
      };
    }
    const staffRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'giveaway_staff_role'").get();
    return {
      embed: createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.GIVEAWAY} Giveaway Staff Role`,
        description: staffRow?.value ? `Current giveaway staff role: <@&${staffRow.value}>` : 'No custom giveaway staff role configured.'
      })
    };
  }

  if (sub === 'config') {
    const staffRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'giveaway_staff_role'").get();
    const activeCount = sdb.prepare('SELECT COUNT(*) as cnt FROM server_giveaways WHERE ended = 0').get()?.cnt || 0;
    return {
      embed: createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.GIVEAWAY} Giveaway Configuration • ${guild.name}`,
        description:
          `• **Staff Manager Role:** ${staffRow?.value ? `<@&${staffRow.value}>` : '`Manage Server permission`'}\n` +
          `• **Active Giveaways:** \`${activeCount}\`\n` +
          `• **Default Reaction Emoji:** ${EMOJIS.GIVEAWAY}\n` +
          `• **Multi-Winner Support:** Up to 50 winners\n` +
          `• **Requirements:** Role, Level, and Account Age supported`
      })
    };
  }

  if (sub === 'embed') {
    const embedPreview = createEmbed({
      color: 0x5865F2,
      title: `${EMOJIS.GIVEAWAY} GIVEAWAY: Discord Nitro (1 Month) ${EMOJIS.GIVEAWAY}`,
      description:
        `Click the button below or react with ${EMOJIS.GIVEAWAY} to enter!\n\n` +
        `• **Winners:** \`1\`\n` +
        `• **Hosted By:** ${author}\n` +
        `• **Ends:** <t:${Math.floor(Date.now() / 1000) + 3600}:R>\n\n` +
        `*Preview embed generated by ${author.username}.*`,
      footer: 'Tungsten Giveaway System'
    });
    return { embed: embedPreview };
  }

  return {
    embed: createEmbed({
      color: client?.config?.COLORS?.INFO || 0x3498DB,
      title: `${EMOJIS.GIVEAWAY} Giveaway System`,
      description:
        `**Subcommands:**\n` +
        `• \`${prefix}giveaway start <duration> <winners> <prize> [--role @role] [--level N] [--age days]\`\n` +
        `• \`${prefix}giveaway reroll <message_id>\` — Select new winners\n` +
        `• \`${prefix}giveaway end <message_id>\` — End an active giveaway\n` +
        `• \`${prefix}giveaway pause <message_id>\` — Pause an active giveaway\n` +
        `• \`${prefix}giveaway resume <message_id>\` — Resume a paused giveaway\n` +
        `• \`${prefix}giveaway list\` — List active giveaways\n` +
        `• \`${prefix}giveaway staff [role]\` — Set or view giveaway staff role\n` +
        `• \`${prefix}giveaway config\` — View giveaway configuration\n` +
        `• \`${prefix}giveaway embed\` — Preview giveaway card\n`
    })
  };
}

module.exports = {
  name: 'giveaway',
  description: 'Host, reroll, end, pause, or resume community giveaways.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  category: 'giveaways',
  usage: 'giveaway <start|reroll|end|pause|resume> [duration] [winners] [prize]',
  aliases: ['gstart', 'glist', 'gstaff', 'gconfig', 'gembed', 'gaway'],
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : '') || '').toLowerCase();
    let action = args[0]?.toLowerCase() || 'help';
    let durationStr = args[1];
    let winnersCount = parseInt(args[2], 10) || 1;
    let rest = args.slice(3);

    if (invoked === 'glist') action = 'list';
    if (invoked === 'gstaff') action = 'staff';
    if (invoked === 'gconfig') action = 'config';
    if (invoked === 'gembed') action = 'embed';

    if (invoked === 'gstart' || /^\d+[smhd]$/i.test(args[0])) {
      action = 'start';
      if (/^\d+[smhd]$/i.test(args[0])) {
        durationStr = args[0];
        winnersCount = parseInt(args[1], 10) || 1;
        rest = args.slice(2);
      }
    }

    if (action === 'start') {
      const prizeTokens = [];
      let requiredRole = null;
      let minLevel = 0;
      let minServerAge = 0;

      for (let i = 0; i < rest.length; i++) {
        const token = rest[i];
        if (token === '--role' || token === '-r') {
          requiredRole = rest[++i];
        } else if (token === '--level' || token === '-l') {
          minLevel = parseInt(rest[++i], 10) || 0;
        } else if (token === '--age' || token === '-a') {
          minServerAge = parseInt(rest[++i], 10) || 0;
        } else {
          prizeTokens.push(token);
        }
      }

      const prize = prizeTokens.join(' ');

      const res = await handleGiveaway({
        guild: message.guild,
        channel: message.channel,
        member: message.member,
        author: message.author,
        action,
        durationStr,
        winnersCount,
        prize,
        targetMsgId: null,
        requiredRole,
        minLevel,
        minServerAge,
        client,
        prefix
      });

      if (res.error) return message.reply(res.error);
      if (res.embed) return message.reply({ embeds: [res.embed] });
      return;
    }

    const targetMsgId = args[1];
    const res = await handleGiveaway({
      guild: message.guild,
      channel: message.channel,
      member: message.member,
      author: message.author,
      action,
      targetMsgId,
      client,
      prefix
    });

    if (res.error) return message.reply(res.error);
    if (res.embed) return message.reply({ embeds: [res.embed] });
  },

  parseDuration,
  handleGiveaway
};
