/**
 * Ticket Command & Interactive Panel Suite (Prefix & Slash)
 * Modular support ticket creation, management, closing, and interactive deployment panels.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, PermissionsBitField, ChannelType } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');
const { getTicketCategories, closeTicketWithTranscript } = require('../../utils/ticketTranscript');
const { EMOJIS } = require('../../utils/emojis');

async function handleTicketAction({ guild, channel, member, author, action, reason, client, prefix = '!' }) {
  if (!guild) return { error: 'This command can only be used in a server.' };
  const sdb = getServerDb(guild.id);
  const sub = (action || 'status').toLowerCase();

  // 1. Deploy Interactive Ticket Panel
  if (sub === 'panel' || sub === 'setup' || sub === 'deploy') {
    if (!hasPerm(member, PermissionsBitField.Flags.ManageGuild)) {
      return { error: 'You need `Manage Server` permission to deploy a ticket panel.' };
    }

    const card = createV2Card({
      color: 0x2b2d31,
      title: `🎫  Customer Support & Inquiries • ${guild.name}`,
      description:
        `> Need assistance from the moderation or server management team?\n\n` +
        `• Select a category from the dropdown menu below to begin.\n` +
        `• A private, dedicated support channel will be provisioned for you.\n` +
        `• Qualified staff members will be automatically notified to assist you.\n\n` +
        `*Please ensure your inquiry is legitimate before opening.*`,
      footerText: `Tungsten Support Desk • 24/7 Active`
    });

    const categories = getTicketCategories(guild.id, sdb);
    const selectOptions = categories.map(cat => ({
      label: cat.name,
      value: cat.id,
      description: (cat.description || `Open a ${cat.name} inquiry`).slice(0, 100),
      emoji: cat.emoji || EMOJIS.TICKET
    }));

    const selectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('ticket:category_select')
        .setPlaceholder('Choose a support category to open a ticket...')
        .addOptions(selectOptions)
    );

    const buttonRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('ticket:create_btn')
        .setLabel('Quick Ticket')
        .setStyle(ButtonStyle.Primary)
        .setEmoji(EMOJIS.TICKET)
    );

    return { success: true, isPanel: true, embeds: [card], components: [selectRow, buttonRow] };
  }

  // 2. Open Ticket
  if (sub === 'create' || sub === 'new' || sub === 'open') {
    const cleanReason = reason || 'General Support Inquiry';

    // Check existing ticket for user
    const existing = sdb.prepare(`
      SELECT * FROM server_tickets WHERE user_id = ? AND status = 'open'
    `).get(author.id);

    if (existing) {
      const chan = guild.channels.cache.get(existing.channel_id);
      if (chan) {
        return { error: `You already have an active ticket open in ${chan}.` };
      }
    }

    try {
      const ticketChannel = await guild.channels.create({
        name: `ticket-${author.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12)}`,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionsBitField.Flags.ViewChannel]
          },
          {
            id: author.id,
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.ReadMessageHistory,
              PermissionsBitField.Flags.AttachFiles
            ]
          },
          {
            id: client.user.id,
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.ManageChannels,
              PermissionsBitField.Flags.EmbedLinks
            ]
          }
        ]
      });

      sdb.prepare(`
        INSERT INTO server_tickets (channel_id, user_id, guild_id, created_at, status)
        VALUES (?, ?, ?, ?, 'open')
      `).run(ticketChannel.id, author.id, guild.id, Date.now());

      const welcomeEmbed = createV2Card({
        color: 0x2b2d31,
        title: '🎫  Support Ticket Provisioned',
        description:
          `> Welcome <@${author.id}>! Staff will assist you shortly.\n\n` +
          `• **Subject:** \`${cleanReason}\`\n` +
          `• **Creator:** <@${author.id}>\n\n` +
          `Click the button below to close this ticket once your inquiry is resolved.`,
        footerText: 'Tungsten Support System'
      });

      const closeBtn = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket:close_btn').setLabel('Close Ticket').setStyle(ButtonStyle.Danger).setEmoji(EMOJIS.LOCK)
      );

      await ticketChannel.send({ content: `<@${author.id}>`, embeds: [welcomeEmbed], components: [closeBtn] });

      const replyCard = createV2Card({
        color: 0x2ECC71,
        title: 'Ticket Created',
        description: `> Your ticket has been generated: <#${ticketChannel.id}>`
      });

      return { success: true, embeds: [replyCard] };
    } catch (e) {
      return { error: `Failed to create ticket: ${e.message}` };
    }
  }

  // 3. Close Ticket
  if (sub === 'close') {
    const ticketRow = sdb.prepare('SELECT * FROM server_tickets WHERE channel_id = ?').get(channel.id);
    if (!ticketRow) {
      return { error: 'This channel is not an active support ticket.' };
    }

    setTimeout(async () => {
      try {
        await closeTicketWithTranscript({
          guild,
          channel,
          closerUser: author,
          reason: reason || 'Ticket closed by staff/user',
          client,
          sdb
        });
      } catch (_) {}
    }, 3000);

    return {
      success: true,
      content: '**Generating transcripts and closing ticket in 3 seconds...**'
    };
  }

  // Status Overview
  const card = createV2Card({
    color: 0x2b2d31,
    title: 'Support Ticket System',
    description:
      `> Automated, isolated ticket management engine.\n\n` +
      `**Commands:**\n` +
      `• \`${prefix}ticket create [reason]\` — Open a private support channel\n` +
      `• \`${prefix}ticket close\` — Close the current ticket\n` +
      `• \`${prefix}ticket panel\` — Deploy the interactive ticket panel to this channel`,
    footerText: `Tungsten Support Suite • ${guild.name}`
  });

  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket:create_btn').setLabel('Open Ticket').setStyle(ButtonStyle.Primary).setEmoji(EMOJIS.TICKET),
    new ButtonBuilder().setCustomId('ticket:help_btn').setLabel('Setup Help').setStyle(ButtonStyle.Secondary).setEmoji(EMOJIS.REFRESH)
  );

  return { success: true, embeds: [card], components: [buttons] };
}

module.exports = {
  name: 'ticket',
  description: 'Open, manage, close, or deploy interactive support ticket panels.',
  permissions: [],
  botPermissions: ['ManageChannels'],
  category: 'tickets',
  usage: '[create|close|panel|setup] [reason]',
  aliases: ['tickets', 'ticketpanel', 'ticketsetup', 'ticketedit'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'ticket').toLowerCase();
    const action = args[0]?.toLowerCase() || (invoked === 'ticketpanel' || invoked === 'ticketsetup' ? 'panel' : 'status');
    const reason = args.slice(1).join(' ');

    const res = await handleTicketAction({
      guild: message.guild,
      channel: message.channel,
      member: message.member,
      author: message.author,
      action,
      reason,
      client,
      prefix
    });

    if (res.error) return message.reply(res.error);
    if (res.isPanel) return message.channel.send({ embeds: res.embeds, components: res.components });
    if (res.content) return message.reply(res.content);
    return message.reply({ embeds: res.embeds, components: res.components });
  },

  handleTicketAction
};
