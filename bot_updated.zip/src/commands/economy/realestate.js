const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { getBalance, debitWallet, creditWallet } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

const PROPERTIES = {
  apt: { id: 'apt', name: 'Downtown Studio Apartment', price: 50000, incomePerHour: 250 },
  suburb: { id: 'suburb', name: 'Suburban Family Residence', price: 250000, incomePerHour: 1500 },
  villa: { id: 'villa', name: 'Luxury Hillside Villa', price: 1000000, incomePerHour: 7500 },
  penthouse: { id: 'penthouse', name: 'Skyline Penthouse Suite', price: 5000000, incomePerHour: 45000 }
};

module.exports = {
  name: 'realestate',
  aliases: ['buyhouse', 'properties', 'realtor', 'property'],
  category: 'economy',
  description: 'Acquire high-value real estate properties that generate passive rental income',
  usage: '<list | buy <property_id> | myproperties | collect>',
  cooldown: 5,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'list').toLowerCase();

    if (sub === 'list') {
      const lines = Object.values(PROPERTIES).map(p =>
        `• **${p.name}** (\`${p.id}\`)\n  Price: **${p.price.toLocaleString()}c** | Rental Income: **+${p.incomePerHour.toLocaleString()}c/hour**`
      );

      const embed = createEmbed({
        title: '🏙️ Tungsten Luxury Real Estate',
        description: lines.join('\n\n') + `\n\n• **Purchase:** \`${prefix}realestate buy <id>\`\n• **My Properties:** \`${prefix}realestate myproperties\`\n• **Collect Rent:** \`${prefix}realestate collect\``,
        color: 0x5865F2,
        footer: { text: 'Real estate properties generate passive hourly yields' }
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const propId = args[1]?.toLowerCase();
      const prop = PROPERTIES[propId];
      if (!prop) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Unknown property. Valid IDs: \`${Object.keys(PROPERTIES).join(', ')}\``);
      }

      const bal = getBalance(sdb, message.author.id);
      if (bal.wallet < prop.price) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You need **${prop.price.toLocaleString()} credits** in your wallet to acquire **${prop.name}**.`);
      }

      const existing = sdb.prepare('SELECT 1 FROM eco_properties WHERE guild_id = ? AND user_id = ? AND property_id = ?')
        .get(message.guild.id, message.author.id, prop.id);

      if (existing) {
        return message.reply(`<a:tungsten_info:1567240890748248084> You already own the **${prop.name}**.`);
      }

      debitWallet(sdb, message.author.id, prop.price);
      const now = Math.floor(Date.now() / 1000);
      sdb.prepare('INSERT INTO eco_properties (guild_id, user_id, property_id, purchased_at) VALUES (?, ?, ?, ?)')
        .run(message.guild.id, message.author.id, prop.id, now);

      const embed = createEmbed({
        title: '🏠 Property Acquired!',
        description: `Congratulations! You are now the official owner of **${prop.name}**.\n` +
          `It will generate **+${prop.incomePerHour.toLocaleString()} credits/hour** in passive rental yield. Collect rent with \`${prefix}realestate collect\`.`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'myproperties' || sub === 'owned') {
      const rows = sdb.prepare('SELECT property_id, purchased_at FROM eco_properties WHERE guild_id = ? AND user_id = ?')
        .all(message.guild.id, message.author.id);

      if (!rows || rows.length === 0) {
        return message.reply(`<a:tungsten_info:1567240890748248084> You do not own any real estate properties. Browse listings via \`${prefix}realestate\`.`);
      }

      let totalYield = 0;
      const lines = rows.map(r => {
        const p = PROPERTIES[r.property_id];
        if (!p) return null;
        totalYield += p.incomePerHour;
        return `• **${p.name}** — Purchased <t:${r.purchased_at}:R> (+${p.incomePerHour}c/h)`;
      }).filter(Boolean);

      const embed = createEmbed({
        title: `🏢 Property Portfolio — ${message.author.username}`,
        description: lines.join('\n') + `\n\n• **Total Passive Yield:** **+${totalYield.toLocaleString()} credits/hour**\n• Collect with \`${prefix}realestate collect\``,
        color: 0x5865F2
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'collect' || sub === 'rent') {
      const rows = sdb.prepare('SELECT property_id, purchased_at FROM eco_properties WHERE guild_id = ? AND user_id = ?')
        .all(message.guild.id, message.author.id);

      if (!rows || rows.length === 0) {
        return message.reply('<a:tungsten_close:1567234632905138206> You do not own any properties to collect rental income from.');
      }

      let totalHourly = 0;
      for (const r of rows) {
        const p = PROPERTIES[r.property_id];
        if (p) totalHourly += p.incomePerHour;
      }

      creditWallet(sdb, message.author.id, totalHourly);

      const embed = createEmbed({
        title: '💰 Rental Income Collected',
        description: `Successfully collected **${totalHourly.toLocaleString()} credits** from your **${rows.length} real estate properties**!`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    return message.reply(`Usage: \`${prefix}realestate <list | buy <id> | myproperties | collect>\``);
  }
};
