const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { getBalance, debitWallet, creditWallet } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

const STOCKS = {
  TUNG: { name: 'Tungsten Technologies', base: 150.0 },
  CLST: { name: 'Tungsten Technologies', base: 150.0 },
  AURA: { name: 'Aura Media Corp', base: 45.0 },
  NEO: { name: 'Neo Quantum Networks', base: 82.5 },
  TITN: { name: 'Titan Heavy Industries', base: 210.0 },
  QUANT: { name: 'Quantum AI Systems', base: 340.0 }
};

function getLivePrice(symbol) {
  const stock = STOCKS[symbol.toUpperCase()];
  if (!stock) return null;
  // Deterministic hourly pseudo-fluctuation +/- 15%
  const hour = Math.floor(Date.now() / 3600000);
  const hash = Math.sin(hour * 1337 + stock.base) * 10000;
  const factor = 1 + (((hash - Math.floor(hash)) * 0.30) - 0.15);
  const current = Math.max(5.0, Math.round(stock.base * factor * 100) / 100);
  const change = Math.round(((current - stock.base) / stock.base) * 10000) / 100;
  return { ...stock, symbol: symbol.toUpperCase(), price: current, change };
}

module.exports = {
  name: 'stocks',
  aliases: ['stock', 'shares', 'stockmarket'],
  category: 'economy',
  description: 'Trade virtual stocks on the Tungsten Exchange with live price fluctuations',
  usage: '<list | buy <ticker> <amount> | sell <ticker> <amount> | portfolio>',
  cooldown: 3,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'list').toLowerCase();

    if (sub === 'list' || sub === 'market') {
      const lines = Object.keys(STOCKS).map(sym => {
        const data = getLivePrice(sym);
        const icon = data.change >= 0 ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>';
        const sign = data.change >= 0 ? '+' : '';
        return `• **${data.symbol}** (${data.name}): **${data.price}c** | ${icon} \`${sign}${data.change}%\``;
      });

      const embed = createEmbed({
        title: '<a:tungsten_chart:1567234342701367357> Tungsten Stock Exchange (CSX)',
        description: lines.join('\n') + `\n\n• **Buy:** \`${prefix}stocks buy <ticker> <amount>\`\n• **Sell:** \`${prefix}stocks sell <ticker> <amount>\`\n• **Portfolio:** \`${prefix}stocks portfolio\``,
        color: 0x5865F2,
        footer: { text: 'Prices update hourly based on market simulation' }
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const sym = args[1]?.toUpperCase();
      const amount = parseInt(args[2], 10);

      const stock = getLivePrice(sym);
      if (!stock) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Unknown stock ticker. Valid tickers: \`${Object.keys(STOCKS).join(', ')}\``);
      }
      if (isNaN(amount) || amount <= 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid number of shares to purchase. Usage: \`${prefix}stocks buy ${sym} <amount>\``);
      }

      const totalCost = Math.round(stock.price * amount);
      const bal = getBalance(sdb, message.author.id);

      if (bal.wallet < totalCost) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You need **${totalCost.toLocaleString()} credits** in your wallet to purchase **${amount} shares** of ${sym}. You have **${bal.wallet.toLocaleString()} credits**.`);
      }

      debitWallet(sdb, message.author.id, totalCost);

      const existing = sdb.prepare('SELECT shares, avg_buy_price FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND symbol = ?')
        .get(message.guild.id, message.author.id, sym);

      if (existing) {
        const totalShares = existing.shares + amount;
        const newAvg = Math.round(((existing.shares * existing.avg_buy_price) + totalCost) / totalShares * 100) / 100;
        sdb.prepare('UPDATE eco_user_stocks SET shares = ?, avg_buy_price = ? WHERE guild_id = ? AND user_id = ? AND symbol = ?')
          .run(totalShares, newAvg, message.guild.id, message.author.id, sym);
      } else {
        sdb.prepare('INSERT INTO eco_user_stocks (guild_id, user_id, symbol, shares, avg_buy_price) VALUES (?, ?, ?, ?, ?)')
          .run(message.guild.id, message.author.id, sym, amount, stock.price);
      }

      const embed = createEmbed({
        title: '<a:tungsten_success:1567242523468890274> Stock Purchase Executed',
        description: `Successfully purchased **${amount} shares** of **${sym}** for **${totalCost.toLocaleString()}c** (@ ${stock.price}c/share).`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'sell') {
      const sym = args[1]?.toUpperCase();
      const amount = parseInt(args[2], 10);

      const stock = getLivePrice(sym);
      if (!stock) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Unknown stock ticker. Valid tickers: \`${Object.keys(STOCKS).join(', ')}\``);
      }

      const row = sdb.prepare('SELECT shares FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND symbol = ?')
        .get(message.guild.id, message.author.id, sym);

      if (!row || row.shares <= 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You do not own any shares of **${sym}**.`);
      }

      const sharesToSell = isNaN(amount) || amount <= 0 ? row.shares : Math.min(amount, row.shares);
      const totalEarned = Math.round(stock.price * sharesToSell);

      if (sharesToSell >= row.shares) {
        sdb.prepare('DELETE FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND symbol = ?')
          .run(message.guild.id, message.author.id, sym);
      } else {
        sdb.prepare('UPDATE eco_user_stocks SET shares = shares - ? WHERE guild_id = ? AND user_id = ? AND symbol = ?')
          .run(sharesToSell, message.guild.id, message.author.id, sym);
      }

      creditWallet(sdb, message.author.id, totalEarned);

      const embed = createEmbed({
        title: '<a:tungsten_success:1567242523468890274> Stock Sale Executed',
        description: `Sold **${sharesToSell} shares** of **${sym}** for **${totalEarned.toLocaleString()}c** (@ ${stock.price}c/share). Credits have been deposited to your wallet.`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'portfolio' || sub === 'holdings') {
      const rows = sdb.prepare('SELECT symbol, shares, avg_buy_price FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND shares > 0')
        .all(message.guild.id, message.author.id);

      if (!rows || rows.length === 0) {
        return message.reply(`<a:tungsten_info:1567240890748248084> You do not have any active stock holdings. View market prices via \`${prefix}stocks\`.`);
      }

      let totalVal = 0;
      let totalCost = 0;

      const lines = rows.map(r => {
        const live = getLivePrice(r.symbol);
        const val = Math.round(live.price * r.shares);
        const cost = Math.round(r.avg_buy_price * r.shares);
        totalVal += val;
        totalCost += cost;
        const profit = val - cost;
        const icon = profit >= 0 ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>';
        return `• **${r.symbol}**: **${r.shares} shares** | Current: **${val.toLocaleString()}c** (${icon} ${profit >= 0 ? '+' : ''}${profit.toLocaleString()}c)`;
      });

      const totalProfit = totalVal - totalCost;
      const profitPct = totalCost > 0 ? Math.round((totalProfit / totalCost) * 10000) / 100 : 0;

      const embed = createEmbed({
        title: `<a:tungsten_chart:1567234342701367357> Stock Portfolio — ${message.author.username}`,
        description: lines.join('\n') + `\n\n` +
          `• **Total Value:** **${totalVal.toLocaleString()} credits**\n` +
          `• **Total P/L:** **${totalProfit >= 0 ? '+' : ''}${totalProfit.toLocaleString()} credits** (\`${profitPct}%\`)`,
        color: totalProfit >= 0 ? 0x57F287 : 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }

    return message.reply(`Usage: \`${prefix}stocks <list | buy <ticker> <amount> | sell <ticker> <amount> | portfolio>\``);
  }
};
