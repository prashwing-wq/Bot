/**
 * Economy Shop Command (Prefix)
 * Browse available server items and consumables.
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed, hasPerm } = require('../../utils/tools');
const { ensureDefaultShopItems } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'shop',
  aliases: ['store', 'market'],
  category: 'economy',
  description: 'View items available in the economy shop.',
  usage: 'shop [add <id> <price> <role|consumable> <name...>]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sdb = getServerDb(message.guild.id);
    ensureDefaultShopItems(sdb);

    const sub = args[0]?.toLowerCase();

    // Admin Add Item: !shop add <id> <price> <type: role|consumable> <name...>
    if (sub === 'add') {
      if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to add items to the shop.');
      }

      const itemId = args[1]?.toLowerCase();
      const price = parseInt(args[2], 10);
      const type = args[3]?.toLowerCase();
      const name = args.slice(4).join(' ');

      if (!itemId || isNaN(price) || price <= 0 || !type || !name) {
        return message.reply(`Usage: \`${prefix}shop add <item_id> <price> <role|consumable> <item_name>\``);
      }

      let roleId = null;
      if (type === 'role') {
        const role = message.mentions?.roles?.first() || message.guild.roles.cache.find(r => r.name.toLowerCase() === name.toLowerCase());
        if (role) roleId = role.id;
      }

      sdb.prepare(`
        INSERT INTO economy_shop_items (item_id, name, description, price, type, role_id, max_per_user)
        VALUES (?, ?, ?, ?, ?, ?, 10)
        ON CONFLICT(item_id) DO UPDATE SET
          name = excluded.name,
          price = excluded.price,
          type = excluded.type,
          role_id = excluded.role_id
      `).run(itemId, name, `Purchasable ${type} item: ${name}`, price, type, roleId);

      return message.reply(`<a:tungsten_success:1567242523468890274> Added **${name}** (\`${itemId}\`) to the shop for **$${price.toLocaleString()}**.`);
    }

    const items = sdb.prepare('SELECT * FROM economy_shop_items ORDER BY price ASC').all();

    if (items.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> The shop is currently empty.');
    }

    const list = items.map(item => {
      const typeIcon = item.type === 'role' ? '🎭' : '📦';
      const roleText = item.role_id ? ` (Grants <@&${item.role_id}>)` : '';
      return `${typeIcon} **${item.name}** — \`${item.item_id}\`\n` +
        `• **Price:** **$${item.price.toLocaleString()}** • **Type:** \`${item.type}\`${roleText}\n` +
        `• *${item.description || 'No description provided.'}*`;
    }).join('\n\n');

    const embed = createEmbed({
      color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
      title: `🛍️  Server Economy Shop • ${message.guild.name}`,
      description:
        `Welcome to the economy store! Use \`${prefix}buy <item_id> [quantity]\` to purchase.\n\n` +
        list,
      footer: { text: `Total Items: ${items.length} • Tungsten Economy Engine` }
    });

    return message.reply({ embeds: [embed] });
  }
};
