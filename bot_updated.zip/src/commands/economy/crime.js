const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { getBalance, creditWallet, debitWallet } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

const CRIMES_SUCCESS = [
  { action: 'hacked into an offshore ATM', min: 1000, max: 3500 },
  { action: 'intercepted an armored cash transport', min: 2500, max: 6000 },
  { action: 'executed a high-stakes jewelry heist', min: 3000, max: 7500 },
  { action: 'infiltrated a casino vault', min: 4000, max: 10000 }
];

const CRIMES_FAIL = [
  'tripped the security laser and were fined by local authorities',
  'left your driver license at the crime scene and had to pay bail',
  'got chased down by the K-9 unit and paid court restitution',
  'were caught red-handed on 4K CCTV cameras'
];

module.exports = {
  name: 'crime',
  aliases: ['heist', 'commitcrime'],
  category: 'economy',
  description: 'Commit a high-risk high-reward crime for large payouts with fine risk',
  usage: '',
  cooldown: 45,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const success = Math.random() >= 0.45; // 55% success rate

    if (success) {
      const scenario = CRIMES_SUCCESS[Math.floor(Math.random() * CRIMES_SUCCESS.length)];
      const reward = Math.floor(Math.random() * (scenario.max - scenario.min + 1)) + scenario.min;

      creditWallet(sdb, message.author.id, reward);
      const bal = getBalance(sdb, message.author.id);

      const embed = createEmbed({
        title: '🕵️ Crime Successful!',
        description: `> You **${scenario.action}** and escaped with **+${reward.toLocaleString()} credits**!\n\n` +
          `**Wallet Balance:** **${bal.wallet.toLocaleString()}c**`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    } else {
      const failReason = CRIMES_FAIL[Math.floor(Math.random() * CRIMES_FAIL.length)];
      const fine = Math.floor(Math.random() * 1200) + 400; // 400-1600 fine

      debitWallet(sdb, message.author.id, fine);
      const bal = getBalance(sdb, message.author.id);

      const embed = createEmbed({
        title: '<a:tungsten_siren:1567242157725712555> Crime Failed — Busted!',
        description: `> You **${failReason}** and were slapped with a **-${fine.toLocaleString()} credit fine**!\n\n` +
          `**Wallet Balance:** **${bal.wallet.toLocaleString()}c**`,
        color: 0xED4245
      });
      return message.reply({ embeds: [embed] });
    }
  }
};
