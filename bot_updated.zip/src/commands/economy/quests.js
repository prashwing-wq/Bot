/**
 * Tungsten Daily Quests Command (Node.js)
 * View daily challenges, track progress bars, claim coin/XP rewards, and maintain streaks.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const {
  getUserQuests,
  getUserStreak,
  claimQuestRewards,
  renderProgressBar,
  getUtcDateString
} = require('../../utils/questEngine');

module.exports = {
  name: 'quests',
  category: 'economy',
  description: 'View daily quests, check progress bars, claim rewards, and track streaks.',
  usage: '[claim]',
  aliases: ['quest', 'dailyquests', 'dailyquest'],
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const sdb = getServerDb(message.guild.id);
    const userId = message.author.id;
    const sub = (args[0] || '').toLowerCase();

    // Subcommand: Claim rewards
    if (sub === 'claim') {
      const claimRes = claimQuestRewards(message.guild.id, userId, sdb);
      if (claimRes.claimedCoins === 0 && claimRes.claimedXp === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.INFO || 0x3498db,
              title: '<a:tungsten_gift:1567240042563244072> Quests Already Claimed',
              description: 'You have no unclaimed quest rewards right now! Keep completing daily quests to earn more coins and XP.'
            })
          ]
        });
      }

      let bonusNotice = '';
      if (claimRes.streakUpdated) {
        bonusNotice = `\n\n<a:tungsten_bolt:1567233430570405968> **Streak Bonus Unlocked!** Current streak: **${claimRes.streakInfo.streak} day(s)**!`;
      }

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x2ecc71,
            title: '<a:tungsten_party:1567241769593339988> Quest Rewards Claimed!',
            description:
              `You claimed **+${claimRes.claimedCoins.toLocaleString()} <a:tungsten_coin:1567238316967985244> Coins** and **+${claimRes.claimedXp.toLocaleString()} <a:tungsten_bolt:1567233430570405968> XP**!${bonusNotice}\n\n` +
              `Check your updated balance with \`${prefix}balance\`.`
          })
        ]
      });
    }

    // Default: Display user's quests
    const today = getUtcDateString();
    const quests = getUserQuests(message.guild.id, userId, today, sdb);
    const streakInfo = getUserStreak(message.guild.id, userId, sdb);

    const now = new Date();
    const midnightUtc = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
    const midnightTimestamp = Math.floor(midnightUtc.getTime() / 1000);

    const typeIcons = {
      chat: '<a:tungsten_chat:1567234399450177665>',
      work: '<a:tungsten_briefcase:1567233568596295821>',
      beg: '<a:tungsten_hands_up:1567240175594250302>',
      fish: '<a:tungsten_ui_water:1569329701409915022>',
      hunt: '<a:tungsten_target:1567242733997789205>',
      daily: '<a:tungsten_gift:1567240042563244072>',
      gamble: '<a:tungsten_slots:1567242206266527956>',
      deposit: '<a:tungsten_bank:1567233290656677924>'
    };

    const questLines = quests.map((q, idx) => {
      const icon = typeIcons[q.type] || '<a:tungsten_quests:1569329552453533827>';
      let statusStr = '<a:tungsten_loading:1567241050567876698> In Progress';
      if (q.completed && q.claimed) {
        statusStr = '<a:tungsten_success:1567242523468890274> Completed';
      } else if (q.completed && !q.claimed) {
        statusStr = '<a:tungsten_gift:1567240042563244072> Claim Ready!';
      }

      const bar = renderProgressBar(q.progress || 0, q.target || 1, 10);
      return (
        `**${idx + 1}. ${icon} ${q.title}** • ${statusStr}\n` +
        `> ${q.desc}\n` +
        `> ${bar}\n` +
        `> **Reward:** +${q.rewardCoins.toLocaleString()} <a:tungsten_coin:1567238316967985244> Coins • +${q.rewardXp} <a:tungsten_bolt:1567233430570405968> XP`
      );
    });

    const allDone = quests.every(q => q.completed);
    let streakText = `<a:tungsten_bolt:1567233430570405968> **Daily Quest Streak:** **${streakInfo.streak}** day(s)`;
    if (allDone) {
      streakText += ' • <a:tungsten_success:1567242523468890274> *All quests completed for today!*';
    } else {
      const nextStreak = (streakInfo.streak || 0) + 1;
      const nextCoins = 500 + (nextStreak * 100);
      const nextXp = 100 + (nextStreak * 25);
      streakText += `\n-# Complete all 3 quests today to reach streak **${nextStreak}** (+${nextCoins} <a:tungsten_coin:1567238316967985244> / +${nextXp} <a:tungsten_bolt:1567233430570405968> XP bonus)!`;
    }

    const embed = createEmbed({
      color: client.config?.COLORS?.PRIMARY || 0x5865f2,
      author: {
        name: `${message.author.username}'s Daily Quests`,
        icon_url: message.author.displayAvatarURL ? message.author.displayAvatarURL({ dynamic: true }) : null
      },
      title: `<a:tungsten_quests:1569329552453533827> Daily Quests (${today})`,
      description:
        `${streakText}\n\n` +
        `${questLines.join('\n\n')}\n\n` +
        `🕒 **Resets:** <t:${midnightTimestamp}:R> (UTC Midnight)`,
      footer: `Tip: Use ${prefix}quests claim if rewards are waiting`
    });

    const hasUnclaimed = quests.some(q => q.completed && !q.claimed);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`quest:claim:${userId}`)
        .setLabel('Claim Rewards')
        .setEmoji('<a:tungsten_gift:1567240042563244072>')
        .setStyle(hasUnclaimed ? ButtonStyle.Success : ButtonStyle.Secondary)
        .setDisabled(!hasUnclaimed && allDone),
      new ButtonBuilder()
        .setCustomId(`quest:refresh:${userId}`)
        .setLabel('Refresh')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Primary)
    );

    return message.reply({
      embeds: [embed],
      components: [row]
    });
  }
};
