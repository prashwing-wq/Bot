/**
 * Tungsten Achievements & Badges Command (Node.js)
 * View badges and achievements, leaderboard, or manage custom guild badges.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createEmbed, hasPerm } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { replaceEmojis } = require('../../utils/emojis');
const {
  BUILTIN_ACHIEVEMENTS,
  checkAndAwardAchievements,
  awardBadge,
  revokeBadge,
  createBadge,
  getUserAchievements,
  getBadgeLeaderboard,
  getGuildBadges
} = require('../../utils/achievementEngine');

const BADGE_EMOJI_FALLBACKS = {
  '\u{1F4AC}': '<a:tungsten_chat:1567234399450177665>',
  '\u{1F949}': '<a:tungsten_medal_bronze:1567241129030582403>',
  '\u{1F947}': '<a:tungsten_medal_gold:1567241163453366472>',
  '\u{1F4B0}': '<a:tungsten_moneybag:1567241334698541109>',
  '\u{1F381}': '<a:tungsten_gift:1567240042563244072>',
  '\u{1F396}\u{FE0F}': '<a:tungsten_achievements:1569329206842757271>',
  '\u{1F396}': '<a:tungsten_achievements:1569329206842757271>',
  '\u{1F91D}': '<a:tungsten_handshake:1567240195646951494>',
  '\u{1F6E1}\u{FE0F}': '<a:tungsten_shield:1567242104923627574>',
  '\u{1F6E1}': '<a:tungsten_shield:1567242104923627574>',
  '\u{1F989}': '<a:tungsten_moon:1567241385021673674>',
  '\u{1F4DC}': '<a:tungsten_scroll:1567242059708899381>',
  '\u{1F3C6}': '<a:tungsten_trophy:1567242918446501939>',
  '\u{2728}': '<a:tungsten_sparkle:1567242264311369839>',
  '\u{1F3F7}\u{FE0F}': '<a:tungsten_tag:1567242698904047691>',
  '\u{1F3F7}': '<a:tungsten_tag:1567242698904047691>',
  '\u{1F3C5}': '<a:tungsten_achievements:1569329206842757271>'
};

function getBadgeEmoji(emoji) {
  if (!emoji) return '<a:tungsten_achievements:1569329206842757271>';
  if (BADGE_EMOJI_FALLBACKS[emoji]) return BADGE_EMOJI_FALLBACKS[emoji];
  const replaced = replaceEmojis(null, emoji);
  if (/[\u{1F000}-\u{1FAFF}\u{2000}-\u{2BFF}]/u.test(replaced)) {
    return '<a:tungsten_achievements:1569329206842757271>';
  }
  return replaced || '<a:tungsten_achievements:1569329206842757271>';
}

module.exports = {
  name: 'achievements',
  category: 'economy',
  description: 'View earned achievements & badges, view leaderboard, or manage custom server badges.',
  usage: '[@user] | leaderboard | create <name> <emoji> <desc> | award <@user> <badge> | revoke <@user> <badge>',
  aliases: ['achievement', 'badges', 'badge'],
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || '').toLowerCase();

    // 1. Subcommand: Leaderboard
    if (sub === 'leaderboard' || sub === 'lb') {
      const topRows = getBadgeLeaderboard(message.guild.id, sdb, 10);
      if (!topRows || topRows.length === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.INFO || 0x3498db,
              title: '<a:tungsten_trophy:1567242918446501939> Achievement Leaderboard',
              description: 'No members have earned badges or achievements in this server yet! Start chatting and earning achievements today.'
            })
          ]
        });
      }

      const medals = [
        '<a:tungsten_medal_gold:1567241163453366472>',
        '<a:tungsten_medal_silver:1567241205409128649>',
        '<a:tungsten_medal_bronze:1567241129030582403>'
      ];
      const lines = topRows.map((r, i) => {
        const medal = medals[i] || `\`#${i + 1}\``;
        return `${medal} <@${r.user_id}> — **${r.badge_count}** badge${r.badge_count === 1 ? '' : 's'}`;
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`ach:user:${message.author.id}`)
          .setLabel('My Badges')
          .setEmoji('<a:tungsten_achievements:1569329206842757271>')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('ach:lb')
          .setLabel('Refresh')
          .setEmoji('<a:tungsten_refresh:1567241907116187658>')
          .setStyle(ButtonStyle.Secondary)
      );

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.GOLD || 0xf1c40f,
            title: `<a:tungsten_trophy:1567242918446501939> ${message.guild.name} • Badge Leaderboard`,
            description: lines.join('\n\n'),
            footer: 'Top members with the most badges earned'
          })
        ],
        components: [row]
      });
    }

    // 2. Subcommand: Create Badge (Staff Only)
    if (sub === 'create') {
      if (!hasPerm(message.member, 'ManageGuild') && !hasPerm(message.member, 'Administrator')) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.DANGER || 0xe74c3c,
              title: 'Permission Denied',
              description: '<a:tungsten_close:1567234632905138206> You must have `Manage Server` permission to create custom badges.'
            })
          ]
        });
      }

      if (args.length < 4) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.WARNING || 0xf39c12,
              title: 'Usage: Create Badge',
              description: `\`${prefix}badge create <name> <emoji> <description>\`\n\n*Example:* \`${prefix}badge create VIP <a:tungsten_star:1567242331785138238> Exclusive server VIP member\``
            })
          ]
        });
      }

      const badgeName = args[1];
      const badgeEmoji = args[2];
      const badgeDesc = args.slice(3).join(' ');
      const badgeId = badgeName.toLowerCase().replace(/[^a-z0-9_-]/g, '_');

      const res = createBadge(message.guild.id, badgeId, badgeName, badgeEmoji, badgeDesc, sdb);
      if (!res.success) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create badge: ${res.reason}`);
      }

      const displayEmoji = getBadgeEmoji(badgeEmoji);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x2ecc71,
            title: '<a:tungsten_sparkle:1567242264311369839> Custom Badge Created',
            description:
              `Successfully registered guild badge **${displayEmoji} ${badgeName}**!\n\n` +
              `• **ID:** \`${badgeId}\`\n` +
              `• **Emoji:** ${displayEmoji}\n` +
              `• **Description:** ${badgeDesc}\n\n` +
              `Award it to members with \`${prefix}badge award @user ${badgeId}\``
          })
        ]
      });
    }

    // 3. Subcommand: Award Badge (Staff Only)
    if (sub === 'award') {
      if (!hasPerm(message.member, 'ManageGuild') && !hasPerm(message.member, 'Administrator')) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.DANGER || 0xe74c3c,
              title: 'Permission Denied',
              description: '<a:tungsten_close:1567234632905138206> You must have `Manage Server` permission to award badges.'
            })
          ]
        });
      }

      if (args.length < 3) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.WARNING || 0xf39c12,
              title: 'Usage: Award Badge',
              description: `\`${prefix}badge award <@user|id> <badge_name|id>\`\n\n*Example:* \`${prefix}badge award @user VIP\``
            })
          ]
        });
      }

      let targetUser = message.mentions?.users?.first();
      if (!targetUser && args[1]) {
        targetUser = await client.users.fetch(args[1]).catch(() => null);
      }

      if (!targetUser) {
        return message.reply('<a:tungsten_close:1567234632905138206> Member not found. Please mention a valid user or provide their user ID.');
      }

      const badgeQuery = args.slice(2).join(' ');
      const res = awardBadge(message.guild.id, targetUser.id, badgeQuery, sdb);

      if (!res.success) {
        if (res.reason === 'not_found') {
          return message.reply(`<a:tungsten_close:1567234632905138206> Badge \`${badgeQuery}\` not found in this server. Use \`${prefix}badge list\` to see custom badges.`);
        }
        if (res.reason === 'already_has') {
          return message.reply(`<a:tungsten_warn:1567246685082746940> <@${targetUser.id}> already possesses the **${res.badge?.name || badgeQuery}** badge.`);
        }
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to award badge: ${res.reason}`);
      }

      const awardedEmoji = getBadgeEmoji(res.badge?.emoji);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x2ecc71,
            title: '<a:tungsten_achievements:1569329206842757271> Badge Awarded',
            description: `Successfully awarded ${awardedEmoji} **${res.badge.name}** to <@${targetUser.id}>!\n\n> *${res.badge.description}*`
          })
        ]
      });
    }

    // 4. Subcommand: Revoke Badge (Staff Only)
    if (sub === 'revoke') {
      if (!hasPerm(message.member, 'ManageGuild') && !hasPerm(message.member, 'Administrator')) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.DANGER || 0xe74c3c,
              title: 'Permission Denied',
              description: '<a:tungsten_close:1567234632905138206> You must have `Manage Server` permission to revoke badges.'
            })
          ]
        });
      }

      if (args.length < 3) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.WARNING || 0xf39c12,
              title: 'Usage: Revoke Badge',
              description: `\`${prefix}badge revoke <@user|id> <badge_name|id>\`\n\n*Example:* \`${prefix}badge revoke @user VIP\``
            })
          ]
        });
      }

      let targetUser = message.mentions?.users?.first();
      if (!targetUser && args[1]) {
        targetUser = await client.users.fetch(args[1]).catch(() => null);
      }

      if (!targetUser) {
        return message.reply('<a:tungsten_close:1567234632905138206> Member not found. Please mention a valid user or provide their user ID.');
      }

      const badgeQuery = args.slice(2).join(' ');
      const res = revokeBadge(message.guild.id, targetUser.id, badgeQuery, sdb);

      if (!res.success) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> <@${targetUser.id}> does not possess badge \`${badgeQuery}\`.`);
      }

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.WARNING || 0xf39c12,
            title: '<a:tungsten_trash:1567242891276062872> Badge Revoked',
            description: `Successfully removed badge \`${res.badge_id}\` from <@${targetUser.id}>.`
          })
        ]
      });
    }

    // 5. Subcommand: List custom badges
    if (sub === 'list') {
      const customBadges = getGuildBadges(message.guild.id, sdb);
      if (!customBadges || customBadges.length === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.INFO || 0x3498db,
              title: `<a:tungsten_tag:1567242698904047691> ${message.guild.name} • Custom Badges`,
              description: `No custom badges have been created yet.\nStaff can create one with \`${prefix}badge create <name> <emoji> <desc>\``
            })
          ]
        });
      }

      const listLines = customBadges.map(b => `${getBadgeEmoji(b.emoji)} **${b.name}** (\`${b.badge_id}\`)\n-# ${b.description || 'No description provided'}`);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.PRIMARY || 0x5865f2,
            title: `<a:tungsten_tag:1567242698904047691> ${message.guild.name} • Custom Badges (${customBadges.length})`,
            description: listLines.join('\n\n')
          })
        ]
      });
    }

    // 6. Default: View member achievements and badges
    let targetUser = message.mentions?.users?.first();
    if (!targetUser && args[0] && /^\d+$/.test(args[0])) {
      targetUser = await client.users.fetch(args[0]).catch(() => null);
    }
    if (!targetUser) {
      targetUser = message.author;
    }

    const targetMember = message.guild.members.cache.get(targetUser.id) ||
      await message.guild.members.fetch(targetUser.id).catch(() => null);

    // Auto-evaluate built-in achievements for this member
    if (targetMember) {
      checkAndAwardAchievements(message.guild, targetMember, sdb);
    }

    const { earned, locked, totalEarned, totalAvailable } = getUserAchievements(message.guild.id, targetUser.id, sdb);

    let earnedSection = '*No achievements earned yet.*';
    if (earned && earned.length > 0) {
      earnedSection = earned.map(a => {
        const timeStr = a.earned_at ? ` <t:${a.earned_at}:R>` : '';
        const tag = a.isCustom ? ' `[Guild Badge]`' : '';
        return `${getBadgeEmoji(a.emoji)} **${a.name}**${tag}${timeStr}\n-# ${a.description}`;
      }).join('\n\n');
    }

    let lockedSection = '';
    if (locked && locked.length > 0) {
      const lockedNames = locked.map(l => `${getBadgeEmoji(l.emoji)} ${l.name}`).join(' • ');
      lockedSection = `\n\n<a:tungsten_lock:1567241079030550668> **Locked Achievements (${locked.length}):**\n-# ${lockedNames}`;
    }

    const embed = createEmbed({
      color: client.config?.COLORS?.PRIMARY || 0x5865f2,
      author: {
        name: `${targetUser.username}'s Achievements & Badges`,
        icon_url: targetUser.displayAvatarURL ? targetUser.displayAvatarURL({ dynamic: true }) : null
      },
      title: `<a:tungsten_achievements:1569329206842757271> Badges Earned: ${totalEarned} / ${totalAvailable}`,
      description: `${earnedSection}${lockedSection}`,
      footer: `Server: ${message.guild.name} • Use ${prefix}achievements leaderboard for top rankings`
    });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('ach:lb')
        .setLabel('Leaderboard')
        .setEmoji('<a:tungsten_trophy:1567242918446501939>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`ach:refresh:${targetUser.id}`)
        .setLabel('Refresh')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Primary)
    );

    return message.reply({
      embeds: [embed],
      components: [row]
    });
  }
};
