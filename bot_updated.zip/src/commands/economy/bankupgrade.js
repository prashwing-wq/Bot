const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { getBalance, debitWallet } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'bankupgrade',
  aliases: ['upgradebank', 'banksize', 'expandbank'],
  category: 'economy',
  description: 'Upgrade your maximum bank vault capacity to store more credits',
  usage: '[info | buy]',
  cooldown: 5,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare('SELECT bank_capacity FROM eco_user_stats WHERE guild_id = ? AND user_id = ?')
      .get(message.guild.id, message.author.id);

    const currentCap = row?.bank_capacity || 50000;
    const upgradeCost = Math.round(currentCap * 0.40); // 40% of current capacity as cost
    const nextCap = currentCap + 50000;

    const sub = (args[0] || 'info').toLowerCase();

    if (sub === 'buy' || sub === 'upgrade') {
      const bal = getBalance(sdb, message.author.id);
      if (bal.wallet < upgradeCost) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You need **${upgradeCost.toLocaleString()} credits** in your wallet to upgrade your bank capacity.`);
      }

      debitWallet(sdb, message.author.id, upgradeCost);

      sdb.prepare(`
        INSERT INTO eco_user_stats (guild_id, user_id, bank_capacity)
        VALUES (?, ?, ?)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET bank_capacity = ?
      `).run(message.guild.id, message.author.id, nextCap, nextCap);

      const embed = createEmbed({
        title: '🏦 Bank Vault Expanded!',
        description: `Successfully upgraded your vault capacity!\n\n` +
          `• **Previous Capacity:** ${currentCap.toLocaleString()} credits\n` +
          `• **New Vault Capacity:** **${nextCap.toLocaleString()} credits**\n` +
          `• **Cost Deducted:** ${upgradeCost.toLocaleString()} credits`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    const embed = createEmbed({
      title: '🏦 Tungsten National Vault Services',
      description: `Current Vault Capacity: **${currentCap.toLocaleString()} credits**\n\n` +
        `• **Next Tier:** **+50,000 credits** (Total: ${nextCap.toLocaleString()}c)\n` +
        `• **Upgrade Fee:** **${upgradeCost.toLocaleString()} credits**\n\n` +
        `*To purchase the vault expansion, run:* \`${prefix}bankupgrade buy\``,
      color: 0x5865F2
    });
    return message.reply({ embeds: [embed] });
  }
};
