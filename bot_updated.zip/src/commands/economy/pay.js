/**
 * Pay Command (Node.js)
 * Atomic transfer of cash between member wallets.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { transfer, getBalance } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'pay',
  description: 'Transfer cash from your wallet to another member.',
  category: 'economy',
  usage: 'pay <@member|id> <amount>',
  aliases: ['transfer', 'givemoney'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (args.length < 2) {
      return message.reply(`Usage: \`${prefix}pay <@member|id> <amount>\``);
    }

    const recipient = message.mentions?.members?.first() ||
      await message.guild.members.fetch(args[0]).catch(() => null);

    if (!recipient) return message.reply('Recipient member not found.');
    if (recipient.id === message.author.id) return message.reply('You cannot pay yourself.');
    if (recipient.user.bot) return message.reply('You cannot transfer money to bot accounts.');

    const amount = parseInt(args[1], 10);
    if (isNaN(amount) || amount <= 0) {
      return message.reply('Please specify a valid amount of cash to send.');
    }

    const sdb = getServerDb(message.guild.id);
    const res = transfer(sdb, message.author.id, recipient.id, amount);
    if (!res.success) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Payment failed: ${res.reason}.`);
    }

    const remainingWallet = getBalance(sdb, message.author.id).wallet;
    const recipientName = recipient.user.username || recipient.displayName || 'Member';

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '💸 Payment Sent',
          description: `Transferred **$${amount.toLocaleString()}** to **${recipientName}**.\n` +
            `Your remaining wallet balance: **$${remainingWallet.toLocaleString()}**.`
        })
      ]
    });
  }
};
