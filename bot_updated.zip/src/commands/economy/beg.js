/**
 * Beg Command (Node.js)
 * Beg for pocket change from generous server citizens with atomic balance updates.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');

const BEG_COOLDOWN_SEC = 45;

const DONORS = [
  'A kind stranger',
  'A wealthy investor',
  'A generous server regular',
  'A passing tourist',
  'A friendly barista',
  'A benevolent moderator',
  'Elon Musk'
];

const REJECTIONS = [
  'Stop begging and get a real job!',
  'I only have lint in my pockets today, sorry.',
  'Get lost before I call the mods!',
  'I just lost all my cash on crypto, nothing for you.',
  'Sorry, I already donated to someone else today.'
];

module.exports = {
  name: 'beg',
  aliases: [],
  category: 'economy',
  description: 'Beg for pocket change from generous passersby.',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  usage: '',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sdb = getServerDb(message.guild.id);
    const now = Math.floor(Date.now() / 1000);

    try {
      sdb.prepare('ALTER TABLE economy_users ADD COLUMN last_beg INTEGER DEFAULT 0').run();
    } catch (e) {}

    // Ensure user row exists and check cooldown
    let userRow = sdb.prepare('SELECT wallet, last_beg FROM economy_users WHERE user_id = ?').get(message.author.id);
    let lastBeg = userRow?.last_beg || 0;

    if (lastBeg && (now - lastBeg < BEG_COOLDOWN_SEC)) {
      const wait = BEG_COOLDOWN_SEC - (now - lastBeg);
      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.WARNING || 0xf1c40f,
            title: '<a:tungsten_loading:1567241050567876698> Begging Cooldown',
            description: `You must wait **${wait}s** before begging again!`
          })
        ]
      });
    }

    // 20% chance of rejection
    const isSuccess = Math.random() > 0.20;

    if (!isSuccess) {
      const reason = REJECTIONS[Math.floor(Math.random() * REJECTIONS.length)];
      try {
        sdb.prepare(`
          INSERT INTO economy_users (user_id, wallet, bank, last_beg)
          VALUES (?, 0, 0, ?)
          ON CONFLICT(user_id) DO UPDATE SET last_beg = ?
        `).run(message.author.id, now, now);
      } catch (e) {}

      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.DANGER || 0xED4245,
            title: '🥺 Begging Failed',
            description: `> "${reason}"\n\nYou received **$0**.`
          })
        ]
      });
    }

    const earned = Math.floor(Math.random() * 70) + 15; // $15 - $84
    const donor = DONORS[Math.floor(Math.random() * DONORS.length)];

    try {
      sdb.prepare(`
        INSERT INTO economy_users (user_id, wallet, bank, last_beg)
        VALUES (?, ?, 0, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          wallet = wallet + ?,
          last_beg = ?
      `).run(message.author.id, earned, now, earned, now);
    } catch (e) {
      // If last_beg column was missing, add it and retry
      try {
        sdb.prepare('ALTER TABLE economy_users ADD COLUMN last_beg INTEGER DEFAULT 0').run();
        sdb.prepare(`
          INSERT INTO economy_users (user_id, wallet, bank, last_beg)
          VALUES (?, ?, 0, ?)
          ON CONFLICT(user_id) DO UPDATE SET
            wallet = wallet + ?,
            last_beg = ?
        `).run(message.author.id, earned, now, earned, now);
      } catch (err) {}
    }

    const updatedRow = sdb.prepare('SELECT wallet FROM economy_users WHERE user_id = ?').get(message.author.id);

    try {
      const { recordQuestProgress } = require('../../utils/questEngine');
      recordQuestProgress(message.guild.id, message.author.id, 'beg', 1, sdb);
    } catch (_) {}

    return message.reply({
      embeds: [
        createEmbed({
          color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
          title: '🪙 Generous Donation!',
          description: `**${donor}** took pity on you and gave you **$${earned}**!\nYour new wallet balance is **$${updatedRow ? updatedRow.wallet.toLocaleString() : earned}**.`
        })
      ]
    });
  }
};
