/**
 * Balance Command (Prefix & Slash)
 * Checks wallet and bank balances from server.db
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');

function buildBalancePayload(target, guild, client) {
  const sdb = getServerDb(guild.id);
  const row = sdb.prepare('SELECT wallet, bank FROM economy_users WHERE user_id = ?').get(target.id) || {
    wallet: 0,
    bank: 0
  };

  const total = row.wallet + row.bank;
  const user = target.user || target;

  const embed = createEmbed({
    color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
    title: `💰 ${user ? user.tag || user.username : 'Member'}'s Finances`,
    thumbnail: (user && typeof user.displayAvatarURL === 'function') ? user.displayAvatarURL({ dynamic: true }) : null,
    fields: [
      { name: '💵 Wallet', value: `\`$${row.wallet.toLocaleString()}\``, inline: true },
      { name: '🏦 Bank', value: `\`$${row.bank.toLocaleString()}\``, inline: true },
      { name: '💎 Net Worth', value: `\`$${total.toLocaleString()}\``, inline: true }
    ],
    footer: `Economy Bank of ${guild.name}`
  });

  return { embeds: [embed] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'balance',
  description: 'Check your or another member\'s wallet and bank balance.',
  category: 'economy',
  usage: 'balance [@member|id]',
  aliases: ['bal', 'money'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const target = message.mentions?.members?.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : message.member);

    if (!target) return message.reply('Member not found.');

    const payload = buildBalancePayload(target, message.guild, client);
    return message.reply(payload);
  },

  buildBalancePayload
};
