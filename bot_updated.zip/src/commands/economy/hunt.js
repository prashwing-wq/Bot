const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { creditWallet, getBalance } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

const TARGETS = [
  { item: 'Missed Shot (Nothing)', value: 0, rarity: 'Miss 💨', weight: 30 },
  { item: 'Wild Rabbit', value: 160, rarity: 'Common 🐇', weight: 38 },
  { item: 'Forest White-Tailed Deer', value: 450, rarity: 'Uncommon 🦌', weight: 22 },
  { item: 'Wild Grizzly Bear', value: 1800, rarity: 'Rare 🐻', weight: 8 },
  { item: 'Ancient Tungsten Dragon', value: 8500, rarity: 'Mythic 🐉', weight: 2 }
];

function getRandomHunt() {
  const rand = Math.random() * 100;
  let cumulative = 0;
  for (const t of TARGETS) {
    cumulative += t.weight;
    if (rand <= cumulative) return t;
  }
  return TARGETS[0];
}

module.exports = {
  name: 'hunt',
  aliases: ['hunting'],
  category: 'economy',
  description: 'Venture into the wilderness to hunt wild animals and claim bounties',
  usage: '',
  cooldown: 25,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const loot = getRandomHunt();

    if (loot.value > 0) {
      creditWallet(sdb, message.author.id, loot.value);
    }
    const bal = getBalance(sdb, message.author.id);

    const embed = createEmbed({
      title: '🏹 Hunting Expedition Results',
      description: `> You trekked into the forest and bagged a **${loot.item}**!\n\n` +
        `• **Rarity:** ${loot.rarity}\n` +
        `• **Bounty Claimed:** **+${loot.value.toLocaleString()} credits**\n\n` +
        `**Wallet Balance:** **${bal.wallet.toLocaleString()}c**`,
      color: loot.value > 1500 ? 0xFEE75C : 0x57F287
    });

    return message.reply({ embeds: [embed] });
  }
};
