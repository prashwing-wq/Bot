const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { getBalance, creditWallet, debitWallet } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'loan',
  aliases: ['bankloan', 'takecredit'],
  category: 'economy',
  description: 'Take a low-interest bank loan or repay an outstanding loan',
  usage: '<take <amount> | repay <amount> | status>',
  cooldown: 5,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'status').toLowerCase();

    const existing = sdb.prepare('SELECT amount, due_date, interest_rate FROM eco_loans WHERE guild_id = ? AND user_id = ?')
      .get(message.guild.id, message.author.id);

    if (sub === 'take' || sub === 'borrow') {
      if (existing && existing.amount > 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You already have an active loan of **${existing.amount.toLocaleString()} credits**. Repay it first via \`${prefix}loan repay\`.`);
      }

      const amount = parseInt(args[1], 10);
      if (isNaN(amount) || amount <= 0 || amount > 100000) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid loan amount between **1** and **100,000 credits**.`);
      }

      const dueDate = Math.floor(Date.now() / 1000) + (7 * 86400); // 7 days
      const totalRepay = Math.round(amount * 1.05); // 5% interest

      sdb.prepare(`
        INSERT INTO eco_loans (guild_id, user_id, amount, due_date, interest_rate)
        VALUES (?, ?, ?, ?, 0.05)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET
          amount = excluded.amount,
          due_date = excluded.due_date
      `).run(message.guild.id, message.author.id, totalRepay, dueDate);

      creditWallet(sdb, message.author.id, amount);

      const embed = createEmbed({
        title: '🏦 Loan Approved & Disbursed',
        description: `Successfully disbursed **${amount.toLocaleString()} credits** to your wallet!\n\n` +
          `• **Principal Borrowed:** ${amount.toLocaleString()} credits\n` +
          `• **Interest Rate:** 5%\n` +
          `• **Total Due:** **${totalRepay.toLocaleString()} credits**\n` +
          `• **Due Date:** <t:${dueDate}:F> (<t:${dueDate}:R>)\n\n` +
          `*Repay anytime using:* \`${prefix}loan repay <amount>\``,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'repay' || sub === 'pay') {
      if (!existing || existing.amount <= 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> You do not have any active loans to repay.');
      }

      const bal = getBalance(sdb, message.author.id);
      const toPay = args[1]?.toLowerCase() === 'all' || isNaN(parseInt(args[1], 10))
        ? Math.min(bal.wallet, existing.amount)
        : Math.min(parseInt(args[1], 10), existing.amount);

      if (toPay <= 0) {
        return message.reply('<a:tungsten_close:1567234632905138206> Specify a positive repayment amount.');
      }
      if (bal.wallet < toPay) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You need **${toPay.toLocaleString()} credits** in your wallet to make this payment.`);
      }

      debitWallet(sdb, message.author.id, toPay);
      const remaining = existing.amount - toPay;

      if (remaining <= 0) {
        sdb.prepare('DELETE FROM eco_loans WHERE guild_id = ? AND user_id = ?').run(message.guild.id, message.author.id);
      } else {
        sdb.prepare('UPDATE eco_loans SET amount = ? WHERE guild_id = ? AND user_id = ?')
          .run(remaining, message.guild.id, message.author.id);
      }

      const embed = createEmbed({
        title: '🏦 Loan Payment Processed',
        description: `Paid **${toPay.toLocaleString()} credits** towards your loan.\n\n` +
          `**Remaining Balance:** **${remaining <= 0 ? '0 credits (Fully Repaid! 🎉)' : `${remaining.toLocaleString()} credits`}**`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (!existing || existing.amount <= 0) {
      return message.reply(`<a:tungsten_info:1567240890748248084> You have no active loans. Borrow up to **100,000c** via \`${prefix}loan take <amount>\`.`);
    }

    const embed = createEmbed({
      title: `🏦 Loan Statement — ${message.author.username}`,
      fields: [
        { name: '💵 Outstanding Debt', value: `**${existing.amount.toLocaleString()} credits**`, inline: true },
        { name: '📅 Due Date', value: `<t:${existing.due_date}:R>`, inline: true }
      ],
      color: 0xFEE75C,
      footer: { text: `Repay using ${prefix}loan repay` }
    });
    return message.reply({ embeds: [embed] });
  }
};
