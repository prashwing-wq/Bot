/**
 * Casino Slots Gambling Command (Node.js)
 * High-performance 88% RTP slot machine with atomic SQLite balance execution.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { playSlots } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'slots',
  aliases: ['gamble', 'slot'],
  category: 'economy',
  description: 'Test your luck on the casino slot machine.',
  usage: '<bet_amount>',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const bet = parseInt(args[0], 10);
    if (isNaN(bet) || bet <= 0) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Please enter a valid bet amount: \`${prefix}slots 100\``);
    }

    const db = getServerDb(message.guild.id);
    const result = playSlots(db, message.author.id, bet);

    if (!result.success) {
      return message.reply(`<a:tungsten_close:1567234632905138206> ${result.reason}`);
    }

    const embed = createEmbed({
      color: result.winnings > bet ? 0x00FF88 : (result.winnings === bet ? 0xFEE75C : 0xFF3B30),
      title: '🎰  Tungsten Casino Slots',
      description:
        `> **Spinning the Reels...**\n\n` +
        `╔════════════╗\n` +
        `║  ${result.r1}  │  ${result.r2}  │  ${result.r3}  ║\n` +
        `╚════════════╝\n\n` +
        `${result.resultText}\n\n` +
        `**Wallet Balance:** **$${result.finalBal.toLocaleString()}**`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
