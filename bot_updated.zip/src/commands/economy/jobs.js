const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { creditWallet } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

const JOBS = {
  dishwasher: { id: 'dishwasher', title: 'Restaurant Dishwasher', salary: 600, reqWork: 0 },
  cashier: { id: 'cashier', title: 'Supermarket Cashier', salary: 1400, reqWork: 5 },
  developer: { id: 'developer', title: 'Fullstack Software Engineer', salary: 3500, reqWork: 15 },
  manager: { id: 'manager', title: 'Regional Operations Manager', salary: 7500, reqWork: 30 },
  ceo: { id: 'ceo', title: 'Corporate Chief Executive Officer', salary: 20000, reqWork: 60 }
};

module.exports = {
  name: 'jobs',
  aliases: ['job', 'career', 'careers'],
  category: 'economy',
  description: 'View career opportunities, apply for promotions, or work at your job',
  usage: '<list | apply <job_id> | info | quit>',
  cooldown: 5,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'info').toLowerCase();

    if (sub === 'list' || sub === 'openings') {
      const lines = Object.values(JOBS).map(j =>
        `• **${j.title}** (\`${j.id}\`)\n  Salary: **${j.salary.toLocaleString()}c/shift** | Minimum Shifts Required: **${j.reqWork}**`
      );

      const embed = createEmbed({
        title: '💼 Tungsten Career Center',
        description: lines.join('\n\n') + `\n\n• **Apply:** \`${prefix}jobs apply <job_id>\`\n• **My Career:** \`${prefix}jobs info\`\n• **Shift Work:** \`${prefix}work\``,
        color: 0x5865F2
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'apply') {
      const jobId = args[1]?.toLowerCase();
      const job = JOBS[jobId];
      if (!job) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Unknown career. Available: \`${Object.keys(JOBS).join(', ')}\``);
      }

      const current = sdb.prepare('SELECT job_id, level FROM eco_jobs WHERE guild_id = ? AND user_id = ?')
        .get(message.guild.id, message.author.id);

      const shiftsCompleted = current?.level || 0;
      if (shiftsCompleted < job.reqWork) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You need at least **${job.reqWork} completed work shifts** to apply for **${job.title}** (You have **${shiftsCompleted}**). Keep using \`${prefix}work\`!`);
      }

      sdb.prepare(`
        INSERT INTO eco_jobs (guild_id, user_id, job_id, salary, level, last_worked)
        VALUES (?, ?, ?, ?, ?, 0)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET
          job_id = excluded.job_id,
          salary = excluded.salary
      `).run(message.guild.id, message.author.id, job.id, job.salary, shiftsCompleted);

      const embed = createEmbed({
        title: '🎉 Career Promotion Accepted!',
        description: `Congratulations! You have been hired as a **${job.title}**!\n` +
          `Your new salary is **${job.salary.toLocaleString()} credits** per completed work shift. Clock in via \`${prefix}work\`.`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'info' || sub === 'current') {
      const current = sdb.prepare('SELECT job_id, salary, level, last_worked FROM eco_jobs WHERE guild_id = ? AND user_id = ?')
        .get(message.guild.id, message.author.id);

      if (!current) {
        return message.reply(`<a:tungsten_info:1567240890748248084> You are currently unemployed. Browse job openings via \`${prefix}jobs list\` and apply with \`${prefix}jobs apply <job_id>\`.`);
      }

      const job = JOBS[current.job_id] || { title: 'Entry Contractor', salary: current.salary };
      const embed = createEmbed({
        title: `👔 Career Profile — ${message.author.username}`,
        thumbnail: { url: message.author.displayAvatarURL() },
        fields: [
          { name: '💼 Position', value: `**${job.title}**`, inline: true },
          { name: '💵 Salary', value: `**${current.salary.toLocaleString()}c** / shift`, inline: true },
          { name: '📈 Total Shifts', value: `\`${current.level}\` shifts`, inline: true }
        ],
        color: 0x5865F2,
        footer: { text: `Run ${prefix}work to clock in and earn your salary` }
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'quit' || sub === 'resign') {
      sdb.prepare('DELETE FROM eco_jobs WHERE guild_id = ? AND user_id = ?').run(message.guild.id, message.author.id);
      return message.reply('🚪 You have resigned from your current job.');
    }

    return message.reply(`Usage: \`${prefix}jobs <list | apply <job_id> | info | quit>\``);
  }
};
