/**
 * Tungsten Badge Command (Node.js)
 * Convenience alias for creating, awarding, revoking, and listing server badges.
 */
const achievements = require('./achievements');

module.exports = {
  name: 'badge',
  category: 'economy',
  description: 'Create, award, revoke, or list custom server badges.',
  usage: 'create <name> <emoji> <desc> | award <@user> <badge> | revoke <@user> <badge> | list',
  aliases: [],
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    // If no args provided, default to listing badges or user's badges
    if (!args || args.length === 0) {
      return achievements.execute(message, ['list'], client, prefix);
    }
    return achievements.execute(message, args, client, prefix);
  }
};
