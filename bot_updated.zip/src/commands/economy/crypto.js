const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { getBalance, debitWallet, creditWallet } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

const COINS = {
  BTC: { name: 'Bitcoin', base: 45000.0 },
  ETH: { name: 'Ethereum', base: 2800.0 },
  SOL: { name: 'Solana', base: 140.0 },
  DOGE: { name: 'Dogecoin', base: 0.15 }
};

function getCryptoPrice(symbol) {
  const coin = COINS[symbol.toUpperCase()];
  if (!coin) return null;
  const hour = Math.floor(Date.now() / 1800000); // 30-min volatility
  const hash = Math.cos(hour * 4242 + coin.base) * 10000;
  const factor = 1 + (((hash - Math.floor(hash)) * 0.40) - 0.20);
  const current = Math.max(0.01, Math.round(coin.base * factor * 100) / 100);
  const change = Math.round(((current - coin.base) / coin.base) * 10000) / 100;
  return { ...coin, symbol: symbol.toUpperCase(), price: current, change };
}

module.exports = {
  name: 'crypto',
  aliases: ['btc', 'eth', 'cryptomarket', 'cryptowallet'],
  category: 'economy',
  description: 'Trade cryptocurrency with simulated live market volatility',
  usage: '<prices | buy <coin> <amount> | sell <coin> <amount> | wallet>',
  cooldown: 3,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'prices').toLowerCase();

    if (sub === 'prices' || sub === 'list') {
      const lines = Object.keys(COINS).map(sym => {
        const data = getCryptoPrice(sym);
        const icon = data.change >= 0 ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>';
        const sign = data.change >= 0 ? '+' : '';
        return `• **${data.symbol}** (${data.name}): **${data.price}c** | ${icon} \`${sign}${data.change}%\``;
      });

      const embed = createEmbed({
        title: '<a:tungsten_bolt:1567233430570405968> Tungsten Crypto Exchange',
        description: lines.join('\n') + `\n\n• **Buy:** \`${prefix}crypto buy <coin> <amount>\`\n• **Sell:** \`${prefix}crypto sell <coin> <amount>\`\n• **Wallet:** \`${prefix}crypto wallet\``,
        color: 0xFEE75C,
        footer: { text: 'High-volatility 30-minute market cycle' }
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const sym = args[1]?.toUpperCase();
      const amount = parseFloat(args[2]);

      const coin = getCryptoPrice(sym);
      if (!coin) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Unknown coin. Available: \`${Object.keys(COINS).join(', ')}\``);
      }
      if (isNaN(amount) || amount <= 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid amount to buy. Usage: \`${prefix}crypto buy ${sym} 1.5\``);
      }

      const totalCost = Math.round(coin.price * amount);
      const bal = getBalance(sdb, message.author.id);

      if (bal.wallet < totalCost) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You need **${totalCost.toLocaleString()} credits** to buy **${amount} ${sym}**.`);
      }

      debitWallet(sdb, message.author.id, totalCost);

      const existing = sdb.prepare('SELECT shares, avg_buy_price FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND symbol = ?')
        .get(message.guild.id, message.author.id, `C_${sym}`);

      if (existing) {
        const total = existing.shares + amount;
        sdb.prepare('UPDATE eco_user_stocks SET shares = ? WHERE guild_id = ? AND user_id = ? AND symbol = ?')
          .run(total, message.guild.id, message.author.id, `C_${sym}`);
      } else {
        sdb.prepare('INSERT INTO eco_user_stocks (guild_id, user_id, symbol, shares, avg_buy_price) VALUES (?, ?, ?, ?, ?)')
          .run(message.guild.id, message.author.id, `C_${sym}`, amount, coin.price);
      }

      const embed = createEmbed({
        title: '<a:tungsten_bolt:1567233430570405968> Crypto Purchase Successful',
        description: `Purchased **${amount} ${sym}** for **${totalCost.toLocaleString()}c**.`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'sell') {
      const sym = args[1]?.toUpperCase();
      const amount = parseFloat(args[2]);

      const coin = getCryptoPrice(sym);
      if (!coin) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Unknown coin. Available: \`${Object.keys(COINS).join(', ')}\``);
      }

      const row = sdb.prepare('SELECT shares FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND symbol = ?')
        .get(message.guild.id, message.author.id, `C_${sym}`);

      if (!row || row.shares <= 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> You do not own any **${sym}**.`);
      }

      const toSell = isNaN(amount) || amount <= 0 ? row.shares : Math.min(amount, row.shares);
      const earned = Math.round(coin.price * toSell);

      if (toSell >= row.shares) {
        sdb.prepare('DELETE FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND symbol = ?')
          .run(message.guild.id, message.author.id, `C_${sym}`);
      } else {
        sdb.prepare('UPDATE eco_user_stocks SET shares = shares - ? WHERE guild_id = ? AND user_id = ? AND symbol = ?')
          .run(toSell, message.guild.id, message.author.id, `C_${sym}`);
      }

      creditWallet(sdb, message.author.id, earned);

      const embed = createEmbed({
        title: '<a:tungsten_bolt:1567233430570405968> Crypto Sold',
        description: `Sold **${toSell} ${sym}** for **${earned.toLocaleString()}c**.`,
        color: 0x57F287
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'wallet') {
      const rows = sdb.prepare("SELECT symbol, shares FROM eco_user_stocks WHERE guild_id = ? AND user_id = ? AND symbol LIKE 'C_%' AND shares > 0")
        .all(message.guild.id, message.author.id);

      if (!rows || rows.length === 0) {
        return message.reply(`<a:tungsten_info:1567240890748248084> Your crypto wallet is currently empty. View coins with \`${prefix}crypto\`.`);
      }

      let totalVal = 0;
      const lines = rows.map(r => {
        const sym = r.symbol.replace('C_', '');
        const live = getCryptoPrice(sym);
        const val = Math.round(live.price * r.shares);
        totalVal += val;
        return `• **${sym}**: **${r.shares}** | Value: **${val.toLocaleString()} credits**`;
      });

      const embed = createEmbed({
        title: `<a:tungsten_coin:1567238316967985244> Crypto Wallet — ${message.author.username}`,
        description: lines.join('\n') + `\n\n• **Total Portfolio Value:** **${totalVal.toLocaleString()} credits**`,
        color: 0xFEE75C
      });
      return message.reply({ embeds: [embed] });
    }

    return message.reply(`Usage: \`${prefix}crypto <prices | buy <coin> <amount> | sell <coin> <amount> | wallet>\``);
  }
};
