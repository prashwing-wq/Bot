/**
 * Withdraw Command (Node.js)
 * Withdraw funds from your bank vault into your wallet.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { withdraw, getBalance } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'withdraw',
  description: 'Withdraw funds from your bank vault into your wallet.',
  category: 'economy',
  usage: 'withdraw <amount|all>',
  aliases: ['with'],
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!args[0]) {
      return message.reply(`Usage: \`${prefix}withdraw <amount|all>\``);
    }

    const sdb = getServerDb(message.guild.id);
    const current = getBalance(sdb, message.author.id);

    let amount = 0;
    if (args[0].toLowerCase() === 'all' || args[0].toLowerCase() === 'max') {
      amount = current.bank;
    } else {
      amount = parseInt(args[0], 10);
    }

    if (isNaN(amount) || amount <= 0) {
      return message.reply('Please specify a positive amount of coins to withdraw.');
    }

    const res = withdraw(sdb, message.author.id, amount);
    if (!res.success) {
      return message.reply(`Withdrawal failed: ${res.reason}. Current bank balance: **$${current.bank.toLocaleString()}**.`);
    }

    const updated = getBalance(sdb, message.author.id);

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '🏧 Bank Withdrawal Completed',
          description: `Successfully withdrew **$${amount.toLocaleString()}** from your bank vault.\n\n` +
            `• **New Wallet Balance:** **$${updated.wallet.toLocaleString()}**\n` +
            `• **Remaining Bank:** **$${updated.bank.toLocaleString()}**`
        })
      ]
    });
  }
};
