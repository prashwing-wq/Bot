/**
 * Economy Buy Command (Prefix)
 * Purchase shop items, roles, or consumables atomically.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { buyItem } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'buy',
  aliases: ['purchase'],
  category: 'economy',
  description: 'Purchase an item, role, or consumable from the economy shop.',
  usage: 'buy <item_id> [quantity]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const itemId = args[0]?.toLowerCase();
    const quantity = parseInt(args[1], 10) || 1;

    if (!itemId) {
      return message.reply(`Usage: \`${prefix}buy <item_id> [quantity]\` — View available items with \`${prefix}shop\``);
    }

    if (quantity <= 0) {
      return message.reply('<a:tungsten_close:1567234632905138206> Please specify a valid quantity to purchase (at least 1).');
    }

    const sdb = getServerDb(message.guild.id);
    const res = buyItem(sdb, message.guild.id, message.author.id, itemId, quantity);

    if (!res.success) {
      return message.reply(`<a:tungsten_close:1567234632905138206> ${res.reason}`);
    }

    // Role distribution if item is a role item
    let roleAwardText = '';
    if (res.item.type === 'role' && res.item.role_id) {
      const roleObj = message.guild.roles.cache.get(res.item.role_id)
        || (typeof message.guild.roles.fetch === 'function' ? await message.guild.roles.fetch(res.item.role_id).catch(() => null) : null);
      if (roleObj) {
        await message.member.roles.add(roleObj, 'Purchased from Economy Shop').catch(() => null);
        roleAwardText = `\n🎭 **Role Granted:** <@&${roleObj.id}>`;
      }
    }

    const embed = createEmbed({
      color: 0x00FF88,
      title: '🛍️  Purchase Successful!',
      description:
        `> You successfully purchased **${res.quantity}x ${res.item.name}**!\n\n` +
        `• **Total Cost:** **$${res.totalCost.toLocaleString()}**\n` +
        `• **Item Type:** \`${res.item.type}\`${roleAwardText}\n` +
        `• **Remaining Wallet:** **$${res.remainingWallet.toLocaleString()}**\n\n` +
        `-# Check your items anytime with \`${prefix}inventory\``,
      footer: { text: `Purchased by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
