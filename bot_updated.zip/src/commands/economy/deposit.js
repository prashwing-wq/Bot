/**
 * Deposit Command (Node.js)
 * Deposit funds from your wallet into the secure bank vault.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { deposit, getBalance } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'deposit',
  description: 'Deposit funds from your wallet into the secure bank vault.',
  category: 'economy',
  usage: 'deposit <amount|all>',
  aliases: ['dep'],
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!args[0]) {
      return message.reply(`Usage: \`${prefix}deposit <amount|all>\``);
    }

    const sdb = getServerDb(message.guild.id);
    const current = getBalance(sdb, message.author.id);

    let amount = 0;
    if (args[0].toLowerCase() === 'all' || args[0].toLowerCase() === 'max') {
      amount = current.wallet;
    } else {
      amount = parseInt(args[0], 10);
    }

    if (isNaN(amount) || amount <= 0) {
      return message.reply('Please specify a positive amount of coins to deposit.');
    }

    const res = deposit(sdb, message.author.id, amount);
    if (!res.success) {
      return message.reply(`Deposit failed: ${res.reason}. Current wallet: **$${current.wallet.toLocaleString()}**.`);
    }

    const updated = getBalance(sdb, message.author.id);

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '🏦 Bank Deposit Completed',
          description: `Successfully deposited **$${amount.toLocaleString()}** into your bank vault.\n\n` +
            `• **Remaining Wallet:** **$${updated.wallet.toLocaleString()}**\n` +
            `• **New Bank Balance:** **$${updated.bank.toLocaleString()}**`
        })
      ]
    });
  }
};
