/**
 * Monthly Command (Node.js)
 * Claims monthly loyalty credit stipend with 30-day cooldown.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');

const MONTHLY_REWARD = 25000;
const MONTHLY_COOLDOWN_SEC = 30 * 24 * 60 * 60; // 30 days

module.exports = {
  name: 'monthly',
  aliases: [],
  category: 'economy',
  description: 'Claim your monthly loyalty reward of $25,000.',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  usage: '',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sdb = getServerDb(message.guild.id);
    const now = Math.floor(Date.now() / 1000);

    try {
      sdb.prepare('ALTER TABLE economy_users ADD COLUMN last_monthly INTEGER DEFAULT 0').run();
    } catch (e) {}

    // Check last_monthly column
    let userRow = sdb.prepare('SELECT wallet, last_monthly FROM economy_users WHERE user_id = ?').get(message.author.id);
    let lastMonthly = userRow?.last_monthly || 0;

    if (lastMonthly && (now - lastMonthly < MONTHLY_COOLDOWN_SEC)) {
      const waitSec = MONTHLY_COOLDOWN_SEC - (now - lastMonthly);
      const days = Math.floor(waitSec / 86400);
      const hours = Math.floor((waitSec % 86400) / 3600);

      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.WARNING || 0xf1c40f,
            title: '<a:tungsten_loading:1567241050567876698> Monthly Cooldown Active',
            description: `You have already claimed your monthly reward!\nPlease return in **${days}d ${hours}h**.`
          })
        ]
      });
    }

    try {
      sdb.prepare(`
        INSERT INTO economy_users (user_id, wallet, bank, last_monthly)
        VALUES (?, ?, 0, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          wallet = wallet + ?,
          last_monthly = ?
      `).run(message.author.id, MONTHLY_REWARD, now, MONTHLY_REWARD, now);
    } catch (e) {
      try {
        sdb.prepare('ALTER TABLE economy_users ADD COLUMN last_monthly INTEGER DEFAULT 0').run();
        sdb.prepare(`
          INSERT INTO economy_users (user_id, wallet, bank, last_monthly)
          VALUES (?, ?, 0, ?)
          ON CONFLICT(user_id) DO UPDATE SET
            wallet = wallet + ?,
            last_monthly = ?
        `).run(message.author.id, MONTHLY_REWARD, now, MONTHLY_REWARD, now);
      } catch (err) {}
    }

    const updatedRow = sdb.prepare('SELECT wallet FROM economy_users WHERE user_id = ?').get(message.author.id);

    return message.reply({
      embeds: [
        createEmbed({
          color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
          title: '💎 Monthly Loyalty Reward Claimed!',
          description: `You received your monthly stipend of **$${MONTHLY_REWARD.toLocaleString()}**!\nYour wallet balance is now **$${updatedRow ? updatedRow.wallet.toLocaleString() : MONTHLY_REWARD.toLocaleString()}**.`
        })
      ]
    });
  }
};
