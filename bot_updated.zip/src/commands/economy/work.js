/**
 * Work Economy Command (Node.js)
 * Allows users to work various jobs to earn server economy currency.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { creditWallet, getBalance } = require('../../utils/economy');

const JOBS = [
  "worked as a Discord bot developer",
  "fixed a critical database query bug",
  "worked as a server security moderator",
  "streamed live coding on Twitch",
  "designed a custom high-res logo",
  "delivered pizza to the server staff",
  "mined cryptocurrency on a Raspberry Pi"
];

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'work',
  category: 'economy',
  description: 'Work a random shift to earn credits for your wallet.',
  usage: '',
  cooldown: 30,

  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);

    // Check user career from eco_jobs
    let earnings = Math.floor(Math.random() * 250) + 50; // default base $50 - $300
    let jobDescription = JOBS[Math.floor(Math.random() * JOBS.length)];

    try {
      const career = sdb.prepare('SELECT job_id, salary, level FROM eco_jobs WHERE guild_id = ? AND user_id = ?')
        .get(message.guild.id, message.author.id);

      if (career && career.salary > 0) {
        earnings = career.salary + Math.floor(Math.random() * (career.salary * 0.15));
        jobDescription = `completed a shift as **${career.job_id.toUpperCase()}**`;
        sdb.prepare("UPDATE eco_jobs SET level = level + 1, last_worked = strftime('%s', 'now') WHERE guild_id = ? AND user_id = ?")
          .run(message.guild.id, message.author.id);
      }
    } catch (_) {}

    creditWallet(sdb, message.author.id, earnings);
    const updated = getBalance(sdb, message.author.id);

    try {
      const { recordQuestProgress } = require('../../utils/questEngine');
      recordQuestProgress(message.guild.id, message.author.id, 'work', 1, sdb);
    } catch (_) {}

    const embed = createEmbed({
      color: 0x00FF88,
      title: '💼  Shift Completed',
      description:
        `> You **${jobDescription}** and earned **+$${earnings.toLocaleString()}**!\n\n` +
        `**New Wallet Balance:** **$${updated.wallet.toLocaleString()}**\n\n` +
        `-# Deposit your earnings into the bank using \`${prefix}deposit ${earnings}\``
    });

    return message.reply({ embeds: [embed] });
  }
};
