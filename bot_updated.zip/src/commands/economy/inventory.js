/**
 * Economy Inventory Command (Prefix)
 * View items and consumables owned in your inventory.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { getInventory } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'inventory',
  aliases: ['backpack', 'bag', 'items'],
  category: 'economy',
  description: 'View items and consumables in your inventory.',
  usage: 'inventory [@user]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const target = message.mentions?.users?.first() || (args[0] ? await client.users.fetch(args[0].replace(/[<@!>]/g, '')).catch(() => null) : null) || message.author;

    const sdb = getServerDb(message.guild.id);
    const items = getInventory(sdb, message.guild.id, target.id);

    if (items.length === 0) {
      return message.reply(`🎒 **${target.username}**'s inventory is empty. Browse items using \`${prefix}shop\`!`);
    }

    const list = items.map(i => {
      const icon = i.type === 'role' ? '🎭' : (i.item_id === 'padlock' ? '<a:tungsten_lock:1567241079030550668>' : '📦');
      return `${icon} **${i.name || i.item_id}** — \`${i.item_id}\`\n` +
        `• **Quantity:** \`${i.quantity}x\` • **Type:** \`${i.type || 'item'}\`\n` +
        `• *${i.description || 'No description available.'}*`;
    }).join('\n\n');

    const embed = createEmbed({
      color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
      title: `🎒  Inventory • ${target.username}`,
      description: list,
      footer: { text: `Total Items: ${items.length} • Tungsten Economy Engine` }
    });

    return message.reply({ embeds: [embed] });
  }
};
