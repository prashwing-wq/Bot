const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { creditWallet, getBalance } = require('../../utils/economy');
const { createEmbed } = require('../../utils/tools');

const CATCHES = [
  { item: 'Old Boot / Seaweed', value: 0, rarity: 'Trash <a:tungsten_trash:1567242891276062872>', weight: 30 },
  { item: 'Common Carp', value: 120, rarity: 'Common 🐟', weight: 40 },
  { item: 'Rainbow Trout', value: 350, rarity: 'Uncommon 🐠', weight: 20 },
  { item: 'Golden Bass', value: 1200, rarity: 'Rare 🐡', weight: 8 },
  { item: 'Legendary Kraken Tentacle', value: 6500, rarity: 'Mythic 🐙', weight: 2 }
];

function getRandomCatch() {
  const rand = Math.random() * 100;
  let cumulative = 0;
  for (const c of CATCHES) {
    cumulative += c.weight;
    if (rand <= cumulative) return c;
  }
  return CATCHES[0];
}

module.exports = {
  name: 'fish',
  aliases: ['fishing', 'castrod'],
  category: 'economy',
  description: 'Cast your fishing rod into the river to reel in fish and sell them for credits',
  usage: '',
  cooldown: 20,
  permissions: [],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const loot = getRandomCatch();

    if (loot.value > 0) {
      creditWallet(sdb, message.author.id, loot.value);
    }
    const bal = getBalance(sdb, message.author.id);

    const embed = createEmbed({
      title: '🎣 Fishing Trip Results',
      description: `> You cast your line and reeled in a **${loot.item}**!\n\n` +
        `• **Rarity:** ${loot.rarity}\n` +
        `• **Market Value:** **+${loot.value.toLocaleString()} credits**\n\n` +
        `**Wallet Balance:** **${bal.wallet.toLocaleString()}c**`,
      color: loot.value > 1000 ? 0xFEE75C : 0x5865F2
    });

    return message.reply({ embeds: [embed] });
  }
};
