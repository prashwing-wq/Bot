/**
 * Rob / Steal Economy Command (Node.js)
 * Attempt to rob credits from another member's wallet with risk of getting caught.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { attemptRob, getBalance } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'rob',
  aliases: ['heist', 'mug'],
  category: 'economy',
  description: "Attempt to rob credits from another member's wallet.",
  usage: '<@user>',
  cooldown: 60,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const target = message.mentions?.users?.first() || (args[0] ? await client.users.fetch(args[0].replace(/[<@!>]/g, '')).catch(() => null) : null);
    if (!target) return message.reply(`Usage: \`${prefix}rob <@user>\``);

    if (target.id === message.author.id) {
      return message.reply("<a:tungsten_close:1567234632905138206> You can't rob yourself!");
    }

    if (target.bot) {
      return message.reply("<a:tungsten_close:1567234632905138206> Bots don't carry physical cash in their wallets!");
    }

    const sdb = getServerDb(message.guild.id);
    const now = Math.floor(Date.now() / 1000);
    const ROB_COOLDOWN = 60;
    const userRow = sdb.prepare('SELECT last_rob FROM economy_users WHERE user_id = ?').get(message.author.id);

    if (userRow && userRow.last_rob && (now - userRow.last_rob < ROB_COOLDOWN)) {
      const rem = ROB_COOLDOWN - (now - userRow.last_rob);
      return message.reply(`<a:tungsten_loading:1567241050567876698> You are on robbery cooldown! Please wait **${rem}s** before attempting another heist.`);
    }

    const authorWallet = getBalance(sdb, message.author.id).wallet;
    if (authorWallet < 100) {
      return message.reply(`<a:tungsten_close:1567234632905138206> You need at least **$100** in your wallet to cover the police bail fine if caught!`);
    }

    const res = attemptRob(sdb, message.author.id, target.id, message.guild.id);
    const finalAuthorWallet = getBalance(sdb, message.author.id).wallet;

    if (res.success) {
      const embed = createEmbed({
        color: 0x00FF88,
        title: '🥷  Heist Successful!',
        description:
          `> You successfully sneaked into <@${target.id}>'s pockets and made off with **+$${res.stolen.toLocaleString()}**!\n\n` +
          `**Your Wallet:** **$${finalAuthorWallet.toLocaleString()}**`
      });
      return message.reply({ embeds: [embed] });
    } else {
      const embed = createEmbed({
        color: 0xFF3B30,
        title: res.caught ? '<a:tungsten_siren:1567242157725712555>  Caught by Police!' : '<a:tungsten_close:1567234632905138206>  Heist Failed',
        description:
          `> ${res.reason}\n\n` +
          `**Your Wallet:** **$${finalAuthorWallet.toLocaleString()}**`
      });
      return message.reply({ embeds: [embed] });
    }
  }
};
