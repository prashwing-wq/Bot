/**
 * Daily Command (Prefix & Slash)
 * Claims daily credit reward with 24h cooldown
 */
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');

const DAILY_REWARD = 500;
const COOLDOWN_MS = 24 * 60 * 60 * 1000;

function handleDaily(guild, user, client) {
  const sdb = getServerDb(guild.id);
  const row = sdb.prepare('SELECT wallet, last_daily FROM economy_users WHERE user_id = ?').get(user.id);
  const now = Date.now();

  if (row && row.last_daily) {
    const elapsed = now - row.last_daily;
    if (elapsed < COOLDOWN_MS) {
      const remaining = COOLDOWN_MS - elapsed;
      const hours = Math.floor(remaining / (1000 * 60 * 60));
      const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
      return {
        onCooldown: true,
        embed: createEmbed({
          color: client?.config?.COLORS?.WARNING || 0xf1c40f,
          title: '<a:tungsten_loading:1567241050567876698> Daily Cooldown Active',
          description: `You have already claimed your daily reward!\nPlease return in **${hours}h ${minutes}m**.`
        })
      };
    }
  }

  const currentWallet = row ? row.wallet : 0;
  const newWallet = currentWallet + DAILY_REWARD;

  sdb.prepare(`
    INSERT INTO economy_users (user_id, wallet, last_daily)
    VALUES (?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET wallet = ?, last_daily = ?
  `).run(user.id, newWallet, now, newWallet, now);

  try {
    const { recordQuestProgress } = require('../../utils/questEngine');
    recordQuestProgress(guild.id, user.id, 'daily', 1, sdb);
  } catch (_) {}

  return {
    success: true,
    embed: createEmbed({
      color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
      title: '🎁 Daily Reward Claimed!',
      description: `You received **$${DAILY_REWARD.toLocaleString()}**!\nYour new wallet balance is **$${newWallet.toLocaleString()}**.`
    })
  };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'daily',
  description: 'Claim your daily stipend of $500.',
  category: 'economy',
  usage: 'daily',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');
    const res = handleDaily(message.guild, message.author, client);
    return message.reply({ embeds: [res.embed] });
  },

  handleDaily
};
