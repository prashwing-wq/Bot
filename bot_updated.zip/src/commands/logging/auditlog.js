/**
 * Audit Logging & Dispatch Command (Node.js)
 */
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'auditlog',
  aliases: ['modlog', 'logchannel'],
  category: 'logging',
  description: 'View or set the server moderation and audit logging channel.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  usage: '[#channel | off]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure audit logs.');
    }

    const db = getServerDb(message.guild.id);
    const channel = message.mentions?.channels?.first() || (args[0] ? message.guild.channels.cache.get(args[0]) : null);

    if (args[0] && args[0].toLowerCase() === 'off') {
      db.prepare(`
        INSERT OR REPLACE INTO server_settings (key, value)
        VALUES ('audit_log_channel', '')
      `).run();

      return message.reply('<a:tungsten_success:1567242523468890274> Audit logging channel has been disabled.');
    }

    if (channel) {
      db.prepare(`
        INSERT OR REPLACE INTO server_settings (key, value)
        VALUES ('audit_log_channel', ?)
      `).run(channel.id);

      const embed = createEmbed({
        title: '📜  Audit Logging Channel Configured',
        description:
          `> Audit logging channel successfully bound to ${channel}.\n\n` +
          `• Moderation kicks, bans, unbans, and warns will be recorded here.\n` +
          `• Security alerts & antinuke events will dispatch real-time embeds.\n\n` +
          `-# To disable, type \`${prefix}auditlog off\``
      });
      return message.reply({ embeds: [embed] });
    }

    // View current setting
    const row = db.prepare("SELECT value FROM server_settings WHERE key = 'audit_log_channel'").get();
    const activeChId = row ? row.value : null;

    const embed = createEmbed({
      title: '📜  Audit Logging Configuration',
      description:
        `> Track and record all administrative actions in real-time.\n\n` +
        `**Active Log Channel:** ${activeChId ? `<#${activeChId}>` : '`Not configured (Disabled)`'}\n\n` +
        `**Usage:**\n` +
        `• \`${prefix}auditlog #channel\` — Bind audit logs to a channel\n` +
        `• \`${prefix}auditlog off\` — Disable audit logs`
    });

    return message.reply({ embeds: [embed] });
  }
};
