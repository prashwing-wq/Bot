/**
 * Logs Command (Node.js)
 * Configure dedicated log routing channels for Messages, Members, Voice, Server, and Mod actions.
 * Supports Essential 6-Channel and Comprehensive 22-Channel automated provisioning,
 * full 22-channel matrix inspection, manual channel allocation, and channel cleanup.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const { hasPerm } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { getAllLogSettings } = require('../../utils/logRouter');
const { createV2Card } = require('../../utils/componentsV2');
const { autoProvisionAllLogChannels, deleteAllLogChannels } = require('../../utils/autoLogging');

const TYPE_KEY_MAP = {
  // Master fallback
  master: 'audit_log_channel',
  audit: 'audit_log_channel',
  fallback: 'audit_log_channel',
  audit_log_channel: 'audit_log_channel',

  // Standard legacy aliases
  members: 'log_members',
  member: 'log_members',
  server: 'log_server',
  srv: 'log_server',

  // 1. Mod logs
  'mod-logs': 'log_mod',
  'mod_logs': 'log_mod',
  'mod': 'log_mod',
  'moderation': 'log_mod',
  'log_mod': 'log_mod',

  // 2. Ban logs
  'ban-logs': 'log_bans',
  'ban_logs': 'log_bans',
  'ban': 'log_bans',
  'bans': 'log_bans',
  'unban': 'log_bans',
  'unbans': 'log_bans',
  'log_bans': 'log_bans',

  // 3. Timeout logs
  'timeout-logs': 'log_timeouts',
  'timeout_logs': 'log_timeouts',
  'timeout': 'log_timeouts',
  'timeouts': 'log_timeouts',
  'mute': 'log_timeouts',
  'mutes': 'log_timeouts',
  'log_timeouts': 'log_timeouts',

  // 4. Nickname logs
  'nickname-logs': 'log_nicknames',
  'nickname_logs': 'log_nicknames',
  'nick-logs': 'log_nicknames',
  'nick_logs': 'log_nicknames',
  'nickname': 'log_nicknames',
  'nicknames': 'log_nicknames',
  'nick': 'log_nicknames',
  'nicks': 'log_nicknames',
  'log_nicknames': 'log_nicknames',

  // 5. Message logs
  'message-logs': 'log_messages',
  'message_logs': 'log_messages',
  'messages': 'log_messages',
  'message': 'log_messages',
  'msg': 'log_messages',
  'msgs': 'log_messages',
  'log_messages': 'log_messages',

  // 6. Voice logs
  'voice-logs': 'log_voice',
  'voice_logs': 'log_voice',
  'voice': 'log_voice',
  'vc': 'log_voice',
  'vclogs': 'log_voice',
  'log_voice': 'log_voice',

  // 7. Channel logs
  'channel-logs': 'log_channels',
  'channel_logs': 'log_channels',
  'channels': 'log_channels',
  'channel': 'log_channels',
  'chnl': 'log_channels',
  'log_channels': 'log_channels',

  // 8. Role logs
  'role-logs': 'log_roles',
  'role_logs': 'log_roles',
  'roles': 'log_roles',
  'role': 'log_roles',
  'log_roles': 'log_roles',

  // 9. Emoji logs
  'emoji-logs': 'log_emojis',
  'emoji_logs': 'log_emojis',
  'emojis': 'log_emojis',
  'emoji': 'log_emojis',
  'log_emojis': 'log_emojis',

  // 10. Guild update logs
  'guildupdate-logs': 'log_guildupdate',
  'guildupdate_logs': 'log_guildupdate',
  'guildupdate': 'log_guildupdate',
  'guild-update': 'log_guildupdate',
  'server-logs': 'log_guildupdate',
  'server_logs': 'log_guildupdate',
  'guild': 'log_guildupdate',
  'log_guildupdate': 'log_guildupdate',

  // 11. Security logs
  'security-logs': 'log_security',
  'security_logs': 'log_security',
  'security': 'log_security',
  'sec': 'log_security',
  'antinuke': 'log_security',
  'antinuke-logs': 'log_security',
  'log_security': 'log_security',

  // 12. Bot logs
  'bot-logs': 'log_bots',
  'bot_logs': 'log_bots',
  'bots': 'log_bots',
  'bot': 'log_bots',
  'log_bots': 'log_bots',

  // 13. Webhook logs
  'webhook-logs': 'log_webhooks',
  'webhook_logs': 'log_webhooks',
  'webhooks': 'log_webhooks',
  'webhook': 'log_webhooks',
  'log_webhooks': 'log_webhooks',

  // 14. Secure WL logs
  'secure-wl-logs': 'log_secure_wl',
  'secure_wl_logs': 'log_secure_wl',
  'secure-wl': 'log_secure_wl',
  'secure_wl': 'log_secure_wl',
  'whitelist-logs': 'log_secure_wl',
  'whitelist_logs': 'log_secure_wl',
  'whitelist': 'log_secure_wl',
  'wl': 'log_secure_wl',
  'wl-logs': 'log_secure_wl',
  'log_secure_wl': 'log_secure_wl',

  // 15. Member join logs
  'memberjoin-logs': 'log_memberjoin',
  'memberjoin_logs': 'log_memberjoin',
  'member-join': 'log_memberjoin',
  'memberjoin': 'log_memberjoin',
  'joins': 'log_memberjoin',
  'join': 'log_memberjoin',
  'leaves': 'log_memberjoin',
  'leave': 'log_memberjoin',
  'log_memberjoin': 'log_memberjoin',

  // 16. Invite event logs
  'inviteevent-logs': 'log_invites',
  'inviteevent_logs': 'log_invites',
  'invite-logs': 'log_invites',
  'invite_logs': 'log_invites',
  'inviteevent': 'log_invites',
  'invites': 'log_invites',
  'invite': 'log_invites',
  'log_invites': 'log_invites',

  // 17. Manual logs
  'manual-logs': 'log_manual',
  'manual_logs': 'log_manual',
  'manual': 'log_manual',
  'modnotes': 'log_manual',
  'mod-notes': 'log_manual',
  'notes': 'log_manual',
  'log_manual': 'log_manual',

  // 18. Ticket history logs
  'tickethistory-logs': 'log_tickets',
  'tickethistory_logs': 'log_tickets',
  'ticket-logs': 'log_tickets',
  'ticket_logs': 'log_tickets',
  'tickethistory': 'log_tickets',
  'tickets': 'log_tickets',
  'ticket': 'log_tickets',
  'log_tickets': 'log_tickets',

  // 19. Quarantine logs
  'quarantine-logs': 'log_quarantine',
  'quarantine_logs': 'log_quarantine',
  'quarantine': 'log_quarantine',
  'isolation': 'log_quarantine',
  'log_quarantine': 'log_quarantine',

  // 20. Thread logs
  'thread-logs': 'log_threads',
  'thread_logs': 'log_threads',
  'threads': 'log_threads',
  'thread': 'log_threads',
  'log_threads': 'log_threads',

  // 21. Sticker logs
  'sticker-logs': 'log_stickers',
  'sticker_logs': 'log_stickers',
  'stickers': 'log_stickers',
  'sticker': 'log_stickers',
  'log_stickers': 'log_stickers',

  // 22. Scheduled event logs
  'scheduled-event-logs': 'log_scheduled_events',
  'scheduled_event_logs': 'log_scheduled_events',
  'scheduled-events': 'log_scheduled_events',
  'scheduled_events': 'log_scheduled_events',
  'events': 'log_scheduled_events',
  'event': 'log_scheduled_events',
  'log_scheduled_events': 'log_scheduled_events'
};

const LOG_CATEGORY_OPTIONS = [
  { label: 'Master Fallback Channel', value: 'audit_log_channel', emoji: '📜', description: 'Default fallback for all unset log types' },
  { label: 'Moderation (Bans, Kicks, Warns)', value: 'log_mod', emoji: '🛡️', description: 'Disciplinary actions and mod case sentinel' },
  { label: 'Bans & Unbans', value: 'log_bans', emoji: '🔨', description: 'Server ban and unban events' },
  { label: 'Timeouts & Mutes', value: 'log_timeouts', emoji: '⏳', description: 'Member communication restraints' },
  { label: 'Nicknames & Identity', value: 'log_nicknames', emoji: '🏷️', description: 'Display name and nickname changes' },
  { label: 'Messages (Edits, Deletes, Purges)', value: 'log_messages', emoji: '💬', description: 'Message edits, deletions, and purges' },
  { label: 'Voice Telemetry', value: 'log_voice', emoji: '🔊', description: 'Voice connects, disconnects, and mutes' },
  { label: 'Channel Structure', value: 'log_channels', emoji: '📁', description: 'Channel creation, deletion, and overwrites' },
  { label: 'Roles & Permissions', value: 'log_roles', emoji: '🎭', description: 'Role updates and member role assignments' },
  { label: 'Custom Emojis', value: 'log_emojis', emoji: '😀', description: 'Custom emoji uploads, deletions, updates' },
  { label: 'Server Configuration', value: 'log_guildupdate', emoji: '🏰', description: 'Server name, icon, and security updates' },
  { label: 'Antinuke & Security', value: 'log_security', emoji: '🚨', description: 'High-priority antinuke and raid triggers' },
  { label: 'Bot Additions', value: 'log_bots', emoji: '🤖', description: 'Bot invites and privileged authorizations' },
  { label: 'Webhooks & Spam', value: 'log_webhooks', emoji: '🔗', description: 'Webhook lifecycle and spam events' },
  { label: 'Security Whitelist', value: 'log_secure_wl', emoji: '🛡️', description: 'Antinuke trust and bypass modifications' },
  { label: 'Member Joins & Leaves', value: 'log_memberjoin', emoji: '🚪', description: 'Member arrivals, departures, and kicks' },
  { label: 'Invites & Attribution', value: 'log_invites', emoji: '📨', description: 'Invite creations, deletions, and attribution' },
  { label: 'Manual Staff Notes', value: 'log_manual', emoji: '📝', description: 'Internal staff notes, warnings, and memos' },
  { label: 'Ticket Transcripts', value: 'log_tickets', emoji: '🎫', description: 'Support ticket history and archive files' },
  { label: 'Quarantine Isolation', value: 'log_quarantine', emoji: '☣️', description: 'Threat containment and role stripping' },
  { label: 'Thread & Forum Posts', value: 'log_threads', emoji: '🧵', description: 'Thread creations, locks, and archives' },
  { label: 'Custom Stickers', value: 'log_stickers', emoji: '🎨', description: 'Server custom sticker lifecycle' },
  { label: 'Scheduled Guild Events', value: 'log_scheduled_events', emoji: '📅', description: 'Scheduled event creations and updates' }
];

function buildLogsPanelPayload(guild) {
  const sdb = getServerDb(guild.id);
  const settings = getAllLogSettings(guild.id, sdb);

  const formatCh = (val) => {
    if (!val) return '`Not Set (Fallback to Master)`';
    const ch = guild.channels?.cache?.get(val);
    return ch ? `<#${ch.id}> (\`${ch.name}\`)` : `\`${val}\` *(Unknown)*`;
  };

  const masterCh = settings.audit_log_channel
    ? `<#${settings.audit_log_channel}>`
    : '`Not Configured (Disabled)`';

  const card = createV2Card({
    color: undefined,
    title: '📡 Dedicated Log Routing Matrix',
    description:
      `Configure individual destination channels for all server events.\n` +
      `If a category is unset, events automatically route to the **Master Fallback Channel**.\n\n` +
      `• **Master Fallback:** ${masterCh}\n` +
      `• 💬 **Messages (Edits/Deletes/Purges):** ${formatCh(settings.log_messages)}\n` +
      `• 👤 **Members (Joins/Leaves/Nicknames):** ${formatCh(settings.log_members)}\n` +
      `• 🔊 **Voice (Connect/Disconnect/Switch):** ${formatCh(settings.log_voice)}\n` +
      `• ⚙️ **Server (Channels/Roles/Emojis/Threads):** ${formatCh(settings.log_server)}\n` +
      `• 🛡️ **Moderation (Bans/Kicks/Warns/Mutes):** ${formatCh(settings.log_mod)}\n\n` +
      `*Use the buttons below to Auto-Provision 22 comprehensive channels or 6 essential channels.*`,
    footerText: 'Tungsten Log Routing System'
  });

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`logs:select_category:${guild.id}`)
      .setPlaceholder('Select a log category to configure or inspect...')
      .addOptions(LOG_CATEGORY_OPTIONS)
  );

  const buttonRow1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`logs:auto_all:${guild.id}`)
      .setLabel('Auto-Provision 22 Channels')
      .setStyle(ButtonStyle.Success)
      .setEmoji('✨'),
    new ButtonBuilder()
      .setCustomId(`logs:auto_standard:${guild.id}`)
      .setLabel('Auto-Provision 6 Channels')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('📦'),
    new ButtonBuilder()
      .setCustomId(`logs:matrix:${guild.id}`)
      .setLabel('22-Channel Matrix')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('📋')
  );

  const buttonRow2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`logs:manual_menu:${guild.id}`)
      .setLabel('Manual Allocator')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('⚙️'),
    new ButtonBuilder()
      .setCustomId(`logs:confirm_delete:${guild.id}`)
      .setLabel('Delete All Log Channels')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🗑️'),
    new ButtonBuilder()
      .setCustomId(`logs:refresh:${guild.id}`)
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔄')
  );

  return { embeds: [card], components: [selectRow, buttonRow1, buttonRow2] };
}

function buildLogsMatrixPayload(guild) {
  const sdb = getServerDb(guild.id);
  const rows = sdb.prepare('SELECT key, value FROM server_settings').all();
  const settingsMap = {};
  for (const r of rows) settingsMap[r.key] = r.value;

  const formatTarget = (key, fallbackKey) => {
    const val = settingsMap[key];
    if (val === 'off' || val === 'disabled') return '`Disabled (Off)`';
    if (val) {
      const ch = guild.channels?.cache?.get(val);
      return ch ? `<#${ch.id}> (\`${ch.name}\`)` : `\`#${val}\` *(Unknown)*`;
    }
    if (fallbackKey && settingsMap[fallbackKey]) {
      const fbCh = guild.channels?.cache?.get(settingsMap[fallbackKey]);
      return fbCh ? `↳ <#${fbCh.id}> *(via ${fallbackKey.replace('log_', '')})*` : `↳ \`${settingsMap[fallbackKey]}\``;
    }
    if (settingsMap.audit_log_channel) {
      const masterCh = guild.channels?.cache?.get(settingsMap.audit_log_channel);
      return masterCh ? `↳ <#${masterCh.id}> *(Master Fallback)*` : `↳ \`${settingsMap.audit_log_channel}\``;
    }
    return '`Not Set (Fallback to Master)`';
  };

  const card = createV2Card({
    color: undefined,
    title: '📋 Comprehensive 22-Channel Log Routing Matrix',
    description:
      `Complete overview of all 22 dedicated telemetry destinations and security sentinels.\n\n` +
      `🛡️ **Moderation & Discipline**\n` +
      `• **Mod Logs:** ${formatTarget('log_mod')}\n` +
      `• **Ban Logs:** ${formatTarget('log_bans', 'log_mod')}\n` +
      `• **Timeout Logs:** ${formatTarget('log_timeouts', 'log_mod')}\n` +
      `• **Manual Staff Notes:** ${formatTarget('log_manual', 'log_mod')}\n` +
      `• **Quarantine Isolation:** ${formatTarget('log_quarantine', 'log_security')}\n\n` +
      `👤 **Members & Identity**\n` +
      `• **Member Joins & Leaves:** ${formatTarget('log_memberjoin', 'log_members')}\n` +
      `• **Nickname Updates:** ${formatTarget('log_nicknames', 'log_members')}\n` +
      `• **Roles & Permissions:** ${formatTarget('log_roles', 'log_server')}\n` +
      `• **Bot Additions:** ${formatTarget('log_bots', 'log_members')}\n` +
      `• **Security Whitelist:** ${formatTarget('log_secure_wl', 'log_security')}\n\n` +
      `💬 **Content & Messaging**\n` +
      `• **Message Edits & Purges:** ${formatTarget('log_messages')}\n` +
      `• **Thread & Forum Posts:** ${formatTarget('log_threads', 'log_server')}\n` +
      `• **Ticket Transcripts:** ${formatTarget('log_tickets')}\n\n` +
      `🔊 **Voice Telemetry**\n` +
      `• **Voice Activity & Rooms:** ${formatTarget('log_voice')}\n\n` +
      `⚙️ **Server & Structural**\n` +
      `• **Channels Lifecycle:** ${formatTarget('log_channels', 'log_server')}\n` +
      `• **Custom Emojis:** ${formatTarget('log_emojis', 'log_server')}\n` +
      `• **Custom Stickers:** ${formatTarget('log_stickers', 'log_server')}\n` +
      `• **Server Configuration:** ${formatTarget('log_guildupdate', 'log_server')}\n` +
      `• **Scheduled Events:** ${formatTarget('log_scheduled_events', 'log_server')}\n` +
      `• **Invites & Attribution:** ${formatTarget('log_invites', 'log_server')}\n` +
      `• **Webhooks & Spam:** ${formatTarget('log_webhooks', 'log_server')}\n\n` +
      `🚨 **Security & Root Fallback**\n` +
      `• **Security Sentinel:** ${formatTarget('log_security')}\n` +
      `• **Master Fallback Channel:** ${formatTarget('audit_log_channel')}\n\n` +
      `*Use \`!logs set <type> <#channel|off>\` to allocate or reset any category.*`,
    footerText: 'Tungsten 22-Channel Sentinel Matrix'
  });

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`logs:back_to_panel:${guild.id}`)
      .setLabel('Back to Panel')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('⬅️'),
    new ButtonBuilder()
      .setCustomId(`logs:matrix:${guild.id}`)
      .setLabel('Refresh Matrix')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🔄'),
    new ButtonBuilder()
      .setCustomId(`logs:confirm_delete:${guild.id}`)
      .setLabel('Delete All Log Channels')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🗑️')
  );

  return { embeds: [card], components: [buttonRow] };
}

function buildLogsManualAllocatorPayload(guild) {
  const card = createV2Card({
    color: undefined,
    title: '⚙️ Manual Log Routing Allocator',
    description:
      `Configure individual destination channels for any of the 22 event categories.\n\n` +
      `**Usage Instructions:**\n` +
      `• **Route to channel:** \`!logs set <type> <#channel>\`\n` +
      `• **Reset to fallback:** \`!logs set <type> off\`\n` +
      `• **View all routings:** \`!logs matrix\`\n\n` +
      `**Supported Log Types:**\n` +
      `\`mod-logs\`, \`ban-logs\`, \`timeout-logs\`, \`nickname-logs\`, \`message-logs\`, \`voice-logs\`,\n` +
      `\`channel-logs\`, \`role-logs\`, \`emoji-logs\`, \`guildupdate-logs\`, \`security-logs\`, \`bot-logs\`,\n` +
      `\`webhook-logs\`, \`secure-wl-logs\`, \`memberjoin-logs\`, \`inviteevent-logs\`, \`manual-logs\`,\n` +
      `\`tickethistory-logs\`, \`quarantine-logs\`, \`thread-logs\`, \`sticker-logs\`, \`scheduled-event-logs\`\n\n` +
      `*Select a category below for quick setup parameters.*`,
    footerText: 'Tungsten Manual Allocator'
  });

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`logs:select_category:${guild.id}`)
      .setPlaceholder('Select a log category to inspect or configure...')
      .addOptions(LOG_CATEGORY_OPTIONS)
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`logs:back_to_panel:${guild.id}`)
      .setLabel('Back to Panel')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('⬅️'),
    new ButtonBuilder()
      .setCustomId(`logs:matrix:${guild.id}`)
      .setLabel('22-Channel Matrix')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('📋'),
    new ButtonBuilder()
      .setCustomId(`logs:refresh:${guild.id}`)
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔄')
  );

  return { embeds: [card], components: [selectRow, buttonRow] };
}

module.exports = {
  name: 'logs',
  category: 'logging',
  description: 'Configure and inspect dedicated log routing channels for server events.',
  usage: 'logs [auto [all|6]|deleteall|matrix|setup|config|enable|disable|reset|set <type> <#channel|off>]',
  aliases: [
    'logging',
    'log',
    'setlog',
    'setlogs',
    'logchannel',
    'logrouter',
    'logsettings',
    'modlogs',
    'autologging',
    'autolog',
    'autologs',
    'autologging_all',
    'autologs_all',
    'autolog_all',
    'logmatrix',
    'logsmatrix'
  ],
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks', 'ManageChannels', 'ManageGuild'],

  slash: new SlashCommandBuilder()
    .setName('logs')
    .setDescription('Configure and inspect dedicated log routing channels for server events.')
    .addSubcommand(sub =>
      sub.setName('panel')
        .setDescription('View the interactive Log Routing Matrix panel')
    )
    .addSubcommand(sub =>
      sub.setName('matrix')
        .setDescription('View the comprehensive 22-channel routing table and configuration status')
    )
    .addSubcommand(sub =>
      sub.setName('auto')
        .setDescription('Automatically provision and configure dedicated log channels')
        .addStringOption(opt =>
          opt.setName('mode')
            .setDescription('Provisioning mode')
            .setRequired(false)
            .addChoices(
              { name: 'Essential 6 Channels (Standard)', value: 'standard' },
              { name: 'Comprehensive 22 Channels (All)', value: 'all' }
            )
        )
    )
    .addSubcommand(sub =>
      sub.setName('delete_all')
        .setDescription('Permanently delete all provisioned log channels and SERVER LOGS category')
    )
    .addSubcommand(sub =>
      sub.setName('set')
        .setDescription('Set the destination channel for a specific log type')
        .addStringOption(opt =>
          opt.setName('category')
            .setDescription('Log category to configure')
            .setRequired(true)
            .addChoices(
              { name: 'Master Fallback Channel', value: 'audit_log_channel' },
              { name: 'Moderation Logs', value: 'log_mod' },
              { name: 'Ban Logs', value: 'log_bans' },
              { name: 'Timeout Logs', value: 'log_timeouts' },
              { name: 'Nickname Logs', value: 'log_nicknames' },
              { name: 'Message Logs', value: 'log_messages' },
              { name: 'Voice Logs', value: 'log_voice' },
              { name: 'Channel Logs', value: 'log_channels' },
              { name: 'Role Logs', value: 'log_roles' },
              { name: 'Emoji Logs', value: 'log_emojis' },
              { name: 'Server Config Logs', value: 'log_guildupdate' },
              { name: 'Security Logs', value: 'log_security' },
              { name: 'Bot Logs', value: 'log_bots' },
              { name: 'Webhook Logs', value: 'log_webhooks' },
              { name: 'Secure WL Logs', value: 'log_secure_wl' },
              { name: 'Member Join Logs', value: 'log_memberjoin' },
              { name: 'Invite Logs', value: 'log_invites' },
              { name: 'Manual Notes', value: 'log_manual' },
              { name: 'Ticket Transcripts', value: 'log_tickets' },
              { name: 'Quarantine Logs', value: 'log_quarantine' },
              { name: 'Thread Logs', value: 'log_threads' },
              { name: 'Sticker Logs', value: 'log_stickers' },
              { name: 'Scheduled Event Logs', value: 'log_scheduled_events' }
            )
        )
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('Target channel (leave blank or select off to disable)')
            .setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub.setName('reset')
        .setDescription('Reset routing and revert to master fallback channel')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async executeSlash(interaction, client) {
    if (!interaction.guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    if (!hasPerm(interaction.member, PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure logs.', ephemeral: true });
    }

    const sub = interaction.options.getSubcommand(false) || 'panel';

    if (sub === 'panel') {
      const payload = buildLogsPanelPayload(interaction.guild);
      return interaction.reply(payload);
    }

    if (sub === 'matrix') {
      const payload = buildLogsMatrixPayload(interaction.guild);
      return interaction.reply(payload);
    }

    if (sub === 'delete_all') {
      const sdb = getServerDb(interaction.guild.id);
      const res = await deleteAllLogChannels(interaction.guild, sdb);
      if (!res.success) {
        return interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> Failed to delete log channels: ${res.error || 'Unknown error'}`,
          ephemeral: true
        });
      }
      const confirmCard = createV2Card({
        color: undefined,
        title: '🗑️ Log Channels Deleted',
        description:
          `Successfully deleted **${res.deletedCount || 0}** log channels and removed the **SERVER LOGS** category.\n` +
          `All logging routes have been reset.\n\n` +
          `*Use \`/logs auto\` to re-provision at any time.*`,
        footerText: 'Tungsten Log Management'
      });
      const panelPayload = buildLogsPanelPayload(interaction.guild);
      return interaction.reply({ embeds: [confirmCard], components: panelPayload.components });
    }

    if (sub === 'auto') {
      const mode = interaction.options.getString('mode') || 'standard';
      const sdb = getServerDb(interaction.guild.id);
      const res = await autoProvisionAllLogChannels(interaction.guild, sdb, mode);
      if (!res.success) {
        return interaction.reply({
          content: `<a:tungsten_close:1567234632905138206> Auto-provisioning failed: ${res.error || 'Unknown error'}`,
          ephemeral: true
        });
      }

      const panelPayload = buildLogsPanelPayload(interaction.guild);
      const titleText = mode === 'all'
        ? '⚡ 22-Channel Comprehensive Auto-Logging Active'
        : '⚡ Auto-Logging Engine Active';
      const descText = mode === 'all'
        ? `Successfully provisioned all **22 dedicated log channels** under **SERVER LOGS** category with announcements posted!\n\n` +
          `• Total channels provisioned: **${res.channels ? Object.keys(res.channels).length : 22}**\n` +
          `• Newly created channels: **${res.newlyCreatedCount}**\n\n` +
          `*Use \`/logs matrix\` to view all channel mappings.*`
        : `Successfully provisioned dedicated log channels under **SERVER LOGS** category with announcements posted:\n\n` +
          `• 📜 **Master Fallback:** ${res.channels?.audit_log_channel ? `<#${res.channels.audit_log_channel.id}>` : '`Configured`'}\n` +
          `• 💬 **Messages:** ${res.channels?.log_messages ? `<#${res.channels.log_messages.id}>` : '`Configured`'}\n` +
          `• 👤 **Members:** ${res.channels?.log_members ? `<#${res.channels.log_members.id}>` : '`Configured`'}\n` +
          `• 🔊 **Voice:** ${res.channels?.log_voice ? `<#${res.channels.log_voice.id}>` : '`Configured`'}\n` +
          `• ⚙️ **Server:** ${res.channels?.log_server ? `<#${res.channels.log_server.id}>` : '`Configured`'}\n` +
          `• 🛡️ **Moderation:** ${res.channels?.log_mod ? `<#${res.channels.log_mod.id}>` : '`Configured`'}\n\n` +
          `*All events are now actively routing to their designated channels.*`;

      const confirmCard = createV2Card({
        color: undefined,
        title: titleText,
        description: descText,
        footerText: 'Tungsten Auto-Logging Provisioner'
      });

      return interaction.reply({
        embeds: [confirmCard],
        components: panelPayload.components
      });
    }

    if (sub === 'set') {
      const category = interaction.options.getString('category');
      const targetChannel = interaction.options.getChannel('channel');

      const sdb = getServerDb(interaction.guild.id);
      if (!targetChannel) {
        sdb.prepare('DELETE FROM server_settings WHERE key = ?').run(category);
        return interaction.reply({ content: `<a:tungsten_success:1567242523468890274> Reset category \`${category}\` to master fallback channel.`, ephemeral: true });
      }

      sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run(category, targetChannel.id);
      return interaction.reply({
        content: `<a:tungsten_success:1567242523468890274> Log category \`${category}\` is now routed to <#${targetChannel.id}>.`,
        ephemeral: true
      });
    }

    if (sub === 'reset') {
      const sdb = getServerDb(interaction.guild.id);
      sdb.prepare("DELETE FROM server_settings WHERE key IN ('log_messages', 'log_members', 'log_voice', 'log_server', 'log_mod')").run();
      return interaction.reply({ content: '<a:tungsten_success:1567242523468890274> All individual log routes have been cleared and reset to Master Fallback.', ephemeral: true });
    }
  },

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure logs.');
    }

    const sdb = getServerDb(message.guild.id);
    const invoked = (message.invokedName || '').toLowerCase();
    const action = args[0] ? args[0].toLowerCase() : '';

    // !logs deleteall, !logs delete_all, !logs purge, !logs delete, !logs cleanup
    if (['deleteall', 'delete_all', 'purge', 'delete', 'cleanup'].includes(action)) {
      const res = await deleteAllLogChannels(message.guild, sdb);
      if (!res.success) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to delete log channels: ${res.error || 'Unknown error'}`);
      }

      const confirmCard = createV2Card({
        color: undefined,
        title: '🗑️ Log Channels Deleted',
        description:
          `<a:tungsten_success:1567242523468890274> Successfully deleted **${res.deletedCount || 0}** log channels and removed the **SERVER LOGS** category.\n\n` +
          `All log routing settings have been reset. Run \`${prefix}logs auto\` or click below to re-provision.`,
        footerText: 'Tungsten Log Management'
      });
      const panelPayload = buildLogsPanelPayload(message.guild);
      return message.reply({ embeds: [confirmCard], components: panelPayload.components });
    }

    // !logs auto [all|22|standard|6] or !autologging / !autolog / !autologs / !autologs_all / !autologging_all
    const isAutoInvoke = [
      'autologging',
      'autolog',
      'autologs',
      'autologs_all',
      'autologging_all',
      'autolog_all'
    ].includes(invoked);

    if (action === 'auto' || isAutoInvoke) {
      let mode = 'standard';
      const subArg = action === 'auto' ? args[1]?.toLowerCase() : (args[0]?.toLowerCase() || '');
      if (
        (subArg && ['all', '22', 'comprehensive'].includes(subArg)) ||
        invoked.includes('all')
      ) {
        mode = 'all';
      }

      const res = await autoProvisionAllLogChannels(message.guild, sdb, mode);
      if (!res.success) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Auto-provisioning failed: ${res.error || 'Unknown error'}`);
      }

      const panelPayload = buildLogsPanelPayload(message.guild);
      const titleText = mode === 'all'
        ? '⚡ 22-Channel Comprehensive Auto-Logging Active'
        : '⚡ Auto-Logging Engine Active';
      const descText = mode === 'all'
        ? `Successfully provisioned all **22 dedicated log channels** under **SERVER LOGS** category with announcements posted!\n\n` +
          `• **Total channels:** ${res.channels ? Object.keys(res.channels).length : 22} provisioned (newly created: **${res.newlyCreatedCount}**)\n` +
          `• View the full routing table with \`${prefix}logs matrix\`.\n\n` +
          `*All server events and security sentinels are now actively routing to their dedicated channels.*`
        : `Successfully provisioned dedicated log channels under **SERVER LOGS** category with announcements posted:\n\n` +
          `• 📜 **Master Fallback:** ${res.channels?.audit_log_channel ? `<#${res.channels.audit_log_channel.id}>` : '`Configured`'}\n` +
          `• 💬 **Messages:** ${res.channels?.log_messages ? `<#${res.channels.log_messages.id}>` : '`Configured`'}\n` +
          `• 👤 **Members:** ${res.channels?.log_members ? `<#${res.channels.log_members.id}>` : '`Configured`'}\n` +
          `• 🔊 **Voice:** ${res.channels?.log_voice ? `<#${res.channels.log_voice.id}>` : '`Configured`'}\n` +
          `• ⚙️ **Server:** ${res.channels?.log_server ? `<#${res.channels.log_server.id}>` : '`Configured`'}\n` +
          `• 🛡️ **Moderation:** ${res.channels?.log_mod ? `<#${res.channels.log_mod.id}>` : '`Configured`'}\n\n` +
          `*All events are now actively routing to their designated channels.*`;

      const confirmCard = createV2Card({
        color: undefined,
        title: titleText,
        description: descText,
        footerText: 'Tungsten Auto-Logging Provisioner'
      });

      return message.reply({
        embeds: [confirmCard],
        components: panelPayload.components
      });
    }

    // !logs matrix or !logs view -> display full 22-channel matrix
    if (action === 'matrix' || action === 'view' || ['logmatrix', 'logsmatrix'].includes(invoked)) {
      const payload = buildLogsMatrixPayload(message.guild);
      return message.reply(payload);
    }

    // !logs (no args) or !logs panel/config/status -> display interactive panel
    if (!args.length || ['panel', 'config', 'status'].includes(action)) {
      const payload = buildLogsPanelPayload(message.guild);
      return message.reply(payload);
    }

    // !logs setup [#channel]
    if (action === 'setup') {
      const targetArg = args[1];
      if (targetArg) {
        const targetId = targetArg.replace(/[<#>]/g, '');
        const targetCh = message.guild.channels.cache.get(targetId);
        if (targetCh && targetCh.isTextBased()) {
          sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('audit_log_channel', targetCh.id);
          const payload = buildLogsPanelPayload(message.guild);
          return message.reply({ content: `<a:tungsten_success:1567242523468890274> Master audit log channel configured to <#${targetCh.id}>.`, ...payload });
        }
      }
      const payload = buildLogsPanelPayload(message.guild);
      return message.reply(payload);
    }

    // !logs enable [#channel]
    if (action === 'enable') {
      const targetArg = args[1];
      let targetCh = null;
      if (targetArg) {
        const targetId = targetArg.replace(/[<#>]/g, '');
        targetCh = message.guild.channels.cache.get(targetId);
      }
      if (!targetCh || !targetCh.isTextBased()) {
        targetCh = message.channel;
      }
      sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('audit_log_channel', targetCh.id);
      const payload = buildLogsPanelPayload(message.guild);
      return message.reply({ content: `<a:tungsten_success:1567242523468890274> Logging enabled in <#${targetCh.id}>.`, ...payload });
    }

    // !logs disable / off
    if (action === 'disable' || action === 'off') {
      sdb.prepare("DELETE FROM server_settings WHERE key IN ('audit_log_channel', 'log_messages', 'log_members', 'log_voice', 'log_server', 'log_mod')").run();
      return message.reply('<a:tungsten_success:1567242523468890274> All log routing and master audit logging have been completely disabled.');
    }

    // !logs reset
    if (action === 'reset') {
      sdb.prepare("DELETE FROM server_settings WHERE key IN ('log_messages', 'log_members', 'log_voice', 'log_server', 'log_mod')").run();
      return message.reply('<a:tungsten_success:1567242523468890274> All specific log routes have been reset to fallback to `audit_log_channel`.');
    }

    // !logs set <type> <#channel|off> or !logs <type> <#channel|off>
    let typeArg = action === 'set' ? args[1]?.toLowerCase() : action;
    let chArg = action === 'set' ? args[2] : args[1];

    const dbKey = TYPE_KEY_MAP[typeArg];
    if (!dbKey) {
      return message.reply(
        `<a:tungsten_close:1567234632905138206> Unknown log type \`${typeArg}\`.\n` +
        `**Available types:** \`mod-logs\`, \`ban-logs\`, \`timeout-logs\`, \`nickname-logs\`, \`message-logs\`, \`voice-logs\`, \`channel-logs\`, \`role-logs\`, \`emoji-logs\`, \`guildupdate-logs\`, \`security-logs\`, \`bot-logs\`, \`webhook-logs\`, \`secure-wl-logs\`, \`memberjoin-logs\`, \`inviteevent-logs\`, \`manual-logs\`, \`tickethistory-logs\`, \`quarantine-logs\`, \`thread-logs\`, \`sticker-logs\`, \`scheduled-event-logs\`\n` +
        `**Usage:** \`${prefix}logs set <type> <#channel|off>\` or view \`${prefix}logs matrix\``
      );
    }

    if (!chArg) {
      const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(dbKey);
      const chVal = row?.value ? `<#${row.value}>` : '`Not configured (fallback)`';
      return message.reply(`<a:tungsten_info:1567240890748248084> Current setting for **${typeArg}** (\`${dbKey}\`): ${chVal}`);
    }

    if (chArg.toLowerCase() === 'off' || chArg.toLowerCase() === 'reset') {
      sdb.prepare('DELETE FROM server_settings WHERE key = ?').run(dbKey);
      return message.reply(`<a:tungsten_success:1567242523468890274> Log routing for **${typeArg}** has been reset to fallback.`);
    }

    const channelId = chArg.replace(/[<#>]/g, '');
    const channel = message.guild.channels.cache.get(channelId);
    if (!channel || !channel.isTextBased()) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Could not locate a valid text channel with ID or mention \`${chArg}\`.`);
    }

    sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run(dbKey, channel.id);
    return message.reply(`<a:tungsten_success:1567242523468890274> Successfully routed **${typeArg}** (\`${dbKey}\`) to <#${channel.id}>.`);
  },

  buildLogsPanelPayload,
  buildLogsMatrixPayload,
  buildLogsManualAllocatorPayload,
  TYPE_KEY_MAP
};
