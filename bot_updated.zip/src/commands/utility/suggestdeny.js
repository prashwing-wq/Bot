/**
 * Tungsten Suggestion Denial Command (Node.js)
 * Allows server staff to deny a community suggestion with review notes.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { buildSuggestionButtons } = require('./suggest');

module.exports = {
  name: 'suggestdeny',
  description: 'Deny a community suggestion and lock its voting.',
  permissions: ['ModerateMembers'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'utility',
  usage: 'suggestdeny <suggestion_id> [reason]',
  aliases: ['suggest-deny'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionsBitField.Flags.ModerateMembers) && !hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need `Moderate Members` or `Manage Server` permission to deny suggestions.'
          })
        ]
      });
    }

    const suggId = parseInt(args[0], 10);
    if (isNaN(suggId)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Invalid ID',
            description: `**Usage:** \`${prefix}suggestdeny <suggestion_id> [reason]\``
          })
        ]
      });
    }

    const reason = args.slice(1).join(' ') || 'Denied by staff';
    const sdb = getServerDb(message.guild.id);
    const sugg = sdb.prepare('SELECT * FROM suggestions WHERE guild_id = ? AND id = ?').get(message.guild.id, suggId);

    if (!sugg) {
      return message.reply(`Suggestion **#${suggId}** was not found in this server.`);
    }

    if (sugg.status !== 'PENDING') {
      return message.reply(`Suggestion **#${suggId}** is already finalized with status: **${sugg.status}**.`);
    }

    const now = Math.floor(Date.now() / 1000);
    sdb.prepare(`
      UPDATE suggestions
      SET status = 'DENIED', reason = ?, reviewed_by = ?, updated_at = ?
      WHERE id = ? AND guild_id = ?
    `).run(reason, message.author.id, now, suggId, message.guild.id);

    // Update Discord message
    try {
      const channel = message.guild.channels.cache.get(sugg.channel_id) ||
        await message.guild.channels.fetch(sugg.channel_id).catch(() => null);

      if (channel && channel.isTextBased() && typeof channel.messages?.fetch === 'function') {
        const targetMsg = await channel.messages.fetch(sugg.message_id).catch(() => null);
        if (targetMsg && targetMsg.embeds.length > 0) {
          const oldEmbed = targetMsg.embeds[0];
          const newEmbed = createEmbed({
            color: client.config.COLORS.DANGER,
            title: `<a:tungsten_close:1567234632905138206> Suggestion #${suggId} — DENIED`,
            description: oldEmbed.description || sugg.content,
            footer: oldEmbed.footer ? { text: oldEmbed.footer.text } : null,
            timestamp: true
          });

          if (oldEmbed.author) {
            newEmbed.setAuthor({
              name: oldEmbed.author.name,
              iconURL: oldEmbed.author.iconURL
            });
          }

          newEmbed.addFields(
            { name: 'Status', value: '`<a:tungsten_close:1567234632905138206> Denied`', inline: true },
            { name: 'Final Votes', value: `👍 **${sugg.upvotes}**  •  👎 **${sugg.downvotes}**`, inline: true },
            { name: 'Staff Note', value: `Reviewed by <@${message.author.id}>: *${reason}*` }
          );

          // Disable buttons
          const disabledButtons = buildSuggestionButtons(suggId, sugg.upvotes, sugg.downvotes, true);
          await targetMsg.edit({ embeds: [newEmbed], components: [disabledButtons] });
        }
      }
    } catch (err) {
      console.warn(`[SuggestDeny] Notice updating suggestion message: ${err.message}`);
    }

    // Try DM author
    try {
      const authorMember = await message.guild.members.fetch(sugg.author_id).catch(() => null);
      if (authorMember) {
        await authorMember.send({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: `<a:tungsten_close:1567234632905138206> Your Suggestion #${suggId} was Denied`,
              description: `**Server:** ${message.guild.name}\n**Suggestion:** ${sugg.content}\n**Staff Note:** ${reason}`
            })
          ]
        }).catch(() => null);
      }
    } catch (_) {}

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '<a:tungsten_close:1567234632905138206> Suggestion Denied',
          description: `Suggestion **#${suggId}** has been marked as **DENIED**.\n**Reason:** ${reason}`
        })
      ]
    });
  }
};
