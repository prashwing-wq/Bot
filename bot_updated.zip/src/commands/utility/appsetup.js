const { PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'appsetup',
  aliases: ['applicationsetup', 'appconfig', 'setappchannel'],
  category: 'utility',
  description: 'Configure staff application settings, review logs channel, and status',
  usage: '<enable | disable | channel <#channel> | questions>',
  cooldown: 5,
  permissions: ['Administrator'],
  botPermissions: [],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.Administrator)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Administrator** permission to configure staff applications.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || 'status').toLowerCase();

    const defaultQuestions = [
      { id: 'q1', label: 'Why do you want to join our staff team?', style: 'Paragraph', required: true },
      { id: 'q2', label: 'What previous moderation experience do you have?', style: 'Paragraph', required: true },
      { id: 'q3', label: 'How many hours weekly can you contribute?', style: 'Short', required: true }
    ];

    if (sub === 'enable' || sub === 'on') {
      const chId = message.channel?.id || '0';
      sdb.prepare(`
        INSERT INTO applications_config (guild_id, channel_id, log_channel_id, questions_json, enabled)
        VALUES (?, ?, ?, ?, 1)
        ON CONFLICT(guild_id) DO UPDATE SET enabled = 1
      `).run(message.guild.id, chId, chId, JSON.stringify(defaultQuestions));

      return message.reply(`<a:tungsten_ui_toggle_on:1569329685110849576> Staff applications are now **enabled**! Reviews will be dispatched to ${message.channel || 'the review channel'}.`);
    }

    if (sub === 'disable' || sub === 'off') {
      sdb.prepare('UPDATE applications_config SET enabled = 0 WHERE guild_id = ?').run(message.guild.id);
      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Staff applications are now **disabled**.');
    }

    if (sub === 'channel' || sub === 'log') {
      const targetCh = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
      if (!targetCh) return message.reply(`<a:tungsten_close:1567234632905138206> Specify a valid channel. Usage: \`${prefix}appsetup channel <#channel>\``);

      sdb.prepare(`
        INSERT INTO applications_config (guild_id, channel_id, log_channel_id, questions_json, enabled)
        VALUES (?, ?, ?, ?, 1)
        ON CONFLICT(guild_id) DO UPDATE SET log_channel_id = ?
      `).run(message.guild.id, targetCh.id, targetCh.id, JSON.stringify(defaultQuestions), targetCh.id);

      return message.reply(`<a:tungsten_success:1567242523468890274> Application review submissions will now be sent to ${targetCh}.`);
    }

    const row = sdb.prepare('SELECT enabled, channel_id, log_channel_id, questions_json FROM applications_config WHERE guild_id = ?').get(message.guild.id);
    const isEnabled = row ? row.enabled === 1 : false;
    const logChannel = row?.log_channel_id ? `<#${row.log_channel_id}>` : '*Not configured*';

    const embed = createEmbed({
      title: '<a:tungsten_memo:1567241226577780957> Staff Application Configuration',
      description: `Current Status: **${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}**\n` +
        `Review Logs Channel: ${logChannel}\n\n` +
        `• **Enable Applications:** \`${prefix}appsetup enable\`\n` +
        `• **Disable Applications:** \`${prefix}appsetup disable\`\n` +
        `• **Set Review Channel:** \`${prefix}appsetup channel <#channel>\`\n` +
        `• **Post Apply Panel:** \`${prefix}apply\``,
      color: isEnabled ? 0x57F287 : 0xED4245
    });

    return message.reply({ embeds: [embed] });
  }
};
