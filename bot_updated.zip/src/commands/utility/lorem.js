/**
 * Tungsten Lorem Ipsum Generator Command (Node.js)
 * Generates classical, placeholder dummy text with word and paragraph telemetry.
 */
const { createV2Card } = require('../../utils/componentsV2');

const CANONICAL_FIRST_PARAGRAPH =
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ' +
  'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ' +
  'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. ' +
  'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';

const SENTENCE_CORPUS = [
  'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis.',
  'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore.',
  'Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?',
  'Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi.',
  'Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga, harum quidem rerum facilis est et expedita distinctio.',
  'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est.',
  'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.',
  'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.'
];

function generateLorem(paragraphCount = 1) {
  const count = Math.max(1, Math.min(5, parseInt(paragraphCount, 10) || 1));
  const paragraphs = [CANONICAL_FIRST_PARAGRAPH];

  for (let p = 1; p < count; p++) {
    const sentences = [];
    // 3 to 4 sentences per paragraph
    const sentenceCount = 3 + (p % 2);
    for (let s = 0; s < sentenceCount; s++) {
      const idx = (p * 3 + s) % SENTENCE_CORPUS.length;
      sentences.push(SENTENCE_CORPUS[idx]);
    }
    paragraphs.push(sentences.join(' '));
  }

  const fullText = paragraphs.join('\n\n');
  const words = fullText.trim().split(/\s+/).filter(Boolean).length;
  const chars = fullText.length;

  return {
    count,
    paragraphs,
    text: fullText,
    totalWords: words,
    totalChars: chars
  };
}

module.exports = {
  name: 'lorem',
  aliases: ['lipsum', 'loremipsum', 'dummytext'],
  category: 'utility',
  description: 'Generate placeholder Lorem Ipsum dummy text.',
  usage: '[paragraphs (1-5)]',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 2,

  async execute(message, args, client, prefix = '!') {
    let requestedCount = 1;
    if (args[0]) {
      const parsed = parseInt(args[0], 10);
      if (!isNaN(parsed) && parsed > 0) {
        requestedCount = Math.min(5, parsed);
      }
    }

    const loremData = generateLorem(requestedCount);

    // Ensure description doesn't exceed Discord limits
    const maxDesc = 3500;
    const isTruncated = loremData.text.length > maxDesc;
    const bodyText = isTruncated
      ? loremData.text.slice(0, maxDesc) + '\n... [truncated]'
      : loremData.text;

    const card = createV2Card({
      color: 0x5865F2,
      title: '📜 Tungsten • Lorem Ipsum Generator',
      description:
        `> **Generated:** \`${loremData.count}\` paragraph${loremData.count > 1 ? 's' : ''} • \`${loremData.totalWords}\` words • \`${loremData.totalChars}\` characters\n\n` +
        bodyText,
      footerText: `Requested by ${message.author?.username || 'User'}`
    });

    return message.reply({ embeds: [card] });
  },

  generateLorem,
  CANONICAL_FIRST_PARAGRAPH,
  SENTENCE_CORPUS
};
