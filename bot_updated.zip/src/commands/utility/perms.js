/**
 * Permissions & Role Hierarchy Inspector (Node.js)
 * Evaluates channel-specific and guild-wide administrative and general permissions
 * with animated toggle status indicators and role hierarchy positioning.
 */
const {
  SlashCommandBuilder,
  PermissionsBitField,
  ChannelType
} = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

const TOGGLE_ON = '<a:tungsten_ui_toggle_on:1569329685110849576>';
const TOGGLE_OFF = '<a:tungsten_ui_toggle_off:1569329677187678368>';

const ADMIN_MOD_PERMS = [
  { flag: PermissionsBitField.Flags.Administrator, name: 'Administrator' },
  { flag: PermissionsBitField.Flags.ManageGuild, name: 'Manage Server' },
  { flag: PermissionsBitField.Flags.ManageRoles, name: 'Manage Roles' },
  { flag: PermissionsBitField.Flags.ManageChannels, name: 'Manage Channels' },
  { flag: PermissionsBitField.Flags.BanMembers, name: 'Ban Members' },
  { flag: PermissionsBitField.Flags.KickMembers, name: 'Kick Members' },
  { flag: PermissionsBitField.Flags.ModerateMembers, name: 'Moderate Members' },
  { flag: PermissionsBitField.Flags.ViewAuditLog, name: 'View Audit Log' },
  { flag: PermissionsBitField.Flags.ManageMessages, name: 'Manage Messages' }
];

const GENERAL_PERMS = [
  { flag: PermissionsBitField.Flags.SendMessages, name: 'Send Messages' },
  { flag: PermissionsBitField.Flags.EmbedLinks, name: 'Embed Links' },
  { flag: PermissionsBitField.Flags.AttachFiles, name: 'Attach Files' },
  { flag: PermissionsBitField.Flags.AddReactions, name: 'Add Reactions' },
  { flag: PermissionsBitField.Flags.MentionEveryone, name: 'Mention Everyone' }
];

/**
 * Builds the permission inspection card for a target member or role in a channel
 */
function buildPermsCard(target, channel, guild) {
  const isRole = Boolean(target.color !== undefined && !target.user);
  const isOwner = !isRole && guild?.ownerId === target.id;

  // Resolve effective channel permissions
  let channelPerms = null;
  if (channel && typeof channel.permissionsFor === 'function') {
    channelPerms = channel.permissionsFor(target);
  }
  if (!channelPerms) {
    channelPerms = target.permissions || new PermissionsBitField();
  }

  const hasAdmin = channelPerms.has(PermissionsBitField.Flags.Administrator);

  // Hierarchy badge
  let hierarchyText = '';
  let cardColor = config.COLORS?.PRIMARY || 0x2b2d31;

  if (isRole) {
    const pos = target.position ?? 0;
    hierarchyText = `\`Position #${pos}\` • @${target.name}`;
    if (target.color) cardColor = target.color;
  } else {
    const highestRole = target.roles?.highest;
    const pos = highestRole ? highestRole.position : 0;
    hierarchyText = `\`Position #${pos}\` • ${highestRole ? `@${highestRole.name}` : '*None*'}${isOwner ? ' • 👑 **Server Owner**' : ''}`;
    if (highestRole?.color) cardColor = highestRole.color;
  }

  // Target header
  let targetHeader = '';
  if (isRole) {
    targetHeader = `• **Role:** <@&${target.id}> (\`@${target.name}\` • \`${target.id}\`)`;
  } else {
    const tag = target.user?.tag || target.displayName || target.id;
    targetHeader = `• **User:** <@${target.id}> (\`${tag}\` • \`${target.id}\`)`;
  }

  const adminModLines = ADMIN_MOD_PERMS.map(p => {
    const granted = hasAdmin || channelPerms.has(p.flag);
    return `${granted ? TOGGLE_ON : TOGGLE_OFF} **${p.name}**`;
  }).join('\n');

  const generalLines = GENERAL_PERMS.map(p => {
    const granted = hasAdmin || channelPerms.has(p.flag);
    return `${granted ? TOGGLE_ON : TOGGLE_OFF} **${p.name}**`;
  }).join('\n');

  const descParts = [
    `> Granular permission sentinel evaluating channel overrides & role stack.\n`,
    `${targetHeader}`,
    `• **Channel:** <#${channel.id}> (\`#${channel.name}\`)`,
    `• **Hierarchy Level:** ${hierarchyText}\n`
  ];

  if (hasAdmin) {
    descParts.push(`⭐ **Administrator Active**: Inherits absolute bypass across all channel restrictions and actions.\n`);
  }

  descParts.push(
    `🛡️ **Admin & Moderation Permissions:**\n${adminModLines}\n`,
    `<a:tungsten_chat:1567234399450177665> **General Channel Permissions:**\n${generalLines}`
  );

  let thumb = null;
  if (!isRole && target.user?.displayAvatarURL) {
    try {
      const u = target.user.displayAvatarURL({ dynamic: true, size: 256 });
      if (typeof u === 'string' && u.startsWith('http')) thumb = u;
    } catch (_) {}
  }

  const titleName = isRole ? `@${target.name}` : (target.displayName || target.user?.username || 'Member');
  return createV2Card({
    color: cardColor,
    title: `<a:tungsten_policy:1569329528851927131> Permission Sentinel • ${titleName}`,
    description: descParts.join('\n'),
    thumbnailUrl: thumb,
    footerText: `Tungsten Permission Sentinel • Evaluated in #${channel.name || 'channel'}`
  });
}

module.exports = {
  name: 'perms',
  aliases: ['permissions', 'botperms', 'myperms', 'userperms'],
  category: 'utility',
  description: 'Inspect permissions and hierarchy position of a member, role, Tungsten, or yourself in any channel.',
  usage: '[user|role|bot] [#channel]',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    const guild = message.guild;
    if (!guild) return;

    let targetChannel = null;
    const remainingArgs = [];

    // Detect mentioned channel or channel ID/name in args
    const mentionedChannel = typeof message.mentions?.channels?.first === 'function'
      ? message.mentions.channels.first()
      : null;
    if (mentionedChannel) {
      targetChannel = mentionedChannel;
    }

    for (const arg of args) {
      if (!targetChannel) {
        const cleanChanId = arg.replace(/[<#>]/g, '');
        const foundChan = (guild.channels?.cache?.get && guild.channels.cache.get(cleanChanId)) ||
          (guild.channels?.cache?.find && guild.channels.cache.find(c => c.name.toLowerCase() === arg.toLowerCase()));
        if (foundChan) {
          targetChannel = foundChan;
          continue;
        }
      }
      remainingArgs.push(arg);
    }

    if (!targetChannel) {
      targetChannel = message.channel;
    }

    let target = null;
    const firstArg = remainingArgs[0]?.toLowerCase();

    // Check shortcut routing or keywords
    const isBotPerms = message.__commandName === 'botperms' || firstArg === 'bot' || (firstArg === 'tungsten' || firstArg === 'tungsten') || firstArg === 'tungsten';
    const isMyPerms = message.__commandName === 'myperms' || firstArg === 'me' || firstArg === 'myself';

    if (isBotPerms) {
      target = guild.members?.me || (guild.members?.fetchMe ? await guild.members.fetchMe().catch(() => null) : null);
    } else if (isMyPerms) {
      target = message.member;
    } else if (typeof message.mentions?.members?.first === 'function' && message.mentions.members.first()) {
      target = message.mentions.members.first();
    } else if (typeof message.mentions?.roles?.first === 'function' && message.mentions.roles.first()) {
      target = message.mentions.roles.first();
    } else if (remainingArgs.length > 0) {
      const cleanTargetId = remainingArgs[0].replace(/[<@!&>]/g, '');

      // 1. Try member by ID
      target = guild.members?.cache?.get ? guild.members.cache.get(cleanTargetId) : null;
      if (!target && guild.members?.fetch) {
        target = await guild.members.fetch(cleanTargetId).catch(() => null);
      }

      // 2. Try role by ID or Name
      if (!target && guild.roles?.cache) {
        target = (guild.roles.cache.get && guild.roles.cache.get(cleanTargetId)) ||
          (guild.roles.cache.find && guild.roles.cache.find(r => r.name.toLowerCase() === remainingArgs.join(' ').toLowerCase() || r.name.toLowerCase() === remainingArgs[0].toLowerCase()));
      }

      // 3. Try member username / display name
      if (!target && guild.members?.cache?.find) {
        const query = remainingArgs.join(' ').toLowerCase();
        target = guild.members.cache.find(m =>
          m.user?.username?.toLowerCase() === query ||
          m.displayName?.toLowerCase() === query ||
          m.user?.tag?.toLowerCase() === query
        );
      }
    }

    // Default to command author if no target specified or found
    if (!target) {
      target = message.member;
    }

    const card = buildPermsCard(target, targetChannel, guild);
    return message.reply({ embeds: [card] });
  },

  slash: new SlashCommandBuilder()
    .setName('perms')
    .setDescription('Inspect permissions and hierarchy position of a user, role, Tungsten, or yourself')
    .addMentionableOption(option =>
      option
        .setName('target')
        .setDescription('User or role to inspect (defaults to yourself)')
        .setRequired(false)
    )
    .addChannelOption(option =>
      option
        .setName('channel')
        .setDescription('Channel to evaluate permissions in (defaults to current channel)')
        .setRequired(false)
    ),

  async executeSlash(interaction, client) {
    const guild = interaction.guild;
    if (!guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    const targetChannel = interaction.options.getChannel('channel') || interaction.channel;
    const mentionable = typeof interaction.options.getMentionable === 'function'
      ? interaction.options.getMentionable('target')
      : (typeof interaction.options.getMember === 'function' ? interaction.options.getMember('target') : null);

    let target = mentionable || interaction.member;
    // In case mentionable is a raw User without member permissions
    if (target && !target.permissions && target.id) {
      const fetchedMember = await guild.members.fetch(target.id).catch(() => null);
      if (fetchedMember) target = fetchedMember;
    }

    const card = buildPermsCard(target, targetChannel, guild);
    return interaction.reply({ embeds: [card] });
  }
};
