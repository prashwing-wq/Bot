const { PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'emojizip',
  aliases: ['tmpemojidownload', 'tmpemojiupload', 'emojidownload', 'emojiupload', 'emojibackup'],
  category: 'utility',
  description: 'Download manifest of all custom emojis or batch upload emojis',
  usage: '<download | upload <name> <url>>',
  cooldown: 5,
  permissions: ['ManageGuildExpressions'],
  botPermissions: ['ManageGuildExpressions'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuildExpressions)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Expressions** permission to use emoji utilities.');
    }

    const sub = (args[0] || (message.content.includes('upload') ? 'upload' : 'download')).toLowerCase();

    if (sub === 'download' || sub === 'export' || sub === 'list') {
      const emojis = await message.guild.emojis.fetch().catch(() => message.guild.emojis.cache);
      if (!emojis || emojis.size === 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> This server has no custom emojis.');
      }

      const manifest = [];
      for (const [id, e] of emojis) {
        manifest.push({
          id: e.id,
          name: e.name,
          animated: e.animated,
          url: e.imageURL({ extension: e.animated ? 'gif' : 'png', size: 128 })
        });
      }

      const jsonStr = JSON.stringify({
        guildId: message.guild.id,
        guildName: message.guild.name,
        count: manifest.length,
        exportedAt: new Date().toISOString(),
        emojis: manifest
      }, null, 2);

      const buffer = Buffer.from(jsonStr, 'utf8');
      const file = new AttachmentBuilder(buffer, { name: `${message.guild.id}_emojis_manifest.json` });

      const embed = createEmbed({
        title: '🎨 Emoji Archive Manifest',
        description: `Exported **${manifest.length}** custom server emojis.\nAttachment contains direct Discord CDN URLs and metadata for all emojis.`,
        color: 0x5865F2
      });

      return message.reply({ embeds: [embed], files: [file] });
    }

    if (sub === 'upload' || sub === 'add') {
      const name = args[1];
      const url = args[2] || message.attachments.first()?.url;

      if (!name || !url) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}emojizip upload <name> <image_url_or_attachment>\``);
      }

      try {
        const created = await message.guild.emojis.create({
          attachment: url,
          name: name.replace(/[^a-zA-Z0-9_]/g, '_')
        });

        const embed = createEmbed({
          title: '<a:tungsten_success:1567242523468890274> Emoji Created',
          description: `Successfully added ${created} (\`:${created.name}:\`) to the server.`,
          color: 0x57F287
        });
        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to upload emoji: ${err.message}`);
      }
    }

    return message.reply(`Usage: \`${prefix}emojizip <download | upload <name> <url>>\``);
  }
};
