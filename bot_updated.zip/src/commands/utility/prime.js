/**
 * Tungsten Prime Showcase Command (Node.js)
 * Showcases Tungsten Prime features (100% free, open-source, fast antinuke, 0 latency).
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'prime',
  aliases: ['tungstenprime', 'premiuminfo', 'free'],
  category: 'utility',
  description: 'Tungsten Prime showcase card (free, open-source, fast antinuke).',
  usage: '',
  cooldown: 5,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    const embed = createEmbed({
      color: 0x00FFB3,
      title: '🌟  Tungsten Prime • 100% Free & Open-Source',
      description:
        `> **Tungsten is completely, unconditionally free forever.**\n` +
        `> No subscriptions, no locked tiers, no license keys, and no paywalled security.\n\n` +
        `### 🛡️ Why Tungsten Prime?\n` +
        `• **Enterprise Antinuke:** Sub-millisecond threat suppression & dual backup role anchors\n` +
        `• **Full Automod Suite:** Real-time anti-spam, anti-mass-mention, and regex filtering\n` +
        `• **Join-to-Create Voice:** Dynamic temporary voice room provisioning & telemetry\n` +
        `• **Unlimited Backups:** Full-fidelity server templates, roles, and channel cloning\n` +
        `• **Zero Telemetry Tracking:** Self-hosted SQLite database isolation per server\n\n` +
        `*Every server receives maximum Prime tier privileges automatically upon bot invitation.*`
    });

    if (client.user && typeof client.user.displayAvatarURL === 'function') {
      const avatar = client.user.displayAvatarURL();
      if (typeof avatar === 'string' && avatar.startsWith('http')) {
        embed.setThumbnail(avatar);
      }
    }

    return message.reply({ embeds: [embed] });
  }
};
