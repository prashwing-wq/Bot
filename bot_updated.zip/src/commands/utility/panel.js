/**
 * Panel / Settings Hub Command (Node.js)
 * Opens the interactive Components V2 Configuration & Sentinel Studio.
 */
const { buildHubPayload, buildPagePayload, PAGE_METADATA } = require('../../panel');
const { can } = require('../../settings/registry');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'panel',
  aliases: ['settings', 'config', 'dashboard', 'studio'],
  category: 'utility',
  description: 'Opens the interactive Components V2 Settings & Sentinel Hub.',
  usage: '[page]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be executed within a server.');
    }

    if (!can(message.member, 'manager')) {
      return message.reply('❌ You need **Manage Server** or Administrator privileges to open the Settings Studio.');
    }

    const sub = (args[0] || '').toLowerCase();
    if (sub && PAGE_METADATA[sub]) {
      const payload = buildPagePayload(message.guild.id, sub, message.author.id);
      return message.reply(payload);
    }

    const payload = buildHubPayload(message.guild.id, message.author.id);
    return message.reply(payload);
  }
};
