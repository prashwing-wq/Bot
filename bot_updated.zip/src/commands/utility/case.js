/**
 * Tungsten Text Case Transformer Command (Node.js)
 * Supports upper, lower, title, camel, snake, kebab, sponge, reverse, and pascal case.
 */
const { createV2Card } = require('../../utils/componentsV2');

function toTitleCase(text) {
  return text.replace(/\b\p{L}[\p{L}\p{N}]*/gu, match =>
    match.charAt(0).toUpperCase() + match.slice(1).toLowerCase()
  );
}

function toCamelCase(text) {
  const words = text
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return '';
  return words[0].toLowerCase() + words.slice(1).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
}

function toPascalCase(text) {
  const words = text
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  return words.map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
}

function toSnakeCase(text) {
  return text
    .replace(/([a-z\d])([A-Z])/g, '$1_$2')
    .replace(/[^\p{L}\p{N}]+/gu, '_')
    .replace(/^_+|_+$/g, '')
    .toLowerCase();
}

function toKebabCase(text) {
  return text
    .replace(/([a-z\d])([A-Z])/g, '$1-$2')
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
    .toLowerCase();
}

function toSpongeCase(text) {
  let upper = false;
  return Array.from(text).map(char => {
    if (/\p{L}/u.test(char)) {
      upper = !upper;
      return upper ? char.toUpperCase() : char.toLowerCase();
    }
    return char;
  }).join('');
}

function toReverse(text) {
  return Array.from(text).reverse().join('');
}

function transformCase(mode, text) {
  const m = String(mode).toLowerCase();
  switch (m) {
    case 'upper':
    case 'uppercase':
    case 'allcaps':
      return text.toUpperCase();

    case 'lower':
    case 'lowercase':
      return text.toLowerCase();

    case 'title':
    case 'titlecase':
    case 'capitalize':
      return toTitleCase(text);

    case 'camel':
    case 'camelcase':
      return toCamelCase(text);

    case 'pascal':
    case 'pascalcase':
      return toPascalCase(text);

    case 'snake':
    case 'snakecase':
      return toSnakeCase(text);

    case 'kebab':
    case 'kebabcase':
    case 'slug':
      return toKebabCase(text);

    case 'sponge':
    case 'spongebob':
    case 'mock':
    case 'alternating':
      return toSpongeCase(text);

    case 'reverse':
    case 'backwards':
    case 'invert':
      return toReverse(text);

    default:
      return null;
  }
}

module.exports = {
  name: 'case',
  aliases: ['textcase', 'casing'],
  category: 'utility',
  description: 'Transform text into uppercase, lowercase, title, camel, snake, kebab, sponge, or reverse casing.',
  usage: '<upper|lower|title|camel|snake|kebab|sponge|reverse> <text>',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 2,

  async execute(message, args, client, prefix = '!') {
    // Backwards-compatibility hook: If args[0] is numeric, delegate to moderation cases
    if (args[0] && /^#?\d+$/.test(args[0]) && client?.commands?.has('cases')) {
      const casesCmd = client.commands.get('cases');
      return casesCmd.execute(message, args, client, prefix);
    }

    if (args.length === 0) {
      const card = createV2Card({
        color: 0x5865F2,
        title: '<a:tungsten_notepad:1567241681911152733> Tungsten • Text Case Transformer',
        description:
          `Convert and reformat text across multiple casing styles.\n\n` +
          `**Syntax & Usage:**\n` +
          `• \`${prefix}case <mode> <text>\`\n\n` +
          `**Supported Modes:**\n` +
          `• \`upper\` — ALL UPPERCASE TEXT\n` +
          `• \`lower\` — all lowercase text\n` +
          `• \`title\` — Capitalize The First Letter Of Each Word\n` +
          `• \`camel\` — camelCaseFormattedText\n` +
          `• \`snake\` — snake_case_formatted_text\n` +
          `• \`kebab\` — kebab-case-formatted-text\n` +
          `• \`sponge\` — sPoNgEbOb mOcKiNg cAsE\n` +
          `• \`reverse\` — txet desreveR\n` +
          `• \`pascal\` — PascalCaseFormattedText\n\n` +
          `**Example:**\n` +
          `• \`${prefix}case camel Hello Tungsten Bot\` -> \`helloTungstenBot\`\n` +
          `• \`${prefix}case sponge Stop doing that\` -> \`sToP dOiNg tHaT\``,
        footerText: `Requested by ${message.author?.username || 'User'}`
      });
      return message.reply({ embeds: [card] });
    }

    const mode = args[0]?.toLowerCase();
    const text = args.slice(1).join(' ').trim();

    if (!text) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Please provide text to transform.\nExample: \`${prefix}case ${mode} <your text here>\``);
    }

    const result = transformCase(mode, text);
    if (result === null) {
      return message.reply(
        `<a:tungsten_close:1567234632905138206> Unknown casing mode \`${mode}\`.\n` +
        `Supported modes: \`upper\`, \`lower\`, \`title\`, \`camel\`, \`snake\`, \`kebab\`, \`sponge\`, \`reverse\`, \`pascal\``
      );
    }

    const maxLen = 1500;
    const isTruncated = result.length > maxLen;
    const safeResult = isTruncated
      ? result.slice(0, maxLen) + `\n... [truncated ${result.length - maxLen} chars]`
      : result;

    const card = createV2Card({
      color: 0x00FF88,
      title: `<a:tungsten_notepad:1567241681911152733> Tungsten • Text Case (${mode.toUpperCase()})`,
      description:
        `• **Mode:** \`${mode}\`\n` +
        `• **Length:** \`${result.length}\` characters\n\n` +
        `**Result:**\n` +
        `\`\`\`\n${safeResult || '[Empty Result]'}\n\`\`\``,
      footerText: `Requested by ${message.author?.username || 'User'}`
    });

    return message.reply({ embeds: [card] });
  },

  transformCase,
  toTitleCase,
  toCamelCase,
  toPascalCase,
  toSnakeCase,
  toKebabCase,
  toSpongeCase,
  toReverse
};
