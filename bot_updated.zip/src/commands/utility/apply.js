const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'apply',
  aliases: ['staffapply', 'appopen'],
  category: 'utility',
  description: 'Submit an application for server staff positions via interactive modal',
  usage: '',
  cooldown: 5,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare('SELECT enabled, channel_id, questions_json FROM applications_config WHERE guild_id = ?').get(message.guild.id);

    if (!row || !row.enabled) {
      return message.reply(`<a:tungsten_info:1567240890748248084> Staff applications are not currently open for this server. Server admins can configure it via \`${prefix}appsetup\`.`);
    }

    const embed = createEmbed({
      title: `${EMOJIS.MEMO} Staff Application Portal`,
      description: 'Interested in joining our server staff team? Click the button below to complete the application questionnaire.',
      color: 0x5865F2,
      footer: { text: 'Tungsten Staff Applications System' }
    });

    const rowBtn = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('apply:open')
        .setLabel('Apply for Staff')
        .setStyle(ButtonStyle.Primary)
        .setEmoji(EMOJIS.MEMO)
    );

    return message.reply({ embeds: [embed], components: [rowBtn] });
  }
};
