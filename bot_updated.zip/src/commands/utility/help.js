/**
 * Tungsten Help Command Center (Node.js)
 * Interactive Category Selection Hub with Row 0 Dropdown, category buttons, and command inspection.
 */
const { MessageFlags, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const {
  CATEGORIES,
  resolveCategoryCommands,
  buildHomeEmbed,
  buildCategoryEmbed,
  createHelpComponents,
  buildCommandEmbed,
  createCommandComponents,
  buildHomePayload,
  buildCategoryPayload,
  buildCommandPayload
} = require('../../utils/helpUi');
const { attachButtonsToEmbed } = require('../../utils/componentsV2');
const { EMOJIS } = require('../../utils/emojis');
const { createEmbed, isOwner } = require('../../utils/tools');

const OWNER_COMMAND_NAMES = new Set([
  'eval', 'exec', 'reload', 'ownerhelp', 'noprefix', 'npmanager', 'ownerpanel',
  'np', 'no-prefix', 'nppanel', 'npm', 'np_manager', 'np-manager', 'npstudio',
  'blacklist', 'bserver', 'dm', 'emojiserver', 'forcepurge', 'freezenick',
  'getinvite', 'globalannounce', 'globalban', 'guildban', 'guildinfo',
  'leaveguild', 'mutual', 'ownerban', 'owners', 'restart', 'selfadmin',
  'sync', 'database'
]);

function isOwnerCommand(cmd, queryName = '') {
  if (cmd?.ownerOnly || cmd?.category === 'owner') return true;
  const name = (cmd?.name || queryName || '').toLowerCase().trim();
  if (OWNER_COMMAND_NAMES.has(name)) return true;
  if (cmd?.aliases && Array.isArray(cmd.aliases)) {
    if (cmd.aliases.some(a => OWNER_COMMAND_NAMES.has(a.toLowerCase()))) return true;
  }
  return false;
}

function findCommandOrAlias(client, query) {
  if (!query) return null;
  const q = String(query).toLowerCase().trim();
  const normalized = q.replace(/[-_]/g, '');
  const noSpace = q.replace(/ /g, '');

  // 1. Direct command name
  let cmd = client?.commands?.get?.(q) || client?.commands?.get?.(normalized);
  if (cmd) return cmd;

  // 2. Client aliases
  const aliasTarget = client?.aliases?.get?.(q) || client?.aliases?.get?.(normalized);
  if (aliasTarget) {
    cmd = client?.commands?.get?.(aliasTarget);
    if (cmd) return cmd;
  }

  // 3. DIRECT_COMMAND_ROUTES from messageCreate
  try {
    const { DIRECT_COMMAND_ROUTES } = require('../../events/messageCreate');
    const routes = DIRECT_COMMAND_ROUTES || {};
    const route = routes[q] || routes[normalized] || routes[noSpace];
    if (route) {
      const target = (typeof route === 'string' ? route : route?.cmd)?.toLowerCase();
      if (target) {
        cmd = client?.commands?.get?.(target) || client?.commands?.get?.(client?.aliases?.get?.(target));
        if (cmd) return cmd;
      }
    }
  } catch (_) {}

  // 4. Multi-word shortcut or subcommand (e.g. "whitelist add", "an limit", "mainrole add")
  if (q.includes(' ')) {
    const firstWord = q.split(' ')[0];
    cmd = client?.commands?.get?.(firstWord);
    if (cmd) return cmd;

    const firstAlias = client?.aliases?.get?.(firstWord);
    if (firstAlias) {
      cmd = client?.commands?.get?.(firstAlias);
      if (cmd) return cmd;
    }

    try {
      const { DIRECT_COMMAND_ROUTES } = require('../../events/messageCreate');
      const routes = DIRECT_COMMAND_ROUTES || {};
      const routeFirst = routes[firstWord];
      if (routeFirst) {
        const target = (typeof routeFirst === 'string' ? routeFirst : routeFirst?.cmd)?.toLowerCase();
        if (target) {
          cmd = client?.commands?.get?.(target) || client?.commands?.get?.(client?.aliases?.get?.(target));
          if (cmd) return cmd;
        }
      }
    } catch (_) {}
  }

  // 5. Match against CATEGORIES sections
  for (const cat of CATEGORIES) {
    for (const sec of cat.sections || []) {
      for (const cmdItem of sec.commands || []) {
        const base = cmdItem.split(' ')[0].toLowerCase();
        if (base === q || (q.includes(' ') && base === q.split(' ')[0])) {
          cmd = client?.commands?.get?.(base) || client?.commands?.get?.(client?.aliases?.get?.(base));
          if (cmd) return cmd;
        }
      }
    }
  }

  return null;
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'help',
  aliases: ['h'],
  category: 'utility',
  description: 'Shows Tungsten command center, category guide, or command usage.',
  usage: '[category | command]',
  cooldown: 3,

  slash: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Shows Tungsten command center, category guide, or command usage.')
    .addStringOption(opt =>
      opt
        .setName('category')
        .setDescription('Category module to inspect')
        .setRequired(false)
        .setAutocomplete(true)
    )
    .addStringOption(opt =>
      opt
        .setName('query')
        .setDescription('Category, command, or shortcut to inspect')
        .setRequired(false)
        .setAutocomplete(true)
    ),

  async autocomplete(interaction, client) {
    let focused = '';
    try {
      const f = interaction.options.getFocused(false);
      focused = (typeof f === 'string' ? f : (f?.value || '')).toLowerCase().trim();
    } catch {
      focused = '';
    }
    const choices = [];
    const seen = new Set();

    const addChoice = (name, value) => {
      if (choices.length >= 25) return;
      const v = String(value).toLowerCase();
      if (seen.has(v)) return;
      seen.add(v);
      choices.push({ name: name.slice(0, 100), value: value.slice(0, 100) });
    };

    // 1. Categories (22 modules)
    for (const cat of CATEGORIES) {
      if (cat.id === 'owner') continue;
      if (!focused || cat.id.toLowerCase().includes(focused) || cat.label.toLowerCase().includes(focused)) {
        addChoice(`${cat.label} (Category)`, cat.id);
      }
      if (choices.length >= 25) break;
    }

    // 2. Direct Commands from client.commands
    if (client?.commands && choices.length < 25) {
      for (const [name, cmd] of client.commands) {
        if (isOwnerCommand(cmd, name)) continue;
        if (!focused || name.includes(focused)) {
          addChoice(`/${name} — ${(cmd.description || '').slice(0, 45)}`, name);
        }
        if (choices.length >= 25) break;
      }
    }

    // 3. Client Aliases from client.aliases
    if (client?.aliases && choices.length < 25) {
      for (const [alias, realName] of client.aliases) {
        const cmd = client.commands?.get?.(realName);
        if (isOwnerCommand(cmd, alias) || isOwnerCommand(null, realName)) continue;
        if (!focused || alias.includes(focused)) {
          addChoice(`/${alias} (alias for ${realName})`, alias);
        }
        if (choices.length >= 25) break;
      }
    }

    // 4. DIRECT_COMMAND_ROUTES Shortcuts
    try {
      const { DIRECT_COMMAND_ROUTES } = require('../../events/messageCreate');
      if (DIRECT_COMMAND_ROUTES && choices.length < 25) {
        for (const [shortcut, route] of Object.entries(DIRECT_COMMAND_ROUTES)) {
          const target = (typeof route === 'string' ? route : route?.cmd)?.toLowerCase();
          const cmd = client?.commands?.get?.(target);
          if (isOwnerCommand(cmd, shortcut) || isOwnerCommand(null, target)) continue;
          if (!focused || shortcut.includes(focused)) {
            addChoice(`/${shortcut} (${target || 'shortcut'})`, shortcut);
          }
          if (choices.length >= 25) break;
        }
      }
    } catch (_) {}

    await interaction.respond(choices.slice(0, 25)).catch(() => null);
  },

  async executeSlash(interaction, client) {
    const category = interaction.options.getString('category')?.trim();
    const query = (category || interaction.options.getString('query') || '').trim();
    const prefix = '/';

    // 1. No Query -> Render Main Sleek Category Selection Hub
    if (!query) {
      const payload = buildHomePayload(client, prefix, interaction.user, interaction.guild?.id);
      return interaction.reply(payload);
    }

    const q = query.toLowerCase();

    // 2. Special Guard: Owner Help Request
    if (q === 'owner' || q === 'dev' || q === 'developer' || q === 'ownerhelp' || q === 'owner & dev') {
      if (!isOwner(interaction.user.id)) {
        return interaction.reply({
          content: 'Access denied: Owner commands are restricted to bot owners.',
          flags: MessageFlags.Ephemeral
        });
      }
      return interaction.reply({
        content: `Bot owner commands are accessible exclusively via \`!ownerhelp\`.`,
        flags: MessageFlags.Ephemeral
      });
    }

    // 2b. Restrict owner command names
    if (isOwnerCommand(null, q) && !isOwner(interaction.user.id)) {
      return interaction.reply({
        content: 'Access denied: This command is restricted to bot owners.',
        flags: MessageFlags.Ephemeral
      });
    }

    // 3. Query is a Category Name -> Jump directly into that category
    const matchedCategory = CATEGORIES.find(c =>
      c.id === q ||
      c.label.toLowerCase() === q ||
      c.label.toLowerCase().replace(/&/g, '').replace(/ /g, '') === q.replace(/&/g, '').replace(/ /g, '')
    );

    if (matchedCategory) {
      const cmds = resolveCategoryCommands(client, matchedCategory.id);
      const payload = buildCategoryPayload(matchedCategory, cmds, 0, client, prefix, interaction.user);
      return interaction.reply(payload);
    }

    // 4. Query is a Command Name, Alias, or Short-Form Shortcut -> Render detailed command guide
    const cmd = findCommandOrAlias(client, q);
    if (cmd) {
      if (isOwnerCommand(cmd, q) && !isOwner(interaction.user.id)) {
        return interaction.reply({
          content: 'Access denied: This command is restricted to bot owners.',
          flags: MessageFlags.Ephemeral
        });
      }

      const payload = buildCommandPayload(cmd, client, prefix, interaction.user);
      return interaction.reply(payload);
    }

    // 5. Command Not Found
    const allNames = Array.from(client.commands?.keys?.() || []).filter(n => {
      const c = client.commands.get(n);
      return !isOwnerCommand(c, n);
    });
    const matches = allNames.filter(n => n.includes(q) || q.includes(n)).slice(0, 4);

    const notFoundEmbed = createEmbed({
      color: client?.config?.COLORS?.DANGER || 0xED4245,
      title: 'Command Not Found',
      description: `Could not find any command or category named \`${query}\`.`
    });

    if (matches.length > 0) {
      notFoundEmbed.addFields({
        name: 'Did you mean?',
        value: matches.map((m, i) => `${i + 1}. \`${prefix}${m}\``).join('\n')
      });
    } else {
      notFoundEmbed.addFields({
        name: 'Tip',
        value: `Type \`/help\` to browse all available categories.`
      });
    }

    return interaction.reply({ embeds: [notFoundEmbed], components: createCommandComponents() });
  },

  async execute(message, args, client, prefix) {
    const query = args.join(' ').trim();

    // 1. No Query -> Render Main Sleek Category Selection Hub
    if (!query) {
      const payload = buildHomePayload(client, prefix, message.author, message.guild?.id);
      return message.reply(payload);
    }

    const q = query.toLowerCase();

    // 2. Special Guard: Owner Help Request
    if (q === 'owner' || q === 'dev' || q === 'developer' || q === 'ownerhelp' || q === 'owner & dev') {
      if (!isOwner(message.author.id)) {
        return message.reply('Access denied: Owner commands are restricted to bot owners.');
      }
      return message.reply(`Bot owner commands are accessible exclusively via \`${prefix}ownerhelp\`.`);
    }

    // 2b. Restrict owner command names
    if (isOwnerCommand(null, q) && !isOwner(message.author.id)) {
      return message.reply('Access denied: This command is restricted to bot owners.');
    }

    // 3. Query is a Category Name -> Jump directly into that category
    const matchedCategory = CATEGORIES.find(c =>
      c.id === q ||
      c.label.toLowerCase() === q ||
      c.label.toLowerCase().replace(/&/g, '').replace(/ /g, '') === q.replace(/&/g, '').replace(/ /g, '')
    );

    if (matchedCategory) {
      const cmds = resolveCategoryCommands(client, matchedCategory.id);
      const payload = buildCategoryPayload(matchedCategory, cmds, 0, client, prefix, message.author);
      return message.reply(payload);
    }

    // 4. Query is a Command Name, Alias, or Short-Form Shortcut -> Render detailed command guide
    const cmd = findCommandOrAlias(client, q);
    if (cmd) {
      if (isOwnerCommand(cmd, q) && !isOwner(message.author.id)) {
        return message.reply('Access denied: This command is restricted to bot owners.');
      }

      const payload = buildCommandPayload(cmd, client, prefix, message.author);
      return message.reply(payload);
    }

    // 5. Command Not Found -> Close matches suggestions with navigation buttons
    const allNames = Array.from(client.commands?.keys?.() || []).filter(n => {
      const c = client.commands.get(n);
      return !isOwnerCommand(c, n);
    });
    const matches = allNames.filter(n => n.includes(q) || q.includes(n)).slice(0, 4);

    const notFoundEmbed = createEmbed({
      color: client?.config?.COLORS?.DANGER || 0xED4245,
      title: 'Command Not Found',
      description: `Could not find any command or category named \`${query}\`.`
    });

    if (matches.length > 0) {
      notFoundEmbed.addFields({
        name: 'Did you mean?',
        value: matches.map((m, i) => `${i + 1}. \`${prefix}${m}\``).join('\n')
      });
    } else {
      notFoundEmbed.addFields({
        name: 'Tip',
        value: `Type \`${prefix}help\` to browse all available categories.`
      });
    }

    return message.reply({ embeds: [notFoundEmbed], components: createCommandComponents() });
  }
};
