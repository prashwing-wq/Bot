/**
 * Tungsten Suggestion Channel Command (Node.js)
 * Configures the target channel for community suggestions.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'suggestchannel',
  description: 'Set or view the dedicated suggestions channel.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'utility',
  usage: 'suggestchannel [#channel|id|reset]',
  aliases: ['suggest-channel', 'suggestionchannel'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) && !hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need `Manage Server` permission to configure the suggestion channel.'
          })
        ]
      });
    }

    const sdb = getServerDb(message.guild.id);

    if (!args[0]) {
      const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'suggestion_channel'").get();
      const chDesc = (row && row.value) ? `<#${row.value}> (\`${row.value}\`)` : '*Not set (defaults to channel where command is run)*';

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: '💡 Suggestion Channel Configuration',
            description: `**Current Channel:** ${chDesc}\n\n*To update: \`${prefix}suggestchannel <#channel>\`*\n*To reset: \`${prefix}suggestchannel reset\`*`
          })
        ]
      });
    }

    if (args[0].toLowerCase() === 'reset') {
      sdb.prepare("DELETE FROM server_settings WHERE key = 'suggestion_channel'").run();
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: 'Suggestion Channel Reset',
            description: 'The suggestion channel has been cleared.'
          })
        ]
      });
    }

    const channel = message.mentions?.channels?.first() ||
      message.guild.channels.cache.get(args[0]) ||
      await message.guild.channels.fetch(args[0]).catch(() => null);

    if (!channel || !channel.isTextBased()) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Invalid Channel',
            description: 'Please specify a valid text channel.\nExample: `!suggestchannel #suggestions`'
          })
        ]
      });
    }

    sdb.prepare(`
      INSERT INTO server_settings (key, value) VALUES ('suggestion_channel', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(channel.id);

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '💡 Suggestion Channel Configured',
          description: `All future suggestions will be posted to ${channel} (\`${channel.id}\`).`
        })
      ]
    });
  }
};
