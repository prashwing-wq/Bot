/**
 * Tungsten Discord Native Poll Command (Node.js)
 * Creates Discord platform-native interactive message polls.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits
} = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

const ALLOWED_DURATIONS = [1, 4, 8, 24, 72, 168];

function normalizeDuration(hours) {
  const h = parseInt(hours, 10);
  if (ALLOWED_DURATIONS.includes(h)) return h;
  // Pick closest allowed duration
  return ALLOWED_DURATIONS.reduce((prev, curr) =>
    Math.abs(curr - h) < Math.abs(prev - h) ? curr : prev, 24
  );
}

module.exports = {
  name: 'discordpoll',
  aliases: ['dpoll', 'nativepoll'],
  category: 'utility',
  description: 'Create a Discord platform-native interactive poll.',
  usage: '<question> | <option1> | <option2> [| <option3> ...]',
  cooldown: 3,
  permissions: ['SendMessages'],
  botPermissions: ['SendMessages'],

  slash: new SlashCommandBuilder()
    .setName('discordpoll')
    .setDescription('Create a Discord platform-native interactive poll.')
    .addStringOption(opt =>
      opt
        .setName('question')
        .setDescription('The question for the poll.')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt
        .setName('option1')
        .setDescription('First poll option.')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt
        .setName('option2')
        .setDescription('Second poll option.')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt
        .setName('option3')
        .setDescription('Third poll option (optional).')
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt
        .setName('option4')
        .setDescription('Fourth poll option (optional).')
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt
        .setName('option5')
        .setDescription('Fifth poll option (optional).')
        .setRequired(false)
    )
    .addIntegerOption(opt =>
      opt
        .setName('duration')
        .setDescription('Poll duration in hours (default: 24).')
        .setRequired(false)
        .addChoices(
          { name: '1 Hour', value: 1 },
          { name: '4 Hours', value: 4 },
          { name: '8 Hours', value: 8 },
          { name: '24 Hours (1 Day)', value: 24 },
          { name: '72 Hours (3 Days)', value: 72 },
          { name: '168 Hours (1 Week)', value: 168 }
        )
    )
    .addBooleanOption(opt =>
      opt
        .setName('allow_multiselect')
        .setDescription('Allow users to select multiple options.')
        .setRequired(false)
    ),

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be executed inside a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.SendMessages)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Send Messages** permission to create polls.');
    }

    let rawInput = '';
    if (args && args.length > 0) {
      if (message.content && message.content.includes(args[0])) {
        rawInput = message.content.slice(message.content.indexOf(args[0])).trim();
      } else {
        rawInput = args.join(' ');
      }
    }

    if (!rawInput || !rawInput.includes('|')) {
      const helpEmbed = createEmbed({
        color: 0x5865F2,
        title: '<a:tungsten_discordpoll:1569329347171590216> Discord Platform-Native Polls',
        description:
          `Create a native Discord interactive voting poll directly in this channel.\n\n` +
          `**Syntax:**\n\`${prefix}discordpoll <question> | <option1> | <option2> [| <option3> ...]\`\n\n` +
          `**Examples:**\n` +
          `• \`${prefix}discordpoll What game tonight? | Minecraft | Valorant | Among Us\`\n` +
          `• \`${prefix}discordpoll Pizza or Tacos? | Pizza | Tacos\`\n` +
          `• \`${prefix}discordpoll Best anime? --multi | Naruto | One Piece | Bleach\``,
        footerText: 'Supports 2 to 10 options • Up to 55 characters per option'
      });
      return message.reply({ embeds: [helpEmbed] });
    }

    const parts = rawInput.split('|').map(p => p.trim()).filter(Boolean);

    if (parts.length < 3) {
      return message.reply(
        `<a:tungsten_close:1567234632905138206> A poll requires a question and at least 2 options.\n` +
        `Usage: \`${prefix}discordpoll <question> | <option1> | <option2> [| <option3> ...]\``
      );
    }

    let question = parts[0];
    let allowMultiselect = false;
    let durationHours = 24;

    // Check flags in question
    if (/--multi\b/i.test(question)) {
      allowMultiselect = true;
      question = question.replace(/--multi\b/gi, '').trim();
    }

    const durationMatch = question.match(/--duration=(\d+)/i);
    if (durationMatch) {
      durationHours = normalizeDuration(durationMatch[1]);
      question = question.replace(/--duration=\d+/gi, '').trim();
    }

    if (question.length === 0) {
      return message.reply('<a:tungsten_close:1567234632905138206> Poll question cannot be empty.');
    }

    const options = parts.slice(1).map(opt => opt.slice(0, 55)).filter(Boolean);

    if (options.length < 2) {
      return message.reply('<a:tungsten_close:1567234632905138206> Please provide at least 2 valid options.');
    }

    if (options.length > 10) {
      return message.reply('<a:tungsten_close:1567234632905138206> Discord native polls support a maximum of 10 options.');
    }

    const answers = options.map(opt => ({ text: opt }));

    const pollPayload = {
      question: { text: question.slice(0, 300) },
      answers,
      duration: durationHours,
      allowMultiselect
    };

    try {
      await message.channel.send({ poll: pollPayload });
      // Delete triggering message if permissions allow for clean presentation
      if (message.deletable) {
        await message.delete().catch(() => null);
      }
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create native poll: ${err.message}`);
    }
  },

  async executeSlash(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    const question = interaction.options.getString('question');
    if (!question) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Please provide a question for the poll.', ephemeral: true });
    }
    const opt1 = interaction.options.getString('option1');
    const opt2 = interaction.options.getString('option2');
    const opt3 = interaction.options.getString('option3');
    const opt4 = interaction.options.getString('option4');
    const opt5 = interaction.options.getString('option5');
    const duration = interaction.options.getInteger('duration') || 24;
    const allowMultiselect = interaction.options.getBoolean('allow_multiselect') || false;

    const rawOptions = [opt1, opt2, opt3, opt4, opt5].filter(Boolean);
    const answers = rawOptions.map(opt => ({ text: opt.slice(0, 55) }));

    const pollPayload = {
      question: { text: question.slice(0, 300) },
      answers,
      duration,
      allowMultiselect
    };

    try {
      return await interaction.reply({ poll: pollPayload });
    } catch (err) {
      return await interaction.reply({ content: `<a:tungsten_close:1567234632905138206> Failed to create native poll: ${err.message}`, ephemeral: true });
    }
  }
};
