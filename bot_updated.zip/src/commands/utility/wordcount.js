/**
 * Tungsten Text Analytics & Word Count Command (Node.js)
 * Computes words, characters, readability timings, structure, and top word frequencies.
 */
const { createV2Card } = require('../../utils/componentsV2');

function formatReadingTime(words) {
  if (words <= 0) return '0 sec';
  const seconds = Math.round(words / (225 / 60));
  if (seconds < 60) return `${Math.max(1, seconds)} sec`;
  const mins = Math.floor(seconds / 60);
  const remSecs = seconds % 60;
  return remSecs > 0 ? `${mins}m ${remSecs}s` : `${mins}m`;
}

function formatSpeakingTime(words) {
  if (words <= 0) return '0 sec';
  const seconds = Math.round(words / (135 / 60));
  if (seconds < 60) return `${Math.max(1, seconds)} sec`;
  const mins = Math.floor(seconds / 60);
  const remSecs = seconds % 60;
  return remSecs > 0 ? `${mins}m ${remSecs}s` : `${mins}m`;
}

function getTopWords(text, limit = 5) {
  const rawWords = text.trim().split(/\s+/).filter(w => w.length > 0);
  if (rawWords.length === 0) return [];

  const counts = new Map();
  for (const raw of rawWords) {
    const cleaned = raw.toLowerCase().replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, '');
    if (!cleaned) continue;
    counts.set(cleaned, (counts.get(cleaned) || 0) + 1);
  }

  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, limit)
    .map(([word, count]) => ({
      word,
      count,
      percentage: ((count / rawWords.length) * 100).toFixed(1)
    }));
}

function analyzeText(text) {
  const trimmed = text.trim();
  const rawWords = trimmed.length > 0 ? trimmed.split(/\s+/).filter(w => w.length > 0) : [];
  const totalWords = rawWords.length;
  const totalChars = text.length;
  const charsNoSpaces = text.replace(/\s+/g, '').length;
  const lines = text.length > 0 ? text.split(/\r?\n/).length : 0;
  const paragraphs = trimmed.length > 0
    ? text.split(/\n\s*\n/).filter(p => p.trim().length > 0).length
    : 0;
  const sentences = trimmed.length > 0
    ? text.split(/[.!?]+/).filter(s => s.trim().length > 0).length
    : 0;

  const readingTime = formatReadingTime(totalWords);
  const speakingTime = formatSpeakingTime(totalWords);
  const topWords = getTopWords(text, 5);

  return {
    totalWords,
    totalChars,
    charsNoSpaces,
    lines,
    paragraphs,
    sentences,
    readingTime,
    speakingTime,
    topWords
  };
}

module.exports = {
  name: 'wordcount',
  aliases: ['wc', 'words', 'textstats'],
  category: 'utility',
  description: 'Analyze word count, character count, estimated reading time, and word frequencies.',
  usage: '<text>',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 2,

  async execute(message, args, client, prefix = '!') {
    const text = args.join(' ').trim();

    if (!text) {
      const card = createV2Card({
        color: 0x5865F2,
        title: '<a:tungsten_wordcount:1569329764508893246> Tungsten • Text Analytics & Word Count',
        description:
          `Analyze text composition, metrics, readability duration, and keyword frequencies.\n\n` +
          `**Usage:**\n` +
          `• \`${prefix}wordcount <text>\`\n` +
          `• \`${prefix}wc <text>\`\n\n` +
          `**Example:**\n` +
          `• \`${prefix}wc The quick brown fox jumps over the lazy dog.\``,
        footerText: `Requested by ${message.author?.username || 'User'}`
      });
      return message.reply({ embeds: [card] });
    }

    const stats = analyzeText(text);

    let topWordsDesc = '*No distinct words detected.*';
    if (stats.topWords.length > 0) {
      topWordsDesc = stats.topWords
        .map((item, idx) => `**${idx + 1}.** \`${item.word}\` — **${item.count}** (${item.percentage}%)`)
        .join('\n');
    }

    const card = createV2Card({
      color: 0x00FF88,
      title: '<a:tungsten_wordcount:1569329764508893246> Tungsten • Text Analytics & Word Count',
      description:
        `> **Text Telemetry:** Analysis of **${stats.totalWords.toLocaleString()}** words\n\n` +
        `**<a:tungsten_chart:1567234342701367357> Count Metrics:**\n` +
        `• **Words:** \`${stats.totalWords.toLocaleString()}\`\n` +
        `• **Characters (all):** \`${stats.totalChars.toLocaleString()}\`\n` +
        `• **Characters (no spaces):** \`${stats.charsNoSpaces.toLocaleString()}\`\n\n` +
        `**<a:tungsten_stopwatch:1567242453562687558> Estimated Timings:**\n` +
        `• **Reading Time:** \`${stats.readingTime}\` *(~225 WPM)*\n` +
        `• **Speaking Time:** \`${stats.speakingTime}\` *(~135 WPM)*\n\n` +
        `**<a:tungsten_clipboard:1567234610176204900> Document Structure:**\n` +
        `• **Lines:** \`${stats.lines.toLocaleString()}\`\n` +
        `• **Sentences:** \`${stats.sentences.toLocaleString()}\`\n` +
        `• **Paragraphs:** \`${stats.paragraphs.toLocaleString()}\`\n\n` +
        `**<a:tungsten_trophy:1567242918446501939> Top 5 Word Frequencies:**\n${topWordsDesc}`,
      footerText: `Requested by ${message.author?.username || 'User'}`
    });

    return message.reply({ embeds: [card] });
  },

  analyzeText,
  formatReadingTime,
  formatSpeakingTime,
  getTopWords
};
