/**
 * Permissions Inspector Command (Node.js)
 * Evaluates channel-specific and guild-wide administrative and general permissions.
 */
const permsCmd = require('./perms');

module.exports = {
  ...permsCmd,
  name: 'permissions',
  aliases: ['perms', 'botperms', 'myperms', 'userperms'],
  description: 'Member\'s effective channel permissions.'
};
