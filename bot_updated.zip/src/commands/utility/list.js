/**
 * Server Entity List Command (Node.js)
 * Clean, organized listing for boosters, role members, emojis, bots, administrators,
 * active voice channel members, earliest joiners, and guild roles.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'list',
  aliases: ['showlist', 'l'],
  category: 'utility',
  description: 'Lists boosters, inrole members, emojis, bots, admins, voice members, early joiners, or roles.',
  usage: '<boosters | inrole <@role> | emojis | bots | admins | invoice | early | roles>',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sub = (args[0] || '').toLowerCase();

    switch (sub) {
      case 'boosters':
      case 'booster':
        return this.handleBoosters(message, client);
      case 'inrole':
      case 'role':
        return this.handleInRole(message, args.slice(1), client, prefix);
      case 'emojis':
      case 'emoji':
        return this.handleEmojis(message, client);
      case 'bots':
      case 'bot':
        return this.handleBots(message, client);
      case 'admins':
      case 'admin':
      case 'staff':
        return this.handleAdmins(message, client);
      case 'invoice':
      case 'invc':
      case 'voice':
        return this.handleInVoice(message, client);
      case 'early':
      case 'oldest':
        return this.handleEarly(message, client);
      case 'roles':
        return this.handleRoles(message, client);
      default: {
        const embed = createEmbed({
          color: 0x2b2d31,
          title: '📋  Server Directory & List Directory',
          description:
            `> Browse detailed server directory listings.\n\n` +
            `• **\`${prefix}list boosters\`** — Server Nitro boosters & boost tenure\n` +
            `• **\`${prefix}list inrole <@role>\`** — Members assigned a specific role\n` +
            `• **\`${prefix}list emojis\`** — Complete server custom emoji directory\n` +
            `• **\`${prefix}list bots\`** — All registered bots in the server\n` +
            `• **\`${prefix}list admins\`** — Members with Administrator permissions\n` +
            `• **\`${prefix}list invoice\`** — Members currently connected to voice channels\n` +
            `• **\`${prefix}list early\`** — Earliest server members sorted by join date\n` +
            `• **\`${prefix}list roles\`** — All server roles and their member counts`
        });
        return message.reply({ embeds: [embed] });
      }
    }
  },

  async handleBoosters(message, client) {
    const guild = message.guild;
    const members = guild.members?.cache ? Array.from(guild.members.cache.values()) : [];
    const boosters = members
      .filter(m => m && m.premiumSinceTimestamp)
      .sort((a, b) => (a.premiumSinceTimestamp || 0) - (b.premiumSinceTimestamp || 0));

    if (boosters.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> This server currently has no active Nitro boosters recorded in cache.');
    }

    const lines = boosters.map((m, i) => {
      const ts = Math.floor(m.premiumSinceTimestamp / 1000);
      return `\`${i + 1}.\` <@${m.id}> (${m.user?.username || 'Unknown'}) — Boosting since <t:${ts}:d> (<t:${ts}:R>)`;
    });

    const embed = createEmbed({
      color: 0xF47FFF,
      title: `<a:tungsten_rocket:1567241971804798976>  Server Boosters (${boosters.length}) • ${guild.name}`,
      description: lines.slice(0, 25).join('\n') + (lines.length > 25 ? `\n\n*...and ${lines.length - 25} more boosters.*` : '')
    });
    return message.reply({ embeds: [embed] });
  },

  async handleInRole(message, args, client, prefix) {
    const guild = message.guild;
    if (!args[0]) {
      return message.reply(`Usage: \`${prefix}list inrole <@role|ID|name>\``);
    }

    const roleMention = message.mentions.roles.first();
    const roleId = args[0].replace(/[<@&>]/g, '');
    const role = roleMention
      || guild.roles.cache.get(roleId)
      || guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLowerCase());

    if (!role) {
      return message.reply('<a:tungsten_close:1567234632905138206> Could not find that role in this server.');
    }

    const members = guild.members?.cache ? Array.from(guild.members.cache.values()) : [];
    const inRoleMembers = members.filter(m => m && m.roles?.cache?.has(role.id));

    if (inRoleMembers.length === 0) {
      return message.reply(`<a:tungsten_info:1567240890748248084> No members currently possess the ${role} role.`);
    }

    const lines = inRoleMembers.map((m, i) => `\`${i + 1}.\` <@${m.id}> (\`${m.user?.username || m.id}\`)`);

    const embed = createEmbed({
      color: role.color || 0x2b2d31,
      title: `👥  Members in Role: @${role.name} (${inRoleMembers.length})`,
      description: lines.slice(0, 30).join('\n') + (lines.length > 30 ? `\n\n*...and ${lines.length - 30} more members.*` : '')
    });
    return message.reply({ embeds: [embed] });
  },

  async handleEmojis(message, client) {
    const emojis = message.guild.emojis?.cache ? Array.from(message.guild.emojis.cache.values()) : [];
    if (emojis.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> This server has no custom emojis uploaded.');
    }

    const staticCount = emojis.filter(e => !e.animated).length;
    const animCount = emojis.filter(e => e.animated).length;
    const displayList = emojis.slice(0, 50).map(e => `${e}`).join(' ');

    const embed = createEmbed({
      color: 0x5865F2,
      title: `🎨  Server Emojis (${emojis.length}) • ${message.guild.name}`,
      description:
        `• **Static Emojis:** \`${staticCount}\`\n` +
        `• **Animated Emojis:** \`${animCount}\`\n` +
        `• **Total Slots Used:** \`${emojis.length}\`\n\n` +
        `### Gallery\n` +
        `${displayList}` +
        (emojis.length > 50 ? `\n\n*...and ${emojis.length - 50} more emojis.*` : '')
    });
    return message.reply({ embeds: [embed] });
  },

  async handleBots(message, client) {
    const members = message.guild.members?.cache ? Array.from(message.guild.members.cache.values()) : [];
    const bots = members.filter(m => m && m.user?.bot);

    if (bots.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> No bots detected in member cache.');
    }

    const lines = bots.map((b, i) => `\`${i + 1}.\` <@${b.id}> (\`${b.user?.tag || b.id}\`)`);

    const embed = createEmbed({
      color: 0x2b2d31,
      title: `🤖  Server Bots (${bots.length}) • ${message.guild.name}`,
      description: lines.slice(0, 30).join('\n') + (lines.length > 30 ? `\n\n*...and ${lines.length - 30} more bots.*` : '')
    });
    return message.reply({ embeds: [embed] });
  },

  async handleAdmins(message, client) {
    const members = message.guild.members?.cache ? Array.from(message.guild.members.cache.values()) : [];
    const admins = members.filter(m => m && m.permissions?.has(PermissionsBitField.Flags.Administrator));

    const lines = admins.map((m, i) => {
      const isServerOwner = m.id === message.guild.ownerId;
      return `\`${i + 1}.\` <@${m.id}> (\`${m.user?.username || m.id}\`)${isServerOwner ? ' 👑 **(Owner)**' : ''}`;
    });

    const embed = createEmbed({
      color: 0xED4245,
      title: `🛡️  Server Administrators (${admins.length}) • ${message.guild.name}`,
      description: lines.slice(0, 30).join('\n') + (lines.length > 30 ? `\n\n*...and ${lines.length - 30} more.*` : '')
    });
    return message.reply({ embeds: [embed] });
  },

  async handleInVoice(message, client) {
    const channels = message.guild.channels?.cache ? Array.from(message.guild.channels.cache.values()) : [];
    const voiceChannels = channels.filter(c => c && c.isVoiceBased?.() && c.members?.size > 0);

    if (voiceChannels.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> No members are currently active in any voice channel.');
    }

    let totalVoiceMembers = 0;
    const sections = [];

    for (const vc of voiceChannels) {
      const memberList = Array.from(vc.members.values());
      totalVoiceMembers += memberList.length;
      const names = memberList.map(m => `<@${m.id}>`).slice(0, 10).join(', ');
      const extra = memberList.length > 10 ? ` +${memberList.length - 10} more` : '';
      sections.push(`🔊 **${vc.name}** (\`${memberList.length}\`)\n> ${names}${extra}`);
    }

    const embed = createEmbed({
      color: 0x57F287,
      title: `🎙️  Active Voice Channels (${totalVoiceMembers} Connected Members)`,
      description: sections.slice(0, 15).join('\n\n')
    });
    return message.reply({ embeds: [embed] });
  },

  async handleEarly(message, client) {
    const members = message.guild.members?.cache ? Array.from(message.guild.members.cache.values()) : [];
    const sorted = members
      .filter(m => m && m.joinedTimestamp)
      .sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);

    if (sorted.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> Member join history unavailable.');
    }

    const lines = sorted.slice(0, 20).map((m, i) => {
      const ts = Math.floor(m.joinedTimestamp / 1000);
      return `\`${i + 1}.\` <@${m.id}> (\`${m.user?.username || m.id}\`) — Joined <t:${ts}:d> (<t:${ts}:R>)`;
    });

    const embed = createEmbed({
      color: 0xFEE75C,
      title: `⏳  Earliest Server Members • ${message.guild.name}`,
      description: lines.join('\n')
    });
    return message.reply({ embeds: [embed] });
  },

  async handleRoles(message, client) {
    const roles = message.guild.roles?.cache
      ? Array.from(message.guild.roles.cache.values()).filter(r => r.id !== message.guild.id)
      : [];

    roles.sort((a, b) => b.position - a.position);

    if (roles.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> No custom roles created in this server.');
    }

    const lines = roles.map((r, i) => `\`${i + 1}.\` <@&${r.id}> — \`${r.members?.size || 0}\` member(s)`);

    const embed = createEmbed({
      color: 0x5865F2,
      title: `🏷️  Server Roles (${roles.length}) • ${message.guild.name}`,
      description: lines.slice(0, 30).join('\n') + (lines.length > 30 ? `\n\n*...and ${lines.length - 30} more roles.*` : '')
    });
    return message.reply({ embeds: [embed] });
  }
};
