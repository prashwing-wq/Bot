/**
 * Terms of Service & Security Charter Command (Node.js)
 * Displays Tungsten Terms of Service, Discord ToS compliance, and server security commitment.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { EMOJIS } = require('../../utils/emojis');
const config = require('../../config');

function buildTosPayload(client, author) {
  const botUser = client?.user;
  const botName = botUser?.username || 'Tungsten';
  const botAvatar = botUser && typeof botUser.displayAvatarURL === 'function' ? botUser.displayAvatarURL({ dynamic: true }) : null;
  const supportServerUrl = config.SUPPORT_SERVER || 'https://discord.gg/tfDMjZS9YJ';

  const scrollIcon = EMOJIS.TUNGSTEN_SCROLL || '<a:tungsten_scroll:1567242059708899381>';
  const lockIcon = EMOJIS.TUNGSTEN_LOCK || '<a:tungsten_lock:1567241079030550668>';
  const shieldIcon = EMOJIS.TUNGSTEN_SHIELD || '<a:tungsten_shield:1567242104923627574>';
  const scalesIcon = EMOJIS.TUNGSTEN_SCALES || '<a:tungsten_scales:1567242041098895521>';

  const description =
    `> **${botName}** operates with an unwavering commitment to Discord platform compliance, user privacy, and unconditional server security.\n\n` +
    `### ${scrollIcon} Section 1: Full Discord ToS & Developer Policy Compliance\n` +
    `• **Strict Platform Adherence:** ${botName} operates in full compliance with the [Discord Developer Terms of Service](https://discord.com/terms), Discord Developer Policy, and [Discord Community Guidelines](https://discord.com/guidelines).\n` +
    `• **Zero Malicious Activities:** Strictly zero unauthorized scraping, zero self-botting, zero mass-DMing, and zero exploitation of Discord APIs or rate limits.\n` +
    `• **Sanctioned Gateway Operations:** All bot operations exclusively use official, documented Discord API endpoints and gateway events.\n\n` +
    `### ${lockIcon} Section 2: Privacy Policy & Zero Data Monetization\n` +
    `• **100% Free & Open Source:** User and server data is never sold, leased, rented, or shared with third parties or advertisers.\n` +
    `• **Data Minimization:** Only essential operational IDs (server IDs, channel IDs, user IDs) required for moderation, antinuke, and automod tracking are retained in server-isolated SQLite databases.\n` +
    `• **Right to Erasure:** Upon bot departure, server uninstallation, or explicit reset, all server-specific database files are immediately and permanently purged.\n\n` +
    `### ${shieldIcon} Section 3: Unconditional Server Security Commitment\n` +
    `• **Enterprise-Grade Defense:** Continuous 24/7 protection featuring fastest antinuke defense, rogue bot interception, defacement auto-healing, and webhook spam mitigation.\n` +
    `• **Dual Backup Roles:** Active \`${botName} Backup Tier I\` & \`${botName} Backup Tier II\` administrator roles anchored right below ${botName}'s highest role to guarantee continuous administrative defense and prevent lockout.\n` +
    `• **Rapid Threat Neutralization:** Unauthorized deletions or modifications of channels, roles, webhooks, bans, and server settings are intercepted and reverted in sub-second latency.\n\n` +
    `### ${scalesIcon} Section 4: Fair Play, No False Bans & Accountability\n` +
    `• **Multi-Source Attribution:** Rigorous multi-source audit log attribution and cross-verification prevent false bans and friendly fire.\n` +
    `• **Authoritative Immunities:** Configured whitelists, extra owners, and server owner immunities are authoritatively and strictly respected.\n` +
    `• **Complete Audit Transparency:** Every automated moderation and antinuke defense action is recorded in detailed server audit records and modlogs.\n`;

  const embed = createV2Card({
    title: `${botName} • Terms of Service & Security Charter`,
    description,
    footerText: `${botName} Security & Compliance Charter • Requested by ${author ? author.username : 'User'}`
  });

  if (botAvatar && typeof botAvatar === 'string' && botAvatar.startsWith('http') && embed && typeof embed.setThumbnail === 'function') {
    embed.setThumbnail(botAvatar);
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Discord Terms')
      .setStyle(ButtonStyle.Link)
      .setURL('https://discord.com/terms'),
    new ButtonBuilder()
      .setLabel('Discord Guidelines')
      .setStyle(ButtonStyle.Link)
      .setURL('https://discord.com/guidelines'),
    new ButtonBuilder()
      .setLabel('Support Server')
      .setStyle(ButtonStyle.Link)
      .setURL(supportServerUrl),
    new ButtonBuilder()
      .setCustomId('tos:security')
      .setLabel('Live Security Guarantees')
      .setStyle(ButtonStyle.Primary)
      .setEmoji(shieldIcon)
  );

  return { embeds: [embed], components: [row] };
}

module.exports = {
  name: 'tos',
  aliases: ['terms', 'termsofservice', 'privacy', 'policy-tos', 'charter'],
  category: 'utility',
  description: 'Displays Tungsten Terms of Service, Discord ToS compliance, and server security commitment.',
  usage: '',
  cooldown: 5,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  slash: new SlashCommandBuilder()
    .setName('tos')
    .setDescription('View Tungsten Terms of Service and Server Security Commitment'),

  async execute(message, args, client, prefix) {
    const payload = buildTosPayload(client, message.author);
    return message.reply(payload);
  },

  async executeSlash(interaction, client) {
    const payload = buildTosPayload(client, interaction.user);
    return interaction.reply(payload);
  },

  buildTosPayload
};
