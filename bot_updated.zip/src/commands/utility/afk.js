/**
 * AFK Command
 * Sets away-from-keyboard status and enables automatic tag DM reminders.
 */
const { createEmbed } = require('../../utils/tools');
const { setAfkStatus } = require('../../utils/pingsDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'afk',
  description: 'Mark yourself as AFK with automatic chat notices and DM reminders when tagged.',
  category: 'utility',
  usage: 'afk [reason]',
  aliases: ['away'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    let reason = args.join(' ') || 'AFK';

    // Prevent advertisement links in AFK reason
    if (reason.toLowerCase().includes('discord.gg/') || reason.toLowerCase().includes('discord.com/invite/')) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Invalid AFK Reason',
            description: 'You cannot include server invite links in your AFK reason.'
          })
        ]
      });
    }

    if (reason.length > 200) {
      reason = reason.slice(0, 197) + '...';
    }

    setAfkStatus(message.author.id, message.guild.id, reason, 1);

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '💤 AFK Status Set',
          description: `I have set your AFK status to: **${reason}**\n\n` +
            `• When someone mentions or tags you, I will inform them in chat.\n` +
            `• You will receive direct message reminders with jump links.\n` +
            `• Send any message in this server to automatically remove your AFK status.`,
          footer: 'Tungsten AFK & Mention Reminder Subsystem'
        })
      ]
    });
  }
};
