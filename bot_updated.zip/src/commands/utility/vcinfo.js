/**
 * Voice Channel Telemetry Command (Node.js)
 * Displays detailed telemetry for the active or specified voice channel.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'vcinfo',
  aliases: ['voiceinfo', 'vcstatusinfo'],
  category: 'utility',
  description: 'Active VC status (Bitrate, User limit, Voice region, Active members).',
  usage: '[#channel]',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const targetInput = args[0];
    let vc = null;
    if (targetInput) {
      const cleanId = targetInput.replace(/[<#>]/g, '');
      vc = message.guild.channels.cache.get(cleanId)
        || message.guild.channels.cache.find(c => c.isVoiceBased?.() && c.name.toLowerCase() === targetInput.toLowerCase());
    }

    if (!vc) {
      vc = message.member?.voice?.channel;
    }

    if (!vc || !vc.isVoiceBased?.()) {
      return message.reply('<a:tungsten_warn:1567246685082746940> You must be connected to a voice channel or specify one: `vcinfo [#channel]`');
    }

    const members = vc.members ? Array.from(vc.members.values()) : [];
    const memberMentions = members.map(m => `<@${m.id}>`).slice(0, 15).join(', ');
    const extra = members.length > 15 ? ` +${members.length - 15} more` : '';

    const embed = createEmbed({
      color: 0x5865F2,
      title: `🔊  Voice Channel Telemetry • #${vc.name}`,
      description:
        `> Live channel diagnostics and member metrics.\n\n` +
        `• **Channel ID:** \`${vc.id}\`\n` +
        `• **Category:** ${vc.parent ? `${vc.parent.name}` : '*None*'}\n` +
        `• **Bitrate:** \`${vc.bitrate ? Math.round(vc.bitrate / 1000) : 64} kbps\`\n` +
        `• **User Limit:** \`${vc.userLimit > 0 ? `${vc.userLimit} members` : 'Unlimited'}\`\n` +
        `• **Voice Region:** \`${vc.rtcRegion || 'Automatic'}\`\n` +
        `• **Active Members:** \`${members.length}\` connected\n\n` +
        `**Connected Members:**\n` +
        (members.length > 0 ? `${memberMentions}${extra}` : '*Channel is currently empty.*')
    });

    return message.reply({ embeds: [embed] });
  }
};
