/**
 * Boost Count & Perks Telemetry Command (Node.js)
 * Displays server boost level, total boosts, progress to next tier, and unlocked perks.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'boostcount',
  aliases: ['boostlevel', 'serverboosts', 'boostsinfo'],
  category: 'utility',
  description: 'Guild boost level, boost count, and boost vanity/perks.',
  usage: '',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const guild = message.guild;
    const tier = guild.premiumTier || 0;
    const count = guild.premiumSubscriptionCount || 0;

    let nextTierGoal = 2;
    let nextTierName = 'Tier 1';
    if (tier === 1) {
      nextTierGoal = 7;
      nextTierName = 'Tier 2';
    } else if (tier === 2) {
      nextTierGoal = 14;
      nextTierName = 'Tier 3';
    } else if (tier >= 3) {
      nextTierGoal = 14;
      nextTierName = 'Max Level';
    }

    const needed = Math.max(0, nextTierGoal - count);
    const vanityCode = guild.vanityURLCode ? `discord.gg/${guild.vanityURLCode}` : '*Not unlocked or unset*';

    const perks = [
      '• 50 Emoji Slots • 128 Kbps Audio • 25 MB Upload Limit',
      '• 100 Emoji Slots • 128 Kbps Audio • 50 MB Upload Limit • Custom Server Invite Background',
      '• 150 Emoji Slots • 256 Kbps Audio • 50 MB Upload Limit • Server Banner • 1080p 60fps Stream',
      '• 250 Emoji Slots • 384 Kbps Audio • 100 MB Upload Limit • Custom Vanity URL (discord.gg/...)'
    ];

    const embed = createEmbed({
      color: 0xF47FFF,
      title: `<a:tungsten_rocket:1567241971804798976>  Server Boost Telemetry • ${guild.name}`,
      description:
        `> Detailed Nitro boost progression and unlocked server perks.\n\n` +
        `• **Current Level:** **Tier ${tier}**\n` +
        `• **Total Boosts:** **${count}** boost(s)\n` +
        `• **Vanity URL:** \`${vanityCode}\`\n` +
        (tier >= 3
          ? `• **Status:** 🌟 **Maximum Boost Tier Unlocked!**\n\n`
          : `• **Next Level:** Needs **${needed}** more boost(s) for **${nextTierName}**\n\n`) +
        `### Unlocked Perks (Tier ${tier})\n` +
        `${perks[tier] || perks[0]}`
    });

    return message.reply({ embeds: [embed] });
  }
};
