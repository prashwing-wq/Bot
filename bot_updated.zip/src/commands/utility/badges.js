/**
 * User Badges Command (Node.js)
 * Displays a user's Discord profile badges, staff/partner indicators, and developer honors.
 */
const { UserFlagsBitField } = require('discord.js');
const { createEmbed } = require('../../utils/tools');

const BADGE_MAP = {
  Staff: '🛡️ Discord Employee',
  Partner: '🤝 Partnered Server Owner',
  Hypesquad: '✨ HypeSquad Events',
  BugHunterLevel1: '🐛 Bug Hunter Level 1',
  BugHunterLevel2: '🐛 Bug Hunter Level 2',
  HypeSquadOnlineHouse1: '🏠 HypeSquad Bravery',
  HypeSquadOnlineHouse2: '🏠 HypeSquad Brilliance',
  HypeSquadOnlineHouse3: '🏠 HypeSquad Balance',
  PremiumEarlySupporter: '💎 Early Supporter',
  VerifiedBot: '🤖 Verified Bot',
  VerifiedDeveloper: '👨‍💻 Early Verified Bot Developer',
  ActiveDeveloper: '⚙️ Active Developer',
  CertifiedModerator: '🎓 Certified Discord Moderator'
};

module.exports = {
  name: 'badges',
  aliases: ['userbadges', 'profilebadges'],
  category: 'utility',
  description: 'Displays a user\'s Discord badges breakdown.',
  usage: '[user]',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    let targetUser = message.author;
    if (args[0]) {
      const cleanId = args[0].replace(/[<@!>]/g, '');
      try {
        targetUser = await client.users.fetch(cleanId, { force: true }).catch(() => null);
      } catch (_) {}
    } else {
      try {
        targetUser = await client.users.fetch(message.author.id, { force: true }).catch(() => message.author);
      } catch (_) {
        targetUser = message.author;
      }
    }

    if (!targetUser) {
      return message.reply('<a:tungsten_close:1567234632905138206> Could not find that user.');
    }

    let flags = [];
    try {
      const fetchedFlags = await targetUser.fetchFlags().catch(() => null);
      flags = fetchedFlags ? fetchedFlags.toArray() : (targetUser.flags?.toArray?.() || []);
    } catch (_) {
      flags = targetUser.flags?.toArray?.() || [];
    }

    const badgeList = flags.map(f => BADGE_MAP[f] || `🏅 ${f}`);

    if (badgeList.length === 0) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0x2b2d31,
            title: `🏅  User Badges • ${targetUser.username}`,
            description: `> **${targetUser.username}** does not have any public Discord profile badges.`
          })
        ]
      });
    }

    const embed = createEmbed({
      color: 0x5865F2,
      title: `🏅  User Badges (${badgeList.length}) • ${targetUser.username}`,
      description:
        `> Public Discord honors and program badges.\n\n` +
        badgeList.map(b => `• ${b}`).join('\n')
    });

    if (typeof targetUser.displayAvatarURL === 'function') {
      const avatar = targetUser.displayAvatarURL({ dynamic: true });
      if (typeof avatar === 'string' && avatar.startsWith('http')) {
        embed.setThumbnail(avatar);
      }
    }

    return message.reply({ embeds: [embed] });
  }
};
