/**
 * User Banner Command (Node.js)
 * Fetches and displays a user's profile banner using Discord REST API fallback.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'banner',
  aliases: ['userbanner'],
  category: 'utility',
  description: 'Displays a user\'s profile banner.',
  usage: '[user]',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    let targetUser = message.author;
    if (args[0]) {
      const cleanId = args[0].replace(/[<@!>]/g, '');
      try {
        targetUser = await client.users.fetch(cleanId, { force: true }).catch(() => null);
      } catch (_) {}
    } else {
      // Force-fetch author to ensure banner data is populated
      try {
        targetUser = await client.users.fetch(message.author.id, { force: true }).catch(() => message.author);
      } catch (_) {
        targetUser = message.author;
      }
    }

    if (!targetUser) {
      return message.reply('<a:tungsten_close:1567234632905138206> Could not find that user.');
    }

    const bannerUrl = typeof targetUser.bannerURL === 'function'
      ? targetUser.bannerURL({ size: 1024, dynamic: true })
      : null;

    if (!bannerUrl) {
      const colorHex = targetUser.accentColor ? `#${targetUser.accentColor.toString(16).padStart(6, '0')}` : null;
      return message.reply({
        embeds: [
          createEmbed({
            color: targetUser.accentColor || 0x2b2d31,
            title: `🎨  Profile Banner • ${targetUser.username}`,
            description: colorHex
              ? `> **${targetUser.username}** does not have an image banner, but uses solid accent color \`${colorHex}\`.`
              : `> **${targetUser.username}** does not have a custom profile banner set.`
          })
        ]
      });
    }

    const embed = createEmbed({
      color: targetUser.accentColor || 0x2b2d31,
      title: `🖼️  Profile Banner • ${targetUser.username}`,
      description: `[Direct Banner Link (1024x1024)](${bannerUrl})`
    });

    if (typeof bannerUrl === 'string' && bannerUrl.startsWith('http')) {
      embed.setImage(bannerUrl);
    }

    return message.reply({ embeds: [embed] });
  }
};
