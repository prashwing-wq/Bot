/**
 * Prefix Command
 */
const { PermissionFlagsBits } = require('discord.js');
const { hasPerm, getConfig, setPrefix, isOwner, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'prefix',
  aliases: ['setprefix'],
  category: 'utility',
  description: 'View or set the custom prefix for this server.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[new_prefix]',
  cooldown: 3,
  async execute(message, args, client, currentPrefix) {
    if (!message.guild) {
      return message.reply(`Default prefix is \`${client.config.DEFAULT_PREFIX}\`.`);
    }

    const newPrefix = args[0]?.trim();
    if (!newPrefix) {
      const cfg = getConfig(message.guild.id);
      return message.reply({
        embeds: [
          createEmbed({
            title: 'Server Prefix',
            description: `The prefix for **${message.guild.name}** is currently set to \`${cfg.prefix}\`.\nTo change it, use \`${cfg.prefix}prefix <new_prefix>\`.`
          })
        ]
      });
    }

    // Permission Check: ManageGuild or Bot Owner
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('You need the **Manage Server** permission to change the prefix.');
    }

    if (newPrefix.length > 5) {
      return message.reply('Prefix length cannot exceed 5 characters.');
    }

    setPrefix(message.guild.id, newPrefix);

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: 'Prefix Updated',
          description: `Server prefix updated to \`${newPrefix}\`.\nExample: \`${newPrefix}help\``
        })
      ]
    });
  }
};
