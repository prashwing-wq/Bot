/**
 * Tungsten Community Poll Command (Node.js)
 * Interactive polls with persistent single/multi-choice voting and live visual progress bars.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SlashCommandBuilder,
  PermissionsBitField,
  MessageFlags
} = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { isModuleEnabled } = require('../../utils/modulesHelper');

const NUMBER_EMOJIS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

function renderProgressBar(percentage, length = 12) {
  const filledCount = Math.round((percentage / 100) * length);
  const emptyCount = length - filledCount;
  return '▰'.repeat(filledCount) + '▱'.repeat(emptyCount);
}

function renderPollEmbed(pollId, question, options, voteCounts, totalVotes, status = 'OPEN', client = null) {
  const isClosed = status === 'CLOSED';
  const color = isClosed
    ? (client?.config?.COLORS?.SECONDARY || 0x747f8d)
    : (client?.config?.COLORS?.PRIMARY || 0x5865F2);

  let desc = `### ${question}\n\n`;

  options.forEach((opt, idx) => {
    const count = voteCounts[idx] || 0;
    const pct = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0;
    const bar = renderProgressBar(pct, 12);
    const emoji = options.length === 2 && opt === 'Yes' ? '👍' : (options.length === 2 && opt === 'No' ? '👎' : (NUMBER_EMOJIS[idx] || '🔹'));

    desc += `${emoji} **${opt}**\n${bar} \`${pct}%\` (${count} ${count === 1 ? 'vote' : 'votes'})\n\n`;
  });

  const embed = createEmbed({
    color,
    title: `📊 Poll #${pollId}${isClosed ? ' [ENDED]' : ''}`,
    description: desc.trim(),
    timestamp: true,
    footer: {
      text: `Total Votes: ${totalVotes} • Status: ${isClosed ? 'Concluded' : 'Active Voting'}`
    }
  });

  return embed;
}

function buildPollComponents(pollId, options, isClosed = false) {
  const rows = [];
  let currentRow = new ActionRowBuilder();

  options.forEach((opt, idx) => {
    if (currentRow.components.length === 5) {
      rows.push(currentRow);
      currentRow = new ActionRowBuilder();
    }

    const emoji = options.length === 2 && opt === 'Yes' ? '👍' : (options.length === 2 && opt === 'No' ? '👎' : (NUMBER_EMOJIS[idx] || undefined));
    const label = opt.length > 20 ? opt.slice(0, 17) + '...' : opt;

    const btn = new ButtonBuilder()
      .setCustomId(`poll:vote:${pollId}:${idx}`)
      .setLabel(label)
      .setStyle(options.length === 2 ? (idx === 0 ? ButtonStyle.Success : ButtonStyle.Danger) : ButtonStyle.Secondary)
      .setDisabled(isClosed);

    if (emoji) btn.setEmoji(emoji);
    currentRow.addComponents(btn);
  });

  if (currentRow.components.length > 0) {
    rows.push(currentRow);
  }

  // Add staff end poll button if poll is open
  if (!isClosed && rows.length < 5) {
    const controlRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`poll:end:${pollId}`)
        .setLabel('End Poll')
        .setEmoji('<a:tungsten_close:1567234632905138206>')
        .setStyle(ButtonStyle.Danger)
    );
    rows.push(controlRow);
  }

  return rows;
}

module.exports = {
  name: 'poll',
  description: 'Create an interactive community poll with visual progress bars.',
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'utility',
  usage: 'poll <question> [| option 1 | option 2 | ...]',
  aliases: ['vote', 'createpoll'],
  cooldown: 5,
  renderProgressBar,
  renderPollEmbed,
  buildPollComponents,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!isModuleEnabled(message.guild.id, 'polls')) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.WARNING || 0xFEE75C,
            title: 'Module Disabled',
            description: 'The **Polls** module is currently disabled in this server.'
          })
        ]
      });
    }

    if (!args[0]) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.WARNING || 0xFEE75C,
            title: 'Invalid Usage',
            description: `**Usage:** \`${prefix}poll <question> [| option 1 | option 2 | ...]\`\n\n` +
              `**Examples:**\n` +
              `• \`${prefix}poll Should we host a community game night?\` (Yes/No)\n` +
              `• \`${prefix}poll Best Game? | Minecraft | Valorant | CS:GO | Roblox\`\n` +
              `• \`${prefix}poll end <poll_id>\` (Close active poll)`
          })
        ]
      });
    }

    const sdb = getServerDb(message.guild.id);

    // 1. End Poll Subcommand
    if (args[0].toLowerCase() === 'end' || args[0].toLowerCase() === 'close') {
      const pollId = parseInt(args[1], 10);
      if (isNaN(pollId)) {
        return message.reply(`**Usage:** \`${prefix}poll end <poll_id>\``);
      }

      const poll = sdb.prepare('SELECT * FROM polls WHERE guild_id = ? AND (id = ? OR message_id = ?)').get(message.guild.id, pollId, String(args[1]));
      if (!poll) {
        return message.reply(`Poll **#${pollId}** was not found in this server.`);
      }

      if (poll.status === 'CLOSED') {
        return message.reply(`Poll **#${poll.id}** is already closed.`);
      }

      const isStaff = hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) ||
        hasPerm(message.member, PermissionsBitField.Flags.ModerateMembers);
      if (poll.author_id !== message.author.id && !isStaff) {
        return message.reply('Only the poll creator or staff members can end this poll.');
      }

      const now = Math.floor(Date.now() / 1000);
      sdb.prepare("UPDATE polls SET status = 'CLOSED', updated_at = ? WHERE id = ?").run(now, poll.id);

      // Re-render and lock message UI
      try {
        const chan = message.guild.channels.cache.get(poll.channel_id) ||
          await message.guild.channels.fetch(poll.channel_id).catch(() => null);
        if (chan && chan.isTextBased()) {
          const pollMsg = await chan.messages.fetch(poll.message_id).catch(() => null);
          if (pollMsg) {
            const options = JSON.parse(poll.options_json);
            const votes = sdb.prepare('SELECT option_index, COUNT(*) as c FROM poll_votes WHERE guild_id = ? AND poll_id = ? GROUP BY option_index').all(message.guild.id, poll.id);
            const voteCounts = options.map((_, i) => votes.find(v => v.option_index === i)?.c || 0);
            const total = voteCounts.reduce((a, b) => a + b, 0);

            const closedEmbed = renderPollEmbed(poll.id, poll.question, options, voteCounts, total, 'CLOSED', client);
            const closedRows = buildPollComponents(poll.id, options, true);
            await pollMsg.edit({ embeds: [closedEmbed], components: closedRows }).catch(() => null);
          }
        }
      } catch (_) {}

      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.SUCCESS || 0x57F287,
            title: 'Poll Concluded',
            description: `Poll **#${poll.id}** has been closed and votes are now finalized.`
          })
        ]
      });
    }

    // 2. Create Poll
    const fullText = args.join(' ').trim();
    let question = fullText;
    let options = ['Yes', 'No'];

    if (fullText.includes('|')) {
      const parts = fullText.split('|').map(s => s.trim()).filter(Boolean);
      if (parts.length >= 2) {
        question = parts[0];
        options = parts.slice(1);
      }
    }

    if (options.length < 2 || options.length > 10) {
      return message.reply('A poll must have between 2 and 10 options.');
    }

    const now = Math.floor(Date.now() / 1000);
    const insertRes = sdb.prepare(`
      INSERT INTO polls (guild_id, channel_id, message_id, author_id, question, options_json, status, created_at, updated_at)
      VALUES (?, ?, '0', ?, ?, ?, 'OPEN', ?, ?)
    `).run(
      message.guild.id,
      message.channel.id,
      message.author.id,
      question,
      JSON.stringify(options),
      now,
      now
    );

    const pollId = insertRes.lastInsertRowid;
    const voteCounts = options.map(() => 0);
    const embed = renderPollEmbed(pollId, question, options, voteCounts, 0, 'OPEN', client);
    const components = buildPollComponents(pollId, options, false);

    try {
      const sentMsg = await message.channel.send({ embeds: [embed], components });
      sdb.prepare('UPDATE polls SET message_id = ? WHERE id = ?').run(sentMsg.id, pollId);
    } catch (err) {
      return message.reply('Failed to dispatch poll in this channel.');
    }
  }
};
