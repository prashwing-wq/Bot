/**
 * Boost Command (Node.js)
 * Displays server boost level, booster count, progress to next tier,
 * active booster list, booster role, and unlocked perks.
 * Fully compatible with Discord Slash Commands and Prefix commands.
 */
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { getGuildAccent } = require('../../utils/serverDb');

function buildBoostPayload(guild, user = null, prefix = '!') {
  const boostTier = guild.premiumTier || 0;
  const boostCount = guild.premiumSubscriptionCount || 0;

  // Next tier requirement
  let nextTier = 'Tier 1';
  let requiredForNext = 2;
  let prevTierRequirement = 0;

  if (boostTier === 0) {
    nextTier = 'Tier 1';
    requiredForNext = 2;
    prevTierRequirement = 0;
  } else if (boostTier === 1) {
    nextTier = 'Tier 2';
    requiredForNext = 7;
    prevTierRequirement = 2;
  } else if (boostTier === 2) {
    nextTier = 'Tier 3';
    requiredForNext = 14;
    prevTierRequirement = 7;
  } else {
    nextTier = 'Max Level Reached';
    requiredForNext = 14;
    prevTierRequirement = 14;
  }

  const needed = Math.max(0, requiredForNext - boostCount);
  const totalInBracket = requiredForNext - prevTierRequirement;
  const currentInBracket = Math.max(0, Math.min(totalInBracket, boostCount - prevTierRequirement));
  const percent = boostTier >= 3 ? 100 : Math.round((currentInBracket / (totalInBracket || 1)) * 100);

  // Visual progress bar
  const totalBars = 10;
  const filledBars = boostTier >= 3 ? totalBars : Math.min(totalBars, Math.round((percent / 100) * totalBars));
  const emptyBars = totalBars - filledBars;
  const progressBar = '▰'.repeat(filledBars) + '▱'.repeat(emptyBars);

  // Perks per tier
  const tierPerks = [
    '• 50 Emoji Slots • 128 Kbps Audio • 25 MB Upload Limit',
    '• 100 Emoji Slots • 128 Kbps Audio • 50 MB Upload Limit • Custom Server Invite Background • Animated Server Icon',
    '• 150 Emoji Slots • 256 Kbps Audio • 50 MB Upload Limit • Server Banner • 1080p 60fps Go Live',
    '• 250 Emoji Slots • 384 Kbps Audio • 100 MB Upload Limit • Custom Vanity URL (discord.gg/name)'
  ];

  // Active Boosters list
  let boosters = [];
  if (guild.members?.cache) {
    const memberList = typeof guild.members.cache.values === 'function'
      ? Array.from(guild.members.cache.values())
      : (Array.isArray(guild.members.cache) ? guild.members.cache : []);
    boosters = memberList
      .filter(m => m && m.premiumSinceTimestamp)
      .sort((a, b) => (b.premiumSinceTimestamp || 0) - (a.premiumSinceTimestamp || 0))
      .map(m => `<@${m.id}> (<t:${Math.floor(m.premiumSinceTimestamp / 1000)}:R>)`);
  }

  const boosterRole = guild.roles?.premiumSubscriberRole
    || (guild.roles?.cache ? guild.roles.cache.find(r => r.tags?.premiumSubscriberRole) : null);

  const boosterCountText = boosters.length > 0
    ? `**${boosters.length} active booster(s)**`
    : `**${boostCount} total boost(s)**`;

  let boosterListText = 'No active boosters recorded in member cache.';
  if (boosters.length > 0) {
    if (boosters.length <= 10) {
      boosterListText = boosters.join('\n');
    } else {
      boosterListText = boosters.slice(0, 10).join('\n') + `\n*...and ${boosters.length - 10} more*`;
    }
  }

  const accent = getGuildAccent(guild.id);
  const rocketEmoji = '<a:tungsten_rocket:1567241971804798976>';
  const starEmoji = '<a:tungsten_star:1567242331785138238>';

  const card = createV2Card({
    color: accent,
    title: `${rocketEmoji}  Server Boost Overview • ${guild.name}`,
    description:
      `> Current Level: **Tier ${boostTier}** (${boostCount} Boosts) • ${boosterCountText}\n\n` +
      `**Progress to Next Tier:**\n` +
      `\`${progressBar}\` **${percent}%**\n` +
      (boostTier >= 3
        ? `${starEmoji} **Server has unlocked maximum Boost Tier 3!**\n\n`
        : `*Needs **${needed} more boost(s)** to achieve **${nextTier}**.*\n\n`) +
      `**Server Booster Role:** ${boosterRole ? `<@&${boosterRole.id}>` : '`None`'}\n\n` +
      `**Current Tier Perks (Tier ${boostTier}):**\n` +
      `${tierPerks[boostTier] || tierPerks[0]}\n\n` +
      `**Recent Server Boosters:**\n` +
      `${boosterListText}`,
    footerText: user ? `Requested by ${user.username || user.tag}` : `Tungsten Server Telemetry • ${guild.name}`
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('boost:refresh')
      .setLabel('Refresh Boosts')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Dismiss')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [card], components: [row] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'boost',
  description: 'Display server boost level, booster count, perks, and boosters.',
  category: 'utility',
  aliases: ['boosts', 'boostcount', 'boostinfo', 'serverboost'],
  cooldown: 3,

  slash: new SlashCommandBuilder()
    .setName('boost')
    .setDescription('View server boost level, tier perks, count, and boosters.'),

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');
    const payload = buildBoostPayload(message.guild, message.author, prefix);
    return message.reply(payload);
  },

  async executeSlash(interaction, client) {
    if (!interaction.guild) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> This command can only be used in a server.', ephemeral: true });
    }
    const payload = buildBoostPayload(interaction.guild, interaction.user, '/');
    return interaction.reply(payload);
  },

  buildBoostPayload
};
