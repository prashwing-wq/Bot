/**
 * DeleteEmoji Command (Node.js)
 * Deletes a custom server emoji by name, mention, or ID.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm } = require('../../utils/tools');

module.exports = {
  name: 'deleteemoji',
  aliases: ['delemoji', 'removeemoji', 'deletesticker'],
  category: 'utility',
  description: 'Delete a custom server emoji by name, ID, or emoji mention.',
  permissions: ['ManageGuildExpressions'],
  botPermissions: ['ManageGuildExpressions'],
  usage: 'deleteemoji <emoji | name | id>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const member = message.member;
    const isAuthorized = hasPerm(member, PermissionsBitField.Flags.ManageGuildExpressions) ||
                         hasPerm(member, PermissionsBitField.Flags.ManageEmojisAndStickers) ||
                         hasPerm(member, PermissionsBitField.Flags.Administrator);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You require **Manage Expressions / Manage Emojis** permission to delete emojis.');
    }

    if (!args[0]) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}deleteemoji <emoji | name | id>\``);
    }

    const input = args[0];
    let emojiId = null;

    // Check if input is <a:name:id> or <:name:id>
    const match = input.match(/<a?:[a-zA-Z0-9_]+:(\d+)>/);
    if (match) {
      emojiId = match[1];
    } else if (/^\d{17,20}$/.test(input)) {
      emojiId = input;
    }

    let targetEmoji = null;
    if (emojiId) {
      targetEmoji = message.guild.emojis.cache.get(emojiId);
    } else {
      const cleanName = input.replace(/:/g, '').toLowerCase();
      targetEmoji = message.guild.emojis.cache.find(e => e.name.toLowerCase() === cleanName);
    }

    if (!targetEmoji) {
      return message.reply('<a:tungsten_close:1567234632905138206> No custom emoji found in this server matching that input.');
    }

    try {
      const oldName = targetEmoji.name;
      await targetEmoji.delete(`Deleted by ${message.author.tag} (${message.author.id})`);
      return message.reply(`<a:tungsten_success:1567242523468890274> Successfully deleted emoji \`:${oldName}:\` from this server.`);
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to delete emoji: \`${err.message}\``);
    }
  }
};
