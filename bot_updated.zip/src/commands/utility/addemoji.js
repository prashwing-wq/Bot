/**
 * AddEmoji / Steal Command (Node.js)
 * Adds custom animated or static emojis to the server from another emoji, URL, or replied message.
 */
const { PermissionsBitField } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { hasPerm } = require('../../utils/tools');
const https = require('node:https');
const http = require('node:http');

function fetchBuffer(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { headers: { 'User-Agent': 'TungstenBot/2.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchBuffer(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP status ${res.statusCode}`));
      }
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Request timed out'));
    });
  });
}

function parseEmojiInput(input) {
  if (!input) return null;
  // Match <a:name:id> or <:name:id>
  const match = input.match(/<(a)?:([a-zA-Z0-9_]{2,32}):(\d{17,20})>/);
  if (match) {
    const animated = Boolean(match[1]);
    const name = match[2];
    const id = match[3];
    const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}`;
    return { name, url, animated };
  }
  return null;
}

module.exports = {
  name: 'addemoji',
  aliases: ['steal', 'eadd', 'emojiadd', 'createemoji'],
  category: 'utility',
  description: 'Add or steal a custom animated/static emoji to this server.',
  permissions: ['ManageGuildExpressions'],
  botPermissions: ['ManageGuildExpressions'],
  usage: 'addemoji <emoji | url> [name] or steal <emoji>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    // Permission check
    const member = message.member;
    const isAuthorized = hasPerm(member, PermissionsBitField.Flags.ManageGuildExpressions) ||
                         hasPerm(member, PermissionsBitField.Flags.ManageEmojisAndStickers) ||
                         hasPerm(member, PermissionsBitField.Flags.Administrator);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You require **Manage Expressions / Manage Emojis** permission to use this command.');
    }

    const botMember = message.guild.members.me;
    if (!botMember.permissions.has(PermissionsBitField.Flags.ManageGuildExpressions) &&
        !botMember.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers) &&
        !botMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('<a:tungsten_close:1567234632905138206> I require **Manage Expressions / Manage Emojis** permission to create custom emojis.');
    }

    let emojiUrl = null;
    let emojiName = null;
    let isAnimated = false;

    // 1. Check referenced replied message
    if (message.reference && message.reference.messageId) {
      try {
        const refMessage = await message.channel.messages.fetch(message.reference.messageId);
        if (refMessage) {
          // Check attachments
          const att = refMessage.attachments.find(a => a.contentType?.startsWith('image/'));
          if (att) {
            emojiUrl = att.url;
            emojiName = args[0] || att.name?.split('.')[0] || 'custom_emoji';
            isAnimated = att.name?.endsWith('.gif') || att.contentType === 'image/gif';
          } else {
            // Check content for custom emoji
            const parsed = parseEmojiInput(refMessage.content);
            if (parsed) {
              emojiUrl = parsed.url;
              emojiName = args[0] || parsed.name;
              isAnimated = parsed.animated;
            }
          }
        }
      } catch (_) {}
    }

    // 2. Parse from args if not found from reply
    if (!emojiUrl && args.length > 0) {
      const firstArg = args[0];
      const parsed = parseEmojiInput(firstArg);
      if (parsed) {
        emojiUrl = parsed.url;
        emojiName = args[1] || parsed.name;
        isAnimated = parsed.animated;
      } else if (firstArg.startsWith('http://') || firstArg.startsWith('https://')) {
        emojiUrl = firstArg;
        emojiName = args[1] || 'custom_emoji';
        isAnimated = emojiUrl.toLowerCase().includes('.gif');
      }
    }

    // 3. Check attachments on current message
    if (!emojiUrl && message.attachments.size > 0) {
      const att = message.attachments.first();
      if (att && att.contentType?.startsWith('image/')) {
        emojiUrl = att.url;
        emojiName = args[0] || att.name?.split('.')[0] || 'custom_emoji';
        isAnimated = att.name?.endsWith('.gif') || att.contentType === 'image/gif';
      }
    }

    if (!emojiUrl) {
      const card = createV2Card({
        title: '🎨  Add Custom Emoji / Steal',
        description:
          `> Upload custom static or animated emojis directly to this server.\n\n` +
          `### 📖 Usage Guide\n` +
          `• **Steal an emoji:** \`${prefix}steal <:name:id>\` or \`${prefix}steal <a:name:id>\`\n` +
          `• **Add from URL:** \`${prefix}addemoji <url> [name]\`\n` +
          `• **Reply to image/emoji:** Reply to any message with \`${prefix}steal [name]\`\n` +
          `• **Upload attachment:** Attach a .png/.gif file with \`${prefix}addemoji [name]\`\n`,
        footerText: `Tungsten Emoji Suite • ${message.guild.name}`
      });
      return message.reply({ embeds: [card] });
    }

    // Sanitize name
    emojiName = (emojiName || 'custom_emoji').replace(/[^a-zA-Z0-9_]/g, '_').slice(0, 32);
    if (emojiName.length < 2) emojiName = `emoji_${emojiName}`;

    // Download buffer
    const notice = await message.reply('<a:tungsten_loading:1567241050567876698> **Downloading and optimizing emoji...**');
    try {
      const buffer = await fetchBuffer(emojiUrl);
      if (buffer.length > 256 * 1024) {
        return notice.edit('<a:tungsten_close:1567234632905138206> Emoji file size exceeds Discord limit (256 KB max).');
      }

      const created = await message.guild.emojis.create({
        attachment: buffer,
        name: emojiName,
        reason: `Added by ${message.author.tag} (${message.author.id})`
      });

      const successCard = createV2Card({
        color: 0x2ecc71,
        title: '<a:tungsten_success:1567242523468890274>  Custom Emoji Added Successfully',
        description:
          `• **Emoji:** ${created.toString()}\n` +
          `• **Name:** \`:${created.name}:\`\n` +
          `• **ID:** \`${created.id}\`\n` +
          `• **Type:** \`${created.animated ? 'Animated GIF' : 'Static PNG'}\`\n` +
          `• **Syntax:** \`${created.toString()}\`\n\n` +
          `*You can now use this emoji in any channel in this server!*`,
        footerText: `Tungsten Emoji Suite • Added by ${message.author.username}`
      });

      return notice.edit({ content: null, embeds: [successCard] });
    } catch (err) {
      return notice.edit(`<a:tungsten_close:1567234632905138206> Failed to create emoji: \`${err.message}\``);
    }
  }
};
