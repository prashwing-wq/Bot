/**
 * Invite Command (Node.js)
 * Provides official OAuth2 invite URLs for Tungsten with full Components V2 interactive links.
 */
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

function buildInvitePayload(client, author) {
  const botUser = client?.user;
  const botId = botUser?.id || config.CLIENT_ID || '';
  const botName = botUser?.username || 'Tungsten';
  const botAvatar = typeof botUser?.displayAvatarURL === 'function' ? botUser.displayAvatarURL({ dynamic: true }) : null;

  // OAuth2 invite URLs
  const adminInviteUrl = `https://discord.com/oauth2/authorize?client_id=${botId}&permissions=8&scope=bot%20applications.commands`;
  const recommendedInviteUrl = `https://discord.com/oauth2/authorize?client_id=${botId}&permissions=1101088902263&scope=bot%20applications.commands`;
  const supportServerUrl = config.SUPPORT_SERVER || 'https://discord.gg/tfDMjZS9YJ';

  const { ICONS } = require('../../ui/icons');
  const description =
    `> Elevate your Discord community with **${botName}** — an enterprise-grade defense, antinuke, and server automation framework.\n\n` +
    `### ${ICONS.shield} Core Capabilities\n` +
    `• **Antinuke 3.0 Sentinel:** 0ms gateway push threat detection & auto-revert\n` +
    `• **Automod 2.0 Engine:** 5-tier escalation ladder, phishing & duplicate spam filters\n` +
    `• **Emergency Panic Lockdown:** Instant zero-bypass server quarantine\n` +
    `• **Dual Backup Roles Safeguard:** Instant fail-safe disaster recovery\n` +
    `• **Components V2 Interactive Hub:** Modern responsive Discord UI\n\n` +
    `### ${ICONS.link} Official Invite Links\n` +
    `• [Invite with Administrator (Recommended for Defense)](${adminInviteUrl})\n` +
    `• [Invite with Standard Permissions](${recommendedInviteUrl})\n` +
    `• [Join Official Support Server](${supportServerUrl})\n`;

  const embed = createV2Card({
    color: 0x5865F2, // Discord Blurple
    title: `${ICONS.bot} Invite ${botName} to Your Server`,
    description,
    buttons: [
      { label: 'Invite (Admin)', style: ButtonStyle.Link, url: adminInviteUrl, emoji: ICONS.shield },
      { label: 'Invite (Standard)', style: ButtonStyle.Link, url: recommendedInviteUrl, emoji: ICONS.shield },
      { label: 'Support Server', style: ButtonStyle.Link, url: supportServerUrl, emoji: ICONS.link }
    ],
    buttonTitle: 'Official Links',
    footerText: `Tungsten Enterprise Defense • Requested by ${author ? author.username : 'User'}`
  });

  if (botAvatar && embed && embed.setThumbnail) {
    embed.setThumbnail(botAvatar);
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Invite (Administrator)')
      .setStyle(ButtonStyle.Link)
      .setURL(adminInviteUrl)
      .setEmoji(ICONS.shield),
    new ButtonBuilder()
      .setLabel('Invite (Standard)')
      .setStyle(ButtonStyle.Link)
      .setURL(recommendedInviteUrl)
      .setEmoji(ICONS.shield),
    new ButtonBuilder()
      .setLabel('Support Server')
      .setStyle(ButtonStyle.Link)
      .setURL(supportServerUrl)
      .setEmoji(ICONS.link)
  );

  return { embeds: [embed], components: [row] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'invite',
  aliases: ['invite-bot', 'botinvite', 'inv', 'addbot'],
  category: 'utility',
  description: 'Invite Tungsten to your Discord server with Administrator or Standard permissions.',
  usage: 'invite',
  cooldown: 3,

  slash: new SlashCommandBuilder()
    .setName('invite')
    .setDescription('Get invite link for Tungsten with Administrator or Standard permissions.'),

  async execute(message, args, client, prefix) {
    const payload = buildInvitePayload(client, message.author);
    return message.reply(payload);
  },

  async executeSlash(interaction, client) {
    const payload = buildInvitePayload(client, interaction.user);
    return interaction.reply(payload);
  },

  buildInvitePayload
};
