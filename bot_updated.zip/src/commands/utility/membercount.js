/**
 * Member Count Breakdown Command (Node.js)
 * Displays human vs bot distribution and server growth metrics.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'membercount',
  aliases: ['mc', 'members'],
  category: 'utility',
  description: 'Displays the total member count and human vs bot distribution of the server.',
  usage: '',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const guild = message.guild;
    const total = guild.memberCount;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const humans = Math.max(0, total - bots);

    const embed = createEmbed({
      title: `👥  ${guild.name} • Member Count`,
      description:
        `> Accurate server population demographics.\n\n` +
        `• **Total Population:** **${total.toLocaleString()}**\n` +
        `• 👤 **Humans:** **${humans.toLocaleString()}** (${Math.round((humans / total) * 100)}%)\n` +
        `• 🤖 **Bots:** **${bots.toLocaleString()}** (${Math.round((bots / total) * 100)}%)\n\n` +
        `-# Requested by ${message.author.username}`
    });

    return message.reply({ embeds: [embed] });
  }
};
