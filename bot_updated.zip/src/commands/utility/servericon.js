/**
 * Server Icon Command (Node.js)
 * Displays the server icon in high resolution (1024x1024 PNG).
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'servericon',
  aliases: ['sicon', 'guildicon', 'serveravatar'],
  category: 'utility',
  description: 'Displays the server\'s icon in high resolution.',
  usage: '',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const iconUrl = typeof message.guild.iconURL === 'function'
      ? message.guild.iconURL({ size: 1024, dynamic: true, extension: 'png' })
      : null;

    if (!iconUrl) {
      return message.reply('<a:tungsten_info:1567240890748248084> This server does not have an icon uploaded.');
    }

    const embed = createEmbed({
      color: 0x5865F2,
      title: `🏰  Server Icon • ${message.guild.name}`,
      description: `[Download Icon (1024x1024)](${iconUrl})`
    });

    if (typeof iconUrl === 'string' && iconUrl.startsWith('http')) {
      embed.setImage(iconUrl);
    }

    return message.reply({ embeds: [embed] });
  }
};
