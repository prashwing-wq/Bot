/**
 * Tungsten Text Diff Command (Node.js)
 * Computes high-precision line-by-line diff between two text blocks using LCS algorithm.
 */
const { createV2Card } = require('../../utils/componentsV2');

function computeLcsDiff(linesA, linesB) {
  // Cap max lines to prevent excessive memory allocation in Termux
  const maxLines = 500;
  const a = linesA.slice(0, maxLines);
  const b = linesB.slice(0, maxLines);

  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Uint32Array(n + 1));

  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      if (a[i] === b[j]) {
        dp[i + 1][j + 1] = dp[i][j] + 1;
      } else {
        dp[i + 1][j + 1] = Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
  }

  let i = m;
  let j = n;
  const result = [];
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && a[i - 1] === b[j - 1]) {
      result.push({ type: 'keep', text: a[i - 1] });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      result.push({ type: 'add', text: b[j - 1] });
      j--;
    } else if (i > 0 && (j === 0 || dp[i][j - 1] < dp[i - 1][j])) {
      result.push({ type: 'del', text: a[i - 1] });
      i--;
    }
  }

  return result.reverse();
}

function formatDiff(diffOps, maxLen = 1500) {
  let additions = 0;
  let deletions = 0;
  let unchanged = 0;

  for (const op of diffOps) {
    if (op.type === 'add') additions++;
    else if (op.type === 'del') deletions++;
    else unchanged++;
  }

  const outputLines = [];
  let totalChars = 0;
  let truncated = false;
  let hiddenLines = 0;

  for (let idx = 0; idx < diffOps.length; idx++) {
    const op = diffOps[idx];
    let prefix = '  ';
    if (op.type === 'add') prefix = '+ ';
    else if (op.type === 'del') prefix = '- ';

    const line = `${prefix}${op.text}`;
    if (totalChars + line.length + 1 > maxLen) {
      truncated = true;
      hiddenLines = diffOps.length - idx;
      break;
    }
    outputLines.push(line);
    totalChars += line.length + 1;
  }

  if (truncated) {
    outputLines.push(`... [diff truncated, ${hiddenLines} more line(s)]`);
  }

  return {
    text: outputLines.join('\n'),
    additions,
    deletions,
    unchanged,
    isIdentical: additions === 0 && deletions === 0
  };
}

module.exports = {
  name: 'diff',
  aliases: ['textdiff', 'compare', 'linediff'],
  category: 'utility',
  description: 'Compare two text blocks and display a line-by-line diff.',
  usage: '<text1> --- <text2>',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 2,

  async execute(message, args, client, prefix = '!') {
    const rawContent = args.join(' ').trim();

    if (!rawContent || (!rawContent.includes('---') && !rawContent.includes('==='))) {
      const card = createV2Card({
        color: 0x5865F2,
        title: '<a:tungsten_search:1567242081167216771> Tungsten • Line-by-Line Text Diff',
        description:
          `Compare two blocks of code or text and see additions, deletions, and identical lines.\n\n` +
          `**Usage & Syntax:**\n` +
          `• \`${prefix}diff <original_text> --- <modified_text>\`\n\n` +
          `**Example:**\n` +
          `\`\`\`\n${prefix}diff\nconst a = 1;\nconst b = 2;\n---\nconst a = 1;\nconst b = 3;\nconst c = 4;\n\`\`\``,
        footerText: `Requested by ${message.author?.username || 'User'}`
      });
      return message.reply({ embeds: [card] });
    }

    const separator = rawContent.includes('---') ? '---' : '===';
    const splitIndex = rawContent.indexOf(separator);
    const text1 = rawContent.slice(0, splitIndex).trim();
    const text2 = rawContent.slice(splitIndex + separator.length).trim();

    const linesA = text1 ? text1.split(/\r?\n/) : [];
    const linesB = text2 ? text2.split(/\r?\n/) : [];

    const diffOps = computeLcsDiff(linesA, linesB);
    const result = formatDiff(diffOps);

    if (result.isIdentical) {
      const card = createV2Card({
        color: 0x00FF88,
        title: '<a:tungsten_search:1567242081167216771> Tungsten • Line-by-Line Diff Comparison',
        description:
          `<a:tungsten_success:1567242523468890274> **Both texts are identical!**\n\n` +
          `• Total lines: \`${linesA.length}\`\n` +
          `• Additions: \`+0\`\n` +
          `• Deletions: \`-0\`\n` +
          `• Unchanged: \`${linesA.length}\``,
        footerText: `Requested by ${message.author?.username || 'User'}`
      });
      return message.reply({ embeds: [card] });
    }

    const card = createV2Card({
      color: result.deletions > 0 && result.additions === 0 ? 0xFF3B30 : 0x00FF88,
      title: '<a:tungsten_search:1567242081167216771> Tungsten • Line-by-Line Diff Comparison',
      description:
        `> **Diff Summary:** \`+${result.additions}\` additions • \`-${result.deletions}\` deletions • \`${result.unchanged}\` unchanged\n\n` +
        `\`\`\`diff\n${result.text || '[Empty Diff]'}\n\`\`\``,
      footerText: `Requested by ${message.author?.username || 'User'}`
    });

    return message.reply({ embeds: [card] });
  },

  computeLcsDiff,
  formatDiff
};
