/**
 * Mathematical Calculator Command (Node.js)
 * High-performance safe mathematical expression evaluator without eval.
 * Uses a tokenized recursive descent parser supporting arithmetic, exponents,
 * trigonometric functions, logarithms, constants, step limits, and timeouts.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

/**
 * Evaluates a mathematical expression safely without eval.
 * @param {string} input - Mathematical expression string.
 * @returns {number} Computed numerical result.
 */
function evaluateMath(input) {
  if (typeof input !== 'string') {
    throw new Error('Input expression must be a string');
  }

  const str = input.trim();
  if (!str) {
    throw new Error('Expression is empty');
  }

  const MAX_STEPS = 5000;
  const MAX_DEPTH = 40;
  const TIMEOUT_MS = 150;
  const startTime = Date.now();
  let steps = 0;
  let depth = 0;

  function tick() {
    steps++;
    if (steps > MAX_STEPS) {
      throw new Error('Expression too complex (step limit exceeded)');
    }
    if (Date.now() - startTime > TIMEOUT_MS) {
      throw new Error('Calculation timed out (150ms execution window exceeded)');
    }
  }

  // Tokenizer
  const tokens = [];
  let i = 0;
  while (i < str.length) {
    const c = str[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    if (c === '*' && str[i + 1] === '*') {
      tokens.push({ type: 'OP', val: '**' });
      i += 2;
      continue;
    }
    if ('+-*/%^(),'.includes(c)) {
      tokens.push({ type: 'OP', val: c });
      i++;
      continue;
    }
    if (/[0-9.]/.test(c)) {
      let num = '';
      let hasDot = false;
      while (i < str.length && (/[0-9]/.test(str[i]) || (str[i] === '.' && !hasDot))) {
        if (str[i] === '.') hasDot = true;
        num += str[i];
        i++;
      }
      tokens.push({ type: 'NUM', val: parseFloat(num) });
      continue;
    }
    if (/[a-zA-Z]/.test(c)) {
      let id = '';
      while (i < str.length && /[a-zA-Z0-9]/.test(str[i])) {
        id += str[i];
        i++;
      }
      tokens.push({ type: 'ID', val: id.toLowerCase() });
      continue;
    }
    throw new Error(`Unexpected character: '${c}'`);
  }

  if (tokens.length === 0) {
    throw new Error('No valid mathematical tokens found');
  }

  let pos = 0;
  function peek() {
    return tokens[pos];
  }
  function consume() {
    return tokens[pos++];
  }

  // Precedence level 1: Addition & Subtraction
  function parseExpression() {
    tick();
    depth++;
    if (depth > MAX_DEPTH) {
      throw new Error('Expression nesting too deep (maximum 40 parentheses levels)');
    }
    try {
      let left = parseTerm();
      while (pos < tokens.length && peek().type === 'OP' && (peek().val === '+' || peek().val === '-')) {
        const op = consume().val;
        const right = parseTerm();
        left = op === '+' ? left + right : left - right;
      }
      return left;
    } finally {
      depth--;
    }
  }

  // Precedence level 2: Multiplication, Division, Modulo
  function parseTerm() {
    tick();
    let left = parsePower();
    while (pos < tokens.length && peek().type === 'OP' && (peek().val === '*' || peek().val === '/' || peek().val === '%')) {
      const op = consume().val;
      const right = parsePower();
      if (op === '*') {
        left = left * right;
      } else if (op === '/') {
        if (right === 0) throw new Error('Division by zero');
        left = left / right;
      } else {
        if (right === 0) throw new Error('Modulo by zero');
        left = left % right;
      }
    }
    return left;
  }

  // Precedence level 3: Exponentiation (right-associative)
  function parsePower() {
    tick();
    let left = parseUnary();
    if (pos < tokens.length && peek().type === 'OP' && (peek().val === '^' || peek().val === '**')) {
      consume();
      const right = parsePower();
      left = Math.pow(left, right);
    }
    return left;
  }

  // Precedence level 4: Unary + and -
  function parseUnary() {
    tick();
    if (pos < tokens.length && peek().type === 'OP' && (peek().val === '+' || peek().val === '-')) {
      const op = consume().val;
      const factor = parseUnary();
      return op === '-' ? -factor : factor;
    }
    return parseFactor();
  }

  // Precedence level 5: Numbers, Identifiers, Parenthesized Expressions
  function parseFactor() {
    tick();
    const tok = peek();
    if (!tok) {
      throw new Error('Unexpected end of expression');
    }

    if (tok.type === 'NUM') {
      consume();
      return tok.val;
    }

    if (tok.type === 'OP' && tok.val === '(') {
      consume();
      const val = parseExpression();
      const close = peek();
      if (!close || close.val !== ')') {
        throw new Error("Missing closing parenthesis ')'");
      }
      consume();
      return val;
    }

    if (tok.type === 'ID') {
      consume();
      const name = tok.val;

      // Constants
      if (name === 'pi') return Math.PI;
      if (name === 'e') return Math.E;
      if (name === 'phi') return 1.618033988749895;

      // Function calls
      const next = peek();
      if (!next || next.val !== '(') {
        throw new Error(`Unknown identifier or constant '${name}'`);
      }
      consume(); // consume '('
      const arg = parseExpression();
      const close = peek();
      if (!close || close.val !== ')') {
        throw new Error(`Missing closing parenthesis ')' after '${name}'`);
      }
      consume();

      switch (name) {
        case 'sqrt':
          if (arg < 0) throw new Error('Square root of negative number');
          return Math.sqrt(arg);
        case 'cbrt':
          return Math.cbrt(arg);
        case 'sin':
          return Math.sin(arg);
        case 'cos':
          return Math.cos(arg);
        case 'tan':
          return Math.tan(arg);
        case 'asin':
          if (arg < -1 || arg > 1) throw new Error('Domain error for asin (must be between -1 and 1)');
          return Math.asin(arg);
        case 'acos':
          if (arg < -1 || arg > 1) throw new Error('Domain error for acos (must be between -1 and 1)');
          return Math.acos(arg);
        case 'atan':
          return Math.atan(arg);
        case 'abs':
          return Math.abs(arg);
        case 'round':
          return Math.round(arg);
        case 'floor':
          return Math.floor(arg);
        case 'ceil':
          return Math.ceil(arg);
        case 'log':
        case 'ln':
          if (arg <= 0) throw new Error('Logarithm of non-positive number');
          return Math.log(arg);
        case 'log10':
          if (arg <= 0) throw new Error('Log10 of non-positive number');
          return Math.log10(arg);
        case 'log2':
          if (arg <= 0) throw new Error('Log2 of non-positive number');
          return Math.log2(arg);
        case 'exp':
          return Math.exp(arg);
        default:
          throw new Error(`Unknown mathematical function '${name}'`);
      }
    }

    throw new Error(`Unexpected token '${tok.val}'`);
  }

  const result = parseExpression();
  if (pos < tokens.length) {
    throw new Error(`Unexpected trailing token '${peek().val}'`);
  }

  return result;
}

/**
 * Formats a numerical computation result cleanly with high precision.
 * @param {number} val - Computed numerical value.
 * @returns {string} Formatted string representation.
 */
function formatResult(val) {
  if (typeof val !== 'number' || isNaN(val)) return 'NaN';
  if (!isFinite(val)) return val > 0 ? 'Infinity' : '-Infinity';
  const rounded = Number(val.toPrecision(12));
  return String(rounded);
}

module.exports = {
  name: 'calc',
  aliases: ['calculate', 'math', 'evalmath'],
  category: 'utility',
  description: 'Safely evaluates mathematical expressions without eval.',
  usage: '<expression>',
  cooldown: 2,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    const rawExpr = args.join(' ').trim();

    // If no arguments provided, show an interactive help card
    if (!rawExpr) {
      const helpCard = createV2Card({
        color: config.COLORS?.PRIMARY || 0x5865F2,
        title: '<a:tungsten_calc:1569329263469924396>  Mathematical Calculator',
        description:
          `> Safe mathematical expression evaluator without \`eval\`.\n\n` +
          `**Usage:**\n` +
          `• \`${prefix || '!'}calc <expression>\`\n\n` +
          `**Supported Operations & Functions:**\n` +
          `• **Arithmetic:** \`+\`, \`-\`, \`*\`, \`/\`, \`%\` (modulo), \`^\` or \`**\` (power)\n` +
          `• **Functions:** \`sqrt(x)\`, \`cbrt(x)\`, \`sin(x)\`, \`cos(x)\`, \`tan(x)\`, \`abs(x)\`, \`round(x)\`, \`floor(x)\`, \`ceil(x)\`, \`log(x)\`, \`exp(x)\`\n` +
          `• **Constants:** \`pi\` (3.14159...), \`e\` (2.71828...)\n\n` +
          `**Examples:**\n` +
          `• \`${prefix || '!'}calc 2 + 2 * 5\`\n` +
          `• \`${prefix || '!'}calc sqrt(144) + 10^2\`\n` +
          `• \`${prefix || '!'}calc sin(pi / 2)\`\n` +
          `• \`${prefix || '!'}calc (50 * 4) / (2^3)\``,
        footerText: `Tungsten Calculator • Requested by ${message.author ? message.author.username : 'User'}`
      });

      return message.reply({ embeds: [helpCard] });
    }

    const t0 = process.hrtime.bigint();
    const clampedExpr = rawExpr.slice(0, 500);

    try {
      const rawResult = evaluateMath(clampedExpr);
      const formatted = formatResult(rawResult);
      const t1 = process.hrtime.bigint();
      const elapsedNs = Number(t1 - t0);
      const elapsedMs = (elapsedNs / 1_000_000).toFixed(3);

      const safeDisplayExpr = clampedExpr.length > 200 ? clampedExpr.slice(0, 197) + '...' : clampedExpr;
      const safeDisplayResult = formatted.slice(0, 1900);

      const card = createV2Card({
        color: 0x00FF88, // Optimal success green
        title: '<a:tungsten_calc:1569329263469924396>  Mathematical Computation Result',
        description:
          `**Input Expression:**\n` +
          `\`\`\`txt\n${safeDisplayExpr}\n\`\`\`\n` +
          `**Result:**\n` +
          `\`\`\`txt\n${safeDisplayResult}\n\`\`\`\n` +
          `-# Engine: Tokenized Recursive Descent • Evaluated in ${elapsedMs}ms (${elapsedNs.toLocaleString()}ns)`,
        footerText: `Requested by ${message.author ? message.author.username : 'User'}`
      });

      const authorId = message.author?.id || '0';
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`calc:delete:${authorId}`)
          .setLabel('Dismiss')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [card], components: [row] });
    } catch (err) {
      const errorCard = createV2Card({
        color: 0xFF3B30, // Error red
        title: '<a:tungsten_close:1567234632905138206>  Calculation Error',
        description:
          `**Input Expression:**\n` +
          `\`\`\`txt\n${clampedExpr.slice(0, 200)}\n\`\`\`\n` +
          `**Error Details:**\n` +
          `> ${err.message || 'Invalid mathematical syntax'}\n\n` +
          `-# Verify parentheses, operators, and function arguments.`,
        footerText: `Requested by ${message.author ? message.author.username : 'User'}`
      });

      const authorId = message.author?.id || '0';
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`calc:delete:${authorId}`)
          .setLabel('Dismiss')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [errorCard], components: [row] });
    }
  },

  evaluateMath,
  formatResult
};
