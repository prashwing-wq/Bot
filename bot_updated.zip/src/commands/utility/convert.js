/**
 * Unit Converter Command (Node.js)
 * High-precision unit converter supporting length, weight, temperature,
 * digital storage, and speed measurements with alias resolution.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

const UNIT_DEFINITIONS = {
  length: {
    name: 'Length & Distance',
    base: 'm',
    units: {
      m: { names: ['m', 'meter', 'meters', 'metre', 'metres'], rate: 1, label: 'Meters (m)' },
      km: { names: ['km', 'kilometer', 'kilometers', 'kilometre', 'kilometres'], rate: 1000, label: 'Kilometers (km)' },
      mi: { names: ['mi', 'mile', 'miles'], rate: 1609.344, label: 'Miles (mi)' },
      ft: { names: ['ft', 'foot', 'feet'], rate: 0.3048, label: 'Feet (ft)' },
      in: { names: ['in', 'inch', 'inches'], rate: 0.0254, label: 'Inches (in)' },
      cm: { names: ['cm', 'centimeter', 'centimeters'], rate: 0.01, label: 'Centimeters (cm)' },
      mm: { names: ['mm', 'millimeter', 'millimeters'], rate: 0.001, label: 'Millimeters (mm)' },
      yd: { names: ['yd', 'yard', 'yards'], rate: 0.9144, label: 'Yards (yd)' }
    }
  },
  weight: {
    name: 'Weight & Mass',
    base: 'g',
    units: {
      g: { names: ['g', 'gram', 'grams'], rate: 1, label: 'Grams (g)' },
      kg: { names: ['kg', 'kilogram', 'kilograms'], rate: 1000, label: 'Kilograms (kg)' },
      lb: { names: ['lb', 'lbs', 'pound', 'pounds'], rate: 453.59237, label: 'Pounds (lb)' },
      oz: { names: ['oz', 'ounce', 'ounces'], rate: 28.349523125, label: 'Ounces (oz)' },
      mg: { names: ['mg', 'milligram', 'milligrams'], rate: 0.001, label: 'Milligrams (mg)' },
      ton: { names: ['ton', 'tons', 'tonne', 'tonnes'], rate: 1000000, label: 'Metric Tonnes (t)' }
    }
  },
  temp: {
    name: 'Temperature',
    base: 'c',
    units: {
      c: { names: ['c', 'celsius', 'centigrade'], label: 'Celsius (°C)' },
      f: { names: ['f', 'fahrenheit'], label: 'Fahrenheit (°F)' },
      k: { names: ['k', 'kelvin'], label: 'Kelvin (K)' }
    }
  },
  data: {
    name: 'Digital Data Storage',
    base: 'b',
    units: {
      b: { names: ['b', 'byte', 'bytes'], rate: 1, label: 'Bytes (B)' },
      kb: { names: ['kb', 'kilobyte', 'kilobytes', 'kib'], rate: 1024, label: 'Kilobytes (KB)' },
      mb: { names: ['mb', 'megabyte', 'megabytes', 'mib'], rate: 1024 * 1024, label: 'Megabytes (MB)' },
      gb: { names: ['gb', 'gigabyte', 'gigabytes', 'gib'], rate: 1024 * 1024 * 1024, label: 'Gigabytes (GB)' },
      tb: { names: ['tb', 'terabyte', 'terabytes', 'tib'], rate: 1024 * 1024 * 1024 * 1024, label: 'Terabytes (TB)' },
      pb: { names: ['pb', 'petabyte', 'petabytes', 'pib'], rate: 1024 * 1024 * 1024 * 1024 * 1024, label: 'Petabytes (PB)' }
    }
  },
  speed: {
    name: 'Speed & Velocity',
    base: 'ms',
    units: {
      ms: { names: ['ms', 'm/s', 'mps'], rate: 1, label: 'Meters per Second (m/s)' },
      kmh: { names: ['kmh', 'km/h', 'kph'], rate: 1 / 3.6, label: 'Kilometers per Hour (km/h)' },
      mph: { names: ['mph', 'mi/h'], rate: 0.44704, label: 'Miles per Hour (mph)' },
      knot: { names: ['knot', 'knots', 'kn'], rate: 0.514444, label: 'Knots (kn)' }
    }
  }
};

/**
 * Finds a unit and its category by name or alias.
 * @param {string} rawUnit - Unit string.
 * @returns {{ category: string, key: string, unit: object }|null}
 */
function resolveUnit(rawUnit) {
  if (!rawUnit || typeof rawUnit !== 'string') return null;
  const clean = rawUnit.trim().toLowerCase();

  for (const [catKey, catDef] of Object.entries(UNIT_DEFINITIONS)) {
    for (const [unitKey, unitDef] of Object.entries(catDef.units)) {
      if (unitKey === clean || (unitDef.names && unitDef.names.includes(clean))) {
        return { category: catKey, key: unitKey, unit: unitDef, categoryName: catDef.name };
      }
    }
  }

  return null;
}

/**
 * Converts a numerical value between two units.
 * @param {number} val - Input numerical quantity.
 * @param {string} from - Source unit.
 * @param {string} to - Destination unit.
 * @returns {{ result: number, fromUnit: object, toUnit: object, category: string }}
 */
function convertUnits(val, from, to) {
  const fromRes = resolveUnit(from);
  const toRes = resolveUnit(to);

  if (!fromRes) throw new Error(`Unknown source unit '${from}'`);
  if (!toRes) throw new Error(`Unknown target unit '${to}'`);

  if (fromRes.category !== toRes.category) {
    throw new Error(
      `Incompatible unit categories: Cannot convert '${from}' (${fromRes.categoryName}) to '${to}' (${toRes.categoryName})`
    );
  }

  const num = Number(val);
  if (isNaN(num) || !isFinite(num)) {
    throw new Error(`Invalid numeric value '${val}'`);
  }

  let converted;

  if (fromRes.category === 'temp') {
    // Step 1: Normalize to Celsius
    let celsius;
    if (fromRes.key === 'c') celsius = num;
    else if (fromRes.key === 'f') celsius = (num - 32) * (5 / 9);
    else if (fromRes.key === 'k') celsius = num - 273.15;

    // Step 2: Convert from Celsius to Target
    if (toRes.key === 'c') converted = celsius;
    else if (toRes.key === 'f') converted = (celsius * (9 / 5)) + 32;
    else if (toRes.key === 'k') converted = celsius + 273.15;
  } else {
    // Standard linear rate conversion: val -> base -> target
    const inBase = num * fromRes.unit.rate;
    converted = inBase / toRes.unit.rate;
  }

  // Clean IEEE-754 floating-point artifacts
  if (isFinite(converted)) {
    converted = Number(converted.toPrecision(12));
  }

  return {
    result: converted,
    fromUnit: fromRes.unit,
    toUnit: toRes.unit,
    category: fromRes.categoryName
  };
}

/**
 * Formats converted numeric value cleanly.
 * @param {number} val - Converted number.
 * @returns {string} Clean string.
 */
function formatConvertedValue(val) {
  if (Number.isInteger(val)) {
    return val.toLocaleString();
  }
  const rounded = Number(val.toFixed(6));
  return String(rounded);
}

module.exports = {
  name: 'convert',
  aliases: ['unitconvert', 'units', 'conv'],
  category: 'utility',
  description: 'Converts between different units of measurement.',
  usage: '<value> <from_unit> <to_unit>',
  cooldown: 2,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (args.length < 3) {
      const helpCard = createV2Card({
        color: config.COLORS?.PRIMARY || 0x5865F2,
        title: '<a:tungsten_convert:1569329320802000956>  Unit Measurement Converter',
        description:
          `> Fast and accurate unit conversion across 5 measurement systems.\n\n` +
          `**Usage:**\n` +
          `• \`${prefix || '!'}convert <value> <from> <to>\`\n\n` +
          `**Supported Measurement Systems:**\n` +
          `• <a:tungsten_bullet:1567233589949497434> **Length:** \`m\`, \`km\`, \`mi\`, \`ft\`, \`in\`, \`cm\`, \`mm\`, \`yd\`\n` +
          `• <a:tungsten_scales:1567242041098895521> **Weight:** \`kg\`, \`g\`, \`lb\`, \`oz\`, \`mg\`, \`ton\`\n` +
          `• <a:tungsten_sun:1567242622701932604> **Temperature:** \`c\` (Celsius), \`f\` (Fahrenheit), \`k\` (Kelvin)\n` +
          `• <a:tungsten_database:1567238475684651168> **Data Storage:** \`b\`, \`kb\`, \`mb\`, \`gb\`, \`tb\`, \`pb\`\n` +
          `• <a:tungsten_rocket:1567241971804798976> **Speed:** \`kmh\` (km/h), \`mph\` (mi/h), \`ms\` (m/s), \`knot\`\n\n` +
          `**Examples:**\n` +
          `• \`${prefix || '!'}convert 100 km mi\`\n` +
          `• \`${prefix || '!'}convert 72 f c\`\n` +
          `• \`${prefix || '!'}convert 500 gb tb\`\n` +
          `• \`${prefix || '!'}convert 150 lb kg\`\n` +
          `• \`${prefix || '!'}convert 120 kmh mph\``,
        footerText: `Tungsten Converters • Requested by ${message.author ? message.author.username : 'User'}`
      });

      return message.reply({ embeds: [helpCard] });
    }

    const rawVal = args[0];
    const fromUnitStr = args[1];
    const toUnitStr = args[2];

    try {
      const { result, fromUnit, toUnit, category } = convertUnits(rawVal, fromUnitStr, toUnitStr);
      const formattedInput = isNaN(Number(rawVal)) ? rawVal : Number(rawVal).toLocaleString();
      const formattedResult = formatConvertedValue(result);

      const card = createV2Card({
        color: 0x00FF88, // Optimal success green
        title: `<a:tungsten_convert:1569329320802000956>  ${category} Conversion`,
        description:
          `**Input Quantity:**\n` +
          `\`\`\`txt\n${formattedInput} ${fromUnit.label}\n\`\`\`\n` +
          `**Converted Result:**\n` +
          `\`\`\`txt\n${formattedResult} ${toUnit.label}\n\`\`\`\n` +
          `-# High-precision calibrated formula`,
        footerText: `Requested by ${message.author ? message.author.username : 'User'}`
      });

      const authorId = message.author?.id || '0';
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`convert:delete:${authorId}`)
          .setLabel('Dismiss')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [card], components: [row] });
    } catch (err) {
      const errorCard = createV2Card({
        color: 0xFF3B30, // Error red
        title: '<a:tungsten_close:1567234632905138206>  Unit Conversion Error',
        description:
          `**Input:** \`${rawVal} ${fromUnitStr} -> ${toUnitStr}\`\n\n` +
          `**Details:**\n` +
          `> ${err.message || 'Unable to convert specified units.'}\n\n` +
          `-# Run \`${prefix || '!'}convert\` to view the list of supported measurement units.`,
        footerText: `Requested by ${message.author ? message.author.username : 'User'}`
      });

      const authorId = message.author?.id || '0';
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`convert:delete:${authorId}`)
          .setLabel('Dismiss')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [errorCard], components: [row] });
    }
  },

  convertUnits,
  resolveUnit,
  formatConvertedValue,
  UNIT_DEFINITIONS
};
