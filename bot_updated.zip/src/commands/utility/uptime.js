/**
 * Uptime & System Health Command (Node.js)
 * Displays precise bot continuous uptime and memory allocation.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'uptime',
  category: 'utility',
  description: 'Displays the continuous uptime and process telemetry of Tungsten.',
  usage: '',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    const totalSeconds = Math.floor(process.uptime());
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const mem = process.memoryUsage();
    const heapUsedMB = (mem.heapUsed / 1024 / 1024).toFixed(1);
    const rssMB = (mem.rss / 1024 / 1024).toFixed(1);

    const embed = createEmbed({
      color: undefined,
      title: '⚡  Tungsten Runtime & Uptime Telemetry',
      description:
        `> High-performance continuous operations dashboard.\n\n` +
        `• **Continuous Uptime:** **${days}d ${hours}h ${minutes}m ${seconds}s**\n` +
        `• **RAM Heap Used:** \`${heapUsedMB} MB\` (RSS: \`${rssMB} MB\`)\n` +
        `• **Node.js Engine:** \`${process.version}\` on \`${process.platform}\`\n` +
        `• **WebSocket Ping:** \`${client.ws ? Math.round(client.ws.ping) : 0}ms\`\n` +
        `• **Database Sync:** MongoDB Atlas Cloud Architecture (In-Memory SQLite Cache)\n\n` +
        `-# Requested by ${message.author.username}`
    });

    return message.reply({ embeds: [embed] });
  }
};
