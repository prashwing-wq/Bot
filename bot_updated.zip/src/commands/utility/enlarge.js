/**
 * Enlarge Command (Node.js)
 * View full high-resolution rendering of custom emojis, stickers, or member avatars.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'enlarge',
  aliases: ['jumbo', 'bigemoji'],
  category: 'utility',
  description: 'Enlarge a custom emoji, sticker, or avatar to high resolution.',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  usage: '<emoji | :emoji: | @member>',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!args[0] && !message.mentions?.members?.first() && !message.stickers?.size) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}enlarge <emoji | :emoji: | @member>\``);
    }

    // Check message sticker
    if (message.stickers?.size > 0) {
      const sticker = message.stickers.first();
      const embed = createEmbed({
        title: `🏷️ Sticker: ${sticker.name}`,
        description: `[Direct Image Link](${sticker.url})`,
        image: { url: sticker.url }
      });
      return message.reply({ embeds: [embed] });
    }

    // Check member mention
    const member = message.mentions?.members?.first();
    if (member) {
      const avatarUrl = member.user.displayAvatarURL({ size: 1024, dynamic: true });
      const embed = createEmbed({
        title: `🖼️ Avatar: ${member.user.tag}`,
        description: `[Open in Browser](${avatarUrl})`,
        image: { url: avatarUrl }
      });
      return message.reply({ embeds: [embed] });
    }

    const input = args[0];

    // Check custom emoji: <:name:id> or <a:name:id>
    const customMatch = input.match(/<(a?):([a-zA-Z0-9_]+):(\d+)>/);
    if (customMatch) {
      const isAnimated = customMatch[1] === 'a';
      const name = customMatch[2];
      const id = customMatch[3];
      const ext = isAnimated ? 'gif' : 'png';
      const url = `https://cdn.discordapp.com/emojis/${id}.${ext}?size=1024&quality=lossless`;

      const embed = createEmbed({
        title: `✨ Custom Emoji: :${name}:`,
        description: `• **Format:** \`${ext.toUpperCase()}\` • **ID:** \`${id}\`\n[Direct Link](${url})`,
        image: { url }
      });
      return message.reply({ embeds: [embed] });
    }

    // Check if input is an emoji ID
    if (/^\d{17,20}$/.test(input)) {
      const url = `https://cdn.discordapp.com/emojis/${input}.png?size=1024&quality=lossless`;
      const embed = createEmbed({
        title: `✨ Emoji ID: ${input}`,
        description: `[Direct Link](${url})`,
        image: { url }
      });
      return message.reply({ embeds: [embed] });
    }

    // Standard Unicode Emoji
    const codePoints = Array.from(input).map(c => c.codePointAt(0).toString(16)).filter(cp => cp !== 'fe0f').join('-');
    if (codePoints) {
      const twemojiUrl = `https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/72x72/${codePoints}.png`;
      const embed = createEmbed({
        title: `✨ Unicode Emoji: ${input}`,
        description: `[Direct Asset Link](${twemojiUrl})`,
        image: { url: twemojiUrl }
      });
      return message.reply({ embeds: [embed] }).catch(() => {
        return message.reply(`🔍 Emoji preview: **${input}**`);
      });
    }

    return message.reply('<a:tungsten_close:1567234632905138206> Could not recognize emoji, sticker, or avatar.');
  }
};
