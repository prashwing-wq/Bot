/**
 * Serverinfo Command (Prefix & Slash)
 * Detailed breakdown of guild channels, roles, boosts, emojis, and verification level
 */
const { ChannelType } = require('discord.js');
const { createEmbed } = require('../../utils/tools');

async function buildServerInfoPayload(guild, client, author) {
  const owner = (guild.fetchOwner && typeof guild.fetchOwner === 'function')
    ? await guild.fetchOwner().catch(() => null)
    : (guild.members?.cache?.get(guild.ownerId) || null);
  const createdAt = guild.createdTimestamp ? `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>` : 'Unknown';

  const textChannels = guild.channels?.cache ? guild.channels.cache.filter(c => c.type === ChannelType.GuildText || c.type === 0).size : 0;
  const voiceChannels = guild.channels?.cache ? guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice || c.type === 2).size : 0;
  const stageChannels = guild.channels?.cache ? guild.channels.cache.filter(c => c.type === ChannelType.GuildStageVoice || c.type === 13).size : 0;
  const categories = guild.channels?.cache ? guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory || c.type === 4).size : 0;

  const count = guild.channels?.cache ? guild.channels.cache.size : 0;
  const totalMembers = guild.memberCount || 0;
  const rolesCount = guild.roles?.cache ? guild.roles.cache.size : 0;
  const emojisCount = guild.emojis?.cache ? guild.emojis.cache.size : 0;
  const stickersCount = guild.stickers?.cache ? guild.stickers.cache.size : 0;
  const boostTier = guild.premiumTier || 0;
  const boostCount = guild.premiumSubscriptionCount || 0;

  const embed = createEmbed({
    color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
    title: guild.name,
    thumbnail: (guild.iconURL && typeof guild.iconURL === 'function') ? guild.iconURL({ size: 256 }) : null,
    fields: [
      { name: 'Server ID', value: `\`${guild.id}\``, inline: true },
      { name: 'Owner', value: owner ? (owner.user ? `${owner.user.username} (<@${owner.id}>)` : `<@${owner.id}>`) : `<@${guild.ownerId}>`, inline: true },
      { name: 'Created', value: createdAt, inline: true },
      { name: 'Members', value: `\`${totalMembers.toLocaleString()}\``, inline: true },
      { name: 'Roles', value: `\`${rolesCount}\``, inline: true },
      { name: 'Boost Level', value: `Tier ${boostTier} (${boostCount} boosts)`, inline: true },
      {
        name: `Channels [${count}]`,
        value: `Text: \`${textChannels}\` · Voice: \`${voiceChannels}\` · Stage: \`${stageChannels}\` · Categories: \`${categories}\``,
        inline: false
      },
      {
        name: 'Emojis',
        value: `Emojis: \`${emojisCount}\` · Stickers: \`${stickersCount}\``,
        inline: false
      }
    ],
    footer: `Requested by ${author?.username || 'User'}`
  });

  if (guild.bannerURL && typeof guild.bannerURL === 'function' && guild.bannerURL()) {
    embed.setImage(guild.bannerURL({ size: 1024 }));
  }

  return { embeds: [embed] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'serverinfo',
  description: 'Display detailed server statistics and properties.',
  category: 'utility',
  usage: 'serverinfo',
  aliases: ['guildinfo', 'si', 'gi'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command must be used in a server.');
    const payload = await buildServerInfoPayload(message.guild, client, message.author);
    return message.reply(payload);
  },

  buildServerInfoPayload
};
