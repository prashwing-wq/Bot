/**
 * Pings & Mention Notification Settings Command
 * Manages user preferences for tag DM reminders.
 */
const { createEmbed } = require('../../utils/tools');
const {
  setMentionAlertsEnabled,
  isMentionAlertsEnabled
} = require('../../utils/pingsDb');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'pings',
  description: 'Manage your direct message reminder alerts when tagged.',
  category: 'utility',
  usage: 'pings <on|off|status|block|unblock> [@user]',
  aliases: ['mentionalert', 'mentionnotify', 'tagnotify'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const sub = args[0]?.toLowerCase() || 'status';
    const userId = message.author.id;
    const guildId = message.guild.id;

    if (sub === 'on' || sub === 'enable') {
      setMentionAlertsEnabled(userId, true, guildId);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_ui_toggle_on:1569329685110849576> Mention Alerts Enabled',
            description: `You will now receive direct message alerts whenever someone mentions or tags you in **${message.guild.name}**!\n\n` +
              `To disable anytime, type \`${prefix}pings off\`.`
          })
        ]
      });
    }

    if (sub === 'off' || sub === 'disable') {
      setMentionAlertsEnabled(userId, false, guildId);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: '<a:tungsten_ui_toggle_off:1569329677187678368> Mention Alerts Disabled',
            description: `You will no longer receive DM alerts when someone tags you in this server.\n\n` +
              `To re-enable anytime, type \`${prefix}pings on\`.`
          })
        ]
      });
    }

    if (sub === 'block') {
      const target = message.mentions?.users?.first() ||
        (args[1] ? await client.users.fetch(args[1]).catch(() => null) : null);

      if (!target) {
        return message.reply(`**Usage:** \`${prefix}pings block <@user|id>\``);
      }

      if (target.id === userId) {
        return message.reply('You cannot block mention alerts from yourself.');
      }

      const sdb = getServerDb(guildId);
      sdb.prepare('INSERT OR IGNORE INTO blocked_senders (user_id, sender_id) VALUES (?, ?)').run(userId, target.id);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_user:1567246556778995802> User Blocked from Mention Alerts',
            description: `You will no longer receive DM alerts when **${target.username}** tags you.\n\n` +
              `To unblock, use \`${prefix}pings unblock @${target.username}\`.`
          })
        ]
      });
    }

    if (sub === 'unblock') {
      const target = message.mentions?.users?.first() ||
        (args[1] ? await client.users.fetch(args[1]).catch(() => null) : null);

      if (!target) {
        return message.reply(`**Usage:** \`${prefix}pings unblock <@user|id>\``);
      }

      const sdb = getServerDb(guildId);
      sdb.prepare('DELETE FROM blocked_senders WHERE user_id = ? AND sender_id = ?').run(userId, target.id);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_user:1567246556778995802> User Unblocked',
            description: `Successfully unblocked mention alerts from **${target.username}**.`
          })
        ]
      });
    }

    // Default: Status
    const isEnabled = isMentionAlertsEnabled(userId, guildId);

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.PRIMARY,
          title: '<a:tungsten_bell:1567233316925612173> Mention Notification Preferences',
          description: `Direct message reminder alerts when you are tagged in chat.\n\n` +
            `• **Current Status:** ${isEnabled ? '`Enabled` <a:tungsten_ui_toggle_on:1569329685110849576>' : '`Disabled` <a:tungsten_ui_toggle_off:1569329677187678368>'}\n` +
            `• **Server:** ${message.guild.name}\n\n` +
            `**Commands:**\n` +
            `• \`${prefix}pings on\` — Enable DM alerts when mentioned\n` +
            `• \`${prefix}pings off\` — Disable DM alerts\n` +
            `• \`${prefix}pings block <@user>\` — Stop alerts when a specific user tags you\n` +
            `• \`${prefix}pings unblock <@user>\` — Resume alerts from a user`,
          footer: 'Tungsten Mention Reminder Engine'
        })
      ]
    });
  }
};
