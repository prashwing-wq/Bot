/**
 * Cryptographic Hash Generator Command (Node.js)
 * Computes SHA-256, SHA-512, MD5, and other standard digests using node:crypto.
 */
const crypto = require('node:crypto');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

const SUPPORTED_ALGORITHMS = ['sha256', 'sha512', 'md5', 'sha1', 'sha384', 'sha224'];

/**
 * Computes a hash digest for a given algorithm and text.
 * @param {string} algo - Hashing algorithm (sha256, sha512, md5, etc.).
 * @param {string} text - Input text.
 * @returns {string} Hexadecimal hash digest.
 */
function generateHash(algo, text) {
  const cleanAlgo = String(algo).trim().toLowerCase();
  const available = crypto.getHashes();
  if (!available.includes(cleanAlgo)) {
    throw new Error(`Unsupported hash algorithm '${algo}'. Supported: ${SUPPORTED_ALGORITHMS.join(', ')}`);
  }
  return crypto.createHash(cleanAlgo).update(String(text), 'utf8').digest('hex');
}

/**
 * Computes common digests (MD5, SHA-256, SHA-512) simultaneously.
 * @param {string} text - Input text.
 * @returns {{ md5: string, sha256: string, sha512: string }}
 */
function generateMultiHash(text) {
  return {
    md5: generateHash('md5', text),
    sha256: generateHash('sha256', text),
    sha512: generateHash('sha512', text)
  };
}

module.exports = {
  name: 'hash',
  aliases: ['digest', 'checksum'],
  category: 'utility',
  description: 'Generates cryptographic hash digests (SHA-256, SHA-512, MD5) for input text.',
  usage: '<algo> <text>',
  cooldown: 2,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    const authorId = message.author?.id || '0';
    const dismissRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`hash:delete:${authorId}`)
        .setLabel('Dismiss')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('<a:tungsten_trash:1567242891276062872>')
    );

    // 1. Show Help Card if no arguments provided
    if (args.length === 0) {
      const helpCard = createV2Card({
        color: config.COLORS?.PRIMARY || 0x5865F2,
        title: '<a:tungsten_keylock:1567240958075084951>  Cryptographic Hash & Digest Generator',
        description:
          `> Generates high-entropy cryptographic digests using Node.js \`node:crypto\`.\n\n` +
          `**Usage:**\n` +
          `• \`${prefix || '!'}hash <algo> <text>\` — Specific algorithm hash\n` +
          `• \`${prefix || '!'}hash <text>\` — Multi-hash overview (MD5, SHA-256, SHA-512)\n\n` +
          `**Supported Algorithms:**\n` +
          `• \`sha256\`, \`sha512\`, \`md5\`, \`sha1\`, \`sha384\`, \`sha224\`\n\n` +
          `**Examples:**\n` +
          `• \`${prefix || '!'}hash sha256 tungsten_secret_phrase\`\n` +
          `• \`${prefix || '!'}hash md5 password123\`\n` +
          `• \`${prefix || '!'}hash sha512 HighSecurityPayload\`\n` +
          `• \`${prefix || '!'}hash Tungsten Bot Security\``,
        footerText: `Tungsten Cryptography • Requested by ${message.author ? message.author.username : 'User'}`
      });

      return message.reply({ embeds: [helpCard] });
    }

    const firstArgLower = args[0].toLowerCase();
    const isExplicitAlgo = SUPPORTED_ALGORITHMS.includes(firstArgLower);

    // 2. Explicit algorithm specified
    if (isExplicitAlgo) {
      const textToHash = args.slice(1).join(' ').trim();
      if (!textToHash) {
        return message.reply({
          embeds: [
            createV2Card({
              color: 0xFF3B30,
              title: '<a:tungsten_close:1567234632905138206>  Missing Input Text',
              description:
                `> Please provide the text string to hash with \`${firstArgLower}\`.\n\n` +
                `**Usage:** \`${prefix || '!'}hash ${firstArgLower} <text>\``,
              footerText: `Requested by ${message.author ? message.author.username : 'User'}`
            })
          ],
          components: [dismissRow]
        });
      }

      try {
        const digest = generateHash(firstArgLower, textToHash);
        const safeSnippet = textToHash.length > 100 ? textToHash.slice(0, 97) + '...' : textToHash;

        const card = createV2Card({
          color: 0x00FF88,
          title: `<a:tungsten_keylock:1567240958075084951>  ${firstArgLower.toUpperCase()} Cryptographic Digest`,
          description:
            `**Input Snippet (${textToHash.length} characters):**\n` +
            `\`\`\`txt\n${safeSnippet}\n\`\`\`\n` +
            `**${firstArgLower.toUpperCase()} Digest:**\n` +
            `\`\`\`txt\n${digest}\n\`\`\`\n` +
            `-# Cryptographic output generated via Node.js node:crypto`,
          footerText: `Requested by ${message.author ? message.author.username : 'User'}`
        });

        return message.reply({ embeds: [card], components: [dismissRow] });
      } catch (err) {
        return message.reply({
          embeds: [
            createV2Card({
              color: 0xFF3B30,
              title: '<a:tungsten_close:1567234632905138206>  Hashing Error',
              description: `> ${err.message || 'Failed to generate hash digest.'}`,
              footerText: `Requested by ${message.author ? message.author.username : 'User'}`
            })
          ],
          components: [dismissRow]
        });
      }
    }

    // 3. Multi-Hash Overview (user provided input without an explicit algorithm)
    const fullText = args.join(' ').trim();
    try {
      const multi = generateMultiHash(fullText);
      const safeSnippet = fullText.length > 100 ? fullText.slice(0, 97) + '...' : fullText;

      const card = createV2Card({
        color: 0x00FF88,
        title: '<a:tungsten_keylock:1567240958075084951>  Multi-Algorithm Cryptographic Digests',
        description:
          `**Input Snippet (${fullText.length} characters):**\n` +
          `\`\`\`txt\n${safeSnippet}\n\`\`\`\n` +
          `**MD5 (128-bit):**\n` +
          `\`\`\`txt\n${multi.md5}\n\`\`\`\n` +
          `**SHA-256 (256-bit):**\n` +
          `\`\`\`txt\n${multi.sha256}\n\`\`\`\n` +
          `**SHA-512 (512-bit):**\n` +
          `\`\`\`txt\n${multi.sha512}\n\`\`\`\n` +
          `-# Cryptographic output generated via Node.js node:crypto`,
        footerText: `Requested by ${message.author ? message.author.username : 'User'}`
      });

      return message.reply({ embeds: [card], components: [dismissRow] });
    } catch (err) {
      return message.reply({
        embeds: [
          createV2Card({
            color: 0xFF3B30,
            title: '<a:tungsten_close:1567234632905138206>  Hashing Error',
            description: `> ${err.message || 'Failed to generate multi-hash digests.'}`,
            footerText: `Requested by ${message.author ? message.author.username : 'User'}`
          })
        ],
        components: [dismissRow]
      });
    }
  },

  generateHash,
  generateMultiHash,
  SUPPORTED_ALGORITHMS
};
