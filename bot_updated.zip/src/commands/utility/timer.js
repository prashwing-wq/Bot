/**
 * Countdown Timer Command (Node.js)
 * Sets a real-time countdown timer with automated notification upon completion.
 */
const { createEmbed } = require('../../utils/tools');

function parseTimerDuration(str) {
  if (!str) return null;
  const match = str.toLowerCase().match(/^(\d+)\s*(s|sec|seconds?|m|min|minutes?|h|hours?|d|days?)$/);
  if (!match) return null;
  const val = parseInt(match[1], 10);
  const unit = match[2];
  if (isNaN(val) || val <= 0) return null;

  if (unit.startsWith('s')) return val;
  if (unit.startsWith('m')) return val * 60;
  if (unit.startsWith('h')) return val * 3600;
  if (unit.startsWith('d')) return val * 86400;
  return null;
}

module.exports = {
  name: 'timer',
  aliases: ['countdown', 'remindme'],
  category: 'utility',
  description: 'Countdown timer with scheduled finish.',
  usage: '<duration> [reason]',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!args[0]) {
      return message.reply(`Usage: \`${prefix}timer <duration> [reason]\` (e.g. \`${prefix}timer 10m Take pizza out\`)`);
    }

    const durationSec = parseTimerDuration(args[0]);
    if (!durationSec) {
      return message.reply('<a:tungsten_warn:1567246685082746940> Please specify a valid duration (e.g. `30s`, `5m`, `1h`, `2d`).');
    }

    if (durationSec > 86400 * 7) {
      return message.reply('<a:tungsten_close:1567234632905138206> Timers cannot exceed 7 days.');
    }

    const reason = args.slice(1).join(' ').trim() || 'Timer finished';
    const finishTimestamp = Math.floor(Date.now() / 1000) + durationSec;

    const startEmbed = createEmbed({
      color: 0x5865F2,
      title: '⏱️  Timer Started',
      description:
        `> Your timer has been set for **${args[0]}**.\n\n` +
        `• **Finishes:** <t:${finishTimestamp}:R> (<t:${finishTimestamp}:T>)\n` +
        `• **Label:** ${reason}`
    });

    await message.reply({ embeds: [startEmbed] });

    // Schedule notification
    const tId = setTimeout(async () => {
      try {
        const finishEmbed = createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '⏰  Timer Alert!',
          description: `Hey ${message.author}, your **${args[0]}** timer is up!\n\n**Note:** ${reason}`
        });

        await message.channel.send({
          content: `${message.author}`,
          embeds: [finishEmbed]
        }).catch(() => null);
      } catch (_) {}
    }, durationSec * 1000);
    if (tId && typeof tId.unref === 'function') tId.unref();
  }
};
