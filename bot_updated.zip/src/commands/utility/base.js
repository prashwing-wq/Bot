/**
 * Number Base Converter Command (Node.js)
 * Converts numbers between bases 2 through 36 with BigInt arbitrary precision.
 * Supports single-number multi-base telemetry breakdown and custom radix mapping.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

const DIGITS = '0123456789abcdefghijklmnopqrstuvwxyz';

/**
 * Converts a number string from a given base to BigInt.
 * @param {string} numStr - Number in text format.
 * @param {number} fromRadix - Source base (2-36).
 * @returns {bigint} BigInt value.
 */
function parseBaseToBigInt(numStr, fromRadix) {
  if (fromRadix < 2 || fromRadix > 36) {
    throw new Error('Source base must be an integer between 2 and 36');
  }

  let isNeg = false;
  let clean = String(numStr).trim().toLowerCase();
  if (clean.startsWith('-')) {
    isNeg = true;
    clean = clean.slice(1);
  } else if (clean.startsWith('+')) {
    clean = clean.slice(1);
  }

  if (!clean) {
    throw new Error('Number cannot be empty');
  }

  const base = BigInt(fromRadix);
  let val = 0n;

  for (let i = 0; i < clean.length; i++) {
    const char = clean[i];
    const digitVal = DIGITS.indexOf(char);
    if (digitVal === -1 || digitVal >= fromRadix) {
      throw new Error(`Character '${char}' is invalid for base ${fromRadix}`);
    }
    val = val * base + BigInt(digitVal);
  }

  return isNeg ? -val : val;
}

/**
 * Converts a number between arbitrary bases (2 to 36).
 * @param {string} numStr - Number string.
 * @param {number} fromRadix - Source base (2-36).
 * @param {number} toRadix - Target base (2-36).
 * @returns {string} Converted number in target base (uppercase).
 */
function convertBase(numStr, fromRadix, toRadix) {
  const from = parseInt(fromRadix, 10);
  const to = parseInt(toRadix, 10);

  if (isNaN(from) || from < 2 || from > 36) {
    throw new Error('Source base must be an integer between 2 and 36');
  }
  if (isNaN(to) || to < 2 || to > 36) {
    throw new Error('Target base must be an integer between 2 and 36');
  }

  const bigIntVal = parseBaseToBigInt(numStr, from);
  const isNeg = bigIntVal < 0n;
  const absVal = isNeg ? -bigIntVal : bigIntVal;

  const resultStr = absVal.toString(to).toUpperCase();
  return isNeg ? `-${resultStr}` : resultStr;
}

/**
 * Generates common base representation breakdown for a BigInt value.
 * @param {bigint} val - Parsed BigInt value.
 * @returns {object} Object with bin, oct, dec, hex, base36 representations.
 */
function getCommonBases(val) {
  const isNeg = val < 0n;
  const abs = isNeg ? -val : val;
  const sign = isNeg ? '-' : '';

  return {
    bin: sign + abs.toString(2),
    oct: sign + abs.toString(8),
    dec: sign + abs.toString(10),
    hex: sign + abs.toString(16).toUpperCase(),
    base36: sign + abs.toString(36).toUpperCase()
  };
}

module.exports = {
  name: 'base',
  aliases: ['baseconvert', 'radix'],
  category: 'utility',
  description: 'Converts numbers between different bases (2 through 36).',
  usage: '<number> [from_base] [to_base]',
  cooldown: 2,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    // 1. Show Help Card if no arguments
    if (args.length === 0) {
      const helpCard = createV2Card({
        color: config.COLORS?.PRIMARY || 0x5865F2,
        title: '🔢  Number Base & Radix Converter',
        description:
          `> Converts arbitrary-precision integers between bases **2** and **36**.\n\n` +
          `**Usage:**\n` +
          `• \`${prefix || '!'}base <number>\` — Multi-base overview (Binary, Octal, Hex, Base36)\n` +
          `• \`${prefix || '!'}base <number> <to_base>\` — Convert from Base 10 to target base\n` +
          `• \`${prefix || '!'}base <number> <from_base> <to_base>\` — Custom conversion\n\n` +
          `**Common Bases:**\n` +
          `• **Base 2:** Binary (\`0, 1\`)\n` +
          `• **Base 8:** Octal (\`0 - 7\`)\n` +
          `• **Base 10:** Decimal (\`0 - 9\`)\n` +
          `• **Base 16:** Hexadecimal (\`0 - 9, A - F\`)\n` +
          `• **Base 36:** Alphanumeric (\`0 - 9, A - Z\`)\n\n` +
          `**Examples:**\n` +
          `• \`${prefix || '!'}base 255\`\n` +
          `• \`${prefix || '!'}base 255 16\`\n` +
          `• \`${prefix || '!'}base 11111111 2 10\`\n` +
          `• \`${prefix || '!'}base FF 16 10\`\n` +
          `• \`${prefix || '!'}base tungsten 36 10\``,
        footerText: `Tungsten Radix Engine • Requested by ${message.author ? message.author.username : 'User'}`
      });

      return message.reply({ embeds: [helpCard] });
    }

    const rawNum = args[0].trim();
    const authorId = message.author?.id || '0';
    const dismissRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`base:delete:${authorId}`)
        .setLabel('Dismiss')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('<a:tungsten_trash:1567242891276062872>')
    );

    // 2. Single Argument: Multi-Base Breakdown
    if (args.length === 1) {
      try {
        const bigVal = parseBaseToBigInt(rawNum, 10);
        const bases = getCommonBases(bigVal);

        const card = createV2Card({
          color: 0x00FF88,
          title: `🔢  Radix Breakdown: ${rawNum.slice(0, 50)}`,
          description:
            `**Multi-Base Representation:**\n` +
            `• **Binary (Base 2):** \`${bases.bin.slice(0, 150)}\`\n` +
            `• **Octal (Base 8):** \`${bases.oct.slice(0, 150)}\`\n` +
            `• **Decimal (Base 10):** \`${bases.dec.slice(0, 150)}\`\n` +
            `• **Hexadecimal (Base 16):** \`${bases.hex.slice(0, 150)}\`\n` +
            `• **Base 36:** \`${bases.base36.slice(0, 150)}\`\n\n` +
            `-# BigInt Arbitrary Precision Engine`,
          footerText: `Requested by ${message.author ? message.author.username : 'User'}`
        });

        return message.reply({ embeds: [card], components: [dismissRow] });
      } catch (err) {
        // If it failed because it had non-decimal chars, suggest providing source base
        const errorCard = createV2Card({
          color: 0xFF3B30,
          title: '<a:tungsten_close:1567234632905138206>  Radix Conversion Notice',
          description:
            `> Input \`${rawNum.slice(0, 50)}\` contains characters outside Base 10.\n\n` +
            `Please specify the source base:\n` +
            `• \`${prefix || '!'}base ${rawNum.slice(0, 20)} <from_base> <to_base>\`\n` +
            `• Example: \`${prefix || '!'}base ${rawNum.slice(0, 20)} 16 10\``,
          footerText: `Requested by ${message.author ? message.author.username : 'User'}`
        });

        return message.reply({ embeds: [errorCard], components: [dismissRow] });
      }
    }

    // 3. Two Arguments: !base <number> <target_base> or auto-detect
    if (args.length === 2) {
      const targetRadix = parseInt(args[1], 10);
      try {
        if (isNaN(targetRadix) || targetRadix < 2 || targetRadix > 36) {
          throw new Error('Base must be an integer between 2 and 36');
        }

        // Test if number has hex or high base characters
        const cleanLower = rawNum.toLowerCase().replace(/^[-+]/, '');
        const hasHighChars = /[a-z]/.test(cleanLower);

        let sourceBase = 10;
        let destBase = targetRadix;

        if (hasHighChars) {
          // Input definitely has letters -> args[1] must be the source base, convert to 10
          sourceBase = targetRadix;
          destBase = 10;
        }

        const converted = convertBase(rawNum, sourceBase, destBase);

        const card = createV2Card({
          color: 0x00FF88,
          title: `🔢  Base ${sourceBase} ➔ Base ${destBase} Conversion`,
          description:
            `**Input (Base ${sourceBase}):**\n` +
            `\`\`\`txt\n${rawNum.slice(0, 500)}\n\`\`\`\n` +
            `**Result (Base ${destBase}):**\n` +
            `\`\`\`txt\n${converted.slice(0, 1000)}\n\`\`\`\n` +
            `-# BigInt Arbitrary Precision Engine`,
          footerText: `Requested by ${message.author ? message.author.username : 'User'}`
        });

        return message.reply({ embeds: [card], components: [dismissRow] });
      } catch (err) {
        const errorCard = createV2Card({
          color: 0xFF3B30,
          title: '<a:tungsten_close:1567234632905138206>  Radix Conversion Error',
          description:
            `**Input:** \`${rawNum} ${args[1]}\`\n\n` +
            `**Details:**\n` +
            `> ${err.message || 'Failed to convert base.'}\n\n` +
            `-# Supported bases range from 2 to 36.`,
          footerText: `Requested by ${message.author ? message.author.username : 'User'}`
        });

        return message.reply({ embeds: [errorCard], components: [dismissRow] });
      }
    }

    // 4. Three Arguments: !base <number> <from_base> <to_base>
    const fromBase = args[1];
    const toBase = args[2];

    try {
      const converted = convertBase(rawNum, fromBase, toBase);

      const card = createV2Card({
        color: 0x00FF88,
        title: `🔢  Base ${fromBase} ➔ Base ${toBase} Conversion`,
        description:
          `**Input (Base ${fromBase}):**\n` +
          `\`\`\`txt\n${rawNum.slice(0, 500)}\n\`\`\`\n` +
          `**Result (Base ${toBase}):**\n` +
          `\`\`\`txt\n${converted.slice(0, 1000)}\n\`\`\`\n` +
          `-# BigInt Arbitrary Precision Engine`,
        footerText: `Requested by ${message.author ? message.author.username : 'User'}`
      });

      return message.reply({ embeds: [card], components: [dismissRow] });
    } catch (err) {
      const errorCard = createV2Card({
        color: 0xFF3B30,
        title: '<a:tungsten_close:1567234632905138206>  Radix Conversion Error',
        description:
          `**Input:** \`${rawNum} ${fromBase} -> ${toBase}\`\n\n` +
          `**Details:**\n` +
          `> ${err.message || 'Failed to convert base.'}\n\n` +
          `-# Supported bases range from 2 to 36.`,
        footerText: `Requested by ${message.author ? message.author.username : 'User'}`
      });

      return message.reply({ embeds: [errorCard], components: [dismissRow] });
    }
  },

  convertBase,
  parseBaseToBigInt,
  getCommonBases
};
