/**
 * Avatar Command (Prefix & Slash)
 * Displays a user's avatar with format/size links
 */
const { createEmbed } = require('../../utils/tools');

function buildAvatarPayload(targetUser, client, author) {
  const user = targetUser?.user || targetUser;
  const hasAvatarFn = user && typeof user.displayAvatarURL === 'function';
  const avatarUrl = hasAvatarFn ? user.displayAvatarURL({ size: 2048 }) : 'https://cdn.discordapp.com/embed/avatars/0.png';
  const png = hasAvatarFn ? user.displayAvatarURL({ extension: 'png', size: 2048 }) : avatarUrl;
  const jpg = hasAvatarFn ? user.displayAvatarURL({ extension: 'jpg', size: 2048 }) : avatarUrl;
  const webp = hasAvatarFn ? user.displayAvatarURL({ extension: 'webp', size: 2048 }) : avatarUrl;

  const embed = createEmbed({
    color: client?.config?.COLORS?.PRIMARY || 0x2b2d31,
    title: `🖼️ Avatar — ${user?.username || 'User'}`,
    description: `[PNG](${png}) • [JPG](${jpg}) • [WEBP](${webp})`
  });

  embed.setImage(avatarUrl);
  embed.setFooter({ text: `Requested by ${author?.username || 'User'}` });

  return { embeds: [embed] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'avatar',
  description: 'Display high-resolution avatar of a user or yourself.',
  category: 'utility',
  usage: 'avatar [@member|id]',
  aliases: ['av', 'pfp'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const member = message.mentions?.members?.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : message.member);

    if (!member) {
      return message.reply('User not found.');
    }

    const payload = buildAvatarPayload(member, client, message.author);
    return message.reply(payload);
  },

  buildAvatarPayload
};
