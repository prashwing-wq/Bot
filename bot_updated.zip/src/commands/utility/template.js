const { PermissionFlagsBits, ChannelType, AttachmentBuilder } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const crypto = require('crypto');

module.exports = {
  name: 'template',
  aliases: ['tmpcreate', 'tmpload', 'tmplist', 'tmpinfo', 'tmpdel', 'tmpexport', 'tmpimport', 'servertemplate'],
  category: 'utility',
  description: 'Create, load, export, and manage server structure templates',
  usage: '<create <name> | load <id> | list | info <id> | delete <id> | export <id> | import>',
  cooldown: 5,
  permissions: ['Administrator'],
  botPermissions: ['ManageChannels', 'ManageRoles'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.Administrator)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Administrator** permission to manage server templates.');
    }

    const sdb = getServerDb(message.guild.id);
    let sub = (args[0] || 'list').toLowerCase();

    // Support direct alias routing e.g. !tmpcreate <name>
    if (message.content.toLowerCase().startsWith(`${prefix}tmpcreate`)) sub = 'create';
    else if (message.content.toLowerCase().startsWith(`${prefix}tmpload`)) sub = 'load';
    else if (message.content.toLowerCase().startsWith(`${prefix}tmplist`)) sub = 'list';
    else if (message.content.toLowerCase().startsWith(`${prefix}tmpinfo`)) sub = 'info';
    else if (message.content.toLowerCase().startsWith(`${prefix}tmpdel`)) sub = 'delete';
    else if (message.content.toLowerCase().startsWith(`${prefix}tmpexport`)) sub = 'export';
    else if (message.content.toLowerCase().startsWith(`${prefix}tmpimport`)) sub = 'import';

    if (sub === 'create') {
      const name = args.slice(sub === args[0]?.toLowerCase() ? 1 : 0).join(' ').trim() || `${message.guild.name} Template`;
      const templateId = `TMP-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

      // Extract roles defensively
      const roleColl = message.guild?.roles?.cache;
      const rolesArr = roleColl ? (typeof roleColl.filter === 'function' ? roleColl.filter(r => !r.managed && r.id !== message.guild.id) : Array.from(roleColl.values()).filter(r => !r.managed && r.id !== message.guild.id)) : [];
      const roles = Array.from(rolesArr.values ? rolesArr.values() : rolesArr).map(r => ({
        name: r.name,
        color: r.color,
        hoist: r.hoist,
        permissions: r.permissions?.bitfield ? r.permissions.bitfield.toString() : (r.permissions ? r.permissions.toString() : '0'),
        mentionable: r.mentionable
      }));

      // Extract categories and channels defensively
      const chColl = message.guild?.channels?.cache;
      const chArr = chColl ? (typeof chColl.filter === 'function' ? chColl.filter(c => c.type !== ChannelType.GuildDirectory) : Array.from(chColl.values()).filter(c => c.type !== ChannelType.GuildDirectory)) : [];
      const channels = Array.from(chArr.values ? chArr.values() : chArr).map(c => ({
        name: c.name,
        type: c.type,
        parentName: c.parent ? c.parent.name : null,
        position: c.rawPosition || 0
      }));

      const data = {
        name,
        guildName: message.guild.name,
        createdAt: Date.now(),
        creator: message.author.tag,
        roles,
        channels
      };

      const now = Math.floor(Date.now() / 1000);
      sdb.prepare(`
        INSERT INTO server_templates (id, guild_id, creator_id, name, description, data_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(templateId, message.guild.id, message.author.id, name, `Created by ${message.author.tag}`, JSON.stringify(data), now);

      const embed = createEmbed({
        title: '📦 Server Template Created',
        description: `Successfully captured guild structure into template **${name}**.\n\n` +
          `• **Template ID:** \`${templateId}\`\n` +
          `• **Roles Captured:** ${roles.length}\n` +
          `• **Channels Captured:** ${channels.length}\n\n` +
          `*To apply on another server where Tungsten is present, run:* \`${prefix}template load ${templateId}\`\n` +
          `*To export as JSON file:* \`${prefix}template export ${templateId}\``,
        color: 0x57F287
      });

      return message.reply({ embeds: [embed] });
    }

    if (sub === 'list') {
      const rows = sdb.prepare('SELECT id, name, created_at FROM server_templates WHERE guild_id = ? ORDER BY created_at DESC').all(message.guild.id);
      if (!rows || rows.length === 0) {
        return message.reply(`<a:tungsten_info:1567240890748248084> No templates saved for this server yet. Create one with \`${prefix}template create <name>\`.`);
      }

      const lines = rows.map(r => `• **${r.name}** — \`${r.id}\` (<t:${r.created_at}:R>)`);
      const embed = createEmbed({
        title: '📦 Saved Server Templates',
        description: lines.join('\n') + `\n\n• **Apply:** \`${prefix}template load <id>\`\n• **Info:** \`${prefix}template info <id>\`\n• **Export:** \`${prefix}template export <id>\``,
        color: 0x5865F2
      });

      return message.reply({ embeds: [embed] });
    }

    if (sub === 'info') {
      const templateId = args[1] || args[0];
      const row = sdb.prepare('SELECT id, name, description, data_json, created_at FROM server_templates WHERE id = ?').get(templateId);
      if (!row) return message.reply('<a:tungsten_close:1567234632905138206> Template not found.');

      const parsed = JSON.parse(row.data_json);
      const embed = createEmbed({
        title: `📦 Template Info — ${row.name}`,
        description: `Template Code: \`${row.id}\`\nCreator: ${parsed.creator || 'Unknown'}`,
        fields: [
          { name: '👥 Roles', value: `\`${parsed.roles?.length || 0}\` roles`, inline: true },
          { name: '📁 Channels', value: `\`${parsed.channels?.length || 0}\` channels`, inline: true },
          { name: '📅 Created At', value: `<t:${row.created_at}:F>`, inline: false }
        ],
        color: 0x5865F2
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'delete' || sub === 'del') {
      const templateId = args[1] || args[0];
      const res = sdb.prepare('DELETE FROM server_templates WHERE id = ?').run(templateId);
      if (res.changes === 0) return message.reply('<a:tungsten_close:1567234632905138206> Template not found.');
      return message.reply(`<a:tungsten_trash:1567242891276062872> Template \`${templateId}\` has been deleted.`);
    }

    if (sub === 'export') {
      const templateId = args[1] || args[0];
      const row = sdb.prepare('SELECT id, name, data_json FROM server_templates WHERE id = ?').get(templateId);
      if (!row) return message.reply('<a:tungsten_close:1567234632905138206> Template not found.');

      const buffer = Buffer.from(row.data_json, 'utf8');
      const attachment = new AttachmentBuilder(buffer, { name: `${row.id}_template.json` });
      return message.reply({
        content: `📦 Export for template **${row.name}** (\`${row.id}\`):`,
        files: [attachment]
      });
    }

    if (sub === 'load') {
      const templateId = args[1] || args[0];
      const row = sdb.prepare('SELECT id, name, data_json FROM server_templates WHERE id = ?').get(templateId);
      if (!row) return message.reply(`<a:tungsten_close:1567234632905138206> Template \`${templateId}\` not found in database.`);

      const parsed = JSON.parse(row.data_json);
      const statusMsg = await message.reply(`<a:tungsten_loading:1567241050567876698> Applying template **${row.name}** (${parsed.roles.length} roles, ${parsed.channels.length} channels)...`);

      let rolesCreated = 0;
      for (const r of parsed.roles) {
        if (!message.guild.roles.cache.some(existing => existing.name === r.name)) {
          try {
            const roleOpts = {
              name: r.name,
              hoist: r.hoist,
              permissions: BigInt(r.permissions || '0'),
              mentionable: r.mentionable,
              reason: `Template apply: ${row.name}`
            };
            if (r.color !== undefined && r.color !== null) {
              roleOpts.colors = { primaryColor: r.color, primary: r.color };
            }
            await message.guild.roles.create(roleOpts);
            rolesCreated++;
            await new Promise(res => setTimeout(res, 200));
          } catch (_) {}
        }
      }

      let channelsCreated = 0;
      for (const c of parsed.channels) {
        if (!message.guild.channels.cache.some(existing => existing.name === c.name)) {
          try {
            await message.guild.channels.create({
              name: c.name,
              type: c.type,
              reason: `Template apply: ${row.name}`
            });
            channelsCreated++;
            await new Promise(res => setTimeout(res, 250));
          } catch (_) {}
        }
      }

      const embed = createEmbed({
        title: '<a:tungsten_success:1567242523468890274> Server Template Applied',
        description: `Successfully restored layout from **${row.name}**.\n\n` +
          `• **New Roles Created:** ${rolesCreated}\n` +
          `• **New Channels Created:** ${channelsCreated}`,
        color: 0x57F287
      });

      return statusMsg.edit({ content: null, embeds: [embed] }).catch(() => null);
    }

    return message.reply(`Usage: \`${prefix}template <create <name> | load <id> | list | info <id> | delete <id> | export <id>>\``);
  }
};
