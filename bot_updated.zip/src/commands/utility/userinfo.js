/**
 * Userinfo Command (Prefix & Slash)
 * Displays comprehensive member profile, permissions, roles, and dates
 */
const { createEmbed } = require('../../utils/tools');

function buildUserInfoPayload(member, client, guild) {
  const user = member.user || member;
  const joinedAt = member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Unknown';
  const createdAt = user.createdTimestamp ? `<t:${Math.floor(user.createdTimestamp / 1000)}:R>` : 'Unknown';
  const roles = member.roles?.cache
    ? member.roles.cache
        .filter(r => r.id !== guild.id)
        .sort((a, b) => b.position - a.position)
        .map(r => r.toString())
    : [];

  const rolesDisplay = roles.length > 15
    ? `${roles.slice(0, 15).join(' ')} ... (+${roles.length - 15} more)`
    : (roles.length > 0 ? roles.join(' ') : 'None');

  const embed = createEmbed({
    color: member.displayColor || client?.config?.COLORS?.PRIMARY || 0x2b2d31,
    title: `${user.bot ? '[BOT] ' : ''}${user.username}`,
    thumbnail: (user && typeof user.displayAvatarURL === 'function') ? user.displayAvatarURL({ size: 256 }) : null,
    fields: [
      { name: 'User ID', value: `\`${user.id}\``, inline: true },
      { name: 'Nickname', value: member.nickname || 'None', inline: true },
      { name: 'Bot Owner', value: client?.config?.OWNER_IDS?.includes(user.id) ? 'Yes' : 'No', inline: true },
      { name: 'Registered', value: createdAt, inline: true },
      { name: 'Joined Server', value: joinedAt, inline: true },
      { name: 'Highest Role', value: member.roles?.highest ? member.roles.highest.toString() : 'None', inline: true },
      { name: `Roles [${roles.length}]`, value: rolesDisplay, inline: false }
    ],
    footer: `Requested by ${user.username}`
  });

  return { embeds: [embed] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'userinfo',
  description: 'Display detailed account & server profile of a user.',
  category: 'utility',
  usage: 'userinfo [@member|id]',
  aliases: ['whois', 'user', 'ui'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command must be used in a server.');

    const member = message.mentions?.members?.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : message.member);

    if (!member) {
      return message.reply('User not found.');
    }

    const payload = buildUserInfoPayload(member, client, message.guild);
    return message.reply(payload);
  },

  buildUserInfoPayload
};
