/**
 * Emoji List Command (Node.js)
 * Displays all server custom emojis with slots used, animated vs static counts, and copyable IDs.
 */
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'emojilist',
  aliases: ['emojis', 'serveremojis', 'listemojis'],
  category: 'utility',
  description: 'Display all custom emojis in this server with slot statistics.',
  usage: 'emojilist',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const emojis = message.guild.emojis.cache;
    if (emojis.size === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> This server has no custom emojis uploaded yet.');
    }

    const staticEmojis = emojis.filter(e => !e.animated);
    const animatedEmojis = emojis.filter(e => e.animated);

    // Tier slot limits
    const tier = message.guild.premiumTier;
    const maxSlots = tier === 3 ? 250 : tier === 2 ? 150 : tier === 1 ? 100 : 50;

    const emojiList = emojis.map(e => e.toString()).slice(0, 50).join(' ');
    const extraCount = emojis.size > 50 ? emojis.size - 50 : 0;

    const card = createV2Card({
      title: `🎨  Server Emojis • ${message.guild.name}`,
      description:
        `### 📊 Slot Capacity\n` +
        `• **Total Emojis:** \`${emojis.size}\`\n` +
        `• **Static Slots:** \`${staticEmojis.size}\` / \`${maxSlots}\`\n` +
        `• **Animated Slots:** \`${animatedEmojis.size}\` / \`${maxSlots}\`\n\n` +
        `### 🎭 Emoji Gallery (First 50)\n` +
        `${emojiList}${extraCount > 0 ? `\n\n*...and ${extraCount} more custom emojis.*` : ''}\n`,
      footerText: `Tungsten Emoji Suite • Use ${prefix}steal <emoji> to add more`
    });

    return message.reply({ embeds: [card] });
  }
};
