/**
 * Users Demographic Command (Node.js)
 * Displays server user statistics broken down into Total, Humans, Bots, and Online presence.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'users',
  aliases: ['serverusers', 'userstats'],
  category: 'utility',
  description: 'Displays guild user breakdown (Total, Humans, Bots, Online).',
  usage: '',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const guild = message.guild;
    const total = guild.memberCount || 0;
    const members = guild.members?.cache ? Array.from(guild.members.cache.values()) : [];

    const bots = members.filter(m => m && m.user?.bot).length;
    const humans = Math.max(0, total - bots);

    // Online members: presence status online, idle, or dnd
    const online = members.filter(m => {
      const status = m?.presence?.status;
      return status && status !== 'offline';
    }).length;

    const embed = createEmbed({
      color: 0x5865F2,
      title: `👥  Server Population Demographics • ${guild.name}`,
      description:
        `> Comprehensive analysis of server community members.\n\n` +
        `• 📊 **Total Population:** **${total.toLocaleString()}**\n` +
        `• 👤 **Humans:** **${humans.toLocaleString()}** (${total > 0 ? Math.round((humans / total) * 100) : 0}%)\n` +
        `• 🤖 **Bots:** **${bots.toLocaleString()}** (${total > 0 ? Math.round((bots / total) * 100) : 0}%)\n` +
        `• 🟢 **Online in Cache:** **${online.toLocaleString()}**\n\n` +
        `-# Cached Members: ${members.length.toLocaleString()}`
    });

    return message.reply({ embeds: [embed] });
  }
};
