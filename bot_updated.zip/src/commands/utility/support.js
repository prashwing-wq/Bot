/**
 * Support Command (Node.js)
 * Provides official Discord invite link to the Tungsten Support Server.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

function buildSupportPayload(client, author) {
  const botUser = client?.user;
  const botName = botUser?.username || 'Tungsten';
  const botAvatar = botUser ? botUser.displayAvatarURL({ dynamic: true }) : null;
  const supportServerUrl = config.SUPPORT_SERVER || 'https://discord.gg/tfDMjZS9YJ';
  const botId = botUser?.id || config.CLIENT_ID || '';
  const botInviteUrl = `https://discord.com/oauth2/authorize?client_id=${botId}&permissions=8&scope=bot%20applications.commands`;

  const { ICONS } = require('../../ui/icons');
  const description =
    `> Welcome to the official **${botName} Community & Support Center**.\n\n` +
    `### ${ICONS.info} Need Assistance or Have Questions?\n` +
    `Our developer and support team are available to help you with:\n` +
    `• **Antinuke & Automod Configuration:** Setup assistance and permission tuning\n` +
    `• **Bug Reports & Incident Response:** Live diagnostic escalation\n` +
    `• **Feature Requests & Feedback:** Shape future security updates\n` +
    `• **Whitelist & Bot Configuration Support:** Setup assistance & operational guidance\n\n` +
    `### ${ICONS.link} Official Support Link\n` +
    `• [Click here to join ${botName} Support Server](${supportServerUrl})\n`;

  const embed = createV2Card({
    color: 0x5865F2, // Discord Blurple
    title: `${ICONS.channel} ${botName} Official Support Server`,
    description,
    buttons: [
      { label: 'Join Support Server', style: ButtonStyle.Link, url: supportServerUrl, emoji: ICONS.link },
      { label: `Invite ${botName || 'Tungsten'}`, style: ButtonStyle.Link, url: botInviteUrl, emoji: ICONS.bot }
    ],
    buttonTitle: 'Community Links',
    footerText: `Tungsten Community • Requested by ${author ? author.username : 'User'}`
  });

  if (botAvatar && embed && embed.setThumbnail) {
    embed.setThumbnail(botAvatar);
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Join Support Server')
      .setStyle(ButtonStyle.Link)
      .setURL(supportServerUrl)
      .setEmoji(ICONS.link),
    new ButtonBuilder()
      .setLabel(`Invite ${botName || 'Tungsten'}`)
      .setStyle(ButtonStyle.Link)
      .setURL(botInviteUrl)
      .setEmoji(ICONS.bot)
  );

  return { embeds: [embed], components: [row] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'support',
  aliases: ['supportserver', 'support-server', 'community', 'supp'],
  category: 'utility',
  description: 'Get the official invite link to Tungsten Support Server.',
  usage: 'support',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const payload = buildSupportPayload(client, message.author);
    return message.reply(payload);
  },

  buildSupportPayload
};
