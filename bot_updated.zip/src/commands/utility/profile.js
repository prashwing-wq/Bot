/**
 * User Profile & Reputation Command (Node.js)
 * Displays user identity, custom biography, reputation points, and stats.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'profile',
  aliases: ['setbio', 'setcolor', 'rep', 'reputation'],
  category: 'utility',
  description: 'View or customize your server profile, set a bio/color, or award reputation points.',
  usage: '[@user | setbio <text> | setcolor <#hex> | rep <@user>]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/ +/)[0] : message.content?.trim().split(/ +/)[0]) || 'profile').toLowerCase();
    const sub = args[0]?.toLowerCase();

    // 1. Give Reputation Points
    if (invoked === 'rep' || invoked === 'reputation' || sub === 'rep') {
      const targetUser = message.mentions?.users?.first() || (args[1] ? await client.users.fetch(args[1]).catch(() => null) : null);
      if (!targetUser) {
        return message.reply(`Please mention the user you want to award rep to: \`${prefix}rep @user\``);
      }
      if (targetUser.id === message.author.id) {
        return message.reply('You cannot award reputation points to yourself.');
      }
      if (targetUser.bot) {
        return message.reply('You cannot award reputation to bots.');
      }

      const now = Math.floor(Date.now() / 1000);
      const COOLDOWN_SEC = 86400; // 24 hours

      const senderRow = sdb.prepare('SELECT last_rep FROM user_profiles WHERE user_id = ?').get(message.author.id);
      if (senderRow && senderRow.last_rep && (now - senderRow.last_rep < COOLDOWN_SEC)) {
        const remaining = COOLDOWN_SEC - (now - senderRow.last_rep);
        const hours = Math.floor(remaining / 3600);
        const mins = Math.floor((remaining % 3600) / 60);
        return message.reply(`You can award reputation again in **${hours}h ${mins}m**.`);
      }

      // Update target rep
      sdb.prepare(`
        INSERT INTO user_profiles (user_id, bio, color, rep, last_rep)
        VALUES (?, 'No bio set.', '#5865F2', 1, 0)
        ON CONFLICT(user_id) DO UPDATE SET rep = rep + 1
      `).run(targetUser.id);

      // Record sender cooldown
      sdb.prepare(`
        INSERT INTO user_profiles (user_id, bio, color, rep, last_rep)
        VALUES (?, 'No bio set.', '#5865F2', 0, ?)
        ON CONFLICT(user_id) DO UPDATE SET last_rep = excluded.last_rep
      `).run(message.author.id, now);

      const targetData = sdb.prepare('SELECT rep FROM user_profiles WHERE user_id = ?').get(targetUser.id);

      const card = createV2Card({
        color: 0x57F287,
        title: 'Reputation Awarded',
        description:
          `${message.author} gave **+1 Rep** to ${targetUser}.\n\n` +
          `• ${targetUser.username} now has **${targetData ? targetData.rep : 1}** reputation point(s).`
      });

      return message.reply({ embeds: [card] });
    }

    // 2. Set Custom Biography
    if (invoked === 'setbio' || sub === 'bio' || sub === 'setbio') {
      const bioText = (invoked === 'setbio' ? args : args.slice(1)).join(' ');
      if (!bioText) {
        return message.reply(`Usage: \`${prefix}setbio <your biography here>\``);
      }
      if (bioText.length > 250) {
        return message.reply('Biography cannot exceed 250 characters.');
      }

      sdb.prepare(`
        INSERT INTO user_profiles (user_id, bio, color, rep, last_rep)
        VALUES (?, ?, '#5865F2', 0, 0)
        ON CONFLICT(user_id) DO UPDATE SET bio = excluded.bio
      `).run(message.author.id, bioText);

      return message.reply('Your profile biography has been updated.');
    }

    // 3. Set Profile Color
    if (invoked === 'setcolor' || sub === 'color' || sub === 'setcolor') {
      const colorHex = (invoked === 'setcolor' ? args[0] : args[1]) || '';
      const hexRegex = /^#?([0-9A-Fa-f]{6})$/;
      if (!hexRegex.test(colorHex)) {
        return message.reply(`Usage: \`${prefix}setcolor #5865F2\` (must be a valid 6-digit hex code)`);
      }
      const formattedHex = colorHex.startsWith('#') ? colorHex : `#${colorHex}`;

      sdb.prepare(`
        INSERT INTO user_profiles (user_id, bio, color, rep, last_rep)
        VALUES (?, 'No bio set.', ?, 0, 0)
        ON CONFLICT(user_id) DO UPDATE SET color = excluded.color
      `).run(message.author.id, formattedHex);

      return message.reply(`Your profile accent color has been set to \`${formattedHex}\`.`);
    }

    // 4. View User Profile
    const targetMember = message.mentions?.members?.first() || (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : message.member);
    if (!targetMember) return message.reply('Could not find that member.');

    const profileData = sdb.prepare('SELECT bio, color, rep FROM user_profiles WHERE user_id = ?').get(targetMember.id) || {
      bio: 'No bio set.',
      color: '#5865F2',
      rep: 0
    };

    const levelData = sdb.prepare('SELECT xp, level FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(message.guild.id, targetMember.id) || {
      xp: 0,
      level: 0
    };

    let accentColor = 0x2b2d31;
    try {
      accentColor = parseInt(profileData.color.replace('#', ''), 16);
    } catch (e) {}

    const card = createV2Card({
      color: accentColor,
      title: `${targetMember.displayName || targetMember.user.username}`,
      description:
        `> ${profileData.bio}\n\n` +
        `**Reputation** — \`${profileData.rep}\` · **Level** — \`${levelData.level}\` (\`${levelData.xp} XP\`)\n` +
        `Joined — <t:${Math.floor(targetMember.joinedTimestamp / 1000)}:D> · Created — <t:${Math.floor(targetMember.user.createdTimestamp / 1000)}:D>\n\n` +
        `-# ${prefix}setbio to change bio · ${prefix}rep to give reputation`,
      footerText: `ID: ${targetMember.id}`
    });

    if (targetMember.user && typeof targetMember.user.displayAvatarURL === 'function') {
      const avatarUrl = targetMember.user.displayAvatarURL({ forceStatic: false });
      if (typeof avatarUrl === 'string' && avatarUrl.startsWith('http')) {
        card.setThumbnail(avatarUrl);
      }
    }

    return message.reply({ embeds: [card] });
  }
};
