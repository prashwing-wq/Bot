/**
 * Media-Only Channels Command (Node.js)
 * Designates channels where only attachments, embeds, and media links are permitted.
 * Supports role-based bypasses so staff/media creators can chat freely.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'media',
  aliases: ['mediaonly', 'mediamode'],
  category: 'utility',
  description: 'Manage media-only channels and bypass roles.',
  usage: '<setup <#channel> | remove <#channel> | config | bypass <add|remove|show> <@role>>',
  cooldown: 3,
  permissions: ['ManageChannels'],
  botPermissions: ['ManageMessages'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Channels` permission to configure media channels.'
          })
        ]
      });
    }

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || '').toLowerCase();

    switch (sub) {
      case 'setup':
      case 'add':
      case 'set':
        return this.handleSetup(message, args.slice(1), client, sdb, prefix);
      case 'remove':
      case 'del':
      case 'delete':
        return this.handleRemove(message, args.slice(1), client, sdb, prefix);
      case 'config':
      case 'list':
      case 'show':
        return this.handleConfig(message, client, sdb, prefix);
      case 'bypass':
        return this.handleBypass(message, args.slice(1), client, sdb, prefix);
      default: {
        const embed = createEmbed({
          color: 0x2b2d31,
          title: '📸  Media-Only Channel Management',
          description:
            `> Enforce that designated channels only allow pictures, videos, files, and links.\n\n` +
            `• **\`${prefix}media setup <#channel>\`** — Mark channel as media-only\n` +
            `• **\`${prefix}media remove <#channel>\`** — Remove media restriction from channel\n` +
            `• **\`${prefix}media config\`** — View configured media channels & bypass roles\n` +
            `• **\`${prefix}media bypass add <@role>\`** — Add role immune to media deletion\n` +
            `• **\`${prefix}media bypass remove <@role>\`** — Remove immune role\n` +
            `• **\`${prefix}media bypass show\`** — List all current bypass roles`
        });
        return message.reply({ embeds: [embed] });
      }
    }
  },

  async handleSetup(message, args, client, sdb, prefix) {
    const targetChannel = message.mentions.channels.first()
      || (args[0] ? message.guild.channels.cache.get(args[0].replace(/[<#>]/g, '')) : null)
      || message.channel;

    if (!targetChannel || typeof targetChannel.isTextBased !== 'function' || !targetChannel.isTextBased()) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Please mention a valid text channel: \`${prefix}media setup <#channel>\``);
    }

    const now = Math.floor(Date.now() / 1000);
    sdb.prepare(`
      INSERT INTO media_channels (guild_id, channel_id, added_by, added_at)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(guild_id, channel_id) DO UPDATE SET added_by = excluded.added_by, added_at = excluded.added_at
    `).run(message.guild.id, targetChannel.id, message.author.id, now);

    const embed = createEmbed({
      color: client.config.COLORS.SUCCESS,
      title: '📸  Media Channel Configured',
      description:
        `> ${targetChannel} has been marked as **media-only**.\n\n` +
        `• **Channel:** ${targetChannel} (\`${targetChannel.id}\`)\n` +
        `• **Enforcement:** Messages without an attachment, embed, or image/video link will be automatically removed.\n` +
        `• **Bypass:** Members with Administrator or configured bypass roles can chat normally.`
    });
    return message.reply({ embeds: [embed] });
  },

  async handleRemove(message, args, client, sdb, prefix) {
    const targetChannel = message.mentions.channels.first()
      || (args[0] ? message.guild.channels.cache.get(args[0].replace(/[<#>]/g, '')) : null)
      || message.channel;

    const res = sdb.prepare('DELETE FROM media_channels WHERE guild_id = ? AND channel_id = ?').run(message.guild.id, targetChannel.id);

    if (res.changes === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> That channel is not currently configured as a media channel.');
    }

    const embed = createEmbed({
      color: client.config.COLORS.SUCCESS,
      title: '📸  Media Restriction Removed',
      description: `Successfully removed media restriction from ${targetChannel}. Standard chatting is restored.`
    });
    return message.reply({ embeds: [embed] });
  },

  async handleConfig(message, client, sdb, prefix) {
    const channels = sdb.prepare('SELECT channel_id, added_at FROM media_channels WHERE guild_id = ?').all(message.guild.id);
    const bypasses = sdb.prepare('SELECT role_id FROM media_bypass_roles WHERE guild_id = ?').all(message.guild.id);

    const channelLines = channels.length > 0
      ? channels.map(c => `• <#${c.channel_id}> (\`${c.channel_id}\`)`).join('\n')
      : '*No media channels configured.*';

    const bypassLines = bypasses.length > 0
      ? bypasses.map(b => `• <@&${b.role_id}> (\`${b.role_id}\`)`).join('\n')
      : '*No bypass roles configured.*';

    const embed = createEmbed({
      color: 0x5865F2,
      title: `📸  Media System Configuration • ${message.guild.name}`,
      fields: [
        { name: `Media Channels (${channels.length})`, value: channelLines, inline: false },
        { name: `Bypass Roles (${bypasses.length})`, value: bypassLines, inline: false }
      ]
    });
    return message.reply({ embeds: [embed] });
  },

  async handleBypass(message, args, client, sdb, prefix) {
    const action = (args[0] || '').toLowerCase();

    if (action === 'show' || action === 'list') {
      const bypasses = sdb.prepare('SELECT role_id, added_at FROM media_bypass_roles WHERE guild_id = ?').all(message.guild.id);
      if (bypasses.length === 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> No roles currently have media bypass permissions.');
      }
      const list = bypasses.map((b, i) => `\`${i + 1}.\` <@&${b.role_id}> (\`${b.role_id}\`)`).join('\n');
      const embed = createEmbed({
        color: 0x5865F2,
        title: '🛡️  Media Bypass Roles',
        description: list
      });
      return message.reply({ embeds: [embed] });
    }

    if (action === 'add') {
      const roleMention = message.mentions.roles.first() || (args[1] ? message.guild.roles.cache.get(args[1].replace(/[<@&>]/g, '')) : null);
      if (!roleMention) {
        return message.reply(`Usage: \`${prefix}media bypass add <@role>\``);
      }
      const now = Math.floor(Date.now() / 1000);
      sdb.prepare(`
        INSERT INTO media_bypass_roles (guild_id, role_id, added_by, added_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(guild_id, role_id) DO NOTHING
      `).run(message.guild.id, roleMention.id, message.author.id, now);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🛡️  Media Bypass Added',
            description: `Successfully granted media channel bypass to ${roleMention}.`
          })
        ]
      });
    }

    if (action === 'remove' || action === 'del') {
      const roleMention = message.mentions.roles.first() || (args[1] ? message.guild.roles.cache.get(args[1].replace(/[<@&>]/g, '')) : null);
      if (!roleMention) {
        return message.reply(`Usage: \`${prefix}media bypass remove <@role>\``);
      }
      sdb.prepare('DELETE FROM media_bypass_roles WHERE guild_id = ? AND role_id = ?').run(message.guild.id, roleMention.id);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🛡️  Media Bypass Removed',
            description: `Removed media channel bypass from ${roleMention}.`
          })
        ]
      });
    }

    return message.reply(`Usage: \`${prefix}media bypass <add <@role> | remove <@role> | show>\``);
  }
};
