/**
 * Tungsten Modules & Feature Management Command (Node.js)
 * Configure and toggle server features with interactive Components select menu and buttons.
 */
const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField
} = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const {
  AVAILABLE_MODULES,
  isModuleEnabled,
  setModuleStatus,
  toggleModule,
  getAllModuleStatuses
} = require('../../utils/modulesHelper');

function buildModulesDashboardPayload(guildId, client) {
  const statuses = getAllModuleStatuses(guildId);
  const modulesList = Object.values(statuses);

  let desc = 'Configure and toggle server subsystems on-the-fly. Select a module from the dropdown below or toggle specific features using commands.\n\n';

  for (const mod of modulesList) {
    const icon = mod.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>';
    const state = mod.enabled ? '**ENABLED**' : '*DISABLED*';
    desc += `${icon} **${mod.name}** (\`${mod.id}\`) — ${state}\n> *${mod.description}*\n\n`;
  }

  const embed = createEmbed({
    color: client?.config?.COLORS?.PRIMARY || 0x5865F2,
    title: '<a:tungsten_tools:1567242831834124431> Server Modules & Automation Dashboard',
    description: desc.trim(),
    footer: { text: 'Tungsten Enterprise Modular Architecture' },
    timestamp: true
  });

  // Select menu options
  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('modtgl:select')
    .setPlaceholder('Select a module to toggle its state...')
    .addOptions(
      modulesList.map(mod => ({
        label: mod.name,
        value: mod.id,
        description: `${mod.enabled ? 'Currently Active • Click to Disable' : 'Currently Off • Click to Enable'}`,
        emoji: mod.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>'
      }))
    );

  const row1 = new ActionRowBuilder().addComponents(selectMenu);

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('modtgl:btn:enable_all')
      .setLabel('Enable All')
      .setEmoji('<a:tungsten_ui_toggle_on:1569329685110849576>')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('modtgl:btn:disable_all')
      .setLabel('Disable All')
      .setEmoji('<a:tungsten_ui_toggle_off:1569329677187678368>')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('modtgl:btn:refresh')
      .setLabel('Refresh')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row1, row2] };
}

module.exports = {
  name: 'modules',
  description: 'Manage and toggle server features and automation modules.',
  category: 'utility',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: 'modules [list|enable|disable|toggle] [module_name]',
  aliases: ['module', 'feature', 'features'],
  cooldown: 3,
  buildModulesDashboardPayload,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) && !hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need `Manage Server` or `Administrator` permission to manage server modules.'
          })
        ]
      });
    }

    const sub = (args[0] || '').toLowerCase();

    // 1. LIST
    if (sub === 'list') {
      const statuses = getAllModuleStatuses(message.guild.id);
      let desc = '';
      for (const mod of Object.values(statuses)) {
        const icon = mod.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>';
        desc += `${icon} **${mod.name}** (\`${mod.id}\`) — ${mod.enabled ? 'Enabled' : 'Disabled'}\n`;
      }
      desc += `\n*Toggle: \`${prefix}modules toggle <name>\` | Enable: \`${prefix}modules enable <name>\`*`;

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: '<a:tungsten_tools:1567242831834124431> Server Modules Status',
            description: desc
          })
        ]
      });
    }

    // 2. ENABLE
    if (sub === 'enable' || sub === 'on') {
      const target = (args[1] || '').toLowerCase();
      const match = AVAILABLE_MODULES.find(m => m.id === target || m.name.toLowerCase().includes(target));

      if (!match) {
        return message.reply(`Unknown module. Available modules: \`${AVAILABLE_MODULES.map(m => m.id).join(', ')}\``);
      }

      setModuleStatus(message.guild.id, match.id, true);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_ui_toggle_on:1569329685110849576> Module Enabled',
            description: `Successfully enabled **${match.name}** (\`${match.id}\`).`
          })
        ]
      });
    }

    // 3. DISABLE
    if (sub === 'disable' || sub === 'off') {
      const target = (args[1] || '').toLowerCase();
      const match = AVAILABLE_MODULES.find(m => m.id === target || m.name.toLowerCase().includes(target));

      if (!match) {
        return message.reply(`Unknown module. Available modules: \`${AVAILABLE_MODULES.map(m => m.id).join(', ')}\``);
      }

      setModuleStatus(message.guild.id, match.id, false);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: '<a:tungsten_ui_toggle_off:1569329677187678368> Module Disabled',
            description: `Successfully disabled **${match.name}** (\`${match.id}\`).`
          })
        ]
      });
    }

    // 4. TOGGLE
    if (sub === 'toggle') {
      const target = (args[1] || '').toLowerCase();
      const match = AVAILABLE_MODULES.find(m => m.id === target || m.name.toLowerCase().includes(target));

      if (!match) {
        return message.reply(`Unknown module. Available modules: \`${AVAILABLE_MODULES.map(m => m.id).join(', ')}\``);
      }

      const newState = toggleModule(message.guild.id, match.id);
      return message.reply({
        embeds: [
          createEmbed({
            color: newState ? client.config.COLORS.SUCCESS : client.config.COLORS.WARNING,
            title: `${newState ? '<a:tungsten_ui_toggle_on:1569329685110849576>' : '<a:tungsten_ui_toggle_off:1569329677187678368>'} Module Toggled`,
            description: `**${match.name}** (\`${match.id}\`) is now **${newState ? 'ENABLED' : 'DISABLED'}**.`
          })
        ]
      });
    }

    // 5. DASHBOARD (Default when no sub or 'dashboard')
    const payload = buildModulesDashboardPayload(message.guild.id, client);
    return message.reply(payload);
  }
};
