/**
 * Tungsten Discord Native Scheduled Event Command (Node.js)
 * Manages native Discord Guild Scheduled Events (list, create, cancel).
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  GuildScheduledEventEntityType,
  GuildScheduledEventPrivacyLevel,
  GuildScheduledEventStatus
} = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

const STATUS_NAMES = {
  [GuildScheduledEventStatus.Scheduled]: 'Scheduled',
  [GuildScheduledEventStatus.Active]: 'Active / Live',
  [GuildScheduledEventStatus.Completed]: 'Completed',
  [GuildScheduledEventStatus.Canceled]: 'Canceled'
};

function parseQuotedArgs(text) {
  const regex = /[^\s"']+|"([^"]*)"|'([^']*)'/g;
  const tokens = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    tokens.push(match[1] || match[2] || match[0]);
  }
  return tokens;
}

function parseRelativeOrAbsoluteTime(input) {
  if (!input) return null;
  const s = String(input).trim();

  // Relative: e.g. 10m, 2h, 1d, 30s
  const relMatch = s.match(/^(\d+)([smhd])$/i);
  if (relMatch) {
    const val = parseInt(relMatch[1], 10);
    const unit = relMatch[2].toLowerCase();
    const mult = unit === 's' ? 1000 : unit === 'm' ? 60000 : unit === 'h' ? 3600000 : 86400000;
    return new Date(Date.now() + val * mult);
  }

  // Absolute / ISO
  const parsed = Date.parse(s);
  if (!isNaN(parsed)) {
    return new Date(parsed);
  }

  return null;
}

module.exports = {
  name: 'discordevent',
  aliases: ['event', 'events', 'scheduledevent'],
  category: 'utility',
  description: 'Manage native Discord scheduled events in the server.',
  usage: '<list | create <name> <start-time> [description] | delete <id>>',
  cooldown: 3,
  permissions: ['ManageEvents'],
  botPermissions: ['ManageEvents'],

  slash: new SlashCommandBuilder()
    .setName('discordevent')
    .setDescription('Manage native Discord scheduled events.')
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all scheduled events in this server.')
    )
    .addSubcommand(sub =>
      sub
        .setName('delete')
        .setDescription('Cancel and delete a scheduled event.')
        .addStringOption(opt =>
          opt
            .setName('event_id')
            .setDescription('ID of the scheduled event to delete.')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('create')
        .setDescription('Create a new scheduled event.')
        .addStringOption(opt =>
          opt
            .setName('name')
            .setDescription('Name of the event.')
            .setRequired(true)
        )
        .addStringOption(opt =>
          opt
            .setName('start_time')
            .setDescription('Start time (e.g. 30m, 2h, 1d, or ISO string).')
            .setRequired(true)
        )
        .addStringOption(opt =>
          opt
            .setName('description')
            .setDescription('Optional description for the event.')
            .setRequired(false)
        )
        .addStringOption(opt =>
          opt
            .setName('location')
            .setDescription('Location or stage name (default: Discord Community).')
            .setRequired(false)
        )
    ),

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be executed inside a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.ManageEvents)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Events** permission to manage scheduled events.');
    }

    if (!message.guild.scheduledEvents) {
      return message.reply('<a:tungsten_close:1567234632905138206> Discord scheduled events are not supported in this guild or missing permissions.');
    }

    const sub = (args[0] || 'list').toLowerCase();

    // 1. LIST
    if (sub === 'list') {
      try {
        const events = await message.guild.scheduledEvents.fetch();
        if (!events || events.size === 0) {
          const embed = createEmbed({
            color: 0x5865F2,
            title: '<a:tungsten_event:1569329363038638090> Server Scheduled Events',
            description: `No scheduled events found in this server.\n\nCreate one with:\n\`${prefix}event create "Community Hangout" 2h Join us for games!\``
          });
          return message.reply({ embeds: [embed] });
        }

        const fields = [];
        for (const [, ev] of events) {
          const statusText = STATUS_NAMES[ev.status] || `Status ${ev.status}`;
          const startSec = Math.floor(ev.scheduledStartTimestamp / 1000);
          const location = ev.entityMetadata?.location || (ev.channel ? `<#${ev.channel.id}>` : 'External');
          fields.push({
            name: `${ev.name} (\`${ev.id}\`)`,
            value:
              `• **Status:** \`${statusText}\`\n` +
              `• **Start:** <t:${startSec}:F> (<t:${startSec}:R>)\n` +
              `• **Location:** ${location}\n` +
              `• **Interested:** \`${ev.userCount || 0}\` users${ev.description ? `\n• **Description:** ${ev.description.slice(0, 150)}` : ''}`,
            inline: false
          });
        }

        const embed = createEmbed({
          color: 0x5865F2,
          title: `<a:tungsten_event:1569329363038638090> Server Scheduled Events (${events.size})`,
          fields: fields.slice(0, 25),
          footerText: `Use ${prefix}event delete <id> to cancel an event`
        });

        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to list scheduled events: ${err.message}`);
      }
    }

    // 2. DELETE / CANCEL
    if (sub === 'delete' || sub === 'cancel' || sub === 'remove') {
      const eventId = args[1];
      if (!eventId) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please provide the Event ID to delete.\nUsage: \`${prefix}event delete <event_id>\``);
      }

      try {
        const ev = await message.guild.scheduledEvents.fetch(eventId).catch(() => null);
        if (!ev) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Scheduled event with ID \`${eventId}\` was not found.`);
        }

        const evName = ev.name;
        await ev.delete();

        const embed = createEmbed({
          color: 0xED4245,
          title: '<a:tungsten_trash:1567242891276062872> Scheduled Event Canceled',
          description: `Successfully removed scheduled event **${evName}** (\`${eventId}\`).`
        });
        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to delete scheduled event: ${err.message}`);
      }
    }

    // 3. CREATE
    if (sub === 'create' || sub === 'new' || sub === 'add') {
      // Re-parse raw message text after 'create'
      let rawText = '';
      if (args && args.length > 1) {
        if (message.content && message.content.includes(args[1])) {
          rawText = message.content.slice(message.content.indexOf(args[1])).trim();
        } else {
          rawText = args.slice(1).join(' ');
        }
      }
      const tokens = parseQuotedArgs(rawText);

      if (tokens.length < 2) {
        return message.reply(
          `<a:tungsten_close:1567234632905138206> Invalid usage.\n` +
          `Usage: \`${prefix}event create <name> <start-time> [description]\`\n\n` +
          `Examples:\n` +
          `• \`${prefix}event create "Gaming Night" 2h Join us on VC\`\n` +
          `• \`${prefix}event create TownHall 1d Monthly server updates\``
        );
      }

      let eventName = '';
      let timeInput = '';
      let description = '';

      // Check if token[1] is a valid time
      const directTime = parseRelativeOrAbsoluteTime(tokens[1]);
      if (directTime) {
        eventName = tokens[0];
        timeInput = tokens[1];
        description = tokens.slice(2).join(' ');
      } else {
        // Find first token that matches a valid time
        let timeIdx = -1;
        for (let i = 1; i < tokens.length; i++) {
          if (parseRelativeOrAbsoluteTime(tokens[i])) {
            timeIdx = i;
            break;
          }
        }

        if (timeIdx !== -1) {
          eventName = tokens.slice(0, timeIdx).join(' ');
          timeInput = tokens[timeIdx];
          description = tokens.slice(timeIdx + 1).join(' ');
        } else {
          return message.reply(
            `<a:tungsten_close:1567234632905138206> Could not determine start time.\n` +
            `Please specify time as a relative offset (e.g. \`30m\`, \`2h\`, \`1d\`) or ISO date.`
          );
        }
      }

      const startTime = parseRelativeOrAbsoluteTime(timeInput);
      if (!startTime || isNaN(startTime.getTime())) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Invalid start time format: \`${timeInput}\`. Try \`30m\`, \`2h\`, or \`1d\`.`);
      }

      const minFuture = Date.now() + 30000;
      if (startTime.getTime() < minFuture) {
        return message.reply('<a:tungsten_close:1567234632905138206> Scheduled start time must be in the future (at least 30 seconds from now).');
      }

      const endTime = new Date(startTime.getTime() + 3600000); // 1 hour duration by default
      const finalName = eventName.slice(0, 100);

      try {
        const createdEvent = await message.guild.scheduledEvents.create({
          name: finalName,
          scheduledStartTime: startTime,
          scheduledEndTime: endTime,
          privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
          entityType: GuildScheduledEventEntityType.External,
          entityMetadata: { location: 'Discord Community' },
          description: description ? description.slice(0, 1000) : 'Scheduled community event.'
        });

        const startSec = Math.floor(startTime.getTime() / 1000);
        const embed = createEmbed({
          color: 0x57F287,
          title: '<a:tungsten_event:1569329363038638090> Scheduled Event Created',
          description:
            `Successfully scheduled **${createdEvent.name}**!\n\n` +
            `• **Event ID:** \`${createdEvent.id}\`\n` +
            `• **Starts:** <t:${startSec}:F> (<t:${startSec}:R>)\n` +
            `• **Location:** Discord Community\n` +
            `• **Description:** ${createdEvent.description || '*None provided*'}\n` +
            `• **Direct Link:** [Open Event](${createdEvent.url})`
        });

        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create scheduled event: ${err.message}`);
      }
    }

    // Default Help
    const helpEmbed = createEmbed({
      color: 0x5865F2,
      title: '<a:tungsten_event:1569329363038638090> Native Discord Scheduled Events',
      description:
        `Manage Discord platform-native scheduled events.\n\n` +
        `• **\`${prefix}event list\`** — List all scheduled events\n` +
        `• **\`${prefix}event create <name> <start-time> [description]\`** — Create a scheduled event\n` +
        `• **\`${prefix}event delete <id>\`** — Cancel a scheduled event\n\n` +
        `**Time formats:** \`30m\`, \`2h\`, \`1d\`, or ISO timestamp`,
      footerText: 'Requires Manage Events permission'
    });

    return message.reply({ embeds: [helpEmbed] });
  },

  async executeSlash(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    if (!hasPerm(interaction.member, PermissionFlagsBits.ManageEvents)) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need Manage Events permission to use this command.', ephemeral: true });
    }

    if (!interaction.guild.scheduledEvents) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> Scheduled events unavailable or missing permissions.', ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      await interaction.deferReply();
      const events = await interaction.guild.scheduledEvents.fetch().catch(() => null);
      if (!events || events.size === 0) {
        return interaction.editReply({
          embeds: [
            createEmbed({
              color: 0x5865F2,
              title: '<a:tungsten_event:1569329363038638090> Server Scheduled Events',
              description: 'No scheduled events found in this server.'
            })
          ]
        });
      }

      const fields = [];
      for (const [, ev] of events) {
        const statusText = STATUS_NAMES[ev.status] || `Status ${ev.status}`;
        const startSec = Math.floor(ev.scheduledStartTimestamp / 1000);
        fields.push({
          name: `${ev.name} (\`${ev.id}\`)`,
          value:
            `• **Status:** \`${statusText}\`\n` +
            `• **Start:** <t:${startSec}:F> (<t:${startSec}:R>)\n` +
            `• **Interested:** \`${ev.userCount || 0}\` users`,
          inline: false
        });
      }

      return interaction.editReply({
        embeds: [
          createEmbed({
            color: 0x5865F2,
            title: `<a:tungsten_event:1569329363038638090> Server Scheduled Events (${events.size})`,
            fields: fields.slice(0, 25)
          })
        ]
      });
    }

    if (sub === 'delete') {
      const id = interaction.options.getString('event_id');
      await interaction.deferReply();
      const ev = await interaction.guild.scheduledEvents.fetch(id).catch(() => null);
      if (!ev) {
        return interaction.editReply(`<a:tungsten_close:1567234632905138206> Scheduled event with ID \`${id}\` not found.`);
      }
      const name = ev.name;
      await ev.delete();
      return interaction.editReply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            title: '<a:tungsten_trash:1567242891276062872> Scheduled Event Canceled',
            description: `Successfully deleted event **${name}** (\`${id}\`).`
          })
        ]
      });
    }

    if (sub === 'create') {
      const name = interaction.options.getString('name');
      const timeInput = interaction.options.getString('start_time');
      const desc = interaction.options.getString('description') || 'Scheduled community event.';
      const loc = interaction.options.getString('location') || 'Discord Community';

      const startTime = parseRelativeOrAbsoluteTime(timeInput);
      if (!startTime || isNaN(startTime.getTime()) || startTime.getTime() <= Date.now() + 30000) {
        return interaction.reply({
          content: '<a:tungsten_close:1567234632905138206> Invalid start time. Must be in the future (e.g. `30m`, `2h`, `1d`).',
          ephemeral: true
        });
      }

      await interaction.deferReply();
      const endTime = new Date(startTime.getTime() + 3600000);

      try {
        const ev = await interaction.guild.scheduledEvents.create({
          name: name.slice(0, 100),
          scheduledStartTime: startTime,
          scheduledEndTime: endTime,
          privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
          entityType: GuildScheduledEventEntityType.External,
          entityMetadata: { location: loc.slice(0, 100) },
          description: desc.slice(0, 1000)
        });

        const startSec = Math.floor(startTime.getTime() / 1000);
        return interaction.editReply({
          embeds: [
            createEmbed({
              color: 0x57F287,
              title: '<a:tungsten_event:1569329363038638090> Scheduled Event Created',
              description:
                `Successfully created scheduled event **${ev.name}**!\n\n` +
                `• **Start:** <t:${startSec}:F> (<t:${startSec}:R>)\n` +
                `• **Link:** [View Event](${ev.url})`
            })
          ]
        });
      } catch (err) {
        return interaction.editReply(`<a:tungsten_close:1567234632905138206> Failed to create scheduled event: ${err.message}`);
      }
    }
  }
};
