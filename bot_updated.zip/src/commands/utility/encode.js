/**
 * Tungsten Text Encoder & Decoder Command (Node.js)
 * Supports Base64, URL/URI, HTML Entities, Binary (8-bit ASCII/UTF-8), and Morse Code.
 */
const { createV2Card } = require('../../utils/componentsV2');

const MORSE_MAP = {
  'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
  'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
  'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
  'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
  'Y': '-.--', 'Z': '--..',
  '0': '-----', '1': '.----', '2': '..---', '3': '...--', '4': '....-',
  '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.',
  '.': '.-.-.-', ',': '--..--', '?': '..--..', "'": '.----.', '!': '-.-.--',
  '/': '-..-.', '(': '-.--.', ')': '-.--.-', '&': '.-...', ':': '---...',
  ';': '-.-.-.', '=': '-...-', '+': '.-.-.', '-': '-....-', '_': '..--.-',
  '"': '.-..-.', '$': '...-..-', '@': '.--.-.'
};

const REVERSE_MORSE = Object.entries(MORSE_MAP).reduce((acc, [char, code]) => {
  acc[code] = char;
  return acc;
}, {});

const HTML_ENTITIES = {
  '&amp;': '&',
  '&lt;': '<',
  '&gt;': '>',
  '&quot;': '"',
  '&#39;': "'",
  '&apos;': "'",
  '&nbsp;': ' ',
  '&copy;': '©',
  '&reg;': '®',
  '&trade;': '™',
  '&euro;': '€',
  '&pound;': '£',
  '&yen;': '¥',
  '&cent;': '¢',
  '&sect;': '§',
  '&deg;': '°',
  '&plusmn;': '±',
  '&times;': '×',
  '&divide;': '÷'
};

function encodeMorse(text) {
  return text
    .toUpperCase()
    .split(/\r?\n/)
    .map(line =>
      line
        .split(/\s+/)
        .map(word =>
          Array.from(word)
            .map(ch => MORSE_MAP[ch] || ch)
            .join(' ')
        )
        .join(' / ')
    )
    .join('\n');
}

function decodeMorse(text) {
  return text
    .split(/\r?\n/)
    .map(line =>
      line
        .split(/\s*\/\s*|\s{3,}/)
        .map(word =>
          word
            .trim()
            .split(/\s+/)
            .map(code => REVERSE_MORSE[code] || (code === '' ? '' : '?'))
            .join('')
        )
        .join(' ')
    )
    .join('\n');
}

function encodeBinary(text) {
  const buf = Buffer.from(text, 'utf-8');
  return Array.from(buf)
    .map(b => b.toString(2).padStart(8, '0'))
    .join(' ');
}

function decodeBinary(text) {
  const tokens = text.trim().split(/\s+/).filter(t => /^[01]+$/.test(t));
  let bytes = [];
  if (tokens.length > 0) {
    bytes = tokens.map(b => parseInt(b, 2));
  } else {
    const clean = text.replace(/[^01]/g, '');
    const chunks = clean.match(/.{1,8}/g) || [];
    bytes = chunks.map(b => parseInt(b, 2));
  }
  return Buffer.from(bytes).toString('utf-8');
}

function encodeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function decodeHtml(text) {
  let result = text;
  for (const [entity, char] of Object.entries(HTML_ENTITIES)) {
    result = result.split(entity).join(char);
  }
  result = result.replace(/&#(\d+);/g, (_, dec) => {
    const code = parseInt(dec, 10);
    return isNaN(code) ? _ : String.fromCharCode(code);
  });
  result = result.replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => {
    const code = parseInt(hex, 16);
    return isNaN(code) ? _ : String.fromCharCode(code);
  });
  return result;
}

function executeConversion(action, mode, text) {
  const normMode = String(mode).toLowerCase();
  switch (normMode) {
    case 'base64':
    case 'b64':
      if (action === 'encode') {
        return Buffer.from(text, 'utf-8').toString('base64');
      } else {
        const clean = text.replace(/\s+/g, '');
        return Buffer.from(clean, 'base64').toString('utf-8');
      }

    case 'url':
    case 'uri':
      if (action === 'encode') {
        return encodeURIComponent(text);
      } else {
        try {
          return decodeURIComponent(text);
        } catch {
          return unescape(text);
        }
      }

    case 'html':
    case 'entity':
    case 'entities':
      return action === 'encode' ? encodeHtml(text) : decodeHtml(text);

    case 'binary':
    case 'bin':
    case 'bits':
      return action === 'encode' ? encodeBinary(text) : decodeBinary(text);

    case 'morse':
    case 'morsecode':
      return action === 'encode' ? encodeMorse(text) : decodeMorse(text);

    default:
      return null;
  }
}

module.exports = {
  name: 'encode',
  aliases: ['decode', 'encoder', 'decoder'],
  category: 'utility',
  description: 'Encode or decode text in Base64, URL, HTML entities, Binary, or Morse code.',
  usage: '<base64|url|html|binary|morse> <text> | decode <mode> <text>',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 2,

  async execute(message, args, client, prefix = '!') {
    const argsCopy = [...args];
    let action = 'encode';

    // Check if invoked with decode alias or explicit flag
    const invoked = message?.content
      ? message.content.slice(prefix.length).trim().split(/\s+/)[0]?.toLowerCase()
      : '';

    if (argsCopy[0] === '--decode') {
      action = 'decode';
      argsCopy.shift();
    } else if (invoked === 'decode' || invoked === 'decoder') {
      action = 'decode';
      if (argsCopy[0]?.toLowerCase() === 'decode') {
        argsCopy.shift();
      }
    } else if (argsCopy[0]?.toLowerCase() === 'decode' || argsCopy[0]?.toLowerCase() === 'dec') {
      action = 'decode';
      argsCopy.shift();
    } else if (argsCopy[0]?.toLowerCase() === 'encode' || argsCopy[0]?.toLowerCase() === 'enc') {
      action = 'encode';
      argsCopy.shift();
    }

    if (argsCopy.length === 0) {
      const card = createV2Card({
        color: 0x5865F2,
        title: '<a:tungsten_encode:1569329355111538820> Tungsten • Text Encoder & Decoder',
        description:
          `Transform text across multiple popular encoding schemes and formats.\n\n` +
          `**Syntax & Usage:**\n` +
          `• \`${prefix}encode <mode> <text>\`\n` +
          `• \`${prefix}decode <mode> <text>\`\n\n` +
          `**Supported Formats:**\n` +
          `• \`base64\` — Standard RFC 4648 Base64 data representation\n` +
          `• \`url\` — Percent-encoding for URI query strings and components\n` +
          `• \`html\` — Named & numeric HTML entity conversion\n` +
          `• \`binary\` — 8-bit UTF-8 octet bitstrings\n` +
          `• \`morse\` — International Morse code with \`/\` word delimitation\n\n` +
          `**Examples:**\n` +
          `• \`${prefix}encode base64 Hello Tungsten\`\n` +
          `• \`${prefix}decode base64 SGVsbG8gQ2VsZXN0aWE=\`\n` +
          `• \`${prefix}encode morse SOS We Need Backup\`\n` +
          `• \`${prefix}decode morse ... --- ...\`\n` +
          `• \`${prefix}encode binary High Speed\``,
        footerText: `Requested by ${message.author?.username || 'User'}`
      });
      return message.reply({ embeds: [card] });
    }

    const mode = argsCopy[0]?.toLowerCase();
    const text = argsCopy.slice(1).join(' ').trim();

    if (!text) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Please provide text to ${action}.\nExample: \`${prefix}${action} ${mode} <your text here>\``);
    }

    const validModes = ['base64', 'b64', 'url', 'uri', 'html', 'entity', 'entities', 'binary', 'bin', 'bits', 'morse', 'morsecode'];
    if (!validModes.includes(mode)) {
      return message.reply(
        `<a:tungsten_close:1567234632905138206> Unknown mode \`${mode}\`.\n` +
        `Supported modes: \`base64\`, \`url\`, \`html\`, \`binary\`, \`morse\``
      );
    }

    let output = '';
    try {
      output = executeConversion(action, mode, text);
      if (output === null) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to process with mode \`${mode}\`.`);
      }
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to ${action} text: ${err.message}`);
    }

    // Safety truncation for Discord display
    const maxLen = 1500;
    const isTruncated = output.length > maxLen;
    const safeOutput = isTruncated
      ? output.slice(0, maxLen) + `\n... [truncated ${output.length - maxLen} chars]`
      : output;

    const actionTitle = action === 'encode' ? 'Encoder' : 'Decoder';
    const card = createV2Card({
      color: 0x00FF88,
      title: `<a:tungsten_encode:1569329355111538820> Tungsten • Text ${actionTitle} (${mode})`,
      description:
        `• **Action:** \`${action.toUpperCase()}\`\n` +
        `• **Format:** \`${mode}\`\n` +
        `• **Input Length:** \`${text.length}\` characters\n` +
        `• **Output Length:** \`${output.length}\` characters\n\n` +
        `**Result:**\n` +
        `\`\`\`\n${safeOutput || '[Empty Output]'}\n\`\`\``,
      footerText: `Requested by ${message.author?.username || 'User'}`
    });

    return message.reply({ embeds: [card] });
  },

  // Export helpers for unit testing
  executeConversion,
  encodeMorse,
  decodeMorse,
  encodeBinary,
  decodeBinary,
  encodeHtml,
  decodeHtml
};
