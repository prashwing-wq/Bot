/**
 * Server Embed & Container Accent Color Command (Node.js)
 * Allows server administrators to customize their server's Components V2 accent color.
 * Defaults to pure stealth black (0x000001). Custom hex overrides the accent across all bot embeds/containers.
 */
const { PermissionFlagsBits } = require('discord.js');
const { getGuildAccent, setGuildAccent } = require('../../utils/serverDb');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'embedcolor',
  aliases: ['accent', 'setaccent', 'embedaccent', 'color', 'setcolor'],
  category: 'utility',
  description: 'View or customize the server UI accent color (default: pure stealth black).',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[hex_code | reset | black]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const currentAccent = getGuildAccent(message.guild.id);
    const hexInput = args[0]?.toLowerCase();

    // 1. Show current accent status
    if (!hexInput || hexInput === 'status' || hexInput === 'show') {
      const isBlack = currentAccent === 0x000001 || currentAccent === 0;
      const hexStr = '#' + currentAccent.toString(16).padStart(6, '0').toUpperCase();

      const card = createV2Card({
        color: currentAccent,
        title: '<a:tungsten_star:1567242331785138238>  UI Accent Color Configuration',
        description:
          `> Server: **${message.guild.name}**\n\n` +
          `• **Current Accent:** \`${hexStr}\` ${isBlack ? '*(Default Pure Stealth Black)*' : '*(Custom Accent)*'}\n` +
          `• **Components V2 Containers:** Using active accent\n\n` +
          `**Customization Commands:**\n` +
          `• \`${prefix}accent <#HEX>\` — Set custom accent (e.g. \`${prefix}accent #00FF88\` or \`${prefix}accent #5865F2\`)\n` +
          `• \`${prefix}accent reset\` — Reset to default stealth pure black (\`#000000\`)`,
        footerText: `Configured for ${message.guild.name}`
      });
      return message.reply({ embeds: [card] });
    }

    // Permissions: ManageGuild or Bot Owner
    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: You need **Manage Server** permissions to configure embed accent colors.');
    }

    // 2. Reset to default pure stealth black
    if (['reset', 'black', 'default', 'none', 'clear'].includes(hexInput)) {
      setGuildAccent(message.guild.id, 'reset');
      const card = createV2Card({
        color: 0x000001,
        title: '<a:tungsten_success:1567242523468890274>  Accent Color Reset',
        description:
          `> Successfully reset UI accent color to **Pure Stealth Black** (\`#000000\`).\n\n` +
          `• All future bot responses, containers, and cards will render in stealth black.\n` +
          `• Set a custom hex anytime with \`${prefix}accent <hex>\`.`,
        footerText: `Reset by ${message.author.username}`
      });
      return message.reply({ embeds: [card] });
    }

    // 3. Set custom hex color
    try {
      const parsedColor = setGuildAccent(message.guild.id, hexInput);
      const hexStr = '#' + parsedColor.toString(16).padStart(6, '0').toUpperCase();

      const card = createV2Card({
        color: parsedColor,
        title: '<a:tungsten_success:1567242523468890274>  Custom Accent Color Deployed',
        description:
          `> Successfully set server accent color to **${hexStr}**.\n\n` +
          `• **Hex Value:** \`${hexStr}\`\n` +
          `• **Integer:** \`${parsedColor}\`\n` +
          `• All embeds and Components V2 containers in this server will now feature this accent.\n\n` +
          `-# Revert to pure black anytime with \`${prefix}accent reset\`.`,
        footerText: `Updated by ${message.author.username}`
      });
      return message.reply({ embeds: [card] });
    } catch (err) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> ${err.message}`);
    }
  }
};
