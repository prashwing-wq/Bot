/**
 * Webhook Management Command (Node.js)
 * Create, manage, and dispatch messages through server webhooks.
 */
const { PermissionsBitField, PermissionFlagsBits, WebhookClient } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'webhook',
  aliases: ['webhooks', 'wh'],
  category: 'utility',
  description: 'Create, manage, and dispatch messages through server webhooks.',
  permissions: ['ManageWebhooks'],
  botPermissions: ['ManageWebhooks'],
  usage: '<list [#channel] | create <#channel> <name> | delete <webhook_id> | send <webhook_id> <message>>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    // Check user permissions
    if (!hasPerm(message.member, PermissionFlagsBits.ManageWebhooks)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the **Manage Webhooks** permission to manage webhooks.'
          })
        ]
      });
    }

    // Check bot permissions
    const botMember = message.guild.members.me;
    if (botMember && !botMember.permissions.has(PermissionFlagsBits.ManageWebhooks)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Bot Missing Permissions',
            description: '<a:tungsten_close:1567234632905138206> I require the **Manage Webhooks** permission to manage webhooks.'
          })
        ]
      });
    }

    const sub = args[0]?.toLowerCase();

    // Subcommand: list [#channel]
    if (sub === 'list') {
      const targetChannel = message.mentions?.channels?.first() ||
        (args[1] ? message.guild.channels.cache.get(args[1]) : null);

      try {
        let webhooksCollection;
        if (targetChannel) {
          if (typeof targetChannel.fetchWebhooks !== 'function') {
            return message.reply({
              embeds: [
                createEmbed({
                  color: client.config.COLORS.DANGER,
                  title: 'Invalid Channel Type',
                  description: `<a:tungsten_close:1567234632905138206> Channel ${targetChannel} does not support webhooks.`
                })
              ]
            });
          }
          webhooksCollection = await targetChannel.fetchWebhooks();
        } else {
          webhooksCollection = await message.guild.fetchWebhooks();
        }

        const webhooks = webhooksCollection ? [...webhooksCollection.values()] : [];

        if (webhooks.length === 0) {
          return message.reply({
            embeds: [
              createEmbed({
                color: client.config.COLORS.INFO,
                title: '🔗 Server Webhooks',
                description: targetChannel
                  ? `No webhooks found in ${targetChannel}.`
                  : 'No webhooks found in this server.'
              })
            ]
          });
        }

        const lines = webhooks.slice(0, 20).map((wh, idx) => {
          const creator = wh.owner ? `<@${wh.owner.id}>` : 'Unknown';
          return `**${idx + 1}.** **${wh.name}** in <#${wh.channelId}> — ID: \`${wh.id}\` (Creator: ${creator})`;
        });

        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.PRIMARY,
              title: `🔗 Server Webhooks (${webhooks.length})`,
              description:
                `> Active webhooks registered${targetChannel ? ` in ${targetChannel}` : ' server-wide'}.\n\n` +
                lines.join('\n') +
                (webhooks.length > 20 ? `\n\n*-# Showing first 20 webhooks.*` : '')
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to Fetch Webhooks',
              description: `<a:tungsten_close:1567234632905138206> Could not retrieve webhooks: ${err.message}`
            })
          ]
        });
      }
    }

    // Subcommand: create <#channel> <name>
    if (sub === 'create') {
      const targetChannel = message.mentions?.channels?.first() ||
        (args[1] ? message.guild.channels.cache.get(args[1]) : null);

      if (!targetChannel) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Channel',
              description: `Usage: \`${prefix}webhook create <#channel> <name>\`\nExample: \`${prefix}webhook create #announcements Updates Webhook\``
            })
          ]
        });
      }

      if (typeof targetChannel.createWebhook !== 'function') {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Unsupported Channel',
              description: `<a:tungsten_close:1567234632905138206> Webhooks cannot be created in ${targetChannel}. Please select a text or announcement channel.`
            })
          ]
        });
      }

      const name = args.slice(2).join(' ').trim();
      if (!name) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Webhook Name',
              description: `Usage: \`${prefix}webhook create <#channel> <name>\``
            })
          ]
        });
      }

      if (name.length > 80) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Name Too Long',
              description: '<a:tungsten_close:1567234632905138206> Webhook name cannot exceed 80 characters.'
            })
          ]
        });
      }

      try {
        const wh = await targetChannel.createWebhook({
          name: name,
          reason: `[Webhook] Created by ${message.author.tag}`
        });

        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '🔗 Webhook Created',
              description:
                `> Successfully created webhook in ${targetChannel}!\n\n` +
                `• **Name:** **${wh.name}**\n` +
                `• **ID:** \`${wh.id}\`\n` +
                `• **Channel:** <#${wh.channelId}>\n` +
                `• **URL:** ||${wh.url}||\n\n` +
                `-# Keep the webhook URL secure to prevent unauthorized message dispatch.`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to Create Webhook',
              description: `<a:tungsten_close:1567234632905138206> Could not create webhook: ${err.message}`
            })
          ]
        });
      }
    }

    // Subcommand: delete <webhook_id>
    if (sub === 'delete') {
      const webhookId = args[1]?.trim();
      if (!webhookId) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Webhook ID',
              description: `Usage: \`${prefix}webhook delete <webhook_id>\``
            })
          ]
        });
      }

      try {
        const webhooks = await message.guild.fetchWebhooks().catch(() => new Map());
        let targetWh = webhooks.get(webhookId);

        if (!targetWh && typeof client.fetchWebhook === 'function') {
          try {
            const fetched = await client.fetchWebhook(webhookId);
            if (fetched && fetched.guildId === message.guild.id) {
              targetWh = fetched;
            }
          } catch (_) {}
        }

        if (!targetWh) {
          return message.reply({
            embeds: [
              createEmbed({
                color: client.config.COLORS.DANGER,
                title: 'Webhook Not Found',
                description: `<a:tungsten_close:1567234632905138206> No webhook found with ID \`${webhookId}\` in this server.`
              })
            ]
          });
        }

        const whName = targetWh.name;
        await targetWh.delete(`[Webhook] Deleted by ${message.author.tag}`);

        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_trash:1567242891276062872> Webhook Deleted',
              description:
                `> Successfully deleted webhook **${whName}** (\`${webhookId}\`).\n\n` +
                `• **Moderator:** <@${message.author.id}>`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to Delete Webhook',
              description: `<a:tungsten_close:1567234632905138206> Could not delete webhook: ${err.message}`
            })
          ]
        });
      }
    }

    // Subcommand: send <webhook_id> <message>
    if (sub === 'send') {
      const webhookId = args[1]?.trim();
      const content = args.slice(2).join(' ').trim();

      if (!webhookId || !content) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Missing Parameters',
              description: `Usage: \`${prefix}webhook send <webhook_id|webhook_url> <message>\``
            })
          ]
        });
      }

      // Check if user passed direct webhook URL
      if (webhookId.startsWith('http://') || webhookId.startsWith('https://')) {
        try {
          const clientWh = new WebhookClient({ url: webhookId });
          await clientWh.send({
            content,
            allowedMentions: { parse: ['users'] }
          });
          return message.reply({
            embeds: [
              createEmbed({
                color: client.config.COLORS.SUCCESS,
                title: '<a:tungsten_success:1567242523468890274> Message Dispatched',
                description: `Successfully dispatched message via webhook URL.`
              })
            ]
          });
        } catch (err) {
          return message.reply({
            embeds: [
              createEmbed({
                color: client.config.COLORS.DANGER,
                title: 'Failed to Send Webhook Message',
                description: `<a:tungsten_close:1567234632905138206> Could not dispatch message: ${err.message}`
              })
            ]
          });
        }
      }

      try {
        const webhooks = await message.guild.fetchWebhooks().catch(() => new Map());
        const targetWh = webhooks.get(webhookId);

        if (!targetWh) {
          return message.reply({
            embeds: [
              createEmbed({
                color: client.config.COLORS.DANGER,
                title: 'Webhook Not Found',
                description: `<a:tungsten_close:1567234632905138206> No webhook found with ID \`${webhookId}\` in this server.`
              })
            ]
          });
        }

        if (!targetWh.token) {
          return message.reply({
            embeds: [
              createEmbed({
                color: client.config.COLORS.DANGER,
                title: 'Missing Webhook Token',
                description: `<a:tungsten_close:1567234632905138206> Cannot dispatch message: This webhook token is not accessible by the bot (created by another integration).`
              })
            ]
          });
        }

        await targetWh.send({
          content,
          allowedMentions: { parse: ['users'] }
        });

        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_success:1567242523468890274> Message Dispatched',
              description:
                `> Successfully dispatched message to webhook **${targetWh.name}** (<#${targetWh.channelId}>).\n\n` +
                `• **Message Preview:** ${content.slice(0, 100)}${content.length > 100 ? '...' : ''}`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Failed to Send Webhook Message',
              description: `<a:tungsten_close:1567234632905138206> Could not dispatch message: ${err.message}`
            })
          ]
        });
      }
    }

    // Default: Help Guide
    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.PRIMARY,
          title: '🔗 Webhook Management',
          description:
            `Create, manage, and dispatch messages through server webhooks.\n\n` +
            `• \`${prefix}webhook list [#channel]\` — List webhooks for a channel or server\n` +
            `• \`${prefix}webhook create <#channel> <name>\` — Create a new webhook\n` +
            `• \`${prefix}webhook delete <webhook_id>\` — Delete a webhook by ID\n` +
            `• \`${prefix}webhook send <webhook_id> <message>\` — Dispatch a message via webhook\n\n` +
            `-# Tip: \`send\` also accepts a full webhook URL in place of ID.`
        })
      ]
    });
  }
};
