const { hasPerm } = require('../../utils/tools');
/**
 * Discord Components V2 Command & Diagnostics (Node.js)
 */
const {
  isComponentsV2Enabled,
  setComponentsV2Enabled,
  createV2Card,
  createButtonRow
} = require('../../utils/componentsV2');
const { ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'componentsv2',
  aliases: ['v2', 'cv2'],
  category: 'utility',
  description: 'View or toggle Discord Components V2 layout architecture and live showcase.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[enable | disable | status | demo]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const sub = args[0] ? args[0].toLowerCase() : 'status';

    if (sub === 'enable' || sub === 'on') {
      if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure Components V2.');
      }
      setComponentsV2Enabled(message.guild.id, true);
      return message.reply('<a:tungsten_ui_toggle_on:1569329685110849576> **Discord Components V2** layout engine has been **ENABLED** for this server.');
    }

    if (sub === 'disable' || sub === 'off') {
      if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure Components V2.');
      }
      setComponentsV2Enabled(message.guild.id, false);
      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> **Discord Components V2** layout engine has been **DISABLED** for this server (reverted to classic embeds).');
    }

    if (sub === 'demo' || sub === 'showcase') {
      const card = createV2Card({
        color: 0x00FF88,
        title: '<a:tungsten_bolt:1567233430570405968>  Discord Components V2 Engine',
        description:
          `You are viewing a native **Discord Components V2** layout with modular containers, action rows, and interactive controls.\n\n` +
          `**Architecture Highlights:**\n` +
          `• **Container Architecture:** Type 17 modular UI wrapping with dynamic accent colors\n` +
          `• **Direct Action Rows:** Type 1 rows embedding up to 5 buttons or select menus\n` +
          `• **Universal Adapter:** Automatically transforms embeds into sleek Components V2 cards\n` +
          `• **High-Speed Statement Caching:** Sub-millisecond response latency\n\n` +
          `-# Interactive Components V2 Demo • Engine Active`
      });

      const buttons = createButtonRow([
        { customId: 'v2_demo_pulse', label: 'Live Pulse', style: ButtonStyle.Success, emoji: '<a:tungsten_success:1567242523468890274>' },
        { customId: 'v2_demo_telemetry', label: 'Telemetry', style: ButtonStyle.Primary, emoji: '<a:tungsten_chart:1567234342701367357>' },
        { customId: 'v2_demo_dismiss', label: 'Dismiss', style: ButtonStyle.Secondary, emoji: '<a:tungsten_sweep:1567242656281657414>' }
      ]);

      return message.reply({ embeds: [card], components: [buttons] });
    }

    // Status
    const enabled = isComponentsV2Enabled(message.guild ? message.guild.id : null);
    const card = createV2Card({
      title: '<a:tungsten_bolt:1567233430570405968>  Discord Components V2 Status',
      description:
        `Tungsten features a state-of-the-art **Components V2** modular layout engine powered by Discord's newest UI system.\n\n` +
        `**Current Status for this Server:** ${enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> **Enabled (Active)**' : '<a:tungsten_ui_toggle_off:1569329677187678368> **Disabled (Classic Embeds)**'}\n\n` +
        `**Available Commands:**\n` +
        `• \`${prefix}componentsv2 enable\` — Enable Components V2 layouts\n` +
        `• \`${prefix}componentsv2 disable\` — Switch back to classic embeds\n` +
        `• \`${prefix}componentsv2 demo\` — Interactive Components V2 showcase\n` +
        `• \`${prefix}componentsv2 status\` — View UI diagnostics`
    });

    return message.reply({ embeds: [card] });
  }
};
