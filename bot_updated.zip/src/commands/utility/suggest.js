/**
 * Tungsten Suggestion Submission Command (Node.js)
 * Enables server members to submit ideas with persistent upvote/downvote voting.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SlashCommandBuilder
} = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { isModuleEnabled } = require('../../utils/modulesHelper');

function buildSuggestionEmbed(suggId, author, text, upvotes = 0, downvotes = 0, status = 'PENDING', client = null) {
  const avatar = (author && typeof author.displayAvatarURL === 'function')
    ? author.displayAvatarURL({ dynamic: true })
    : null;

  const validAvatar = (typeof avatar === 'string' && avatar.startsWith('http')) ? avatar : null;

  const statusLabel = status === 'APPROVED' ? '<a:tungsten_success:1567242523468890274> Approved' : (status === 'DENIED' ? '<a:tungsten_close:1567234632905138206> Denied' : '<a:tungsten_loading:1567241050567876698> Pending Staff Review');
  const color = status === 'APPROVED'
    ? (client?.config?.COLORS?.SUCCESS || 0x57F287)
    : (status === 'DENIED'
      ? (client?.config?.COLORS?.DANGER || 0xED4245)
      : (client?.config?.COLORS?.PRIMARY || 0x5865F2));

  const embed = createEmbed({
    color,
    title: `💡 Suggestion #${suggId}`,
    description: text,
    timestamp: true,
    footer: { text: `Submitted by ${author?.username || 'Unknown'} (ID: ${author?.id || '0'})` }
  });

  if (validAvatar) {
    embed.setAuthor({ name: author?.username || 'Member Suggestion', iconURL: validAvatar });
  } else {
    embed.setAuthor({ name: author?.username || 'Member Suggestion' });
  }

  embed.addFields(
    { name: 'Status', value: `\`${statusLabel}\``, inline: true },
    { name: 'Votes', value: `👍 **${upvotes}**  •  👎 **${downvotes}**`, inline: true }
  );

  return embed;
}

function buildSuggestionButtons(suggId, upvotes = 0, downvotes = 0, disabled = false) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`sugg:up:${suggId}`)
      .setLabel(`${upvotes}`)
      .setEmoji('<a:tungsten_tick:1567242779908636802>')
      .setStyle(ButtonStyle.Success)
      .setDisabled(disabled),
    new ButtonBuilder()
      .setCustomId(`sugg:down:${suggId}`)
      .setLabel(`${downvotes}`)
      .setEmoji('<a:tungsten_close:1567234632905138206>')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(disabled)
  );
  return row;
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'suggest',
  description: 'Submit a community suggestion for voting and staff review.',
  category: 'utility',
  usage: 'suggest <your idea / feedback>',
  aliases: ['suggestion'],
  cooldown: 5,
  buildSuggestionEmbed,
  buildSuggestionButtons,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!isModuleEnabled(message.guild.id, 'suggestions')) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Module Disabled',
            description: 'The **Suggestions** module is currently disabled in this server.'
          })
        ]
      });
    }

    const text = args.join(' ').trim();
    if (!text || text.length < 5) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Invalid Suggestion',
            description: `**Usage:** \`${prefix}suggest <idea / feedback>\`\nPlease provide at least 5 characters.`
          })
        ]
      });
    }

    if (text.length > 1800) {
      return message.reply('Suggestion text is too long (maximum 1800 characters).');
    }

    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'suggestion_channel'").get();
    let targetChannel = message.channel;

    if (row && row.value) {
      const configured = message.guild.channels.cache.get(row.value) ||
        await message.guild.channels.fetch(row.value).catch(() => null);
      if (configured && configured.isTextBased()) {
        targetChannel = configured;
      }
    }

    const now = Math.floor(Date.now() / 1000);
    const insertRes = sdb.prepare(`
      INSERT INTO suggestions (guild_id, channel_id, message_id, author_id, author_tag, content, status, upvotes, downvotes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, 'PENDING', 0, 0, ?, ?)
    `).run(
      message.guild.id,
      targetChannel.id,
      '0',
      message.author.id,
      message.author.username,
      text,
      now,
      now
    );

    const suggId = insertRes.lastInsertRowid;
    const embed = buildSuggestionEmbed(suggId, message.author, text, 0, 0, 'PENDING', client);
    const buttons = buildSuggestionButtons(suggId, 0, 0, false);

    try {
      const sentMsg = await targetChannel.send({ embeds: [embed], components: [buttons] });
      sdb.prepare('UPDATE suggestions SET message_id = ? WHERE id = ?').run(sentMsg.id, suggId);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_success:1567242523468890274> Suggestion Submitted',
            description: `Your suggestion has been posted to ${targetChannel}! [Click here to view it](${sentMsg.url})`
          })
        ]
      });
    } catch (err) {
      console.error('[Suggest Error]', err);
      return message.reply('Failed to deliver suggestion to the designated channel. Please ensure the bot has permission to send messages in that channel.');
    }
  }
};
