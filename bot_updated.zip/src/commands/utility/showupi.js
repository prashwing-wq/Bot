/**
 * Show UPI Command (Node.js)
 * Displays the configured server UPI payment details and dynamic QR code.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'showupi',
  aliases: ['upi', 'donate', 'paymentqr'],
  category: 'utility',
  description: 'Displays the server UPI payment QR code and ID.',
  usage: '',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sdb = getServerDb(message.guild.id);
    const idRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'server_upi_id'").get();
    const nameRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'server_upi_name'").get();

    if (!idRow || !idRow.value) {
      return message.reply(`<a:tungsten_info:1567240890748248084> Server UPI has not been configured yet. Administrators can set it up with \`${prefix}setupi <upi_id> [name]\`.`);
    }

    const upiId = idRow.value;
    const payeeName = nameRow?.value || message.guild.name;

    const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&cu=INR`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUri)}`;

    const embed = createEmbed({
      color: 0x5865F2,
      title: `💳  Server UPI Payment • ${message.guild.name}`,
      description:
        `> Scan the QR code below using any UPI app (GPay, PhonePe, Paytm, BHIM) to send donations or payments.\n\n` +
        `• **UPI ID:** \`${upiId}\`\n` +
        `• **Payee Name:** **${payeeName}**\n\n` +
        `[Direct QR Link](${qrUrl})`
    });

    if (typeof qrUrl === 'string' && qrUrl.startsWith('http')) {
      embed.setImage(qrUrl);
    }

    return message.reply({ embeds: [embed] });
  }
};
