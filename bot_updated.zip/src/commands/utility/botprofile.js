/**
 * BotProfile Command (Node.js)
 * Customizes Tungsten's per-server identity (nickname, server status, bio).
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'botprofile',
  aliases: ['bp', 'serverprofile'],
  category: 'utility',
  description: "Customize Tungsten's per-server profile (nickname, bio, persona).",
  permissions: ['ManageGuild'],
  botPermissions: ['ManageNicknames', 'SendMessages', 'EmbedLinks'],
  usage: '[nick <new_name> | bio <new_bio> | reset | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const isAuthorized = hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) ||
                         message.author.id === message.guild.ownerId ||
                         (client?.config?.OWNER_IDS || []).includes(message.author.id);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You require **Manage Server** permission to customize the bot profile.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase();

    // 1. Set Bot Server Nickname
    if (sub === 'nick' || sub === 'nickname' || sub === 'name') {
      const newNick = args.slice(1).join(' ').trim();
      if (!newNick) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}botprofile nick <new_nickname>\``);
      }
      if (newNick.length > 32) {
        return message.reply('<a:tungsten_close:1567234632905138206> Nickname must be 32 characters or fewer.');
      }

      try {
        const me = message.guild.members.me;
        await me.setNickname(newNick, `Bot profile updated by ${message.author.tag}`);
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('bot_custom_nick', ?)").run(newNick);

        return message.reply({
          embeds: [
            createEmbed({
              color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
              title: '🤖 Bot Nickname Updated',
              description: `Tungsten's server nickname changed to: **${newNick}**.`
            })
          ]
        });
      } catch (e) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to update bot nickname: ${e.message}`);
      }
    }

    // 2. Set Bot Server Bio
    if (sub === 'bio' || sub === 'about' || sub === 'status') {
      const newBio = args.slice(1).join(' ').trim();
      if (!newBio) {
        // Show current profile
        const bioRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'bot_custom_bio'").get();
        const me = message.guild.members.me;
        const currentBio = bioRow ? bioRow.value : 'No custom server bio configured.';

        const card = createV2Card({
          color: 0x5865F2,
          title: `🤖  Bot Server Profile • ${message.guild.name}`,
          description:
            `> Per-server custom appearance and persona configuration.\n\n` +
            `• **Server Nickname:** \`${me.displayName}\`\n` +
            `• **Server Persona Bio:**\n${currentBio}\n\n` +
            `**Management Commands:**\n` +
            `• \`${prefix}botprofile nick <name>\` — Change server nickname\n` +
            `• \`${prefix}botprofile bio <text>\` — Set custom server bio\n` +
            `• \`${prefix}botprofile reset\` — Reset to default appearance`,
          footer: { text: `Requested by ${message.author.username}` }
        });
        return message.reply({ embeds: [card] });
      }

      if (newBio.length > 256) {
        return message.reply('<a:tungsten_close:1567234632905138206> Bio must be 256 characters or fewer.');
      }

      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('bot_custom_bio', ?)").run(newBio);
      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
            title: '🤖 Server Bio Updated',
            description: `Tungsten's server persona bio updated:\n> "${newBio}"`
          })
        ]
      });
    }

    // 3. Reset Bot Profile
    if (sub === 'reset' || sub === 'clear') {
      try {
        const me = message.guild.members.me;
        await me.setNickname(null, `Bot profile reset by ${message.author.tag}`).catch(() => null);
        sdb.prepare("DELETE FROM server_settings WHERE key IN ('bot_custom_nick', 'bot_custom_bio')").run();

        return message.reply({
          embeds: [
            createEmbed({
              color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
              title: '🤖 Bot Profile Reset',
              description: "Successfully reset Tungsten's server profile and nickname to default."
            })
          ]
        });
      } catch (e) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to reset profile: ${e.message}`);
      }
    }

    // Default overview
    const bioRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'bot_custom_bio'").get();
    const me = message.guild.members.me;
    const currentBio = bioRow ? bioRow.value : 'No custom server bio configured.';

    const card = createV2Card({
      color: 0x5865F2,
      title: `🤖  Bot Server Profile • ${message.guild.name}`,
      description:
        `> Per-server custom appearance and persona configuration.\n\n` +
        `• **Server Nickname:** \`${me.displayName}\`\n` +
        `• **Server Persona Bio:**\n${currentBio}\n\n` +
        `**Management Commands:**\n` +
        `• \`${prefix}botprofile nick <name>\` — Change server nickname\n` +
        `• \`${prefix}botprofile bio <text>\` — Set custom server bio\n` +
        `• \`${prefix}botprofile reset\` — Reset to default appearance`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [card] });
  }
};
