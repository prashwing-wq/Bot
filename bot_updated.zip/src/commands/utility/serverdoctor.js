/**
 * Server Doctor Health & Security Diagnostics Command (Node.js)
 * Executes deep multi-vector audits across bot role hierarchy, bot permissions,
 * dangerous @everyone privileges, mod log configuration, and server defense baselines.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

function renderProgressBar(score, totalBlocks = 10) {
  const filled = Math.max(0, Math.min(totalBlocks, Math.round((score / 100) * totalBlocks)));
  const empty = totalBlocks - filled;
  return '▰'.repeat(filled) + '▱'.repeat(empty);
}

/**
 * Runs deep server diagnostic health and security scan
 * @param {import('discord.js').Guild} guild
 * @param {import('discord.js').Client} client
 * @param {string} prefix
 * @returns {Promise<{ card: any, buttons: ActionRowBuilder, score: number, grade: string }>}
 */
async function runServerDoctorScan(guild, client, prefix = '!') {
  const me = guild.members.me || (await guild.members.fetchMe().catch(() => null));
  const sdb = getServerDb(guild.id);

  let score = 100;
  const recommendations = [];

  // 1. Bot Role Hierarchy Audit
  const myHighestRole = me?.roles?.highest;
  const myPos = myHighestRole ? myHighestRole.position : 0;
  const higherRoles = guild.roles.cache.filter(
    r => r.id !== guild.id && !r.managed && r.position >= myPos
  );

  let hierarchyStatus = '';
  if (higherRoles.size > 0) {
    score -= 20;
    const sample = higherRoles.map(r => `\`@${r.name}\``).slice(0, 3).join(', ');
    const extra = higherRoles.size > 3 ? ` (+${higherRoles.size - 3} more)` : '';
    hierarchyStatus = `<a:tungsten_ui_toggle_off:1569329677187678368> **Hierarchy Deficiency (-20 pts):** Tungsten's highest role (\`${myHighestRole?.name || 'Unknown'}\`) is positioned below **${higherRoles.size}** unmanaged role(s): ${sample}${extra}.`;
    recommendations.push(`Move Tungsten's role to the top of Server Settings → Roles so it can moderate members and manage roles higher in the stack.`);
  } else {
    hierarchyStatus = `<a:tungsten_ui_toggle_on:1569329685110849576> **Optimal Role Hierarchy:** Tungsten holds top position above all manageable roles.`;
  }

  // 2. Critical Bot Permissions Audit
  const criticalPerms = [
    { flag: PermissionsBitField.Flags.KickMembers, name: 'Kick Members' },
    { flag: PermissionsBitField.Flags.BanMembers, name: 'Ban Members' },
    { flag: PermissionsBitField.Flags.ManageChannels, name: 'Manage Channels' },
    { flag: PermissionsBitField.Flags.ViewAuditLog, name: 'View Audit Log' },
    { flag: PermissionsBitField.Flags.ManageMessages, name: 'Manage Messages' }
  ];

  const missingBotPerms = criticalPerms.filter(p => !me?.permissions?.has(p.flag));
  let botPermsStatus = '';
  if (missingBotPerms.length > 0) {
    const penalty = missingBotPerms.length * 8;
    score -= penalty;
    const missingNames = missingBotPerms.map(p => `\`${p.name}\``).join(', ');
    botPermsStatus = `<a:tungsten_ui_toggle_off:1569329677187678368> **Missing Bot Permissions (-${penalty} pts):** Tungsten lacks ${missingBotPerms.length} critical permission(s): ${missingNames}.`;
    recommendations.push(`Grant ${missingNames} to Tungsten's role to enable full moderation and threat mitigation.`);
  } else {
    botPermsStatus = `<a:tungsten_ui_toggle_on:1569329685110849576> **Bot Permissions:** All 5 critical defense permissions (Kick, Ban, Manage Channels, View Audit Log, Manage Messages) are granted.`;
  }

  // 3. Dangerous @everyone Permissions Scan
  const dangerousEveryonePerms = [
    { flag: PermissionsBitField.Flags.Administrator, name: 'Administrator' },
    { flag: PermissionsBitField.Flags.MentionEveryone, name: 'Mention @everyone / @here' },
    { flag: PermissionsBitField.Flags.ManageRoles, name: 'Manage Roles' },
    { flag: PermissionsBitField.Flags.ManageGuild, name: 'Manage Server' },
    { flag: PermissionsBitField.Flags.ManageChannels, name: 'Manage Channels' },
    { flag: PermissionsBitField.Flags.BanMembers, name: 'Ban Members' },
    { flag: PermissionsBitField.Flags.KickMembers, name: 'Kick Members' }
  ];

  const everyoneRole = guild.roles.everyone;
  const rogueEveryone = dangerousEveryonePerms.filter(p => everyoneRole?.permissions?.has(p.flag));
  let everyoneStatus = '';
  if (rogueEveryone.length > 0) {
    const penalty = rogueEveryone.length * 10;
    score -= penalty;
    const rogueNames = rogueEveryone.map(p => `\`${p.name}\``).join(', ');
    everyoneStatus = `<a:tungsten_ui_toggle_off:1569329677187678368> **Exposed @everyone Privileges (-${penalty} pts):** Default @everyone role holds ${rogueEveryone.length} dangerous permission(s): ${rogueNames}.`;
    recommendations.push(`Revoke ${rogueNames} from @everyone in Server Settings → Roles to prevent rogue permissions abuse.`);
  } else {
    everyoneStatus = `<a:tungsten_ui_toggle_on:1569329685110849576> **@everyone Posture:** No dangerous administrative or management permissions are assigned to default members.`;
  }

  // 4. Mod Log / Alert Channel Configuration
  let modLogStatus = '';
  let logRow = null;
  try {
    logRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'log_mod' OR key = 'audit_log_channel'").get();
  } catch (_) {}

  if (logRow && logRow.value) {
    const channel = guild.channels.cache.get(logRow.value);
    if (channel) {
      const canSend = me ? channel.permissionsFor(me)?.has(PermissionsBitField.Flags.SendMessages) : false;
      if (canSend) {
        modLogStatus = `<a:tungsten_ui_toggle_on:1569329685110849576> **Incident Logging:** Active in <#${channel.id}> (\`#${channel.name}\`).`;
      } else {
        score -= 10;
        modLogStatus = `<a:tungsten_ui_toggle_off:1569329677187678368> **Channel Inaccessible (-10 pts):** Log channel <#${channel.id}> is configured, but Tungsten lacks \`Send Messages\` permission there.`;
        recommendations.push(`Grant Tungsten \`Send Messages\` and \`Embed Links\` in <#${channel.id}>.`);
      }
    } else {
      score -= 12;
      modLogStatus = `<a:tungsten_ui_toggle_off:1569329677187678368> **Invalid Log Channel (-12 pts):** Channel ID \`${logRow.value}\` was configured but no longer exists.`;
      recommendations.push(`Reconfigure your incident log channel using \`${prefix}logs mod <#channel>\`.`);
    }
  } else {
    score -= 15;
    modLogStatus = `<a:tungsten_ui_toggle_off:1569329677187678368> **Mod Log Unconfigured (-15 pts):** No dedicated mod log or audit alert channel is configured.`;
    recommendations.push(`Set up an incident channel using \`${prefix}logs mod <#channel>\` to track moderation cases and security incidents.`);
  }

  // 5. Server Security Baseline (Verification & 2FA)
  let baselineStatus = [];
  if (guild.verificationLevel === 0) {
    score -= 5;
    baselineStatus.push('<a:tungsten_ui_toggle_off:1569329677187678368> **Verification Level (-5 pts):** Set to `None` (unverified accounts can join and chat immediately).');
    recommendations.push(`Raise server verification level to Low or Medium in Server Settings → Safety Setup.`);
  } else {
    baselineStatus.push(`<a:tungsten_ui_toggle_on:1569329685110849576> **Verification:** Level ${guild.verificationLevel} active.`);
  }

  if (guild.mfaLevel === 0) {
    score -= 5;
    baselineStatus.push('<a:tungsten_ui_toggle_off:1569329677187678368> **2FA Requirement (-5 pts):** Two-factor authentication requirement for staff is disabled.');
    recommendations.push(`Enable 2FA requirement for moderation in Server Settings → Safety Setup.`);
  } else {
    baselineStatus.push(`<a:tungsten_ui_toggle_on:1569329685110849576> **2FA Requirement:** Active for administrative actions.`);
  }

  // Clamp Score
  score = Math.max(0, Math.min(100, score));

  // Determine Grade & Color
  let grade = 'F (CRITICAL)';
  let gradeColor = 0xED4245; // Red

  if (score >= 95) {
    grade = 'A+ (Pristine Health)';
    gradeColor = 0x2ECC71;
  } else if (score >= 85) {
    grade = 'A (Hardened)';
    gradeColor = 0x2ECC71;
  } else if (score >= 75) {
    grade = 'B (Moderate Posture)';
    gradeColor = 0x3498DB;
  } else if (score >= 60) {
    grade = 'C (Vulnerable)';
    gradeColor = 0xF1C40F;
  } else if (score >= 40) {
    grade = 'D (High Risk)';
    gradeColor = 0xE67E22;
  }

  const progressBar = renderProgressBar(score, 12);

  const formattedRecs = recommendations.length > 0
    ? recommendations.map((r, i) => `\`${i + 1}.\` ${r}`).join('\n')
    : '<a:tungsten_sparkle:1567242264311369839> *Server configuration is in pristine health! All security sentinels, role postures, and log channels meet enterprise defense standards.*';

  const card = createV2Card({
    color: gradeColor,
    title: `<a:tungsten_serverdoctor:1569329568471457898> Server Doctor • Health & Security Diagnostic`,
    description:
      `> Deep diagnostic scan for **${guild.name}**\n\n` +
      `**Health Score:** \`${score} / 100\` • **Grade:** \`${grade}\`\n` +
      `\`[${progressBar}]\` **${score}%**\n\n` +
      `### <a:tungsten_crown:1567238355463176334> Role Hierarchy\n` +
      `${hierarchyStatus}\n\n` +
      `### <a:tungsten_key:1567240907684581492> Bot Defense Permissions\n` +
      `${botPermsStatus}\n\n` +
      `### <a:tungsten_shield:1567242104923627574> @everyone Role Posture\n` +
      `${everyoneStatus}\n\n` +
      `### <a:tungsten_satellite:1567241994928005137> Mod Log & Alert Routing\n` +
      `${modLogStatus}\n\n` +
      `### <a:tungsten_gear:1567239932970406012> Server Safety Baseline\n` +
      `${baselineStatus.join('\n')}\n\n` +
      `### <a:tungsten_clipboard:1567234610176204900> Doctor's Actionable Prescriptions\n` +
      formattedRecs,
    footerText: `Tungsten Server Doctor • Diagnostic Engine`
  });

  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('doctor:rescan')
      .setLabel('Re-Scan Server')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('<a:tungsten_serverdoctor:1569329568471457898>'),
    new ButtonBuilder()
      .setCustomId('cmd_dismiss')
      .setLabel('Dismiss')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_trash:1567242891276062872>')
  );

  return { card, buttons, score, grade };
}

module.exports = {
  name: 'serverdoctor',
  aliases: ['doctor', 'serveraudit', 'guilddoctor', 'sdoctor'],
  category: 'utility',
  description: 'Deep diagnostic health scan of guild: audits role hierarchy, bot permissions, @everyone posture, and log configuration',
  usage: '',
  cooldown: 5,
  permissions: ['ManageGuild'],
  botPermissions: ['ViewAuditLog'],

  slash: new SlashCommandBuilder()
    .setName('serverdoctor')
    .setDescription('Deep diagnostic health scan of guild: audits role hierarchy, bot permissions, and log configuration')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  runServerDoctorScan,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to run Server Doctor diagnostics.'
          })
        ]
      });
    }

    const { card, buttons } = await runServerDoctorScan(message.guild, client, prefix);
    return message.reply({ embeds: [card], components: [buttons] });
  },

  async executeSlash(interaction, client) {
    if (!interaction.guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    if (!hasPerm(interaction.member, PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to run Server Doctor diagnostics.',
        ephemeral: true
      });
    }

    await interaction.deferReply();
    const { card, buttons } = await runServerDoctorScan(interaction.guild, client, '/');
    return interaction.editReply({ embeds: [card], components: [buttons] });
  }
};
