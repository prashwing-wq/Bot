/**
 * System Status Command (Node.js)
 * Displays bot operational status, memory, ping, uptime, guild count, and shard telemetry.
 */
const os = require('os');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'status',
  aliases: ['botstatus', 'systemstatus', 'pingstatus'],
  category: 'utility',
  description: 'Bot system status (Uptime, Memory, Ping, Guilds, Users, Shards).',
  usage: '',
  cooldown: 5,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    const mem = process.memoryUsage();
    const rssMB = (mem.rss / 1024 / 1024).toFixed(1);
    const heapUsedMB = (mem.heapUsed / 1024 / 1024).toFixed(1);
    const totalMemGB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);

    const uptimeSec = Math.floor(process.uptime());
    const days = Math.floor(uptimeSec / 86400);
    const hours = Math.floor((uptimeSec % 86400) / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const seconds = uptimeSec % 60;
    const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    const totalGuilds = client.guilds?.cache ? client.guilds.cache.size : 0;
    let totalUsers = 0;
    if (client.guilds?.cache) {
      for (const g of client.guilds.cache.values()) {
        totalUsers += (g.memberCount || 0);
      }
    }

    const shardCount = client.shard?.count || 1;
    const shardId = client.shard?.ids ? client.shard.ids[0] : 0;
    const pingMs = Math.round(client.ws?.ping ?? 0);

    const embed = createEmbed({
      color: 0x57F287,
      title: '⚡  Tungsten System & Runtime Status',
      fields: [
        { name: '⏱️ Uptime', value: `\`${uptimeStr}\``, inline: true },
        { name: '📶 WebSocket Ping', value: `\`${pingMs}ms\``, inline: true },
        { name: '💾 Memory (RSS/Heap)', value: `\`${rssMB} MB / ${heapUsedMB} MB\``, inline: true },
        { name: '🏰 Total Guilds', value: `\`${totalGuilds.toLocaleString()}\``, inline: true },
        { name: '👥 Total Users', value: `\`${totalUsers.toLocaleString()}\``, inline: true },
        { name: '🧩 Shards', value: `\`Shard ${shardId + 1} of ${shardCount}\``, inline: true },
        { name: '⚙️ Runtime', value: `\`Node.js ${process.version}\``, inline: true },
        { name: '🖥️ Platform', value: `\`${os.type()} (${os.arch()})\``, inline: true },
        { name: '🛡️ Core Engine', value: '`Discord.js v14 • Node 22`', inline: true }
      ]
    });

    if (client.user && typeof client.user.displayAvatarURL === 'function') {
      const avatar = client.user.displayAvatarURL();
      if (typeof avatar === 'string' && avatar.startsWith('http')) {
        embed.setThumbnail(avatar);
      }
    }

    return message.reply({ embeds: [embed] });
  }
};
