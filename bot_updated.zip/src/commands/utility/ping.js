/**
 * Ping Latency Command (Node.js)
 * Displays bot WebSocket latency, Discord REST round-trip, and database telemetry.
 */
const { SlashCommandBuilder } = require('discord.js');
const { getServerDb, getMasterDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'ping',
  aliases: ['latency', 'speed', 'telemetry', 'benchmark'],
  category: 'utility',
  description: 'Displays the bot WebSocket latency, REST round-trip, and database telemetry.',
  cooldown: 2,

  slash: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Displays bot WebSocket latency, Discord REST round-trip, and database telemetry.'),

  async executeSlash(interaction, client) {
    const dbStart = process.hrtime.bigint();
    try {
      const sdb = interaction.guild ? getServerDb(interaction.guild.id) : getMasterDb();
      sdb.prepare('SELECT 1').get();
    } catch (_) {}
    const dbEnd = process.hrtime.bigint();
    const dbNs = Number(dbEnd - dbStart);
    const dbMs = (dbNs / 1_000_000).toFixed(2);

    const mem = process.memoryUsage();
    const heapUsedMb = (mem.heapUsed / (1024 * 1024)).toFixed(1);

    const restStart = Date.now();
    await interaction.deferReply();
    const restDuration = Math.max(1, Date.now() - restStart);

    const wsPing = client.ws ? Math.round(client.ws.ping) : 0;

    let statusLabel = 'optimal';
    if (wsPing > 300) {
      statusLabel = 'poor';
    } else if (wsPing > 150) {
      statusLabel = 'degraded';
    }

    const card = createV2Card({
      title: 'Latency',
      description:
        `**Network**\n` +
        `WebSocket — \`${wsPing}ms\` · REST — \`${restDuration}ms\`\n\n` +
        `**Engine**\n` +
        `Database — \`${dbMs}ms\` · Heap — \`${heapUsedMb} MB\``
    });

    return interaction.editReply({ embeds: [card] });
  },

  async execute(message, args, client) {
    const dbStart = process.hrtime.bigint();
    try {
      const sdb = message.guild ? getServerDb(message.guild.id) : getMasterDb();
      sdb.prepare('SELECT 1').get();
    } catch (_) {}
    const dbEnd = process.hrtime.bigint();
    const dbNs = Number(dbEnd - dbStart);
    const dbMs = (dbNs / 1_000_000).toFixed(2);

    const mem = process.memoryUsage();
    const heapUsedMb = (mem.heapUsed / (1024 * 1024)).toFixed(1);

    const restStart = Date.now();
    const wsPing = client.ws ? Math.round(client.ws.ping) : 0;

    let statusLabel = 'optimal';
    if (wsPing > 300) {
      statusLabel = 'poor';
    } else if (wsPing > 150) {
      statusLabel = 'degraded';
    }

    const initialRest = Math.max(1, Date.now() - message.createdTimestamp);
    const embed = createV2Card({
      title: 'Latency',
      description:
        `**Network**\n` +
        `WebSocket — \`${wsPing}ms\` · REST — \`${initialRest}ms\`\n\n` +
        `**Engine**\n` +
        `Database — \`${dbMs}ms\` · Heap — \`${heapUsedMb} MB\``
    });

    const sent = await message.reply({ embeds: [embed] });
    if (sent) {
      const restDuration = Math.max(1, Date.now() - restStart);
      const updatedCard = createV2Card({
        title: 'Latency',
        description:
          `**Network**\n` +
          `WebSocket — \`${wsPing}ms\` · REST — \`${restDuration}ms\`\n\n` +
          `**Engine**\n` +
          `Database — \`${dbMs}ms\` · Heap — \`${heapUsedMb} MB\``
      });
      await sent.edit({ embeds: [updatedCard] }).catch(() => null);
    }
  }
};
