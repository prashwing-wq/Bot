/**
 * Reputation System Command (Node.js)
 * Enables members to award positive reputation to peers (1 point / 24h per unique giver).
 * Staff can set/reset reputation. Includes leaderboard and 30-day history.
 */
const { SlashCommandBuilder } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createEmbed, hasPerm } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

function extractUserId(arg) {
  if (!arg) return null;
  const match = String(arg).trim().match(/^<@!?(\d+)>$/) || String(arg).trim().match(/^(\d{15,21})$/);
  return match ? match[1] : null;
}

module.exports = {
  name: 'rep',
  aliases: ['reputation', 'giverep'],
  category: 'utility',
  description: 'Give reputation points to members, view server rep leaderboards, or check rep history',
  usage: '<@user|list|history|set|reset> [options]',
  cooldown: 3,
  permissions: [],
  botPermissions: [],

  async execute(message, args, client, prefix) {
    if (!message.guild) return;
    const gid = message.guild.id;
    const db = getServerDb(gid);
    const sub = (args[0] || '').toLowerCase();

    // 1. Subcommand: LIST / LEADERBOARD
    if (sub === 'list' || sub === 'leaderboard' || sub === 'top') {
      const rows = db.prepare('SELECT user_id, score FROM reputation WHERE guild_id = ? AND score > 0 ORDER BY score DESC LIMIT 10').all(gid);
      if (!rows || rows.length === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0x3498DB,
              title: '<a:tungsten_rep:1569329560917381213> Reputation Leaderboard',
              description: '<a:tungsten_info:1567240890748248084> No reputation points have been earned yet in this server.'
            })
          ]
        });
      }

      const lines = rows.map((r, i) => {
        const medal = i === 0 ? '<a:tungsten_medal_gold:1567241163453366472>' : i === 1 ? '<a:tungsten_medal_silver:1567241205409128649>' : i === 2 ? '<a:tungsten_medal_bronze:1567241129030582403>' : `\`#${i + 1}\``;
        return `${medal} <@${r.user_id}> — **${r.score.toLocaleString()}** rep`;
      });

      const card = createV2Card({
        color: 0xF1C40F,
        title: '<a:tungsten_rep:1569329560917381213> Server Reputation Leaderboard',
        description: `Top members by reputation in **${message.guild.name}**:\n\n${lines.join('\n')}`,
        footerText: 'Tungsten Community • Reputation'
      });
      return message.reply({ embeds: [card] });
    }

    // 2. Subcommand: HISTORY
    if (sub === 'history') {
      const rawTarget = args[1];
      const targetId = message.mentions.users.first()?.id || extractUserId(rawTarget) || message.author.id;
      const thirtyDaysAgo = Math.floor(Date.now() / 1000) - (30 * 86400);

      const rows = db.prepare(
        'SELECT giver_id, given_at FROM rep_given WHERE guild_id = ? AND receiver_id = ? AND given_at >= ? ORDER BY given_at DESC LIMIT 10'
      ).all(gid, targetId, thirtyDaysAgo);

      if (!rows || rows.length === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0x3498DB,
              title: '<a:tungsten_rep:1569329560917381213> Reputation History',
              description: `<a:tungsten_info:1567240890748248084> <@${targetId}> has not received any reputation points in the last 30 days.`
            })
          ]
        });
      }

      const lines = rows.map(r => `• From <@${r.giver_id}> on <t:${r.given_at}:d> (<t:${r.given_at}:R>)`);
      const card = createV2Card({
        color: 0x5865F2,
        title: `<a:tungsten_rep:1569329560917381213> Reputation History • <@${targetId}>`,
        description: `Recent reputation received in the last 30 days:\n\n${lines.join('\n')}`,
        footerText: 'Tungsten Community • Reputation History'
      });
      return message.reply({ embeds: [card] });
    }

    // 3. Subcommand: SET (Staff)
    if (sub === 'set') {
      if (!hasPerm(message.member, 'ManageGuild')) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              title: 'Permission Denied',
              description: '<a:tungsten_close:1567234632905138206> You need the **Manage Server** permission to set reputation points.'
            })
          ]
        });
      }

      const targetId = message.mentions.users.first()?.id || extractUserId(args[1]);
      const newScore = parseInt(args[2], 10);
      if (!targetId || isNaN(newScore) || newScore < 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xF1C40F,
              title: 'Invalid Parameters',
              description: `<a:tungsten_warn:1567246685082746940> **Usage:** \`${prefix}rep set <@user|id> <amount>\``
            })
          ]
        });
      }

      db.prepare(`
        INSERT INTO reputation (guild_id, user_id, score) VALUES (?, ?, ?)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET score = excluded.score
      `).run(gid, targetId, newScore);

      return message.reply({
        embeds: [
          createEmbed({
            color: 0x2ECC71,
            title: 'Reputation Set',
            description: `<a:tungsten_success:1567242523468890274> Set <@${targetId}>'s reputation to **${newScore.toLocaleString()}** points.`
          })
        ]
      });
    }

    // 4. Subcommand: RESET (Staff)
    if (sub === 'reset') {
      if (!hasPerm(message.member, 'ManageGuild')) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              title: 'Permission Denied',
              description: '<a:tungsten_close:1567234632905138206> You need the **Manage Server** permission to reset reputation points.'
            })
          ]
        });
      }

      const targetId = message.mentions.users.first()?.id || extractUserId(args[1]);
      if (!targetId) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xF1C40F,
              title: 'Invalid Target',
              description: `<a:tungsten_warn:1567246685082746940> **Usage:** \`${prefix}rep reset <@user|id>\``
            })
          ]
        });
      }

      db.prepare('DELETE FROM reputation WHERE guild_id = ? AND user_id = ?').run(gid, targetId);
      db.prepare('DELETE FROM rep_given WHERE guild_id = ? AND receiver_id = ?').run(gid, targetId);

      return message.reply({
        embeds: [
          createEmbed({
            color: 0x2ECC71,
            title: 'Reputation Reset',
            description: `<a:tungsten_success:1567242523468890274> Reset reputation and history for <@${targetId}>.`
          })
        ]
      });
    }

    // 5. Default / Main Action: Give Rep to User (!rep @user [reason])
    const targetId = message.mentions.users.first()?.id || extractUserId(args[0]);
    if (!targetId) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xF1C40F,
            title: '<a:tungsten_rep:1569329560917381213> Reputation System',
            description:
              `**Award Rep:** \`${prefix}rep @user [reason]\`\n` +
              `**Leaderboard:** \`${prefix}rep list\`\n` +
              `**History:** \`${prefix}rep history [@user]\`\n` +
              `**Staff Controls:** \`${prefix}rep set <@user> <amount>\` | \`${prefix}rep reset <@user>\``
          })
        ]
      });
    }

    if (targetId === message.author.id) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            title: '<a:tungsten_close:1567234632905138206> Self Reputation Prohibited',
            description: '<a:tungsten_close:1567234632905138206> You cannot give reputation to yourself.'
          })
        ]
      });
    }

    const now = Math.floor(Date.now() / 1000);
    const cooldownSeconds = 24 * 3600; // 24 hours per unique giver/receiver

    const lastRep = db.prepare(
      'SELECT given_at FROM rep_given WHERE guild_id = ? AND giver_id = ? AND receiver_id = ?'
    ).get(gid, message.author.id, targetId);

    if (lastRep && (now - lastRep.given_at) < cooldownSeconds) {
      const remainingSeconds = cooldownSeconds - (now - lastRep.given_at);
      const hours = Math.floor(remainingSeconds / 3600);
      const mins = Math.floor((remainingSeconds % 3600) / 60);
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xF1C40F,
            title: '<a:tungsten_loading:1567241050567876698> Cooldown Active',
            description: `<a:tungsten_loading:1567241050567876698> You can give rep to <@${targetId}> again in **${hours}h ${mins}m**.`
          })
        ]
      });
    }

    // Update or insert rep_given
    db.prepare(`
      INSERT INTO rep_given (guild_id, giver_id, receiver_id, given_at) VALUES (?, ?, ?, ?)
      ON CONFLICT(guild_id, giver_id, receiver_id) DO UPDATE SET given_at = excluded.given_at
    `).run(gid, message.author.id, targetId, now);

    // Increment reputation score
    db.prepare(`
      INSERT INTO reputation (guild_id, user_id, score) VALUES (?, ?, 1)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET score = score + 1
    `).run(gid, targetId);

    const updated = db.prepare('SELECT score FROM reputation WHERE guild_id = ? AND user_id = ?').get(gid, targetId);
    const totalScore = updated?.score || 1;
    const reasonText = args.slice(1).join(' ').trim();

    const desc = reasonText
      ? `<a:tungsten_party:1567241769593339988> <@${message.author.id}> gave **+1 rep** to <@${targetId}> for: *${reasonText}*\n\n<a:tungsten_rep:1569329560917381213> Total Reputation: **${totalScore.toLocaleString()}**`
      : `<a:tungsten_party:1567241769593339988> <@${message.author.id}> gave **+1 rep** to <@${targetId}>!\n\n<a:tungsten_rep:1569329560917381213> Total Reputation: **${totalScore.toLocaleString()}**`;

    const card = createV2Card({
      color: 0x2ECC71,
      title: '<a:tungsten_rep:1569329560917381213> Reputation Awarded!',
      description: desc,
      footerText: 'Tungsten Community • Reputation'
    });

    return message.reply({ embeds: [card] });
  }
};
