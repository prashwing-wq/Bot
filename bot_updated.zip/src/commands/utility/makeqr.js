/**
 * QR Code Generator Command (Node.js)
 * Generates high-contrast QR codes using the qrserver API with defensive URL checking.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'makeqr',
  aliases: ['qr', 'qrcode'],
  category: 'utility',
  description: 'Generates a QR code from text or URL.',
  usage: '<text|url>',
  cooldown: 3,
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!args[0]) {
      return message.reply(`Usage: \`${prefix}makeqr <text|url>\``);
    }

    const input = args.join(' ').trim();
    if (input.length > 500) {
      return message.reply('<a:tungsten_warn:1567246685082746940> Input text too long (maximum 500 characters).');
    }

    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(input)}`;

    const embed = createEmbed({
      color: 0x5865F2,
      title: '📱  QR Code Generated',
      description: `> Successfully encoded **${input.length}** character(s) into QR code.\n\n[Direct QR Image Link](${qrUrl})`
    });

    if (typeof qrUrl === 'string' && qrUrl.startsWith('http')) {
      embed.setImage(qrUrl);
    }

    return message.reply({ embeds: [embed] });
  }
};
