/**
 * Botinfo Command
 * Technical overview of Tungsten Bot
 */
const os = require('node:os');
const { version: djsVersion } = require('discord.js');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'botinfo',
  description: 'Display internal technical and architecture specifications of Tungsten.',
  category: 'utility',
  usage: 'botinfo',
  aliases: ['about', 'info', 'bi'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const uptimeSec = Math.floor(process.uptime());
    const days = Math.floor(uptimeSec / 86400);
    const hours = Math.floor((uptimeSec % 86400) / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const seconds = uptimeSec % 60;
    const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    const memUsage = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);
    const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);

    const embed = createEmbed({
      color: undefined,
      title: 'Tungsten',
      description: 'Tungsten is a heavy-duty, rock-solid server defense and automation framework running on Node.js.',
      fields: [
        { name: 'Developers', value: (client.config?.OWNER_IDS && client.config.OWNER_IDS.length > 0) ? client.config.OWNER_IDS.map(id => `<@${id}>`).join(', ') : 'Discord Application Owner', inline: false },
        { name: 'UI Credits', value: 'Olympus', inline: true },
        { name: 'Development', value: 'Coded entirely with Antigravity', inline: true },
        { name: 'Creator Note', value: "Built by a proud vibecoder who doesn't know a single line of code!", inline: false },
        { name: 'Runtime', value: `Node.js \`${process.version}\`\nDiscord.js \`v${djsVersion}\``, inline: true },
        { name: 'Memory', value: `\`${memUsage} MB\` / \`${totalMem} GB\``, inline: true },
        { name: 'Uptime', value: `\`${uptimeStr}\``, inline: true },
        { name: 'Database', value: 'MongoDB Atlas Cloud (`tungsten_bot`)', inline: true },
        { name: 'Defense Engine', value: 'Instant Anti-Nuke, Anti-Raid, Emergency Lockdown', inline: true },
        { name: 'Servers', value: `\`${client.guilds.cache.size.toLocaleString()}\``, inline: true }
      ],
      footer: `Prefix: ${prefix} • Slash Commands Active`
    });

    return message.reply({ embeds: [embed] });
  }
};
