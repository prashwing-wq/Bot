/**
 * DeleteSticker Command (Node.js)
 * Delete a custom guild sticker by name or ID.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'delsticker',
  aliases: ['deletesticker', 'removesticker'],
  category: 'utility',
  description: 'Delete a custom sticker from this server.',
  permissions: ['ManageGuildExpressions'],
  botPermissions: ['ManageGuildExpressions'],
  usage: '<sticker_name | id>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const isAuthorized = hasPerm(message.member, PermissionsBitField.Flags.ManageGuildExpressions) ||
                         hasPerm(message.member, PermissionsBitField.Flags.ManageEmojisAndStickers) ||
                         hasPerm(message.member, PermissionsBitField.Flags.Administrator);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You require the **Manage Expressions** permission to delete stickers.');
    }

    if (!args[0]) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}delsticker <sticker_name | id>\``);
    }

    const query = args.join(' ').trim().toLowerCase();

    // Check message sticker
    let targetSticker = null;
    if (message.stickers?.size > 0) {
      targetSticker = message.stickers.first();
    } else {
      targetSticker = message.guild.stickers.cache.get(args[0]) ||
        message.guild.stickers.cache.find(s => s.name.toLowerCase() === query);

      if (!targetSticker) {
        try {
          const fetched = await message.guild.stickers.fetch();
          targetSticker = fetched.get(args[0]) || fetched.find(s => s.name.toLowerCase() === query);
        } catch (e) {}
      }
    }

    if (!targetSticker) {
      return message.reply('<a:tungsten_close:1567234632905138206> Sticker not found in this server. Please provide the exact name or sticker ID.');
    }

    if (targetSticker.guildId !== message.guild.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> Cannot delete a sticker belonging to another server or Discord default pack.');
    }

    try {
      const stickerName = targetSticker.name;
      await targetSticker.delete(`Sticker removed by ${message.author.tag}`);

      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
            title: '<a:tungsten_success:1567242523468890274> Sticker Deleted',
            description: `Successfully deleted custom sticker: **${stickerName}**.`
          })
        ]
      });
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to delete sticker: ${e.message}`);
    }
  }
};
