/**
 * UPI Setup Command (Node.js)
 * Configures the server's UPI ID for member donations and payments with live QR generation.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');

module.exports = {
  name: 'setupi',
  aliases: ['setupiid', 'upi-setup'],
  category: 'utility',
  description: 'Configures server UPI ID and generates donation payment QR code.',
  usage: '<upi_id> [payee_name]',
  cooldown: 5,
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Server` permission to configure UPI.'
          })
        ]
      });
    }

    if (!args[0]) {
      return message.reply(`Usage: \`${prefix}setupi <upi_id@bank> [payee_name]\``);
    }

    const upiId = args[0].trim();
    if (!upiId.includes('@')) {
      return message.reply('<a:tungsten_warn:1567246685082746940> Please provide a valid UPI ID (e.g. `community@oksbi`).');
    }

    const payeeName = args.slice(1).join(' ').trim() || message.guild.name;
    const sdb = getServerDb(message.guild.id);

    sdb.prepare(`
      INSERT INTO server_settings (key, value, updated_at)
      VALUES ('server_upi_id', ?, strftime('%s', 'now'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%s', 'now')
    `).run(upiId);

    sdb.prepare(`
      INSERT INTO server_settings (key, value, updated_at)
      VALUES ('server_upi_name', ?, strftime('%s', 'now'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%s', 'now')
    `).run(payeeName);

    syncServerDataToMaster(message.guild.id);

    const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&cu=INR`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUri)}`;

    const embed = createEmbed({
      color: client.config.COLORS.SUCCESS,
      title: '💳  UPI ID Configured',
      description:
        `> Successfully configured server payment details.\n\n` +
        `• **UPI ID:** \`${upiId}\`\n` +
        `• **Payee Name:** **${payeeName}**\n\n` +
        `*Members can now use \`${prefix}showupi\` to view payment details and scan the QR code.*`
    });

    if (typeof qrUrl === 'string' && qrUrl.startsWith('http')) {
      embed.setImage(qrUrl);
    }

    return message.reply({ embeds: [embed] });
  }
};
