/**
 * EmojiPack Command (Node.js)
 * Previews and automatically installs the curated Tungsten custom animated & static emoji suite.
 */
const { PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { BUILTIN_PACK } = require('../../utils/emojis');
const { createV2Card } = require('../../utils/componentsV2');
const { hasPerm } = require('../../utils/tools');
const fs = require('node:fs');
const https = require('node:https');

function fetchBuffer(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'TungstenBot/2.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchBuffer(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

module.exports = {
  name: 'emojipack',
  aliases: ['emojispack', 'emojisetup', 'emojiauto'],
  category: 'utility',
  description: 'Preview or auto-install the curated animated custom emoji suite into your server.',
  permissions: ['ManageGuildExpressions'],
  botPermissions: ['ManageGuildExpressions'],
  usage: 'emojipack [list | install]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sub = (args[0] || 'list').toLowerCase();

    if (sub === 'install') {
      const member = message.member;
      const isAuthorized = hasPerm(member, PermissionsBitField.Flags.ManageGuildExpressions) ||
                           hasPerm(member, PermissionsBitField.Flags.ManageEmojisAndStickers) ||
                           hasPerm(member, PermissionsBitField.Flags.Administrator);

      if (!isAuthorized) {
        return message.reply('<a:tungsten_close:1567234632905138206> You require **Manage Expressions / Manage Emojis** permission to install the emoji pack.');
      }

      const botMember = message.guild.members.me;
      if (!botMember.permissions.has(PermissionsBitField.Flags.ManageGuildExpressions) &&
          !botMember.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers) &&
          !botMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.reply('<a:tungsten_close:1567234632905138206> I require **Manage Expressions / Manage Emojis** permission to upload custom emojis.');
      }

      const notice = await message.reply(`<a:tungsten_loading:1567241050567876698> **Installing curated animated & static emojis into ${message.guild.name}...** (0/${BUILTIN_PACK.length})`);

      let added = 0;
      let skipped = 0;
      let failed = 0;

      for (let i = 0; i < BUILTIN_PACK.length; i++) {
        const item = BUILTIN_PACK[i];

        // Check if emoji already exists in server
        const exists = message.guild.emojis.cache.find(e => e.name.toLowerCase() === item.name.toLowerCase());
        if (exists) {
          skipped++;
          continue;
        }

        try {
          let buffer = null;
          if (item.localFile && fs.existsSync(item.localFile)) {
            buffer = fs.readFileSync(item.localFile);
          } else if (item.remoteUrl) {
            buffer = await fetchBuffer(item.remoteUrl);
          } else if (item.discordTag) {
            const tagMatch = item.discordTag.match(/<(a?):[a-zA-Z0-9_]+:(\d+)>/);
            if (tagMatch) {
              const anim = Boolean(tagMatch[1]);
              const id = tagMatch[2];
              buffer = await fetchBuffer(`https://cdn.discordapp.com/emojis/${id}.${anim ? 'gif' : 'png'}`);
            }
          }

          if (buffer) {
            await message.guild.emojis.create({
              attachment: buffer,
              name: item.name,
              reason: `[Tungsten EmojiPack] Installed by ${message.author.tag}`
            });
            added++;
          } else {
            failed++;
          }
        } catch (e) {
          failed++;
        }

        // Throttle slightly to respect Discord rate limits
        await new Promise(r => setTimeout(r, 600));
      }

      const card = createV2Card({
        color: 0x2ecc71,
        title: '🎨  Emoji Pack Installation Complete',
        description:
          `> Successfully processed the curated animated custom emoji suite.\n\n` +
          `• **Newly Uploaded:** \`${added}\`\n` +
          `• **Already Present (Skipped):** \`${skipped}\`\n` +
          `• **Failed / Slots Full:** \`${failed}\`\n\n` +
          `*Your server now has custom animated numbers 1, 2, 3, loading spinners, alerts, and security shields!*`,
        footerText: `Tungsten Emoji Suite • ${message.guild.name}`
      });

      return notice.edit({ content: null, embeds: [card] });
    }

    // Default: List / Preview
    const formattedLines = BUILTIN_PACK.map((item, idx) => {
      const typeStr = item.animated ? '⚡' : '🖼️';
      const preview = item.discordTag || item.fallback;
      return `**${idx + 1}.** ${preview} \`:${item.name}:\` *(${typeStr} ${item.label})*`;
    });

    let packItems = formattedLines.join('\n');
    if (packItems.length > 3000) {
      const firstChunk = formattedLines.slice(0, 30).join('\n');
      packItems = `${firstChunk}\n\n*... and ${BUILTIN_PACK.length - 30} more custom emojis across all 4 dedicated servers.*`;
    }

    const previewCard = createV2Card({
      title: '🎨  Tungsten Curated Emoji Pack',
      description:
        `> Essential high-definition animated and static custom emojis designed for Tungsten.\n\n` +
        `### 📦 Available Pack Emojis (${BUILTIN_PACK.length} Total)\n` +
        `${packItems}\n\n` +
        `### 🚀 How to Install to Your Server\n` +
        `Run \`${prefix}emojipack install\` to automatically upload all these emojis into your Discord server!`,
      footerText: `Tungsten Emoji Suite • Type ${prefix}emojipack install to add`
    });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('emojipack:info')
        .setLabel('Install Guide')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('<a:tungsten_warn:1567246685082746940>'),
      new ButtonBuilder()
        .setCustomId('emojipack:view_emojis')
        .setLabel('View Server Emojis')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('<a:tungsten_warn:1567246685082746940>')
    );

    return message.reply({ embeds: [previewCard], components: [row] });
  }
};
