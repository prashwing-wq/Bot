/**
 * Tungsten Suggestion Configuration & Metrics Command (Node.js)
 * Displays active suggestions channel, module state, and vote statistics.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { isModuleEnabled } = require('../../utils/modulesHelper');

module.exports = {
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'suggestconfig',
  description: 'View current community suggestions settings and statistics.',
  category: 'utility',
  usage: 'suggestconfig',
  aliases: ['suggest-config', 'suggestionsconfig'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'suggestion_channel'").get();
    const isEnabled = isModuleEnabled(message.guild.id, 'suggestions');

    const total = sdb.prepare('SELECT COUNT(*) as c FROM suggestions WHERE guild_id = ?').get(message.guild.id)?.c || 0;
    const pending = sdb.prepare("SELECT COUNT(*) as c FROM suggestions WHERE guild_id = ? AND status = 'PENDING'").get(message.guild.id)?.c || 0;
    const approved = sdb.prepare("SELECT COUNT(*) as c FROM suggestions WHERE guild_id = ? AND status = 'APPROVED'").get(message.guild.id)?.c || 0;
    const denied = sdb.prepare("SELECT COUNT(*) as c FROM suggestions WHERE guild_id = ? AND status = 'DENIED'").get(message.guild.id)?.c || 0;

    const channelDesc = (row && row.value) ? `<#${row.value}> (\`${row.value}\`)` : '*Not configured (current channel)*';

    const embed = createEmbed({
      color: client.config.COLORS.PRIMARY,
      title: '<a:tungsten_notepad:1567241681911152733> Community Suggestions Configuration',
      description: `**Module Status:** ${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}\n` +
        `**Suggestions Channel:** ${channelDesc}\n\n` +
        `### Suggestions Metrics\n` +
        `• **Total Submitted:** \`${total}\`\n` +
        `• **Pending Review:** \`${pending}\`\n` +
        `• **Approved:** \`${approved}\`\n` +
        `• **Denied:** \`${denied}\`\n\n` +
        `*Set channel: \`${prefix}suggestchannel <#channel>\` | Approve: \`${prefix}suggest-approve <id>\` | Deny: \`${prefix}suggest-deny <id>\`*`
    });

    return message.reply({ embeds: [embed] });
  }
};
