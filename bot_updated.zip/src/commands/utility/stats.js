/**
 * Bot Statistics Command
 */
const os = require('os');
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'stats',
  aliases: ['bi', 'status'],
  category: 'utility',
  description: 'Displays Tungsten runtime statistics, resource usage, and host details.',
  cooldown: 5,
  async execute(message, args, client) {
    const memUsedMB = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
    const totalMemGB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
    const freeMemGB = (os.freemem() / 1024 / 1024 / 1024).toFixed(1);

    const uptimeSec = Math.floor(process.uptime());
    const days = Math.floor(uptimeSec / 86400);
    const hours = Math.floor((uptimeSec % 86400) / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const seconds = uptimeSec % 60;
    const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    const totalServers = client.guilds?.cache ? client.guilds.cache.size : 0;
    let totalMembers = 0;
    if (client.guilds?.cache) {
      for (const g of client.guilds.cache.values()) {
        totalMembers += (g.memberCount || 0);
      }
    }
    const totalChannels = client.channels?.cache ? client.channels.cache.size : 0;
    const totalCommands = client.commands ? client.commands.size : 0;

    const embed = createEmbed({
      title: 'Statistics',
      fields: [
        { name: 'Servers', value: `\`${totalServers.toLocaleString()}\``, inline: true },
        { name: 'Users', value: `\`${totalMembers.toLocaleString()}\``, inline: true },
        { name: 'Channels', value: `\`${totalChannels.toLocaleString()}\``, inline: true },
        { name: 'Commands', value: `\`${totalCommands.toLocaleString()}\``, inline: true },
        { name: 'Uptime', value: `\`${uptimeStr}\``, inline: true },
        { name: 'Ping', value: `\`${Math.round(client.ws.ping)}ms\``, inline: true },
        { name: 'Memory', value: `\`${memUsedMB}MB / ${totalMemGB}GB\``, inline: true },
        { name: 'Runtime', value: `\`Node.js ${process.version}\``, inline: true },
        { name: 'Platform', value: `\`${os.type()} (${os.arch()})\``, inline: true }
      ]
    });

    if (client.user && typeof client.user.displayAvatarURL === 'function') {
      const avatar = client.user.displayAvatarURL();
      if (typeof avatar === 'string' && avatar.startsWith('http')) {
        embed.setThumbnail(avatar);
        embed.setAuthor({ name: client.user.username, iconURL: avatar });
      }
    }

    await message.reply({ embeds: [embed] });
  }
};
