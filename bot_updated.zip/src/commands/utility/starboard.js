/**
 * Tungsten Starboard Configuration Command (Node.js)
 * Configure the starboard to showcase top community messages based on star reactions.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { isModuleEnabled, setModuleStatus } = require('../../utils/modulesHelper');

module.exports = {
  name: 'starboard',
  description: 'Configure and manage the starboard highlighting top community messages.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'utility',
  usage: 'starboard <channel|limit|selfstar|enable|disable|status> [options]',
  aliases: ['star'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) && !hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need `Manage Server` permission to configure the starboard.'
          })
        ]
      });
    }

    const sub = (args[0] || 'status').toLowerCase();
    const sdb = getServerDb(message.guild.id);

    // 1. CHANNEL
    if (sub === 'channel' || sub === 'setchannel') {
      const channel = message.mentions?.channels?.first() ||
        message.guild.channels.cache.get(args[1]) ||
        (args[1] ? await message.guild.channels.fetch(args[1]).catch(() => null) : null);

      if (!channel || !channel.isTextBased()) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.WARNING,
              title: 'Invalid Channel',
              description: `**Usage:** \`${prefix}starboard channel <#channel>\``
            })
          ]
        });
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value) VALUES ('starboard_channel', ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
      `).run(channel.id);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_star:1567242331785138238> Starboard Channel Configured',
            description: `Starboard highlights will now be posted to ${channel} (\`${channel.id}\`).`
          })
        ]
      });
    }

    // 2. LIMIT / THRESHOLD
    if (sub === 'limit' || sub === 'threshold' || sub === 'count') {
      const limit = parseInt(args[1], 10);
      if (isNaN(limit) || limit < 1 || limit > 100) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.WARNING,
              title: 'Invalid Star Limit',
              description: `Please specify a valid number between 1 and 100.\nExample: \`${prefix}starboard limit 3\``
            })
          ]
        });
      }

      sdb.prepare(`
        INSERT INTO server_settings (key, value) VALUES ('starboard_threshold', ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
      `).run(String(limit));

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_star:1567242331785138238> Starboard Threshold Updated',
            description: `Messages now require at least **${limit} <a:tungsten_star:1567242331785138238> reactions** to be pinned to the starboard.`
          })
        ]
      });
    }

    // 3. SELF STAR
    if (sub === 'selfstar' || sub === 'self') {
      const val = (args[1] || '').toLowerCase();
      const allow = (val === 'enable' || val === 'on' || val === 'true' || val === 'yes');

      sdb.prepare(`
        INSERT INTO server_settings (key, value) VALUES ('starboard_selfstar', ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
      `).run(allow ? '1' : '0');

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_star:1567242331785138238> Starboard Self-Star Updated',
            description: `Author self-stars are now **${allow ? 'ALLOWED' : 'IGNORED'}**.`
          })
        ]
      });
    }

    // 4. ENABLE / DISABLE
    if (sub === 'enable' || sub === 'on') {
      setModuleStatus(message.guild.id, 'starboard', true);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_ui_toggle_on:1569329685110849576> Starboard Enabled',
            description: 'Starboard monitoring is now **ACTIVE**.'
          })
        ]
      });
    }

    if (sub === 'disable' || sub === 'off') {
      setModuleStatus(message.guild.id, 'starboard', false);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: '<a:tungsten_ui_toggle_off:1569329677187678368> Starboard Disabled',
            description: 'Starboard monitoring is now **DISABLED**.'
          })
        ]
      });
    }

    // 5. STATUS / CONFIG (Default)
    const chanRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_channel'").get();
    const threshRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_threshold'").get();
    const selfRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_selfstar'").get();
    const isEnabled = isModuleEnabled(message.guild.id, 'starboard');

    const totalStarred = sdb.prepare('SELECT COUNT(*) as c FROM starboard_messages WHERE guild_id = ?').get(message.guild.id)?.c || 0;
    const channelDesc = (chanRow && chanRow.value) ? `<#${chanRow.value}> (\`${chanRow.value}\`)` : '*Not configured*';
    const threshold = (threshRow && threshRow.value) ? parseInt(threshRow.value, 10) : 3;
    const allowSelfStar = selfRow ? selfRow.value === '1' : false;

    const embed = createEmbed({
      color: client.config.COLORS.PRIMARY,
      title: '<a:tungsten_star:1567242331785138238> Starboard Configuration',
      description: `**Module Status:** ${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}\n` +
        `**Starboard Channel:** ${channelDesc}\n` +
        `**Star Threshold:** \`${threshold}\` <a:tungsten_star:1567242331785138238>\n` +
        `**Self-Starring:** \`${allowSelfStar ? 'Allowed' : 'Ignored'}\`\n` +
        `**Total Starred Posts:** \`${totalStarred}\`\n\n` +
        `*Commands:*\n` +
        `• \`${prefix}starboard channel <#channel>\` — Set starboard channel\n` +
        `• \`${prefix}starboard limit <count>\` — Set star threshold\n` +
        `• \`${prefix}starboard selfstar <enable|disable>\` — Toggle author self-stars\n` +
        `• \`${prefix}starboard <enable|disable>\` — Toggle module`
    });

    return message.reply({ embeds: [embed] });
  }
};
