/**
 * Backup Command
 * Creates structural server snapshots (roles, channels, categories, permissions)
 */
const fs = require('node:fs');
const path = require('node:path');
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'backup',
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  description: 'Create and inspect server structural template backups.',
  category: 'backups',
  usage: 'backup <create|list|info> [backup_id]',
  aliases: ['backups', 'serverbackup'],
  cooldown: 10,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.Administrator) &&
        !client.config.OWNER_IDS.includes(message.author.id)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Administrator` permission or Bot Ownership to manage backups.'
          })
        ]
      });
    }

    const sub = args[0]?.toLowerCase() || 'create';
    const sdb = getServerDb(message.guild.id);

    if (sub === 'create') {
      const backupId = `bk_${Date.now().toString(36)}`;
      const backupName = args.slice(1).join(' ') || `${message.guild.name} Snapshot`;

      const roles = message.guild.roles.cache
        .filter(r => !r.managed && r.id !== message.guild.id)
        .map(r => ({
          name: r.name,
          color: r.color,
          hoist: r.hoist,
          permissions: r.permissions.bitfield.toString(),
          position: r.position
        }));

      const channels = message.guild.channels.cache
        .map(c => ({
          name: c.name,
          type: c.type,
          parentId: c.parentId,
          position: c.position
        }));

      const snapshot = {
        guildId: message.guild.id,
        guildName: message.guild.name,
        createdAt: Date.now(),
        creator: message.author.id,
        roles,
        channels
      };

      sdb.prepare(`
        INSERT INTO server_backups (backup_id, guild_id, name, creator_id, created_at, snapshot_json)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(backupId, message.guild.id, backupName, message.author.id, Date.now(), JSON.stringify(snapshot));

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '💾 Server Backup Created',
            description: `Successfully captured server structure snapshot.\n\n` +
              `• **Backup ID:** \`${backupId}\`\n` +
              `• **Name:** ${backupName}\n` +
              `• **Roles Saved:** \`${roles.length}\`\n` +
              `• **Channels Saved:** \`${channels.length}\`\n\n` +
              `*Saved safely in dedicated server database.*`
          })
        ]
      });
    }

    if (sub === 'list') {
      const rows = sdb.prepare('SELECT backup_id, name, created_at FROM server_backups WHERE guild_id = ? ORDER BY created_at DESC LIMIT 10').all(message.guild.id);
      if (!rows || rows.length === 0) {
        return message.reply('No backups recorded for this server yet.');
      }

      const listStr = rows.map(r => `• \`${r.backup_id}\` — **${r.name}** (<t:${Math.floor(r.created_at / 1000)}:R>)`).join('\n');

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: `💾 Server Backups [${rows.length}]`,
            description: listStr
          })
        ]
      });
    }

    if (sub === 'info') {
      const backupId = args[1];
      if (!backupId) return message.reply(`Usage: \`${prefix}backup info <backup_id>\``);

      const row = sdb.prepare('SELECT * FROM server_backups WHERE guild_id = ? AND backup_id = ?').get(message.guild.id, backupId);
      if (!row) return message.reply(`<a:tungsten_close:1567234632905138206> Backup \`${backupId}\` was not found for this server.`);

      let snapshot = {};
      try { snapshot = JSON.parse(row.snapshot_json); } catch (e) {}

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.INFO,
            title: `💾 Backup Details — ${row.name}`,
            fields: [
              { name: 'Backup ID', value: `\`${row.backup_id}\``, inline: true },
              { name: 'Created', value: `<t:${Math.floor(row.created_at / 1000)}:F>`, inline: true },
              { name: 'Creator', value: `<@${row.creator_id}>`, inline: true },
              { name: 'Roles Snapshot', value: `\`${snapshot.roles?.length || 0}\` roles`, inline: true },
              { name: 'Channels Snapshot', value: `\`${snapshot.channels?.length || 0}\` channels`, inline: true }
            ]
          })
        ]
      });
    }

    if (sub === 'restore') {
      const backupId = args[1];
      if (!backupId) return message.reply(`Usage: \`${prefix}backup restore <backup_id>\``);

      const row = sdb.prepare('SELECT * FROM server_backups WHERE guild_id = ? AND backup_id = ?').get(message.guild.id, backupId);
      if (!row) return message.reply(`<a:tungsten_close:1567234632905138206> Backup \`${backupId}\` was not found for this server.`);

      let snapshot = {};
      try { snapshot = JSON.parse(row.snapshot_json); } catch (e) {
        return message.reply('<a:tungsten_close:1567234632905138206> Failed to parse backup data payload.');
      }

      const progressMsg = await message.reply('🔄 **Restoring server structure from snapshot...**');

      let rolesRestored = 0;
      let channelsRestored = 0;

      // 1. Recreate missing roles
      if (Array.isArray(snapshot.roles)) {
        for (const r of snapshot.roles) {
          try {
            const exists = message.guild.roles.cache.find(role => role.name.toLowerCase() === r.name.toLowerCase());
            if (!exists) {
              const roleOpts = {
                name: r.name,
                hoist: Boolean(r.hoist),
                permissions: r.permissions ? BigInt(r.permissions) : 0n,
                reason: `[Tungsten Backup Restore] Snapshot ${backupId}`
              };
              if (r.color !== undefined && r.color !== null) {
                roleOpts.colors = { primaryColor: r.color, primary: r.color };
              }
              await message.guild.roles.create(roleOpts).catch(() => null);
              rolesRestored++;
            }
          } catch (e) {}
        }
      }

      // 2. Recreate missing channels (Categories first, then child channels)
      if (Array.isArray(snapshot.channels)) {
        const categories = snapshot.channels.filter(c => c.type === 4);
        const nonCategories = snapshot.channels.filter(c => c.type !== 4);

        for (const c of categories) {
          try {
            const exists = message.guild.channels.cache.find(ch => ch.name.toLowerCase() === c.name.toLowerCase() && ch.type === 4);
            if (!exists) {
              await message.guild.channels.create({
                name: c.name,
                type: 4,
                reason: `[Tungsten Backup Restore] Snapshot ${backupId}`
              }).catch(() => null);
              channelsRestored++;
            }
          } catch (e) {}
        }

        for (const c of nonCategories) {
          try {
            const exists = message.guild.channels.cache.find(ch => ch.name.toLowerCase() === c.name.toLowerCase());
            if (!exists) {
              await message.guild.channels.create({
                name: c.name,
                type: c.type || 0,
                reason: `[Tungsten Backup Restore] Snapshot ${backupId}`
              }).catch(() => null);
              channelsRestored++;
            }
          } catch (e) {}
        }
      }

      return progressMsg.edit({
        content: null,
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_success:1567242523468890274> Server Structure Restored',
            description: `Successfully restored structural snapshot \`${row.name}\` (\`${backupId}\`).\n\n` +
              `• **Roles Recreated:** \`${rolesRestored}\`\n` +
              `• **Channels Recreated:** \`${channelsRestored}\`\n\n` +
              `*Existing roles and channels were preserved.*`
          })
        ]
      });
    }

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.INFO,
          title: '💾 Server Backup System',
          description: `• \`${prefix}backup create [name]\` — Capture server roles & channels\n` +
            `• \`${prefix}backup list\` — View saved backups\n` +
            `• \`${prefix}backup info <id>\` — Inspect backup details\n` +
            `• \`${prefix}backup restore <id>\` — Recreate missing roles & channels`
        })
      ]
    });
  }
};
