/**
 * Reaction Roles Command (Node.js)
 * Implements interactive button and dropdown self-role assignment panels.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  PermissionFlagsBits
} = require('discord.js');
const { hasPerm, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

const DANGEROUS_PERMS = [
  PermissionFlagsBits.Administrator,
  PermissionFlagsBits.ManageGuild,
  PermissionFlagsBits.ManageRoles,
  PermissionFlagsBits.ManageChannels,
  PermissionFlagsBits.BanMembers,
  PermissionFlagsBits.KickMembers,
  PermissionFlagsBits.ManageWebhooks,
  PermissionFlagsBits.MentionEveryone
];

const DANGEROUS_PERM_NAMES = [
  'Administrator',
  'ManageGuild',
  'ManageRoles',
  'ManageChannels',
  'BanMembers',
  'KickMembers',
  'ManageWebhooks',
  'MentionEveryone'
];

function hasDangerousPerms(role) {
  if (!role || !role.permissions) return false;
  return DANGEROUS_PERMS.some(p => {
    try {
      return typeof role.permissions.has === 'function' && role.permissions.has(p);
    } catch {
      return false;
    }
  }) || DANGEROUS_PERM_NAMES.some(name => {
    try {
      return typeof role.permissions.has === 'function' && role.permissions.has(name);
    } catch {
      return false;
    }
  });
}

function buildDeployRows(rows, guild) {
  const buttons = [];
  for (const r of rows.slice(0, 25)) {
    const parts = (r.emoji || '').split(':');
    const em = parts[0] || '🎭';
    const lbl = parts[1] || 'Role';
    const role = guild.roles?.cache?.get(r.role_id);
    if (role) {
      const btn = new ButtonBuilder()
        .setCustomId(`rr:toggle:${role.id}`)
        .setLabel(lbl.slice(0, 80))
        .setStyle(ButtonStyle.Primary);
      if (em) {
        try {
          btn.setEmoji(em);
        } catch (_) {}
      }
      buttons.push(btn);
    }
  }

  if (buttons.length === 0) return null;

  const actionRows = [];
  for (let i = 0; i < buttons.length; i += 5) {
    actionRows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
  }
  return actionRows;
}

async function deployReactionRolePanel(guild, channel, sdb) {
  const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(guild.id);
  if (rows.length === 0) {
    return { error: 'No reaction roles configured yet. Add one first: `reactionrole add @role Gamer 🎮`' };
  }
  const actionRows = buildDeployRows(rows, guild);
  if (!actionRows || actionRows.length === 0) {
    return { error: 'None of the mapped roles exist in this server.' };
  }

  let title = `🎭  Self-Assignable Roles • ${guild.name}`;
  let description =
    `Select and click the buttons below to assign or remove roles from your profile.\n\n` +
    `• Clicking a button when you already have the role will cleanly remove it.\n` +
    `• Clicking a button when you do not have the role will instantly grant it.\n\n` +
    `-# Click any button below to toggle your roles.`;
  let banner = null;
  let avatar = null;

  try {
    const settings = sdb.prepare("SELECT key, value FROM server_settings WHERE key IN ('rr_panel_title', 'rr_panel_description', 'rr_panel_banner', 'rr_panel_avatar')").all();
    for (const row of settings) {
      if (row.key === 'rr_panel_title' && row.value) title = row.value;
      if (row.key === 'rr_panel_description' && row.value) description = row.value;
      if (row.key === 'rr_panel_banner' && row.value) banner = row.value;
      if (row.key === 'rr_panel_avatar' && row.value) avatar = row.value;
    }
  } catch (_) {}

  const card = createV2Card({
    color: undefined,
    title,
    description,
    thumbnailUrl: (avatar && typeof avatar === 'string' && avatar.startsWith('http')) ? avatar : null
  });
  if (banner && typeof banner === 'string' && banner.startsWith('http')) {
    card.setImage(banner);
  }

  const sent = await channel.send({ embeds: [card], components: actionRows });
  sdb.prepare('UPDATE reaction_roles SET message_id = ?, channel_id = ? WHERE guild_id = ?')
    .run(sent.id, channel.id, guild.id);

  return { success: true, messageId: sent.id, channel };
}

function buildReactionRoleStudio(guild, rows, prefix = '!') {
  let listText = '';
  if (!rows || rows.length === 0) {
    listText = '*No reaction roles configured yet.*';
  } else {
    listText = rows.map((r, i) => {
      const parts = (r.emoji || '').split(':');
      const em = parts[0] || '🎭';
      const lbl = parts[1] || 'Role';
      const role = guild.roles?.cache?.get(r.role_id);
      const roleMention = role ? `<@&${r.role_id}> (\`${role.name}\`)` : `\`Deleted Role (${r.role_id})\``;
      return `\`#${i + 1}\` ${roleMention} — ${em} **${lbl}**`;
    }).join('\n');
  }

  let customTitle = null;
  let customDesc = null;
  let customBanner = null;
  let customAvatar = null;
  try {
    const sdb = getServerDb(guild.id);
    const settings = sdb.prepare("SELECT key, value FROM server_settings WHERE key IN ('rr_panel_title', 'rr_panel_description', 'rr_panel_banner', 'rr_panel_avatar')").all();
    for (const row of settings) {
      if (row.key === 'rr_panel_title') customTitle = row.value;
      if (row.key === 'rr_panel_description') customDesc = row.value;
      if (row.key === 'rr_panel_banner') customBanner = row.value;
      if (row.key === 'rr_panel_avatar') customAvatar = row.value;
    }
  } catch (_) {}

  const customInfo = [
    `• **Title:** ${customTitle ? `\`${customTitle.slice(0, 60)}\`` : '*Default* (`🎭 Self-Assignable Roles • Server Name`)'}`,
    `• **Description:** ${customDesc ? `\`${customDesc.slice(0, 70)}...\`` : '*Default*'}`,
    `• **Banner:** ${customBanner ? (customBanner.startsWith('http') ? `[View Banner](${customBanner})` : `\`${customBanner.slice(0, 40)}\``) : '*None*'}`,
    `• **Avatar/Thumbnail:** ${customAvatar ? (customAvatar.startsWith('http') ? `[View Avatar](${customAvatar})` : `\`${customAvatar.slice(0, 40)}\``) : '*None*'}`
  ].join('\n');

  const card = createV2Card({
    color: undefined,
    title: `🎭  Reaction Role Studio • ${guild.name}`,
    description:
      `> Interactive self-assignable reaction role management system.\n\n` +
      `**🎨 Panel Customizations:**\n` +
      customInfo +
      `\n\n` +
      `**<a:tungsten_refresh:1567241907116187658> Configured Self-Assignable Roles [${rows ? rows.length : 0}]:**\n` +
      listText +
      `\n\n**Quick Commands:**\n` +
      `• \`${prefix}reactionrole add <@role> <label> <emoji>\` — Add a role option\n` +
      `• \`${prefix}reactionrole panel [#channel]\` — Deploy self-role buttons\n` +
      `• \`${prefix}reactionrole clear\` — Reset all mappings`,
    thumbnailUrl: (customAvatar && typeof customAvatar === 'string' && customAvatar.startsWith('http')) ? customAvatar : null,
    footerText: `Tungsten Role Engine • ${guild.name}`
  });
  if (customBanner && typeof customBanner === 'string' && customBanner.startsWith('http')) {
    card.setImage(customBanner);
  }

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('rr:btn_add').setLabel('Add Role').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_plus:1567241830612086884>'),
    new ButtonBuilder().setCustomId('rr:btn_remove').setLabel('Remove Role').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_minus:1567241276057849856>'),
    new ButtonBuilder().setCustomId('rr:btn_deploy').setLabel('Deploy Panel').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_rocket:1567241971804798976>'),
    new ButtonBuilder().setCustomId('rr:btn_clear').setLabel('Clear All').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_sweep:1567242656281657414>'),
    new ButtonBuilder().setCustomId('rr:btn_refresh').setLabel('Refresh').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>')
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('rr:btn_edit_title').setLabel('Set Title').setStyle(ButtonStyle.Secondary).setEmoji('✏️'),
    new ButtonBuilder().setCustomId('rr:btn_edit_desc').setLabel('Set Description').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
    new ButtonBuilder().setCustomId('rr:btn_edit_banner').setLabel('Set Banner').setStyle(ButtonStyle.Secondary).setEmoji('🖼️'),
    new ButtonBuilder().setCustomId('rr:btn_edit_avatar').setLabel('Set Avatar').setStyle(ButtonStyle.Secondary).setEmoji('👤'),
    new ButtonBuilder().setCustomId('rr:btn_reset_custom').setLabel('Reset Custom').setStyle(ButtonStyle.Danger).setEmoji('↺')
  );

  return { embeds: [card], components: [row1, row2] };
}

module.exports = {
  name: 'reactionrole',
  aliases: ['rr', 'rrpanel', 'rpanel', 'rolepanel', 'rolespanel', 'selfrole', 'selfroles'],
  category: 'roles',
  description: 'Create interactive self-role assignment buttons and panels for members.',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  usage: '[add <@role> <label> <emoji> | panel <#channel> | list | clear]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionFlagsBits.ManageRoles) && !isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Roles` permission to configure reaction roles.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase();

    // 1. Add Reaction Role mapping
    if (sub === 'add') {
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1]) : null);
      if (!role) return message.reply(`Usage: \`${prefix}reactionrole add <@role> <label> <emoji>\``);

      // Check @everyone
      if (role.id === message.guild.id) {
        return message.reply('<a:tungsten_close:1567234632905138206> The `@everyone` role cannot be added to a reaction role panel.');
      }

      // Hierarchy check
      if (message.guild.members?.me?.roles?.highest?.position !== undefined && message.guild.members.me.roles.highest.position <= role.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> Cannot add that role: its position is equal to or higher than Tungsten\'s highest role.');
      }

      // Check for dangerous permissions
      if (hasDangerousPerms(role)) {
        return message.reply('<a:tungsten_warn:1567242784535085148> That role cannot be added to a reaction role panel because it has dangerous administrative permissions (**Administrator**, **Manage Server**, **Manage Roles**, etc.). For security, roles with dangerous permissions can never be self-assigned.');
      }

      const label = args[2] || role.name;
      const emoji = args[3] || '🎭';

      sdb.prepare(`
        INSERT INTO reaction_roles (guild_id, message_id, channel_id, emoji, role_id)
        VALUES (?, 'pending', 'pending', ?, ?)
      `).run(message.guild.id, `${emoji}:${label}`, role.id);

      return message.reply(`<a:tungsten_success:1567242523468890274> Added reaction role mapping for ${role} with label \`${label}\` and emoji ${emoji}. Use \`${prefix}reactionrole panel\` to deploy the panel.`);
    }

    // 2. Clear reaction roles
    if (sub === 'clear' || sub === 'reset') {
      sdb.prepare('DELETE FROM reaction_roles WHERE guild_id = ?').run(message.guild.id);
      return message.reply('<a:tungsten_success:1567242523468890274> Cleared all reaction role mappings for this server.');
    }

    // 3. Remove single reaction role mapping
    if (sub === 'remove' || sub === 'delete') {
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1]) : null);
      const roleId = role ? role.id : args[1];
      if (!roleId) return message.reply(`Usage: \`${prefix}reactionrole remove <@role|role_id>\``);
      sdb.prepare('DELETE FROM reaction_roles WHERE guild_id = ? AND role_id = ?').run(message.guild.id, roleId);
      return message.reply(`<a:tungsten_success:1567242523468890274> Removed reaction role mapping for role ID \`${roleId}\`.`);
    }

    // 4. Deploy Interactive Panel if explicit target channel provided or sub === 'deploy'
    const channelMention = message.mentions?.channels?.first() || (args[1] ? message.guild.channels.cache.get(args[1]) : null);

    if (sub === 'deploy' || (sub === 'panel' && channelMention)) {
      const targetChannel = channelMention || message.channel;
      const res = await deployReactionRolePanel(message.guild, targetChannel, sdb);
      if (res.error) {
        return message.reply(`<a:tungsten_close:1567234632905138206> ${res.error}`);
      }
      return message.reply(`<a:tungsten_success:1567242523468890274> Reaction role panel successfully deployed to ${targetChannel}.`);
    }

    // 5. Default / panel / studio / list: Show Interactive Reaction Role Studio
    const rows = sdb.prepare('SELECT * FROM reaction_roles WHERE guild_id = ?').all(message.guild.id);
    const studio = buildReactionRoleStudio(message.guild, rows, prefix);
    return message.reply(studio);
  },

  buildReactionRoleStudio,
  buildDeployRows,
  deployReactionRolePanel,
  hasDangerousPerms,
  DANGEROUS_PERMS
};
