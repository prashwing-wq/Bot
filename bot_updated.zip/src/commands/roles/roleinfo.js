/**
 * Roleinfo Command
 * Detailed stats on a specific role
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'roleinfo',
  description: 'Display properties, permissions, and member count of a role.',
  category: 'roles',
  usage: 'roleinfo <@role|name|id>',
  aliases: ['rinfo', 'ri'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!args[0]) {
      return message.reply(`**Usage:** \`${prefix}roleinfo <@role|name|id>\``);
    }

    const roleQuery = args.join(' ').toLowerCase();
    const role = message.mentions?.roles?.first() ||
      message.guild.roles.cache.get(args[0]) ||
      message.guild.roles.cache.find(r => r.name.toLowerCase() === roleQuery);

    if (!role) {
      return message.reply('Role not found.');
    }

    const createdAt = `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`;
    const permissions = role.permissions.toArray();
    const permsDisplay = permissions.length > 10
      ? `${permissions.slice(0, 10).map(p => `\`${p}\``).join(', ')} ... (+${permissions.length - 10} more)`
      : (permissions.length > 0 ? permissions.map(p => `\`${p}\``).join(', ') : 'None');

    const embed = createEmbed({
      color: role.color || client.config.COLORS.PRIMARY,
      title: `🎭 Role Info — ${role.name}`,
      fields: [
        { name: '🆔 Role ID', value: `\`${role.id}\``, inline: true },
        { name: '🎨 Hex Color', value: `\`${role.hexColor}\``, inline: true },
        { name: '🔝 Position', value: `\`${role.position}\` / \`${message.guild.roles.cache.size}\``, inline: true },
        { name: '👥 Member Count', value: `\`${role.members.size}\``, inline: true },
        { name: '📌 Hoisted', value: role.hoist ? 'Yes <a:tungsten_success:1567242523468890274>' : 'No <a:tungsten_close:1567234632905138206>', inline: true },
        { name: '🤖 Managed / Integration', value: role.managed ? 'Yes <a:tungsten_success:1567242523468890274>' : 'No <a:tungsten_close:1567234632905138206>', inline: true },
        { name: '📅 Created', value: createdAt, inline: true },
        { name: '🔑 Key Permissions', value: permsDisplay, inline: false }
      ],
      footer: `Requested by ${message.author.tag}`
    });

    return message.reply({ embeds: [embed] });
  }
};
