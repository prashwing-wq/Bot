/**
 * Autorole Command Suite & Interactive Studio (Node.js)
 * Configures automatic join role assignment for humans and bots using isolated per-server databases.
 * Features native Components V2 layout and interactive studio buttons.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { createV2Card, createButtonRow } = require('../../utils/componentsV2');

function parseRoleIds(raw) {
  if (!raw) return [];
  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (Array.isArray(parsed)) return parsed.map(String);
  } catch (e) {}
  return String(raw).replace(/[\[\]]/g, '').split(',')
    .map(s => s.trim())
    .filter(s => /^\d+$/.test(s));
}

function getAutoroleData(guildId) {
  const sdb = getServerDb(guildId);
  const row = sdb.prepare('SELECT bots, humans FROM autorole WHERE guild_id = ?').get(String(guildId));
  if (row) {
    return {
      bots: parseRoleIds(row.bots),
      humans: parseRoleIds(row.humans)
    };
  }
  return { bots: [], humans: [] };
}

function saveAutoroleData(guildId, data) {
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  const botsJson = JSON.stringify(data.bots || []);
  const humansJson = JSON.stringify(data.humans || []);

  sdb.prepare('INSERT OR REPLACE INTO autorole (guild_id, bots, humans) VALUES (?, ?, ?)')
    .run(gid, botsJson, humansJson);

  // Dual-write to master
  syncServerDataToMaster(gid);
}

function buildAutoroleStudio(guild, data, prefix) {
  const humanRoles = data.humans.map(id => {
    const r = guild.roles.cache.get(id);
    return r ? `<@&${r.id}> (\`${r.name}\`)` : `\`Deleted Role (${id})\``;
  });
  const botRoles = data.bots.map(id => {
    const r = guild.roles.cache.get(id);
    return r ? `<@&${r.id}> (\`${r.name}\`)` : `\`Deleted Role (${id})\``;
  });

  const card = createV2Card({
    color: 0x2b2d31,
    title: `🎭  Autorole Studio • ${guild.name}`,
    description:
      `> Automatic role assignment for new arrivals upon server entry.\n\n` +
      `**<a:tungsten_refresh:1567241907116187658> Human Autoroles [${data.humans.length}/10]:**\n` +
      (humanRoles.length > 0 ? humanRoles.join('\n') : '*No human autoroles configured.*') +
      `\n\n**<a:tungsten_refresh:1567241907116187658> Bot Autoroles [${data.bots.length}/10]:**\n` +
      (botRoles.length > 0 ? botRoles.join('\n') : '*No bot autoroles configured.*') +
      `\n\n**Quick Commands:**\n` +
      `• \`${prefix}autorole humans add @role\` — Add join role for humans\n` +
      `• \`${prefix}autorole bots add @role\` — Add join role for bots\n` +
      `• \`${prefix}autorole reset\` — Clear all configured autoroles`,
    footerText: `Tungsten Role Engine • ${guild.name}`
  });

  const row0 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('autorole:add:human').setLabel('Add Human Role').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('autorole:add:bot').setLabel('Add Bot Role').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('autorole:remove').setLabel('Remove Role').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_minus:1567241276057849856>')
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('autorole:refresh').setLabel('Refresh').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('autorole:reset').setLabel('Reset All').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_sweep:1567242656281657414>'),
    new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [card], components: [row0, row1] };
}

module.exports = {
  name: 'autorole',
  aliases: [
    'ar',
    'joinrole',
    'autorolepanel',
    'autorole_panel',
    'autorolestudio',
    'autorolemenu'
  ],
  category: 'roles',
  description: 'Manage automated join role assignment for new human members and bots with interactive studio.',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  usage: '[panel | humans | bots | config | reset] [add|remove] [role]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    // Permissions: Administrator or ManageRoles or Owner
    if (!hasPerm(message.member, PermissionFlagsBits.ManageRoles)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Roles** permission to configure autoroles.');
    }

    const sub = args[0]?.toLowerCase();
    const data = getAutoroleData(message.guild.id);

    // 1. autorole panel / config / default
    if (!sub || sub === 'panel' || sub === 'studio' || sub === 'config' || sub === 'settings' || sub === 'show') {
      const studio = buildAutoroleStudio(message.guild, data, prefix);
      return message.reply(studio);
    }

    // 2. autorole reset [all | bots | humans]
    if (sub === 'reset') {
      const resetTarget = args[1]?.toLowerCase();
      if (resetTarget === 'bots' || resetTarget === 'bot') {
        saveAutoroleData(message.guild.id, { ...data, bots: [] });
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '🧹 Bot Autoroles Reset',
              description: 'All bot autoroles have been cleared for this server.'
            })
          ]
        });
      }

      if (resetTarget === 'humans' || resetTarget === 'human') {
        saveAutoroleData(message.guild.id, { ...data, humans: [] });
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '🧹 Human Autoroles Reset',
              description: 'All human autoroles have been cleared for this server.'
            })
          ]
        });
      }

      saveAutoroleData(message.guild.id, { bots: [], humans: [] });
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '🧹 Autoroles Reset',
            description: 'All human and bot autoroles have been cleared for this server.'
          })
        ]
      });
    }

    // 3. autorole humans / bots [add / remove / list]
    if (sub === 'humans' || sub === 'human' || sub === 'bots' || sub === 'bot') {
      const isBotTarget = sub.startsWith('bot');
      const action = args[1]?.toLowerCase();

      // Display configured list for bots or humans
      if (!action || action === 'list' || action === 'show' || action === 'config') {
        const targetList = isBotTarget ? data.bots : data.humans;
        const targetLabel = isBotTarget ? 'Bot' : 'Human';
        const rolesDesc = targetList.map(id => {
          const r = message.guild.roles.cache.get(id);
          return r ? `• <@&${r.id}> (\`${r.name}\`)` : `• \`Deleted Role (${id})\``;
        });

        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.PRIMARY,
              title: `🎭  ${targetLabel} Autoroles • ${message.guild.name}`,
              description:
                `> Automatic join roles assigned to new ${isBotTarget ? 'bot integrations' : 'human members'}.\n\n` +
                (rolesDesc.length > 0 ? rolesDesc.join('\n') : `*No ${targetLabel.toLowerCase()} autoroles configured.*`) +
                `\n\n**Quick Commands:**\n` +
                `• \`${prefix}autorole ${sub} add @role\`\n` +
                `• \`${prefix}autorole ${sub} remove @role\`\n` +
                `• \`${prefix}autorole reset ${isBotTarget ? 'bots' : 'humans'}\``,
              footerText: `Total: ${targetList.length}/10 ${targetLabel.toLowerCase()} autorole(s)`
            })
          ]
        });
      }

      const roleMention = args.slice(2).join(' ').trim();

      if (!['add', 'remove', 'del', 'rem'].includes(action)) {
        return message.reply(`Usage: \`${prefix}autorole ${sub} <add|remove> <@role>\``);
      }

      // Resolve role
      const roleIdMatch = roleMention.match(/\d{17,20}/);
      const roleId = roleIdMatch ? roleIdMatch[0] : null;
      const role = roleId ? message.guild.roles.cache.get(roleId) : message.guild.roles.cache.find(r => r.name.toLowerCase() === roleMention.toLowerCase());

      if (!role) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please specify a valid role (mention or role ID).');
      }

      if (role.id === message.guild.id) {
        return message.reply('<a:tungsten_close:1567234632905138206> The `@everyone` role cannot be set as an autorole.');
      }

      // Hierarchy check
      if (message.guild.members.me.roles.highest.position <= role.position) {
        return message.reply(`<a:tungsten_close:1567234632905138206> I cannot manage ${role} because it is positioned higher than or equal to my highest role.`);
      }

      const targetList = isBotTarget ? data.bots : data.humans;

      if (action === 'add') {
        if (role.permissions?.has(PermissionFlagsBits.Administrator) || role.permissions?.has('Administrator')) {
          return message.reply('<a:tungsten_warn:1567242784535085148> That role cannot be used as an autorole because **Administrator** is enabled for that role. For security, administrative roles can never be automatically assigned to joining members.');
        }
        if (targetList.includes(role.id)) {
          return message.reply(`<a:tungsten_info:1567240890748248084> ${role} is already in ${isBotTarget ? 'bot' : 'human'} autoroles.`);
        }
        if (targetList.length >= 10) {
          return message.reply('<a:tungsten_close:1567234632905138206> Maximum limit of 10 autoroles reached.');
        }
        targetList.push(role.id);
        saveAutoroleData(message.guild.id, data);
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_success:1567242523468890274> Autorole Added',
              description: `Successfully added ${role} to **${isBotTarget ? 'bot' : 'human'}** autoroles.`
            })
          ]
        });
      } else {
        if (!targetList.includes(role.id)) {
          return message.reply(`<a:tungsten_info:1567240890748248084> ${role} is not in ${isBotTarget ? 'bot' : 'human'} autoroles.`);
        }
        const updatedList = targetList.filter(id => id !== role.id);
        if (isBotTarget) data.bots = updatedList;
        else data.humans = updatedList;
        saveAutoroleData(message.guild.id, data);
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.SUCCESS,
              title: '<a:tungsten_success:1567242523468890274> Autorole Removed',
              description: `Successfully removed ${role} from **${isBotTarget ? 'bot' : 'human'}** autoroles.`
            })
          ]
        });
      }
    }

    return message.reply(`Usage: \`${prefix}autorole <humans|bots|config|reset|panel> [add|remove] [role]\``);
  },

  getAutoroleData,
  saveAutoroleData,
  buildAutoroleStudio
};
