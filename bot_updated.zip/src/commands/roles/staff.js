/**
 * Staff Shortcut Command (Node.js)
 */
const { staff } = require('./customRoleShortcuts');
module.exports = staff;
