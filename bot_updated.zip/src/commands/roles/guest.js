/**
 * Guest Shortcut Command (Node.js)
 */
const { guest } = require('./customRoleShortcuts');
module.exports = guest;
