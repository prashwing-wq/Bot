/**
 * Friend Shortcut Command (Node.js)
 */
const { friend } = require('./customRoleShortcuts');
module.exports = friend;
