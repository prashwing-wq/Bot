/**
 * VIP Shortcut Command (Node.js)
 */
const { vip } = require('./customRoleShortcuts');
module.exports = vip;
