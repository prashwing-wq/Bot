/**
 * RoleIcon Command (Node.js)
 * Set, update, or remove the custom icon of a server role.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'roleicon',
  aliases: ['setroleicon'],
  category: 'roles',
  description: 'Set, update, or remove the custom icon for a server role.',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  usage: '<@role|id> <emoji | image_url | none>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.DANGER || 0xED4245,
            title: 'Permission Denied',
            description: 'You need the `Manage Roles` permission to edit role icons.'
          })
        ]
      });
    }

    if (!args[0]) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}roleicon <@role|id> <emoji | image_url | none>\``);
    }

    const role = message.mentions?.roles?.first() ||
      message.guild.roles.cache.get(args[0]) ||
      message.guild.roles.cache.find(r => r.name.toLowerCase() === args[0].toLowerCase());

    if (!role) {
      return message.reply('<a:tungsten_close:1567234632905138206> Role not found. Please provide a valid role mention or ID.');
    }

    const me = message.guild.members.me;
    if (role.position >= me.roles.highest.position) {
      return message.reply(`<a:tungsten_close:1567234632905138206> I cannot modify ${role} because it is positioned higher than or equal to my highest role.`);
    }

    if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
      return message.reply(`<a:tungsten_close:1567234632905138206> You cannot modify ${role} because it is positioned higher than or equal to your highest role.`);
    }

    const input = args[1]?.trim();
    if (!input || input.toLowerCase() === 'none' || input.toLowerCase() === 'reset' || input.toLowerCase() === 'remove') {
      try {
        await role.setIcon(null, `Role icon removed by ${message.author.tag}`);
        return message.reply({
          embeds: [
            createEmbed({
              color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
              title: '<a:tungsten_success:1567242523468890274> Role Icon Removed',
              description: `Successfully removed icon from ${role}.`
            })
          ]
        });
      } catch (e) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to remove role icon: ${e.message}`);
      }
    }

    // Check if input is a direct image URL or attachment
    const attachmentUrl = message.attachments?.first()?.url;
    const targetUrl = attachmentUrl || (input.startsWith('http') ? input : null);

    try {
      if (targetUrl) {
        await role.setIcon(targetUrl, `Role icon updated by ${message.author.tag}`);
        return message.reply({
          embeds: [
            createEmbed({
              color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
              title: '<a:tungsten_success:1567242523468890274> Role Icon Updated',
              description: `Successfully updated icon for ${role}.`,
              thumbnail: { url: targetUrl }
            })
          ]
        });
      }

      // Check custom emoji <:name:id>
      const customMatch = input.match(/<a?:[a-zA-Z0-9_]+:(\d+)>/);
      if (customMatch) {
        const emojiUrl = `https://cdn.discordapp.com/emojis/${customMatch[1]}.png`;
        await role.setIcon(emojiUrl, `Role icon updated by ${message.author.tag}`);
        return message.reply({
          embeds: [
            createEmbed({
              color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
              title: '<a:tungsten_success:1567242523468890274> Role Icon Updated',
              description: `Successfully updated icon for ${role} with emoji ${input}.`,
              thumbnail: { url: emojiUrl }
            })
          ]
        });
      }

      // Standard unicode emoji
      await role.setUnicodeEmoji(input, `Role unicode emoji set by ${message.author.tag}`);
      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
            title: '<a:tungsten_success:1567242523468890274> Role Emoji Updated',
            description: `Successfully set emoji **${input}** for ${role}.`
          })
        ]
      });
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to update role icon: ${e.message}\n-# Note: Server must be Level 2+ Boosted for custom image role icons, or standard unicode emoji can be used.`);
    }
  }
};
