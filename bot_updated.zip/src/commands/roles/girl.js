/**
 * Girl Shortcut Command (Node.js)
 */
const { girl } = require('./customRoleShortcuts');
module.exports = girl;
