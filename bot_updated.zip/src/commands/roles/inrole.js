/**
 * In-Role Member Inspection Command (Node.js)
 * Lists all server members who have been assigned a specific role.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'inrole',
  aliases: ['membersinrole', 'rolemembers'],
  category: 'roles',
  description: 'View and count members assigned to a specific role.',
  usage: '<@role | role_id | name>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!args[0]) return message.reply(`Usage: \`${prefix}inrole <@role>\``);

    const role = message.mentions?.roles?.first() ||
                 message.guild.roles.cache.get(args[0]) ||
                 message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLowerCase());

    if (!role) return message.reply('<a:tungsten_close:1567234632905138206> Role not found. Please provide a valid role mention, ID, or name.');

    const members = role.members;
    const memberList = members.size > 0
      ? members.map(m => `• <@${m.id}> (\`${m.user.username}\`)`).slice(0, 30).join('\n')
      : '*No members currently hold this role.*';

    const embed = createEmbed({
      color: role.color || undefined,
      title: `🎭  Members with @${role.name}`,
      description:
        `> **Total Assigned Members:** **${members.size}**\n\n` +
        memberList +
        (members.size > 30 ? `\n\n*...and ${members.size - 30} more members.*` : ''),
      footer: { text: `Role ID: ${role.id}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
