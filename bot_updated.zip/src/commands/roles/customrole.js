/**
 * Custom Roles Management Command (Node.js)
 * Quick-assignment presets for Staff, VIP, Girl, Guest, and Friend roles.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { getSetupRole, setSetupRole } = require('./setup');

module.exports = {
  name: 'customrole',
  aliases: ['cr', 'crole', 'specialrole'],
  category: 'roles',
  description: 'Quick-assign designated VIP, Staff, Girl, Guest, or Friend roles to members.',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  usage: '[setup <type> <@role> | <staff|girl|vip|guest|friend> <@user> | config]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Roles` permission to manage custom roles.');
    }

    const sub = args[0]?.toLowerCase() || 'config';

    const TYPES = ['staff', 'girl', 'vip', 'guest', 'friend'];

    // 1. Setup a specific role type
    if (sub === 'setup' && args[1]) {
      const type = args[1].toLowerCase();
      if (!TYPES.includes(type)) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Invalid custom role type. Valid types: ${TYPES.map(t => `\`${t}\``).join(', ')}`);
      }

      const role = message.mentions?.roles?.first() || message.guild.roles.cache.get(args[2]);
      if (!role) return message.reply(`Usage: \`${prefix}customrole setup ${type} @Role\``);

      setSetupRole(message.guild.id, type, role.id);

      return message.reply(`<a:tungsten_success:1567242523468890274> Designated ${role} as the server's **${type.toUpperCase()}** role.`);
    }

    // 2. Direct Assign/Remove for a type
    if (TYPES.includes(sub)) {
      const target = message.mentions?.members?.first() || (args[1] ? await message.guild.members.fetch(args[1]).catch(() => null) : null);
      if (!target) return message.reply(`Usage: \`${prefix}customrole ${sub} <@user>\``);

      const roleId = getSetupRole(message.guild.id, sub);
      if (!roleId) {
        return message.reply(`<a:tungsten_close:1567234632905138206> The \`${sub}\` role has not been configured yet. Use \`${prefix}customrole setup ${sub} @Role\` first.`);
      }

      const role = message.guild.roles.cache.get(roleId);
      if (!role) return message.reply('<a:tungsten_close:1567234632905138206> The designated role no longer exists in this server.');

      if (message.guild.members.me.roles.highest.position <= role.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot manage this role because it is higher than or equal to my highest role.');
      }

      const hasRole = target.roles.cache.has(role.id);
      if (hasRole) {
        await target.roles.remove(role, `[CustomRole] Removed by ${message.author.tag}`);
        return message.reply(`<a:tungsten_trash:1567242891276062872> Removed ${role} from ${target}.`);
      } else {
        await target.roles.add(role, `[CustomRole] Assigned by ${message.author.tag}`);
        return message.reply(`✨ Assigned ${role} to ${target}!`);
      }
    }

    // 3. Configuration overview
    const configList = [];
    for (const t of TYPES) {
      const roleId = getSetupRole(message.guild.id, t);
      const roleMention = roleId ? `<@&${roleId}>` : '`Not configured`';
      configList.push(`• **${t.toUpperCase()}:** ${roleMention}`);
    }

    const embed = createEmbed({
      title: `🎭  Custom Roles Directory • ${message.guild.name}`,
      description:
        `> Quick-assignment shortcuts for popular member roles.\n\n` +
        configList.join('\n') +
        `\n\n**Setup Commands:**\n` +
        `• \`${prefix}customrole setup <staff|vip|girl|guest|friend> @Role\`\n` +
        `• \`${prefix}customrole <type> @user\` — Toggle role on user`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
