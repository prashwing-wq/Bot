/**
 * Custom Role Shortcuts Engine (Node.js)
 * Quick-assignment toggle commands for Staff, Girl, Friend, VIP, and Guest roles.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { getSetupRole } = require('./setup');

async function toggleShortcutRole(roleKey, displayName, message, args, client, prefix) {
  if (!message.guild) return;

  if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
    return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Roles` permission to toggle this role.');
  }

  const target = message.mentions?.members?.first() ||
    (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : null);

  if (!target) {
    return message.reply(`Usage: \`${prefix}${roleKey} <@user|id>\``);
  }

  const roleId = getSetupRole(message.guild.id, roleKey);
  if (!roleId) {
    return message.reply(
      `<a:tungsten_close:1567234632905138206> The \`${roleKey}\` role has not been configured yet. Use \`${prefix}setup ${roleKey} @Role\` first.`
    );
  }

  const role = message.guild.roles.cache.get(roleId);
  if (!role) {
    return message.reply('<a:tungsten_close:1567234632905138206> The designated role no longer exists in this server.');
  }

  if (message.guild.members.me.roles.highest.position <= role.position) {
    return message.reply('<a:tungsten_close:1567234632905138206> I cannot manage this role because it is higher than or equal to my highest role.');
  }

  if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId && !isOwner(message.author.id)) {
    return message.reply('<a:tungsten_close:1567234632905138206> You cannot manage this role because it is higher than or equal to your highest role.');
  }

  const hasRole = target.roles.cache.has(role.id);
  if (hasRole) {
    await target.roles.remove(role, `[Shortcut Role] Removed by ${message.author.tag}`);
    return message.reply({
      embeds: [
        createEmbed({
          color: client.config?.COLORS?.WARNING || 0xfaa61a,
          title: '<a:tungsten_trash:1567242891276062872> Role Removed',
          description: `Removed ${role} from ${target}.`
        })
      ]
    });
  } else {
    await target.roles.add(role, `[Shortcut Role] Assigned by ${message.author.tag}`);
    return message.reply({
      embeds: [
        createEmbed({
          color: client.config?.COLORS?.SUCCESS || 0x43b581,
          title: '<a:tungsten_success:1567242523468890274> Role Assigned',
          description: `Assigned ${role} to ${target}!`
        })
      ]
    });
  }
}

function createShortcutCommand(roleKey, displayName) {
  return {
    name: roleKey,
    category: 'roles',
    description: `Quick-toggle designated ${displayName} role on a member.`,
    permissions: ['ManageRoles'],
    botPermissions: ['ManageRoles'],
    usage: '<@user|id>',
    cooldown: 3,
    async execute(message, args, client, prefix) {
      return toggleShortcutRole(roleKey, displayName, message, args, client, prefix);
    }
  };
}

const staff = createShortcutCommand('staff', 'Staff');
const girl = createShortcutCommand('girl', 'Girl');
const friend = createShortcutCommand('friend', 'Friend');
const vip = createShortcutCommand('vip', 'VIP');
const guest = createShortcutCommand('guest', 'Guest');

module.exports = {
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  toggleShortcutRole,
  createShortcutCommand,
  staff,
  girl,
  friend,
  vip,
  guest
};
