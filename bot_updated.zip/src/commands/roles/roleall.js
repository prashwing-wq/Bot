/**
 * Roleall Command (Node.js)
 * Mass assign or remove a role across all server members, humans, or bots
 * with strict hierarchy enforcement and rate-limit safe batch processing.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, isOwner, isServerOwner, createEmbed } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  name: 'roleall',
  aliases: ['massrole', 'allrole', 'roleallmembers'],
  category: 'roles',
  description: 'Mass add or remove a role for all members, humans, or bots.',
  usage: 'roleall [add|remove] <all|humans|bots> <@role|name|id>',
  cooldown: 10,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    // 1. Permissions Check
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Roles` permission to use this command.'
          })
        ]
      });
    }

    if (!args[0]) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Missing Arguments',
            description:
              `**Usage:**\n` +
              `• \`${prefix}roleall <all|humans|bots> <@role|name|id>\` (Mass add)\n` +
              `• \`${prefix}roleall add <all|humans|bots> <@role|name|id>\`\n` +
              `• \`${prefix}roleall remove <all|humans|bots> <@role|name|id>\``
          })
        ]
      });
    }

    // 2. Parse Operation and Target Filter
    let op = 'add';
    let targetScope = 'all';
    let roleQuery = '';

    const first = args[0].toLowerCase();
    if (first === 'add' || first === 'give') {
      op = 'add';
      targetScope = (args[1] || 'all').toLowerCase();
      roleQuery = args.slice(2).join(' ');
    } else if (first === 'remove' || first === 'take') {
      op = 'remove';
      targetScope = (args[1] || 'all').toLowerCase();
      roleQuery = args.slice(2).join(' ');
    } else if (['all', 'humans', 'bots', 'users', 'members'].includes(first)) {
      op = 'add';
      targetScope = first;
      roleQuery = args.slice(1).join(' ');
    } else {
      targetScope = 'all';
      roleQuery = args.join(' ');
    }

    if (targetScope === 'users' || targetScope === 'members') targetScope = 'humans';
    if (!['all', 'humans', 'bots'].includes(targetScope)) {
      roleQuery = `${targetScope} ${roleQuery}`.trim();
      targetScope = 'all';
    }

    if (!roleQuery) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Role Required',
            description: `Please specify the role you wish to ${op} for \`${targetScope}\` members.`
          })
        ]
      });
    }

    // 3. Resolve Target Role
    const role = message.mentions?.roles?.first() ||
      message.guild.roles.cache.get(roleQuery.replace(/[<@&>]/g, '')) ||
      message.guild.roles.cache.find(r => r.name.toLowerCase() === roleQuery.toLowerCase()) ||
      message.guild.roles.cache.find(r => r.name.toLowerCase().includes(roleQuery.toLowerCase()));

    if (!role) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Role Not Found',
            description: `Could not locate a role matching \`${roleQuery}\`.`
          })
        ]
      });
    }

    // 4. Hierarchy and Safety Checks
    if (role.id === message.guild.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> Cannot mass assign or remove the `@everyone` role.');
    }

    if (role.managed) {
      return message.reply('<a:tungsten_close:1567234632905138206> Cannot manage this role because it is managed by an integration or bot.');
    }

    const botMember = message.guild.members.me || await message.guild.members.fetchMe().catch(() => null);
    if (!botMember || role.position >= botMember.roles.highest.position) {
      return message.reply(`<a:tungsten_close:1567234632905138206> I cannot ${op} ${role} because it is higher than or equal to my highest role.`);
    }

    const isAuthorizedOwner = isServerOwner(message.guild, message.author.id) || isOwner(message.author.id);
    if (!isAuthorizedOwner && role.position >= message.member.roles.highest.position) {
      return message.reply(`<a:tungsten_close:1567234632905138206> You cannot ${op} ${role} because it is higher than or equal to your highest role.`);
    }

    // 5. Fetch and Filter Members
    const initialStatus = await message.reply({
      embeds: [
        createEmbed({
          color: 0x5865F2,
          title: '🔄  Scanning Server Members...',
          description: `Gathering and filtering members for target scope: **${targetScope.toUpperCase()}**...`
        })
      ]
    });

    let allMembers;
    try {
      allMembers = await message.guild.members.fetch();
    } catch (_) {
      allMembers = message.guild.members.cache;
    }

    const targets = allMembers.filter(m => {
      if (targetScope === 'humans' && m.user.bot) return false;
      if (targetScope === 'bots' && !m.user.bot) return false;
      const hasRole = m.roles.cache.has(role.id);
      return op === 'add' ? !hasRole : hasRole;
    });

    const targetCount = targets.size;
    if (targetCount === 0) {
      return initialStatus.edit({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'No Members to Update',
            description: op === 'add'
              ? `All **${targetScope}** already have the ${role} role.`
              : `None of the **${targetScope}** have the ${role} role.`
          })
        ]
      });
    }

    // 6. Execute Batch Operation
    const opVerb = op === 'add' ? 'Granting' : 'Removing';
    await initialStatus.edit({
      embeds: [
        createV2Card({
          color: 0x5865F2,
          title: `⚡  Mass Role ${op === 'add' ? 'Assignment' : 'Revocation'} in Progress`,
          description:
            `> **Role:** ${role} (\`${role.id}\`)\n` +
            `> **Scope:** \`${targetScope.toUpperCase()}\`\n` +
            `> **Queue Size:** \`${targetCount}\` members\n\n` +
            `<a:tungsten_loading:1567241050567876698> ${opVerb} role across eligible members. This will run with safe rate-limit throttling...`
        })
      ]
    });

    let successCount = 0;
    let failCount = 0;

    for (const [, member] of targets) {
      try {
        if (op === 'add') {
          await member.roles.add(role.id, `Mass role added by ${message.author.tag}`);
        } else {
          await member.roles.remove(role.id, `Mass role removed by ${message.author.tag}`);
        }
        successCount++;
      } catch (err) {
        failCount++;
      }
      // Small sleep (50ms) to prevent Gateway and REST queue throttling
      if (targetCount > 10) {
        await new Promise(r => setTimeout(r, 60));
      }
    }

    // 7. Render Final Report
    const completionCard = createV2Card({
      color: client.config.COLORS.SUCCESS,
      title: `<a:tungsten_tick:1567242779908636802>  Mass Role Operation Complete`,
      description:
        `> **Target Role:** ${role} (\`${role.id}\`)\n` +
        `> **Scope:** \`${targetScope.toUpperCase()}\`\n` +
        `> **Action:** \`${op.toUpperCase()}\`\n\n` +
        `• <a:tungsten_success:1567242523468890274> **Successfully Updated:** \`${successCount}\` member(s)\n` +
        (failCount > 0 ? `• <a:tungsten_warn:1567246685082746940> **Failed / Skipped:** \`${failCount}\` member(s)\n` : '') +
        `• ⏱️ **Moderator:** ${message.author} (\`${message.author.id}\`)`
    });

    return initialStatus.edit({ embeds: [completionCard] }).catch(() => null);
  }
};
