/**
 * Removerole Command
 * Remove a role from a member with hierarchy protection
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'removerole',
  description: 'Remove a role from a server member.',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  category: 'roles',
  usage: 'removerole <@member|id> <@role|name|id>',
  aliases: ['takerole', 'roledel'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Manage Roles` permission to remove roles.'
          })
        ]
      });
    }

    if (args.length < 2) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Missing Arguments',
            description: `**Usage:** \`${prefix}removerole <@member|id> <@role|name|id>\``
          })
        ]
      });
    }

    const member = message.mentions?.members?.first() ||
      await message.guild.members.fetch(args[0]).catch(() => null);

    if (!member) return message.reply('Member not found.');

    const roleQuery = args.slice(1).join(' ').toLowerCase();
    const role = message.mentions?.roles?.first() ||
      message.guild.roles.cache.get(args[1]) ||
      message.guild.roles.cache.find(r => r.name.toLowerCase() === roleQuery);

    if (!role) return message.reply('Role not found.');

    if (role.position >= message.guild.members.me.roles.highest.position) {
      return message.reply(`I cannot remove ${role} because it is higher than or equal to my highest role.`);
    }

    if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
      return message.reply(`You cannot remove ${role} because it is higher than or equal to your highest role.`);
    }

    if (!member.roles.cache.has(role.id)) {
      return message.reply(`${member} does not have the ${role} role.`);
    }

    try {
      await member.roles.remove(role, `Role removed by ${message.author.tag}`);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_success:1567242523468890274> Role Removed',
            description: `Successfully removed ${role} from ${member}.`
          })
        ]
      });
    } catch (e) {
      return message.reply(`Failed to remove role: ${e.message}`);
    }
  }
};
