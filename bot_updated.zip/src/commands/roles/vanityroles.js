/**
 * Vanity Roles Command (Node.js)
 * Configure Vanity URL reward role for members displaying server invite in their status.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

function ensureVanityTable(sdb) {
  sdb.exec(`
    CREATE TABLE IF NOT EXISTS vanity_roles (
      guild_id TEXT PRIMARY KEY,
      vanity_string TEXT,
      role_id TEXT,
      channel_id TEXT
    );
  `);
}

function getVanityRole(guildId) {
  const sdb = getServerDb(guildId);
  ensureVanityTable(sdb);
  return sdb.prepare('SELECT guild_id, vanity_string, role_id, channel_id FROM vanity_roles WHERE guild_id = ?')
    .get(String(guildId)) || null;
}

function setVanityRole(guildId, vanityString, roleId, channelId = null) {
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  ensureVanityTable(sdb);

  sdb.prepare(`
    INSERT OR REPLACE INTO vanity_roles (guild_id, vanity_string, role_id, channel_id)
    VALUES (?, ?, ?, ?)
  `).run(gid, String(vanityString).trim(), String(roleId), channelId ? String(channelId) : null);
}

function resetVanityRole(guildId) {
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  ensureVanityTable(sdb);

  return sdb.prepare('DELETE FROM vanity_roles WHERE guild_id = ?').run(gid);
}

async function checkMemberVanity(member, customStatusText = null) {
  if (!member || !member.guild || member.user?.bot) return false;
  const config = getVanityRole(member.guild.id);
  if (!config || !config.vanity_string || !config.role_id) return false;

  const role = member.guild.roles.cache.get(config.role_id);
  if (!role) return false;

  // Determine status text
  let statusText = customStatusText;
  if (!statusText && member.presence?.activities) {
    const customAct = member.presence.activities.find(a => a.type === 4); // 4 = CustomStatus
    statusText = [customAct?.state, customAct?.name].filter(Boolean).join(' ');
  }

  const hasVanityInStatus = statusText && statusText.toLowerCase().includes(config.vanity_string.toLowerCase());
  const hasRole = member.roles.cache.has(role.id);

  if (hasVanityInStatus && !hasRole) {
    if (member.guild.members.me?.roles.highest.position > role.position) {
      await member.roles.add(role, `[Vanity Reward] Status contains ${config.vanity_string}`).catch(() => null);
      if (config.channel_id) {
        const channel = member.guild.channels.cache.get(config.channel_id);
        if (channel && channel.isTextBased()) {
          channel.send({
            content: `🎉 Congratulations <@${member.id}>! You added \`${config.vanity_string}\` to your status and received the **${role.name}** role!`
          }).catch(() => null);
        }
      }
      return true;
    }
  } else if (!hasVanityInStatus && hasRole) {
    if (member.guild.members.me?.roles.highest.position > role.position) {
      await member.roles.remove(role, `[Vanity Reward] Removed ${config.vanity_string} from status`).catch(() => null);
      return true;
    }
  }

  return false;
}

module.exports = {
  name: 'vanityroles',
  aliases: ['vanityrole', 'vanity', 'vanityreward'],
  category: 'roles',
  description: 'Configure Vanity URL reward role.',
  permissions: ['ManageGuild'],
  botPermissions: ['ManageRoles'],
  usage: '[config|setup|reset] [vanity_text] [@role] [#channel]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure vanity roles.');
    }

    const sub = args[0]?.toLowerCase() || 'config';

    // 1. Reset vanity configuration
    if (sub === 'reset') {
      resetVanityRole(message.guild.id);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x43b581,
            title: '<a:tungsten_sweep:1567242656281657414> Vanity Role Reset',
            description: 'Vanity reward role configuration has been cleared for this server.'
          })
        ]
      });
    }

    // 2. Setup vanity reward: vanityroles setup <vanity_text> <@role> [#channel]
    if (sub === 'setup') {
      const vanityText = args[1]?.trim();
      if (!vanityText) {
        return message.reply(`Usage: \`${prefix}vanityroles setup <vanity_text> <@role> [#channel]\``);
      }

      const roleArg = args[2];
      const role = message.mentions?.roles?.first() ||
        (roleArg ? message.guild.roles.cache.get(roleArg.replace(/[<@&>]/g, '')) : null) ||
        (roleArg ? message.guild.roles.cache.find(r => r.name.toLowerCase() === roleArg.toLowerCase()) : null);

      if (!role) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please specify a valid role (mention or role ID).');
      }

      if (role.id === message.guild.id) {
        return message.reply('<a:tungsten_close:1567234632905138206> The `@everyone` role cannot be configured as a vanity reward.');
      }

      if (message.guild.members.me.roles.highest.position <= role.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot manage this role because it is higher than or equal to my highest role.');
      }

      if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId && !isOwner(message.author.id)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You cannot configure this role because it is higher than or equal to your highest role.');
      }

      const channelArg = args[3];
      const channel = message.mentions?.channels?.first() ||
        (channelArg ? message.guild.channels.cache.get(channelArg.replace(/[<#>]/g, '')) : null);

      setVanityRole(message.guild.id, vanityText, role.id, channel?.id || null);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x43b581,
            title: '<a:tungsten_success:1567242523468890274> Vanity Role Configured',
            description:
              `Members with \`${vanityText}\` in their status will automatically be granted ${role}.\n\n` +
              `• **Vanity String:** \`${vanityText}\`\n` +
              `• **Reward Role:** ${role}\n` +
              `• **Notification Channel:** ${channel ? `<#${channel.id}>` : '*Disabled*'}`
          })
        ]
      });
    }

    // 3. Config overview (default)
    const config = getVanityRole(message.guild.id);
    if (!config || !config.role_id) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.PRIMARY || 0x5865f2,
            title: `🔗  Vanity Role Configuration • ${message.guild.name}`,
            description:
              `> Reward members who display your custom invite URL in their Discord custom status.\n\n` +
              `*No Vanity Reward role is currently configured.*\n\n` +
              `**Configuration Commands:**\n` +
              `• \`${prefix}vanityroles setup <vanity_string> <@role> [#channel]\`\n` +
              `• \`${prefix}vanityroles reset\` — Clear configuration`,
            footerText: `Tungsten Vanity Engine • ${message.guild.name}`
          })
        ]
      });
    }

    const role = message.guild.roles.cache.get(config.role_id);
    const roleStr = role ? `<@&${role.id}> (\`${role.name}\`)` : `\`Deleted Role (${config.role_id})\``;
    const channel = config.channel_id ? message.guild.channels.cache.get(config.channel_id) : null;
    const chStr = channel ? `<#${channel.id}>` : (config.channel_id ? `\`#${config.channel_id}\`` : '*Disabled*');

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config?.COLORS?.PRIMARY || 0x5865f2,
          title: `🔗  Vanity Role Configuration • ${message.guild.name}`,
          description:
            `> Reward members who display your custom invite URL in their Discord custom status.\n\n` +
            `• **Vanity String:** \`${config.vanity_string}\`\n` +
            `• **Reward Role:** ${roleStr}\n` +
            `• **Notification Channel:** ${chStr}\n\n` +
            `**Management Commands:**\n` +
            `• \`${prefix}vanityroles setup <vanity_string> <@role> [#channel]\`\n` +
            `• \`${prefix}vanityroles reset\` — Clear configuration`,
          footerText: `Tungsten Vanity Engine • ${message.guild.name}`
        })
      ]
    });
  },

  getVanityRole,
  setVanityRole,
  resetVanityRole,
  checkMemberVanity
};
