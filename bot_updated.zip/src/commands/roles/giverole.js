/**
 * Giverole Command
 * Grant a role to a member with hierarchy protection
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'giverole',
  description: 'Assign a role to a server member.',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  category: 'roles',
  usage: 'giverole <@member|id> <@role|name|id>',
  aliases: ['addrole', 'roleadd'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Manage Roles` permission to assign roles.'
          })
        ]
      });
    }

    if (args.length < 2) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Missing Arguments',
            description: `**Usage:** \`${prefix}giverole <@member|id> <@role|name|id>\``
          })
        ]
      });
    }

    const member = message.mentions?.members?.first() ||
      await message.guild.members.fetch(args[0]).catch(() => null);

    if (!member) return message.reply('Member not found.');

    const roleQuery = args.slice(1).join(' ').toLowerCase();
    const role = message.mentions?.roles?.first() ||
      message.guild.roles.cache.get(args[1]) ||
      message.guild.roles.cache.find(r => r.name.toLowerCase() === roleQuery);

    if (!role) return message.reply('Role not found.');

    if (role.position >= message.guild.members.me.roles.highest.position) {
      return message.reply(`I cannot assign ${role} because it is higher than or equal to my highest role.`);
    }

    if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
      return message.reply(`You cannot assign ${role} because it is higher than or equal to your highest role.`);
    }

    if (member.roles.cache.has(role.id)) {
      return message.reply(`${member} already possesses the ${role} role.`);
    }

    try {
      await member.roles.add(role, `Role assigned by ${message.author.tag}`);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_success:1567242523468890274> Role Granted',
            description: `Successfully gave ${role} to ${member}.`
          })
        ]
      });
    } catch (e) {
      return message.reply(`Failed to assign role: ${e.message}`);
    }
  }
};
