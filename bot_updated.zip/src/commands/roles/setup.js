/**
 * Setup Custom Shortcut Roles Command (Node.js)
 * Configure custom shortcut roles (staff, girl, friend, vip, guest, and custom named shortcuts).
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

const STANDARD_KEYS = ['staff', 'girl', 'friend', 'vip', 'guest'];

function ensureSetupTable(sdb) {
  sdb.exec(`
    CREATE TABLE IF NOT EXISTS custom_setup_roles (
      guild_id TEXT NOT NULL,
      role_key TEXT NOT NULL,
      role_id TEXT NOT NULL,
      PRIMARY KEY (guild_id, role_key)
    );
    CREATE INDEX IF NOT EXISTS idx_custom_setup_roles_guild ON custom_setup_roles (guild_id);
  `);
}

function resolveRole(guild, input, message) {
  if (message?.mentions?.roles?.first()) {
    return message.mentions.roles.first();
  }
  if (!input) return null;
  const match = input.match(/\d{17,20}/);
  if (match) {
    const role = guild.roles.cache.get(match[0]);
    if (role) return role;
  }
  const clean = input.toLowerCase().trim();
  return guild.roles.cache.find(r => r.name.toLowerCase() === clean) || null;
}

function getSetupRole(guildId, roleKey) {
  const sdb = getServerDb(guildId);
  ensureSetupTable(sdb);
  const row = sdb.prepare('SELECT role_id FROM custom_setup_roles WHERE guild_id = ? AND role_key = ?')
    .get(String(guildId), String(roleKey).toLowerCase());
  if (row?.role_id) return row.role_id;

  // Fallback to server_settings for legacy compatibility
  const fallback = sdb.prepare('SELECT value FROM server_settings WHERE key = ?')
    .get(`crole_${String(roleKey).toLowerCase()}`);
  return fallback?.value || null;
}

function getAllSetupRoles(guildId) {
  const sdb = getServerDb(guildId);
  ensureSetupTable(sdb);
  return sdb.prepare('SELECT role_key, role_id FROM custom_setup_roles WHERE guild_id = ?')
    .all(String(guildId));
}

function setSetupRole(guildId, roleKey, roleId) {
  const gid = String(guildId);
  const key = String(roleKey).toLowerCase();
  const rid = String(roleId);
  const sdb = getServerDb(gid);
  ensureSetupTable(sdb);

  sdb.prepare('INSERT OR REPLACE INTO custom_setup_roles (guild_id, role_key, role_id) VALUES (?, ?, ?)')
    .run(gid, key, rid);

  // Sync to server_settings for backward compatibility
  try {
    sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)')
      .run(`crole_${key}`, rid);
  } catch (_) {}
}

function deleteSetupRole(guildId, roleKey) {
  const gid = String(guildId);
  const key = String(roleKey).toLowerCase();
  const sdb = getServerDb(gid);
  ensureSetupTable(sdb);

  const res = sdb.prepare('DELETE FROM custom_setup_roles WHERE guild_id = ? AND role_key = ?')
    .run(gid, key);

  try {
    sdb.prepare('DELETE FROM server_settings WHERE key = ?')
      .run(`crole_${key}`);
  } catch (_) {}

  return res.changes > 0;
}

function resetSetupRoles(guildId) {
  const gid = String(guildId);
  const sdb = getServerDb(gid);
  ensureSetupTable(sdb);

  sdb.prepare('DELETE FROM custom_setup_roles WHERE guild_id = ?').run(gid);
  try {
    sdb.prepare("DELETE FROM server_settings WHERE key LIKE 'crole_%'").run();
  } catch (_) {}
}

module.exports = {
  name: 'setup',
  aliases: ['setuprole', 'setuproles', 'role-setup', 'rolesetup'],
  category: 'roles',
  description: 'Configure custom shortcut roles (staff, girl, friend, vip, guest).',
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  usage: '[config|list|reset|create|delete|<staff|girl|friend|vip|guest>] [@role]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageRoles)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Roles` permission to configure shortcut roles.');
    }

    const sub = args[0]?.toLowerCase() || 'config';
    const sdb = getServerDb(message.guild.id);
    ensureSetupTable(sdb);

    // 1. Reset all shortcut roles
    if (sub === 'reset') {
      resetSetupRoles(message.guild.id);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x43b581,
            title: '<a:tungsten_sweep:1567242656281657414> Setup Roles Cleared',
            description: 'All configured custom shortcut roles have been cleared for this server.'
          })
        ]
      });
    }

    // 2. List all configured setup roles
    if (sub === 'list') {
      const rows = getAllSetupRoles(message.guild.id);
      if (!rows || rows.length === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config?.COLORS?.WARNING || 0xfaa61a,
              title: '📋 Setup Roles List',
              description: `*No shortcut roles are currently configured.*\n\nUse \`${prefix}setup <staff|girl|friend|vip|guest> @role\` or \`${prefix}setup create <name> @role\` to configure one.`
            })
          ]
        });
      }

      const listDesc = rows.map(r => {
        const role = message.guild.roles.cache.get(r.role_id);
        const mention = role ? `<@&${r.role_id}> (\`${role.name}\`)` : `\`Deleted Role (${r.role_id})\``;
        return `• **${r.role_key.toUpperCase()}**: ${mention}`;
      }).join('\n');

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.PRIMARY || 0x5865f2,
            title: `📋 Configured Setup Roles • ${message.guild.name}`,
            description: listDesc,
            footerText: `Total: ${rows.length} shortcut role(s)`
          })
        ]
      });
    }

    // 3. Create custom named shortcut: setup create <name> <@role>
    if (sub === 'create') {
      const name = args[1]?.toLowerCase();
      if (!name || !/^[a-z0-9_-]{2,32}$/.test(name)) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please provide a valid shortcut name (2-32 letters, digits, underscore, or dash).\nUsage: \`${prefix}setup create <name> <@role>\``);
      }

      const roleInput = args.slice(2).join(' ').trim();
      const role = resolveRole(message.guild, roleInput, message);
      if (!role) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid role (mention, name, or role ID).\nUsage: \`${prefix}setup create ${name} <@role>\``);
      }

      if (role.id === message.guild.id) {
        return message.reply('<a:tungsten_close:1567234632905138206> The `@everyone` role cannot be configured as a shortcut role.');
      }

      if (message.guild.members.me.roles.highest.position <= role.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot manage this role because it is higher than or equal to my highest role.');
      }

      if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId && !isOwner(message.author.id)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You cannot configure this role because it is higher than or equal to your highest role.');
      }

      setSetupRole(message.guild.id, name, role.id);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x43b581,
            title: '<a:tungsten_success:1567242523468890274> Custom Shortcut Created',
            description: `Successfully configured shortcut **${name.toUpperCase()}** to ${role}.`
          })
        ]
      });
    }

    // 4. Delete custom named shortcut: setup delete <name>
    if (sub === 'delete' || sub === 'del' || sub === 'remove') {
      const name = args[1]?.toLowerCase();
      if (!name) {
        return message.reply(`Usage: \`${prefix}setup delete <name>\``);
      }

      const deleted = deleteSetupRole(message.guild.id, name);
      if (!deleted) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Shortcut role **${name}** was not found.`);
      }

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x43b581,
            title: '<a:tungsten_trash:1567242891276062872> Shortcut Removed',
            description: `Successfully deleted custom shortcut **${name.toUpperCase()}**.`
          })
        ]
      });
    }

    // 5. Standard shortcut setters: setup <staff|girl|friend|vip|guest> <@role>
    if (STANDARD_KEYS.includes(sub)) {
      const roleInput = args.slice(1).join(' ').trim();
      const role = resolveRole(message.guild, roleInput, message);
      if (!role) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid role (mention, name, or role ID).\nUsage: \`${prefix}setup ${sub} <@role>\``);
      }

      if (role.id === message.guild.id) {
        return message.reply('<a:tungsten_close:1567234632905138206> The `@everyone` role cannot be configured as a shortcut role.');
      }

      if (message.guild.members.me.roles.highest.position <= role.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot manage this role because it is higher than or equal to my highest role.');
      }

      if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId && !isOwner(message.author.id)) {
        return message.reply('<a:tungsten_close:1567234632905138206> You cannot configure this role because it is higher than or equal to your highest role.');
      }

      setSetupRole(message.guild.id, sub, role.id);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config?.COLORS?.SUCCESS || 0x43b581,
            title: '<a:tungsten_success:1567242523468890274> Shortcut Role Configured',
            description: `Designated ${role} as the server's **${sub.toUpperCase()}** role shortcut.`
          })
        ]
      });
    }

    // 6. Config overview (default)
    const rows = getAllSetupRoles(message.guild.id);
    const roleMap = new Map();
    for (const r of rows) {
      roleMap.set(r.role_key.toLowerCase(), r.role_id);
    }

    // Include fallback from server_settings
    for (const k of STANDARD_KEYS) {
      if (!roleMap.has(k)) {
        const fb = getSetupRole(message.guild.id, k);
        if (fb) roleMap.set(k, fb);
      }
    }

    const standardOverview = STANDARD_KEYS.map(k => {
      const rid = roleMap.get(k);
      const role = rid ? message.guild.roles.cache.get(rid) : null;
      const mention = role ? `<@&${role.id}>` : (rid ? `\`Deleted (${rid})\`` : '*Not configured*');
      return `• **${k.charAt(0).toUpperCase() + k.slice(1)}:** ${mention}`;
    }).join('\n');

    // Custom non-standard shortcuts
    const customKeys = [...roleMap.keys()].filter(k => !STANDARD_KEYS.includes(k));
    const customOverview = customKeys.length > 0
      ? customKeys.map(k => {
          const rid = roleMap.get(k);
          const role = rid ? message.guild.roles.cache.get(rid) : null;
          const mention = role ? `<@&${role.id}>` : (rid ? `\`Deleted (${rid})\`` : '*Not configured*');
          return `• **${k.toUpperCase()}:** ${mention}`;
        }).join('\n')
      : null;

    let desc = `> Quick-assignment shortcuts allow staff to toggle preset roles with single-word commands.\n\n` +
      `**Standard Shortcut Roles:**\n${standardOverview}\n`;

    if (customOverview) {
      desc += `\n**Custom Named Shortcuts:**\n${customOverview}\n`;
    }

    desc += `\n**Configuration Commands:**\n` +
      `• \`${prefix}setup staff <@role>\` — Set staff role\n` +
      `• \`${prefix}setup girl <@role>\` — Set girl role\n` +
      `• \`${prefix}setup friend <@role>\` — Set friend role\n` +
      `• \`${prefix}setup vip <@role>\` — Set VIP role\n` +
      `• \`${prefix}setup guest <@role>\` — Set guest role\n` +
      `• \`${prefix}setup create <name> <@role>\` — Create custom shortcut\n` +
      `• \`${prefix}setup delete <name>\` — Remove shortcut\n` +
      `• \`${prefix}setup list\` — List all configured shortcuts\n` +
      `• \`${prefix}setup reset\` — Clear all shortcuts`;

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config?.COLORS?.PRIMARY || 0x5865f2,
          title: `🛠️  Custom Role Setup • ${message.guild.name}`,
          description: desc,
          footerText: `Tungsten Role Engine • ${message.guild.name}`
        })
      ]
    });
  },

  getSetupRole,
  getAllSetupRoles,
  setSetupRole,
  deleteSetupRole,
  resetSetupRoles,
  resolveRole
};
