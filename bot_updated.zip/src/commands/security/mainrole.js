/**
 * Main Staff Role Protection Command (Node.js)
 * Registers and protects key staff roles from unauthorized deletion, permission stripping, and tampering.
 */
const { PermissionsBitField, SlashCommandBuilder } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { EMOJIS } = require('../../utils/emojis');

function initMainRolesTable(sdb) {
  sdb.prepare(`
    CREATE TABLE IF NOT EXISTS main_roles (
      role_id TEXT PRIMARY KEY,
      created_at INTEGER
    )
  `).run();
}

module.exports = {
  name: 'mainrole',
  aliases: ['mainroles', 'staffrole', 'staffroles'],
  category: 'security',
  description: 'Manage protected main staff & backup roles.',
  usage: '[add <@role|id> | remove <@role|id> | list | reset]',
  cooldown: 3,
  permissions: ['Administrator'],
  botPermissions: ['ManageRoles'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            description: `${EMOJIS.ERROR} You need **Administrator** permission to manage main roles.`
          })
        ]
      });
    }

    const sdb = getServerDb(message.guild.id);
    initMainRolesTable(sdb);

    const sub = args[0]?.toLowerCase() || 'list';

    // ─────────────────────────────────────────────────────────────
    // 1. ADD SUBCOMMAND
    // ─────────────────────────────────────────────────────────────
    if (sub === 'add') {
      const raw = args[1];
      if (!raw) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.WARNING} Usage: \`${prefix}mainrole add <@role|role_id>\``
            })
          ]
        });
      }

      const roleId = raw.replace(/[<@&>]/g, '').trim();
      const role = message.guild.roles.cache.get(roleId);

      if (!role) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.ERROR} Could not find role with ID/mention \`${raw}\` in this server.`
            })
          ]
        });
      }

      if (role.id === message.guild.id) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.ERROR} You cannot designate the **@everyone** role as a protected main role.`
            })
          ]
        });
      }

      if (role.managed) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.ERROR} Bot integration / managed roles cannot be added to main staff roles.`
            })
          ]
        });
      }

      const exists = sdb.prepare('SELECT role_id FROM main_roles WHERE role_id = ?').get(role.id);
      if (exists) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xFEE75C,
              description: `${EMOJIS.WARNING} Role <@&${role.id}> is already registered as a protected main role.`
            })
          ]
        });
      }

      sdb.prepare('INSERT INTO main_roles (role_id, created_at) VALUES (?, ?)').run(role.id, Date.now());

      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SHIELD} Main Staff Role Protected`,
        description: `Successfully registered <@&${role.id}> (\`${role.name}\` • \`${role.id}\`) as a protected staff role.\n\n` +
          `• **Tamper Defense:** Automated position restoration & permission sentinel\n` +
          `• **Backup Tier:** High priority restoration during anti-nuke incidents`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. REMOVE SUBCOMMAND
    // ─────────────────────────────────────────────────────────────
    if (sub === 'remove' || sub === 'delete' || sub === 'del') {
      const raw = args[1];
      if (!raw) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.WARNING} Usage: \`${prefix}mainrole remove <@role|role_id>\``
            })
          ]
        });
      }

      const roleId = raw.replace(/[<@&>]/g, '').trim();
      const res = sdb.prepare('DELETE FROM main_roles WHERE role_id = ?').run(roleId);

      if (res.changes === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xFEE75C,
              description: `${EMOJIS.WARNING} Role <@&${roleId}> is not in the protected main roles list.`
            })
          ]
        });
      }

      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SUCCESS} Main Staff Role Unregistered`,
        description: `Role <@&${roleId}> (\`${roleId}\`) has been removed from protected main roles.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. RESET SUBCOMMAND
    // ─────────────────────────────────────────────────────────────
    if (sub === 'reset' || sub === 'clear') {
      sdb.prepare('DELETE FROM main_roles').run();
      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SUCCESS} Protected Main Roles Reset`,
        description: 'All configured protected main staff roles have been successfully cleared.'
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. LIST SUBCOMMAND (DEFAULT)
    // ─────────────────────────────────────────────────────────────
    const rows = sdb.prepare('SELECT role_id, created_at FROM main_roles ORDER BY created_at ASC').all();

    if (rows.length === 0) {
      const embed = createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.SHIELD} Protected Main Staff Roles`,
        description:
          `> No protected main staff roles are currently configured in this server.\n\n` +
          `• Register critical roles using \`${prefix}mainrole add <@role|id>\`\n` +
          `• Registered roles are shielded against deletion, privilege loss, and unauthorized modifications.`
      });
      return message.reply({ embeds: [embed] });
    }

    const lines = rows.map((r, i) => {
      const role = message.guild.roles.cache.get(r.role_id);
      const mention = role ? `<@&${r.role_id}>` : `\`[Deleted Role ${r.role_id}]\``;
      const roleName = role ? `• **${role.name}**` : '';
      return `\`${i + 1}.\` ${mention} ${roleName} (\`${r.role_id}\`)`;
    });

    const embed = createEmbed({
      color: 0x5865F2,
      title: `${EMOJIS.SHIELD} Protected Main Staff Roles (${rows.length})`,
      description:
        `> Staff roles actively guarded against unauthorized stripping or deletion.\n\n` +
        lines.join('\n') +
        `\n\n-# Total protected roles: \`${rows.length}\``
    });
    return message.reply({ embeds: [embed] });
  },

  slash: new SlashCommandBuilder()
    .setName('mainrole')
    .setDescription('Manage protected main staff & backup roles.')
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Add a role to protected main roles.')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to protect').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a role from protected main roles.')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all configured protected main roles.')
    )
    .addSubcommand(sub =>
      sub
        .setName('reset')
        .setDescription('Clear all configured protected main roles.')
    ),

  async executeSlash(interaction, client) {
    if (!interaction.guild) return;

    if (!hasPerm(interaction.member, PermissionsBitField.Flags.Administrator)) {
      return interaction.reply({
        content: `${EMOJIS.ERROR} You need **Administrator** permission to manage main roles.`,
        ephemeral: true
      });
    }

    const sdb = getServerDb(interaction.guild.id);
    initMainRolesTable(sdb);

    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const role = interaction.options.getRole('role');
      if (role.id === interaction.guild.id || role.managed) {
        return interaction.reply({
          content: `${EMOJIS.ERROR} Invalid role selection (managed or @everyone).`,
          ephemeral: true
        });
      }

      const exists = sdb.prepare('SELECT role_id FROM main_roles WHERE role_id = ?').get(role.id);
      if (exists) {
        return interaction.reply({
          content: `${EMOJIS.WARNING} Role <@&${role.id}> is already protected.`,
          ephemeral: true
        });
      }

      sdb.prepare('INSERT INTO main_roles (role_id, created_at) VALUES (?, ?)').run(role.id, Date.now());
      return interaction.reply({
        content: `${EMOJIS.SUCCESS} Successfully added <@&${role.id}> to protected main roles.`,
        ephemeral: true
      });
    }

    if (sub === 'remove') {
      const role = interaction.options.getRole('role');
      const res = sdb.prepare('DELETE FROM main_roles WHERE role_id = ?').run(role.id);
      if (res.changes === 0) {
        return interaction.reply({
          content: `${EMOJIS.WARNING} Role <@&${role.id}> is not in the protected list.`,
          ephemeral: true
        });
      }
      return interaction.reply({
        content: `${EMOJIS.SUCCESS} Successfully removed <@&${role.id}> from protected main roles.`,
        ephemeral: true
      });
    }

    if (sub === 'reset') {
      sdb.prepare('DELETE FROM main_roles').run();
      return interaction.reply({
        content: `${EMOJIS.SUCCESS} All protected main roles have been cleared.`,
        ephemeral: true
      });
    }

    // list
    const rows = sdb.prepare('SELECT role_id FROM main_roles ORDER BY created_at ASC').all();
    if (rows.length === 0) {
      return interaction.reply({
        content: 'No protected main roles configured.',
        ephemeral: true
      });
    }
    const lines = rows.map((r, i) => `\`${i + 1}.\` <@&${r.role_id}> (\`${r.role_id}\`)`);
    return interaction.reply({
      content: `**Protected Main Roles (${rows.length}):**\n${lines.join('\n')}`,
      ephemeral: true
    });
  }
};
