/**
 * Tungsten No-Prefix Authorization Hub & Studio (Node.js)
 * Manages authorized No-Prefix access globally, per-guild, and through appointed NP Managers.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { isOwner, isNoPrefix, isNpManager, refreshOwners, createEmbed, parseDuration, invalidateNoPrefixCache } = require('../../utils/tools');
const { getMasterDb, getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

function buildNpHubPayload(guild, author, prefix = '!') {
  const mdb = getMasterDb();
  const sdb = guild ? getServerDb(guild.id) : null;

  const globalUsers = mdb.prepare('SELECT user_id, added_at, expires_at FROM noprefix_users').all();
  const managers = mdb.prepare('SELECT user_id, added_at FROM np_managers').all();
  const serverUsers = sdb ? sdb.prepare('SELECT target_id, added_at FROM guild_noprefix_access WHERE guild_id = ?').all(String(guild.id)) : [];

  const botOwnersText = config.OWNER_IDS.map(id => `• <a:tungsten_shield:1567242104923627574> <@${id}> (\`${id}\`) — *Bot Developer / Super-Owner*`).join('\n');

  let mgrText = '*No NP Managers currently appointed.*';
  if (managers.length > 0) {
    mgrText = managers.map(m => `• <a:tungsten_refresh:1567241907116187658> <@${m.user_id}> (\`${m.user_id}\`) • Added <t:${m.added_at}:R>`).join('\n');
  }

  let globalText = '*No additional global no-prefix users designated.*';
  if (globalUsers.length > 0) {
    globalText = globalUsers.map(u => {
      const exp = (u.expires_at === null || u.expires_at === -1 || u.expires_at === undefined)
        ? '`Permanent ♾️`'
        : `<t:${u.expires_at}:R>`;
      return `• <@${u.user_id}> (\`${u.user_id}\`) • Expires: ${exp}`;
    }).join('\n');
  }

  let serverText = '*No server-level no-prefix users designated.*';
  if (serverUsers.length > 0) {
    serverText = serverUsers.map(u => `• <@${u.target_id}> (\`${u.target_id}\`) • Added <t:${u.added_at}:R>`).join('\n');
  }

  const card = createV2Card({
    color: 0x2b2d31,
    title: '<a:tungsten_refresh:1567241907116187658>  Tungsten No-Prefix Authorization Hub',
    description:
      `> Authorized members execute commands without typing the server prefix (\`${prefix}\`).\n\n` +
      `**<a:tungsten_shield:1567242104923627574> Primary Bot Owners (Permanent Full Access):**\n` +
      botOwnersText + '\n\n' +
      `**<a:tungsten_refresh:1567241907116187658> Appointed NP Managers [${managers.length}]:**\n` +
      mgrText + '\n\n' +
      `**🌐 Global No-Prefix Members [${globalUsers.length}]:**\n` +
      globalText + '\n\n' +
      `**🏰 Server-Level No-Prefix Members [${serverUsers.length}]:**\n` +
      serverText + '\n\n' +
      `**Quick Commands:**\n` +
      `• \`${prefix}np add <@user|id> [duration]\` — Grant no-prefix authorization\n` +
      `• \`${prefix}np remove <@user|id>\` — Revoke no-prefix authorization\n` +
      `• \`${prefix}np check <@user|id>\` — Inspect user no-prefix status\n` +
      `• \`${prefix}np manager\` — Open the NP Manager Studio`,
    footerText: `Tungsten Access Controller • Requested by ${author.username}`
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('np:btn_add')
      .setLabel('Add No-Prefix')
      .setStyle(ButtonStyle.Success)
      .setEmoji('<a:tungsten_success:1567242523468890274>'),
    new ButtonBuilder()
      .setCustomId('np:btn_remove')
      .setLabel('Remove No-Prefix')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('<a:tungsten_error:1567238753284653106>'),
    new ButtonBuilder()
      .setCustomId('np:btn_list')
      .setLabel('View List')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder()
      .setCustomId('np:btn_mgr_studio')
      .setLabel('NP Manager Studio')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder()
      .setCustomId('np:close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [card], components: [row] };
}

function buildNpManagerStudioPayload(author, prefix = '!') {
  const mdb = getMasterDb();
  const managers = mdb.prepare('SELECT user_id, added_at, added_by FROM np_managers').all();
  const totalNpCount = mdb.prepare('SELECT COUNT(*) as cnt FROM noprefix_users').get().cnt;

  const botOwnersText = config.OWNER_IDS.map(id => `• <a:tungsten_crown:1567238355463176334> <@${id}> (\`${id}\`) — *Bot Developer / Super-Owner*`).join('\n');

  let mgrListText = '*No NP Managers currently appointed. Only Master Bot Owners have access.*';
  if (managers.length > 0) {
    mgrListText = managers.map(m => `• <a:tungsten_shield:1567242104923627574> <@${m.user_id}> (\`${m.user_id}\`) • Appointed <t:${m.added_at}:R> by <@${m.added_by}>`).join('\n');
  }

  const desc =
    `> **NP Managers** possess elevated authority to grant, remove, and inspect No Prefix privileges globally.\n\n` +
    `### 📊 System Overview\n` +
    `• **Master Authorities**:\n` +
    botOwnersText + '\n' +
    `• **Active NP Managers**: \`${managers.length}\` appointed\n` +
    `• **Global No-Prefix Users**: \`${totalNpCount}\` active accounts\n\n` +
    `### <a:tungsten_shield:1567242104923627574> Appointed NP Managers\n` +
    mgrListText + '\n\n' +
    `**Management Commands:**\n` +
    `• \`${prefix}np manager add <@user|id>\` — Appoint an NP Manager\n` +
    `• \`${prefix}np manager remove <@user|id>\` — Revoke manager access\n` +
    `• \`${prefix}np manager list\` — List appointed managers`;

  const embed = createV2Card({
    color: 0x3498DB,
    title: '<a:tungsten_shield:1567242104923627574> Tungsten • NP Manager Studio',
    description: desc,
    footerText: `Tungsten Access Control Matrix • Executed by ${author.username}`
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('npm_btn_add')
      .setLabel('Add Manager')
      .setStyle(ButtonStyle.Success)
      .setEmoji('<a:tungsten_success:1567242523468890274>'),
    new ButtonBuilder()
      .setCustomId('npm_btn_remove')
      .setLabel('Remove Manager')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('<a:tungsten_error:1567238753284653106>'),
    new ButtonBuilder()
      .setCustomId('npm_btn_list')
      .setLabel('List All')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder()
      .setCustomId('npm_btn_refresh')
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder()
      .setCustomId('npm_btn_close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [embed], components: [row] };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'noprefix',
  aliases: ['np', 'no-prefix'],
  category: 'owner',
  ownerOnly: true,
  description: 'Manage authorized No-Prefix access for bot owners.',
  usage: '[add <@user|id> [duration] | remove <@user|id> | list | check <@user|id> | manager <add|remove|list|panel> | panel]',
  cooldown: 3,

  buildNpHubPayload,
  buildNpManagerStudioPayload,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('This command can be executed only by Bot Owner.');
    }

    const isBotOwner = true;
    const isManager = false;
    const isServerOwner = false;

    const sub = (args[0] || '').toLowerCase();
    const mdb = getMasterDb();
    const sdb = message.guild ? getServerDb(message.guild.id) : null;

    // ─────────────────────────────────────────────────────────────
    // 1. NP Manager Studio & Operations (!np manager ...)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'manager' || sub === 'mgr') {
      const mgrSub = (args[1] || 'panel').toLowerCase();

      // A. Add NP Manager (Bot Owner Only)
      if (mgrSub === 'add' || mgrSub === 'set') {
        if (!isBotOwner) {
          return message.reply('<a:tungsten_close:1567234632905138206> Only **Tungsten Bot Owners and Master Authorities** can manage NP Managers.');
        }

        const targetInput = args[2];
        if (!targetInput) {
          return message.reply(`Usage: \`${prefix}np manager add <@user|id>\``);
        }

        const cleanId = targetInput.replace(/[<@!>]/g, '');
        const targetUser = message.mentions?.users?.first() || (await client.users.fetch(cleanId).catch(() => null));
        if (!targetUser) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve \`${targetInput}\` to a valid user.`);
        }

        const now = Math.floor(Date.now() / 1000);
        mdb.prepare('INSERT OR REPLACE INTO np_managers (user_id, added_at, added_by) VALUES (?, ?, ?)')
          .run(String(targetUser.id), now, String(message.author.id));
        refreshOwners();

        const card = createV2Card({
          color: 0x2ECC71,
          title: '<a:tungsten_shield:1567242104923627574>  NP Manager Appointed',
          description:
            `> Successfully appointed <@${targetUser.id}> (\`${targetUser.id}\`) as a **Tungsten NP Manager**.\n\n` +
            `**Granted Privileges:**\n` +
            `• Global No-Prefix execution across all servers\n` +
            `• Authority to grant and revoke No-Prefix privileges (\`${prefix}np add\` / \`${prefix}np remove\`)\n` +
            `• Authority to inspect No-Prefix user telemetry\n\n` +
            `-# Appointed by <@${message.author.id}>`,
          footerText: `Tungsten Access Control Matrix`
        });

        try {
          targetUser.send({
            embeds: [
              createEmbed({
                color: 0x3498DB,
                title: '<a:tungsten_shield:1567242104923627574>  NP Manager Access Granted',
                description: `You have been appointed as a **Tungsten NP Manager** by <@${message.author.id}>.`
              })
            ]
          }).catch(() => null);
        } catch (e) {}

        return message.reply({ embeds: [card] });
      }

      // B. Remove NP Manager (Bot Owner Only)
      if (mgrSub === 'remove' || mgrSub === 'del' || mgrSub === 'delete' || mgrSub === 'rem') {
        if (!isBotOwner) {
          return message.reply('<a:tungsten_close:1567234632905138206> Only **Tungsten Bot Owners and Master Authorities** can manage NP Managers.');
        }

        const targetInput = args[2];
        if (!targetInput) {
          return message.reply(`Usage: \`${prefix}np manager remove <@user|id>\``);
        }

        const cleanId = targetInput.replace(/[<@!>]/g, '');
        const targetUser = message.mentions?.users?.first() || (await client.users.fetch(cleanId).catch(() => null));
        const targetId = targetUser ? targetUser.id : cleanId;

        mdb.prepare('DELETE FROM np_managers WHERE user_id = ?').run(String(targetId));
        refreshOwners();

        return message.reply(`<a:tungsten_success:1567242523468890274> Successfully revoked NP Manager privileges from <@${targetId}> (\`${targetId}\`).`);
      }

      // C. List NP Managers
      if (mgrSub === 'list' || mgrSub === 'show' || mgrSub === 'all') {
        const payload = buildNpManagerStudioPayload(message.author, prefix);
        return message.reply(payload);
      }

      // D. NP Manager Studio Panel
      const payload = buildNpManagerStudioPayload(message.author, prefix);
      return message.reply(payload);
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Add No-Prefix Access (!np add <@user|id> [duration])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'add' || sub === 'grant') {
      const targetInput = args[1];
      if (!targetInput) {
        return message.reply(`Usage: \`${prefix}np add <@user|id> [duration]\` (e.g. \`30d\`, \`lifetime\`)`);
      }

      const cleanId = targetInput.replace(/[<@!>]/g, '');
      const user = message.mentions?.users?.first() || (await client.users.fetch(cleanId).catch(() => null));
      if (!user) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve \`${targetInput}\` to a valid user.`);
      }

      const durInput = args[2] || 'lifetime';
      const parsedDur = parseDuration(durInput);
      if (!parsedDur) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Invalid duration: \`${durInput}\`. Example: \`30d\`, \`1w\`, or \`lifetime\`.`);
      }

      const now = Math.floor(Date.now() / 1000);
      const expiresAt = parsedDur.seconds <= 0 ? -1 : now + parsedDur.seconds;
      const durStr = expiresAt === -1 ? '`♾️ Lifetime Access`' : `<t:${expiresAt}:F> (<t:${expiresAt}:R>)`;

      // Bot owner grants Global No-Prefix
      mdb.prepare(`
        INSERT INTO noprefix_users (user_id, added_at, added_by, expires_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          added_at = excluded.added_at,
          added_by = excluded.added_by,
          expires_at = excluded.expires_at
      `).run(String(user.id), now, String(message.author.id), expiresAt);
      invalidateNoPrefixCache(user.id);

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_crown:1567238355463176334>  Global No-Prefix Granted',
        description:
          `> Successfully granted **Global No-Prefix** authorization to ${user}.\n\n` +
          `• **User:** <@${user.id}> (\`${user.id}\`)\n` +
          `• **Scope:** Global (Active across all servers)\n` +
          `• **Duration:** ${durStr}\n` +
          `• **Authorized By:** <@${message.author.id}> (\`Bot Owner\`)\n\n` +
          `-# Revoke anytime with \`${prefix}np remove <@${user.id}>\``,
        footerText: `Tungsten Global Security Matrix`
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Remove No-Prefix Access (!np remove <@user|id>)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'remove' || sub === 'del' || sub === 'revoke' || sub === 'rem') {
      const targetInput = args[1];
      if (!targetInput) {
        return message.reply(`Usage: \`${prefix}np remove <@user|id>\``);
      }

      const cleanId = targetInput.replace(/[<@!>]/g, '');
      const user = message.mentions?.users?.first() || (await client.users.fetch(cleanId).catch(() => null));
      const targetId = user ? user.id : cleanId;

      mdb.prepare('DELETE FROM noprefix_users WHERE user_id = ?').run(String(targetId));
      if (sdb) {
        sdb.prepare('DELETE FROM guild_noprefix_access WHERE guild_id = ? AND target_id = ?').run(String(message.guild.id), String(targetId));
      }
      invalidateNoPrefixCache(targetId);

      return message.reply(`<a:tungsten_success:1567242523468890274> Revoked No-Prefix access from <@${targetId}> (\`${targetId}\`).`);
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Check No-Prefix Status (!np check <@user|id>)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'check' || sub === 'status') {
      const targetInput = args[1];
      const targetId = targetInput
        ? (message.mentions?.users?.first()?.id || targetInput.replace(/[<@!>]/g, ''))
        : message.author.id;

      const user = await client.users.fetch(targetId).catch(() => null);
      const isOwnerUser = isOwner(targetId);
      const isManagerUser = isNpManager(targetId);

      const gRow = mdb.prepare('SELECT added_at, added_by, expires_at FROM noprefix_users WHERE user_id = ?').get(String(targetId));
      const sRow = sdb ? sdb.prepare('SELECT added_at, added_by FROM guild_noprefix_access WHERE guild_id = ? AND target_id = ?').get(String(message.guild?.id), String(targetId)) : null;

      let statusTier = '<a:tungsten_close:1567234632905138206> Inactive (Prefix Required)';
      let details = `User must type prefix \`${prefix}\` before executing commands.`;

      if (isOwnerUser) {
        statusTier = '<a:tungsten_crown:1567238355463176334> Super-Owner (Permanent Full Access)';
        details = 'Master bot developer authority with permanent zero-prefix execution everywhere.';
      } else if (isManagerUser) {
        statusTier = '<a:tungsten_shield:1567242104923627574> NP Manager (Global Access)';
        details = 'Elevated manager authority with global no-prefix and administration rights.';
      } else if (gRow) {
        const exp = (gRow.expires_at === null || gRow.expires_at === -1 || gRow.expires_at === undefined)
          ? '`Permanent ♾️`'
          : `<t:${gRow.expires_at}:F> (<t:${gRow.expires_at}:R>)`;
        statusTier = '🌐 Global No-Prefix Member';
        details = `Active across all servers.\n• **Expires:** ${exp}\n• **Granted By:** <@${gRow.added_by}>\n• **Added:** <t:${gRow.added_at}:R>`;
      } else if (sRow) {
        statusTier = '🏰 Server-Level No-Prefix';
        details = `Active only in **${message.guild.name}**.\n• **Granted By:** <@${sRow.added_by}>\n• **Added:** <t:${sRow.added_at}:R>`;
      }

      const card = createV2Card({
        color: (isOwnerUser || isManagerUser || gRow || sRow) ? 0x2ECC71 : 0x95A5A6,
        title: `⚡  No-Prefix Status: ${user ? user.username : targetId}`,
        description:
          `• **User:** <@${targetId}> (\`${targetId}\`)\n` +
          `• **Status:** ${statusTier}\n\n` +
          details,
        footerText: `Tungsten Telemetry Hub`
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. List No-Prefix Users (!np list)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'list' || sub === 'all') {
      const payload = buildNpHubPayload(message.guild, message.author, prefix);
      return message.reply(payload);
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Default Interactive Dashboard Panel (!np [panel])
    // ─────────────────────────────────────────────────────────────
    const payload = buildNpHubPayload(message.guild, message.author, prefix);
    return message.reply(payload);
  }
};
