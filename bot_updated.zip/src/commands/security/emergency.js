/**
 * Emergency Command (Node.js)
 * Master emergency panic suite wrapper guaranteeing both 'emergency' and 'panic' are registered.
 */
const panic = require('./panic');

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  ...panic,
  name: 'emergency',
  aliases: []
};
