/**
 * Anti-Raid & Join Flood Protection Command (Node.js)
 * Automatically detects and halts distributed token raids and mass joins.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'antiraid',
  aliases: ['raidmode', 'raiddefense'],
  category: 'security',
  description: 'Configure automated anti-raid join-flood detection (Default: pre-armed with 8 joins / 10s kick quarantine).',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[on | off | limit <count> | action <kick|ban|timeout> | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure Anti-Raid.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase() || 'status';

    if (sub === 'on' || sub === 'enable') {
      sdb.prepare(`
        INSERT INTO antiraid_settings (guild_id, enabled)
        VALUES (?, 1)
        ON CONFLICT(guild_id) DO UPDATE SET enabled = 1
      `).run(message.guild.id);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '<a:tungsten_shield:1567242104923627574>  Anti-Raid Sentinel Armed',
        description:
          `> Automatic join-flood detection is now <a:tungsten_ui_toggle_on:1569329685110849576> **ACTIVE**.\n\n` +
          `• **Join Threshold:** 8 joins per 10 seconds\n` +
          `• **Countermeasure:** Mass join accounts will be quarantined / kicked and channel locks applied.\n\n` +
          `-# Configure threshold with \`${prefix}antiraid limit <count>\``
      });
      return message.reply({ embeds: [embed] });
    }

    if (sub === 'off' || sub === 'disable') {
      sdb.prepare(`
        INSERT INTO antiraid_settings (guild_id, enabled)
        VALUES (?, 0)
        ON CONFLICT(guild_id) DO UPDATE SET enabled = 0
      `).run(message.guild.id);

      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Anti-Raid Sentinel has been **DISABLED**.');
    }

    if (sub === 'limit' && args[1]) {
      const limit = parseInt(args[1], 10);
      if (isNaN(limit) || limit < 3 || limit > 50) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please enter a valid join limit between 3 and 50.');
      }

      sdb.prepare(`
        INSERT INTO antiraid_settings (guild_id, join_limit)
        VALUES (?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET join_limit = excluded.join_limit
      `).run(message.guild.id, limit);

      return message.reply(`<a:tungsten_success:1567242523468890274> Anti-Raid threshold set to **${limit} joins / 10s**.`);
    }

    if (sub === 'action' && args[1]) {
      const action = args[1].toLowerCase();
      if (!['kick', 'ban', 'timeout'].includes(action)) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please choose a valid action: `kick`, `ban`, or `timeout`.');
      }

      sdb.prepare(`
        INSERT INTO antiraid_settings (guild_id, action)
        VALUES (?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET action = excluded.action
      `).run(message.guild.id, action);

      return message.reply(`<a:tungsten_success:1567242523468890274> Anti-Raid enforcement action set to **${action.toUpperCase()}**.`);
    }

    const row = sdb.prepare('SELECT * FROM antiraid_settings WHERE guild_id = ?').get(message.guild.id);
    const isArmed = row ? row.enabled === 1 : true;
    const limit = row ? row.join_limit : 8;

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574>  Anti-Raid Sentinel Configuration',
      description:
        `> Automated join flood detection & token raid neutralizer.\n\n` +
        `• **Sentinel Status:** ${isArmed ? '<a:tungsten_ui_toggle_on:1569329685110849576> `ACTIVE & ARMED`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `DISABLED`'}\n` +
        `• **Default Policy:** Pre-armed out-of-the-box for instant zero-day defense\n` +
        `• **Threshold:** \`${limit} joins per 10s\`\n` +
        `• **Action on Trigger:** Instant Raid Lockdown & Kick Quarantine\n\n` +
        `**Commands:**\n` +
        `• \`${prefix}antiraid on\` — Activate anti-raid shield\n` +
        `• \`${prefix}antiraid off\` — Disable shield\n` +
        `• \`${prefix}antiraid limit <3-50>\` — Set join limit`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
