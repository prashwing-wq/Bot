/**
 * Antinuke Suite Command & Security Console (Node.js)
 * Clean, modern security studio built on Discord Components V2 Type 17 Containers.
 * Configurable per-vector rate limits, enforcement actions, structural auto-healing,
 * and disaster recovery snapshot management.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  PermissionsBitField,
  MessageFlags
} = require('discord.js');
const config = require('../../config');
const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');
const { isNpManager, isOwner, createEmbed } = require('../../utils/tools');
const {
  animateSequence,
  getAntinukeEnableFrames,
  getAntinukeDisableFrames
} = require('../../utils/animation');
const {
  isAntinukeArmed,
  ensureDualBackupRoles,
  ANTINUKE_VECTORS,
  getAntinukeRule,
  setAntinukeRule,
  getAllAntinukeRules,
  applyAntinukePreset,
  quarantineUser,
  unquarantineUser,
  createServerSnapshot,
  restoreServerSnapshot,
  listServerSnapshots,
  deleteServerSnapshot,
  cacheChannelSnapshot,
  cacheRoleSnapshot
} = require('../../utils/antinukeEngine');
const { createV2Card } = require('../../utils/componentsV2');
const { panel, section, header, facts, list, toggleRow, confirm, empty, footer, separator } = require('../../ui/kit');
const { getStateAccent, COLORS, sanitizeAccent } = require('../../ui/tokens');
const { timeAgo, healthSubtext } = require('../../ui/copy');

function getAntinukeStatus(guildId) {
  return isAntinukeArmed(guildId);
}

function setAntinukeStatus(guildId, enabled) {
  const { setAntinukeStatus: engineSetStatus } = require('../../utils/antinukeEngine');
  return engineSetStatus(guildId, enabled);
}

const VECTOR_GROUPS = {
  channels: {
    title: 'Channels (delete, create, edit)',
    customId: 'an:group:channels',
    vectors: ['channel_delete', 'channel_create', 'channel_update']
  },
  roles: {
    title: 'Roles (delete, create, escalation)',
    customId: 'an:group:roles',
    vectors: ['role_delete', 'role_create', 'role_update']
  },
  members: {
    title: 'Members & Bots (ban, kick, bot add, prune)',
    customId: 'an:group:members',
    vectors: ['ban', 'kick', 'bot_add', 'prune']
  },
  server: {
    title: 'Server & Webhooks (vanity, server update, webhook)',
    customId: 'an:group:server',
    vectors: ['vanity', 'server_update', 'webhook', 'everyone_ping', 'emoji', 'sticker']
  }
};

function getAntinukeHealth(guild) {
  if (!guild) return 'normal';
  const issues = [];
  try {
    const me = guild.members?.me;
    if (me && me.permissions && typeof me.permissions.has === 'function') {
      if (!me.permissions.has(PermissionsBitField.Flags.Administrator)) {
        issues.push('missing administrator permission');
      }
    }
  } catch (_) {}

  try {
    const sdb = getServerDb(guild.id);
    const t1 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_1'").get();
    const t2 = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_2'").get();
    if (!t1?.value || !t2?.value) {
      issues.push('backup roles not deployed');
    } else if (guild.roles?.cache && typeof guild.roles.cache.has === 'function') {
      if (!guild.roles.cache.has(t1.value) || !guild.roles.cache.has(t2.value)) {
        issues.push('backup roles pending anchor');
      }
    }
  } catch (_) {}

  const memberCount = guild.memberCount || guild.members?.cache?.size || 0;
  if (memberCount < 50) {
    issues.push('member count below 50');
  }

  if (issues.length === 0) {
    return 'all checks passed';
  }
  return `${issues.length} check${issues.length === 1 ? '' : 's'} need${issues.length === 1 ? 's' : ''} attention (${issues.join(', ')})`;
}

function getLastIncidentText(guildId) {
  try {
    const sdb = getServerDb(guildId);
    const row = sdb.prepare(`
      SELECT timestamp FROM audit_logs 
      WHERE action LIKE 'antinuke%' OR action LIKE 'an_%' 
      ORDER BY timestamp DESC LIMIT 1
    `).get();
    if (row && row.timestamp) {
      return timeAgo(row.timestamp);
    }
  } catch (_) {}
  return 'never';
}

function createAntinukeButtons(isEnabled) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(isEnabled ? 'an:disarm' : 'an:arm')
      .setLabel(isEnabled ? 'Disarm' : 'Arm')
      .setStyle(isEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('an:presets_menu')
      .setLabel('Presets')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('wl:studio')
      .setLabel('Whitelist')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('an:snapshots')
      .setLabel('Snapshots')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('an:close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );
}

function buildMemberRequirementCard(guild) {
  const memberCount = guild?.memberCount || guild?.members?.cache?.size || 0;
  return createV2Card({
    color: COLORS.warning,
    title: 'Antinuke Minimum Requirement',
    description:
      `Antinuke protections require a minimum of 50 members to activate.\n\n` +
      `• Current server members: ${memberCount} / 50\n` +
      `• Required threshold: 50 members\n` +
      `• Protection status: Activation restricted\n\n` +
      `-# To prevent accidental lockouts on developing servers, Antinuke can only be activated once the server reaches 50 members. Bot owners and managers can authorize an override.`,
    footerText: `Server requirement (${memberCount}/50)`
  });
}

/**
 * Builds the interactive Antinuke Studio payload.
 */
function buildAntinukeStudioPayload(guild, prefix = '!') {
  const isArmed = Boolean(getAntinukeStatus(guild.id));
  const rules = getAllAntinukeRules(guild.id);
  const enabledCount = Object.values(rules).filter(r => r.enabled).length;
  const lastIncidentText = getLastIncidentText(guild.id);
  const healthSummary = getAntinukeHealth(guild);

  const status = `${isArmed ? 'Armed' : 'Disarmed'} · ${enabledCount} of 16 protections on · last incident ${lastIncidentText}`;
  const healthLine = `-# Setup health: ${healthSummary}`;

  const sections = [];
  for (const [grpKey, grp] of Object.entries(VECTOR_GROUPS)) {
    const activeInGroup = grp.vectors.filter(v => rules[v]?.enabled).length;
    const totalInGroup = grp.vectors.length;
    const hint = `${activeInGroup} of ${totalInGroup} active`;
    sections.push(section({
      title: grp.title,
      hint,
      accessory: new ButtonBuilder()
        .setCustomId(grp.customId)
        .setLabel('Configure')
        .setStyle(ButtonStyle.Secondary)
    }));
  }

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(isArmed ? 'an:disarm' : 'an:arm')
      .setLabel(isArmed ? 'Disarm' : 'Arm')
      .setStyle(isArmed ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('an:presets_menu')
      .setLabel('Presets')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('wl:studio')
      .setLabel('Whitelist')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('an:snapshots')
      .setLabel('Snapshots')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('an:close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );

  return panel({
    title: 'Antinuke',
    status,
    description: healthLine,
    color: getStateAccent(isArmed ? 'armed' : 'disarmed'),
    sections,
    rows: [navRow]
  });
}

/**
 * Builds the interactive Sentinel vector detail payload.
 */
function buildVectorDetailPayload(guild, vector, prefix = '!') {
  const rule = getAntinukeRule(guild.id, vector);
  if (!rule) return null;

  const isEnabled = Boolean(rule.enabled);
  const statusStr = isEnabled ? 'Enabled' : 'Disabled';
  const thresholdStr = `${rule.limit_count} incident${rule.limit_count > 1 ? 's' : ''} in ${rule.time_window}s`;
  const actionStr = String(rule.action || 'ban').toUpperCase();
  const autoHealStr = rule.auto_heal ? 'On' : 'Off';

  const cleanDesc = rule.desc 
    ? rule.desc.replace(/Sub-50ms\s*/i, '').replace(/Ultra\s*/i, '')
    : 'Real-time protection sentinel.';

  const sections = [
    section({
      title: `Protection: ${statusStr}`,
      hint: `Auto-heal: ${autoHealStr}`,
      accessory: new ButtonBuilder()
        .setCustomId(`an:vec_toggle:${vector}`)
        .setLabel(isEnabled ? 'Disable' : 'Enable')
        .setStyle(isEnabled ? ButtonStyle.Danger : ButtonStyle.Success)
    }),
    section({
      title: `Threshold: ${thresholdStr}`,
      hint: `Action: ${actionStr}`,
      accessory: new ButtonBuilder()
        .setCustomId(`an:vec_action:${vector}`)
        .setLabel('Action ▾')
        .setStyle(ButtonStyle.Secondary)
    })
  ];

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`an:vec_toggle:${vector}`)
      .setLabel(isEnabled ? 'Disable' : 'Enable')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`an:vec_action:${vector}`)
      .setLabel('Action ▾')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`an:vec_limit:${vector}`)
      .setLabel(`${rule.limit_count}/${rule.time_window}s`)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('an:vec_back')
      .setLabel('Back to Studio')
      .setStyle(ButtonStyle.Secondary)
  );

  return panel({
    title: `Antinuke · ${rule.name}`,
    status: `${statusStr} · ${actionStr} · ${thresholdStr}`,
    description: cleanDesc,
    color: getStateAccent(isEnabled ? 'armed' : 'disarmed'),
    sections,
    rows: [buttonRow]
  });
}

/**
 * Builds the interactive group vectors payload.
 */
function buildGroupVectorsPayload(guild, groupKey, prefix = '!') {
  const group = VECTOR_GROUPS[groupKey];
  if (!group) return null;

  const rules = getAllAntinukeRules(guild.id);
  const vectorsInGroup = group.vectors.map(v => rules[v]).filter(Boolean);
  const activeCount = vectorsInGroup.filter(v => v.enabled).length;

  const sections = vectorsInGroup.map(v => {
    const isEnabled = Boolean(v.enabled);
    const actionStr = String(v.action || 'ban').toUpperCase();
    const hint = `${isEnabled ? 'Enabled' : 'Disabled'} · ${actionStr} · ${v.limit_count}/${v.time_window}s`;
    return section({
      title: v.name,
      hint,
      accessory: new ButtonBuilder()
        .setCustomId(`an:vector:${v.vector}`)
        .setLabel('Configure')
        .setStyle(ButtonStyle.Secondary)
    });
  });

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('an:vec_back')
      .setLabel('Back to Studio')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('an:close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );

  return panel({
    title: `Antinuke · ${group.title.split(' (')[0]}`,
    status: `${activeCount} of ${vectorsInGroup.length} protections active`,
    description: '-# Select a protection vector below to adjust rate limits or action policy.',
    color: getStateAccent(activeCount > 0 ? 'armed' : 'disarmed'),
    sections,
    rows: [navRow]
  });
}

/**
 * Builds the presets payload.
 */
function buildPresetsPayload(guild) {
  const presets = [
    { key: 'strict', name: 'Strict (Ultra)', desc: '1 incident per 10s · Ban · Auto-heal on' },
    { key: 'balanced', name: 'Balanced', desc: '2 incidents per 10s · Kick · Auto-heal on' },
    { key: 'relaxed', name: 'Relaxed', desc: '3 incidents per 10s · Quarantine · Auto-heal on' },
    { key: 'lockdown', name: 'Lockdown', desc: 'Immediate ban on all 16 vectors' }
  ];

  const sections = presets.map(p => section({
    title: p.name,
    hint: p.desc,
    accessory: new ButtonBuilder()
      .setCustomId(`an:preset:${p.key}`)
      .setLabel('Apply')
      .setStyle(ButtonStyle.Secondary)
  }));

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('an:vec_back')
      .setLabel('Back to Studio')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('an:close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Secondary)
  );

  return panel({
    title: 'Antinuke · Protection Presets',
    status: 'Select a preset configuration profile',
    description: '-# Applying a preset updates thresholds across all 16 protection sentinels.',
    sections,
    rows: [navRow]
  });
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'antinuke',
  aliases: ['an', 'security', 'guard', 'andashboard', 'anpanel', 'anui', 'antinukepanel', 'studio'],
  category: 'security',
  description: 'Enterprise Wick/Olympus-grade Antinuke defense studio, vector threshold management, quarantine, and recovery.',
  usage: '[enable|disable|status|config|panel|setlimit|setaction|toggle|autoheal|quarantine|unquarantine|snapshot]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sdb = getServerDb(message.guild.id);
    const isBotOwner = isOwner(message.author.id);
    const isServerOwner = message.author.id === message.guild.ownerId;
    const isManager = isNpManager(message.author.id);
    const isExtraOwner = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id));
    const isGuildAdmin = Boolean(message.member?.permissions?.has?.(PermissionsBitField.Flags.Administrator));
    const hasModPerms = isServerOwner || isExtraOwner || isGuildAdmin || isBotOwner;

    if (!hasModPerms && !isManager) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: Only the **Server Owner**, **Administrators**, or **Extra Owners** can manage Antinuke protection.');
    }

    const sub = args[0]?.toLowerCase();
    const isEnabled = getAntinukeStatus(message.guild.id);
    const botAvatar = client.user ? client.user.displayAvatarURL() : null;

    // NP Manager without moderation roles: allowed ONLY to view studio panel or turn ON Antinuke
    if (!hasModPerms && isManager && !isBotOwner) {
      const isStudioView = !sub || ['status', 'config', 'panel', 'dashboard', 'check', 'studio', 'ui'].includes(sub);
      const isTurnOn = ['enable', 'on', 'arm', 'preset', 'profile', 'mode'].includes(sub);
      const isToggle = sub === 'toggle';

      if (!isStudioView && !isTurnOn && !isToggle) {
        return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: NP Managers without server administration roles can only view the studio panel or turn on Antinuke protection.');
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 1. Studio Panel / Overview
    // ─────────────────────────────────────────────────────────────
    if (!sub || ['status', 'config', 'panel', 'dashboard', 'check', 'studio', 'ui'].includes(sub)) {
      const payload = buildAntinukeStudioPayload(message.guild, prefix);
      return message.reply(payload);
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Arm / Disarm Commands (4-Stage Cyber-Matrix Animation)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'enable' || sub === 'on' || sub === 'arm') {
      if (!isManager && (message.guild.memberCount || 0) < 50) {
        const card = buildMemberRequirementCard(message.guild);
        return message.reply({ embeds: [card] });
      }

      const frames = getAntinukeEnableFrames(message.guild.name, botAvatar);
      const statusMsg = await message.reply({ embeds: [frames[0]] });

      await animateSequence(statusMsg, frames.slice(0, 3), { intervalMs: 500 });

      setAntinukeStatus(message.guild.id, true);
      sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('backup_roles_enabled', '1')").run();
      syncServerDataToMaster(message.guild.id);

      for (const vKey of Object.keys(ANTINUKE_VECTORS)) {
        setAntinukeRule(message.guild.id, vKey, { enabled: true, limit_count: 1, action: 'ban', auto_heal: 1 });
      }
      if (message.guild.channels?.cache) {
        for (const ch of message.guild.channels.cache.values()) cacheChannelSnapshot(ch);
      }
      if (message.guild.roles?.cache) {
        for (const r of message.guild.roles.cache.values()) cacheRoleSnapshot(r);
      }

      // Non-blocking background anchoring of backup roles
      ensureDualBackupRoles(message.guild, { force: true }).catch(err => {
        console.warn(`[Antinuke Enable] ensureDualBackupRoles failed for ${message.guild.id}:`, err?.message || err);
      });

      const card = createV2Card({
        color: COLORS.success,
        title: 'Tungsten Antinuke Armed',
        description:
          `Antinuke protections are now armed and active.\n\n` +
          `• Global defense state: Armed and enforcing\n` +
          `• Threat protections: 16 of 16 vectors active\n` +
          `• Auto-healing: Active\n` +
          `• Dual backup roles: Safeguard active\n` +
          `• Snapshots: Preserved\n\n` +
          `-# Unauthorized channel/role deletion, member pruning, or permission tampering will be intercepted immediately.`,
        footerText: `Armed by ${message.author.username}`
      });

      if (statusMsg?.edit) {
        return await statusMsg.edit({
          embeds: [card],
          components: [createAntinukeButtons(true)]
        });
      } else if (statusMsg && typeof statusMsg === 'object') {
        statusMsg.embeds = [card];
        statusMsg.components = [createAntinukeButtons(true)];
      }
      return statusMsg;
    }

    if (sub === 'disable' || sub === 'off' || sub === 'disarm') {
      if (isManager && !isServerOwner && !isBotOwner) {
        return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: NP Managers cannot disable Antinuke. Only the Server Owner can turn it off.');
      }

      const frames = getAntinukeDisableFrames(message.guild.name, botAvatar);
      const statusMsg = await message.reply({ embeds: [frames[0]] });

      await animateSequence(statusMsg, frames.slice(0, 2), { intervalMs: 450 });

      setAntinukeStatus(message.guild.id, false);
      try {
        const sdb = getServerDb(message.guild.id);
        sdb.prepare("DELETE FROM server_settings WHERE key = 'backup_roles_enabled'").run();
      } catch (_) {}
      syncServerDataToMaster(message.guild.id);

      const card = createV2Card({
        color: COLORS.danger,
        title: 'Tungsten Antinuke Disarmed',
        description:
          `Antinuke protections are now disarmed.\n\n` +
          `• Global defense state: Disarmed and inactive\n` +
          `• Threat protections: Paused (actions not intercepted)\n` +
          `• Safe state: Whitelist, backup roles, and configurations preserved\n\n` +
          `-# To re-arm protection at any time, run ${prefix}an enable or click Arm below.`,
        footerText: `Disarmed by ${message.author.username}`
      });

      if (statusMsg?.edit) {
        return await statusMsg.edit({
          embeds: [card],
          components: [createAntinukeButtons(false)]
        });
      } else if (statusMsg && typeof statusMsg === 'object') {
        statusMsg.embeds = [card];
        statusMsg.components = [createAntinukeButtons(false)];
      }
      return statusMsg;
    }

    // ─────────────────────────────────────────────────────────────
    // 2.5 Dual Backup Roles Command (!an backuproles)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'backuproles' || sub === 'rolesafeguard' || sub === 'roles') {
      const deployRes = await ensureDualBackupRoles(message.guild, { force: true });
      if (!deployRes.success) {
        return message.reply(`<a:tungsten_error:1567238753284653106> Failed to deploy Dual Backup Roles: \`${deployRes.reason}\`\nPlease ensure Tungsten has the **Administrator** or **Manage Roles** permission and is positioned near the top of the role list.`);
      }

      const role1Id = deployRes.roles[0];
      const role2Id = deployRes.roles[1];
      const r1 = message.guild.roles?.cache?.get(role1Id) || { name: 'Tungsten Backup Tier I', id: role1Id };
      const r2 = message.guild.roles?.cache?.get(role2Id) || { name: 'Tungsten Backup Tier II', id: role2Id };

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_shield:1567242104923627574> Dual Backup Roles Safeguard Anchored',
        description:
          `> High-availability bot self-preservation roles have been deployed and verified.\n\n` +
          `• **Primary Safeguard:** <@&${r1.id}> (\`${r1.id}\`)\n` +
          `• **Secondary Safeguard:** <@&${r2.id}> (\`${r2.id}\`)\n` +
          `• **Role Permissions:** Administrator / High-Privilege Defenses\n` +
          `• **Binding Status:** Active & Bound to <@${client.user.id}>\n\n` +
          `-# If a rogue admin strips Tungsten's main role, these backup roles maintain authority to immediately terminate the attacker and restore defenses.`,
        footer: { text: `Dual-Role Safeguard • Wick/Olympus Grade Architecture` }
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Set Vector Limit (!an setlimit <vector> <count> [window])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'setlimit' || sub === 'limit') {
      const vector = args[1]?.toLowerCase();
      const count = parseInt(args[2], 10);
      let windowSec = 10;
      if (args[3]) {
        const match = args[3].toLowerCase().match(/^(\d+)s?$/);
        if (match) windowSec = parseInt(match[1], 10);
      }

      if (!vector || !ANTINUKE_VECTORS[vector] || isNaN(count) || count < 1) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an setlimit <vector> <count> [window_seconds]\`\nValid vectors: \`${Object.keys(ANTINUKE_VECTORS).join('`, `')}\``);
      }

      setAntinukeRule(message.guild.id, vector, { limit_count: count, time_window: windowSec });
      const rule = getAntinukeRule(message.guild.id, vector);

      const card = createV2Card({
        color: 0x2ECC71,
        title: `${rule.icon} Sentinel Threshold Updated`,
        description:
          `> Configured operational rate limit for sentinel **${rule.name}**.\n\n` +
          `• **Sentinel Vector:** \`${vector}\`\n` +
          `• **New Threshold:** \`${count} incident(s) / ${windowSec}s\`\n` +
          `• **Enforcement Action:** \`${rule.action.toUpperCase()}\`\n\n` +
          `-# Attacks exceeding this limit trigger automated interception and sanction.`,
        footer: { text: `Configured by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Set Vector Action (!an setaction <vector> <ban|kick|strip|quarantine>)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'setaction' || sub === 'action') {
      const vector = args[1]?.toLowerCase();
      const action = args[2]?.toLowerCase();
      const validActions = ['ban', 'kick', 'strip', 'quarantine'];

      if (!vector || !ANTINUKE_VECTORS[vector] || !validActions.includes(action)) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an setaction <vector> <ban|kick|strip|quarantine>\`\nValid vectors: \`${Object.keys(ANTINUKE_VECTORS).join('`, `')}\``);
      }

      setAntinukeRule(message.guild.id, vector, { action });
      const rule = getAntinukeRule(message.guild.id, vector);

      const card = createV2Card({
        color: 0x2ECC71,
        title: `${rule.icon} Sentinel Action Updated`,
        description:
          `> Configured punishment policy for sentinel **${rule.name}**.\n\n` +
          `• **Sentinel Vector:** \`${vector}\`\n` +
          `• **Sanction Mode:** \`${action.toUpperCase()}\`\n` +
          `• **Auto-Heal:** ${rule.auto_heal ? '<a:tungsten_ui_toggle_on:1569329685110849576> `<ACTIVE>`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `<OFF>`'}\n\n` +
          `-# Attackers caught violating this vector will face immediate ${action.toUpperCase()}.`,
        footer: { text: `Configured by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. Preset Configuration (!an preset [relaxed|balanced|strict|lockdown])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'preset' || sub === 'profile' || sub === 'mode') {
      const mode = (args[1]?.toLowerCase() || 'balanced');
      if (!['relaxed', 'balanced', 'strict', 'lockdown'].includes(mode)) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an preset <relaxed|balanced|strict|lockdown>\`\n\nAvailable presets:\n• **relaxed**: Higher tolerance thresholds with quarantine/strip responses.\n• **balanced**: Production baseline balancing protection and operational tolerance.\n• **strict**: Single-strike ban policy on primary vectors with limited emoji tolerance.\n• **lockdown**: Immediate ban enforcement across all 16 vectors.`);
      }

      if (!isManager && (message.guild.memberCount || 0) < 50) {
        const card = buildMemberRequirementCard(message.guild);
        return message.reply({ embeds: [card] });
      }

      applyAntinukePreset(message.guild.id, mode);
      setAntinukeStatus(message.guild.id, true);

      const descriptions = {
        relaxed: 'Higher tolerance thresholds with quarantine/strip responses.',
        balanced: 'Production baseline balancing protection and operational tolerance.',
        strict: 'Single-strike ban policy on primary vectors with limited emoji tolerance.',
        lockdown: 'Immediate ban enforcement across all 16 vectors.'
      };

      const card = createV2Card({
        color: config.COLORS.PRIMARY,
        title: 'Antinuke Preset Applied',
        description: `Applied **${mode}** preset to 16 threat vectors.\n-# ${descriptions[mode]}`,
        footer: { text: `Preset applied by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Toggle Sentinel (!an toggle <vector> [on|off])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'toggle') {
      const vector = args[1]?.toLowerCase();
      if (!vector || !ANTINUKE_VECTORS[vector]) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an toggle <vector> [on|off]\`\nValid vectors: \`${Object.keys(ANTINUKE_VECTORS).join('`, `')}\``);
      }

      const curRule = getAntinukeRule(message.guild.id, vector);
      let targetEnabled = !curRule.enabled;
      if (args[2]) {
        targetEnabled = ['on', 'enable', 'true', '1'].includes(args[2].toLowerCase());
      }

      if (targetEnabled) {
        if (!isManager && (message.guild.memberCount || 0) < 50) {
          const card = buildMemberRequirementCard(message.guild);
          return message.reply({ embeds: [card] });
        }
      } else {
        if (isManager && !isServerOwner && !isBotOwner) {
          return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: NP Managers cannot turn off Antinuke sentinels. Only the Server Owner can turn it off.');
        }
        if (!hasModPerms) {
          return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: Only administrators can modify sentinel settings.');
        }
      }

      setAntinukeRule(message.guild.id, vector, { enabled: targetEnabled });
      const updated = getAntinukeRule(message.guild.id, vector);

      const card = createV2Card({
        color: updated.enabled ? 0x2ECC71 : 0xED4245,
        title: `${updated.icon} Sentinel State Toggled`,
        description:
          `> Sentinel **${updated.name}** is now ${updated.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> **ARMED & ACTIVE**' : '<a:tungsten_ui_toggle_off:1569329677187678368> **DISABLED**'}.\n\n` +
          `• **Vector:** \`${vector}\`\n` +
          `• **Action:** \`${updated.action.toUpperCase()}\`\n` +
          `• **Threshold:** \`${updated.limit_count}/${updated.time_window}s\``,
        footer: { text: `Updated by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Toggle Auto-Heal (!an autoheal <vector> [on|off])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'autoheal' || sub === 'heal') {
      const vector = args[1]?.toLowerCase();
      if (!vector || !ANTINUKE_VECTORS[vector]) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an autoheal <vector> [on|off]\``);
      }

      const curRule = getAntinukeRule(message.guild.id, vector);
      let targetHeal = !curRule.auto_heal;
      if (args[2]) {
        targetHeal = ['on', 'enable', 'true', '1'].includes(args[2].toLowerCase());
      }

      setAntinukeRule(message.guild.id, vector, { auto_heal: targetHeal });
      const updated = getAntinukeRule(message.guild.id, vector);

      const card = createV2Card({
        color: updated.auto_heal ? 0x2ECC71 : 0xED4245,
        title: `<a:tungsten_refresh:1567241907116187658> Auto-Heal Toggled: ${updated.name}`,
        description:
          `> Automatic structural rollback for **${updated.name}** is now ${updated.auto_heal ? '<a:tungsten_ui_toggle_on:1569329685110849576> **ENABLED**' : '<a:tungsten_ui_toggle_off:1569329677187678368> **DISABLED**'}.\n\n` +
          `• **Auto-Healing Mode:** ${updated.auto_heal ? '<a:tungsten_ui_toggle_on:1569329685110849576> Sub-50ms instant recreation of deleted items' : '<a:tungsten_ui_toggle_off:1569329677187678368> Off (Items remain deleted)'}`,
        footer: { text: `Updated by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 7. Isolation Quarantine System (!an quarantine / !an unquarantine)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'quarantine' || sub === 'jail') {
      const targetRaw = args[1];
      if (!targetRaw) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an quarantine <@user|id> [reason]\``);
      }

      const cleanId = targetRaw.replace(/[<@!>]/g, '');
      const reason = args.slice(2).join(' ') || `Manual administrative quarantine by ${message.author.username}`;

      const res = await quarantineUser(message.guild, cleanId, reason, client);
      if (!res.success) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Quarantine failed: ${res.reason || res.error}`);
      }

      const card = createV2Card({
        color: 0xED4245,
        title: '<a:tungsten_shield:1567242104923627574>  Member Quarantined & Isolated',
        description:
          `> Account <@${cleanId}> (\`${cleanId}\`) has been quarantined and isolated.\n\n` +
          `• **Original Roles Preserved:** \`${res.quarantinedRoles}\` roles saved to encrypted registry\n` +
          `• **Isolation Role:** \`@Tungsten Quarantined\` bound (All channels denied)\n` +
          `• **Communication Timeout:** 28 days applied\n` +
          `• **Reason:** ${reason}\n\n` +
          `-# To release and restore roles: \`${prefix}an unquarantine <@${cleanId}>\``,
        footer: { text: `Quarantined by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    if (sub === 'unquarantine' || sub === 'unjail') {
      const targetRaw = args[1];
      if (!targetRaw) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an unquarantine <@user|id>\``);
      }

      const cleanId = targetRaw.replace(/[<@!>]/g, '');
      const res = await unquarantineUser(message.guild, cleanId, client);
      if (!res.success) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Unquarantine failed: ${res.reason || res.error}`);
      }

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_success:1567242523468890274>  Quarantine Lifted & Roles Restored',
        description:
          `> Successfully released <@${cleanId}> from quarantine isolation.\n\n` +
          `• **Isolation Role:** Revoked\n` +
          `• **Original Roles:** Restored from registry\n` +
          `• **Account Status:** Active & Normal`,
        footer: { text: `Unquarantined by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    if (sub === 'quarantined' || sub === 'jailed') {
      const rows = sdb.prepare('SELECT user_id, quarantined_at, quarantined_by, reason FROM quarantined_users WHERE guild_id = ?').all(message.guild.id);
      if (rows.length === 0) {
        return message.reply('<a:tungsten_shield:1567242104923627574> No members currently in quarantine isolation.');
      }

      const lines = rows.map((r, i) => `\`#${i + 1}\` <@${r.user_id}> (\`${r.user_id}\`) • Quarantined <t:${r.quarantined_at}:R>\n↳ Reason: *${r.reason || 'None specified'}*`).join('\n\n');
      const embed = createEmbed({
        title: `<a:tungsten_shield:1567242104923627574>  Quarantine Registry • ${message.guild.name}`,
        description: `Active isolated accounts:\n\n${lines}`,
        footer: { text: `Total: ${rows.length} quarantined accounts` }
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 8. Disaster Recovery Snapshots (!an snapshot)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'snapshot' || sub === 'backup') {
      const action = args[1]?.toLowerCase();

      if (action === 'create') {
        const name = args.slice(2).join(' ') || null;
        const snap = await createServerSnapshot(message.guild, message.author.id, name);
        if (!snap) {
          return message.reply('<a:tungsten_close:1567234632905138206> Failed to generate server snapshot.');
        }

        const card = createV2Card({
          color: 0x2ECC71,
          title: '<a:tungsten_refresh:1567241907116187658>  Disaster Recovery Snapshot Generated',
          description:
            `> Successfully captured complete structural state of **${message.guild.name}**.\n\n` +
            `• **Snapshot ID:** \`#${snap.id}\`\n` +
            `• **Snapshot Label:** *${snap.name}*\n` +
            `• **Captured Assets:** \`${snap.channelsCount}\` channels, \`${snap.rolesCount}\` roles, server metadata\n\n` +
            `-# To restore if a breach occurs: \`${prefix}an snapshot restore ${snap.id}\``,
          footer: { text: `Snapshot by ${message.author.username}` }
        });
        return message.reply({ embeds: [card] });
      }

      if (action === 'list') {
        const snaps = listServerSnapshots(message.guild.id);
        if (snaps.length === 0) {
          return message.reply('<a:tungsten_warn:1567246685082746940> No snapshots saved for this server yet. Create one with `!an snapshot create`.');
        }

        const lines = snaps.map(s => `• **ID #${s.id}:** *${s.name}* — Captured <t:${s.created_at}:R> by <@${s.created_by}>`).join('\n');
        const embed = createEmbed({
          title: `<a:tungsten_refresh:1567241907116187658>  Disaster Recovery Snapshots • ${message.guild.name}`,
          description: `Saved server structure recovery points:\n\n${lines}\n\nRestore anytime with \`${prefix}an snapshot restore <id>\`.`,
          footer: { text: `Tungsten Recovery Sentinel` }
        });
        return message.reply({ embeds: [embed] });
      }

      if (action === 'restore') {
        const snapId = parseInt(args[2], 10);
        if (isNaN(snapId)) {
          return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an snapshot restore <snapshot_id>\``);
        }

        const res = await restoreServerSnapshot(message.guild, snapId);
        if (!res.success) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Restoration failed: ${res.error}`);
        }

        const card = createV2Card({
          color: 0x2ECC71,
          title: '<a:tungsten_success:1567242523468890274>  Disaster Recovery Executed',
          description:
            `> Successfully restored server structure from Snapshot \`#${snapId}\`.\n\n` +
            `• **Restored Channels:** \`${res.restoredChannels}\`\n` +
            `• **Restored Roles:** \`${res.restoredRoles}\`\n` +
            `• **Server Properties:** Verified & Restored`,
          footer: { text: `Restoration triggered by ${message.author.username}` }
        });
        return message.reply({ embeds: [card] });
      }

      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}an snapshot <create [name]|list|restore <id>>\``);
    }

    // ─────────────────────────────────────────────────────────────
    // 9. All-in-One Whitelist Management (!an whitelist / !an wl)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'whitelist' || sub === 'wl') {
      const wlCmd = client.commands.get('whitelist');
      if (wlCmd && typeof wlCmd.execute === 'function') {
        return wlCmd.execute(message, args.slice(1), client, prefix);
      }
    }

    if (sub === 'unwhitelist' || sub === 'unwl') {
      const unwlCmd = client.commands.get('unwhitelist');
      if (unwlCmd && typeof unwlCmd.execute === 'function') {
        return unwlCmd.execute(message, args.slice(1), client, prefix);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 10. Extra Owner Management (!an extraowner / !an trust)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'extraowner' || sub === 'trust' || sub === 'owner') {
      const eoCmd = client.commands.get('extraowner');
      if (eoCmd && typeof eoCmd.execute === 'function') {
        return eoCmd.execute(message, args.slice(1), client, prefix);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 11. Emergency Panic Lockdown (!an panic)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'panic') {
      const panicCmd = client.commands.get('panic');
      if (panicCmd && typeof panicCmd.execute === 'function') {
        return panicCmd.execute(message, args.slice(1), client, prefix);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 12. Security Vulnerability Audit (!an audit / !an logs)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'audit' || sub === 'anaudit' || sub === 'logs') {
      const auditCmd = client.commands.get('anaudit');
      if (auditCmd && typeof auditCmd.execute === 'function') {
        return auditCmd.execute(message, args.slice(1), client, prefix);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 13. Factory Reset (!an reset)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'reset') {
      if (!isServerOwner) {
        return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: Only the Primary Server Owner can execute an Antinuke Factory Reset.');
      }
      for (const [vecKey, meta] of Object.entries(ANTINUKE_VECTORS)) {
        setAntinukeRule(message.guild.id, vecKey, {
          enabled: meta.defaultEnabled !== undefined ? meta.defaultEnabled : true,
          limit_count: meta.defaultLimit || 1,
          time_window: meta.defaultWindow || 10,
          action: meta.defaultAction || 'ban',
          auto_heal: meta.defaultHeal ? true : false
        });
      }
      setAntinukeStatus(message.guild.id, false);
      return message.reply('<a:tungsten_success:1567242523468890274> Antinuke configuration has been factory reset to default sentinels and disarmed.');
    }

    // Default: Show Master Studio
    const payload = buildAntinukeStudioPayload(message.guild, prefix);
    return message.reply(payload);
  },

  getAntinukeStatus,
  setAntinukeStatus,
  createAntinukeButtons,
  buildAntinukeStudioPayload,
  buildVectorDetailPayload,
  buildGroupVectorsPayload,
  buildPresetsPayload,
  getAntinukeHealth,
  buildMemberRequirementCard,
  VECTOR_GROUPS
};
