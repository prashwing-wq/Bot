/**
 * Tungsten Security Posture & Self-Audit Command (Node.js)
 * Comprehensive health audit evaluating bot hierarchy, critical permissions,
 * dual backup roles, antinuke status, automod filters, honeypot decoy, and administrative role exposure.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  PermissionsBitField
} = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { getServerDb } = require('../../utils/serverDb');
const { isAntinukeArmed, ensureDualBackupRoles } = require('../../utils/antinukeEngine');
const config = require('../../config');

const TOGGLE_ON = '<a:tungsten_ui_toggle_on:1569329685110849576>';
const TOGGLE_OFF = '<a:tungsten_ui_toggle_off:1569329677187678368>';

function renderProgressBar(score, totalBlocks = 12) {
  const filled = Math.max(0, Math.min(totalBlocks, Math.round((score / 100) * totalBlocks)));
  const empty = totalBlocks - filled;
  return '▰'.repeat(filled) + '▱'.repeat(empty);
}

/**
 * Executes a full security self-audit on the guild
 */
async function runSelfcheckAudit(guild, client, autoFix = false) {
  const me = guild.members?.me || (guild.members?.fetchMe ? await guild.members.fetchMe().catch(() => null) : null);
  const sdb = getServerDb(guild.id);

  let score = 0;
  const sections = [];
  const recommendations = [];

  const allRoles = guild.roles?.cache
    ? (typeof guild.roles.cache.values === 'function' ? [...guild.roles.cache.values()] : Array.from(guild.roles.cache))
    : [];

  const findRole = (fn) => allRoles.find(fn);
  const getRole = (id) => allRoles.find(r => r.id === id);

  // 1. Bot Role Hierarchy Position (20 pts)
  const myHighest = me?.roles?.highest;
  let highestRoleName = myHighest?.name || 'Tungsten';
  if (myHighest && (myHighest.name === 'Celestia' || myHighest.name?.includes('Celestia'))) {
    if (me?.guild?.roles?.edit && myHighest.editable) myHighest.edit({ name: 'Tungsten' }).catch(() => {});
    else if (myHighest.editable && typeof myHighest.edit === 'function') myHighest.edit({ name: 'Tungsten' }).catch(() => {});
    else if (myHighest.editable && typeof myHighest.setName === 'function') myHighest.setName('Tungsten').catch(() => {});
    highestRoleName = 'Tungsten';
  }
  const myPos = myHighest ? myHighest.position : 0;
  const higherUnmanaged = allRoles.filter(r =>
    r.id !== guild.id &&
    !r.managed &&
    !r.tags?.premiumSubscriberRole &&
    r.position >= myPos
  );

  if (higherUnmanaged.length === 0) {
    score += 20;
    sections.push(`${TOGGLE_ON} **Bot Role Hierarchy:** Optimal (\`${highestRoleName}\` sits at top of manageable roles) *(+20)*`);
  } else {
    const roleSample = higherUnmanaged.map(r => `\`@${r.name}\``).slice(0, 3).join(', ');
    const extra = higherUnmanaged.length > 3 ? ` (+${higherUnmanaged.length - 3} more)` : '';
    sections.push(`${TOGGLE_OFF} **Bot Role Hierarchy:** Suboptimal — Positioned below ${higherUnmanaged.length} role(s): ${roleSample}${extra} *(+0)*`);
    recommendations.push(`Move Tungsten's highest role (\`${highestRoleName}\`) to the top in Server Settings → Roles.`);
  }

  // 2. Bot Core Permissions Audit (25 pts)
  const corePerms = [
    { flag: PermissionsBitField.Flags.Administrator, name: 'Administrator' },
    { flag: PermissionsBitField.Flags.ManageRoles, name: 'Manage Roles' },
    { flag: PermissionsBitField.Flags.ManageChannels, name: 'Manage Channels' },
    { flag: PermissionsBitField.Flags.BanMembers, name: 'Ban Members' },
    { flag: PermissionsBitField.Flags.KickMembers, name: 'Kick Members' },
    { flag: PermissionsBitField.Flags.ViewAuditLog, name: 'View Audit Log' }
  ];

  const missingPerms = corePerms.filter(p => !me?.permissions?.has(p.flag));
  if (missingPerms.length === 0) {
    score += 25;
    sections.push(`${TOGGLE_ON} **Bot Core Permissions:** All 6 critical permissions active *(+25)*`);
  } else {
    const grantedCount = corePerms.length - missingPerms.length;
    const earnedPts = Math.round((grantedCount / corePerms.length) * 25);
    score += earnedPts;
    const missingNames = missingPerms.map(p => `\`${p.name}\``).join(', ');
    sections.push(`${TOGGLE_OFF} **Bot Core Permissions:** Missing ${missingPerms.length} perm(s): ${missingNames} *(+${earnedPts})*`);
    recommendations.push(`Grant missing permissions (${missingNames}) to Tungsten's role to enable full server defense.`);
  }

  // 3. Dual Backup Roles Status (15 pts)
  let backupStatus = false;
  let t1Id = null;
  let t2Id = null;
  try {
    t1Id = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_1'").get()?.value;
    t2Id = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_role_tier_2'").get()?.value;
  } catch (_) {}

  let role1 = (t1Id && getRole(t1Id)) || findRole(r => r.name === 'Tungsten Backup Tier I' || r.name?.includes('Backup Tier I'));
  let role2 = (t2Id && getRole(t2Id)) || findRole(r => r.name === 'Tungsten Backup Tier II' || r.name?.includes('Backup Tier II'));

  if (role1 && role1.name !== 'Tungsten Backup Tier I' && role1.editable) {
    if (typeof role1.edit === 'function') role1.edit({ name: 'Tungsten Backup Tier I' }).catch(() => {});
    else if (typeof role1.setName === 'function') role1.setName('Tungsten Backup Tier I').catch(() => {});
  }
  if (role2 && role2.name !== 'Tungsten Backup Tier II' && role2.editable) {
    if (typeof role2.edit === 'function') role2.edit({ name: 'Tungsten Backup Tier II' }).catch(() => {});
    else if (typeof role2.setName === 'function') role2.setName('Tungsten Backup Tier II').catch(() => {});
  }

  // Attempt auto-fix if requested and antinuke is armed
  if (autoFix && (!role1 || !role2) && isAntinukeArmed(guild.id)) {
    try {
      await ensureDualBackupRoles(guild);
      role1 = findRole(r => r.name === 'Tungsten Backup Tier I' || r.name?.includes('Backup Tier I'));
      role2 = findRole(r => r.name === 'Tungsten Backup Tier II' || r.name?.includes('Backup Tier II'));
    } catch (_) {}
  }

  const hasBothRoles = Boolean(role1 && role2);
  const botHasBoth = hasBothRoles && Boolean(
    (me?.roles?.cache?.has && me.roles.cache.has(role1.id) && me.roles.cache.has(role2.id)) ||
    (me?.roles?.cache && typeof me.roles.cache.values === 'function' && [...me.roles.cache.values()].some(r => r.id === role1.id) && [...me.roles.cache.values()].some(r => r.id === role2.id))
  );
  const isAnchored = hasBothRoles && Math.abs(myPos - role1.position) <= 2 && Math.abs(myPos - role2.position) <= 2;

  if (hasBothRoles && botHasBoth && isAnchored) {
    score += 15;
    sections.push(`${TOGGLE_ON} **Dual Backup Roles:** Tier I & Tier II Active & Anchored *(+15)*`);
  } else if (hasBothRoles) {
    score += 8;
    sections.push(`${TOGGLE_OFF} **Dual Backup Roles:** Present but unanchored or unassigned *(+8)*`);
    recommendations.push(`Ensure \`Tungsten Backup Tier I\` and \`Tier II\` are assigned to Tungsten and anchored directly below its highest role.`);
  } else {
    sections.push(`${TOGGLE_OFF} **Dual Backup Roles:** Missing from server *(+0)*`);
    recommendations.push(`Arm Antinuke with \`!an enable\` to auto-provision Dual Backup Roles safeguard.`);
  }

  // 4. Antinuke Status & 50-Member Criteria (20 pts total)
  const armed = isAntinukeArmed(guild.id);
  if (armed) {
    score += 15;
    sections.push(`${TOGGLE_ON} **Antinuke Sentinel:** Armed & Real-Time Defense Active *(+15)*`);
  } else {
    sections.push(`${TOGGLE_OFF} **Antinuke Sentinel:** Disarmed / Inactive *(+0)*`);
    recommendations.push(`Arm Antinuke using \`!an enable\` for autonomous raid and nuker mitigation.`);
  }

  const memberCount = guild.memberCount || (guild.members?.cache?.size ?? 0);
  if (memberCount >= 50) {
    score += 5;
    sections.push(`${TOGGLE_ON} **Member Count Criteria:** \`${memberCount}\` members (meets 50+ threshold) *(+5)*`);
  } else {
    sections.push(`${TOGGLE_OFF} **Member Count Criteria:** \`${memberCount}/50\` members (under 50 threshold; requires Bot Owner/NP Manager to arm) *(+0)*`);
  }

  // 5. Automod Status & Honeypot Decoy (15 pts total)
  const filterKeys = [
    'automod_anti_invite',
    'automod_anti_link',
    'automod_anti_spam',
    'automod_anti_caps',
    'automod_anti_mention',
    'automod_anti_emoji',
    'automod_anti_zalgo',
    'automod_anti_newlines',
    'automod_anti_spoiler',
    'automod_anti_token',
    'automod_anti_scam',
    'automod_anti_nsfw',
    'automod_banned_words_enabled'
  ];

  let activeFilters = 0;
  for (const k of filterKeys) {
    try {
      const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get(k);
      if (['automod_anti_token', 'automod_anti_scam', 'automod_banned_words_enabled'].includes(k) && !row) {
        activeFilters++;
      } else if (row && (row.value === '1' || row.value === 'true')) {
        activeFilters++;
      }
    } catch (_) {}
  }

  if (activeFilters >= 5) {
    score += 8;
    sections.push(`${TOGGLE_ON} **Automod Defense:** \`${activeFilters}/${filterKeys.length}\` filters active *(+8)*`);
  } else {
    const pts = Math.min(7, activeFilters);
    score += pts;
    sections.push(`${TOGGLE_OFF} **Automod Defense:** Only \`${activeFilters}/${filterKeys.length}\` filters active *(+${pts})*`);
    recommendations.push(`Enable recommended Automod filters (Anti-Invite, Anti-Link, Anti-Spam) using \`!automod\`.`);
  }

  let hpChannel = null;
  try {
    const hpRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_honeypot_channel'").get();
    if (hpRow && hpRow.value && guild.channels?.cache) {
      hpChannel = (guild.channels.cache.get && guild.channels.cache.get(hpRow.value)) ||
        (typeof guild.channels.cache.values === 'function' && [...guild.channels.cache.values()].find(c => c.id === hpRow.value));
    }
  } catch (_) {}

  if (hpChannel) {
    score += 7;
    sections.push(`${TOGGLE_ON} **Honeypot Decoy Channel:** Active in <#${hpChannel.id}> *(+7)*`);
  } else {
    sections.push(`${TOGGLE_OFF} **Honeypot Decoy Channel:** Not configured *(+0)*`);
    recommendations.push(`Set up an automod honeypot channel using \`!automod honeypot <#channel>\` to catch raid bots.`);
  }

  // 6. Dangerous Admin Roles Exposure (10 pts)
  const dangerousRoles = allRoles.filter(r =>
    r.id !== guild.id &&
    !r.managed &&
    !r.name?.includes('Backup Tier I') &&
    !r.name?.includes('Backup Tier II') &&
    r.permissions &&
    (r.permissions.has(PermissionsBitField.Flags.Administrator) || r.permissions.has(PermissionsBitField.Flags.ManageGuild))
  );

  if (dangerousRoles.length <= 2) {
    score += 10;
    sections.push(`${TOGGLE_ON} **Administrative Role Exposure:** \`${dangerousRoles.length}\` non-bot admin role(s) (Tight privilege containment) *(+10)*`);
  } else if (dangerousRoles.length <= 5) {
    score += 5;
    sections.push(`${TOGGLE_OFF} **Administrative Role Exposure:** \`${dangerousRoles.length}\` non-bot admin role(s) (Moderate risk) *(+5)*`);
    recommendations.push(`Audit server roles and restrict \`Administrator\` / \`Manage Server\` to trusted leadership.`);
  } else {
    sections.push(`${TOGGLE_OFF} **Administrative Role Exposure:** \`${dangerousRoles.length}\` non-bot admin roles (High privilege escalation risk) *(+0)*`);
    recommendations.push(`Strip \`Administrator\` privileges from unneeded roles to prevent rogue admin attacks.`);
  }

  score = Math.max(0, Math.min(100, score));

  let grade = 'F (Critical)';

  if (score >= 95) {
    grade = 'A+ (Pristine Defense)';
  } else if (score >= 85) {
    grade = 'A (Hardened)';
  } else if (score >= 70) {
    grade = 'B (Moderate Posture)';
  } else if (score >= 50) {
    grade = 'C (Vulnerable)';
  } else {
    grade = 'D (High Risk)';
  }

  const progressBar = renderProgressBar(score, 12);

  const recsFormatted = recommendations.length > 0
    ? recommendations.map((r, i) => `\`${i + 1}.\` ${r}`).join('\n')
    : '<a:tungsten_sparkle:1567242264311369839> *Server security posture meets enterprise hardening standards. No critical vulnerabilities found.*';

  const card = createV2Card({
    title: `<a:tungsten_shield:1567242104923627574> Tungsten Security Self-Check • ${guild.name}`,
    description:
      `> Real-time diagnostic scan of bot privileges, hierarchy, dual backup anchors, and defense sentinels.\n\n` +
      `**Health Score:** \`${score}/100\` • **Rating:** \`${grade}\`\n` +
      `\`${progressBar}\` \`${score}%\`\n\n` +
      `🛡️ **Diagnostic Audit Vectors:**\n` +
      sections.join('\n') +
      `\n\n💡 **Actionable Recommendations:**\n` +
      recsFormatted,
    footerText: `Tungsten Autonomous Security Sentinel • ${guild.name}`
  });

  return { card, score, grade };
}

module.exports = {
  name: 'selfcheck',
  aliases: ['securitycheck', 'auditcheck', 'checkup', 'botcheck'],
  category: 'security',
  description: 'Audits Tungsten bot permissions, role hierarchy, dual backup roles, antinuke, and guild security posture.',
  usage: '[--fix]',
  cooldown: 5,
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages', 'EmbedLinks'],

  async execute(message, args, client, prefix) {
    const guild = message.guild;
    if (!guild) return;

    const autoFix = args.includes('--fix') || args.includes('-fix');
    const { card } = await runSelfcheckAudit(guild, client, autoFix);
    return message.reply({ embeds: [card] });
  },

  slash: new SlashCommandBuilder()
    .setName('selfcheck')
    .setDescription('Audits Tungsten bot permissions, role hierarchy, dual backup roles, antinuke, and security posture')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async executeSlash(interaction, client) {
    const guild = interaction.guild;
    if (!guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    const { card } = await runSelfcheckAudit(guild, client, false);
    return interaction.reply({ embeds: [card] });
  }
};
