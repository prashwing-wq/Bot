/**
 * Verification & Captcha Gateway Command (Node.js)
 * Implements interactive Discord Components V2 verification gates to block selfbots & raiders.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField
} = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'verification',
  aliases: ['verify', 'vcfg', 'vpanel', 'vrf'],
  category: ['whitelist', 'security'],
  description: 'Configure and deploy an interactive verification gate to block raiders and alt accounts.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[setup <@role> [#channel] | panel | disable | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` permission to configure verification.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase() || 'status';

    // 1. Setup Verification
    if (sub === 'setup' || sub === 'enable') {
      const role = message.mentions?.roles?.first() || (args[1] ? message.guild.roles.cache.get(args[1]) : null);
      if (!role) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify the verified role: \`${prefix}verification setup @VerifiedRole [#channel]\``);
      }

      const channel = message.mentions?.channels?.first() || (args[2] ? message.guild.channels.cache.get(args[2]) : null) || message.channel;

      sdb.prepare(`
        INSERT INTO verification_settings (guild_id, enabled, role_id, channel_id, mode)
        VALUES (?, 1, ?, ?, 'button')
        ON CONFLICT(guild_id) DO UPDATE SET
          enabled = 1,
          role_id = excluded.role_id,
          channel_id = excluded.channel_id
      `).run(message.guild.id, role.id, channel.id);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '<a:tungsten_ui_toggle_on:1569329685110849576>  Verification Gateway Configured',
        description:
          `> Verification gate has been <a:tungsten_ui_toggle_on:1569329685110849576> **ENABLED** for **${message.guild.name}**.\n\n` +
          `• **Target Channel:** ${channel}\n` +
          `• **Role to Assign:** ${role}\n` +
          `• **Mode:** Interactive Button Verification\n\n` +
          `-# Deploy the interactive panel with \`${prefix}verification panel\``
      });

      return message.reply({ embeds: [embed] });
    }

    // 2. Deploy Interactive Verification Panel
    if (sub === 'panel' || sub === 'deploy') {
      const row = sdb.prepare('SELECT * FROM verification_settings WHERE guild_id = ?').get(message.guild.id);
      if (!row || !row.role_id) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please setup verification first: \`${prefix}verification setup @VerifiedRole\``);
      }

      const card = createV2Card({
        color: 0x2b2d31,
        title: `Verification Gate — ${message.guild.name}`,
        description:
          `Welcome to **${message.guild.name}**!\n\n` +
          `To protect our community against selfbots, automated raids, and malicious accounts, please click the **Complete Verification** button below to unlock access to the server.\n\n` +
          `• By verifying, you agree to follow the Discord Community Guidelines and Server Rules.`,
        buttons: [
          { customId: 'verify:gate_pass', label: 'Complete Verification', style: ButtonStyle.Success, emoji: '<a:tungsten_shield:1567242104923627574>' }
        ],
        buttonTitle: 'Security Gatepass'
      });

      if (message.guild.iconURL) {
        card.setThumbnail(message.guild.iconURL());
      }

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('verify:gate_pass')
          .setLabel('Complete Verification')
          .setStyle(ButtonStyle.Success)
          .setEmoji('<a:tungsten_shield:1567242104923627574>')
      );

      const targetChannel = (row.channel_id ? message.guild.channels.cache.get(row.channel_id) : null) || message.channel;
      await targetChannel.send({ embeds: [card], components: [buttons] });

      return message.reply(`<a:tungsten_success:1567242523468890274> Verification panel deployed to ${targetChannel}.`);
    }

    // 3. Disable Verification
    if (sub === 'disable' || sub === 'off') {
      sdb.prepare('UPDATE verification_settings SET enabled = 0 WHERE guild_id = ?').run(message.guild.id);
      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Verification gate has been **DISABLED**.');
    }

    // 4. Status
    const configRow = sdb.prepare('SELECT * FROM verification_settings WHERE guild_id = ?').get(message.guild.id);
    const isGateOn = configRow ? configRow.enabled === 1 : false;
    const roleId = configRow ? configRow.role_id : null;
    const channelId = configRow ? configRow.channel_id : null;

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574>  Verification Gateway Status',
      description:
        `> Anti-Raid & Selfbot Verification Matrix.\n\n` +
        `• **Gateway Status:** ${isGateOn ? '<a:tungsten_ui_toggle_on:1569329685110849576> `ACTIVE & ARMED`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `DISABLED`'}\n` +
        `• **Verified Role:** ${roleId ? `<@&${roleId}>` : '`Not configured`'}\n` +
        `• **Verification Channel:** ${channelId ? `<#${channelId}>` : '`Current Channel`'}\n\n` +
        `**Commands:**\n` +
        `• \`${prefix}verification setup @role [#channel]\` — Configure gate\n` +
        `• \`${prefix}verification panel\` — Deploy button verification message\n` +
        `• \`${prefix}verification disable\` — Deactivate verification gate`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
