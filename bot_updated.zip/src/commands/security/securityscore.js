/**
 * Security Score & Vulnerability Audit Command (Node.js)
 * Evaluates 7 core server security vectors and computes a 0-100% defense score with fixes.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { isAntinukeArmed } = require('../../utils/antinukeEngine');
const { getServerDb } = require('../../utils/serverDb');
const { animateSequence, getSecurityScanFrames } = require('../../utils/animation');

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'securityscore',
  aliases: ['secscore', 'score', 'auditcheck'],
  category: 'security',
  description: 'Calculates server security posture score (0-100%) and details vulnerability fixes.',
  usage: '',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    const guild = message.guild;

    // Play 3-phase cyber security audit animation
    const scanFrames = getSecurityScanFrames(guild.name);
    const statusMsg = await message.reply({ embeds: [scanFrames[0]] });
    await animateSequence(statusMsg, scanFrames, { intervalMs: 450 });

    let score = 0;
    const checks = [];
    const fixes = [];

    // 1. Check @everyone permissions (25 points)
    const everyone = guild.roles.everyone;
    const dangerousPerms = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.ManageGuild,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.MentionEveryone
    ];
    const hasDangerous = dangerousPerms.some(p => everyone.permissions.has(p));
    if (!hasDangerous) {
      score += 25;
      checks.push('<a:tungsten_ui_toggle_on:1569329685110849576> **@everyone Permissions**: No dangerous permissions granted *(+25)*');
    } else {
      checks.push('<a:tungsten_ui_toggle_off:1569329677187678368> **@everyone Permissions**: Dangerous permissions found *(+0)*');
      fixes.push('• Strip Admin, Manage Roles/Channels, Ban/Kick, and Mention Everyone from `@everyone`.');
    }

    // 2. Check external bots with Administrator (15 points)
    const adminBots = guild.members.cache.filter(m => m.user.bot && m.id !== client.user.id && m.permissions.has(PermissionsBitField.Flags.Administrator));
    if (adminBots.size === 0) {
      score += 15;
      checks.push('<a:tungsten_ui_toggle_on:1569329685110849576> **External Bot Admin**: No third-party bots have Administrator *(+15)*');
    } else {
      checks.push(`<a:tungsten_ui_toggle_off:1569329677187678368> **External Bot Admin**: ${adminBots.size} bot(s) hold Administrator *(+0)*`);
      fixes.push(`• Revoke Administrator from third-party bots: ${adminBots.map(b => b.user.username).slice(0, 3).join(', ')}.`);
    }

    // 3. Verification level (15 points)
    if (guild.verificationLevel >= 2) { // Medium or higher
      score += 15;
      checks.push(`<a:tungsten_ui_toggle_on:1569329685110849576> **Verification Level**: Level ${guild.verificationLevel} Active *(+15)*`);
    } else {
      checks.push(`<a:tungsten_ui_toggle_off:1569329677187678368> **Verification Level**: Low/None *(+0)*`);
      fixes.push('• Elevate Server Verification Level to Medium (5 min account age) or higher.');
    }

    // 4. 2FA Requirement for Moderation (10 points)
    if (guild.mfaLevel === 1) { // 2FA required
      score += 10;
      checks.push('<a:tungsten_ui_toggle_on:1569329685110849576> **2FA Moderation**: Enforced for staff actions *(+10)*');
    } else {
      checks.push('<a:tungsten_ui_toggle_off:1569329677187678368> **2FA Moderation**: Disabled *(+0)*');
      fixes.push('• Enable 2FA Requirement for Moderation in Server Settings -> Safety.');
    }

    // 5. Antinuke Status (20 points)
    const antinukeActive = isAntinukeArmed(guild.id);
    if (antinukeActive) {
      score += 20;
      checks.push('<a:tungsten_ui_toggle_on:1569329685110849576> **Tungsten Antinuke**: Fully Armed & Guarding *(+20)*');
    } else {
      checks.push('<a:tungsten_ui_toggle_off:1569329677187678368> **Tungsten Antinuke**: Inactive / Disabled *(+0)*');
      fixes.push(`• Enable zero-bypass defense with \`${prefix}antinuke enable\`.`);
    }

    // 6. Automod Status (15 points)
    const sdb = getServerDb(guild.id);
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'automod_anti_invite'").get();
    const automodActive = row ? row.value === '1' : false;
    if (automodActive) {
      score += 15;
      checks.push('<a:tungsten_ui_toggle_on:1569329685110849576> **Automod Filtering**: Active & Filtering Invites *(+15)*');
    } else {
      checks.push('<a:tungsten_ui_toggle_off:1569329677187678368> **Automod Filtering**: Inactive *(+0)*');
      fixes.push(`• Turn on automated link protection with \`${prefix}automod toggle anti_invite\`.`);
    }

    // Gauge visualization
    const filled = Math.round(score / 10);
    const empty = 10 - filled;
    const bar = '▰'.repeat(filled) + '▱'.repeat(empty);

    let statusText = '<a:tungsten_ui_toggle_on:1569329685110849576> EXCELLENT';
    let embedColor = 0x00FF88;
    if (score < 50) {
      statusText = '<a:tungsten_ui_toggle_off:1569329677187678368> HIGH RISK';
      embedColor = 0xFF3B30;
    } else if (score < 80) {
      statusText = '<a:tungsten_ui_toggle_off:1569329677187678368> MODERATE VULNERABILITY';
      embedColor = 0xFEE75C;
    }

    const fixesText = fixes.length > 0 ? fixes.join('\n') : '<a:tungsten_shield:1567242104923627574> *Zero critical vulnerabilities detected. Server is fortressed!*';

    const embed = createEmbed({
      color: embedColor,
      title: `<a:tungsten_shield:1567242104923627574>  Security Posture Audit • ${guild.name}`,
      description:
        `> Comprehensive vulnerability evaluation across 6 critical threat vectors.\n\n` +
        `**Defense Score:** **${score}/100** \`[${bar}]\` **${statusText}**\n\n` +
        `**Security Vector Diagnostics:**\n` +
        checks.join('\n') +
        `\n\n**Actionable Recommendations:**\n` +
        fixesText +
        `\n\n-# Re-run anytime with \`${prefix}securityscore\``,
      footer: { text: `Evaluated for ${message.author.username} • Tungsten Sentinel Engine` }
    });

    if (guild.iconURL) {
      embed.setThumbnail(guild.iconURL());
    }

    return statusMsg.edit({ embeds: [embed] });
  }
};
