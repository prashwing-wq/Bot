/**
 * Unwhitelist Command (Node.js)
 * Removes an administrator, role, or channel from the Whitelist Matrix.
 */
const { ButtonStyle } = require('discord.js');
const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { clearImmunityCache } = require('../../utils/antinukeEngine');
const { createV2Card } = require('../../utils/componentsV2');

function parseWhitelist(raw) {
  if (!raw) return [];
  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (Array.isArray(parsed)) return parsed.map(String);
  } catch (e) {}
  return [];
}

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'unwhitelist',
  aliases: ['unwl'],
  category: 'security',
  description: 'Removes an administrator, role, or channel from the Whitelist Matrix.',
  usage: '<@user|@role|#channel|id> | channel <#channel|id>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    // Check authority: Server Owner or Extra Owners
    const sdb = getServerDb(message.guild.id);
    const isServerOwner = message.author.id === message.guild.ownerId;
    const isExtraOwner = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id);

    if (!isServerOwner && !isExtraOwner) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner** or **Extra Owners** can manage the whitelist.');
    }

    let targetInput = args[0];
    if (!targetInput) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}unwhitelist <@user|@role|#channel|id>\``);
    }

    // Check if subcommand: user/member/admin, role, channel/ch
    const firstLower = targetInput.toLowerCase();
    if (['channel', 'ch', 'user', 'member', 'admin', 'role'].includes(firstLower)) {
      targetInput = args[1];
      if (!targetInput) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}unwhitelist ${firstLower} <target>\``);
      }
    }

    const cleanId = targetInput.replace(/[<@!&#>]/g, '');
    const isRoleMention = targetInput.startsWith('<@&');
    const isChannelMention = targetInput.startsWith('<#');
    const nowSec = Math.floor(Date.now() / 1000);

    // 1. Channel Check
    const channelTarget = isChannelMention
      ? (message.mentions.channels?.first() || message.guild.channels?.cache?.get(cleanId))
      : message.guild.channels?.cache?.get(cleanId);

    if (channelTarget || isChannelMention) {
      const chId = channelTarget?.id || cleanId;
      const chName = channelTarget?.name || chId;
      const delChan = sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').run(message.guild.id, chId);
      clearImmunityCache(message.guild.id);

      if (delChan.changes === 0) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Channel <#${chId}> is not on the whitelist.`);
      }

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(message.guild.id, 'channel', chId, 'all', message.author.id, 'unwhitelist', nowSec);

      const card = createV2Card({
        color: 0xED4245,
        title: '<a:tungsten_minus:1567241276057849856>  Channel Revoked From Whitelist',
        description:
          `> Successfully removed channel **#${chName}** (<#${chId}>) from the Whitelist Matrix.\n\n` +
          `• **Channel ID:** \`${chId}\`\n` +
          `• **Immunity Status:** Revoked (All transmissions now inspected by Antinuke & Automod)\n\n` +
          `-# Re-authorize anytime with \`${prefix}wl channel <#${chId}>\``,
        footer: { text: `Revoked by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // 2. Role Check
    const roleTarget = isRoleMention
      ? (message.mentions.roles?.first() || message.guild.roles?.cache?.get(cleanId))
      : message.guild.roles?.cache?.get(cleanId);

    if (roleTarget) {
      const delRole = sdb.prepare('DELETE FROM whitelisted_roles WHERE guild_id = ? AND role_id = ?').run(message.guild.id, roleTarget.id);
      clearImmunityCache(message.guild.id);

      if (delRole.changes === 0) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Role **@${roleTarget.name}** is not on the whitelist.`);
      }

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(message.guild.id, 'role', roleTarget.id, 'all', message.author.id, 'unwhitelist', nowSec);

      const card = createV2Card({
        color: 0xED4245,
        title: '<a:tungsten_minus:1567241276057849856>  Role Revoked From Whitelist',
        description:
          `> Successfully removed role **@${roleTarget.name}** (<@&${roleTarget.id}>) from the Whitelist Matrix.\n\n` +
          `• **Role ID:** \`${roleTarget.id}\`\n` +
          `• **Immunity Status:** Revoked (All role members now subject to standard security limits)\n\n` +
          `-# To re-authorize, use \`${prefix}whitelist <@&${roleTarget.id}>\``,
        buttons: [
          { label: 'View Whitelist', style: ButtonStyle.Primary, emoji: '<a:tungsten_refresh:1567241907116187658>' },
          { label: 'Security Overview', style: ButtonStyle.Secondary, emoji: '<a:tungsten_shield:1567242104923627574>' }
        ],
        buttonTitle: 'Security Action',
        footer: { text: `Revoked by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // 3. User / ID Check
    const deletedUser = sdb.prepare('DELETE FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').run(message.guild.id, cleanId);
    const deletedRole = sdb.prepare('DELETE FROM whitelisted_roles WHERE guild_id = ? AND role_id = ?').run(message.guild.id, cleanId);
    const deletedChannel = sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').run(message.guild.id, cleanId);

    // Sync server_settings JSON
    const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get('whitelist');
    const currentWl = row ? parseWhitelist(row.value) : [];
    const updated = currentWl.filter(id => id !== cleanId);
    sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)')
      .run('whitelist', JSON.stringify(updated));
    syncServerDataToMaster(message.guild.id);

    // Clear immunity cache
    clearImmunityCache(message.guild.id);

    if (deletedUser.changes === 0 && deletedRole.changes === 0 && deletedChannel.changes === 0 && !currentWl.includes(cleanId)) {
      return message.reply('<a:tungsten_warn:1567246685082746940> That user, role, or channel is not on the whitelist.');
    }

    sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(message.guild.id, deletedChannel.changes > 0 ? 'channel' : (deletedRole.changes > 0 ? 'role' : 'user'), cleanId, 'all', message.author.id, 'unwhitelist', nowSec);

    const card = createV2Card({
      color: 0xED4245,
      title: '<a:tungsten_minus:1567241276057849856>  Revoked From Whitelist Matrix',
      description:
        `> Successfully removed target \`${cleanId}\` from the Whitelist Matrix.\n\n` +
        `• **Target ID:** \`${cleanId}\`\n` +
        `• **Immunity Status:** Revoked (Subject to all standard security limits)\n\n` +
        `-# To re-authorize, use \`${prefix}whitelist <@user|@role|#channel>\``,
      buttons: [
        { label: 'View Whitelist', style: ButtonStyle.Primary, emoji: '<a:tungsten_refresh:1567241907116187658>' },
        { label: 'Security Overview', style: ButtonStyle.Secondary, emoji: '<a:tungsten_shield:1567242104923627574>' }
      ],
      buttonTitle: 'Security Action',
      footer: { text: `Revoked by ${message.author.username}` }
    });

    return message.reply({ embeds: [card] });
  }
};
