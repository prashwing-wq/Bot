/**
 * Quarantine / Jail Command (Node.js)
 * Isolates an account with a specialized quarantine role, strips dangerous roles,
 * and preserves original role state for subsequent release.
 * Wick / Olympus / Zynrax production parity.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { quarantineUser } = require('../../utils/antinukeEngine');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['ManageRoles','SendMessages','EmbedLinks'],
  name: 'quarantine',
  aliases: ['jail', 'isolate'],
  category: 'security',
  description: 'Isolate a compromised account by stripping roles and applying strict containment overrides.',
  usage: '<@user|id> [reason]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const isServerOwner = message.author.id === message.guild.ownerId;
    const isExtraOwner = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id));

    if (!isServerOwner && !isExtraOwner) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner** or **Extra Owners** can quarantine members.');
    }

    const targetRaw = args[0];
    if (!targetRaw) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}quarantine <@user|id> [reason]\``);
    }

    const cleanId = targetRaw.replace(/[<@!>]/g, '');
    const reason = args.slice(1).join(' ') || `Manual administrative quarantine by ${message.author.username}`;

    const res = await quarantineUser(message.guild, cleanId, reason, client);
    if (!res.success) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Quarantine failed: ${res.reason || res.error}`);
    }

    const card = createV2Card({
      color: 0xED4245,
      title: '<a:tungsten_shield:1567242104923627574>  Member Quarantined & Isolated',
      description:
        `> Account <@${cleanId}> (\`${cleanId}\`) has been quarantined and isolated.\n\n` +
        `• **Original Roles Preserved:** \`${res.quarantinedRoles}\` roles saved to encrypted registry\n` +
        `• **Isolation Role:** \`@Tungsten Quarantined\` bound (All channels denied)\n` +
        `• **Communication Timeout:** 28 days applied\n` +
        `• **Reason:** ${reason}\n\n` +
        `-# To release and restore roles: \`${prefix}unquarantine <@${cleanId}>\``,
      footer: { text: `Quarantined by ${message.author.username}` }
    });

    return message.reply({ embeds: [card] });
  }
};
