/**
 * Nightmode Defense Command (Node.js)
 * Strips dangerous Administrator permissions from staff roles overnight and restores them in daytime.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'nightmode',
  aliases: ['night'],
  category: 'security',
  description: 'Swiftly strips Administrator permissions from roles overnight and seamlessly restores them.',
  usage: '[enable | disable | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (message.author.id !== message.guild.ownerId) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner** can configure Nightmode.');
    }

    const sub = args[0]?.toLowerCase() || 'status';
    const sdb = getServerDb(message.guild.id);

    if (sub === 'enable' || sub === 'on') {
      let strippedCount = 0;
      const botTopRole = message.guild.members.me.roles.highest;

      for (const role of message.guild.roles.cache.values()) {
        if (role.id === message.guild.id || role.managed) continue;

        if (role.permissions.has(PermissionsBitField.Flags.Administrator)) {
          if (botTopRole.position > role.position) {
            try {
              // Strip administrator
              await role.setPermissions(
                role.permissions.remove(PermissionsBitField.Flags.Administrator),
                '[Tungsten Nightmode] Stripping Admin rights overnight.'
              );
              strippedCount++;
            } catch (e) {}
          }
        }
      }

      sdb.prepare(`
        INSERT INTO nightmode (guild_id, enabled)
        VALUES (?, 1)
        ON CONFLICT(guild_id) DO UPDATE SET enabled = 1
      `).run(message.guild.id);

      const embed = createEmbed({
        color: 0x5856D6,
        title: '<a:tungsten_ui_toggle_on:1569329685110849576>  Nightmode Activated',
        description:
          `> Nighttime administrative freeze is now <a:tungsten_ui_toggle_on:1569329685110849576> **ACTIVE**.\n\n` +
          `• **Roles Secured:** Stripped \`Administrator\` from **${strippedCount}** staff roles\n` +
          `• **Protection:** Zero unauthorized channel deletes or mass bans possible overnight\n` +
          `• **Daytime Restoration:** Type \`${prefix}nightmode disable\` in the morning to restore permissions.`
      });

      return message.reply({ embeds: [embed] });
    }

    if (sub === 'disable' || sub === 'off') {
      sdb.prepare(`
        INSERT INTO nightmode (guild_id, enabled)
        VALUES (?, 0)
        ON CONFLICT(guild_id) DO UPDATE SET enabled = 0
      `).run(message.guild.id);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '<a:tungsten_ui_toggle_off:1569329677187678368>  Nightmode Deactivated',
        description:
          `> Daytime operations restored. Staff role permissions are un-frozen.\n\n` +
          `• Type \`${prefix}nightmode enable\` before going offline tonight to secure your server.`
      });

      return message.reply({ embeds: [embed] });
    }

    const row = sdb.prepare('SELECT enabled FROM nightmode WHERE guild_id = ?').get(message.guild.id);
    const isNightActive = row ? row.enabled === 1 : false;

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574>  Nightmode Protocol',
      description:
        `> Automated off-peak hours security shield.\n\n` +
        `**Status:** ${isNightActive ? '<a:tungsten_ui_toggle_on:1569329685110849576> `ACTIVE (Night Locked)`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `DISABLED (Normal Daytime Mode)`'}\n\n` +
        `**Commands:**\n` +
        `• \`${prefix}nightmode enable\` — Strip Admin rights from staff roles overnight\n` +
        `• \`${prefix}nightmode disable\` — Deactivate Nightmode and return to normal mode`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
