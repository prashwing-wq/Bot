/**
 * Unquarantine / Unjail Command (Node.js)
 * Releases an account from quarantine isolation and restores their preserved roles.
 * Wick / Olympus / Zynrax production parity.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { unquarantineUser } = require('../../utils/antinukeEngine');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['ManageRoles','SendMessages','EmbedLinks'],
  name: 'unquarantine',
  aliases: ['unjail', 'release'],
  category: 'security',
  description: 'Release an account from quarantine isolation and restore original roles.',
  usage: '<@user|id>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const isServerOwner = message.author.id === message.guild.ownerId;
    const isExtraOwner = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id));

    if (!isServerOwner && !isExtraOwner) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner** or **Extra Owners** can release quarantined members.');
    }

    const targetRaw = args[0];
    if (!targetRaw) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}unquarantine <@user|id>\``);
    }

    const cleanId = targetRaw.replace(/[<@!>]/g, '');
    const res = await unquarantineUser(message.guild, cleanId, client);
    if (!res.success) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Release failed: ${res.reason || res.error}`);
    }

    const card = createV2Card({
      color: 0x2ECC71,
      title: '<a:tungsten_success:1567242523468890274>  Quarantine Lifted & Roles Restored',
      description:
        `> Successfully released <@${cleanId}> from quarantine isolation.\n\n` +
        `• **Isolation Role:** Revoked\n` +
        `• **Original Roles:** Restored from registry\n` +
        `• **Account Status:** Active & Normal`,
      footer: { text: `Unquarantined by ${message.author.username}` }
    });

    return message.reply({ embeds: [card] });
  }
};
