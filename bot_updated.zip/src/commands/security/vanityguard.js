/**
 * Vanity URL Guard Command (Node.js)
 * Locks the server custom vanity URL and auto-reclaims it if hijacked.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'vanityguard',
  aliases: ['vanity', 'antivanity'],
  category: 'security',
  description: 'Lock and protect server Vanity URL with instant auto-reclaim against theft.',
  usage: '[enable <code> | disable | status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (message.author.id !== message.guild.ownerId) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner** can configure Vanity Guard.');
    }

    const sdb = getServerDb(message.guild.id);
    const sub = args[0]?.toLowerCase() || 'status';

    if (sub === 'enable' || sub === 'set') {
      const code = args[1] || message.guild.vanityURLCode;
      if (!code) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify the vanity code to lock: \`${prefix}vanityguard enable <code_here>\``);
      }

      sdb.prepare(`
        INSERT INTO vanity_guard (guild_id, enabled, vanity_code, action)
        VALUES (?, 1, ?, 'ban')
        ON CONFLICT(guild_id) DO UPDATE SET enabled = 1, vanity_code = excluded.vanity_code
      `).run(message.guild.id, code);

      const embed = createEmbed({
        color: 0x00FF88,
        title: '<a:tungsten_ui_toggle_on:1569329685110849576>  Vanity Guard Armed',
        description:
          `> Server vanity URL locked to: **discord.gg/${code}**\n\n` +
          `• **Monitoring:** Active 24/7\n` +
          `• **Countermeasure:** Immediate BAN of any unauthorized admin attempting to change vanity\n` +
          `• **Auto-Reclaim:** Tungsten will instantly send REST API requests to reclaim \`${code}\` if tampered with.`
      });

      return message.reply({ embeds: [embed] });
    }

    if (sub === 'disable' || sub === 'off') {
      sdb.prepare(`
        INSERT INTO vanity_guard (guild_id, enabled)
        VALUES (?, 0)
        ON CONFLICT(guild_id) DO UPDATE SET enabled = 0
      `).run(message.guild.id);

      return message.reply('<a:tungsten_ui_toggle_off:1569329677187678368> Vanity Guard has been **DISABLED** for this server.');
    }

    const row = sdb.prepare('SELECT enabled, vanity_code FROM vanity_guard WHERE guild_id = ?').get(message.guild.id);
    const isArmed = row ? row.enabled === 1 : false;
    const code = row ? row.vanity_code : (message.guild.vanityURLCode || 'None');

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574>  Vanity URL Protection Matrix',
      description:
        `> High-priority protection against vanity URL sniping and malicious transfers.\n\n` +
        `• **Guard Status:** ${isArmed ? '<a:tungsten_ui_toggle_on:1569329685110849576> `ARMED & ACTIVE`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `DISABLED`'}\n` +
        `• **Locked Vanity Code:** \`${code}\`\n` +
        `• **Live Server Vanity:** \`${message.guild.vanityURLCode || 'None'}\`\n\n` +
        `**Setup:**\n` +
        `• \`${prefix}vanityguard enable <code>\` — Lock your server vanity\n` +
        `• \`${prefix}vanityguard disable\` — Turn off protection`
    });

    return message.reply({ embeds: [embed] });
  }
};
