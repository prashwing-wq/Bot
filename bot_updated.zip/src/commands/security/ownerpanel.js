/**
 * Tungsten Bot Owner Control Panel (Node.js)
 * Master operational dashboard strictly restricted to verified Bot Owners (Section 4.18).
 * Ephemeral only; replaces raw chat SQL execution with safe read-only explorers & diagnostics.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  MessageFlags
} = require('discord.js');
const os = require('os');
const { isOwner } = require('../../utils/tools');
const { getMasterDb, _DB_CACHE } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'ownerpanel',
  aliases: ['op', 'botcontrol', 'masterpanel'],
  category: 'owner',
  description: 'Master Control & Diagnostic Hub for verified Bot Owners.',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('This command can be executed only by Bot Owner.');
    }

    const payload = buildOwnerPanelPayload(client, message.author.id);
    return message.reply(payload);
  },
  buildOwnerPanelPayload
};

function buildOwnerPanelPayload(client, userId) {
  const uptimeSec = Math.floor(process.uptime());
  const days = Math.floor(uptimeSec / 86400);
  const hours = Math.floor((uptimeSec % 86400) / 3600);
  const minutes = Math.floor((uptimeSec % 3600) / 60);
  const seconds = uptimeSec % 60;
  const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

  const memUsage = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);
  const heapUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
  const ping = Math.round(client.ws.ping) || 0;
  const dbHandles = _DB_CACHE ? _DB_CACHE.size : 0;

  let ownerCount = config.OWNER_IDS.length;
  let blacklistCount = 0;
  try {
    const mdb = getMasterDb();
    const row = mdb.prepare('SELECT COUNT(*) as c FROM blacklist_users').get();
    if (row) blacklistCount = row.c;
  } catch (_) {}

  const desc =
    `> **Tungsten Bot Infrastructure & Diagnostics Sentinel**\n` +
    `> Real-time system health, database metrics, and global fleet controls.\n\n` +
    `### Node.js Telemetry\n` +
    `• **Uptime:** \`${uptimeStr}\`\n` +
    `• **Gateway Ping:** \`${ping}ms\`\n` +
    `• **Memory Footprint:** \`${memUsage} MB\` (Heap: \`${heapUsage} MB\`)\n` +
    `• **Open DB Handles:** \`${dbHandles}\` active cached handles\n` +
    `• **Servicing Fleet:** \`${client.guilds.cache.size}\` guilds • \`${client.users.cache.size}\` users\n\n` +
    `### Security & Governance\n` +
    `• **Bot Owners Enrolled:** \`${ownerCount}\`\n` +
    `• **Global Blacklisted Users:** \`${blacklistCount}\`\n` +
    `• **Master Database:** \`db/tungsten.db\` (WAL Mode)\n\n` +
    `*All database explorer operations are strictly read-only with parameter masking.*`;

  const card = createV2Card({
    color: config.COLORS.PRIMARY,
    title: '<a:tungsten_shield:1567242104923627574> Tungsten Bot Owner Master Control Panel',
    description: desc
  });

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`op:backup:now:${userId}`)
      .setLabel('Backup Database')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`op:db:integrity:${userId}`)
      .setLabel('Integrity Check')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`op:refresh:now:${userId}`)
      .setLabel('Refresh')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`op:dismiss:now:${userId}`)
      .setLabel('Dismiss')
      .setEmoji('<a:tungsten_sweep:1567242656281657414>')
      .setStyle(ButtonStyle.Danger)
  );

  return {
    embeds: [card],
    components: [row1]
  };
}
