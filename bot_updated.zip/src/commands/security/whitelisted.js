/**
 * Whitelisted Users & Channels Directory Command (Node.js)
 * Displays all authorized administrators, extra owners, whitelisted roles, and whitelisted channels.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'whitelisted',
  aliases: ['wlist', 'trustlist', 'trusted'],
  category: ['whitelist', 'security'],
  description: 'View the directory of all whitelisted administrators, roles, channels, and Extra Owners in the server.',
  usage: '',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const nowSec = Math.floor(Date.now() / 1000);

    // 1. Fetch extra owners
    const eoRows = sdb.prepare('SELECT owner_id FROM extraowners WHERE guild_id = ?').all(message.guild.id);
    const extraOwnersList = eoRows.length > 0
      ? eoRows.map(r => `• <@${r.owner_id}> (\`${r.owner_id}\`)`).join('\n')
      : '*No Extra Owners designated.*';

    // 2. Fetch whitelisted users
    const wlRows = sdb.prepare('SELECT user_id, action, expires_at FROM whitelisted_users WHERE guild_id = ?').all(message.guild.id);
    let whitelistedList = '';
    if (wlRows.length === 0) {
      whitelistedList = '*No administrators whitelisted yet.*';
    } else {
      whitelistedList = wlRows.map(r => {
        let expText = '';
        if (r.expires_at) {
          expText = r.expires_at <= nowSec ? ' • `[EXPIRED]`' : ` • Expires <t:${r.expires_at}:R>`;
        }
        return `• <@${r.user_id}> (\`${r.user_id}\`) — Action: \`${r.action}\`${expText}`;
      }).join('\n');
    }

    // 3. Fetch whitelisted roles
    const roleRows = sdb.prepare('SELECT role_id, action, expires_at FROM whitelisted_roles WHERE guild_id = ?').all(message.guild.id);
    let roleList = '';
    if (roleRows.length === 0) {
      roleList = '*No roles whitelisted yet.*';
    } else {
      roleList = roleRows.map(r => {
        let expText = '';
        if (r.expires_at) {
          expText = r.expires_at <= nowSec ? ' • `[EXPIRED]`' : ` • Expires <t:${r.expires_at}:R>`;
        }
        return `• <@&${r.role_id}> (\`${r.role_id}\`) — Action: \`${r.action}\`${expText}`;
      }).join('\n');
    }

    // 4. Fetch whitelisted channels
    const chanRows = sdb.prepare('SELECT channel_id, scope FROM whitelisted_channels WHERE guild_id = ?').all(message.guild.id);
    let channelList = '';
    if (chanRows.length === 0) {
      channelList = '*No channels whitelisted yet.*';
    } else {
      channelList = chanRows.map(r => `• <#${r.channel_id}> (\`${r.channel_id}\`) — Scope: \`${r.scope}\``).join('\n');
    }

    const embed = createEmbed({
      title: `<a:tungsten_shield:1567242104923627574>  Authorized Personnel & Channels Directory • ${message.guild.name}`,
      description:
        `> Complete trust hierarchy recognized by Tungsten Zero-Bypass Antinuke & Automod.\n\n` +
        `<a:tungsten_crown:1567238355463176334> **Primary Server Owner:**\n• <@${message.guild.ownerId}> (\`${message.guild.ownerId}\`)\n\n` +
        `<a:tungsten_crown:1567238355463176334> **Extra Owners (Immunity):**\n${extraOwnersList}\n\n` +
        `<a:tungsten_users:1567246628606185502> **Whitelisted Administrators:**\n${whitelistedList}\n\n` +
        `<a:tungsten_shield:1567242104923627574> **Whitelisted Roles:**\n${roleList}\n\n` +
        `<a:tungsten_gear:1567239932970406012> **Whitelisted Channels:**\n${channelList}\n\n` +
        `-# Manage using \`${prefix}wl <@user|@role|#channel>\` or \`${prefix}wl channel <#channel>\``,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
