/**
 * Ignore System Command (Node.js)
 * Configure command, channel, user, and bypass role ignores for granular bot access control.
 */
const { PermissionsBitField, SlashCommandBuilder } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { EMOJIS } = require('../../utils/emojis');

function initIgnoreTable(sdb) {
  sdb.prepare(`
    CREATE TABLE IF NOT EXISTS cmd_ignores (
      guild_id TEXT,
      type TEXT,
      target_id TEXT,
      PRIMARY KEY(guild_id, type, target_id)
    )
  `).run();
}

module.exports = {
  name: 'ignore',
  aliases: ['cmdignore', 'botignore', 'channelignore', 'ignores'],
  category: 'security',
  description: 'Configure command, channel, user, and bypass ignores.',
  usage: '[show | command <add|remove|show> <cmd> | channel <add|remove|show> <#ch> | user <add|remove|show> <@user> | bypass <add|remove|show> <@role> | reset]',
  cooldown: 3,
  permissions: ['Administrator'],
  botPermissions: [],

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            description: `${EMOJIS.ERROR} You need **Administrator** permission to configure ignores.`
          })
        ]
      });
    }

    const sdb = getServerDb(message.guild.id);
    initIgnoreTable(sdb);

    const sub = args[0]?.toLowerCase() || 'show';

    // ─────────────────────────────────────────────────────────────
    // 1. COMMAND IGNORES
    // ─────────────────────────────────────────────────────────────
    if (sub === 'command' || sub === 'cmd') {
      const action = args[1]?.toLowerCase() || 'show';
      const cmdName = args[2]?.toLowerCase();

      if (action === 'add') {
        if (!cmdName) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore command add <command_name>\``
              })
            ]
          });
        }

        if (cmdName === 'ignore' || cmdName === 'antinuke' || cmdName === 'help') {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.ERROR} Essential administration command \`${cmdName}\` cannot be ignored.`
              })
            ]
          });
        }

        const exists = sdb.prepare('SELECT 1 FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').get(message.guild.id, 'command', cmdName);
        if (exists) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} Command \`${cmdName}\` is already in the ignore list.`
              })
            ]
          });
        }

        sdb.prepare('INSERT INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(message.guild.id, 'command', cmdName);
        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} Command Ignored`,
          description: `Command \`${cmdName}\` is now ignored in this server.\n` +
            `• Regular members cannot execute this command.\n` +
            `• Administrators and members with bypass roles remain exempt.`
        });
        return message.reply({ embeds: [embed] });
      }

      if (action === 'remove' || action === 'delete' || action === 'del') {
        if (!cmdName) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore command remove <command_name>\``
              })
            ]
          });
        }

        const res = sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(message.guild.id, 'command', cmdName);
        if (res.changes === 0) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} Command \`${cmdName}\` was not ignored.`
              })
            ]
          });
        }

        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} Command Unignored`,
          description: `Command \`${cmdName}\` has been removed from the ignore list.`
        });
        return message.reply({ embeds: [embed] });
      }

      // show commands
      const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(message.guild.id, 'command');
      const list = rows.length > 0 ? rows.map(r => `• \`${r.target_id}\``).join('\n') : '`None`';
      const embed = createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.SHIELD} Ignored Commands (${rows.length})`,
        description: list
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. CHANNEL IGNORES
    // ─────────────────────────────────────────────────────────────
    if (sub === 'channel' || sub === 'ch') {
      const action = args[1]?.toLowerCase() || 'show';
      const rawTarget = args[2];

      if (action === 'add') {
        if (!rawTarget) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore channel add <#channel|id>\``
              })
            ]
          });
        }

        const channelId = rawTarget.replace(/[<#>]/g, '').trim();
        const channel = message.guild.channels.cache.get(channelId);
        if (!channel) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.ERROR} Could not find channel with ID/mention \`${rawTarget}\`.`
              })
            ]
          });
        }

        const exists = sdb.prepare('SELECT 1 FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').get(message.guild.id, 'channel', channel.id);
        if (exists) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} Channel <#${channel.id}> is already ignored.`
              })
            ]
          });
        }

        sdb.prepare('INSERT INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(message.guild.id, 'channel', channel.id);
        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} Channel Ignored`,
          description: `Channel <#${channel.id}> (\`${channel.name}\`) is now ignored.\n` +
            `• Bot commands will be muted here for regular members.`
        });
        return message.reply({ embeds: [embed] });
      }

      if (action === 'remove' || action === 'delete' || action === 'del') {
        if (!rawTarget) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore channel remove <#channel|id>\``
              })
            ]
          });
        }

        const channelId = rawTarget.replace(/[<#>]/g, '').trim();
        const res = sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(message.guild.id, 'channel', channelId);
        if (res.changes === 0) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} Channel <#${channelId}> was not in the ignore list.`
              })
            ]
          });
        }

        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} Channel Unignored`,
          description: `Channel <#${channelId}> has been removed from the ignore list.`
        });
        return message.reply({ embeds: [embed] });
      }

      // show channels
      const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(message.guild.id, 'channel');
      const list = rows.length > 0 ? rows.map(r => `• <#${r.target_id}> (\`${r.target_id}\`)`).join('\n') : '`None`';
      const embed = createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.SHIELD} Ignored Channels (${rows.length})`,
        description: list
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. USER IGNORES
    // ─────────────────────────────────────────────────────────────
    if (sub === 'user' || sub === 'member') {
      const action = args[1]?.toLowerCase() || 'show';
      const rawTarget = args[2];

      if (action === 'add') {
        if (!rawTarget) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore user add <@user|id>\``
              })
            ]
          });
        }

        const userId = rawTarget.replace(/[<@!>]/g, '').trim();
        if (userId === message.guild.ownerId || isOwner(userId)) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.ERROR} You cannot ignore the Server Owner or Bot Owners.`
              })
            ]
          });
        }

        const exists = sdb.prepare('SELECT 1 FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').get(message.guild.id, 'user', userId);
        if (exists) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} User <@${userId}> is already ignored.`
              })
            ]
          });
        }

        sdb.prepare('INSERT INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(message.guild.id, 'user', userId);
        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} User Ignored`,
          description: `User <@${userId}> (\`${userId}\`) is now ignored.\n` +
            `• Tungsten will silently drop all command invocations from this user.`
        });
        return message.reply({ embeds: [embed] });
      }

      if (action === 'remove' || action === 'delete' || action === 'del') {
        if (!rawTarget) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore user remove <@user|id>\``
              })
            ]
          });
        }

        const userId = rawTarget.replace(/[<@!>]/g, '').trim();
        const res = sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(message.guild.id, 'user', userId);
        if (res.changes === 0) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} User <@${userId}> was not in the ignore list.`
              })
            ]
          });
        }

        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} User Unignored`,
          description: `User <@${userId}> has been removed from the ignore list.`
        });
        return message.reply({ embeds: [embed] });
      }

      // show users
      const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(message.guild.id, 'user');
      const list = rows.length > 0 ? rows.map(r => `• <@${r.target_id}> (\`${r.target_id}\`)`).join('\n') : '`None`';
      const embed = createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.SHIELD} Ignored Users (${rows.length})`,
        description: list
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. BYPASS ROLES
    // ─────────────────────────────────────────────────────────────
    if (sub === 'bypass' || sub === 'exempt') {
      const action = args[1]?.toLowerCase() || 'show';
      const rawTarget = args[2];

      if (action === 'add') {
        if (!rawTarget) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore bypass add <@role|id>\``
              })
            ]
          });
        }

        const roleId = rawTarget.replace(/[<@&>]/g, '').trim();
        const role = message.guild.roles.cache.get(roleId);
        if (!role) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.ERROR} Could not find role with ID/mention \`${rawTarget}\`.`
              })
            ]
          });
        }

        const exists = sdb.prepare('SELECT 1 FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').get(message.guild.id, 'bypass', role.id);
        if (exists) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} Role <@&${role.id}> is already configured as a bypass role.`
              })
            ]
          });
        }

        sdb.prepare('INSERT INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(message.guild.id, 'bypass', role.id);
        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} Bypass Role Added`,
          description: `Role <@&${role.id}> (\`${role.name}\`) is now exempt from command and channel ignores.`
        });
        return message.reply({ embeds: [embed] });
      }

      if (action === 'remove' || action === 'delete' || action === 'del') {
        if (!rawTarget) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xED4245,
                description: `${EMOJIS.WARNING} Usage: \`${prefix}ignore bypass remove <@role|id>\``
              })
            ]
          });
        }

        const roleId = rawTarget.replace(/[<@&>]/g, '').trim();
        const res = sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(message.guild.id, 'bypass', roleId);
        if (res.changes === 0) {
          return message.reply({
            embeds: [
              createEmbed({
                color: 0xFEE75C,
                description: `${EMOJIS.WARNING} Role <@&${roleId}> was not in the bypass list.`
              })
            ]
          });
        }

        const embed = createEmbed({
          color: 0x57F287,
          title: `${EMOJIS.SUCCESS} Bypass Role Removed`,
          description: `Role <@&${roleId}> has been removed from bypass roles.`
        });
        return message.reply({ embeds: [embed] });
      }

      // show bypass
      const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(message.guild.id, 'bypass');
      const list = rows.length > 0 ? rows.map(r => `• <@&${r.target_id}> (\`${r.target_id}\`)`).join('\n') : '`None`';
      const embed = createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.SHIELD} Ignore Bypass Roles (${rows.length})`,
        description: list
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. RESET
    // ─────────────────────────────────────────────────────────────
    if (sub === 'reset' || sub === 'clear') {
      sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ?').run(message.guild.id);
      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SUCCESS} Ignores Reset`,
        description: 'All command, channel, user, and bypass ignores have been cleared for this server.'
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 6. SHOW ALL (DEFAULT)
    // ─────────────────────────────────────────────────────────────
    const allRows = sdb.prepare('SELECT type, target_id FROM cmd_ignores WHERE guild_id = ?').all(message.guild.id);

    const cmds = allRows.filter(r => r.type === 'command').map(r => `\`${r.target_id}\``);
    const chs = allRows.filter(r => r.type === 'channel').map(r => `<#${r.target_id}>`);
    const usrs = allRows.filter(r => r.type === 'user').map(r => `<@${r.target_id}>`);
    const byps = allRows.filter(r => r.type === 'bypass').map(r => `<@&${r.target_id}>`);

    const embed = createEmbed({
      color: 0x5865F2,
      title: `${EMOJIS.SHIELD} Server Ignore Configuration`,
      description:
        `> Granular suppression of command execution across server vectors.\n\n` +
        `• **Ignored Commands (${cmds.length}):** ${cmds.length > 0 ? cmds.join(', ') : '`None`'}\n` +
        `• **Ignored Channels (${chs.length}):** ${chs.length > 0 ? chs.join(', ') : '`None`'}\n` +
        `• **Ignored Users (${usrs.length}):** ${usrs.length > 0 ? usrs.join(', ') : '`None`'}\n` +
        `• **Bypass Roles (${byps.length}):** ${byps.length > 0 ? byps.join(', ') : '`None`'}\n\n` +
        `**Management Commands:**\n` +
        `• \`${prefix}ignore command <add|remove|show> <cmd>\`\n` +
        `• \`${prefix}ignore channel <add|remove|show> <#ch>\`\n` +
        `• \`${prefix}ignore user <add|remove|show> <@user>\`\n` +
        `• \`${prefix}ignore bypass <add|remove|show> <@role>\`\n` +
        `• \`${prefix}ignore reset\` — Clear all ignores`
    });
    return message.reply({ embeds: [embed] });
  },

  slash: new SlashCommandBuilder()
    .setName('ignore')
    .setDescription('Configure command, channel, user, and bypass ignores.')
    .addSubcommand(sub =>
      sub
        .setName('show')
        .setDescription('Display active command, channel, user, and bypass ignores.')
    )
    .addSubcommand(sub =>
      sub
        .setName('command')
        .setDescription('Manage command ignores.')
        .addStringOption(opt =>
          opt
            .setName('action')
            .setDescription('Action')
            .setRequired(true)
            .addChoices(
              { name: 'Add', value: 'add' },
              { name: 'Remove', value: 'remove' },
              { name: 'Show', value: 'show' }
            )
        )
        .addStringOption(opt => opt.setName('command_name').setDescription('Command name').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('channel')
        .setDescription('Manage channel ignores.')
        .addStringOption(opt =>
          opt
            .setName('action')
            .setDescription('Action')
            .setRequired(true)
            .addChoices(
              { name: 'Add', value: 'add' },
              { name: 'Remove', value: 'remove' },
              { name: 'Show', value: 'show' }
            )
        )
        .addChannelOption(opt => opt.setName('target_channel').setDescription('Target channel').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('user')
        .setDescription('Manage user ignores.')
        .addStringOption(opt =>
          opt
            .setName('action')
            .setDescription('Action')
            .setRequired(true)
            .addChoices(
              { name: 'Add', value: 'add' },
              { name: 'Remove', value: 'remove' },
              { name: 'Show', value: 'show' }
            )
        )
        .addUserOption(opt => opt.setName('target_user').setDescription('Target user').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('bypass')
        .setDescription('Manage ignore bypass roles.')
        .addStringOption(opt =>
          opt
            .setName('action')
            .setDescription('Action')
            .setRequired(true)
            .addChoices(
              { name: 'Add', value: 'add' },
              { name: 'Remove', value: 'remove' },
              { name: 'Show', value: 'show' }
            )
        )
        .addRoleOption(opt => opt.setName('target_role').setDescription('Exempt role').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('reset')
        .setDescription('Reset and clear all server ignores.')
    ),

  async executeSlash(interaction, client) {
    if (!interaction.guild) return;

    if (!hasPerm(interaction.member, PermissionsBitField.Flags.Administrator)) {
      return interaction.reply({
        content: `${EMOJIS.ERROR} You need **Administrator** permission to configure ignores.`,
        ephemeral: true
      });
    }

    const sdb = getServerDb(interaction.guild.id);
    initIgnoreTable(sdb);

    const sub = interaction.options.getSubcommand();

    if (sub === 'reset') {
      sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ?').run(interaction.guild.id);
      return interaction.reply({ content: `${EMOJIS.SUCCESS} All ignores cleared for this server.`, ephemeral: true });
    }

    if (sub === 'command') {
      const act = interaction.options.getString('action');
      const cmdName = interaction.options.getString('command_name')?.toLowerCase();
      if (act === 'show') {
        const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(interaction.guild.id, 'command');
        return interaction.reply({ content: `Ignored commands: ${rows.map(r => r.target_id).join(', ') || 'None'}`, ephemeral: true });
      }
      if (!cmdName) {
        return interaction.reply({ content: 'Please provide a command name.', ephemeral: true });
      }
      if (act === 'add') {
        if (cmdName === 'ignore' || cmdName === 'antinuke' || cmdName === 'help') {
          return interaction.reply({ content: 'Cannot ignore essential administration commands.', ephemeral: true });
        }
        sdb.prepare('INSERT OR IGNORE INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(interaction.guild.id, 'command', cmdName);
        return interaction.reply({ content: `Command \`${cmdName}\` is now ignored.`, ephemeral: true });
      }
      if (act === 'remove') {
        sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(interaction.guild.id, 'command', cmdName);
        return interaction.reply({ content: `Command \`${cmdName}\` unignored.`, ephemeral: true });
      }
    }

    if (sub === 'channel') {
      const act = interaction.options.getString('action');
      const ch = interaction.options.getChannel('target_channel');
      if (act === 'show') {
        const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(interaction.guild.id, 'channel');
        return interaction.reply({ content: `Ignored channels: ${rows.map(r => `<#${r.target_id}>`).join(', ') || 'None'}`, ephemeral: true });
      }
      if (!ch) return interaction.reply({ content: 'Please select a channel.', ephemeral: true });
      if (act === 'add') {
        sdb.prepare('INSERT OR IGNORE INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(interaction.guild.id, 'channel', ch.id);
        return interaction.reply({ content: `Channel <#${ch.id}> is now ignored.`, ephemeral: true });
      }
      if (act === 'remove') {
        sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(interaction.guild.id, 'channel', ch.id);
        return interaction.reply({ content: `Channel <#${ch.id}> unignored.`, ephemeral: true });
      }
    }

    if (sub === 'user') {
      const act = interaction.options.getString('action');
      const u = interaction.options.getUser('target_user');
      if (act === 'show') {
        const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(interaction.guild.id, 'user');
        return interaction.reply({ content: `Ignored users: ${rows.map(r => `<@${r.target_id}>`).join(', ') || 'None'}`, ephemeral: true });
      }
      if (!u) return interaction.reply({ content: 'Please select a user.', ephemeral: true });
      if (act === 'add') {
        if (u.id === interaction.guild.ownerId || isOwner(u.id)) {
          return interaction.reply({ content: 'Cannot ignore server owner or bot owners.', ephemeral: true });
        }
        sdb.prepare('INSERT OR IGNORE INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(interaction.guild.id, 'user', u.id);
        return interaction.reply({ content: `User <@${u.id}> is now ignored.`, ephemeral: true });
      }
      if (act === 'remove') {
        sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(interaction.guild.id, 'user', u.id);
        return interaction.reply({ content: `User <@${u.id}> unignored.`, ephemeral: true });
      }
    }

    if (sub === 'bypass') {
      const act = interaction.options.getString('action');
      const r = interaction.options.getRole('target_role');
      if (act === 'show') {
        const rows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(interaction.guild.id, 'bypass');
        return interaction.reply({ content: `Bypass roles: ${rows.map(row => `<@&${row.target_id}>`).join(', ') || 'None'}`, ephemeral: true });
      }
      if (!r) return interaction.reply({ content: 'Please select a role.', ephemeral: true });
      if (act === 'add') {
        sdb.prepare('INSERT OR IGNORE INTO cmd_ignores (guild_id, type, target_id) VALUES (?, ?, ?)').run(interaction.guild.id, 'bypass', r.id);
        return interaction.reply({ content: `Role <@&${r.id}> is now exempt from ignores.`, ephemeral: true });
      }
      if (act === 'remove') {
        sdb.prepare('DELETE FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').run(interaction.guild.id, 'bypass', r.id);
        return interaction.reply({ content: `Role <@&${r.id}> removed from bypass roles.`, ephemeral: true });
      }
    }

    // show all
    const allRows = sdb.prepare('SELECT type, target_id FROM cmd_ignores WHERE guild_id = ?').all(interaction.guild.id);
    const cmds = allRows.filter(r => r.type === 'command').map(r => r.target_id).join(', ') || 'None';
    const chs = allRows.filter(r => r.type === 'channel').map(r => `<#${r.target_id}>`).join(', ') || 'None';
    const usrs = allRows.filter(r => r.type === 'user').map(r => `<@${r.target_id}>`).join(', ') || 'None';
    const byps = allRows.filter(r => r.type === 'bypass').map(r => `<@&${r.target_id}>`).join(', ') || 'None';

    return interaction.reply({
      content: `**Ignored Commands:** ${cmds}\n**Ignored Channels:** ${chs}\n**Ignored Users:** ${usrs}\n**Bypass Roles:** ${byps}`,
      ephemeral: true
    });
  }
};
