/**
 * Anti-Bot Protection & Bot Whitelist Sentinel (Node.js)
 * Automatically halts unauthorized bot additions and maintains trusted bot whitelists.
 */
const { PermissionsBitField, SlashCommandBuilder } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { EMOJIS } = require('../../utils/emojis');

function getAntibotSettings(sdb, guildId) {
  sdb.prepare(`
    CREATE TABLE IF NOT EXISTS antibot_settings (
      guild_id TEXT PRIMARY KEY,
      enabled INTEGER DEFAULT 1,
      punishment TEXT DEFAULT 'kick',
      whitelisted_bots TEXT DEFAULT '[]'
    )
  `).run();

  let row = sdb.prepare('SELECT * FROM antibot_settings WHERE guild_id = ?').get(guildId);
  if (!row) {
    sdb.prepare(`
      INSERT INTO antibot_settings (guild_id, enabled, punishment, whitelisted_bots)
      VALUES (?, 1, 'kick', '[]')
    `).run(guildId);
    row = { guild_id: guildId, enabled: 1, punishment: 'kick', whitelisted_bots: '[]' };
  }
  return row;
}

module.exports = {
  name: 'antibot',
  aliases: ['antibots', 'botguard', 'botdefense'],
  category: 'security',
  description: 'Manage AntiBot protection and bot whitelists.',
  usage: '[config | enable | disable | action <kick|ban> | add <bot_id> | remove <bot_id> | reset]',
  cooldown: 3,
  permissions: ['Administrator'],
  botPermissions: ['KickMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            description: `${EMOJIS.ERROR} You need **Administrator** permission to configure AntiBot.`
          })
        ]
      });
    }

    const sdb = getServerDb(message.guild.id);
    const settings = getAntibotSettings(sdb, message.guild.id);

    let sub = args[0]?.toLowerCase() || 'config';

    // Support syntax: "antibot whitelist add <id>" or "antibot whitelist remove <id>"
    if (sub === 'whitelist') {
      const nested = args[1]?.toLowerCase();
      if (nested === 'add' || nested === 'remove' || nested === 'show' || nested === 'list') {
        sub = nested;
        args = [sub, ...args.slice(2)];
      } else {
        sub = 'config';
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 1. ENABLE / ON
    // ─────────────────────────────────────────────────────────────
    if (sub === 'enable' || sub === 'on') {
      sdb.prepare('UPDATE antibot_settings SET enabled = 1 WHERE guild_id = ?').run(message.guild.id);
      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SHIELD} AntiBot Sentinel Armed`,
        description:
          `AntiBot Sentinel is now ${EMOJIS.UI_TOGGLE_ON} **ACTIVE**.\n\n` +
          `• **Enforcement:** Unauthorized bot invites will be automatically intercepted.\n` +
          `• **Punishment:** \`${settings.punishment.toUpperCase()}\`\n` +
          `• **Whitelist:** Only bot IDs explicitly whitelisted via \`${prefix}antibot add <bot_id>\` may enter.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. DISABLE / OFF
    // ─────────────────────────────────────────────────────────────
    if (sub === 'disable' || sub === 'off') {
      sdb.prepare('UPDATE antibot_settings SET enabled = 0 WHERE guild_id = ?').run(message.guild.id);
      const embed = createEmbed({
        color: 0xED4245,
        title: `${EMOJIS.WARNING} AntiBot Sentinel Disarmed`,
        description: `AntiBot Sentinel is now ${EMOJIS.UI_TOGGLE_OFF} **DISABLED**.\n\n` +
          `${EMOJIS.WARNING} New bot joins will not be checked or quarantined by the AntiBot engine.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. ACTION / PUNISHMENT
    // ─────────────────────────────────────────────────────────────
    if (sub === 'action' || sub === 'punishment') {
      const act = args[1]?.toLowerCase();
      if (!['kick', 'ban'].includes(act)) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.WARNING} Please specify a valid punishment: \`kick\` or \`ban\`.\n` +
                `Example: \`${prefix}antibot action kick\``
            })
          ]
        });
      }

      sdb.prepare('UPDATE antibot_settings SET punishment = ? WHERE guild_id = ?').run(act, message.guild.id);
      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SUCCESS} AntiBot Punishment Updated`,
        description: `Unauthorized bots will now be **${act.toUpperCase()}ED** immediately upon arrival.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. ADD BOT TO WHITELIST
    // ─────────────────────────────────────────────────────────────
    if (sub === 'add') {
      const raw = args[1];
      if (!raw) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.WARNING} Usage: \`${prefix}antibot add <bot_id>\``
            })
          ]
        });
      }

      const botId = raw.replace(/[<@!>]/g, '').trim();
      if (!/^\d{17,20}$/.test(botId)) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.ERROR} Please provide a valid 17-20 digit Discord bot ID.`
            })
          ]
        });
      }

      let list = [];
      try {
        list = JSON.parse(settings.whitelisted_bots || '[]');
      } catch (e) {
        list = [];
      }

      if (list.includes(botId)) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xFEE75C,
              description: `${EMOJIS.WARNING} Bot <@${botId}> (\`${botId}\`) is already in the AntiBot whitelist.`
            })
          ]
        });
      }

      list.push(botId);
      sdb.prepare('UPDATE antibot_settings SET whitelisted_bots = ? WHERE guild_id = ?').run(JSON.stringify(list), message.guild.id);

      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SUCCESS} Bot Whitelisted`,
        description: `Successfully added <@${botId}> (\`${botId}\`) to the trusted AntiBot whitelist.\n\n` +
          `• This bot is now authorized to join the server without triggering defensive actions.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. REMOVE BOT FROM WHITELIST
    // ─────────────────────────────────────────────────────────────
    if (sub === 'remove' || sub === 'delete' || sub === 'del') {
      const raw = args[1];
      if (!raw) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              description: `${EMOJIS.WARNING} Usage: \`${prefix}antibot remove <bot_id>\``
            })
          ]
        });
      }

      const botId = raw.replace(/[<@!>]/g, '').trim();
      let list = [];
      try {
        list = JSON.parse(settings.whitelisted_bots || '[]');
      } catch (e) {
        list = [];
      }

      if (!list.includes(botId)) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xFEE75C,
              description: `${EMOJIS.WARNING} Bot <@${botId}> (\`${botId}\`) is not in the AntiBot whitelist.`
            })
          ]
        });
      }

      list = list.filter(id => id !== botId);
      sdb.prepare('UPDATE antibot_settings SET whitelisted_bots = ? WHERE guild_id = ?').run(JSON.stringify(list), message.guild.id);

      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SUCCESS} Bot Unwhitelisted`,
        description: `Removed <@${botId}> (\`${botId}\`) from the AntiBot whitelist.`
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 6. RESET
    // ─────────────────────────────────────────────────────────────
    if (sub === 'reset') {
      sdb.prepare("UPDATE antibot_settings SET enabled = 1, punishment = 'kick', whitelisted_bots = '[]' WHERE guild_id = ?").run(message.guild.id);
      const embed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.SUCCESS} AntiBot Settings Reset`,
        description: 'AntiBot has been reset to defaults: **Enabled (Kick)** with an empty whitelist.'
      });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 7. CONFIG / STATUS (DEFAULT)
    // ─────────────────────────────────────────────────────────────
    const isArmed = settings.enabled === 1;
    let whitelisted = [];
    try {
      whitelisted = JSON.parse(settings.whitelisted_bots || '[]');
    } catch (e) {
      whitelisted = [];
    }

    const botListStr = whitelisted.length > 0
      ? whitelisted.map((id, i) => `\`${i + 1}.\` <@${id}> (\`${id}\`)`).join('\n')
      : '`None configured` (all unauthorized bots will be intercepted)';

    const embed = createEmbed({
      color: isArmed ? 0x57F287 : 0xED4245,
      title: `${EMOJIS.SHIELD} AntiBot Protection Sentinel`,
      description:
        `> Automated defense against unauthorized or rogue bot additions.\n\n` +
        `• **Sentinel Status:** ${isArmed ? `${EMOJIS.UI_TOGGLE_ON} \`ACTIVE & ARMED\`` : `${EMOJIS.UI_TOGGLE_OFF} \`DISABLED\``}\n` +
        `• **Punishment Action:** \`${settings.punishment.toUpperCase()}\`\n` +
        `• **Inviter Punishment:** Automatic quarantine / strike attribution for unauthorized inviter\n\n` +
        `**Whitelisted Bots (${whitelisted.length}):**\n${botListStr}\n\n` +
        `**Commands:**\n` +
        `• \`${prefix}antibot enable\` / \`${prefix}antibot disable\` — Toggle defense\n` +
        `• \`${prefix}antibot action <kick|ban>\` — Set bot punishment\n` +
        `• \`${prefix}antibot add <bot_id>\` — Whitelist trusted bot\n` +
        `• \`${prefix}antibot remove <bot_id>\` — Remove bot from whitelist\n` +
        `• \`${prefix}antibot reset\` — Reset to default settings`
    });
    return message.reply({ embeds: [embed] });
  },

  slash: new SlashCommandBuilder()
    .setName('antibot')
    .setDescription('Manage AntiBot protection and bot whitelists.')
    .addSubcommand(sub =>
      sub
        .setName('config')
        .setDescription('Display AntiBot status, punishment, and whitelisted bots.')
    )
    .addSubcommand(sub =>
      sub
        .setName('enable')
        .setDescription('Enable AntiBot protection.')
    )
    .addSubcommand(sub =>
      sub
        .setName('disable')
        .setDescription('Disable AntiBot protection.')
    )
    .addSubcommand(sub =>
      sub
        .setName('action')
        .setDescription('Set punishment for unauthorized bot joins.')
        .addStringOption(opt =>
          opt
            .setName('punishment')
            .setDescription('Punishment action')
            .setRequired(true)
            .addChoices(
              { name: 'Kick', value: 'kick' },
              { name: 'Ban', value: 'ban' }
            )
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Whitelist a bot ID.')
        .addStringOption(opt => opt.setName('bot_id').setDescription('17-20 digit Bot ID').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a bot ID from whitelist.')
        .addStringOption(opt => opt.setName('bot_id').setDescription('17-20 digit Bot ID').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('reset')
        .setDescription('Reset AntiBot settings to defaults.')
    ),

  async executeSlash(interaction, client) {
    if (!interaction.guild) return;

    if (!hasPerm(interaction.member, PermissionsBitField.Flags.Administrator)) {
      return interaction.reply({
        content: `${EMOJIS.ERROR} You need **Administrator** permission to configure AntiBot.`,
        ephemeral: true
      });
    }

    const sdb = getServerDb(interaction.guild.id);
    const settings = getAntibotSettings(sdb, interaction.guild.id);
    const sub = interaction.options.getSubcommand();

    if (sub === 'enable') {
      sdb.prepare('UPDATE antibot_settings SET enabled = 1 WHERE guild_id = ?').run(interaction.guild.id);
      return interaction.reply({
        content: `${EMOJIS.SUCCESS} AntiBot Sentinel is now **ENABLED**.`,
        ephemeral: true
      });
    }

    if (sub === 'disable') {
      sdb.prepare('UPDATE antibot_settings SET enabled = 0 WHERE guild_id = ?').run(interaction.guild.id);
      return interaction.reply({
        content: `${EMOJIS.WARNING} AntiBot Sentinel is now **DISABLED**.`,
        ephemeral: true
      });
    }

    if (sub === 'action') {
      const act = interaction.options.getString('punishment');
      sdb.prepare('UPDATE antibot_settings SET punishment = ? WHERE guild_id = ?').run(act, interaction.guild.id);
      return interaction.reply({
        content: `${EMOJIS.SUCCESS} AntiBot punishment updated to **${act.toUpperCase()}**.`,
        ephemeral: true
      });
    }

    if (sub === 'add') {
      const botId = interaction.options.getString('bot_id').replace(/[<@!>]/g, '').trim();
      if (!/^\d{17,20}$/.test(botId)) {
        return interaction.reply({ content: `${EMOJIS.ERROR} Invalid bot ID format.`, ephemeral: true });
      }
      let list = [];
      try { list = JSON.parse(settings.whitelisted_bots || '[]'); } catch (e) { list = []; }
      if (list.includes(botId)) {
        return interaction.reply({ content: `${EMOJIS.WARNING} Bot <@${botId}> is already whitelisted.`, ephemeral: true });
      }
      list.push(botId);
      sdb.prepare('UPDATE antibot_settings SET whitelisted_bots = ? WHERE guild_id = ?').run(JSON.stringify(list), interaction.guild.id);
      return interaction.reply({ content: `${EMOJIS.SUCCESS} Whitelisted bot <@${botId}>.`, ephemeral: true });
    }

    if (sub === 'remove') {
      const botId = interaction.options.getString('bot_id').replace(/[<@!>]/g, '').trim();
      let list = [];
      try { list = JSON.parse(settings.whitelisted_bots || '[]'); } catch (e) { list = []; }
      if (!list.includes(botId)) {
        return interaction.reply({ content: `${EMOJIS.WARNING} Bot <@${botId}> is not in whitelist.`, ephemeral: true });
      }
      list = list.filter(id => id !== botId);
      sdb.prepare('UPDATE antibot_settings SET whitelisted_bots = ? WHERE guild_id = ?').run(JSON.stringify(list), interaction.guild.id);
      return interaction.reply({ content: `${EMOJIS.SUCCESS} Removed <@${botId}> from whitelist.`, ephemeral: true });
    }

    if (sub === 'reset') {
      sdb.prepare("UPDATE antibot_settings SET enabled = 1, punishment = 'kick', whitelisted_bots = '[]' WHERE guild_id = ?").run(interaction.guild.id);
      return interaction.reply({ content: `${EMOJIS.SUCCESS} AntiBot reset to defaults.`, ephemeral: true });
    }

    // config
    let whitelisted = [];
    try { whitelisted = JSON.parse(settings.whitelisted_bots || '[]'); } catch (e) { whitelisted = []; }
    return interaction.reply({
      content: `**AntiBot Status:** ${settings.enabled ? 'ENABLED' : 'DISABLED'}\n**Punishment:** ${settings.punishment.toUpperCase()}\n**Whitelisted Bots:** ${whitelisted.length > 0 ? whitelisted.map(id => `<@${id}>`).join(', ') : 'None'}`,
      ephemeral: true
    });
  }
};
