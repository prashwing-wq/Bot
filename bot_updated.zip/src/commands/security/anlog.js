/**
 * Antinuke Audit Log & Telemetry Dashboard Command (Node.js)
 * Enterprise-grade security dashboard visualizing real-time threat telemetry,
 * 16 sentinel vector armed states, in-memory rate-limit buckets, immunity cache nodes,
 * isolation quarantine registry, and automated structural auto-heal mitigations.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SlashCommandBuilder,
  PermissionFlagsBits
} = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm } = require('../../utils/tools');
const {
  isAntinukeArmed,
  getAllAntinukeRules,
  ANTINUKE_VECTORS,
  _IMMUNITY_CACHE,
  _RATE_LIMIT_BUCKETS,
  _AUTO_HEAL_LOCKS
} = require('../../utils/antinukeEngine');
const { createV2Card } = require('../../utils/componentsV2');
const { getWatchlist } = require('../../utils/watchlist');

// Custom Tungsten Animated Icons
const EMOJIS = {
  SHIELD: '<a:tungsten_shield:1567242104923627574>',
  ALARM: '<a:tungsten_alarm:1567229471474585682>',
  CHECK: '<a:tungsten_tick:1567242779908636802>',
  CLOSE: '<a:tungsten_close:1567234632905138206>',
  WARN: '<a:tungsten_warn:1567246685082746940>',
  GEAR: '<a:tungsten_gear:1567239932970406012>',
  REFRESH: '<a:tungsten_refresh:1567241907116187658>',
  CHART: '<a:tungsten_chart:1567234342701367357>',
  CLOCK: '<a:tungsten_clock:1567234623216554118>',
  UI_TOGGLE_ON: '<a:tungsten_ui_toggle_on:1569329685110849576>',
  UI_TOGGLE_OFF: '<a:tungsten_ui_toggle_off:1569329677187678368>',
  WATCHLIST: '<a:tungsten_watchlist:1569329733303541801>',
  LOCKDOWN: '<a:tungsten_lockdown:1569329429174296697>'
};

/**
 * Gathers complete antinuke telemetry for a guild.
 */
function gatherTelemetry(guild) {
  const gid = String(guild.id);
  let sdb = null;
  try {
    sdb = getServerDb(gid);
  } catch (_) {}

  // 1. Armed state & Vector rules
  const isArmed = isAntinukeArmed(gid);
  let rules = {};
  try {
    rules = getAllAntinukeRules(gid) || {};
  } catch (_) {}

  // 2. Last 20 triggers
  let triggers = [];
  if (sdb) {
    try {
      triggers = sdb.prepare(`
        SELECT log_id, action, actor_id, target_id, details, timestamp
        FROM audit_logs
        WHERE action = 'antinuke_punishment'
           OR action LIKE '%antinuke%'
           OR details LIKE '%[Action:%'
           OR details LIKE '%[Tungsten Antinuke]%'
           OR details LIKE '%[Tungsten Antinuke]%'
        ORDER BY timestamp DESC
        LIMIT 20
      `).all();
    } catch (_) {}
  }

  // 3. Quarantined accounts
  let quarantinedUsers = [];
  if (sdb) {
    try {
      quarantinedUsers = sdb.prepare(`
        SELECT user_id, quarantined_at, quarantined_by, original_roles, reason
        FROM quarantined_users
        WHERE guild_id = ?
        ORDER BY quarantined_at DESC
      `).all(gid);
    } catch (_) {}
  }

  // 4. Recent auto-heal mitigations
  let autoHeals = [];
  if (sdb) {
    try {
      autoHeals = sdb.prepare(`
        SELECT log_id, action, actor_id, target_id, details, timestamp
        FROM audit_logs
        WHERE action LIKE '%heal%'
           OR details LIKE '%Auto-Heal%'
           OR details LIKE '%Auto-Healed%'
           OR details LIKE '%Re-creating%'
        ORDER BY timestamp DESC
        LIMIT 10
      `).all();
    } catch (_) {}
  }

  // In-memory locks inspection
  let activeHealsCount = 0;
  if (_AUTO_HEAL_LOCKS && typeof _AUTO_HEAL_LOCKS.forEach === 'function') {
    const lockNow = Date.now();
    _AUTO_HEAL_LOCKS.forEach((ts, key) => {
      if (typeof key === 'string' && key.startsWith(`${gid}:`) && (lockNow - ts < 60000)) {
        activeHealsCount++;
      }
    });
  }

  // 5. Immunity Cache Nodes
  let cachedImmuneCount = 0;
  let ttlSum = 0;
  const now = Date.now();
  if (_IMMUNITY_CACHE && typeof _IMMUNITY_CACHE.forEach === 'function') {
    _IMMUNITY_CACHE.forEach((entry, key) => {
      if (typeof key === 'string' && key.startsWith(`${gid}:`)) {
        if (entry && entry.expires > now) {
          cachedImmuneCount++;
          ttlSum += Math.max(0, Math.round((entry.expires - now) / 1000));
        }
      }
    });
  }
  const avgTtl = cachedImmuneCount > 0 ? Math.round(ttlSum / cachedImmuneCount) : 15;

  // DB Configured Exemptions
  let extraOwnersCount = 0;
  let whitelistedUsersCount = 0;
  let whitelistedRolesCount = 0;
  if (sdb) {
    try {
      const eo = sdb.prepare('SELECT COUNT(*) AS c FROM extraowners WHERE guild_id = ?').get(gid);
      extraOwnersCount = eo ? eo.c : 0;
      const wu = sdb.prepare('SELECT COUNT(*) AS c FROM whitelisted_users WHERE guild_id = ?').get(gid);
      whitelistedUsersCount = wu ? wu.c : 0;
      const wr = sdb.prepare('SELECT COUNT(*) AS c FROM whitelisted_roles WHERE guild_id = ?').get(gid);
      whitelistedRolesCount = wr ? wr.c : 0;
    } catch (_) {}
  }

  // 6. Sliding-Window Rate Limit Buckets
  let trackedUsersCount = 0;
  if (_RATE_LIMIT_BUCKETS && typeof _RATE_LIMIT_BUCKETS.forEach === 'function') {
    _RATE_LIMIT_BUCKETS.forEach((timestamps, key) => {
      if (typeof key === 'string' && key.startsWith(`${gid}:`) && Array.isArray(timestamps) && timestamps.length > 0) {
        trackedUsersCount++;
      }
    });
  }

  // 7. Surveillance Watchlist Stats
  let watchlistEntries = [];
  try {
    watchlistEntries = getWatchlist(gid) || [];
  } catch (_) {}

  return {
    isArmed,
    rules,
    triggers,
    quarantinedUsers,
    autoHeals,
    activeHealsCount,
    cachedImmuneCount,
    avgTtl,
    extraOwnersCount,
    whitelistedUsersCount,
    whitelistedRolesCount,
    trackedUsersCount,
    watchlistEntries
  };
}

/**
 * Builds the visual Components V2 dashboard payload for a specific tab.
 */
function buildDashboardPayload(guild, telemetry, tab = 'triggers', requesterId) {
  const isArmed = telemetry.isArmed;
  const accentColor = isArmed ? 0x2ECC71 : 0xED4245;
  const currentTab = ['triggers', 'vectors', 'quarantine', 'stats'].includes(tab) ? tab : 'triggers';

  let title = '';
  let description = '';

  if (currentTab === 'triggers') {
    title = `${EMOJIS.SHIELD} Antinuke Audit Telemetry Matrix`;
    const triggersList = telemetry.triggers.length > 0
      ? telemetry.triggers.map((t, idx) => {
          const ts = Math.floor(Number(t.timestamp) || Date.now() / 1000);
          const target = t.target_id ? `<@${t.target_id}> (\`${t.target_id}\`)` : 'Unknown Actor';
          const details = t.details || 'Security violation intercepted';
          return (
            `**${idx + 1}.** <t:${ts}:T> (<t:${ts}:R>)\n` +
            `   ${EMOJIS.ALARM} **Offender:** ${target}\n` +
            `   ${EMOJIS.GEAR} **Log Entry:** \`${details}\``
          );
        }).join('\n\n')
      : `${EMOJIS.CHECK} Zero unauthorized threat incursions recorded. All perimeter sentinels nominal.`;

    const autoHealsList = telemetry.autoHeals.length > 0
      ? telemetry.autoHeals.slice(0, 5).map((h, idx) => {
          const ts = Math.floor(Number(h.timestamp) || Date.now() / 1000);
          return `**${idx + 1}.** <t:${ts}:R> — \`${h.details || 'Structural element reconstructed'}\``;
        }).join('\n')
      : `${EMOJIS.CHECK} Zero structural tampering events. Server hierarchy and channels pristine.`;

    description =
      `> **Live Sub-50ms Threat Interception & Neutralization Intelligence**\n\n` +
      `• **Global Defense State:** ${isArmed ? `${EMOJIS.UI_TOGGLE_ON} \`ARMED & ACTIVE (Zero-Tolerance)\`` : `${EMOJIS.UI_TOGGLE_OFF} \`DISARMED (Inactive)\``}\n` +
      `• **Active Quarantine:** \`${telemetry.quarantinedUsers.length} accounts\` • **Auto-Heals:** \`${telemetry.autoHeals.length} operations\`\n` +
      `• **Immunity Cache Nodes:** \`${telemetry.cachedImmuneCount} cached (Avg TTL: ${telemetry.avgTtl}s)\` • **Rate Trackers:** \`${telemetry.trackedUsersCount} active\`\n` +
      `• ${EMOJIS.WATCHLIST} **Watchlist Zero-Tolerance:** \`${telemetry.watchlistEntries.length} flagged accounts (limit: 1)\`\n\n` +
      `### ${EMOJIS.ALARM} Recent Antinuke Triggers (Last 20)\n` +
      `${triggersList}\n\n` +
      `### ${EMOJIS.REFRESH} Structural Auto-Heal Mitigations\n` +
      `${autoHealsList}`;
  } else if (currentTab === 'vectors') {
    title = `${EMOJIS.GEAR} Antinuke Sentinel Vector Matrix (16 Vectors)`;
    const vectorKeys = Object.keys(ANTINUKE_VECTORS);
    const vectorLines = vectorKeys.map(k => {
      const meta = ANTINUKE_VECTORS[k] || {};
      const rule = telemetry.rules[k] || {
        enabled: true,
        action: meta.defaultAction || 'ban',
        limit_count: meta.defaultLimit || 1,
        time_window: meta.defaultWindow || 10,
        auto_heal: Boolean(meta.defaultHeal)
      };

      const icon = meta.icon || EMOJIS.SHIELD;
      const statusIcon = rule.enabled ? `${EMOJIS.UI_TOGGLE_ON} \`ARMED\`` : `${EMOJIS.UI_TOGGLE_OFF} \`DISARMED\``;
      const healIcon = rule.auto_heal ? `${EMOJIS.UI_TOGGLE_ON} \`ON\`` : `${EMOJIS.UI_TOGGLE_OFF} \`OFF\``;
      const act = String(rule.action || 'ban').toUpperCase();

      return (
        `${icon} **${meta.name || k}**\n` +
        `• Status: ${statusIcon} • Action: \`${act}\` • Threshold: \`${rule.limit_count}/${rule.time_window}s\` • Auto-Heal: ${healIcon}`
      );
    });

    description =
      `> **Granular Vector Thresholds, Actions & Structural Auto-Healing**\n\n` +
      vectorLines.join('\n\n') +
      `\n\n-# Reconfigure vectors at any time using \`/an edit\` or \`!antinuke\`.`;
  } else if (currentTab === 'quarantine') {
    title = `${EMOJIS.SHIELD} Isolation Quarantine Registry (${telemetry.quarantinedUsers.length})`;
    if (telemetry.quarantinedUsers.length > 0) {
      const qRows = telemetry.quarantinedUsers.slice(0, 10).map((u, i) => {
        let roleCount = 0;
        try {
          const parsed = JSON.parse(u.original_roles || '[]');
          roleCount = Array.isArray(parsed) ? parsed.length : 0;
        } catch (_) {}

        return (
          `**${i + 1}.** <@${u.user_id}> (\`${u.user_id}\`)\n` +
          `   ${EMOJIS.CLOCK} Quarantined: <t:${u.quarantined_at}:R> (<t:${u.quarantined_at}:f>)\n` +
          `   ${EMOJIS.SHIELD} Enforcer: <@${u.quarantined_by}>\n` +
          `   ${EMOJIS.GEAR} Preserved Roles: \`${roleCount}\` saved in encrypted vault\n` +
          `   ${EMOJIS.WARN} Reason: \`${u.reason || 'Manual or Antinuke Quarantine'}\``
        );
      });

      description =
        `> **Compromised Accounts Stripped of Privileges & Locked in Containment**\n\n` +
        qRows.join('\n\n') +
        `\n\n-# Run \`!unquarantine <@user>\` to release containment and restore preserved roles.`;
    } else {
      description =
        `> **Compromised Accounts Stripped of Privileges & Locked in Containment**\n\n` +
        `${EMOJIS.CHECK} Zero accounts currently quarantined or isolated in this server.\nPerimeter security is intact.`;
    }
  } else if (currentTab === 'stats') {
    title = `${EMOJIS.CHART} Antinuke Engine Telemetry & In-Memory Stats`;
    description =
      `> **Sub-50ms Reaction Sentinel Diagnostic Metrics**\n\n` +
      `### ${EMOJIS.SHIELD} In-Memory Immunity Cache\n` +
      `• **Active Cached Nodes:** \`${telemetry.cachedImmuneCount}\` entries for this guild\n` +
      `• **Average Sliding TTL:** \`${telemetry.avgTtl}s\` (15s sliding invalidation window)\n` +
      `• **Cache Invalidation:** Event-driven on permission updates, role edits, and whitelist changes\n\n` +
      `### ${EMOJIS.ALARM} Sliding-Window Rate Limit Buckets\n` +
      `• **Tracked User Buckets:** \`${telemetry.trackedUsersCount}\` active sliding windows\n` +
      `• **Window Duration:** \`10,000ms (10 seconds)\`\n` +
      `• **Fortress Circuit Breaker:** \`< 5 actions / 2s attack velocity limit\`\n\n` +
      `### ${EMOJIS.GEAR} Exemption Hierarchy & Roles\n` +
      `• **Primary Server Owner:** <@${guild.ownerId}> (\`${guild.ownerId}\`) [Full Immunity]\n` +
      `• **Extra Owners (Immune):** \`${telemetry.extraOwnersCount}\` configured\n` +
      `• **Whitelisted Users:** \`${telemetry.whitelistedUsersCount}\` accounts\n` +
      `• **Whitelisted Roles:** \`${telemetry.whitelistedRolesCount}\` roles\n` +
      `• **Dual Backup Roles:** \`Tungsten Backup Tier I & II (Anchored)\`\n\n` +
      `### ${EMOJIS.WATCHLIST} Surveillance Watchlist System\n` +
      `• **Active Watchlisted Accounts:** \`${telemetry.watchlistEntries.length}\` users\n` +
      `• **Zero-Tolerance Enforcement:** \`limit_count: 1 (Instant Neutralization)\`\n` +
      `• **Immunity Bypass:** \`ALWAYS FALSE (Watchlisted accounts never immune)\``;
  }

  // Build Interactive ActionRow with native custom animated emojis
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`anlog_tab_triggers_${requesterId}`)
      .setLabel(`Triggers (${telemetry.triggers.length})`)
      .setStyle(currentTab === 'triggers' ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setEmoji({ id: '1567229471474585682', name: 'tungsten_alarm', animated: true }),
    new ButtonBuilder()
      .setCustomId(`anlog_tab_vectors_${requesterId}`)
      .setLabel('Vectors (16)')
      .setStyle(currentTab === 'vectors' ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setEmoji({ id: '1567239932970406012', name: 'tungsten_gear', animated: true }),
    new ButtonBuilder()
      .setCustomId(`anlog_tab_quarantine_${requesterId}`)
      .setLabel(`Quarantine (${telemetry.quarantinedUsers.length})`)
      .setStyle(currentTab === 'quarantine' ? ButtonStyle.Danger : ButtonStyle.Secondary)
      .setEmoji({ id: '1567242104923627574', name: 'tungsten_shield', animated: true }),
    new ButtonBuilder()
      .setCustomId(`anlog_tab_stats_${requesterId}`)
      .setLabel('Stats & Cache')
      .setStyle(currentTab === 'stats' ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setEmoji({ id: '1567234342701367357', name: 'tungsten_chart', animated: true }),
    new ButtonBuilder()
      .setCustomId(`anlog_tab_refresh_${requesterId}`)
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji({ id: '1567241907116187658', name: 'tungsten_refresh', animated: true })
  );

  // Components V2 Type 17 Container card with integrated in-embed button panel
  const card = createV2Card({
    title,
    description,
    color: accentColor,
    footer: { text: `Tungsten Defense Matrix • Guild: ${guild.id}` },
    buttons: [
      { label: `Triggers (${telemetry.triggers.length})`, emoji: EMOJIS.ALARM, style: currentTab === 'triggers' ? ButtonStyle.Primary : ButtonStyle.Secondary },
      { label: 'Vectors (16)', emoji: EMOJIS.GEAR, style: currentTab === 'vectors' ? ButtonStyle.Primary : ButtonStyle.Secondary },
      { label: `Quarantine (${telemetry.quarantinedUsers.length})`, emoji: EMOJIS.SHIELD, style: currentTab === 'quarantine' ? ButtonStyle.Danger : ButtonStyle.Secondary },
      { label: 'Stats & Cache', emoji: EMOJIS.CHART, style: currentTab === 'stats' ? ButtonStyle.Primary : ButtonStyle.Secondary },
      { label: 'Refresh', emoji: EMOJIS.REFRESH, style: ButtonStyle.Secondary }
    ]
  });

  return {
    embeds: [card],
    components: [row]
  };
}

module.exports = {
  name: 'anlog',
  aliases: ['anlogs', 'antinukelog', 'antinukelogs', 'an_log', 'an_logs'],
  category: 'security',
  description: 'Antinuke audit log dashboard with live threat intelligence, vector statuses, and mitigation telemetry.',
  usage: '[triggers|vectors|quarantine|stats]',
  cooldown: 3,
  permissions: ['ViewAuditLog'],
  botPermissions: ['ViewAuditLog'],

  slash: new SlashCommandBuilder()
    .setName('anlog')
    .setDescription('Antinuke audit log dashboard with live threat intelligence')
    .setDefaultMemberPermissions(PermissionFlagsBits.ViewAuditLog)
    .setDMPermission(false)
    .addStringOption(opt =>
      opt
        .setName('view')
        .setDescription('Initial dashboard view tab')
        .setRequired(false)
        .addChoices(
          { name: 'Recent Triggers', value: 'triggers' },
          { name: 'Vector Defense Matrix', value: 'vectors' },
          { name: 'Quarantine Registry', value: 'quarantine' },
          { name: 'Telemetry & Cache Stats', value: 'stats' }
        )
    ),

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.ViewAuditLog)) {
      return message.reply({
        embeds: [
          createV2Card({
            color: 0xED4245,
            title: `${EMOJIS.CLOSE} Permission Denied`,
            description: `You need the \`View Audit Log\` permission to access the Antinuke Audit Dashboard.`
          })
        ]
      });
    }

    const sub = (args[0] || '').toLowerCase();
    let initialTab = 'triggers';
    if (sub.includes('vec')) initialTab = 'vectors';
    else if (sub.includes('quar') || sub.includes('jail')) initialTab = 'quarantine';
    else if (sub.includes('stat') || sub.includes('cache') || sub.includes('rate')) initialTab = 'stats';

    const authorId = message.author.id;
    let telemetry = gatherTelemetry(message.guild);
    let currentTab = initialTab;
    const payload = buildDashboardPayload(message.guild, telemetry, currentTab, authorId);

    const replyMsg = await message.reply(payload);
    if (!replyMsg || typeof replyMsg.createMessageComponentCollector !== 'function') {
      return replyMsg;
    }

    // Attach interactive Components V2 button collector
    const collector = replyMsg.createMessageComponentCollector({
      time: 120000
    });

    collector.on('collect', async interaction => {
      if (!interaction.customId || !interaction.customId.startsWith('anlog_tab_')) return;

      if (!interaction.customId.endsWith(`_${authorId}`)) {
        return interaction.reply({
          content: `${EMOJIS.CLOSE} This interactive telemetry dashboard was summoned by another administrator.`,
          ephemeral: true
        }).catch(() => null);
      }

      if (interaction.customId.includes('_triggers_')) {
        currentTab = 'triggers';
      } else if (interaction.customId.includes('_vectors_')) {
        currentTab = 'vectors';
      } else if (interaction.customId.includes('_quarantine_')) {
        currentTab = 'quarantine';
      } else if (interaction.customId.includes('_stats_')) {
        currentTab = 'stats';
      } else if (interaction.customId.includes('_refresh_')) {
        // Keep current tab and refresh telemetry
      }

      telemetry = gatherTelemetry(message.guild);
      const updatedPayload = buildDashboardPayload(message.guild, telemetry, currentTab, authorId);

      if (typeof interaction.update === 'function') {
        await interaction.update(updatedPayload).catch(() => null);
      }
    });

    collector.on('end', async () => {
      try {
        if (replyMsg && typeof replyMsg.edit === 'function') {
          const finalPayload = buildDashboardPayload(message.guild, telemetry, currentTab, authorId);
          if (finalPayload.components && finalPayload.components[0]) {
            finalPayload.components[0].components.forEach(btn => btn.setDisabled(true));
          }
          await replyMsg.edit(finalPayload).catch(() => null);
        }
      } catch (_) {}
    });

    return replyMsg;
  },

  async executeSlash(interaction, client) {
    if (!interaction.guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    if (!hasPerm(interaction.member, PermissionFlagsBits.ViewAuditLog)) {
      return interaction.reply({
        embeds: [
          createV2Card({
            color: 0xED4245,
            title: `${EMOJIS.CLOSE} Permission Denied`,
            description: `You need the \`View Audit Log\` permission to access the Antinuke Audit Dashboard.`
          })
        ],
        ephemeral: true
      });
    }

    const selectedView = interaction.options.getString('view') || 'triggers';
    const authorId = interaction.user.id;
    let telemetry = gatherTelemetry(interaction.guild);
    let currentTab = selectedView;
    const payload = buildDashboardPayload(interaction.guild, telemetry, currentTab, authorId);

    const reply = await interaction.reply(payload);
    let replyMsg = null;
    try {
      if (typeof interaction.fetchReply === 'function') {
        replyMsg = await interaction.fetchReply();
      } else {
        replyMsg = reply;
      }
    } catch (_) {
      replyMsg = reply;
    }

    if (!replyMsg || typeof replyMsg.createMessageComponentCollector !== 'function') {
      return;
    }

    const collector = replyMsg.createMessageComponentCollector({
      time: 120000
    });

    collector.on('collect', async btnInt => {
      if (!btnInt.customId || !btnInt.customId.startsWith('anlog_tab_')) return;

      if (!btnInt.customId.endsWith(`_${authorId}`)) {
        return btnInt.reply({
          content: `${EMOJIS.CLOSE} This interactive telemetry dashboard was summoned by another administrator.`,
          ephemeral: true
        }).catch(() => null);
      }

      if (btnInt.customId.includes('_triggers_')) {
        currentTab = 'triggers';
      } else if (btnInt.customId.includes('_vectors_')) {
        currentTab = 'vectors';
      } else if (btnInt.customId.includes('_quarantine_')) {
        currentTab = 'quarantine';
      } else if (btnInt.customId.includes('_stats_')) {
        currentTab = 'stats';
      } else if (btnInt.customId.includes('_refresh_')) {
        // Keep current tab and refresh telemetry
      }

      telemetry = gatherTelemetry(interaction.guild);
      const updatedPayload = buildDashboardPayload(interaction.guild, telemetry, currentTab, authorId);

      if (typeof btnInt.update === 'function') {
        await btnInt.update(updatedPayload).catch(() => null);
      }
    });

    collector.on('end', async () => {
      try {
        if (replyMsg && typeof replyMsg.edit === 'function') {
          const finalPayload = buildDashboardPayload(interaction.guild, telemetry, currentTab, authorId);
          if (finalPayload.components && finalPayload.components[0]) {
            finalPayload.components[0].components.forEach(btn => btn.setDisabled(true));
          }
          await replyMsg.edit(finalPayload).catch(() => null);
        }
      } catch (_) {}
    });
  }
};
