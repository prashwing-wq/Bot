/**
 * Antinuke Vulnerability Audit Command (Node.js)
 * Executes deep security scanning across hierarchy, permissions, webhooks, and antinuke sentinels.
 * Ported from cogs/commands/antinuke_ultra.py with rich Discord Components V2 telemetry.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, PermissionsBitField } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { getServerDb } = require('../../utils/serverDb');
const { isOwner, hasPerm } = require('../../utils/tools');
const { getAntinukeMode } = require('./anmode');
const { isAntinukeArmed } = require('../../utils/antinukeEngine');

module.exports = {
  name: 'anaudit',
  aliases: ['secscan', 'diagnostics', 'vaudit', 'securityaudit', 'an_audit'],
  category: 'security',
  description: 'Executes a comprehensive Antinuke security audit and vulnerability assessment.',
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const isAuthorized = hasPerm(message.member, PermissionFlagsBits.Administrator);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Administrator` permission to run security diagnostics.');
    }

    const initial = await message.reply('<a:tungsten_loading:1567241050567876698> **Executing deep vulnerability scan across server hierarchy, permissions, and defense modules...**');

    const guild = message.guild;
    const me = guild.members.me;
    let score = 100;
    const checksPassed = [];
    const findings = [];

    // 1. Bot Role Hierarchy Check
    const myPos = me ? me.roles.highest.position : 0;
    const higherRoles = guild.roles.cache.filter(r => r.position >= myPos && r.id !== guild.id && !r.managed);
    if (higherRoles.size > 0) {
      score -= 20;
      findings.push(`<a:tungsten_ui_toggle_off:1569329677187678368> **Role Hierarchy Deficiency (-20pts):** Tungsten's highest role is positioned below ${higherRoles.size} unmanaged role(s). Move Tungsten to the top of your role hierarchy.`);
    } else {
      checksPassed.push('<a:tungsten_ui_toggle_on:1569329685110849576> **Role Hierarchy:** Tungsten holds top role position.');
    }

    // 2. Dangerous @everyone Permissions
    const everyone = guild.roles.everyone;
    const dangerousPerms = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageGuild,
      PermissionsBitField.Flags.ManageWebhooks,
      PermissionsBitField.Flags.MentionEveryone
    ];

    const roguePerms = dangerousPerms.filter(p => everyone.permissions.has(p));
    if (roguePerms.length > 0) {
      score -= 30;
      findings.push(`<a:tungsten_ui_toggle_off:1569329677187678368> **Critical Perms on @everyone (-30pts):** Default members hold ${roguePerms.length} dangerous permission(s).`);
    } else {
      checksPassed.push('<a:tungsten_ui_toggle_on:1569329685110849576> **@everyone Clean:** No dangerous permissions assigned to default members.');
    }

    // 3. Antinuke Core Status & Mode
    const isArmed = isAntinukeArmed(guild.id);
    const currentMode = getAntinukeMode(guild.id);
    if (isArmed) {
      checksPassed.push('<a:tungsten_ui_toggle_on:1569329685110849576> **Antinuke Armed:** Real-time defense sentinels active.');
    } else {
      score -= 25;
      findings.push(`<a:tungsten_ui_toggle_off:1569329677187678368> **Antinuke Disarmed (-25pts):** Server protection is inactive. Enable with \`${prefix}antinuke enable\`.`);
    }

    checksPassed.push('<a:tungsten_bolt:1567233430570405968> **Ultra Shield Active:** Zero-tolerance 1-action ban with instant auto-rollback.');

    // 4. Other Bot Administrative Privileges
    const otherBots = guild.members.cache.filter(m => m.user.bot && m.id !== client.user.id);
    const adminBots = otherBots.filter(b => b.permissions.has(PermissionsBitField.Flags.Administrator));
    if (adminBots.size > 0) {
      score -= 10;
      findings.push(`<a:tungsten_ui_toggle_off:1569329677187678368> **Third-Party Bot Risk (-10pts):** ${adminBots.size} other bot(s) hold Administrator privileges.`);
    } else {
      checksPassed.push('<a:tungsten_ui_toggle_on:1569329685110849576> **Bot Permissions:** No rogue bots with unmonitored admin access.');
    }

    // 5. Dual Backup Roles Safeguard
    const backupRole1 = guild.roles.cache.find(r => (r.name.toLowerCase().includes('tungsten backup tier') || r.name.toLowerCase().includes('tungsten backup tier')));
    if (backupRole1) {
      checksPassed.push('<a:tungsten_ui_toggle_on:1569329685110849576> **Safeguard Anchors:** Dual Administrator Backup Roles active.');
    } else {
      score -= 10;
      findings.push('<a:tungsten_ui_toggle_off:1569329677187678368> **Safeguard Anchor:** Backup roles not provisioned. Arming antinuke automatically anchors dual roles.');
    }

    // 6. Surveillance Watchlist System
    let watchlistCount = 0;
    try {
      const sdb = getServerDb(guild.id);
      const wlRow = sdb.prepare('SELECT COUNT(*) as count FROM antinuke_watchlist WHERE guild_id = ?').get(guild.id);
      watchlistCount = wlRow?.count || 0;
    } catch (_) {}
    if (watchlistCount > 0) {
      checksPassed.push(`<a:tungsten_watchlist:1569329733303541801> **Watchlist Active:** \`${watchlistCount}\` monitored account(s) under zero-tolerance.`);
    } else {
      checksPassed.push('<a:tungsten_watchlist:1569329733303541801> **Watchlist Enforcer:** Zero-tolerance sentinel armed for flagged accounts.');
    }

    score = Math.max(0, Math.min(100, score));
    const grade = score >= 90 ? 'A+' : score >= 80 ? 'A' : score >= 70 ? 'B' : score >= 50 ? 'C' : 'F (CRITICAL)';
    const gradeColor = score >= 80 ? 0x2ECC71 : (score >= 60 ? 0xF1C40F : 0xED4245);

    const reportCard = createV2Card({
      color: gradeColor,
      title: `<a:tungsten_shield:1567242104923627574>  Antinuke Security Audit • Grade ${grade} (${score}/100)`,
      description:
        `> Comprehensive vulnerability diagnosis for **${guild.name}**.\n\n` +
        `**Security Score:** \`${score} / 100\` • **Grade:** \`${grade}\`\n` +
        `**Defense Mode:** \`${currentMode}\` • **Antinuke Status:** ${isArmed ? '<a:tungsten_ui_toggle_on:1569329685110849576> `ARMED`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `DISARMED`'}\n\n` +
        `### <a:tungsten_shield:1567242104923627574> Verified Safeguards:\n` +
        checksPassed.join('\n') +
        `\n\n### <a:tungsten_warn:1567246685082746940> Vulnerabilities & Recommended Fixes:\n` +
        (findings.length > 0 ? findings.join('\n\n') : '<a:tungsten_shield:1567242104923627574> *No vulnerabilities detected. Your server meets enterprise security standards.*'),
      footerText: `Tungsten Vulnerability Engine • Requested by ${message.author.username}`
    });

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('anmode:refresh').setLabel('Defense Mode').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_shield:1567242104923627574>'),
      new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_sweep:1567242656281657414>')
    );

    return initial.edit({ content: null, embeds: [reportCard], components: [buttons] });
  }
};
