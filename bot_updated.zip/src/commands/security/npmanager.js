/**
 * Tungsten NP Manager Standalone Command (Node.js)
 * Standalone entry point for !npmanager, !npm, !np-manager.
 */
const { isOwner } = require('../../utils/tools');
const npCommand = require('./np');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'npmanager',
  aliases: ['npm', 'np-manager', 'np_manager'],
  category: 'owner',
  description: 'Manage Tungsten NP Managers and access the NP Manager Studio.',
  usage: '[add <@user|id> | remove <@user|id> | list | panel]',
  cooldown: 3,
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('This command can be executed only by Bot Owner.');
    }
    // Route to np manager subcommand seamlessly
    return npCommand.execute(message, ['manager', ...args], client, prefix);
  }
};
