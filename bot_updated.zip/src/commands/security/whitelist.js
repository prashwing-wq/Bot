/**
 * Whitelist Command & Master Security Whitelist Studio (Node.js)
 * Manages trusted administrators, roles, and channels exempt from Antinuke and Automod triggers.
 * Fully interactive Studio with ActionRows for managing users, roles, channels, and extra owners.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');
const { createEmbed } = require('../../utils/tools');
const { clearImmunityCache, isImmune, isChannelWhitelisted } = require('../../utils/antinukeEngine');
const { isAutomodBypassed } = require('../../utils/automodEngine');
const { createV2Card } = require('../../utils/componentsV2');
const { EMOJIS } = require('../../utils/emojis');
const {
  WHITELIST_SCOPES,
  SCOPES,
  isValidScope,
  getScope,
  isHighDangerScope,
  normalizeScope
} = require('../../security/scopes');
const { invalidateBypassCache } = require('../../security/resolveBypass');

const VALID_ACTIONS = Object.freeze(Object.keys(WHITELIST_SCOPES));

function parseWhitelist(raw) {
  if (!raw) return [];
  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (Array.isArray(parsed)) return parsed.map(String);
  } catch (e) {}
  return [];
}

/**
 * Parses duration string (e.g., '30s', '10m', '2h', '24h', '7d', '30d') into seconds.
 */
function parseDuration(str) {
  if (!str || typeof str !== 'string') return null;
  const match = str.trim().toLowerCase().match(/^(\d+)([smhd])$/);
  if (!match) return null;
  const val = parseInt(match[1], 10);
  const unit = match[2];
  if (isNaN(val) || val <= 0) return null;
  const multipliers = { s: 1, m: 60, h: 3600, d: 86400 };
  return val * multipliers[unit];
}

/**
 * Builds the interactive Master Security Whitelist Studio payload.
 */
function buildWhitelistStudioPayload(guild, sdb, prefix = '!', username = '') {
  const nowSec = Math.floor(Date.now() / 1000);

  // 1. Extra Owners
  const eoRows = sdb.prepare('SELECT owner_id FROM extraowners WHERE guild_id = ?').all(guild.id);
  const eoLines = eoRows.length > 0
    ? eoRows.map(r => `• <@${r.owner_id}> (\`${r.owner_id}\`)`).join('\n')
    : '*No Extra Owners designated.*';

  // 2. Whitelisted Users
  const userRows = sdb.prepare('SELECT user_id, action, expires_at FROM whitelisted_users WHERE guild_id = ?').all(guild.id);
  const userMap = new Map();
  for (const r of userRows) {
    if (!userMap.has(r.user_id)) userMap.set(r.user_id, []);
    userMap.get(r.user_id).push(r);
  }

  let userLines = '*No whitelisted users configured.*';
  if (userMap.size > 0) {
    const list = [];
    for (const [uid, entries] of userMap.entries()) {
      const actList = entries.map(e => e.action);
      const actStr = actList.includes('all') ? 'all' : actList.join(', ');
      const m = guild.members?.cache?.get(uid);
      const tag = (m && m.user?.bot) ? ' `[BOT]`' : '';
      const name = m ? `**${m.displayName}**` : `User \`${uid}\``;

      const expEntry = entries.find(e => e.expires_at !== null && e.expires_at !== undefined);
      let expText = '';
      if (expEntry && expEntry.expires_at) {
        if (expEntry.expires_at <= nowSec) {
          expText = ' • `[EXPIRED]`';
        } else {
          expText = ` • Expires <t:${expEntry.expires_at}:R>`;
        }
      }

      list.push(`• <@${uid}> (${name})${tag} — \`${actStr}\`${expText}`);
    }
    userLines = list.slice(0, 15).join('\n');
    if (list.length > 15) userLines += `\n*...and ${list.length - 15} more users*`;
  }

  // 3. Whitelisted Roles
  const roleRows = sdb.prepare('SELECT role_id, action, expires_at FROM whitelisted_roles WHERE guild_id = ?').all(guild.id);
  const roleMap = new Map();
  for (const r of roleRows) {
    if (!roleMap.has(r.role_id)) roleMap.set(r.role_id, []);
    roleMap.get(r.role_id).push(r);
  }

  let roleLines = '*No whitelisted roles configured.*';
  if (roleMap.size > 0) {
    const list = [];
    for (const [rid, entries] of roleMap.entries()) {
      const actList = entries.map(e => e.action);
      const actStr = actList.includes('all') ? 'all' : actList.join(', ');
      const role = guild.roles?.cache?.get(rid);
      const name = role ? `**@${role.name}**` : `Role \`${rid}\``;

      const expEntry = entries.find(e => e.expires_at !== null && e.expires_at !== undefined);
      let expText = '';
      if (expEntry && expEntry.expires_at) {
        if (expEntry.expires_at <= nowSec) {
          expText = ' • `[EXPIRED]`';
        } else {
          expText = ` • Expires <t:${expEntry.expires_at}:R>`;
        }
      }

      list.push(`• <@&${rid}> (${name}) — \`${actStr}\`${expText}`);
    }
    roleLines = list.slice(0, 10).join('\n');
    if (list.length > 10) roleLines += `\n*...and ${list.length - 10} more roles*`;
  }

  // 4. Whitelisted Channels
  const chanRows = sdb.prepare('SELECT channel_id, scope, added_at FROM whitelisted_channels WHERE guild_id = ?').all(guild.id);
  let chanLines = '*No whitelisted channels configured.*';
  if (chanRows.length > 0) {
    chanLines = chanRows.slice(0, 10).map(r => {
      const ch = guild.channels?.cache?.get(r.channel_id);
      const name = ch ? `#${ch.name}` : `Channel \`${r.channel_id}\``;
      return `• <#${r.channel_id}> (${name}) — Scope: \`${r.scope}\``;
    }).join('\n');
    if (chanRows.length > 10) chanLines += `\n*...and ${chanRows.length - 10} more channels*`;
  }

  const embed = createEmbed({
    color: 0x2b2d31,
    title: `<a:tungsten_shield:1567242104923627574>  Master Security Whitelist Studio • ${guild.name}`,
    description:
      `> Whitelisted members, roles, and channels bypass automated Antinuke & Automod security checks.\n` +
      `> Server Owners hold master oversight; Extra Owners operate under a separate restricted whitelist tier.\n\n` +
      `**<a:tungsten_crown:1567238355463176334> Designated Extra Owners (${eoRows.length}/10):**\n` +
      eoLines + '\n\n' +
      `**<a:tungsten_users:1567246628606185502> Whitelisted Administrators (${userMap.size}):**\n` +
      userLines + '\n\n' +
      `**<a:tungsten_shield:1567242104923627574> Whitelisted Roles (${roleMap.size}):**\n` +
      roleLines + '\n\n' +
      `**<a:tungsten_gear:1567239932970406012> Whitelisted Channels (${chanRows.length}):**\n` +
      chanLines + '\n\n' +
      `**<a:tungsten_bolt:1567233430570405968> Quick Management & Commands:**\n` +
      `• \`${prefix}wl <@user|@role> [action] [time]\` — Authorize target (e.g. \`${prefix}wl @user role 24h\`)\n` +
      `• \`${prefix}wl channel <#channel> [scope]\` — Whitelist channel for automod/links/all\n` +
      `• \`${prefix}wl check <target>\` — Diagnostic inspection of target immunity status\n` +
      `• \`${prefix}wl audit\` — Whitelist operation audit trail\n` +
      `• \`${prefix}unwl <@user|@role|#channel>\` — Revoke authorization`,
    footer: {
      text: `Total: ${userMap.size} user(s), ${roleMap.size} role(s), ${chanRows.length} channel(s) • Tungsten Master Whitelist Matrix`
    }
  });

  const row0 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('wl:add_user').setLabel('Add User').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_plus:1567241846453833840>'),
    new ButtonBuilder().setCustomId('wl:remove_user').setLabel('Remove User').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_minus:1567241276057849856>'),
    new ButtonBuilder().setCustomId('wl:manage_user').setLabel('Manage User').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_shield:1567242104923627574>')
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('wl:add_role').setLabel('Add Role').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_plus:1567241846453833840>'),
    new ButtonBuilder().setCustomId('wl:remove_role').setLabel('Remove Role').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_minus:1567241276057849856>'),
    new ButtonBuilder().setCustomId('wl:manage_role').setLabel('Manage Role').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_shield:1567242104923627574>')
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('wl:add_channel').setLabel('Add Channel').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_plus:1567241846453833840>'),
    new ButtonBuilder().setCustomId('wl:remove_channel').setLabel('Remove Channel').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_minus:1567241276057849856>'),
    new ButtonBuilder().setCustomId('wl:manage_channel').setLabel('Manage Channel').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_gear:1567239932970406012>')
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('wl:open_eo').setLabel('Extra Owners').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_crown:1567238355463176334>'),
    new ButtonBuilder().setCustomId('wl:refresh').setLabel('Refresh Panel').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [embed], components: [row0, row1, row2, row3] };
}

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'whitelist',
  aliases: ['wl'],
  category: 'security',
  description: 'Master Security Whitelist Studio, Scope Configuration, and Channel Authorization Hub.',
  usage: '[@user|@role|#channel|id] [action/scope] [duration] | channel <#channel> [scope] | check <target> | audit | clear [users|roles|channels|all]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const sdb = getServerDb(message.guild.id);
    const isServerOwner = message.author.id === message.guild.ownerId;
    const isExtraOwner = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id);

    if (!isServerOwner && !isExtraOwner) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner** or **Extra Owners** can manage the whitelist.');
    }

    const sub = args[0]?.toLowerCase();

    // ─────────────────────────────────────────────────────────────
    // 1. Studio Panel
    // ─────────────────────────────────────────────────────────────
    if (!sub || ['overview', 'panel', 'show', 'list', 'view'].includes(sub)) {
      const payload = buildWhitelistStudioPayload(message.guild, sdb, prefix, message.author.username);
      return message.reply(payload);
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Audit Trail (!wl audit [limit])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'audit' || sub === 'logs' || sub === 'log') {
      const limit = Math.min(25, Math.max(5, parseInt(args[1], 10) || 10));
      const logs = sdb.prepare('SELECT target_type, target_id, action_scope, operator_id, operation, timestamp FROM whitelist_audit_log WHERE guild_id = ? ORDER BY timestamp DESC LIMIT ?')
        .all(message.guild.id, limit);

      if (logs.length === 0) {
        return message.reply('<a:tungsten_warn:1567246685082746940> No whitelist audit entries recorded yet.');
      }

      const logLines = logs.map(l => {
        const op = l.operation.toUpperCase();
        let targetStr = `\`${l.target_id}\``;
        if (l.target_type === 'user') targetStr = `<@${l.target_id}>`;
        else if (l.target_type === 'role') targetStr = `<@&${l.target_id}>`;
        else if (l.target_type === 'channel') targetStr = `<#${l.target_id}>`;

        return `• <t:${l.timestamp}:R> — **${op}** ${l.target_type} ${targetStr} [Scope: \`${l.action_scope}\`] by <@${l.operator_id}>`;
      }).join('\n');

      const embed = createEmbed({
        color: 0x2b2d31,
        title: `<a:tungsten_chart:1567234342701367357>  Whitelist Audit Log • ${message.guild.name}`,
        description: `Recent administrative trust modifications:\n\n${logLines}`,
        footer: { text: `Displaying last ${logs.length} operations • Tungsten Security Telemetry` }
      });

      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Clear Subcommand (!wl clear [users|roles|channels|all])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'clear' || sub === 'reset') {
      const targetType = args[1]?.toLowerCase() || 'all';
      let clearedSummary = '';

      if (targetType === 'users' || targetType === 'all') {
        const delU = sdb.prepare('DELETE FROM whitelisted_users WHERE guild_id = ?').run(message.guild.id);
        sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)').run('whitelist', JSON.stringify([]));
        clearedSummary += `• Whitelisted Users: **${delU.changes}** cleared\n`;
      }
      if (targetType === 'roles' || targetType === 'all') {
        const delR = sdb.prepare('DELETE FROM whitelisted_roles WHERE guild_id = ?').run(message.guild.id);
        clearedSummary += `• Whitelisted Roles: **${delR.changes}** cleared\n`;
      }
      if (targetType === 'channels' || targetType === 'all') {
        const delC = sdb.prepare('DELETE FROM whitelisted_channels WHERE guild_id = ?').run(message.guild.id);
        clearedSummary += `• Whitelisted Channels: **${delC.changes}** cleared\n`;
      }

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(message.guild.id, targetType, 'ALL', 'all', message.author.id, 'clear', Math.floor(Date.now() / 1000));

      clearImmunityCache(message.guild.id);
      syncServerDataToMaster(message.guild.id);

      const card = createV2Card({
        color: 0xED4245,
        title: '<a:tungsten_sweep:1567242656281657414>  Whitelist Database Purged',
        description:
          `> Successfully reset whitelist entries for scope: \`${targetType.toUpperCase()}\`.\n\n` +
          clearedSummary +
          `\n-# All affected targets are now subject to standard Antinuke & Automod enforcement.`,
        footer: { text: `Purged by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Diagnostic Check (!wl check <target>)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'check' || sub === 'inspect') {
      const targetRaw = args[1];
      if (!targetRaw) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}wl check <@user|@role|#channel|id>\``);
      }

      const cleanId = targetRaw.replace(/[<@!&#>]/g, '');
      const nowSec = Math.floor(Date.now() / 1000);

      // Check if channel
      const ch = message.guild.channels.cache.get(cleanId);
      if (ch || targetRaw.startsWith('<#')) {
        const chRows = sdb.prepare('SELECT scope, added_at, added_by FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ?').all(message.guild.id, cleanId);
        const scopes = chRows.map(r => `\`${r.scope}\``).join(', ') || '*None*';
        const isBypassed = isChannelWhitelisted(message.guild.id, cleanId, 'all');

        const card = createV2Card({
          color: chRows.length > 0 ? 0x2ECC71 : 0xED4245,
          title: `<a:tungsten_shield:1567242104923627574>  Channel Whitelist Status • #${ch?.name || cleanId}`,
          description:
            `• **Channel:** <#${cleanId}> (\`${cleanId}\`)\n` +
            `• **Whitelisted Status:** ${chRows.length > 0 ? '`<ACTIVE>`' : '`<INACTIVE>`'}\n` +
            `• **Authorized Scopes:** ${scopes}\n` +
            `• **Global Bypass:** ${isBypassed ? '`<ENABLED>`' : '`<DISABLED>`'}\n\n` +
            `-# Manage with \`${prefix}wl channel <#${cleanId}>\` or \`${prefix}unwl <#${cleanId}>\``,
          footer: { text: `Diagnostic query by ${message.author.username}` }
        });
        return message.reply({ embeds: [card] });
      }

      // Check if role
      const role = message.guild.roles.cache.get(cleanId);
      if (role || targetRaw.startsWith('<@&')) {
        const rRows = sdb.prepare('SELECT action, expires_at, added_by FROM whitelisted_roles WHERE guild_id = ? AND role_id = ?').all(message.guild.id, cleanId);
        let statusText = '*Role is not whitelisted.*';
        if (rRows.length > 0) {
          statusText = rRows.map(r => {
            const exp = r.expires_at ? (r.expires_at <= nowSec ? '`[EXPIRED]`' : `Expires <t:${r.expires_at}:R>`) : '`Permanent`';
            return `• Action: \`${r.action}\` — ${exp}`;
          }).join('\n');
        }

        const card = createV2Card({
          color: rRows.length > 0 ? 0x2ECC71 : 0xED4245,
          title: `<a:tungsten_shield:1567242104923627574>  Role Whitelist Status • @${role?.name || cleanId}`,
          description:
            `• **Role:** <@&${cleanId}> (\`${cleanId}\`)\n` +
            `• **Authorization Status:** ${rRows.length > 0 ? '`<ACTIVE>`' : '`<INACTIVE>`'}\n\n` +
            `**Authorized Policies:**\n${statusText}\n\n` +
            `-# Manage with \`${prefix}wl <@&${cleanId}>\` or \`${prefix}unwl <@&${cleanId}>\``,
          footer: { text: `Diagnostic query by ${message.author.username}` }
        });
        return message.reply({ embeds: [card] });
      }

      // Check user
      let member = null;
      try {
        member = message.guild.members.cache.get(cleanId) || await message.guild.members.fetch(cleanId).catch(() => null);
      } catch (e) {}

      const isPrimaryOwner = cleanId === message.guild.ownerId;
      const isExtraOwnerUser = Boolean(sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, cleanId));
      const userRows = sdb.prepare('SELECT action, expires_at FROM whitelisted_users WHERE guild_id = ? AND user_id = ?').all(message.guild.id, cleanId);

      let userStatusText = '*No direct user whitelist policies.*';
      if (userRows.length > 0) {
        userStatusText = userRows.map(r => {
          const exp = r.expires_at ? (r.expires_at <= nowSec ? '`[EXPIRED]`' : `Expires <t:${r.expires_at}:R>`) : '`Permanent`';
          return `• Action: \`${r.action}\` — ${exp}`;
        }).join('\n');
      }

      const antinukeImmune = isImmune(message.guild, cleanId, 'all');
      const automodImmune = isAutomodBypassed(message.guild, member, null, 'all', cleanId);

      const card = createV2Card({
        color: antinukeImmune ? 0x2ECC71 : 0x2b2d31,
        title: `<a:tungsten_shield:1567242104923627574>  Security Diagnostic • ${member?.displayName || cleanId}`,
        description:
          `• **Target:** <@${cleanId}> (\`${cleanId}\`)\n` +
          `• **Primary Server Owner:** ${isPrimaryOwner ? '`<YES>`' : '`<NO>`'}\n` +
          `• **Extra Owner Status:** ${isExtraOwnerUser ? '`<ACTIVE>`' : '`<NONE>`'}\n` +
          `• **Antinuke Immunity:** ${antinukeImmune ? '`<IMMUNE>`' : '`<ENFORCED>`'}\n` +
          `• **Automod Bypass:** ${automodImmune ? '`<BYPASS>`' : '`<FILTERED>`'}\n\n` +
          `**User Whitelist Policies:**\n${userStatusText}\n\n` +
          `-# Manage with \`${prefix}wl <@${cleanId}>\` or \`${prefix}unwl <@${cleanId}>\``,
        footer: { text: `Diagnostic query by ${message.author.username}` }
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 5. Channel Whitelisting (!wl channel <#channel> [scope])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'channel' || sub === 'ch') {
      const channelInput = args[1];
      if (!channelInput) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}wl channel <#channel|id> [scope (all|automod|links|spam|all)]\``);
      }

      const cleanChId = channelInput.replace(/[<#>]/g, '');
      const targetChannel = message.guild.channels.cache.get(cleanChId) || await client.channels.fetch(cleanChId).catch(() => null);

      if (!targetChannel || targetChannel.guildId !== message.guild.id) {
        return message.reply('<a:tungsten_close:1567234632905138206> Invalid channel. Please mention a text/voice channel in this server.');
      }

      const scopeArg = args[2]?.toLowerCase() || 'all';
      const validScopes = ['all', 'automod', 'links', 'spam', 'antinuke', ...VALID_ACTIONS];
      const scope = validScopes.includes(scopeArg) ? scopeArg : 'all';

      const existing = sdb.prepare('SELECT 1 FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ? AND scope = ?').get(message.guild.id, targetChannel.id, scope);
      if (existing) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Channel <#${targetChannel.id}> is already whitelisted for scope \`${scope}\`.`);
      }

      const nowSec = Math.floor(Date.now() / 1000);
      sdb.prepare('INSERT OR REPLACE INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at) VALUES (?, ?, ?, ?, ?)')
        .run(message.guild.id, targetChannel.id, scope, message.author.id, nowSec);

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(message.guild.id, 'channel', targetChannel.id, scope, message.author.id, 'whitelist', nowSec);

      clearImmunityCache(message.guild.id);

      const { buildTargetWhitelistPayload } = require('../../utils/whitelistUi');
      const payload = buildTargetWhitelistPayload(message.guild, sdb, 'channel', targetChannel.id, prefix);
      return message.reply(payload);
    }

    // ─────────────────────────────────────────────────────────────
    // 6. Direct User, Role, or Channel Whitelisting (with optional scope & duration)
    // ─────────────────────────────────────────────────────────────
    let targetInput = args[0];
    let remainingArgs = args.slice(1);

    if (sub === 'manage') {
      targetInput = args[1];
      remainingArgs = args.slice(2);
      if (!targetInput) {
        const payload = buildWhitelistStudioPayload(message.guild, sdb, prefix, message.author.username);
        return message.reply(payload);
      }
      const cleanId = targetInput.replace(/[<@!&#>]/g, '');
      const { buildTargetWhitelistPayload } = require('../../utils/whitelistUi');

      if (targetInput.startsWith('<#') || message.guild.channels?.cache?.has(cleanId)) {
        return message.reply(buildTargetWhitelistPayload(message.guild, sdb, 'channel', cleanId, prefix));
      }
      if (targetInput.startsWith('<@&') || message.guild.roles?.cache?.has(cleanId)) {
        return message.reply(buildTargetWhitelistPayload(message.guild, sdb, 'role', cleanId, prefix));
      }
      const isEo = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, cleanId);
      if (isEo) {
        return message.reply(buildTargetWhitelistPayload(message.guild, sdb, 'extraowner', cleanId, prefix));
      }
      return message.reply(buildTargetWhitelistPayload(message.guild, sdb, 'user', cleanId, prefix));
    }

    if (sub === 'user' || sub === 'member' || sub === 'admin') {
      targetInput = args[1];
      remainingArgs = args.slice(2);
    } else if (sub === 'role') {
      targetInput = args[1];
      remainingArgs = args.slice(2);
    }

    if (!targetInput) {
      const payload = buildWhitelistStudioPayload(message.guild, sdb, prefix, message.author.username);
      return message.reply(payload);
    }

    const cleanId = targetInput.replace(/[<@!&#>]/g, '');
    const isRoleMention = targetInput.startsWith('<@&');
    const isChannelMention = targetInput.startsWith('<#');

    // If channel mention or existing channel ID provided directly
    if (isChannelMention || message.guild.channels.cache.has(cleanId)) {
      const ch = message.guild.channels.cache.get(cleanId) || await client.channels.fetch(cleanId).catch(() => null);
      if (ch && ch.guildId === message.guild.id) {
        const scopeArg = remainingArgs[0]?.toLowerCase() || 'all';
        const validScopes = ['all', 'automod', 'links', 'spam', 'antinuke', ...VALID_ACTIONS];
        const scope = validScopes.includes(scopeArg) ? scopeArg : 'all';

        const existing = sdb.prepare('SELECT 1 FROM whitelisted_channels WHERE guild_id = ? AND channel_id = ? AND scope = ?').get(message.guild.id, ch.id, scope);
        if (existing) {
          return message.reply(`<a:tungsten_warn:1567246685082746940> Channel <#${ch.id}> is already whitelisted for scope \`${scope}\`.`);
        }

        const nowSec = Math.floor(Date.now() / 1000);
        sdb.prepare('INSERT OR REPLACE INTO whitelisted_channels (guild_id, channel_id, scope, added_by, added_at) VALUES (?, ?, ?, ?, ?)')
          .run(message.guild.id, ch.id, scope, message.author.id, nowSec);

        sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
          .run(message.guild.id, 'channel', ch.id, scope, message.author.id, 'whitelist', nowSec);

        clearImmunityCache(message.guild.id);

        const { buildTargetWhitelistPayload } = require('../../utils/whitelistUi');
        const payload = buildTargetWhitelistPayload(message.guild, sdb, 'channel', ch.id, prefix);
        return message.reply(payload);
      }
    }

    const roleTarget = isRoleMention
      ? (message.mentions.roles?.first() || message.guild.roles?.cache?.get(cleanId))
      : (message.guild.roles?.cache?.get(cleanId) || null);

    // Resolve scope & duration
    let action = 'all';
    let durationSec = null;

    const arg0Duration = parseDuration(remainingArgs[0]);
    if (arg0Duration) {
      action = 'all';
      durationSec = arg0Duration;
    } else {
      if (remainingArgs[0]) {
        const actCandidate = remainingArgs[0].toLowerCase();
        if (isValidScope(actCandidate)) {
          action = normalizeScope(actCandidate);
        } else if (VALID_ACTIONS.includes(actCandidate)) {
          action = actCandidate;
        }
      }
      durationSec = parseDuration(remainingArgs[1]);
    }

    const nowSec = Math.floor(Date.now() / 1000);
    const expiresAt = durationSec ? (nowSec + durationSec) : null;
    const durationLabel = expiresAt ? `Expires <t:${expiresAt}:R>` : '`Permanent`';

    // A. Role Whitelisting
    if (roleTarget) {
      // Role Safety Checks: Refuse @everyone and Managed bot roles
      if (roleTarget.id === message.guild.id || roleTarget.name === '@everyone') {
        return message.reply('<a:tungsten_close:1567234632905138206> Security Restriction: The **@everyone** role cannot be whitelisted.');
      }
      if (roleTarget.managed) {
        return message.reply('<a:tungsten_close:1567234632905138206> Security Restriction: Managed bot integration roles cannot be whitelisted.');
      }

      sdb.prepare(`
        INSERT OR REPLACE INTO whitelisted_roles (guild_id, role_id, action, expires_at, added_by)
        VALUES (?, ?, ?, ?, ?)
      `).run(message.guild.id, roleTarget.id, action, expiresAt, message.author.id);

      sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(message.guild.id, 'role', roleTarget.id, action, message.author.id, 'whitelist', nowSec);

      clearImmunityCache(message.guild.id);
      invalidateBypassCache(message.guild.id, roleTarget.id);

      const { buildTargetWhitelistPayload } = require('../../utils/whitelistUi');
      const payload = buildTargetWhitelistPayload(message.guild, sdb, 'role', roleTarget.id, prefix);
      return message.reply(payload);
    }

    // B. User Whitelisting
    let targetUser = null;
    try {
      targetUser = message.mentions.users?.first() || await client.users.fetch(cleanId).catch(() => null);
    } catch (e) {}

    if (!targetUser) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve user, role, or channel matching \`${targetInput}\`.\nPlease specify a valid target.`);
    }

    sdb.prepare(`
      INSERT OR REPLACE INTO whitelisted_users (guild_id, user_id, action, expires_at, added_by)
      VALUES (?, ?, ?, ?, ?)
    `).run(message.guild.id, targetUser.id, action, expiresAt, message.author.id);

    // Sync to server_settings JSON array for backward compatibility
    const row = sdb.prepare('SELECT value FROM server_settings WHERE key = ?').get('whitelist');
    const currentWl = row ? parseWhitelist(row.value) : [];
    if (!currentWl.includes(targetUser.id)) {
      currentWl.push(targetUser.id);
      sdb.prepare('INSERT OR REPLACE INTO server_settings (key, value) VALUES (?, ?)')
        .run('whitelist', JSON.stringify(currentWl));
    }
    syncServerDataToMaster(message.guild.id);

    sdb.prepare('INSERT INTO whitelist_audit_log (guild_id, target_type, target_id, action_scope, operator_id, operation, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(message.guild.id, 'user', targetUser.id, action, message.author.id, 'whitelist', nowSec);

    clearImmunityCache(message.guild.id);
    invalidateBypassCache(message.guild.id, targetUser.id);

    const { buildTargetWhitelistPayload: buildTargetWlUser } = require('../../utils/whitelistUi');
    const payload = buildTargetWlUser(message.guild, sdb, 'user', targetUser.id, prefix);
    return message.reply(payload);
  },

  buildWhitelistStudioPayload,
  VALID_ACTIONS,
  parseDuration
};
