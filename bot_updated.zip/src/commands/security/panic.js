/**
 * Emergency Panic Lockdown Command (Node.js)
 * High-speed full server isolation, channel lockdown, and permission freezing with 5-stage cyber animation.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const {
  animateSequence,
  getPanicLockdownFrames,
  getPanicUnlockFrames
} = require('../../utils/animation');
const { getServerDb, syncServerDataToMaster } = require('../../utils/serverDb');
const { resolveEmoji } = require('../../utils/emojis');

function getLockdownStatus(guildId) {
  try {
    const sdb = getServerDb(guildId);
    const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'panic_status'").get();
    return row ? row.value === '1' || row.value === 'true' : false;
  } catch (e) {
    return false;
  }
}

function setLockdownStatus(guildId, locked) {
  try {
    const sdb = getServerDb(guildId);
    sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('panic_status', ?)").run(locked ? '1' : '0');
    syncServerDataToMaster(guildId);
  } catch (e) {}
}

function createPanicButtons(isLocked, hasBaseline = false) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('panic:lock')
      .setLabel('Engage Lockdown')
      .setEmoji('<a:tungsten_lockdown:1569329429174296697>')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(isLocked),
    new ButtonBuilder()
      .setCustomId('panic:unlock')
      .setLabel('Lift Lockdown')
      .setEmoji('<a:tungsten_unlock:1567246515209117968>')
      .setStyle(ButtonStyle.Success)
      .setDisabled(!isLocked),
    new ButtonBuilder()
      .setCustomId('panic:status')
      .setLabel('Refresh')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Secondary)
  );

  if (hasBaseline) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('panic:restore_baseline')
        .setLabel('Restore Baseline')
        .setEmoji('<a:tungsten_cat_backups:1567233747567251666>')
        .setStyle(ButtonStyle.Primary)
    );
  }

  return row;
}

/**
 * Capture pre-attack clean baseline snapshot.
 */
async function captureCleanSnapshot(guild) {
  const { captureCleanSnapshot: ccs } = require('../../interactions/panic');
  return ccs(guild);
}

/**
 * Execute panic unlock procedure.
 */
async function executePanicUnlock(guild, client, reason) {
  const { executePanicUnlock: epu } = require('../../interactions/panic');
  return epu(guild, client, reason);
}

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages', 'EmbedLinks', 'ManageChannels'],
  name: 'panic',
  aliases: ['lockdown', 'serverpanic', 'emergencylockdown'],
  category: 'security',
  description: 'Instant full-server emergency quarantine & lockdown with 5-stage cyber animation.',
  usage: '[lock|unlock|status]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    // Only Server Owner or Extra Owners can trigger emergency panic mode
    let isAuthorized = message.author.id === message.guild.ownerId;
    if (!isAuthorized) {
      try {
        const sdb = getServerDb(message.guild.id);
        const eo = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id);
        if (eo) isAuthorized = true;
      } catch (_) {}
    }

    if (!isAuthorized) {
      return message.reply(`${resolveEmoji(client, 'cross')} Access Denied: Only the Server Owner or Extra Owners can trigger emergency panic lockdown.`);
    }

    const sub = args[0]?.toLowerCase();
    const isLocked = getLockdownStatus(message.guild.id);
    const sdb = getServerDb(message.guild.id);
    const cleanBaselineRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_baseline_snapshot_id'").get();
    const hasBaseline = Boolean(cleanBaselineRow?.value);

    // 1. Dashboard Overview
    if (!sub || sub === 'status' || sub === 'panel') {
      const statusBadge = isLocked ? '<a:tungsten_lockdown:1569329429174296697> `Quarantine Active (Locked)`' : '<a:tungsten_ui_toggle_off:1569329677187678368> `Normal (Unrestricted)`';
      const textChannels = message.guild.channels.cache.filter(c => c.isTextBased()).size;
      const voiceChannels = message.guild.channels.cache.filter(c => c.type === 2 || c.type === 13 || c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice).size;

      const embed = createEmbed({
        color: isLocked ? client.config.COLORS.DANGER : client.config.COLORS.PRIMARY,
        title: `<a:tungsten_alarm:1567229471474585682> Emergency Lockdown Hub — ${message.guild.name}`,
        description:
          `Instant server-wide quarantine protocol for raid containment.\n\n` +
          `• System State: **${statusBadge}**\n` +
          `• Channels Monitored: **${textChannels}** text • **${voiceChannels}** voice\n` +
          `• Enforcement: Revokes SendMessages & Connect/Speak for @everyone\n` +
          `• Exempt: Server Owner and Authorized Administrators\n` +
          (hasBaseline ? `• Clean Baseline: Baseline snapshot \`#${cleanBaselineRow.value}\` ready\n` : '') +
          `\n**Commands**\n` +
          `• \`${prefix}panic lock\` — Engage 5-stage animated lockdown\n` +
          `• \`${prefix}panic unlock\` — Lift lockdown and restore channel access`,
        footer: { text: 'Tungsten Incident Response Protocol' }
      });

      return message.reply({ embeds: [embed], components: [createPanicButtons(isLocked, hasBaseline)] });
    }

    // 2. Engage Lockdown
    if (sub === 'lock' || sub === 'on' || sub === 'trigger' || sub === 'start') {
      if (isLocked) {
        return message.reply(`${resolveEmoji(client, 'warning')} Emergency Lockdown is already active! Re-snapshotting is blocked to prevent permanent lockdown.`);
      }

      setLockdownStatus(message.guild.id, true);

      const snapshot = {
        timestamp: Date.now(),
        channels: {}
      };

      const channelList = Array.from(message.guild.channels.cache.values());
      for (const channel of channelList) {
        if (channel.isThread?.()) continue;
        const overwrite = channel.permissionOverwrites?.cache?.get(message.guild.id);
        const isVoice = channel.type === 2 || channel.type === 13 || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildStageVoice;
        if (channel.isTextBased?.() || isVoice) {
          snapshot.channels[channel.id] = overwrite
            ? { allow: overwrite.allow.bitfield.toString(), deny: overwrite.deny.bitfield.toString() }
            : null;
        }
      }

      const frames = getPanicLockdownFrames();
      const statusMsg = await message.reply({ embeds: [frames[0]], components: [] });

      const animPromise = animateSequence(statusMsg, frames.slice(0, 4), { intervalMs: 500 });

      // Lock text channels
      let lockedCount = 0;
      for (const channel of channelList) {
        if (channel.isTextBased?.() && !channel.isThread?.() && channel.permissionsFor?.(message.guild.members.me)?.has?.(PermissionFlagsBits.ManageChannels)) {
          try {
            await channel.permissionOverwrites?.edit?.(message.guild.roles.everyone, {
              SendMessages: false
            });
            lockedCount++;
          } catch (e) {}
        }
      }

      // Lock voice channels (Fix 1)
      let voiceLockedCount = 0;
      for (const channel of channelList) {
        const isVoice = channel.type === 2 || channel.type === 13 || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildStageVoice;
        if (isVoice && channel.permissionsFor?.(message.guild.members.me)?.has?.(PermissionFlagsBits.ManageChannels)) {
          try {
            await channel.permissionOverwrites?.edit?.(message.guild.roles.everyone, {
              Connect: false,
              Speak: false
            });
            snapshot.channels[channel.id] = Object.assign(snapshot.channels[channel.id] || {}, { voiceLocked: true });
            voiceLockedCount++;
          } catch (e) {}
        }
      }

      // Revoke all active invites (Fix 2)
      let revokedInvites = 0;
      try {
        if (typeof message.guild.invites?.fetch === 'function') {
          const invites = await message.guild.invites.fetch().catch(() => null);
          if (invites) {
            for (const invite of invites.values()) {
              await invite.delete('[Tungsten Panic] Revoking all invites during emergency lockdown.').catch(() => null);
              revokedInvites++;
            }
          }
        } else if (typeof message.guild.fetchInvites === 'function') {
          const invites = await message.guild.fetchInvites().catch(() => null);
          if (invites) {
            for (const invite of invites.values()) {
              await invite.delete('[Tungsten Panic] Revoking all invites during emergency lockdown.').catch(() => null);
              revokedInvites++;
            }
          }
        }
      } catch (e) {}
      snapshot.invitesRevoked = revokedInvites;

      try {
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('panic_snapshot', ?)").run(JSON.stringify(snapshot));
      } catch (e) {}

      // Auto-unlock timer (Fix 4)
      const autoUnlockRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'panic_auto_unlock_hours'").get();
      const autoUnlockHours = (autoUnlockRow && !isNaN(autoUnlockRow.value)) ? Number(autoUnlockRow.value) : 6;
      if (autoUnlockHours > 0) {
        const unlockAt = Date.now() + (autoUnlockHours * 3600000);
        sdb.prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('panic_auto_unlock_at', ?)").run(String(unlockAt));

        try {
          const { scheduleTask } = require('../../utils/scheduler');
          scheduleTask(message.guild.id, 'panic_auto_unlock', unlockAt, { reason: 'Auto-unlock: Time limit reached' });
        } catch (_) {}

        const timer = setTimeout(async () => {
          try {
            const isStillLocked = getLockdownStatus(message.guild.id);
            if (isStillLocked) {
              await executePanicUnlock(message.guild, client, 'Auto-unlock: Time limit reached');
            }
          } catch (_) {}
        }, Math.min(autoUnlockHours * 3600000, 2147483647));
        if (timer && typeof timer.unref === 'function') timer.unref();
      }

      await animPromise;

      const finalEmbed = createEmbed({
        color: client.config.COLORS.DANGER,
        title: '<a:tungsten_lockdown:1569329429174296697> EMERGENCY LOCKDOWN ENGAGED',
        description:
          `> **Server Quarantine is Active**\n` +
          `> All public communications have been halted to stop unauthorized damage.\n\n` +
          `• **Secured Channels:** \`${lockedCount}\` text channels locked\n` +
          `• **Secured Voice Channels:** \`${voiceLockedCount}\` voice channels locked\n` +
          `• **Channel State:** \`SendMessages: FALSE\` & \`Connect/Speak: FALSE\` for \`@everyone\`\n` +
          (revokedInvites > 0 ? `• **Revoked Invites:** \`${revokedInvites}\` active invites deleted\n` : '') +
          `• **Auto-Unlock:** ${autoUnlockHours > 0 ? `\`${autoUnlockHours} hours\`` : '`Manual Only`'}\n` +
          `• **Exempt:** Server Owner and Authorized Administrators\n\n` +
          `-# Click below or type \`${prefix}panic unlock\` to restore normal communications.`,
        footer: { text: 'Tungsten Threat Containment Protocol • Locked' }
      });

      return statusMsg.edit({ embeds: [finalEmbed], components: [createPanicButtons(true, hasBaseline)] });
    }

    // 3. Lift Lockdown
    if (sub === 'unlock' || sub === 'off' || sub === 'lift' || sub === 'stop') {
      const frames = getPanicUnlockFrames();
      const statusMsg = await message.reply({ embeds: [frames[0]], components: [] });

      const animPromise = animateSequence(statusMsg, frames.slice(0, 2), { intervalMs: 500 });

      const unlockResult = await executePanicUnlock(message.guild, client, 'Manual command unlock');

      await animPromise;

      const finalEmbed = createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '<a:tungsten_ui_toggle_off:1569329677187678368> EMERGENCY LOCKDOWN DISENGAGED',
        description:
          `> **Server Quarantine Lifted**\n` +
          `> Communications have been safely restored across all text and voice channels.\n\n` +
          `• **Restored Channels:** \`${unlockResult.unlockedCount}\` text channels reopened\n` +
          `• **Restored Voice Channels:** \`${unlockResult.unlockedVoiceCount}\` voice channels reopened\n` +
          (hasBaseline ? `• **Clean Baseline Available:** Snapshot \`#${cleanBaselineRow.value}\` ready. Click Restore Baseline below to fully rollback to pre-attack state.\n` : '') +
          `• **Status:** <a:tungsten_ui_toggle_off:1569329677187678368> Normal member operations active.`,
        footer: { text: 'Tungsten Threat Containment Protocol • Restored' }
      });

      return statusMsg.edit({ embeds: [finalEmbed], components: [createPanicButtons(false, hasBaseline)] });
    }

    return message.reply(`Usage: \`${prefix}panic [lock|unlock|status]\``);
  },

  getLockdownStatus,
  setLockdownStatus,
  createPanicButtons,
  captureCleanSnapshot,
  executePanicUnlock
};
