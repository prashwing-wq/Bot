/**
 * Tungsten Discord Native AutoMod Command (Node.js)
 * Manages Discord platform-native AutoMod rules (keyword filters, spam, mention spam, actions).
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  AutoModerationRuleEventType,
  AutoModerationRuleTriggerType,
  AutoModerationActionType
} = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { setAutomodRule } = require('../../utils/automodEngine');
const { getServerDb } = require('../../utils/serverDb');

const TRIGGER_TYPE_NAMES = {
  [AutoModerationRuleTriggerType.Keyword]: 'Keyword',
  [AutoModerationRuleTriggerType.Spam]: 'Spam Filter',
  [AutoModerationRuleTriggerType.KeywordPreset]: 'Keyword Preset',
  [AutoModerationRuleTriggerType.MentionSpam]: 'Mention Spam',
  [AutoModerationRuleTriggerType.MemberProfile]: 'Member Profile'
};

const ACTION_TYPE_NAMES = {
  [AutoModerationActionType.BlockMessage]: 'Block Message',
  [AutoModerationActionType.SendAlertMessage]: 'Send Alert',
  [AutoModerationActionType.Timeout]: 'Timeout Member',
  [AutoModerationActionType.BlockMemberInteraction]: 'Block Interaction'
};

function formatActions(actions = []) {
  if (!actions.length) return 'None';
  return actions
    .map(act => {
      const name = ACTION_TYPE_NAMES[act.type] || `Action (${act.type})`;
      if (act.type === AutoModerationActionType.Timeout && act.metadata?.durationSeconds) {
        return `${name} (${act.metadata.durationSeconds}s)`;
      }
      if (act.type === AutoModerationActionType.SendAlertMessage && (act.metadata?.channel || act.metadata?.channelId)) {
        const chId = act.metadata.channel || act.metadata.channelId;
        return `${name} (<#${chId}>)`;
      }
      return name;
    })
    .join(', ');
}

module.exports = {
  name: 'nativeautomod',
  aliases: ['nam', 'nativeam', 'discordautomod'],
  category: 'security',
  description: 'Manage Discord platform-native AutoMod rules (keywords, spam, mentions).',
  usage: '<list | add keyword|spam|mentions | delete <ruleId> | enable <id> | disable <id>>',
  cooldown: 3,
  permissions: ['ManageGuild'],
  botPermissions: ['ManageGuild'],

  slash: new SlashCommandBuilder()
    .setName('nativeautomod')
    .setDescription('Manage Discord platform-native AutoMod rules.')
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all native AutoMod rules in the server.')
    )
    .addSubcommand(sub =>
      sub
        .setName('delete')
        .setDescription('Delete a native AutoMod rule.')
        .addStringOption(opt =>
          opt
            .setName('rule_id')
            .setDescription('The ID of the rule to delete.')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('enable')
        .setDescription('Enable a native AutoMod rule.')
        .addStringOption(opt =>
          opt
            .setName('rule_id')
            .setDescription('The ID of the rule to enable.')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('disable')
        .setDescription('Disable a native AutoMod rule.')
        .addStringOption(opt =>
          opt
            .setName('rule_id')
            .setDescription('The ID of the rule to disable.')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Add a new native AutoMod rule.')
        .addStringOption(opt =>
          opt
            .setName('type')
            .setDescription('Type of rule to add.')
            .setRequired(true)
            .addChoices(
              { name: 'Keyword Filter', value: 'keyword' },
              { name: 'Spam Filter', value: 'spam' },
              { name: 'Mention Spam', value: 'mentions' }
            )
        )
        .addStringOption(opt =>
          opt
            .setName('input')
            .setDescription('Keywords (comma-separated) or mention limit (number).')
            .setRequired(false)
        )
        .addStringOption(opt =>
          opt
            .setName('action')
            .setDescription('Action to take on trigger (default: block).')
            .setRequired(false)
            .addChoices(
              { name: 'Block Message', value: 'block' },
              { name: 'Send Alert', value: 'alert' },
              { name: 'Timeout Member (60s)', value: 'timeout' }
            )
        )
    ),

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be executed inside a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.ManageGuild)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Server** permission to manage native AutoMod rules.');
    }

    if (!message.guild.autoModerationRules) {
      return message.reply('<a:tungsten_close:1567234632905138206> Discord native AutoMod rules are not available or bot lacks Manage Server permissions.');
    }

    const sub = (args[0] || '').toLowerCase();

    // 1. LIST
    if (sub === 'list') {
      try {
        const rules = await message.guild.autoModerationRules.fetch();
        if (!rules || rules.size === 0) {
          const embed = createEmbed({
            color: 0x5865F2,
            title: '<a:tungsten_nativeautomod:1569329462921920542> Discord Native AutoMod Rules',
            description: `No native AutoMod rules found in this server.\n\nCreate one with:\n• \`${prefix}nativeautomod add keyword <word1,word2,...>\`\n• \`${prefix}nativeautomod add spam\`\n• \`${prefix}nativeautomod add mentions <limit>\``
          });
          return message.reply({ embeds: [embed] });
        }

        const fields = [];
        for (const [, rule] of rules) {
          const trigger = TRIGGER_TYPE_NAMES[rule.triggerType] || `Type ${rule.triggerType}`;
          const actionsStr = formatActions(rule.actions);
          const status = rule.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled';
          fields.push({
            name: `${rule.name} (\`${rule.id}\`)`,
            value: `• **Status:** ${status}\n• **Trigger:** \`${trigger}\`\n• **Actions:** ${actionsStr}`,
            inline: false
          });
        }

        const embed = createEmbed({
          color: 0x5865F2,
          title: `<a:tungsten_nativeautomod:1569329462921920542> Discord Native AutoMod Rules (${rules.size})`,
          description: 'Platform-native rules enforced directly by Discord gateway infrastructure.',
          fields: fields.slice(0, 25),
          footerText: `Use ${prefix}nativeautomod delete <id> to remove a rule`
        });

        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to fetch AutoMod rules: ${err.message}`);
      }
    }

    // 2. DELETE
    if (sub === 'delete' || sub === 'remove' || sub === 'del') {
      const ruleId = args[1];
      if (!ruleId) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please provide the Rule ID to delete.\nUsage: \`${prefix}nativeautomod delete <rule_id>\``);
      }

      try {
        const rule = await message.guild.autoModerationRules.fetch(ruleId).catch(() => null);
        if (!rule) {
          return message.reply(`<a:tungsten_close:1567234632905138206> AutoMod rule with ID \`${ruleId}\` was not found.`);
        }

        const ruleName = rule.name;
        await rule.delete('Deleted by Tungsten Native AutoMod');

        if (message.guild?.id) {
          try {
            setAutomodRule(message.guild.id, {
              rule_id: ruleId,
              filter_type: 'native_' + ruleId,
              enabled: false
            });
          } catch (_) {}
        }

        const embed = createEmbed({
          color: 0xED4245,
          title: '<a:tungsten_trash:1567242891276062872> AutoMod Rule Deleted',
          description: `Successfully deleted native rule **${ruleName}** (\`${ruleId}\`).`
        });
        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to delete rule: ${err.message}`);
      }
    }

    // 3. ENABLE
    if (sub === 'enable') {
      const ruleId = args[1];
      if (!ruleId) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please provide the Rule ID to enable.\nUsage: \`${prefix}nativeautomod enable <rule_id>\``);
      }

      try {
        const rule = await message.guild.autoModerationRules.fetch(ruleId).catch(() => null);
        if (!rule) {
          return message.reply(`<a:tungsten_close:1567234632905138206> AutoMod rule with ID \`${ruleId}\` was not found.`);
        }

        await rule.edit({ enabled: true });

        if (message.guild?.id) {
          try {
            setAutomodRule(message.guild.id, {
              rule_id: rule.id,
              filter_type: 'native_' + rule.id,
              enabled: true
            });
          } catch (_) {}
        }

        const embed = createEmbed({
          color: 0x57F287,
          title: '<a:tungsten_nativeautomod:1569329462921920542> AutoMod Rule Enabled',
          description: `Rule **${rule.name}** (\`${rule.id}\`) is now enabled.`
        });
        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to enable rule: ${err.message}`);
      }
    }

    // 4. DISABLE
    if (sub === 'disable') {
      const ruleId = args[1];
      if (!ruleId) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please provide the Rule ID to disable.\nUsage: \`${prefix}nativeautomod disable <rule_id>\``);
      }

      try {
        const rule = await message.guild.autoModerationRules.fetch(ruleId).catch(() => null);
        if (!rule) {
          return message.reply(`<a:tungsten_close:1567234632905138206> AutoMod rule with ID \`${ruleId}\` was not found.`);
        }

        await rule.edit({ enabled: false });

        if (message.guild?.id) {
          try {
            setAutomodRule(message.guild.id, {
              rule_id: rule.id,
              filter_type: 'native_' + rule.id,
              enabled: false
            });
          } catch (_) {}
        }

        const embed = createEmbed({
          color: 0xED4245,
          title: '<a:tungsten_nativeautomod:1569329462921920542> AutoMod Rule Disabled',
          description: `Rule **${rule.name}** (\`${rule.id}\`) is now disabled.`
        });
        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to disable rule: ${err.message}`);
      }
    }

    // 5. ADD / CREATE
    if (sub === 'add' || sub === 'create') {
      const targetType = (args[1] || '').toLowerCase();
      const remaining = args.slice(2);

      // Determine action (block / alert / timeout)
      let actionType = 'block';
      let timeoutSecs = 60;

      const lastArg = remaining[remaining.length - 1]?.toLowerCase();
      const secondLastArg = remaining[remaining.length - 2]?.toLowerCase();

      if (!isNaN(parseInt(lastArg, 10)) && secondLastArg === 'timeout') {
        actionType = 'timeout';
        timeoutSecs = Math.min(2419200, Math.max(10, parseInt(lastArg, 10)));
        remaining.splice(remaining.length - 2, 2);
      } else if (lastArg === 'timeout') {
        actionType = 'timeout';
        timeoutSecs = 60;
        remaining.pop();
      } else if (lastArg === 'alert') {
        actionType = 'alert';
        remaining.pop();
      } else if (lastArg === 'block') {
        actionType = 'block';
        remaining.pop();
      }

      const actions = [];
      if (actionType === 'block') {
        actions.push({ type: AutoModerationActionType.BlockMessage });
      } else if (actionType === 'alert') {
        actions.push({
          type: AutoModerationActionType.SendAlertMessage,
          metadata: { channel: message.channel.id }
        });
      } else if (actionType === 'timeout') {
        actions.push({
          type: AutoModerationActionType.Timeout,
          metadata: { durationSeconds: timeoutSecs }
        });
      }

      // 5A: Keyword Rule
      if (targetType === 'keyword' || targetType === 'keywords') {
        const wordsString = remaining.join(' ');
        const rawWords = wordsString.includes(',')
          ? wordsString.split(',').map(w => w.trim()).filter(Boolean)
          : wordsString.split(/\s+/).map(w => w.trim()).filter(Boolean);

        if (rawWords.length === 0) {
          return message.reply(
            `<a:tungsten_close:1567234632905138206> Please provide at least one keyword.\n` +
            `Usage: \`${prefix}nativeautomod add keyword <word1,word2,...> [block|alert|timeout]\``
          );
        }

        const keywords = rawWords.slice(0, 50).map(w => w.slice(0, 60));
        const ruleName = `Tungsten Keyword (${keywords.slice(0, 2).join(', ')})`.slice(0, 100);

        try {
          const rule = await message.guild.autoModerationRules.create({
            name: ruleName,
            eventType: AutoModerationRuleEventType.MessageSend,
            triggerType: AutoModerationRuleTriggerType.Keyword,
            triggerMetadata: { keywordFilter: keywords },
            actions,
            enabled: true
          });

          if (message.guild?.id) {
            try {
              setAutomodRule(message.guild.id, {
                rule_id: rule.id,
                filter_type: 'native_keyword',
                enabled: true,
                action: actionType
              });
              getServerDb(message.guild.id).prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_native_routing', '1')").run();
            } catch (_) {}
          }

          const embed = createEmbed({
            color: 0x57F287,
            title: '<a:tungsten_nativeautomod:1569329462921920542> Native Keyword Rule Created',
            description:
              `Successfully created Discord native keyword filter.\n\n` +
              `• **Name:** ${rule.name}\n` +
              `• **Rule ID:** \`${rule.id}\`\n` +
              `• **Keywords:** \`${keywords.slice(0, 10).join(', ')}${keywords.length > 10 ? '...' : ''}\` (${keywords.length} total)\n` +
              `• **Action:** \`${actionType.toUpperCase()}\`${actionType === 'timeout' ? ` (${timeoutSecs}s)` : ''}`
          });
          return message.reply({ embeds: [embed] });
        } catch (err) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create Keyword rule: ${err.message}`);
        }
      }

      // 5B: Spam Filter Rule
      if (targetType === 'spam') {
        const ruleName = 'Tungsten Native Spam Filter';

        try {
          const rule = await message.guild.autoModerationRules.create({
            name: ruleName,
            eventType: AutoModerationRuleEventType.MessageSend,
            triggerType: AutoModerationRuleTriggerType.Spam,
            actions,
            enabled: true
          });

          if (message.guild?.id) {
            try {
              setAutomodRule(message.guild.id, {
                rule_id: rule.id,
                filter_type: 'native_spam',
                enabled: true,
                action: actionType
              });
              getServerDb(message.guild.id).prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_native_routing', '1')").run();
            } catch (_) {}
          }

          const embed = createEmbed({
            color: 0x57F287,
            title: '<a:tungsten_nativeautomod:1569329462921920542> Native Spam Filter Created',
            description:
              `Successfully created Discord native Spam Filter rule.\n\n` +
              `• **Name:** ${rule.name}\n` +
              `• **Rule ID:** \`${rule.id}\`\n` +
              `• **Trigger:** Suspected Spam detection by Discord ML\n` +
              `• **Action:** \`${actionType.toUpperCase()}\``
          });
          return message.reply({ embeds: [embed] });
        } catch (err) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create Spam rule: ${err.message}`);
        }
      }

      // 5C: Mentions Spam Rule
      if (targetType === 'mentions' || targetType === 'mention' || targetType === 'mentionspam') {
        let limit = 5;
        const candidateLimit = parseInt(remaining[0], 10);
        if (!isNaN(candidateLimit) && candidateLimit >= 1 && candidateLimit <= 50) {
          limit = candidateLimit;
        }

        const ruleName = `Tungsten Mention Limit (${limit})`;

        try {
          const rule = await message.guild.autoModerationRules.create({
            name: ruleName,
            eventType: AutoModerationRuleEventType.MessageSend,
            triggerType: AutoModerationRuleTriggerType.MentionSpam,
            triggerMetadata: { mentionTotalLimit: limit },
            actions,
            enabled: true
          });

          if (message.guild?.id) {
            try {
              setAutomodRule(message.guild.id, {
                rule_id: rule.id,
                filter_type: 'native_mention',
                enabled: true,
                limit_count: limit,
                action: actionType
              });
              getServerDb(message.guild.id).prepare("INSERT OR REPLACE INTO server_settings (key, value) VALUES ('automod_native_routing', '1')").run();
            } catch (_) {}
          }

          const embed = createEmbed({
            color: 0x57F287,
            title: '<a:tungsten_nativeautomod:1569329462921920542> Native Mention Spam Rule Created',
            description:
              `Successfully created Discord native Mention Spam rule.\n\n` +
              `• **Name:** ${rule.name}\n` +
              `• **Rule ID:** \`${rule.id}\`\n` +
              `• **Mention Limit:** \`${limit}\` mentions per message\n` +
              `• **Action:** \`${actionType.toUpperCase()}\``
          });
          return message.reply({ embeds: [embed] });
        } catch (err) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create Mention Spam rule: ${err.message}`);
        }
      }

      return message.reply(
        `<a:tungsten_close:1567234632905138206> Invalid rule type \`${targetType}\`.\n` +
        `Available types: \`keyword\`, \`spam\`, \`mentions\`\n\n` +
        `Examples:\n` +
        `• \`${prefix}nativeautomod add keyword discord.gg,free nitro block\`\n` +
        `• \`${prefix}nativeautomod add spam block\`\n` +
        `• \`${prefix}nativeautomod add mentions 5 timeout 60\``
      );
    }

    // Default: Help Menu
    const helpEmbed = createEmbed({
      color: 0x5865F2,
      title: '<a:tungsten_nativeautomod:1569329462921920542> Discord Platform-Native AutoMod',
      description:
        `Manage Discord-native AutoMod rules executed directly at Discord's gateway layer.\n\n` +
        `• **\`${prefix}nativeautomod list\`** — List all native AutoMod rules\n` +
        `• **\`${prefix}nativeautomod add keyword <words> [action]\`** — Add keyword filter\n` +
        `• **\`${prefix}nativeautomod add spam [action]\`** — Add native spam filter\n` +
        `• **\`${prefix}nativeautomod add mentions <limit> [action]\`** — Add mention spam limit\n` +
        `• **\`${prefix}nativeautomod delete <ruleId>\`** — Delete a rule\n` +
        `• **\`${prefix}nativeautomod enable <ruleId>\`** — Enable a rule\n` +
        `• **\`${prefix}nativeautomod disable <ruleId>\`** — Disable a rule\n\n` +
        `**Actions:** \`block\` (default), \`alert\`, \`timeout [seconds]\``,
      footerText: 'Requires Manage Server permission'
    });

    return message.reply({ embeds: [helpEmbed] });
  },

  async executeSlash(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
    }

    if (!hasPerm(interaction.member, PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> You need Manage Server permission to use this command.', ephemeral: true });
    }

    if (!interaction.guild.autoModerationRules) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> AutoMod rules unavailable or missing permissions.', ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      await interaction.deferReply();
      const rules = await interaction.guild.autoModerationRules.fetch().catch(() => null);
      if (!rules || rules.size === 0) {
        return interaction.editReply({
          embeds: [
            createEmbed({
              color: 0x5865F2,
              title: '<a:tungsten_nativeautomod:1569329462921920542> Discord Native AutoMod Rules',
              description: 'No native AutoMod rules found in this server.'
            })
          ]
        });
      }

      const fields = [];
      for (const [, rule] of rules) {
        const trigger = TRIGGER_TYPE_NAMES[rule.triggerType] || `Type ${rule.triggerType}`;
        const actionsStr = formatActions(rule.actions);
        const status = rule.enabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Enabled' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled';
        fields.push({
          name: `${rule.name} (\`${rule.id}\`)`,
          value: `• **Status:** ${status}\n• **Trigger:** \`${trigger}\`\n• **Actions:** ${actionsStr}`,
          inline: false
        });
      }

      return interaction.editReply({
        embeds: [
          createEmbed({
            color: 0x5865F2,
            title: `<a:tungsten_nativeautomod:1569329462921920542> Discord Native AutoMod Rules (${rules.size})`,
            fields: fields.slice(0, 25)
          })
        ]
      });
    }

    if (sub === 'delete') {
      const id = interaction.options.getString('rule_id');
      await interaction.deferReply();
      const rule = await interaction.guild.autoModerationRules.fetch(id).catch(() => null);
      if (!rule) {
        return interaction.editReply(`<a:tungsten_close:1567234632905138206> Rule with ID \`${id}\` not found.`);
      }
      const name = rule.name;
      await rule.delete('Deleted by Tungsten Native AutoMod');
      return interaction.editReply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            title: '<a:tungsten_trash:1567242891276062872> AutoMod Rule Deleted',
            description: `Successfully deleted rule **${name}** (\`${id}\`).`
          })
        ]
      });
    }

    if (sub === 'enable') {
      const id = interaction.options.getString('rule_id');
      await interaction.deferReply();
      const rule = await interaction.guild.autoModerationRules.fetch(id).catch(() => null);
      if (!rule) {
        return interaction.editReply(`<a:tungsten_close:1567234632905138206> Rule with ID \`${id}\` not found.`);
      }
      await rule.edit({ enabled: true });
      return interaction.editReply({
        embeds: [
          createEmbed({
            color: 0x57F287,
            title: '<a:tungsten_nativeautomod:1569329462921920542> AutoMod Rule Enabled',
            description: `Rule **${rule.name}** (\`${rule.id}\`) has been enabled.`
          })
        ]
      });
    }

    if (sub === 'disable') {
      const id = interaction.options.getString('rule_id');
      await interaction.deferReply();
      const rule = await interaction.guild.autoModerationRules.fetch(id).catch(() => null);
      if (!rule) {
        return interaction.editReply(`<a:tungsten_close:1567234632905138206> Rule with ID \`${id}\` not found.`);
      }
      await rule.edit({ enabled: false });
      return interaction.editReply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            title: '<a:tungsten_nativeautomod:1569329462921920542> AutoMod Rule Disabled',
            description: `Rule **${rule.name}** (\`${rule.id}\`) has been disabled.`
          })
        ]
      });
    }

    if (sub === 'add') {
      const type = interaction.options.getString('type');
      const input = interaction.options.getString('input') || '';
      const actionType = interaction.options.getString('action') || 'block';
      await interaction.deferReply();

      const actions = [];
      if (actionType === 'block') {
        actions.push({ type: AutoModerationActionType.BlockMessage });
      } else if (actionType === 'alert') {
        actions.push({
          type: AutoModerationActionType.SendAlertMessage,
          metadata: { channel: interaction.channelId }
        });
      } else if (actionType === 'timeout') {
        actions.push({
          type: AutoModerationActionType.Timeout,
          metadata: { durationSeconds: 60 }
        });
      }

      try {
        if (type === 'keyword') {
          const keywords = input
            .split(',')
            .map(w => w.trim().slice(0, 60))
            .filter(Boolean)
            .slice(0, 50);

          if (!keywords.length) {
            return interaction.editReply('<a:tungsten_close:1567234632905138206> Please specify at least one keyword in the `input` option.');
          }

          const ruleName = `Tungsten Keyword (${keywords.slice(0, 2).join(', ')})`.slice(0, 100);
          const rule = await interaction.guild.autoModerationRules.create({
            name: ruleName,
            eventType: AutoModerationRuleEventType.MessageSend,
            triggerType: AutoModerationRuleTriggerType.Keyword,
            triggerMetadata: { keywordFilter: keywords },
            actions,
            enabled: true
          });

          return interaction.editReply({
            embeds: [
              createEmbed({
                color: 0x57F287,
                title: '<a:tungsten_nativeautomod:1569329462921920542> Native Keyword Rule Created',
                description: `Successfully created rule **${rule.name}** (\`${rule.id}\`).`
              })
            ]
          });
        }

        if (type === 'spam') {
          const rule = await interaction.guild.autoModerationRules.create({
            name: 'Tungsten Native Spam Filter',
            eventType: AutoModerationRuleEventType.MessageSend,
            triggerType: AutoModerationRuleTriggerType.Spam,
            actions,
            enabled: true
          });

          return interaction.editReply({
            embeds: [
              createEmbed({
                color: 0x57F287,
                title: '<a:tungsten_nativeautomod:1569329462921920542> Native Spam Filter Created',
                description: `Successfully created rule **${rule.name}** (\`${rule.id}\`).`
              })
            ]
          });
        }

        if (type === 'mentions') {
          const limit = Math.min(50, Math.max(1, parseInt(input, 10) || 5));
          const rule = await interaction.guild.autoModerationRules.create({
            name: `Tungsten Mention Limit (${limit})`,
            eventType: AutoModerationRuleEventType.MessageSend,
            triggerType: AutoModerationRuleTriggerType.MentionSpam,
            triggerMetadata: { mentionTotalLimit: limit },
            actions,
            enabled: true
          });

          return interaction.editReply({
            embeds: [
              createEmbed({
                color: 0x57F287,
                title: '<a:tungsten_nativeautomod:1569329462921920542> Native Mention Spam Rule Created',
                description: `Successfully created rule **${rule.name}** (\`${rule.id}\`).`
              })
            ]
          });
        }
      } catch (err) {
        return interaction.editReply(`<a:tungsten_close:1567234632905138206> Failed to create rule: ${err.message}`);
      }
    }
  }
};
