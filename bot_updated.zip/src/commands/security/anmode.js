/**
 * Antinuke Defense Mode Command & Interactive Studio (Node.js)
 * Permanently locked to Ultra Zero-Tolerance Defense Mode.
 * Standard and Strict modes have been consolidated into Ultra for 100% zero-bypass protection.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { getServerDb, syncServerDataToMaster, getGuildAccent } = require('../../utils/serverDb');
const { isOwner, hasPerm } = require('../../utils/tools');

function getAntinukeMode(guildId) {
  return 'ULTRA';
}

function setAntinukeMode(guildId, mode) {
  const gid = String(guildId);
  const target = 'ULTRA';
  try {
    const sdb = getServerDb(gid);
    sdb.prepare(`
      INSERT INTO server_settings (key, value)
      VALUES ('antinuke_mode', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(target);
    syncServerDataToMaster(gid);
  } catch (e) {}
  return target;
}

function buildAnmodePanel(guild, currentMode = 'ULTRA', prefix = '!') {
  const accent = getGuildAccent(guild.id);

  const card = createV2Card({
    color: accent,
    title: `<a:tungsten_shield:1567242104923627574> Antinuke Defense Mode • Ultra Zero-Tolerance`,
    description:
      `> Current Defense Mode: **\`ULTRA ZERO-TOLERANCE\`** <a:tungsten_shield:1567242104923627574>\n` +
      `> Protection Integrity: **\`PERMANENT & UNBREAKABLE\`** <a:tungsten_shield:1567242104923627574>\n\n` +
      `Tungsten operates exclusively on **Ultra Zero-Tolerance Mode**. Standard and Strict modes have been retired to guarantee zero-bypass enterprise server security.\n\n` +
      `### <a:tungsten_shield:1567242104923627574> Ultra Zero-Tolerance Enforcement Suite:\n` +
      `• **Zero-Tolerance (1 Action):** Instant permanent ban on the *very first* unauthorized destructive action.\n` +
      `• **Sub-50ms Traitor Strip:** Automatically strips all administrative, moderator, and dangerous permissions from malicious actors.\n` +
      `• **Instant State Auto-Rollback:** Deleted channels and roles are reconstructed immediately with identical permissions, overwrites, and hierarchy positions intact.\n` +
      `• **Owner Emergency Alert:** Direct real-time incident dispatch sent directly to the Server Owner with full forensic audit details.\n` +
      `• **Quarantine Isolation:** Threat containment locks down compromised tokens and rogue bots instantly.\n\n` +
      `-# Antinuke is permanently locked to Ultra Zero-Tolerance for all servers.`,
    footerText: `Tungsten Enterprise Defense Suite • ${guild.name}`
  });

  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('anmode:ultra')
      .setLabel('Ultra Active')
      .setEmoji('<a:tungsten_shield:1567242104923627574>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('anmode:refresh')
      .setLabel('Refresh')
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('anmode:dismiss')
      .setLabel('Dismiss')
      .setEmoji('<a:tungsten_close:1567234632905138206>')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [card], components: [buttons] };
}

module.exports = {
  name: 'anmode',
  aliases: ['antimode', 'defmode', 'securitymode', 'an_mode', 'antinukemode'],
  category: 'security',
  description: 'View the locked Ultra Zero-Tolerance Antinuke Defense Mode.',
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[status]',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const isAuthorized = hasPerm(message.member, PermissionFlagsBits.Administrator);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Administrator` permission or Server Owner status to view Antinuke Defense Mode.');
    }

    const sub = args[0]?.toLowerCase();

    if (sub === 'standard' || sub === 'strict') {
      return message.reply({
        content: '<a:tungsten_alarm:1567229471474585682> **Notice:** Standard and Strict modes have been permanently retired. Tungsten operates exclusively on **Ultra Zero-Tolerance Mode** (`ULTRA`) to eliminate threat bypasses.'
      });
    }

    if (sub === 'ultra' || sub === 'status') {
      const accent = getGuildAccent(message.guild.id);
      const confirmCard = createV2Card({
        color: accent,
        title: `<a:tungsten_success:1567242523468890274> Antinuke Defense Mode • ULTRA`,
        description:
          `> Antinuke Defense Mode is confirmed at **\`ULTRA ZERO-TOLERANCE\`** for **${message.guild.name}**.\n\n` +
          `• **Enforcement:** Zero-Tolerance (1 destructive event triggers permanent ban & auto-rollback)\n` +
          `• **Status:** Active & Impervious <a:tungsten_shield:1567242104923627574>\n` +
          `• **Configured By:** <@${message.author.id}>\n\n` +
          `-# Utmost zero-bypass security is active for all servers.`,
        footerText: 'Tungsten Enterprise Defense Suite'
      });

      return message.reply({ embeds: [confirmCard] });
    }

    // Default: Open the interactive panel
    const panel = buildAnmodePanel(message.guild, 'ULTRA', prefix);
    return message.reply(panel);
  },

  getAntinukeMode,
  setAntinukeMode,
  buildAnmodePanel
};
