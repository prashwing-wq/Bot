/**
 * Extra Owner Studio & Executive Governance Command (Node.js)
 * Manages executive co-owners with absolute antinuke immunity and emergency powers.
 * Provides a live interactive studio with Discord Components V2 and live ActionRows.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { clearImmunityCache } = require('../../utils/antinukeEngine');
const { createV2Card } = require('../../utils/componentsV2');
const { askConfirmation } = require('../../utils/confirmAction');

/**
 * Builds the interactive Extra Owner Studio payload.
 */
function buildExtraOwnerStudioPayload(guild, sdb, prefix = '!', username = '') {
  let rows = [];
  try {
    rows = sdb.prepare('SELECT owner_id, added_at, added_by FROM extraowners WHERE guild_id = ?').all(guild.id);
  } catch (e) {
    rows = sdb.prepare('SELECT owner_id, added_at FROM extraowners WHERE guild_id = ?').all(guild.id);
  }

  let listText = '';
  if (rows.length === 0) {
    listText = '*No Extra Owners currently assigned.* Click **Add Extra Owner** below.';
  } else {
    listText = rows.map((r, i) => {
      const m = guild.members?.cache?.get(r.owner_id);
      const name = m ? `**${m.displayName}**` : `User \`${r.owner_id}\``;
      const timeStr = r.added_at ? `<t:${r.added_at}:R>` : 'Active';
      const addedByStr = r.added_by && r.added_by !== 'unknown' ? `<@${r.added_by}>` : 'Server Owner';
      return `\`#${i + 1}\` <@${r.owner_id}> (${name})\n> • **Added By:** ${addedByStr} • **Timestamp:** ${timeStr}`;
    }).join('\n\n');
  }

  const card = createV2Card({
    color: 0x2b2d31,
    title: `<a:tungsten_shield:1567242104923627574> Extra Owner Studio • ${guild.name}`,
    description:
      `> Extra Owners hold elevated executive authority with complete Antinuke immunity.\n\n` +
      `**Designated Extra Owners [${rows.length}/10]:**\n` +
      listText +
      `\n\n**Executive Superpowers:**\n` +
      `• **100% Antinuke Immunity:** Exempt from bans, kicks, and rate limits\n` +
      `• **Lockdown Authority:** Authorized for \`${prefix}panic trigger\` and \`${prefix}panic unlock\`\n` +
      `• **Whitelist Governance:** Manage trusted staff & modules (\`${prefix}wl\`)\n` +
      `• **Zero Permissions Leak:** Internal trust verification\n\n` +
      `*Click the buttons below to manage Extra Owners instantly.*`,
    footerText: username ? `Requested by ${username}` : `Tungsten Executive Governance • ${guild.name}`
  });

  const row0 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('eo:add').setLabel('Add Extra Owner').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_shield:1567242104923627574>'),
    new ButtonBuilder().setCustomId('eo:manage').setLabel('Manage Extra Owner').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_gear:1567239932970406012>'),
    new ButtonBuilder().setCustomId('eo:remove').setLabel('Remove Extra Owner').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_sweep:1567242656281657414>'),
    new ButtonBuilder().setCustomId('eo:manage_wl').setLabel('Whitelist Studio').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_shield:1567242104923627574>')
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('eo:privileges').setLabel('View Privileges').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_shield:1567242104923627574>'),
    new ButtonBuilder().setCustomId('eo:refresh').setLabel('Refresh').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('eo:reset').setLabel('Reset All').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_warn:1567246685082746940>'),
    new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_error:1567238753284653106>')
  );

  return { embeds: [card], components: [row0, row1] };
}

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'extraowner',
  aliases: ['eo', 'extraowners', 'extraown', 'eopanel', 'eostudio'],
  category: 'security',
  description: 'Manage server Extra Owners with absolute antinuke immunity and executive authority.',
  usage: '[panel | add <@user> | remove <@user> | reset | list]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sdb = getServerDb(message.guild.id);
    const isServerOwner = message.author.id === message.guild.ownerId;
    const isExtraOwner = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id);

    // Only primary server owner or extra owners can access extra owner studio
    if (!isServerOwner && !isExtraOwner) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner** or **Extra Owners** can access the Extra Owner Studio.');
    }

    const sub = (args[0] || 'panel').toLowerCase();

    // 1. Add Extra Owner
    if (sub === 'add') {
      if (!isServerOwner) {
        return message.reply('<a:tungsten_close:1567234632905138206> Only the **Primary Server Owner** can add new Extra Owners.');
      }

      const target = message.mentions?.users?.first() || (args[1] ? await client.users.fetch(args[1].replace(/[<@!>]/g, '')).catch(() => null) : null);
      if (!target) return message.reply(`<a:tungsten_close:1567234632905138206> Please mention a valid user: \`${prefix}extraowner add @user\``);

      if (target.id === message.guild.ownerId) {
        return message.reply('<a:tungsten_close:1567234632905138206> The Server Owner already holds primary ownership.');
      }

      const nowSec = Math.floor(Date.now() / 1000);
      const recentRemoval = sdb.prepare(`
        SELECT timestamp FROM audit_logs
        WHERE target_id = ? AND action IN ('extraowner_remove', 'whitelist_revoke')
        ORDER BY timestamp DESC LIMIT 1
      `).get(target.id);

      if (recentRemoval && (nowSec - Number(recentRemoval.timestamp)) < 86400) {
        const unlockTime = Number(recentRemoval.timestamp) + 86400;
        return message.reply(`<a:tungsten_close:1567234632905138206> **Security Cooldown Active**: <@${target.id}> was recently removed as an Extra Owner. A **24-hour cooldown** is enforced before they can be re-added.\nTry again <t:${unlockTime}:R> (<t:${unlockTime}:F>).`);
      }

      const count = sdb.prepare('SELECT COUNT(*) as cnt FROM extraowners WHERE guild_id = ?').get(message.guild.id).cnt;
      if (count >= 10) {
        return message.reply('<a:tungsten_close:1567234632905138206> Maximum limit of 10 Extra Owners reached for this server.');
      }

      sdb.prepare(`
        INSERT OR REPLACE INTO extraowners (guild_id, owner_id, added_at, added_by)
        VALUES (?, ?, ?, ?)
      `).run(message.guild.id, target.id, nowSec, message.author.id);

      clearImmunityCache(message.guild.id);

      const { buildTargetWhitelistPayload } = require('../../utils/whitelistUi');
      const payload = buildTargetWhitelistPayload(message.guild, sdb, 'extraowner', target.id, prefix);
      return message.reply(payload);
    }

    // 1b. Manage Extra Owner
    if (sub === 'manage') {
      const target = message.mentions?.users?.first() || (args[1] ? await client.users.fetch(args[1].replace(/[<@!>]/g, '')).catch(() => null) : null);
      if (target) {
        const { buildTargetWhitelistPayload } = require('../../utils/whitelistUi');
        const payload = buildTargetWhitelistPayload(message.guild, sdb, 'extraowner', target.id, prefix);
        return message.reply(payload);
      }
      const payload = buildExtraOwnerStudioPayload(message.guild, sdb, prefix, message.author.username);
      return message.reply(payload);
    }

    // 2. Remove Extra Owner
    if (sub === 'remove' || sub === 'delete' || sub === 'del') {
      if (!isServerOwner) {
        return message.reply('<a:tungsten_close:1567234632905138206> Only the **Primary Server Owner** can remove Extra Owners.');
      }

      const target = message.mentions?.users?.first() || (args[1] ? await client.users.fetch(args[1].replace(/[<@!>]/g, '')).catch(() => null) : null);
      if (!target) return message.reply(`<a:tungsten_close:1567234632905138206> Please mention a user to remove: \`${prefix}extraowner remove @user\``);

      const res = sdb.prepare('DELETE FROM extraowners WHERE guild_id = ? AND owner_id = ?').run(message.guild.id, target.id);
      clearImmunityCache(message.guild.id);

      if (res.changes === 0) {
        return message.reply(`<a:tungsten_info:1567240890748248084> That user is not currently an Extra Owner.`);
      }

      try {
        sdb.prepare(`
          INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
          VALUES ('extraowner_remove', ?, ?, 'Removed via command', ?)
        `).run(message.author.id, target.id, Math.floor(Date.now() / 1000));
      } catch (e) {}

      return message.reply(`<a:tungsten_success:1567242523468890274> Removed <@${target.id}> from Extra Owners.`);
    }

    // 3. Reset All Extra Owners
    if (sub === 'reset') {
      if (!isServerOwner) {
        return message.reply('<a:tungsten_close:1567234632905138206> Only the **Primary Server Owner** can reset all Extra Owners.');
      }

      const { confirmed } = await askConfirmation(message, {
        title: '<a:tungsten_crown:1567238355463176334>  Confirm Reset All Extra Owners',
        description: `Are you sure you want to revoke all **Extra Owner** appointments for **${message.guild.name}**?`,
        confirmLabel: 'Yes, Reset All Extra Owners'
      });
      if (!confirmed) return;

      const eoList = sdb.prepare('SELECT owner_id FROM extraowners WHERE guild_id = ?').all(message.guild.id);
      const nowSec = Math.floor(Date.now() / 1000);
      for (const eo of eoList) {
        try {
          sdb.prepare(`
            INSERT INTO audit_logs (action, actor_id, target_id, details, timestamp)
            VALUES ('extraowner_remove', ?, ?, 'Reset all extra owners via command', ?)
          `).run(message.author.id, eo.owner_id, nowSec);
        } catch (e) {}
      }

      sdb.prepare('DELETE FROM extraowners WHERE guild_id = ?').run(message.guild.id);
      clearImmunityCache(message.guild.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Successfully reset all Extra Owners for **${message.guild.name}**.`);
    }

    // 4. Default: Live Studio Panel
    const payload = buildExtraOwnerStudioPayload(message.guild, sdb, prefix, message.author.username);
    return message.reply(payload);
  },

  buildExtraOwnerStudioPayload
};
