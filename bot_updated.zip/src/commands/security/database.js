/**
 * Owner Database Explorer & Management Command (Node.js)
 * Comprehensive read-only MongoDB Atlas Cloud Database Inspector and in-memory SQLite Explorer.
 * Zero local disk SQLite files, 100% cloud-backed and memory-safe.
 * Strictly restricted to Bot Owners.
 */
const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  AttachmentBuilder
} = require('discord.js');
const path = require('node:path');
const fs = require('node:fs');
const { isOwner, createEmbed } = require('../../utils/tools');
const { getMasterDb, getServerDb } = require('../../utils/serverDb');
const { isMongoConnected, pingMongo, getMongoDb, initMongo } = require('../../utils/mongoClient');
const { pushAllDatabasesToMongo } = require('../../utils/mongoSync');

/**
 * Redacts sensitive tokens, passwords, and secrets from documents
 */
function redactSensitive(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(redactSensitive);
  const clean = {};
  for (const [k, v] of Object.entries(obj)) {
    const lowerKey = k.toLowerCase();
    if (
      lowerKey.includes('token') ||
      lowerKey.includes('secret') ||
      lowerKey.includes('password') ||
      lowerKey.includes('auth') ||
      lowerKey.includes('webhook_url')
    ) {
      clean[k] = '[REDACTED]';
    } else if (typeof v === 'string') {
      clean[k] = v.replace(/[\w-]{24,26}\.[\w-]{6}\.[\w-]{27,38}/g, '[REDACTED_TOKEN]');
    } else if (typeof v === 'object' && v !== null) {
      clean[k] = redactSensitive(v);
    } else {
      clean[k] = v;
    }
  }
  return clean;
}

/**
 * Formats tabular data as an ASCII table for SQL query outputs
 */
function formatAsciiTable(rows, maxCols = 5) {
  if (!rows || rows.length === 0) return 'Empty result set (0 rows).';

  const allKeys = Object.keys(rows[0]).slice(0, maxCols);
  const colWidths = {};

  allKeys.forEach(k => {
    colWidths[k] = Math.min(25, Math.max(k.length, ...rows.map(r => String(r[k] ?? 'NULL').length)));
  });

  const header = allKeys.map(k => k.padEnd(colWidths[k])).join(' | ');
  const divider = allKeys.map(k => '-'.repeat(colWidths[k])).join('-+-');
  const dataLines = rows.slice(0, 15).map(r => {
    return allKeys.map(k => {
      const val = String(r[k] ?? 'NULL');
      return (val.length > 25 ? val.slice(0, 22) + '...' : val).padEnd(colWidths[k]);
    }).join(' | ');
  });

  return `${header}\n${divider}\n${dataLines.join('\n')}`;
}

/**
 * Ensures MongoDB connection is established and returns the db instance
 */
async function ensureMongoDb() {
  if (!isMongoConnected()) {
    try {
      await initMongo();
    } catch (_) {}
  }
  return getMongoDb();
}

/**
 * Canonical Schema Definitions for Master Tables (26 Total)
 */
const MASTER_TABLE_SCHEMAS = {
  automod: ['guild_id', 'enabled'],
  automod_punishments: ['guild_id', 'event', 'punishment'],
  automod_settings: ['guild_id', 'timeout_duration', 'delete_message', 'warn_alert', 'caps_threshold', 'mention_threshold', 'spam_threshold', 'emoji_threshold'],
  automod_subfilters: ['guild_id', 'filter_name', 'enabled', 'punishment'],
  autorole: ['guild_id', 'bots', 'humans'],
  bot_owners: ['user_id', 'added_at', 'added_by'],
  components_v2_settings: ['guild_id', 'enabled'],
  extraowners: ['guild_id', 'owner_id'],
  global_settings: ['key', 'value', 'updated_at'],
  guild_punishment_settings: ['guild_id', 'profile_name', 'punishment_type'],
  j2c_hubs: ['guild_id', 'channel_id', 'category_id'],
  j2c_panel_channels: ['guild_id', 'channel_id'],
  j2c_temp_channels: ['channel_id', 'guild_id', 'owner_id', 'panel_message_id', 'panel_channel_id', 'created_at'],
  market_prices: ['asset_type', 'symbol', 'name', 'current_price', 'min_price', 'max_price', 'change_percent'],
  mod_cases: ['case_id', 'guild_id', 'user_id', 'mod_id', 'action', 'reason', 'created_at'],
  noprefix_users: ['user_id', 'added_at', 'added_by', 'expires_at'],
  np_managers: ['user_id', 'added_at', 'added_by'],
  panic_lockdown_roles: ['guild_id', 'role_id', 'original_permissions'],
  prefix: ['guild_id', 'prefix'],
  premium_audit_logs: ['id', 'guild_id', 'event_type', 'actor_id', 'target_id', 'details', 'timestamp'],
  scheduled_tasks: ['id', 'guild_id', 'kind', 'run_at', 'payload', 'done', 'retries'],
  security_snapshots: ['snapshot_id', 'guild_id', 'created_at', 'created_at_iso', 'trigger_type', 'guild_name', 'data'],
  user_settings: ['user_id', 'enabled'],
  welcome_panel: ['guild_id', 'status', 'channel_id', 'format', 'dm_enabled', 'dm_message', 'ping_mode', 'auto_delete', 'action_buttons', 'cv2_title', 'cv2_description', 'cv2_thumbnail', 'cv2_banner'],
  whitelisted_roles: ['guild_id', 'role_id', 'added_by', 'added_at', 'ban', 'kick', 'prune', 'botadd', 'serverup', 'memup', 'chcr', 'chdl', 'chup', 'rlcr', 'rlup', 'rldl', 'meneve', 'mngweb', 'mngstemo', 'is_extraowner_wl'],
  whitelisted_users: ['guild_id', 'user_id', 'ban', 'kick', 'prune', 'botadd', 'serverup', 'memup', 'chcr', 'chdl', 'chup', 'rlcr', 'rlup', 'rldl', 'meneve', 'mngweb', 'mngstemo', 'expires_at', 'is_extraowner_wl', 'added_by']
};

/**
 * Canonical Schema Definitions for Guild Tables (35 Total)
 */
const GUILD_TABLE_SCHEMAS = {
  antinuke_rules: ['vector', 'enabled', 'action', 'limit_count', 'time_window', 'auto_heal'],
  audit_logs: ['log_id', 'user_id', 'action', 'actor_id', 'target_id', 'reason', 'details', 'created_at', 'timestamp'],
  automod_logs: ['id', 'user_id', 'channel_id', 'violation', 'action_taken', 'content_snippet', 'timestamp'],
  automod_rules: ['rule_id', 'filter_type', 'enabled', 'limit_count', 'time_window', 'action', 'strike_weight', 'exemptions', 'log_channel', 'rule_name', 'threshold_val', 'extra_config'],
  automod_strikes: ['user_id', 'strikes', 'last_strike_at'],
  autoreactions: ['trigger_word', 'emoji'],
  autoresponders: ['trigger_word', 'response_text', 'creator_id'],
  autorole: ['bots', 'humans'],
  channel_snapshots: ['channel_id', 'data', 'updated_at'],
  economy_shop_items: ['item_id', 'name', 'description', 'price', 'type', 'role_id', 'max_per_user'],
  economy_users: ['user_id', 'wallet', 'bank', 'last_daily', 'last_rob', 'last_beg', 'last_monthly'],
  home_voice_channels: ['channel_id', 'status_text', 'enabled', 'reconnect_count', 'updated_at'],
  join_raid_log: ['id', 'user_id', 'joined_at', 'left_at', 'flagged'],
  leveling_roles: ['level', 'role_id'],
  leveling_users: ['user_id', 'xp', 'level', 'last_xp_time'],
  member_warnings: ['id', 'user_id', 'moderator_id', 'reason', 'timestamp'],
  mod_cases: ['id', 'case_num', 'action', 'user_id', 'moderator_id', 'reason', 'timestamp'],
  nightmode: ['enabled', 'start_time', 'end_time'],
  reaction_roles: ['id', 'message_id', 'channel_id', 'emoji', 'role_id'],
  role_snapshots: ['role_id', 'data', 'updated_at'],
  server_baseline_identity: ['name', 'icon_url', 'icon_base64', 'banner_url', 'banner_base64', 'verification_level', 'updated_at'],
  server_info: ['name', 'owner_id', 'created_at', 'updated_at'],
  server_settings: ['key', 'value', 'updated_at'],
  server_snapshots: ['id', 'name', 'created_by', 'created_at', 'channels_data', 'roles_data', 'server_data'],
  server_ticket_categories: ['category_id', 'name', 'staff_role_id', 'questions'],
  server_tickets: ['channel_id', 'user_id', 'created_at', 'status', 'category', 'claimed_by', 'last_activity', 'closed_at'],
  sniped_messages: ['channel_id', 'content', 'author_id', 'author_tag', 'timestamp', 'attachments'],
  suggestion_votes: ['suggestion_id', 'user_id', 'vote_type', 'timestamp'],
  suggestions: ['id', 'channel_id', 'message_id', 'author_id', 'author_tag', 'content', 'status', 'upvotes', 'downvotes', 'reason', 'reviewed_by', 'created_at', 'updated_at'],
  user_quests: ['user_id', 'date', 'quests_json'],
  verification_settings: ['enabled', 'role_id', 'channel_id', 'mode', 'code'],
  voice_activity: ['user_id', 'total_seconds', 'daily_seconds', 'weekly_seconds', 'monthly_seconds', 'last_joined', 'updated_at'],
  welcome_panel: ['status', 'channel_id', 'format', 'dm_enabled', 'dm_message', 'ping_mode', 'auto_delete', 'action_buttons', 'cv2_title', 'cv2_description', 'cv2_thumbnail', 'cv2_banner'],
  whitelist_audit_log: ['id', 'target_type', 'target_id', 'action_scope', 'operator_id', 'operation', 'timestamp'],
  whitelisted_users: ['user_id', 'action', 'expires_at', 'added_by']
};

/**
 * Computes exact MongoDB Atlas storage consumption out of the 512.00 MB free tier quota
 */
async function getStorageStats(db) {
  let stats = null;
  if (db && typeof db.command === 'function') {
    try {
      stats = await db.command({ dbStats: 1 });
    } catch (_) {}
  }

  const totalQuota = 512.0;
  if (!stats) {
    return {
      totalQuota,
      dataSizeMb: '0.00',
      storageSizeMb: '0.00',
      indexSizeMb: '0.00',
      totalConsumedMb: '0.00',
      freeMb: '512.00',
      consumedPercent: '0.00',
      progressBar: '[░░░░░░░░░░░░░░░░░░░░] 0.00%',
      collections: 0,
      objects: 0,
      indexes: 0,
      avgObjSize: '0 B',
      ok: false
    };
  }

  const dataSize = stats.dataSize || 0;
  const storageSize = stats.storageSize || 0;
  const indexSize = stats.indexSize || 0;

  const dataSizeMb = (dataSize / 1048576).toFixed(2);
  const storageSizeMb = (storageSize / 1048576).toFixed(2);
  const indexSizeMb = (indexSize / 1048576).toFixed(2);
  const totalConsumedMb = ((storageSize + indexSize) / 1048576).toFixed(2);
  const freeMb = (512.0 - parseFloat(totalConsumedMb)).toFixed(2);
  const consumedPercent = (((storageSize + indexSize) / (512 * 1048576)) * 100).toFixed(2);

  const totalBlocks = 20;
  let filledBlocks = Math.round((parseFloat(consumedPercent) / 100) * totalBlocks);
  if (filledBlocks === 0 && parseFloat(consumedPercent) > 0) filledBlocks = 1;
  filledBlocks = Math.min(totalBlocks, Math.max(0, filledBlocks));
  const emptyBlocks = totalBlocks - filledBlocks;
  const progressBar = `[${'█'.repeat(filledBlocks)}${'░'.repeat(emptyBlocks)}] ${consumedPercent}%`;

  let avgObjSize = '0 B';
  if (stats.avgObjSize) {
    avgObjSize = stats.avgObjSize > 1024
      ? `${(stats.avgObjSize / 1024).toFixed(2)} KB`
      : `${Math.round(stats.avgObjSize)} B`;
  }

  return {
    totalQuota,
    dataSizeMb,
    storageSizeMb,
    indexSizeMb,
    totalConsumedMb,
    freeMb,
    consumedPercent,
    progressBar,
    collections: stats.collections || 0,
    objects: stats.objects || 0,
    indexes: stats.indexes || 0,
    avgObjSize,
    ok: true,
    raw: stats
  };
}

/**
 * Formats prominent storage quota consumption meter block
 */
function formatStorageQuotaBlock(storageStats) {
  return (
    `**MongoDB Atlas Storage Quota (${storageStats.totalQuota.toFixed(2)} MB Free Tier):**\n` +
    `\`${storageStats.progressBar}\`\n` +
    `• **Consumed Storage:** \`${storageStats.totalConsumedMb} MB\` / \`${storageStats.totalQuota.toFixed(2)} MB\` (\`${storageStats.consumedPercent}%\`)\n` +
    `• **Free Quota Remaining:** \`${storageStats.freeMb} MB\`\n` +
    `• **WiredTiger Breakdown:** Disk: \`${storageStats.storageSizeMb} MB\` • Indexes: \`${storageStats.indexSizeMb} MB\` • Uncompressed: \`${storageStats.dataSizeMb} MB\``
  );
}

/**
 * Universal contents & storage payload builder reused across prefix and slash commands
 */
async function buildContentsPayload({ category = 'all', page = 1, db = null, client = null, guildId = null }) {
  if (!db) {
    db = await ensureMongoDb();
  }

  const storageStats = await getStorageStats(db);
  const quotaHeader = formatStorageQuotaBlock(storageStats);

  // Retrieve document counts from MongoDB Atlas
  const masterDocCounts = new Map();
  const guildDocCounts = new Map();

  if (db) {
    try {
      const mAgg = await db.collection('master_records').aggregate([
        { $group: { _id: '$table', count: { $sum: 1 } } }
      ]).toArray();
      mAgg.forEach(r => { if (r._id) masterDocCounts.set(r._id, r.count); });
    } catch (_) {}

    try {
      const gAgg = await db.collection('guild_records').aggregate([
        { $group: { _id: '$table', count: { $sum: 1 } } }
      ]).toArray();
      gAgg.forEach(r => { if (r._id) guildDocCounts.set(r._id, r.count); });
    } catch (_) {}
  }

  // Sorted list of all 26 master tables + any additional cloud tables
  const masterSet = new Set(Object.keys(MASTER_TABLE_SCHEMAS));
  for (const t of masterDocCounts.keys()) masterSet.add(t);
  const masterTables = Array.from(masterSet).sort();

  // Sorted list of all 35 guild tables + any additional cloud tables
  const guildSet = new Set(Object.keys(GUILD_TABLE_SCHEMAS));
  for (const t of guildDocCounts.keys()) guildSet.add(t);
  const guildTables = Array.from(guildSet).sort();

  const cat = String(category).toLowerCase();

  // ─────────────────────────────────────────────
  // A. MASTER TABLES VIEW (26 tables with fields)
  // ─────────────────────────────────────────────
  if (cat === 'master') {
    const pageSize = 13;
    const totalPages = Math.ceil(masterTables.length / pageSize) || 1;
    const currentPage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
    const startIdx = (currentPage - 1) * pageSize;
    const pageTables = masterTables.slice(startIdx, startIdx + pageSize);

    const lines = pageTables.map(t => {
      const count = masterDocCounts.get(t) || 0;
      const fields = MASTER_TABLE_SCHEMAS[t] || ['id'];
      return `• \`${t}\` — **${count}** doc${count === 1 ? '' : 's'}\n  ↳ fields: \`[${fields.join(', ')}]\``;
    });

    const desc =
      `${quotaHeader}\n\n` +
      `**Master Tables (${masterTables.length} Total — Page ${currentPage}/${totalPages}):**\n\n` +
      lines.join('\n\n');

    const embed = createEmbed()
      .setTitle(`MongoDB Atlas — Master Tables (${masterTables.length} Total)`)
      .setDescription(desc)
      .setFooter({ text: `Page ${currentPage}/${totalPages} • ${masterTables.length} Master Tables • Read-Only Schema` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:master:${Math.max(1, currentPage - 1)}`)
        .setLabel('◀ Prev')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage <= 1),
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:master:${currentPage + 1}`)
        .setLabel('Next ▶')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage >= totalPages),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:guild:1')
        .setLabel(`Guild Tables (${guildTables.length})`)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:quota:1')
        .setLabel('Storage Quota')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:all:1')
        .setLabel('Overview')
        .setStyle(ButtonStyle.Secondary)
    );

    return { embeds: [embed], components: [row] };
  }

  // ─────────────────────────────────────────────
  // B. GUILD TABLES VIEW (35 tables with fields)
  // ─────────────────────────────────────────────
  if (cat === 'guild' || cat === 'guilds') {
    const pageSize = 18;
    const totalPages = Math.ceil(guildTables.length / pageSize) || 1;
    const currentPage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
    const startIdx = (currentPage - 1) * pageSize;
    const pageTables = guildTables.slice(startIdx, startIdx + pageSize);

    const lines = pageTables.map(t => {
      const count = guildDocCounts.get(t) || 0;
      const fields = GUILD_TABLE_SCHEMAS[t] || ['id'];
      return `• \`${t}\` — **${count}** doc${count === 1 ? '' : 's'} across servers\n  ↳ fields: \`[${fields.join(', ')}]\``;
    });

    const desc =
      `${quotaHeader}\n\n` +
      `**Guild Tables (${guildTables.length} Total — Page ${currentPage}/${totalPages}):**\n\n` +
      lines.join('\n\n');

    const embed = createEmbed()
      .setTitle(`MongoDB Atlas — Guild Tables (${guildTables.length} Total)`)
      .setDescription(desc)
      .setFooter({ text: `Page ${currentPage}/${totalPages} • ${guildTables.length} Guild Tables across servers • Read-Only Schema` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:guild:${Math.max(1, currentPage - 1)}`)
        .setLabel('◀ Prev')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage <= 1),
      new ButtonBuilder()
        .setCustomId(`dbnav:contents:guild:${currentPage + 1}`)
        .setLabel('Next ▶')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(currentPage >= totalPages),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:master:1')
        .setLabel(`Master Tables (${masterTables.length})`)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:quota:1')
        .setLabel('Storage Quota')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:all:1')
        .setLabel('Overview')
        .setStyle(ButtonStyle.Secondary)
    );

    return { embeds: [embed], components: [row] };
  }

  // ─────────────────────────────────────────────
  // C. STORAGE / QUOTA DEEP-DIVE
  // ─────────────────────────────────────────────
  if (cat === 'storage' || cat === 'quota' || cat === 'meter') {
    const desc =
      `**MongoDB Atlas Free Tier Quota (M0 Cluster — 512.00 MB)**\n` +
      `\`${storageStats.progressBar}\`\n\n` +
      `**Storage Allocation Metrics:**\n` +
      `• **Total Consumed:** \`${storageStats.totalConsumedMb} MB\` / \`${storageStats.totalQuota.toFixed(2)} MB\` (\`${storageStats.consumedPercent}%\`)\n` +
      `• **Free Quota Remaining:** \`${storageStats.freeMb} MB\` (\`${(512.0 - parseFloat(storageStats.totalConsumedMb)).toFixed(2)} MB\` available)\n` +
      `• **WiredTiger Disk Storage:** \`${storageStats.storageSizeMb} MB\` (allocated storage on disk)\n` +
      `• **BSON Index Storage:** \`${storageStats.indexSizeMb} MB\` (indexes across all collections)\n` +
      `• **Uncompressed Data Size:** \`${storageStats.dataSizeMb} MB\` (raw logical data footprint)\n` +
      `• **Collections Created:** \`${storageStats.collections}\` (\`master_records\`, \`guild_records\`)\n` +
      `• **Total Objects / Documents:** \`${storageStats.objects.toLocaleString()}\` documents\n` +
      `• **Average Object Size:** \`${storageStats.avgObjSize}\`\n` +
      `• **Compression Engine:** WiredTiger Block Compression (Snappy / Zlib Active)\n\n` +
      `**In-Memory SQLite Cache Engine:**\n` +
      `• **Local Disk Files:** \`0\` (Zero disk files, pure in-memory SQLite RAM cache)\n` +
      `• **Engine Mode:** In-Memory SQLite RAM Engine (No local file I/O)\n` +
      `• **Cloud Persistence:** Continuous replication and on-boot hydration active`;

    const embed = createEmbed()
      .setTitle('MongoDB Atlas — Storage Quota & WiredTiger Telemetry')
      .setDescription(desc)
      .setFooter({ text: 'Atlas M0 Free Tier Quota: 512.00 MB • Read-Only Telemetry' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('dbnav:contents:master:1')
        .setLabel(`Master Tables (${masterTables.length})`)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:guild:1')
        .setLabel(`Guild Tables (${guildTables.length})`)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:quota:1')
        .setLabel('Refresh')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('dbnav:contents:all:1')
        .setLabel('Overview')
        .setStyle(ButtonStyle.Secondary)
    );

    return { embeds: [embed], components: [row] };
  }

  // ─────────────────────────────────────────────
  // D. DEFAULT: ALL / OVERVIEW
  // ─────────────────────────────────────────────
  const masterLines = masterTables.map(t => {
    const count = masterDocCounts.get(t) || 0;
    return `• \`${t}\` — **${count}** doc${count === 1 ? '' : 's'}`;
  });

  const guildLines = guildTables.map(t => {
    const count = guildDocCounts.get(t) || 0;
    return `• \`${t}\` — **${count}** doc${count === 1 ? '' : 's'}`;
  });

  const canonicalMasterCount = Object.keys(MASTER_TABLE_SCHEMAS).length;
  const canonicalGuildCount = Object.keys(GUILD_TABLE_SCHEMAS).length;

  const desc =
    `${quotaHeader}\n\n` +
    `**Master Tables (${canonicalMasterCount} Total):**\n` +
    masterLines.join('\n') +
    `\n\n**Guild Tables (${canonicalGuildCount} Total across all servers):**\n` +
    guildLines.join('\n');

  const embed = createEmbed()
    .setTitle('MongoDB Atlas Cloud Tables & Storage Quota')
    .setDescription(desc)
    .setFooter({ text: `All ${masterTables.length} Master & ${guildTables.length} Guild Tables • Click buttons below for field definitions & quota breakdown` });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dbnav:contents:master:1')
      .setLabel(`Master Tables (${masterTables.length})`)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('dbnav:contents:guild:1')
      .setLabel(`Guild Tables (${guildTables.length})`)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('dbnav:contents:quota:1')
      .setLabel('Storage Quota')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dbnav:contents:refresh:1')
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

/**
 * Helper to build the embed alone for interactions or modules
 */
async function buildContentsEmbed(category = 'all', page = 1, db = null, client = null, guildId = null) {
  const payload = await buildContentsPayload({ category, page, db, client, guildId });
  return payload.embeds[0];
}

/**
 * Builds paginated document inspection payload with interactive Components V2 buttons
 */
async function buildInspectPayload({ scope = null, table = null, page = 1, pageSize = 5, db = null, client = null, guildId = null }) {
  if (!db) {
    db = await ensureMongoDb();
  }

  const targetTable = (table || '').trim();
  if (!targetTable) {
    const embed = createEmbed()
      .setTitle('Document Inspector — Missing Table')
      .setDescription('Please specify a table name to inspect. Example: `bot_owners` or `antinuke_rules`.')
      .setFooter({ text: 'MongoDB Atlas & In-Memory Sentinel' });
    return { embeds: [embed] };
  }

  const MASTER_EXPLICIT_TABLES = new Set([
    'bot_owners',
    'global_settings',
    'shard_stats',
    'guild_records',
    'master_records',
    'automod',
    'emergency_lockdown',
    'backup_snapshots',
    'maintenance_mode'
  ]);

  let targetScope = scope;
  if (!targetScope) {
    if (MASTER_TABLE_SCHEMAS[targetTable] || MASTER_EXPLICIT_TABLES.has(targetTable.toLowerCase())) {
      targetScope = 'master';
    } else if (guildId) {
      targetScope = guildId;
    } else {
      targetScope = 'master';
    }
  }

  const isMaster = targetScope === 'master' || targetScope === 'global';
  const collName = isMaster ? 'master_records' : 'guild_records';
  const query = { table: targetTable };
  if (!isMaster && targetScope) {
    query.guild_id = String(targetScope);
  }

  let docs = [];
  let total = 0;

  if (db) {
    try {
      total = await db.collection(collName).countDocuments(query);
      if (total > 0) {
        const totalPages = Math.max(1, Math.ceil(total / pageSize));
        const safePage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
        docs = await db.collection(collName)
          .find(query)
          .skip((safePage - 1) * pageSize)
          .limit(pageSize)
          .toArray();
      }
    } catch (_) {}
  }

  // Fallback to in-memory SQLite if MongoDB returned 0 or is disconnected
  if (total === 0) {
    try {
      const targetDb = isMaster ? getMasterDb() : (targetScope && targetScope !== 'master' ? getServerDb(targetScope) : getMasterDb());
      const countRes = targetDb.prepare(`SELECT COUNT(*) as c FROM "${targetTable}"`).get();
      total = countRes?.c || 0;
      if (total > 0) {
        const totalPages = Math.max(1, Math.ceil(total / pageSize));
        const safePage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
        const offset = (safePage - 1) * pageSize;
        const rows = targetDb.prepare(`SELECT * FROM "${targetTable}" LIMIT ? OFFSET ?`).all(pageSize, offset);
        docs = rows.map(r => ({ table: targetTable, ...r }));
      }
    } catch (_) {}
  }

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(totalPages, Math.max(1, parseInt(page, 10) || 1));
  const targetKey = isMaster ? `master:${targetTable}` : `${targetScope}:${targetTable}`;

  if (total === 0 || docs.length === 0) {
    const embed = createEmbed()
      .setTitle(`MongoDB Atlas Document Inspector — ${isMaster ? 'Master DB' : `Server ${targetScope}`}`)
      .setDescription(
        `No documents found in \`${collName}\` matching table \`${targetTable}\`.\n\n` +
        `Tip: Run \`!db contents\` to browse all 61 canonical tables.`
      )
      .setFooter({ text: `Scope: ${collName} • Table: ${targetTable} • Read-Only` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('dbnav:contents:master:1').setLabel('Master Tables').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('dbnav:contents:guild:1').setLabel('Guild Tables').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('dbnav:contents:all:1').setLabel('Overview').setStyle(ButtonStyle.Secondary)
    );

    return { embeds: [embed], components: [row] };
  }

  const formatted = docs.map((doc, idx) => {
    const clean = redactSensitive({ ...doc });
    const docId = clean._id || `row_${(safePage - 1) * pageSize + idx + 1}`;
    delete clean._id;
    delete clean._synced_at;
    delete clean.table;
    if (!isMaster) delete clean.guild_id;
    const docNum = (safePage - 1) * pageSize + idx + 1;
    return `/* Document #${docNum} of ${total} | ID: ${docId} */\n${JSON.stringify(clean, null, 2)}`;
  }).join('\n\n');

  let textBlock = formatted;
  if (textBlock.length > 1850) {
    textBlock = textBlock.slice(0, 1800) + '\n\n... [Output Truncated to fit Discord Embed]';
  }

  const embed = createEmbed()
    .setTitle(`MongoDB Atlas Document Inspector — ${isMaster ? 'Master DB' : `Server ${targetScope}`}`)
    .setDescription(
      `Table: \`${targetTable}\` • Showing **${docs.length}** of **${total}** documents (Page ${safePage}/${totalPages}):\n\`\`\`json\n${textBlock}\n\`\`\``
    )
    .setFooter({ text: `Scope: ${collName} • Page ${safePage} of ${totalPages} • Total: ${total} • Read-Only` });

  const prevPage = Math.max(1, safePage - 1);
  const nextPage = Math.min(totalPages, safePage + 1);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`dbnav:inspect:${targetKey}:${prevPage}`)
      .setLabel('◀ Prev')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(safePage <= 1),
    new ButtonBuilder()
      .setCustomId(`dbnav:inspect:${targetKey}:${safePage}`)
      .setLabel(`Page ${safePage} / ${totalPages}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`dbnav:inspect:${targetKey}:${nextPage}`)
      .setLabel('Next ▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(safePage >= totalPages),
    new ButtonBuilder()
      .setCustomId(`dbnav:export:${targetKey}:1`)
      .setLabel('📥 Download JSON File')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

/**
 * Exports table documents or files as downloadable JSON buffer and attachment
 */
async function exportTableData({ scope = null, table = null, db = null, client = null, guildId = null }) {
  if (!db) {
    db = await ensureMongoDb();
  }

  let targetTable = table ? String(table).trim() : null;
  let targetScope = scope ? String(scope).trim() : null;

  // Check if exporting entire master database
  if (targetTable === 'master' || (targetScope === 'master' && (!targetTable || targetTable === 'all' || targetTable === 'master'))) {
    let docs = [];
    if (db) {
      try {
        docs = await db.collection('master_records').find({}).toArray();
      } catch (_) {}
    }
    if (docs.length === 0) {
      try {
        const masterDb = getMasterDb();
        const tables = masterDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
        for (const t of tables) {
          const rows = masterDb.prepare(`SELECT * FROM "${t.name}"`).all();
          for (const r of rows) docs.push({ table: t.name, ...r });
        }
      } catch (_) {}
    }
    const cleanDocs = docs.map(d => redactSensitive({ ...d }));
    const jsonStr = JSON.stringify(cleanDocs, null, 2);
    const buffer = Buffer.from(jsonStr, 'utf-8');
    const fileName = 'master_database.json';
    const attachment = new AttachmentBuilder(buffer, { name: fileName });
    const embed = createEmbed()
      .setTitle('Database Export — Master Database')
      .setDescription(
        `📦 Exported **${cleanDocs.length}** documents from master database as a downloadable JSON file.\n` +
        `• **File:** \`${fileName}\`\n` +
        `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\`\n` +
        `• **Scope:** \`master_records\` (Atlas Cloud & RAM)`
      )
      .setFooter({ text: 'MongoDB Atlas Cloud Export • Authorized Bot Owner' });
    return { buffer, fileName, docCount: cleanDocs.length, embed, attachment, files: [attachment], embeds: [embed] };
  }

  // Check if exporting entire server
  const isServerScope = (targetTable === 'server' && targetScope) || (/^\d{16,21}$/.test(targetTable) && !targetScope) || (/^\d{16,21}$/.test(targetScope) && (!targetTable || targetTable === 'all' || targetTable === 'server'));
  if (isServerScope) {
    const sId = /^\d{16,21}$/.test(targetTable) ? targetTable : (targetScope || guildId);
    let docs = [];
    if (db) {
      try {
        docs = await db.collection('guild_records').find({ guild_id: String(sId) }).toArray();
      } catch (_) {}
    }
    if (docs.length === 0) {
      try {
        const guildDb = getServerDb(sId);
        const tables = guildDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
        for (const t of tables) {
          const rows = guildDb.prepare(`SELECT * FROM "${t.name}"`).all();
          for (const r of rows) docs.push({ guild_id: sId, table: t.name, ...r });
        }
      } catch (_) {}
    }
    const cleanDocs = docs.map(d => redactSensitive({ ...d }));
    const jsonStr = JSON.stringify(cleanDocs, null, 2);
    const buffer = Buffer.from(jsonStr, 'utf-8');
    const fileName = `server_${sId}.json`;
    const attachment = new AttachmentBuilder(buffer, { name: fileName });
    const embed = createEmbed()
      .setTitle(`Database Export — Server ${sId}`)
      .setDescription(
        `📦 Exported **${cleanDocs.length}** documents for server \`${sId}\` as a downloadable JSON file.\n` +
        `• **File:** \`${fileName}\`\n` +
        `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\`\n` +
        `• **Scope:** \`guild_records\` (Server: ${sId})`
      )
      .setFooter({ text: `Guild ID: ${sId} • Export Complete` });
    return { buffer, fileName, docCount: cleanDocs.length, embed, attachment, files: [attachment], embeds: [embed] };
  }

  // Check if a disk file in db/ is requested (e.g. emoji_ids.json)
  const dbDir = path.resolve(process.cwd(), 'db');
  const potentialFile = targetTable ? path.resolve(dbDir, targetTable.replace(/^[/\\]+/, '')) : null;
  if (potentialFile && potentialFile.startsWith(dbDir) && (fs.existsSync(potentialFile) || fs.existsSync(potentialFile + '.json'))) {
    const realFile = fs.existsSync(potentialFile) && fs.statSync(potentialFile).isFile()
      ? potentialFile
      : potentialFile + '.json';
    if (fs.existsSync(realFile) && fs.statSync(realFile).isFile()) {
      const baseName = path.basename(realFile);
      let raw = fs.readFileSync(realFile, 'utf-8');
      if (baseName.endsWith('.json')) {
        try {
          const parsed = JSON.parse(raw);
          raw = JSON.stringify(redactSensitive(parsed), null, 2);
        } catch (_) {}
      }
      const buffer = Buffer.from(raw, 'utf-8');
      const attachment = new AttachmentBuilder(buffer, { name: baseName });
      const embed = createEmbed()
        .setTitle(`Database File Export — ${baseName}`)
        .setDescription(
          `📦 Exported file \`${baseName}\` from \`db/\` directory.\n` +
          `• **File:** \`${baseName}\`\n` +
          `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\``
        )
        .setFooter({ text: `File: db/${baseName} • Read-Only` });
      return { buffer, fileName: baseName, docCount: 1, embed, attachment, files: [attachment], embeds: [embed] };
    }
  }

  // Normal table export
  if (!targetTable) targetTable = 'bot_owners';
  const isMaster = targetScope === 'master' || targetScope === 'global' || Boolean(MASTER_TABLE_SCHEMAS[targetTable]);
  const collName = isMaster ? 'master_records' : 'guild_records';
  const query = { table: targetTable };
  if (!isMaster && (targetScope || guildId)) {
    query.guild_id = String(targetScope || guildId);
  }

  let docs = [];
  if (db) {
    try {
      docs = await db.collection(collName).find(query).toArray();
      if (docs.length === 0 && !isMaster) {
        docs = await db.collection('guild_records').find({ table: targetTable }).toArray();
      }
    } catch (_) {}
  }

  if (docs.length === 0) {
    try {
      const targetDb = isMaster ? getMasterDb() : (targetScope || guildId ? getServerDb(targetScope || guildId) : getMasterDb());
      const rows = targetDb.prepare(`SELECT * FROM "${targetTable}"`).all();
      docs = rows.map(r => ({ table: targetTable, ...r }));
    } catch (_) {}
  }

  const cleanDocs = docs.map(d => redactSensitive({ ...d }));
  const jsonStr = JSON.stringify(cleanDocs, null, 2);
  const buffer = Buffer.from(jsonStr, 'utf-8');
  const fileName = `${targetTable}.json`;
  const attachment = new AttachmentBuilder(buffer, { name: fileName });
  const embed = createEmbed()
    .setTitle(`Database Table Export — ${targetTable}`)
    .setDescription(
      `📦 Exported **${cleanDocs.length}** documents from \`${targetTable}\` as a downloadable JSON file.\n` +
      `• **File:** \`${fileName}\`\n` +
      `• **Size:** \`${(buffer.length / 1024).toFixed(2)} KB\`\n` +
      `• **Table:** \`${targetTable}\` (${collName})`
    )
    .setFooter({ text: `Scope: ${collName} • Table: ${targetTable} • Export Complete` });

  return { buffer, fileName, docCount: cleanDocs.length, embed, attachment, files: [attachment], embeds: [embed] };
}

/**
 * Performs global text/regex search across all master and guild records in MongoDB Atlas & RAM
 */
async function searchDatabase(keyword, { db = null, limit = 25 } = {}) {
  const kw = String(keyword || '').trim();
  if (!kw) return [];

  if (!db) {
    db = await ensureMongoDb();
  }

  const matches = [];
  const safeRegex = new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');

  if (db) {
    try {
      // 1. Direct query on indexed / common fields in master_records
      const masterDirect = await db.collection('master_records').find({
        $or: [
          { table: { $regex: safeRegex } },
          { _id: { $regex: safeRegex } },
          { user_id: { $regex: safeRegex } },
          { key: { $regex: safeRegex } },
          { value: { $regex: safeRegex } }
        ]
      }).limit(15).toArray();

      for (const doc of masterDirect) {
        matches.push({
          scope: 'master',
          table: doc.table || 'master',
          id: doc._id || 'unknown',
          doc: redactSensitive(doc)
        });
      }

      // 2. Direct query on indexed / common fields in guild_records
      const guildDirect = await db.collection('guild_records').find({
        $or: [
          { table: { $regex: safeRegex } },
          { guild_id: { $regex: safeRegex } },
          { _id: { $regex: safeRegex } },
          { user_id: { $regex: safeRegex } },
          { role_id: { $regex: safeRegex } },
          { channel_id: { $regex: safeRegex } }
        ]
      }).limit(15).toArray();

      for (const doc of guildDirect) {
        matches.push({
          scope: doc.guild_id || 'guild',
          table: doc.table || 'guild',
          id: doc._id || 'unknown',
          doc: redactSensitive(doc)
        });
      }

      // 3. Scan documents to catch arbitrary nested fields
      if (matches.length < 5) {
        const mCursor = db.collection('master_records').find({}).limit(150);
        for await (const doc of mCursor) {
          if (matches.some(m => m.id === doc._id)) continue;
          const str = JSON.stringify(redactSensitive(doc));
          if (safeRegex.test(str)) {
            matches.push({
              scope: 'master',
              table: doc.table || 'master',
              id: doc._id || 'unknown',
              doc: redactSensitive(doc)
            });
            if (matches.length >= limit) break;
          }
        }
      }
    } catch (_) {}
  }

  // Fallback to SQLite in-memory tables if no matches or disconnected
  if (matches.length === 0) {
    try {
      const masterDb = getMasterDb();
      const tables = masterDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
      for (const t of tables) {
        const rows = masterDb.prepare(`SELECT * FROM "${t.name}"`).all();
        for (const r of rows) {
          const str = JSON.stringify(redactSensitive(r));
          if (safeRegex.test(str)) {
            matches.push({
              scope: 'master',
              table: t.name,
              id: r.id || r.user_id || r.key || 'row',
              doc: redactSensitive(r)
            });
            if (matches.length >= limit) break;
          }
        }
        if (matches.length >= limit) break;
      }
    } catch (_) {}
  }

  return matches;
}

module.exports = {
  permissions: ['Administrator'],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'database',
  aliases: [
    'db',
    'sql',
    'dbs',
    'dbview',
    'dbtables',
    'dbquery',
    'dbschema',
    'dbservers',
    'dbstats',
    'dbmongo',
    'dbsync',
    'dbcontents',
    'dbinspect',
    'dbguilds',
    'dbexport',
    'dbfile',
    'dbdownload',
    'dbdump',
    'dbsearch',
    'dbfind'
  ],
  category: 'owner',
  description: 'Inspect and monitor MongoDB Atlas cloud database and in-memory SQLite tables directly from Discord.',
  usage: '<servers|server|contents|inspect|export|file|search|stats|sync|schema|query> [args]',
  ownerOnly: true,

  slash: new SlashCommandBuilder()
    .setName('db')
    .setDescription('MongoDB Atlas Cloud Database Explorer & Inspector')
    .addStringOption(opt =>
      opt.setName('action')
        .setDescription('Database action to execute')
        .setRequired(false)
        .addChoices(
          { name: 'Stats — MongoDB Atlas & Storage Telemetry', value: 'stats' },
          { name: 'Contents — List all tables & storage quota', value: 'contents' },
          { name: 'Servers — List all server databases in Atlas', value: 'servers' },
          { name: 'Server — Inspect tables for a specific server', value: 'server' },
          { name: 'Inspect — View raw documents in a table', value: 'inspect' },
          { name: 'Export — Download table, server, or master JSON file', value: 'export' },
          { name: 'File — View or download files from db/ directory', value: 'file' },
          { name: 'Search — Search all database records globally', value: 'search' },
          { name: 'Sync — Mirror in-memory DBs to Atlas', value: 'sync' }
        )
    )
    .addStringOption(opt =>
      opt.setName('category')
        .setDescription('Category for contents view (all, master, guild, storage)')
        .setRequired(false)
        .addChoices(
          { name: 'All — Complete Overview & Storage Quota Meter', value: 'all' },
          { name: 'Master — All 26 Master Tables & Column Fields', value: 'master' },
          { name: 'Guild — All 35 Guild Tables & Column Fields', value: 'guild' },
          { name: 'Storage — Deep-Dive Quota Breakdown', value: 'storage' }
        )
    )
    .addStringOption(opt =>
      opt.setName('target')
        .setDescription('Guild ID or "master" (for server / inspect)')
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt.setName('table')
        .setDescription('Table name to inspect')
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt.setName('query')
        .setDescription('Search keyword, file name, or table for export')
        .setRequired(false)
    )
    .addIntegerOption(opt =>
      opt.setName('page')
        .setDescription('Page number for paginated views (master/guild)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(10)
    )
    .addIntegerOption(opt =>
      opt.setName('limit')
        .setDescription('Number of records to display (1-20)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(20)
    ),

  async execute(message, args, client, prefix) {
    // 1. Strictly Owner-Only check
    if (!isOwner(message.author.id)) {
      return message.reply('Access Denied: This command can be executed only by Bot Owner.');
    }

    const invokedCmd = (
      message.invokedName ||
      (message.content && prefix && message.content.startsWith(prefix)
        ? message.content.slice(prefix.length).trim().split(/\s+/)[0]
        : message.content?.trim().split(/\s+/)[0]) ||
      'db'
    ).toLowerCase();

    let sub = args[0]?.toLowerCase();

    // Map alias invocations directly to subcommands
    if (invokedCmd === 'dbservers' || invokedCmd === 'dbguilds') sub = 'servers';
    if (invokedCmd === 'dbtables' || invokedCmd === 'dbcontents') sub = 'contents';
    if (invokedCmd === 'dbinspect' || invokedCmd === 'dbview') sub = 'inspect';
    if (invokedCmd === 'dbquery') sub = 'query';
    if (invokedCmd === 'dbschema') sub = 'schema';
    if (invokedCmd === 'dbstats' || invokedCmd === 'dbmongo' || invokedCmd === 'dbstatus') sub = 'stats';
    if (invokedCmd === 'dbsync') sub = 'sync';
    if (invokedCmd === 'dbexport' || invokedCmd === 'dbdownload' || invokedCmd === 'dbdump') sub = 'export';
    if (invokedCmd === 'dbfile') sub = 'file';
    if (invokedCmd === 'dbsearch' || invokedCmd === 'dbfind') sub = 'search';

    // ─────────────────────────────────────────────────────────────
    // 1. HELP / OVERVIEW
    // ─────────────────────────────────────────────────────────────
    if (!sub || sub === 'help') {
      const embed = createEmbed()
        .setTitle('MongoDB Atlas Cloud Database Explorer')
        .setDescription(
          `Comprehensive read-only viewing, inspection, and export suite for **MongoDB Atlas** cloud storage and in-memory SQLite tables.\n\n` +
          `**Cloud Viewing & Inspection Commands:**\n` +
          `• \`${prefix}db contents\` (or \`tables\`) — List all 61 canonical tables with storage quota meter\n` +
          `• \`${prefix}db inspect <guild_id|master> <table> [page]\` — Interactive paginated viewer with download button\n` +
          `• \`${prefix}db export <table> [guild_id]\` — Export any table directly to Discord as downloadable JSON\n` +
          `• \`${prefix}db export server <guild_id>\` — Dumps all tables of that server into \`server_<guild_id>.json\`\n` +
          `• \`${prefix}db export master\` — Dumps all master tables into \`master_database.json\`\n` +
          `• \`${prefix}db file <filename>\` — View or download files in \`db/\` directory (e.g. \`emoji_ids.json\`)\n` +
          `• \`${prefix}db search <keyword>\` — Global regex search across master & guild database records\n` +
          `• \`${prefix}db servers\` — List all servers created in MongoDB Atlas & their contents\n` +
          `• \`${prefix}db server <guild_id>\` — View all tables & document counts for a server\n` +
          `• \`${prefix}db stats\` (or \`status\`, \`mongo\`) — MongoDB Atlas connection, latency, and telemetry\n` +
          `• \`${prefix}db sync\` (or \`push\`) — Trigger immediate push of in-memory data to Atlas\n` +
          `• \`${prefix}db schema <table>\` — Inspect schema and field types\n` +
          `• \`${prefix}db query <SQL>\` — Execute read-only SQL query on in-memory DB\n\n` +
          `**Architecture:**\n` +
          `• 100% Cloud-backed on MongoDB Atlas\n` +
          `• In-memory SQLite RAM cache (Zero local disk files)\n` +
          `• Read-only inspection safeguards & credentials redacted`
        )
        .setFooter({ text: `Authorized Bot Owner: ${message.author.username}` });
      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. SERVERS LIST (MongoDB Atlas)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'servers' || sub === 'guilds' || sub === 'list') {
      try {
        const db = await ensureMongoDb();
        if (!db) {
          return message.reply('MongoDB Atlas is currently disconnected or MONGODB_URI is not configured in .env.');
        }

        const pipeline = [
          {
            $group: {
              _id: { guild_id: '$guild_id', table: '$table' },
              tableDocCount: { $sum: 1 }
            }
          },
          {
            $group: {
              _id: '$_id.guild_id',
              tablesCount: { $sum: 1 },
              totalDocs: { $sum: '$tableDocCount' }
            }
          },
          { $sort: { totalDocs: -1 } }
        ];

        const serverAgg = await db.collection('guild_records').aggregate(pipeline).toArray();

        // Retrieve server names from server_info
        const infoDocs = await db.collection('guild_records').find(
          { table: 'server_info' },
          { projection: { guild_id: 1, name: 1 } }
        ).toArray();
        const nameMap = new Map();
        for (const doc of infoDocs) {
          if (doc.guild_id && doc.name) nameMap.set(doc.guild_id, doc.name);
        }

        if (serverAgg.length === 0) {
          const embed = createEmbed()
            .setTitle('MongoDB Atlas — Server Databases (0 Total)')
            .setDescription(`No server records found in MongoDB Atlas cloud storage.\nRun \`${prefix}db sync\` to push server data to Atlas.`);
          return message.reply({ embeds: [embed] });
        }

        const lines = serverAgg.slice(0, 25).map((s, idx) => {
          const gid = s._id;
          const name = client?.guilds?.cache?.get(gid)?.name || nameMap.get(gid) || 'Unknown Server';
          return `${idx + 1}. \`${gid}\` — **${name}**\n   ↳ **${s.totalDocs}** documents • **${s.tablesCount}** tables`;
        });

        const embed = createEmbed()
          .setTitle(`MongoDB Atlas — Registered Server Databases (${serverAgg.length} Total)`)
          .setDescription(
            `Database records have been created for **${serverAgg.length}** distinct servers in MongoDB Atlas cloud storage:\n\n` +
            lines.join('\n') +
            (serverAgg.length > 25 ? `\n\n*...and ${serverAgg.length - 25} more servers in cloud.*` : '')
          )
          .setFooter({ text: `Use ${prefix}db server <guild_id> to inspect a server's tables` });

        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Error fetching servers from MongoDB: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 3. SPECIFIC SERVER TABLES & CONTENTS (MongoDB Atlas)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'server') {
      const targetGid = args[1] || (message.guild ? message.guild.id : null);
      if (!targetGid) {
        return message.reply(`Usage: \`${prefix}db server <guild_id>\``);
      }

      try {
        const db = await ensureMongoDb();
        if (!db) {
          return message.reply('MongoDB Atlas is currently disconnected or MONGODB_URI is not configured in .env.');
        }

        const tableResults = await db.collection('guild_records').aggregate([
          { $match: { guild_id: String(targetGid) } },
          { $group: { _id: '$table', count: { $sum: 1 } } },
          { $sort: { count: -1 } }
        ]).toArray();

        if (tableResults.length === 0) {
          return message.reply(`No records found in MongoDB Atlas for server \`${targetGid}\`.`);
        }

        const serverInfoDoc = await db.collection('guild_records').findOne({ guild_id: String(targetGid), table: 'server_info' });
        const serverName = client?.guilds?.cache?.get(String(targetGid))?.name || serverInfoDoc?.name || 'Unknown Server';
        const totalDocs = tableResults.reduce((sum, t) => sum + t.count, 0);

        const lines = tableResults.map(t => `• \`${t._id.padEnd(28)}\` — **${t.count}** documents`);

        const embed = createEmbed()
          .setTitle(`Server Cloud Database — ${serverName} (${targetGid})`)
          .setDescription(
            `Found **${tableResults.length}** tables with **${totalDocs}** total documents stored in MongoDB Atlas:\n\n` +
            lines.slice(0, 30).join('\n') +
            (lines.length > 30 ? `\n\n*...and ${lines.length - 30} more tables.*` : '')
          )
          .setFooter({ text: `Use ${prefix}db inspect ${targetGid} <table> to view documents` });

        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Error fetching server tables: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 4. INSPECT TABLE DOCUMENTS (Read-Only with Pagination & Download Button)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'inspect' || sub === 'view' || sub === 'mongoview' || sub === 'mview') {
      let targetScope = null;
      let targetTable = null;
      let pageVal = 1;

      const MASTER_EXPLICIT_TABLES = new Set([
        'bot_owners',
        'global_settings',
        'shard_stats',
        'guild_records',
        'master_records',
        'automod',
        'emergency_lockdown',
        'backup_snapshots',
        'maintenance_mode'
      ]);

      const rawA = args[1]?.trim();
      const rawB = args[2]?.trim();
      const rawC = args[3]?.trim();

      if (!rawA) {
        return message.reply(`Usage: \`${prefix}db inspect <guild_id|master> <table> [page]\` or \`${prefix}db inspect <table> [page]\` (in a server)`);
      }

      if (rawA.toLowerCase() === 'master' || rawA.toLowerCase() === 'global') {
        targetScope = 'master';
        targetTable = rawB;
        pageVal = parseInt(rawC, 10) || 1;
      } else if (/^\d{16,21}$/.test(rawA)) {
        targetScope = rawA;
        targetTable = rawB;
        pageVal = parseInt(rawC, 10) || 1;
      } else {
        // rawA is the table name
        targetTable = rawA;
        pageVal = parseInt(rawB, 10) || 1;
        if (MASTER_TABLE_SCHEMAS[targetTable] || MASTER_EXPLICIT_TABLES.has(targetTable.toLowerCase())) {
          targetScope = 'master';
        } else if (message.guild) {
          targetScope = message.guild.id;
        } else {
          targetScope = 'master';
        }
      }

      if (!targetTable) {
        return message.reply(`Please specify a table to inspect. Example: \`${prefix}db inspect ${targetScope === 'master' ? 'master bot_owners' : 'antinuke_rules'}\``);
      }

      try {
        const payload = await buildInspectPayload({
          scope: targetScope,
          table: targetTable,
          page: pageVal,
          pageSize: 5,
          guildId: message.guild?.id
        });
        return message.reply(payload);
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Error inspecting documents: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 4B. EXPORT / DOWNLOAD TABLE OR DATABASE AS JSON ATTACHMENT
    // ─────────────────────────────────────────────────────────────
    if (sub === 'export' || sub === 'download' || sub === 'dump' || sub === 'dl') {
      const rawA = args[1]?.trim();
      const rawB = args[2]?.trim();

      let targetScope = 'master';
      let targetTable = null;

      if (!rawA || rawA.toLowerCase() === 'all' || rawA.toLowerCase() === 'master') {
        targetScope = 'master';
        targetTable = rawB || null;
      } else if (rawA.toLowerCase() === 'server' || rawA.toLowerCase() === 'guild') {
        targetScope = rawB || message.guild?.id;
        targetTable = args[3]?.trim() || null;
      } else if (/^\d{16,21}$/.test(rawA)) {
        targetScope = rawA;
        targetTable = rawB || null;
      } else {
        targetTable = rawA;
        if (MASTER_TABLE_SCHEMAS[targetTable] || targetTable.startsWith('global_')) {
          targetScope = 'master';
        } else if (message.guild) {
          targetScope = message.guild.id;
        } else {
          targetScope = 'master';
        }
      }

      try {
        const payload = await exportTableData({
          scope: targetScope,
          table: targetTable,
          guildId: message.guild?.id
        });
        return message.reply(payload);
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Export failed: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 4C. FILE EXPLORER (Read & download db/ files directly in Discord)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'file' || sub === 'files' || sub === 'readfile' || sub === 'showfile' || sub === 'cat') {
      const fileName = args[1]?.trim();
      const dbBaseDir = path.resolve(__dirname, '../../../db');

      if (!fileName) {
        // List all files in db/
        let filesList = [];
        try {
          if (fs.existsSync(dbBaseDir)) {
            filesList = fs.readdirSync(dbBaseDir).filter(f => !f.startsWith('.'));
          }
        } catch (_) {}

        const embed = createEmbed()
          .setTitle('Database File Explorer')
          .setDescription(
            `Files located in the bot's runtime database environment:\n\n` +
            (filesList.length > 0
              ? filesList.map(f => `• \`${f}\``).join('\n')
              : `*No local files found in db/ (Zero local SQLite database footprint active — 100% in MongoDB Atlas)*\n\n`) +
            `\n**Viewing or downloading a file or table:**\n` +
            `• \`${prefix}db file <filename>\` — View contents or download file directly via Discord\n` +
            `• \`${prefix}db export <table>\` — Export any MongoDB Atlas table as a JSON attachment`
          )
          .setFooter({ text: 'In-Discord Direct File Access • Read-Only' });
        return message.reply({ embeds: [embed] });
      }

      // Prevent path traversal
      const safeName = path.basename(fileName);
      const targetPath = path.resolve(dbBaseDir, safeName);

      if (!fs.existsSync(targetPath)) {
        // If not in db/, check if it's a known table name to export
        if (MASTER_TABLE_SCHEMAS[safeName] || GUILD_TABLE_SCHEMAS[safeName]) {
          const payload = await exportTableData({ scope: 'master', table: safeName, guildId: message.guild?.id });
          return message.reply(payload);
        }
        return message.reply(`<a:tungsten_close:1567234632905138206> File \`${safeName}\` not found in \`db/\`. Run \`${prefix}db file\` to list available files.`);
      }

      try {
        const stats = fs.statSync(targetPath);
        if (stats.isDirectory()) {
          const innerFiles = fs.readdirSync(targetPath).slice(0, 30);
          const embed = createEmbed()
            .setTitle(`Directory: ${safeName}/`)
            .setDescription(innerFiles.map(f => `• \`${f}\``).join('\n') || '*Empty directory*')
            .setFooter({ text: 'Read-Only' });
          return message.reply({ embeds: [embed] });
        }

        const buffer = fs.readFileSync(targetPath);
        if (safeName.endsWith('.json') && buffer.length < 1800) {
          try {
            const parsed = JSON.parse(buffer.toString('utf-8'));
            const clean = redactSensitive(parsed);
            const embed = createEmbed()
              .setTitle(`File: ${safeName}`)
              .setDescription(`\`\`\`json\n${JSON.stringify(clean, null, 2).slice(0, 1800)}\n\`\`\``)
              .setFooter({ text: `Size: ${(buffer.length / 1024).toFixed(2)} KB • Read-Only` });
            return message.reply({ embeds: [embed] });
          } catch (_) {}
        }

        const attachment = new AttachmentBuilder(buffer, { name: safeName });
        const embed = createEmbed()
          .setTitle(`File Attachment: ${safeName}`)
          .setDescription(`Attached file \`${safeName}\` (${(buffer.length / 1024).toFixed(2)} KB) for direct download via Discord.`)
          .setFooter({ text: 'In-Discord File Delivery • Read-Only' });
        return message.reply({ embeds: [embed], files: [attachment] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed reading file: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 4D. GLOBAL DATABASE SEARCH (Search across cloud collections)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'search' || sub === 'find' || sub === 'grep' || sub === 'lookup') {
      const keyword = args.slice(1).join(' ').trim();
      if (!keyword) {
        return message.reply(`Usage: \`${prefix}db search <keyword>\``);
      }

      try {
        const results = await searchDatabase(keyword);
        if (results.length === 0) {
          const embed = createEmbed()
            .setTitle(`Database Search — "${keyword}"`)
            .setDescription(`No records matching keyword \`${keyword}\` found in MongoDB Atlas cloud storage.`)
            .setFooter({ text: '0 records matched • Read-Only' });
          return message.reply({ embeds: [embed] });
        }

        const snippetLines = results.slice(0, 10).map((r, i) => {
          const cleanDoc = redactSensitive({ ...r.doc });
          delete cleanDoc._id;
          delete cleanDoc._synced_at;
          delete cleanDoc.table;
          const snippet = JSON.stringify(cleanDoc).slice(0, 120);
          return `**${i + 1}. [${r.scope.toUpperCase()}] \`${r.table}\`** (ID: \`${r.id}\`)\n\`${snippet}...\``;
        }).join('\n\n');

        const embed = createEmbed()
          .setTitle(`Database Search Results — "${keyword}"`)
          .setDescription(
            `Found **${results.length}** matching record(s) across MongoDB Atlas cloud collections:\n\n` +
            snippetLines +
            (results.length > 10 ? `\n\n*... and ${results.length - 10} more matches.*` : '')
          )
          .setFooter({ text: `Showing top ${Math.min(results.length, 10)} of ${results.length} results • Read-Only` });

        return message.reply({ embeds: [embed] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Search failed: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 5. CONTENTS / ALL TABLES (MongoDB Atlas)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'contents' || sub === 'tables') {
      try {
        const subArg = args[1]?.toLowerCase();
        const db = await ensureMongoDb();

        if (subArg === 'master') {
          const page = parseInt(args[2], 10) || 1;
          const payload = await buildContentsPayload({ category: 'master', page, db, client, guildId: message.guild?.id });
          return message.reply(payload);
        }

        if (subArg === 'guild' || subArg === 'guilds') {
          const page = parseInt(args[2], 10) || 1;
          const payload = await buildContentsPayload({ category: 'guild', page, db, client, guildId: message.guild?.id });
          return message.reply(payload);
        }

        if (subArg === 'storage' || subArg === 'quota' || subArg === 'meter') {
          const payload = await buildContentsPayload({ category: 'storage', page: 1, db, client, guildId: message.guild?.id });
          return message.reply(payload);
        }

        if (!subArg || subArg === 'all') {
          const payload = await buildContentsPayload({ category: 'all', page: 1, db, client, guildId: message.guild?.id });
          return message.reply(payload);
        }

        // Specific table view: !db contents <table> [limit]
        const targetTable = subArg;
        let limitVal = parseInt(args[2], 10) || 5;
        limitVal = Math.min(20, Math.max(1, limitVal));

        const isMaster = Boolean(MASTER_TABLE_SCHEMAS[targetTable]);
        const collName = isMaster ? 'master_records' : 'guild_records';
        const query = { table: targetTable };
        if (!isMaster && message.guild) {
          query.guild_id = String(message.guild.id);
        }

        let docs = [];
        let total = 0;
        if (db) {
          try {
            docs = await db.collection(collName).find(query).limit(limitVal).toArray();
            total = await db.collection(collName).countDocuments(query);
            if (docs.length === 0 && !isMaster) {
              docs = await db.collection('guild_records').find({ table: targetTable }).limit(limitVal).toArray();
              total = await db.collection('guild_records').countDocuments({ table: targetTable });
            }
          } catch (_) {}
        }

        if (docs.length === 0) {
          const targetDb = isMaster ? getMasterDb() : (message.guild ? getServerDb(message.guild.id) : getMasterDb());
          let rows = [];
          try {
            rows = targetDb.prepare(`SELECT * FROM "${targetTable}" LIMIT ?`).all(limitVal);
          } catch (_) {}

          if (rows.length > 0) {
            const formatted = rows.map((r, idx) => `/* Row #${idx + 1} */\n${JSON.stringify(r, null, 2)}`).join('\n\n');
            let textBlock = formatted.length > 1850 ? formatted.slice(0, 1800) + '\n\n... [Truncated]' : formatted;
            const embed = createEmbed()
              .setTitle(`In-Memory Document Inspector — Table: ${targetTable}`)
              .setDescription(`Showing **${rows.length}** rows from in-memory cache for table \`${targetTable}\`:\n\`\`\`json\n${textBlock}\n\`\`\``)
              .setFooter({ text: `Scope: In-Memory SQLite • Table: ${targetTable} • Read-Only` });

            const row = new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('dbnav:contents:master:1').setLabel('Master Tables (26)').setStyle(ButtonStyle.Primary),
              new ButtonBuilder().setCustomId('dbnav:contents:guild:1').setLabel('Guild Tables (35)').setStyle(ButtonStyle.Primary),
              new ButtonBuilder().setCustomId('dbnav:contents:quota:1').setLabel('Storage Quota').setStyle(ButtonStyle.Secondary),
              new ButtonBuilder().setCustomId('dbnav:contents:all:1').setLabel('Overview').setStyle(ButtonStyle.Secondary)
            );
            return message.reply({ embeds: [embed], components: [row] });
          }

          const embed = createEmbed()
            .setTitle(`MongoDB Atlas Document Inspector — Table: ${targetTable}`)
            .setDescription(
              `No documents found matching table \`${targetTable}\` in MongoDB Atlas or in-memory cache.\n\n` +
              `Click below to browse all available Master and Guild tables.`
            )
            .setFooter({ text: `Scope: ${collName} • Table: ${targetTable}` });

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('dbnav:contents:master:1').setLabel('Master Tables (26)').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('dbnav:contents:guild:1').setLabel('Guild Tables (35)').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('dbnav:contents:quota:1').setLabel('Storage Quota').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('dbnav:contents:all:1').setLabel('Overview').setStyle(ButtonStyle.Secondary)
          );
          return message.reply({ embeds: [embed], components: [row] });
        }

        const formatted = docs.map((doc, idx) => {
          const clean = redactSensitive({ ...doc });
          const docId = clean._id;
          delete clean._id;
          delete clean._synced_at;
          delete clean.table;
          return `/* Document #${idx + 1} | ID: ${docId} */\n${JSON.stringify(clean, null, 2)}`;
        }).join('\n\n');

        let textBlock = formatted;
        if (textBlock.length > 1850) {
          textBlock = textBlock.slice(0, 1800) + '\n\n... [Output Truncated to fit Discord Embed]';
        }

        const embed = createEmbed()
          .setTitle(`MongoDB Atlas Document Inspector — Table: ${targetTable}`)
          .setDescription(
            `Showing **${docs.length}** of **${total}** documents from \`${collName}\` matching table \`${targetTable}\`:\n\`\`\`json\n${textBlock}\n\`\`\``
          )
          .setFooter({ text: `Scope: ${collName} • Table: ${targetTable} • Read-Only` });

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('dbnav:contents:master:1').setLabel('Master Tables (26)').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('dbnav:contents:guild:1').setLabel('Guild Tables (35)').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('dbnav:contents:quota:1').setLabel('Storage Quota').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('dbnav:contents:all:1').setLabel('Overview').setStyle(ButtonStyle.Secondary)
        );

        return message.reply({ embeds: [embed], components: [row] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Error listing contents: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 6. STATS & TELEMETRY (MongoDB Atlas & In-Memory SQLite)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'stats' || sub === 'status' || sub === 'mongo' || sub === 'atlas') {
      try {
        let ping = { ok: false, latencyMs: 0 };
        let dbName = 'tungsten_bot';
        let masterDocs = 0;
        let guildDocs = 0;
        let totalServers = 0;
        let db = null;

        try {
          db = await ensureMongoDb();
          if (db) {
            dbName = db.databaseName;
            ping = await pingMongo();
            try {
              masterDocs = await db.collection('master_records').countDocuments();
              guildDocs = await db.collection('guild_records').countDocuments();
              const distinctGuilds = await db.collection('guild_records').distinct('guild_id');
              totalServers = distinctGuilds.length;
            } catch (_) {}
          }
        } catch (_) {}

        const storageStats = await getStorageStats(db);
        const quotaHeader = formatStorageQuotaBlock(storageStats);

        const totalDocs = masterDocs + guildDocs;
        const clusterStatusText = ping.ok
          ? '🟢 Connected'
          : (isMongoConnected() ? '🟡 Connected (Ping Pending)' : '🔴 Disconnected');

        const embed = createEmbed()
          .setTitle('MongoDB Atlas Cloud Database Diagnostics')
          .setDescription(
            `${quotaHeader}\n\n` +
            `**MongoDB Atlas Cloud Engine:**\n` +
            `• **Cluster Status:** ${clusterStatusText}\n` +
            `• **Roundtrip Latency:** \`${ping.latencyMs ? ping.latencyMs + 'ms' : 'N/A'}\`\n` +
            `• **Database Name:** \`${dbName}\`\n` +
            `• **Total Documents:** \`${totalDocs}\` (\`master_records\`: ${masterDocs}, \`guild_records\`: ${guildDocs})\n` +
            `• **Total Servers Created:** \`${totalServers}\` servers in cloud database\n` +
            `• **Collections & Indexes:** \`${storageStats.collections}\` collections • \`${storageStats.indexes}\` indexes\n` +
            `• **Cloud Architecture:** Consolidated 2-collection schema (BSON optimized)\n\n` +
            `**In-Memory SQLite Cache Engine:**\n` +
            `• **Local Disk Files:** \`0\` (Zero disk files, pure in-memory SQLite RAM cache)\n` +
            `• **Engine Mode:** In-Memory SQLite RAM Engine (No local file I/O)\n` +
            `• **Cloud Persistence:** Continuous replication and on-boot hydration active`
          )
          .setFooter({ text: `Execute ${prefix}db sync to mirror latest state to Atlas` });

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('dbnav:contents:master:1').setLabel('Master Tables (26)').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('dbnav:contents:guild:1').setLabel('Guild Tables (35)').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('dbnav:contents:quota:1').setLabel('Storage Quota').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('dbnav:contents:all:1').setLabel('Overview').setStyle(ButtonStyle.Secondary)
        );

        return message.reply({ embeds: [embed], components: [row] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Telemetry Error: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 7. SYNC / PUSH TO MONGODB ATLAS
    // ─────────────────────────────────────────────────────────────
    if (sub === 'sync' || sub === 'push') {
      let waitMsg = null;
      try {
        waitMsg = await message.reply('<a:tungsten_refresh:1567241907116187658> Connecting to MongoDB Atlas & initiating full database synchronization...');
      } catch (_) {}

      try {
        const summary = await pushAllDatabasesToMongo();
        const embed = createEmbed()
          .setTitle('MongoDB Atlas Cloud Synchronization Complete')
          .setDescription(
            `• **Status:** Success (100% Pushed to Cloud)\n` +
            `• **Cloud Database:** \`${summary.databaseName}\`\n` +
            `• **Master Tables:** \`${summary.masterTablesCount}\` (${summary.masterRowsCount} documents)\n` +
            `• **Guild Databases:** \`${summary.guildsCount}\` (${summary.guildRowsCount} documents)\n` +
            `• **Total Documents:** \`${summary.totalDocuments}\`\n` +
            `• **Elapsed Time:** \`${(summary.durationMs / 1000).toFixed(2)}s\`\n` +
            `• **Free-Tier Footprint:** \`< 1 MB\` (< 0.2% of 512 MB tier)`
          )
          .setFooter({ text: 'All in-memory tables safely mirrored to MongoDB Atlas' });

        if (waitMsg && typeof waitMsg.edit === 'function') {
          return waitMsg.edit({ content: null, embeds: [embed] });
        }
        return message.reply({ embeds: [embed] });
      } catch (err) {
        if (waitMsg && typeof waitMsg.edit === 'function') {
          return waitMsg.edit(`<a:tungsten_close:1567234632905138206> MongoDB Sync Error: ${err.message}`);
        }
        return message.reply(`<a:tungsten_close:1567234632905138206> MongoDB Sync Error: ${err.message}`);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 8. TABLE SCHEMA (In-Memory & MongoDB Atlas)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'schema' || sub === 'info') {
      const cleanArgs = args.filter(a => a !== '--server' && a !== '-s');
      const tableName = cleanArgs[1] || args[1];
      if (!tableName) {
        return message.reply(`Usage: \`${prefix}db schema <table>\``);
      }

      let columns = [];
      let targetDb = getMasterDb();
      try {
        columns = targetDb.prepare(`PRAGMA table_info("${tableName}")`).all();
      } catch (_) {}
      if ((!columns || columns.length === 0) && message.guild) {
        try {
          const sdb = getServerDb(message.guild.id);
          columns = sdb.prepare(`PRAGMA table_info("${tableName}")`).all();
          if (columns.length > 0) targetDb = sdb;
        } catch (_) {}
      }

      let sampleDoc = null;
      try {
        const db = await ensureMongoDb();
        if (db) {
          sampleDoc =
            (await db.collection('master_records').findOne({ table: tableName })) ||
            (await db.collection('guild_records').findOne({ table: tableName }));
        }
      } catch (_) {}

      const lines = [];
      if (columns && columns.length > 0) {
        columns.forEach(c => {
          const pkBadge = c.pk ? ' [PRIMARY KEY]' : '';
          const notNull = c.notnull ? ' NOT NULL' : '';
          const dflt = c.dflt_value !== null ? ` DEFAULT ${c.dflt_value}` : '';
          lines.push(`• \`${c.name.padEnd(20)}\` — \`${(c.type || 'ANY').toUpperCase()}\`${pkBadge}${notNull}${dflt}`);
        });
      } else if (sampleDoc) {
        const cleanSample = { ...sampleDoc };
        delete cleanSample._id;
        delete cleanSample.table;
        delete cleanSample._synced_at;
        delete cleanSample.guild_id;
        for (const [k, v] of Object.entries(cleanSample)) {
          const type = Array.isArray(v) ? 'ARRAY' : (v === null ? 'NULL' : typeof v);
          lines.push(`• \`${k.padEnd(20)}\` — \`${type.toUpperCase()}\``);
        }
      }

      if (lines.length === 0) {
        return message.reply(`Table \`${tableName}\` was not found in in-memory schema or MongoDB Atlas sample records.`);
      }

      const embed = createEmbed()
        .setTitle(`Table Schema — ${tableName}`)
        .setDescription(
          `Fields and data types for \`${tableName}\` across in-memory cache and MongoDB Atlas:\n\n` +
          lines.join('\n')
        )
        .setFooter({ text: `${lines.length} fields defined • Read-Only Schema` });

      return message.reply({ embeds: [embed] });
    }

    // ─────────────────────────────────────────────────────────────
    // 9. READ-ONLY SQL QUERY (In-Memory SQLite)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'query' || sub === 'sql' || sub === 'exec') {
      const cleanArgs = args.filter(a => a !== '--server' && a !== '-s');
      const isServerTarget = args.includes('--server') || args.includes('-s');
      const targetDb = (isServerTarget && message.guild)
        ? getServerDb(message.guild.id)
        : getMasterDb();

      const sql = cleanArgs.slice(1).join(' ').trim();
      if (!sql) {
        return message.reply(`Usage: \`${prefix}db query <SQL>\` (e.g. \`${prefix}db query SELECT * FROM bot_owners\`)`);
      }

      const start = performance.now();
      try {
        const isSelect = /^\s*(SELECT|PRAGMA|EXPLAIN)\b/i.test(sql);
        if (!isSelect) {
          return message.reply('Security Notice: Only read-only queries (SELECT, PRAGMA, EXPLAIN) are permitted.');
        }

        const rows = targetDb.prepare(sql).all();
        const elapsed = (performance.now() - start).toFixed(2);
        const tableStr = formatAsciiTable(rows);

        if (tableStr.length > 1850) {
          const truncated = tableStr.slice(0, 1800);
          return message.reply(
            `**Query Executed** (${elapsed}ms) — Showing ${rows.length} row(s) [Truncated]:\n\`\`\`\n${truncated}\n\`\`\``
          );
        }

        return message.reply(
          `**Query Executed** (${elapsed}ms) — Returned ${rows.length} row(s):\n\`\`\`\n${tableStr}\n\`\`\``
        );
      } catch (err) {
        const elapsed = (performance.now() - start).toFixed(2);
        return message.reply(
          `**SQL Error** (${elapsed}ms):\n\`\`\`\n${err.message}\`\`\``
        );
      }
    }

    return message.reply(`Unknown subcommand. Use \`${prefix}db help\` for instructions.`);
  },

  async executeSlash(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({
        content: 'Access Denied: This command can be executed only by Bot Owner.',
        ephemeral: true
      });
    }

    const action = interaction.options.getString('action') || 'stats';
    const catOpt = interaction.options.getString('category') || 'all';
    await interaction.deferReply({ ephemeral: true });

    if (action === 'contents') {
      const payload = await buildContentsPayload(catOpt, 1);
      return interaction.editReply(payload);
    }

    // Default: stats
    try {
      let ping = { ok: false, latencyMs: 0 };
      let dbName = 'tungsten_bot';
      let masterDocs = 0;
      let guildDocs = 0;
      let totalServers = 0;
      let db = null;

      try {
        db = await ensureMongoDb();
        if (db) {
          ping = await pingMongo();
          dbName = db.databaseName;
          masterDocs = await db.collection('master_records').countDocuments().catch(() => 0);
          guildDocs = await db.collection('guild_records').countDocuments().catch(() => 0);
          const distinctGuilds = await db.collection('guild_records').distinct('guild_id').catch(() => []);
          totalServers = distinctGuilds.length;
        }
      } catch (_) {}

      const totalDocs = masterDocs + guildDocs;
      const storageStats = await getStorageStats(db);
      const quotaHeader = formatStorageQuotaBlock(storageStats);
      const clusterStatusText = ping.ok ? '🟢 Active & Connected' : '🔴 Standby / Reconnecting';

      const embed = createEmbed()
        .setTitle('📊 MongoDB Atlas & In-Memory SQLite Telemetry')
        .setDescription(
          `${quotaHeader}\n\n` +
          `**MongoDB Atlas Cloud Engine:**\n` +
          `• **Cluster Status:** ${clusterStatusText}\n` +
          `• **Roundtrip Latency:** \`${ping.latencyMs ? ping.latencyMs + 'ms' : 'N/A'}\`\n` +
          `• **Database Name:** \`${dbName}\`\n` +
          `• **Total Documents:** \`${totalDocs}\` (\`master_records\`: ${masterDocs}, \`guild_records\`: ${guildDocs})\n` +
          `• **Total Servers Created:** \`${totalServers}\` servers in cloud database\n` +
          `• **Collections & Indexes:** \`${storageStats.collections}\` collections • \`${storageStats.indexes}\` indexes\n` +
          `• **Cloud Architecture:** Consolidated 2-collection schema (BSON optimized)\n\n` +
          `**In-Memory SQLite Cache Engine:**\n` +
          `• **Local Disk Files:** \`0\` (Zero disk files, pure in-memory SQLite RAM cache)\n` +
          `• **Engine Mode:** In-Memory SQLite RAM Engine (No local file I/O)\n` +
          `• **Cloud Persistence:** Continuous replication and on-boot hydration active`
        );

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply(`Diagnostics Error: ${err.message}`);
    }
  }
};

module.exports.ensureMongoDb = ensureMongoDb;
module.exports.getStorageStats = getStorageStats;
module.exports.formatStorageQuotaBlock = formatStorageQuotaBlock;
module.exports.buildContentsPayload = buildContentsPayload;
module.exports.buildContentsEmbed = buildContentsEmbed;
module.exports.buildInspectPayload = buildInspectPayload;
module.exports.exportTableData = exportTableData;
module.exports.searchDatabase = searchDatabase;
module.exports.redactSensitive = redactSensitive;
module.exports.MASTER_TABLE_SCHEMAS = MASTER_TABLE_SCHEMAS;
module.exports.GUILD_TABLE_SCHEMAS = GUILD_TABLE_SCHEMAS;
