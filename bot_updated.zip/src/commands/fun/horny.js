/**
 * Horny Command (Node.js)
 * Calculates a member's horny rating percentage for the day.
 */
const { createRateCommand } = require('../../utils/rateHelper');
const { EMOJIS } = require('../../utils/emojis');

module.exports = createRateCommand({
  name: 'horny',
  aliases: ['hornyrate'],
  title: 'Horny Level Detector',
  type: 'horny',
  emoji: EMOJIS.SIREN,
  color: 0xE91E63,
  description: 'Detects the current horny level of yourself or another member.',
  getComment(score) {
    if (score < 25) return `Pure innocence! Pure thoughts only! ${EMOJIS.FACE_SMILE}`;
    if (score < 50) return `Mildly suspicious thoughts detected... ${EMOJIS.EYES}`;
    if (score < 80) return `BONK! Direct ticket to horny jail! ${EMOJIS.HAMMER}`;
    return `Critical horniness breach! Evacuate the channel! ${EMOJIS.SIREN} ${EMOJIS.EXPLOSION}`;
  }
});
