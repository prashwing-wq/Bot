/**
 * Tharki Command (Node.js)
 * Calculates a member's tharki rating percentage for the day.
 */
const { createRateCommand } = require('../../utils/rateHelper');
const { EMOJIS } = require('../../utils/emojis');

module.exports = createRateCommand({
  name: 'tharki',
  aliases: ['tharkirate'],
  title: 'Tharki Meter',
  type: 'tharki',
  emoji: EMOJIS.EYE,
  color: 0xF39C12,
  description: 'Calculates the tharki score of yourself or another member.',
  getComment(score) {
    if (score < 25) return `Saintly behavior, zero tharkipan found! ${EMOJIS.SHIELD}`;
    if (score < 50) return `Subtle flirting vibes spotted! ${EMOJIS.FACE_WINK}`;
    if (score < 80) return `Extreme sliding into DMs detected! ${EMOJIS.EYES}`;
    return `Ultra Pro Max Tharki! Keep away from group chats! ${EMOJIS.WARN} ${EMOJIS.FACE_LAUGH}`;
  }
});
