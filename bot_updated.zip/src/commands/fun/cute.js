/**
 * Cute Rate Command (Node.js)
 * Calculates a member's cuteness rating percentage for the day.
 */
const { createRateCommand } = require('../../utils/rateHelper');
const { EMOJIS } = require('../../utils/emojis');

module.exports = createRateCommand({
  name: 'cute',
  aliases: ['cuterate', 'cuteness'],
  title: 'Cuteness Meter',
  type: 'cute',
  emoji: EMOJIS.SPARKLE,
  color: 0xFF69B4,
  description: 'Calculates the cuteness score of yourself or another member.',
  getComment(score) {
    if (score < 25) return `Needs a little charm boost today! ${EMOJIS.UI_PLANT || EMOJIS.SPARKLE}`;
    if (score < 50) return `Pretty cute! Charming smile! ${EMOJIS.FACE_SMILE}`;
    if (score < 80) return `Adorable cinnamon roll! Must protect! ${EMOJIS.FACE_PLEADING}`;
    return `Astronomical cuteness overload! ${EMOJIS.HEART_SPARKLE} ${EMOJIS.SPARKLE}`;
  }
});
