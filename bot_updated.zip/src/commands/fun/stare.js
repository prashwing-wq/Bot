const { createRoleplayCommand } = require('./roleplay');
module.exports = createRoleplayCommand('stare');
