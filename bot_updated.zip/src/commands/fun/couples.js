/**
 * Tungsten Couples Leaderboard Command (Node.js)
 * Displays the longest-standing married couples in the server.
 */
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

module.exports = {
  name: 'couples',
  aliases: ['couple', 'marriages', 'married'],
  category: 'fun',
  description: 'View the longest-married couples leaderboard in the server.',
  usage: '[leaderboard]',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const guildId = message.guild?.id;
    if (!guildId) {
      return message.reply({ content: '<a:tungsten_close:1567234632905138206> Marriage commands can only be used inside a server.' });
    }

    const db = getServerDb(guildId);
    const marriages = db.prepare(`
      SELECT * FROM marriages
      WHERE guild_id = ?
      ORDER BY married_at ASC
      LIMIT 10
    `).all(String(guildId));

    if (!marriages || marriages.length === 0) {
      const p = prefix || '!';
      const emptyCard = createV2Card({
        title: '<a:tungsten_marriage:1569329446325063725>  Server Couples Leaderboard',
        color: config.COLORS?.PRIMARY || 0x2b2d31,
        description:
          `There are currently no married couples in **${message.guild.name}**!\n\n` +
          `Want to be the first? Propose to your partner with \`${p}marry @user\`!`,
        footerText: 'Tungsten Relationships'
      });
      return message.reply({ embeds: [emptyCard] });
    }

    const now = Date.now();
    const rows = marriages.map((m, i) => {
      const rank = i + 1;
      const medal = rank === 1 ? '<a:tungsten_medal_gold:1567241163453366472>' : rank === 2 ? '<a:tungsten_medal_silver:1567241205409128649>' : rank === 3 ? '<a:tungsten_medal_bronze:1567241129030582403>' : `\`#${rank}\``;
      const diffMs = Math.max(0, now - (m.married_at || now));
      const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const durationStr = days > 0 ? `${days} day${days === 1 ? '' : 's'}` : `${hours} hour${hours === 1 ? '' : 's'}`;
      const timestampSec = Math.floor(m.married_at / 1000);

      return `${medal} <@${m.user1_id}> ❤️ <@${m.user2_id}>\n` +
        `-# Married for **${durationStr}** • Since <t:${timestampSec}:D>`;
    }).join('\n\n');

    const card = createV2Card({
      title: `<a:tungsten_marriage:1569329446325063725>  ${message.guild.name} • Married Couples`,
      color: 0xEB459E,
      description: rows,
      footerText: 'Top 10 Longest Lasting Marriages'
    });

    return message.reply({ embeds: [card] });
  }
};
