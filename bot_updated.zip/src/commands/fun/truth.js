/**
 * Truth Command (Node.js)
 * Returns a fun, safe, and engaging truth question from a curated registry of 35+ questions.
 */
const { createEmbed } = require('../../utils/tools');

const TRUTH_QUESTIONS = [
  'What is the most embarrassing thing you have ever done in a voice call?',
  'If you could swap lives with anyone in this server for 24 hours, who would it be?',
  'What is the weirdest habit you have when you are completely alone?',
  'Have you ever sent a text to the wrong person and panicked? What was it?',
  'What is the most childish thing that you still do regularly?',
  'If you were forced to delete all your social media apps except one, which one would you keep?',
  'What is a secret talent or hobby that nobody in this server knows about?',
  'Have you ever laughed so hard that you cried or choked on whatever you were drinking?',
  'What is the most ridiculous lie you told that someone actually believed?',
  'What is your biggest irrational fear?',
  'If you had to eat only one meal for the rest of your life, what would it be?',
  'What is the cringiest username or nickname you ever had online?',
  'Have you ever pretended to be sick to avoid hanging out or attending an event?',
  'What is the most useless piece of trivia that you know by heart?',
  'If your search history from the past 7 days was read aloud, how embarrassed would you be on a scale of 1-10?',
  'What is something you bought that was a total waste of money, but you still keep?',
  'Have you ever practiced an argument in the shower and still lost it in your head?',
  'What movie or show can you watch a hundred times without getting bored?',
  'If you could instantly master one musical instrument, what would you pick?',
  'Have you ever ghosted someone because you were simply too tired or lazy to reply?',
  'What is the weirdest food combination that you secretly enjoy?',
  'What song do you sing at the top of your lungs when nobody is listening?',
  'If you had a time machine, would you travel 100 years into the past or the future?',
  'What is the longest time you have ever stayed awake in a single stretch?',
  'Have you ever tripped or fallen in public and pretended like you meant to do that?',
  'If you could have any fictional creature as a companion, which one would you choose?',
  'What is the strangest dream you remember having recently?',
  'Have you ever accidentally liked a years-old photo while browsing someone’s profile?',
  'What is your ultimate go-to comfort food when having a long day?',
  'If you woke up tomorrow with superpowers, would you be a heroic defender or a chaotic trickster?',
  'What is one trend from the past that makes you cringe when you look back?',
  'What is the silliest reason you have ever gotten genuinely annoyed over?',
  'Who was your very first fictional character crush?',
  'If you could rename this Discord server right now, what hilarious name would you choose?',
  'What is something you are surprisingly terrible at despite practicing?'
];

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'truth',
  aliases: ['truthquestion', 'tordtruth'],
  category: 'fun',
  description: 'Picks a fun, safe, and engaging truth question.',
  usage: '',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    const question = TRUTH_QUESTIONS[Math.floor(Math.random() * TRUTH_QUESTIONS.length)];

    const embed = createEmbed({
      color: 0x3498DB,
      title: '🤔  Truth Question',
      description: `> **"${question}"**`,
      footer: `Requested by ${message.author.tag} • Answer honestly!`
    });

    return message.reply({ embeds: [embed] });
  }
};
