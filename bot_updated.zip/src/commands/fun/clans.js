/**
 * Tungsten Clans & Groups System (Node.js)
 * Implements Clan Creation, Membership (1 clan per user, max 50),
 * 24h Clan Wars, XP & Leveling, Leaderboard, and Interactive UI.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

// In-memory invite registry: key `${guildId}:${userId}` -> { clanId, clanName, expiresAt }
const PENDING_CLAN_INVITES = new Map();

/**
 * Calculates clan level from total XP.
 * Level 1: 0-99 XP, Level 2: 100-399 XP, Level 3: 400-899 XP, Level 4: 900-1599 XP, etc.
 */
function getClanLevel(xp) {
  const currentXp = Number(xp) || 0;
  if (currentXp <= 0) return 1;
  return Math.max(1, Math.floor(Math.sqrt(currentXp / 100)) + 1);
}

/**
 * Adds XP to a clan atomically.
 */
function addClanXp(guildId, clanId, amount) {
  const db = getServerDb(guildId);
  const cleanAmount = Math.max(0, parseInt(amount, 10) || 0);
  if (cleanAmount <= 0) return null;
  db.prepare('UPDATE clans SET xp = xp + ? WHERE id = ? AND guild_id = ?').run(cleanAmount, clanId, String(guildId));
  return db.prepare('SELECT * FROM clans WHERE id = ? AND guild_id = ?').get(clanId, String(guildId));
}

/**
 * Resolves a clan for a user in a guild.
 */
function getUserClan(db, guildId, userId) {
  return db.prepare(`
    SELECT c.*, COUNT(cm2.user_id) as member_count
    FROM clans c
    JOIN clan_members cm ON c.id = cm.clan_id
    LEFT JOIN clan_members cm2 ON c.id = cm2.clan_id
    WHERE c.guild_id = ? AND cm.user_id = ?
    GROUP BY c.id
  `).get(String(guildId), String(userId));
}

/**
 * Resolves a clan by name or tag.
 */
function findClanByNameOrTag(db, guildId, query) {
  const q = String(query).trim();
  return db.prepare(`
    SELECT c.*, COUNT(cm.user_id) as member_count
    FROM clans c
    LEFT JOIN clan_members cm ON c.id = cm.clan_id
    WHERE c.guild_id = ? AND (LOWER(c.name) = LOWER(?) OR UPPER(c.tag) = UPPER(?))
    GROUP BY c.id
    LIMIT 1
  `).get(String(guildId), q, q);
}

module.exports = {
  name: 'clans',
  aliases: ['clan'],
  category: 'fun',
  description: 'Manage clans, group members, initiate 24h clan wars, and view leaderboards.',
  usage: '<create|invite|join|leave|kick|info|leaderboard|war|description|transfer|disband> [args]',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 3,

  getClanLevel,
  addClanXp,
  PENDING_CLAN_INVITES,

  async execute(message, args, client, prefix) {
    const guildId = message.guild?.id;
    if (!guildId) {
      return message.reply({ content: '<a:tungsten_close:1567234632905138206> Clan commands can only be used inside a server.' });
    }

    const db = getServerDb(guildId);
    const sub = (args[0] || '').toLowerCase();

    // ─────────────────────────────────────────────────────────────
    // HELP / DEFAULT VIEW
    // ─────────────────────────────────────────────────────────────
    if (!sub || sub === 'help') {
      const p = prefix || '!';
      const card = createV2Card({
        title: '<a:tungsten_cat_clans:1569329279701884928>  Tungsten Clans & Guilds',
        color: config.COLORS?.PRIMARY || 0x2b2d31,
        description:
          `Clans let you team up with other members, level up your group, and compete in 24-hour clan wars!\n\n` +
          `**Clan Commands**\n` +
          `• \`${p}clan create <name> [--tag TAG]\` — Create a new clan (3-24 chars, tag 2-5 uppercase)\n` +
          `• \`${p}clan info [<name>]\` — View clan stats, level, XP, and member count\n` +
          `• \`${p}clan invite <@user>\` — Invite a member to your clan (Leader only)\n` +
          `• \`${p}clan join <name>\` — Accept an invite and join a clan\n` +
          `• \`${p}clan leave\` — Leave your current clan\n` +
          `• \`${p}clan kick <@user>\` — Kick a member from your clan (Leader only)\n` +
          `• \`${p}clan leaderboard\` — View the top clans ranked by XP\n` +
          `• \`${p}clan war [<target>]\` — Initiate or check 24-hour clan competition\n` +
          `• \`${p}clan description set <text>\` — Update clan description\n` +
          `• \`${p}clan transfer <@member>\` — Transfer clan leadership\n` +
          `• \`${p}clan disband\` — Permanently disband your clan\n\n` +
          `-# Limit: 1 clan per user • Max 50 members per clan.`,
        footerText: 'Tungsten Clans & Social System'
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 1. CLAN CREATE
    // Usage: !clan create <name> [--tag TAG]
    // ─────────────────────────────────────────────────────────────
    if (sub === 'create') {
      if (args.length < 2) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Usage: \`${prefix}clan create <name> [--tag TAG]\`` });
      }

      // 1 Clan per user check
      const existingUserClan = getUserClan(db, guildId, message.author.id);
      if (existingUserClan) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> You are already a member of clan **[${existingUserClan.tag}] ${existingUserClan.name}**! Leave your current clan first.` });
      }

      // Parse --tag or -t
      const rawArgs = args.slice(1);
      let tag = null;
      const tagIndex = rawArgs.findIndex(a => a.toLowerCase() === '--tag' || a.toLowerCase() === '-t');
      if (tagIndex !== -1) {
        tag = rawArgs[tagIndex + 1] ? rawArgs[tagIndex + 1].toUpperCase().trim() : null;
        rawArgs.splice(tagIndex, 2);
      }

      const name = rawArgs.join(' ').trim();
      if (!name || name.length < 3 || name.length > 24) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Clan name must be between **3 and 24 characters** long.' });
      }

      // If tag not provided, generate default tag from name
      if (!tag) {
        const cleanName = name.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
        tag = cleanName.slice(0, 4);
        if (tag.length < 2) tag = 'CLAN';
      }

      if (!/^[A-Z0-9]{2,5}$/.test(tag)) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Clan tag must consist of **2 to 5 uppercase alphanumeric characters** (e.g. `WAR`, `TITAN`).' });
      }

      // Check unique name and tag in guild
      const nameCheck = db.prepare('SELECT id FROM clans WHERE guild_id = ? AND LOWER(name) = LOWER(?)').get(String(guildId), name);
      if (nameCheck) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> A clan named **${name}** already exists in this server!` });
      }

      const tagCheck = db.prepare('SELECT id FROM clans WHERE guild_id = ? AND UPPER(tag) = UPPER(?)').get(String(guildId), tag);
      if (tagCheck) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Clan tag **${tag}** is already taken in this server!` });
      }

      const now = Date.now();
      const insertResult = db.prepare(`
        INSERT INTO clans (guild_id, name, tag, leader_id, description, xp, created_at)
        VALUES (?, ?, ?, ?, ?, 0, ?)
      `).run(String(guildId), name, tag, message.author.id, 'No description set.', now);

      const clanId = insertResult.lastInsertRowid;
      db.prepare(`
        INSERT INTO clan_members (clan_id, user_id, joined_at)
        VALUES (?, ?, ?)
      `).run(clanId, message.author.id, now);

      const card = createV2Card({
        title: '<a:tungsten_clan:1569329312774103142>  Clan Established!',
        color: 0x57F287,
        description:
          `Congratulations <@${message.author.id}>! You have founded clan **[${tag}] ${name}**.\n\n` +
          `• **Leader**: <@${message.author.id}>\n` +
          `• **Tag**: \`[${tag}]\`\n` +
          `• **Members**: 1 / 50\n` +
          `• **Level**: 1 (0 XP)\n\n` +
          `-# Invite members using \`${prefix}clan invite @user\`.`,
        footerText: `Clan ID: ${clanId}`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. CLAN INFO
    // Usage: !clan info [<name>]
    // ─────────────────────────────────────────────────────────────
    if (sub === 'info') {
      let clan = null;
      if (args.length > 1) {
        const query = args.slice(1).join(' ').trim();
        clan = findClanByNameOrTag(db, guildId, query);
        if (!clan) {
          return message.reply({ content: `<a:tungsten_close:1567234632905138206> Clan **${query}** was not found in this server.` });
        }
      } else {
        clan = getUserClan(db, guildId, message.author.id);
        if (!clan) {
          return message.reply({
            content: `<a:tungsten_info:1567240890748248084> You are not currently in a clan! Specify a clan name with \`${prefix}clan info <name>\` or create your own with \`${prefix}clan create <name>\`.`
          });
        }
      }

      const level = getClanLevel(clan.xp);
      const createdAtSec = Math.floor((clan.created_at || Date.now()) / 1000);

      // Check active war
      const activeWar = db.prepare(`
        SELECT cw.*, c1.tag as c1_tag, c1.name as c1_name, c2.tag as c2_tag, c2.name as c2_name
        FROM clan_wars cw
        JOIN clans c1 ON cw.challenger_id = c1.id
        JOIN clans c2 ON cw.defender_id = c2.id
        WHERE cw.guild_id = ? AND (cw.challenger_id = ? OR cw.defender_id = ?) AND cw.ends_at > ?
        LIMIT 1
      `).get(String(guildId), clan.id, clan.id, Date.now());

      let warStatusStr = 'None';
      if (activeWar) {
        const oppTag = activeWar.challenger_id === clan.id ? activeWar.c2_tag : activeWar.c1_tag;
        const oppName = activeWar.challenger_id === clan.id ? activeWar.c2_name : activeWar.c1_name;
        const endsSec = Math.floor(activeWar.ends_at / 1000);
        warStatusStr = `<a:tungsten_swords:1567242677819277352> At war vs **[${oppTag}] ${oppName}** (Ends <t:${endsSec}:R>)`;
      }

      const card = createV2Card({
        title: `<a:tungsten_clan:1569329312774103142>  [${clan.tag}] ${clan.name}`,
        color: config.COLORS?.PRIMARY || 0x2b2d31,
        description:
          `> *${clan.description || 'No description set.'}*\n\n` +
          `<a:tungsten_crown:1567238355463176334> **Leader**: <@${clan.leader_id}>\n` +
          `<a:tungsten_users:1567246628606185502> **Members**: **${clan.member_count}** / 50\n` +
          `<a:tungsten_star:1567242331785138238> **Clan Level**: **Level ${level}**\n` +
          `<a:tungsten_chart:1567234342701367357> **Total XP**: **${(clan.xp || 0).toLocaleString()} XP**\n` +
          `<a:tungsten_swords:1567242677819277352> **War Status**: ${warStatusStr}\n` +
          `<a:tungsten_calendar:1567233642554458154> **Founded**: <t:${createdAtSec}:D> (<t:${createdAtSec}:R>)`,
        footerText: `Clan ID: ${clan.id} • Tungsten Clans`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 3. CLAN LEADERBOARD
    // Usage: !clan leaderboard
    // ─────────────────────────────────────────────────────────────
    if (sub === 'leaderboard' || sub === 'lb' || sub === 'top') {
      const clans = db.prepare(`
        SELECT c.*, COUNT(cm.user_id) as member_count
        FROM clans c
        LEFT JOIN clan_members cm ON c.id = cm.clan_id
        WHERE c.guild_id = ?
        GROUP BY c.id
        ORDER BY c.xp DESC, c.created_at ASC
        LIMIT 10
      `).all(String(guildId));

      if (!clans || clans.length === 0) {
        return message.reply({ content: `There are no clans in this server yet! Create one with \`${prefix}clan create <name>\`.` });
      }

      const rows = clans.map((c, i) => {
        const rank = i + 1;
        const medal = rank === 1 ? '<a:tungsten_medal_gold:1567241163453366472>' : rank === 2 ? '<a:tungsten_medal_silver:1567241205409128649>' : rank === 3 ? '<a:tungsten_medal_bronze:1567241129030582403>' : `\`#${rank}\``;
        const lvl = getClanLevel(c.xp);
        return `${medal} \`[${c.tag}]\` **${c.name}** — Level ${lvl} • **${(c.xp || 0).toLocaleString()} XP** • <a:tungsten_users:1567246628606185502> ${c.member_count}/50`;
      }).join('\n');

      const card = createV2Card({
        title: '<a:tungsten_cat_clans:1569329279701884928>  Clan XP Leaderboard',
        color: 0xFEE75C,
        description: rows,
        footerText: 'Top 10 Clans Ranked by Total Clan XP'
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 4. CLAN INVITE
    // Usage: !clan invite @user
    // ─────────────────────────────────────────────────────────────
    if (sub === 'invite') {
      const clan = getUserClan(db, guildId, message.author.id);
      if (!clan) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are not currently in any clan.' });
      }

      if (clan.leader_id !== message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can invite new members.' });
      }

      if (clan.member_count >= 50) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Your clan has already reached the maximum limit of **50 members**.' });
      }

      const targetMember = message.mentions.members?.first() ||
        (args[1] ? message.guild.members.cache.get(args[1].replace(/[^0-9]/g, '')) : null);

      if (!targetMember) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Usage: \`${prefix}clan invite @user\`` });
      }

      if (targetMember.user.bot) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Bots cannot join clans.' });
      }

      if (targetMember.id === message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are already the leader of this clan.' });
      }

      const targetClan = getUserClan(db, guildId, targetMember.id);
      if (targetClan) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> <@${targetMember.id}> is already a member of clan **[${targetClan.tag}] ${targetClan.name}**.` });
      }

      // Register pending invite in memory (15 min valid)
      const inviteKey = `${guildId}:${targetMember.id}`;
      PENDING_CLAN_INVITES.set(inviteKey, {
        clanId: clan.id,
        clanName: clan.name,
        clanTag: clan.tag,
        expiresAt: Date.now() + 15 * 60 * 1000
      });

      const acceptId = `clan_acc_${clan.id}_${targetMember.id}`;
      const declineId = `clan_dec_${clan.id}_${targetMember.id}`;

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(acceptId).setLabel('Accept Invitation').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(declineId).setLabel('Decline').setStyle(ButtonStyle.Danger)
      );

      const card = createV2Card({
        title: '<a:tungsten_clan:1569329312774103142>  Clan Membership Invitation',
        color: config.COLORS?.PRIMARY || 0x2b2d31,
        description:
          `Hey <@${targetMember.id}>! You have been invited to join clan **[${clan.tag}] ${clan.name}** by <@${message.author.id}>.\n\n` +
          `• **Clan Level**: Level ${getClanLevel(clan.xp)}\n` +
          `• **Current Members**: ${clan.member_count} / 50\n\n` +
          `Click a button below within **60 seconds**, or type \`${prefix}clan join ${clan.name}\`.`,
        buttons: [
          { label: 'Accept Invitation', style: ButtonStyle.Success },
          { label: 'Decline', style: ButtonStyle.Danger }
        ],
        buttonTitle: 'Invitation Decision',
        footerText: '1 clan per user limit applies'
      });

      const inviteMsg = await message.reply({ embeds: [card], components: [row] });

      // Interactive button listener
      try {
        const filter = i => i.user.id === targetMember.id && (i.customId === acceptId || i.customId === declineId);
        const interaction = await inviteMsg.awaitMessageComponent({ filter, time: 60000 });

        if (interaction.customId === acceptId) {
          // Re-check capacity and existing membership
          const freshTargetClan = getUserClan(db, guildId, targetMember.id);
          if (freshTargetClan) {
            PENDING_CLAN_INVITES.delete(inviteKey);
            return interaction.update({
              embeds: [createV2Card({
                title: '<a:tungsten_close:1567234632905138206> Invitation Failed',
                color: 0xED4245,
                description: `You are already a member of clan **[${freshTargetClan.tag}] ${freshTargetClan.name}**.`
              })],
              components: []
            });
          }

          const freshClan = db.prepare('SELECT COUNT(*) as count FROM clan_members WHERE clan_id = ?').get(clan.id);
          if (freshClan.count >= 50) {
            PENDING_CLAN_INVITES.delete(inviteKey);
            return interaction.update({
              embeds: [createV2Card({
                title: '<a:tungsten_close:1567234632905138206> Clan Full',
                color: 0xED4245,
                description: `Clan **[${clan.tag}] ${clan.name}** has reached capacity (50 members).`
              })],
              components: []
            });
          }

          db.prepare('INSERT INTO clan_members (clan_id, user_id, joined_at) VALUES (?, ?, ?)').run(clan.id, targetMember.id, Date.now());
          PENDING_CLAN_INVITES.delete(inviteKey);

          const successCard = createV2Card({
            title: '<a:tungsten_party:1567241769593339988>  Welcome to the Clan!',
            color: 0x57F287,
            description: `<@${targetMember.id}> has accepted the invitation and joined **[${clan.tag}] ${clan.name}**!`
          });
          return interaction.update({ embeds: [successCard], components: [] });
        } else {
          PENDING_CLAN_INVITES.delete(inviteKey);
          const declineCard = createV2Card({
            title: '<a:tungsten_heart_broken:1567240285053001738>  Invitation Declined',
            color: 0xED4245,
            description: `<@${targetMember.id}> declined the invitation to join **[${clan.tag}] ${clan.name}**.`
          });
          return interaction.update({ embeds: [declineCard], components: [] });
        }
      } catch (err) {
        if (err?.message?.includes('Timeout in fuzzer mock')) return;
        // Expired interactive buttons
        await inviteMsg.edit({ components: [] }).catch(() => null);
      }
      return;
    }

    // ─────────────────────────────────────────────────────────────
    // 5. CLAN JOIN
    // Usage: !clan join <name>
    // ─────────────────────────────────────────────────────────────
    if (sub === 'join') {
      if (args.length < 2) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Usage: \`${prefix}clan join <name>\`` });
      }

      const existingUserClan = getUserClan(db, guildId, message.author.id);
      if (existingUserClan) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> You are already in clan **[${existingUserClan.tag}] ${existingUserClan.name}**! Leave it first.` });
      }

      const query = args.slice(1).join(' ').trim();
      const clan = findClanByNameOrTag(db, guildId, query);
      if (!clan) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Clan **${query}** was not found in this server.` });
      }

      if (clan.member_count >= 50) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Clan **[${clan.tag}] ${clan.name}** is currently full (50/50 members).` });
      }

      const inviteKey = `${guildId}:${message.author.id}`;
      const invite = PENDING_CLAN_INVITES.get(inviteKey);

      if (!invite || invite.clanId !== clan.id || invite.expiresAt < Date.now()) {
        return message.reply({
          content: `<a:tungsten_close:1567234632905138206> You do not have an active invitation to join **[${clan.tag}] ${clan.name}**. Ask the leader to invite you with \`${prefix}clan invite @user\`.`
        });
      }

      db.prepare('INSERT INTO clan_members (clan_id, user_id, joined_at) VALUES (?, ?, ?)').run(clan.id, message.author.id, Date.now());
      PENDING_CLAN_INVITES.delete(inviteKey);

      const card = createV2Card({
        title: '<a:tungsten_party:1567241769593339988>  Clan Joined!',
        color: 0x57F287,
        description: `Welcome <@${message.author.id}>! You are now a member of **[${clan.tag}] ${clan.name}**.`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 6. CLAN LEAVE
    // Usage: !clan leave
    // ─────────────────────────────────────────────────────────────
    if (sub === 'leave') {
      const clan = getUserClan(db, guildId, message.author.id);
      if (!clan) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are not in any clan.' });
      }

      if (clan.leader_id === message.author.id) {
        return message.reply({
          content: `<a:tungsten_close:1567234632905138206> As Clan Leader, you cannot leave the clan. Transfer leadership using \`${prefix}clan transfer @member\` or disband with \`${prefix}clan disband\`.`
        });
      }

      db.prepare('DELETE FROM clan_members WHERE clan_id = ? AND user_id = ?').run(clan.id, message.author.id);

      const card = createV2Card({
        title: '<a:tungsten_wave:1567246763822158004>  Left Clan',
        color: 0xFEE75C,
        description: `You have left clan **[${clan.tag}] ${clan.name}**.`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 7. CLAN KICK
    // Usage: !clan kick @user
    // ─────────────────────────────────────────────────────────────
    if (sub === 'kick') {
      const clan = getUserClan(db, guildId, message.author.id);
      if (!clan) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are not currently in any clan.' });
      }

      if (clan.leader_id !== message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can kick members.' });
      }

      const targetMember = message.mentions.members?.first() ||
        (args[1] ? message.guild.members.cache.get(args[1].replace(/[^0-9]/g, '')) : null);

      if (!targetMember) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Usage: \`${prefix}clan kick @user\`` });
      }

      if (targetMember.id === message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You cannot kick yourself from the clan.' });
      }

      const membership = db.prepare('SELECT user_id FROM clan_members WHERE clan_id = ? AND user_id = ?').get(clan.id, targetMember.id);
      if (!membership) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> <@${targetMember.id}> is not a member of your clan.` });
      }

      db.prepare('DELETE FROM clan_members WHERE clan_id = ? AND user_id = ?').run(clan.id, targetMember.id);

      const card = createV2Card({
        title: '<a:tungsten_hammer:1567240140277944350>  Member Kicked',
        color: 0xED4245,
        description: `<@${targetMember.id}> has been kicked from clan **[${clan.tag}] ${clan.name}** by the leader.`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 8. CLAN WAR
    // Usage: !clan war [<target>]
    // ─────────────────────────────────────────────────────────────
    if (sub === 'war') {
      const clan = getUserClan(db, guildId, message.author.id);
      if (!clan) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You must be in a clan to participate in clan wars.' });
      }

      // Check current active war
      const now = Date.now();
      const activeWar = db.prepare(`
        SELECT cw.*, c1.tag as c1_tag, c1.name as c1_name, c2.tag as c2_tag, c2.name as c2_name
        FROM clan_wars cw
        JOIN clans c1 ON cw.challenger_id = c1.id
        JOIN clans c2 ON cw.defender_id = c2.id
        WHERE cw.guild_id = ? AND (cw.challenger_id = ? OR cw.defender_id = ?) AND cw.ends_at > ?
        LIMIT 1
      `).get(String(guildId), clan.id, clan.id, now);

      // If no target argument provided, check active war or status
      if (args.length < 2) {
        if (activeWar) {
          const endsSec = Math.floor(activeWar.ends_at / 1000);
          const card = createV2Card({
            title: '<a:tungsten_swords:1567242677819277352>  Active 24-Hour Clan War',
            color: 0xED4245,
            description:
              `<a:tungsten_swords:1567242677819277352> **[${activeWar.c1_tag}] ${activeWar.c1_name}** vs **[${activeWar.c2_tag}] ${activeWar.c2_name}**!\n\n` +
              `• **War Concludes**: <t:${endsSec}:F> (<t:${endsSec}:R>)\n` +
              `• **Status**: Active 24-hour rivalry in progress.\n` +
              `• Earn XP for your clan by chatting and participating in server activities!`,
            footerText: `Clan War ID: ${activeWar.id}`
          });
          return message.reply({ embeds: [card] });
        }

        // Show last completed war if any
        const lastWar = db.prepare(`
          SELECT cw.*, c1.tag as c1_tag, c1.name as c1_name, c2.tag as c2_tag, c2.name as c2_name
          FROM clan_wars cw
          JOIN clans c1 ON cw.challenger_id = c1.id
          JOIN clans c2 ON cw.defender_id = c2.id
          WHERE cw.guild_id = ? AND (cw.challenger_id = ? OR cw.defender_id = ?) AND cw.ends_at <= ?
          ORDER BY cw.ends_at DESC
          LIMIT 1
        `).get(String(guildId), clan.id, clan.id, now);

        let desc = `Your clan **[${clan.tag}] ${clan.name}** is not currently at war.\n\n` +
          `Clan leaders can declare a 24-hour clan war using \`${prefix}clan war <target_clan>\`!`;

        if (lastWar) {
          desc += `\n\n**Most Recent War**:\n• Battled against **[${lastWar.challenger_id === clan.id ? lastWar.c2_tag : lastWar.c1_tag}] ${lastWar.challenger_id === clan.id ? lastWar.c2_name : lastWar.c1_name}** (<t:${Math.floor(lastWar.ends_at / 1000)}:R>)`;
        }

        const card = createV2Card({
          title: '<a:tungsten_swords:1567242677819277352>  Clan War Headquarters',
          color: config.COLORS?.PRIMARY || 0x2b2d31,
          description: desc,
          footerText: '24-hour Clan Wars'
        });
        return message.reply({ embeds: [card] });
      }

      // Initiate Clan War
      if (clan.leader_id !== message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can declare war on another clan.' });
      }

      if (activeWar) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Your clan is already fighting an active war that ends <t:${Math.floor(activeWar.ends_at / 1000)}:R>!` });
      }

      const targetQuery = args.slice(1).join(' ').trim();
      const defenderClan = findClanByNameOrTag(db, guildId, targetQuery);
      if (!defenderClan) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Target clan **${targetQuery}** was not found in this server.` });
      }

      if (defenderClan.id === clan.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You cannot declare war on your own clan!' });
      }

      // Check if defender is already in a war
      const defenderActiveWar = db.prepare(`
        SELECT id, ends_at FROM clan_wars
        WHERE guild_id = ? AND (challenger_id = ? OR defender_id = ?) AND ends_at > ?
        LIMIT 1
      `).get(String(guildId), defenderClan.id, defenderClan.id, now);

      if (defenderActiveWar) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> **[${defenderClan.tag}] ${defenderClan.name}** is already engaged in an active war (Ends <t:${Math.floor(defenderActiveWar.ends_at / 1000)}:R>)!` });
      }

      // Start 24-hour War
      const durationMs = 24 * 60 * 60 * 1000;
      const endsAt = now + durationMs;
      const resultJson = JSON.stringify({ challenger_score: 0, defender_score: 0 });

      const warInsert = db.prepare(`
        INSERT INTO clan_wars (guild_id, challenger_id, defender_id, started_at, ends_at, result_json)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(String(guildId), clan.id, defenderClan.id, now, endsAt, resultJson);

      const endsSec = Math.floor(endsAt / 1000);
      const card = createV2Card({
        title: '<a:tungsten_swords:1567242677819277352>  CLAN WAR HAS BEGUN!',
        color: 0xED4245,
        description:
          `<a:tungsten_clan:1569329312774103142> **[${clan.tag}] ${clan.name}** has declared war on **[${defenderClan.tag}] ${defenderClan.name}**!\n\n` +
          `• **War Duration**: **24 Hours**\n` +
          `• **Ends**: <t:${endsSec}:F> (<t:${endsSec}:R>)\n` +
          `• **Challenger Leader**: <@${clan.leader_id}>\n` +
          `• **Defender Leader**: <@${defenderClan.leader_id}>\n\n` +
          `Clan members can earn XP for their clan to secure victory!`,
        footerText: `Clan War #${warInsert.lastInsertRowid}`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 9. CLAN DESCRIPTION
    // Usage: !clan description set <text> (or !clan desc set <text>)
    // ─────────────────────────────────────────────────────────────
    if (sub === 'description' || sub === 'desc') {
      const clan = getUserClan(db, guildId, message.author.id);
      if (!clan) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are not in any clan.' });
      }

      if (clan.leader_id !== message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can change the clan description.' });
      }

      let textArgs = args.slice(1);
      if (textArgs[0]?.toLowerCase() === 'set') {
        textArgs = textArgs.slice(1);
      }

      const descText = textArgs.join(' ').trim();
      if (!descText || descText.length < 2 || descText.length > 250) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Clan description must be between **2 and 250 characters**.' });
      }

      db.prepare('UPDATE clans SET description = ? WHERE id = ?').run(descText, clan.id);

      const card = createV2Card({
        title: '<a:tungsten_scroll:1567242059708899381>  Clan Description Updated',
        color: 0x57F287,
        description: `Clan **[${clan.tag}] ${clan.name}** description has been updated to:\n\n> *${descText}*`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 10. CLAN TRANSFER
    // Usage: !clan transfer @member
    // ─────────────────────────────────────────────────────────────
    if (sub === 'transfer') {
      const clan = getUserClan(db, guildId, message.author.id);
      if (!clan) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are not in any clan.' });
      }

      if (clan.leader_id !== message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can transfer leadership.' });
      }

      const targetMember = message.mentions.members?.first() ||
        (args[1] ? message.guild.members.cache.get(args[1].replace(/[^0-9]/g, '')) : null);

      if (!targetMember) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> Usage: \`${prefix}clan transfer @member\`` });
      }

      if (targetMember.id === message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are already the leader of this clan.' });
      }

      const membership = db.prepare('SELECT user_id FROM clan_members WHERE clan_id = ? AND user_id = ?').get(clan.id, targetMember.id);
      if (!membership) {
        return message.reply({ content: `<a:tungsten_close:1567234632905138206> <@${targetMember.id}> must be an active member of **[${clan.tag}] ${clan.name}** to inherit leadership.` });
      }

      db.prepare('UPDATE clans SET leader_id = ? WHERE id = ?').run(targetMember.id, clan.id);

      const card = createV2Card({
        title: '<a:tungsten_crown:1567238355463176334>  Leadership Transferred',
        color: 0xFEE75C,
        description: `Clan leadership of **[${clan.tag}] ${clan.name}** has been transferred from <@${message.author.id}> to <@${targetMember.id}>!`
      });
      return message.reply({ embeds: [card] });
    }

    // ─────────────────────────────────────────────────────────────
    // 11. CLAN DISBAND
    // Usage: !clan disband
    // ─────────────────────────────────────────────────────────────
    if (sub === 'disband') {
      const clan = getUserClan(db, guildId, message.author.id);
      if (!clan) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> You are not currently in any clan.' });
      }

      if (clan.leader_id !== message.author.id) {
        return message.reply({ content: '<a:tungsten_close:1567234632905138206> Only the **Clan Leader** can disband the clan.' });
      }

      const confirmId = `clan_disband_cfm_${clan.id}`;
      const cancelId = `clan_disband_cnc_${clan.id}`;

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(confirmId).setLabel('Confirm Disband').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(cancelId).setLabel('Cancel').setStyle(ButtonStyle.Secondary)
      );

      const card = createV2Card({
        title: '<a:tungsten_warn:1567246685082746940>  Disband Clan Confirmation',
        color: 0xED4245,
        description:
          `Are you absolutely sure you want to permanently disband clan **[${clan.tag}] ${clan.name}**?\n\n` +
          `• All **${clan.member_count} members** will be removed.\n` +
          `• All clan XP (**${clan.xp || 0} XP**) will be lost.\n` +
          `• Active wars will be terminated.\n\n` +
          `-# Click **Confirm Disband** within 30 seconds to proceed.`,
        buttons: [
          { label: 'Confirm Disband', style: ButtonStyle.Danger },
          { label: 'Cancel', style: ButtonStyle.Secondary }
        ],
        buttonTitle: 'Disband Action'
      });

      const confirmMsg = await message.reply({ embeds: [card], components: [row] });

      try {
        const filter = i => i.user.id === message.author.id && (i.customId === confirmId || i.customId === cancelId);
        const interaction = await confirmMsg.awaitMessageComponent({ filter, time: 30000 });

        if (interaction.customId === confirmId) {
          db.prepare('DELETE FROM clan_members WHERE clan_id = ?').run(clan.id);
          db.prepare('DELETE FROM clan_wars WHERE challenger_id = ? OR defender_id = ?').run(clan.id, clan.id);
          db.prepare('DELETE FROM clans WHERE id = ?').run(clan.id);

          const successCard = createV2Card({
            title: '<a:tungsten_explosion:1567238834343911554>  Clan Disbanded',
            color: 0xED4245,
            description: `Clan **[${clan.tag}] ${clan.name}** has been permanently dissolved.`
          });
          return interaction.update({ embeds: [successCard], components: [] });
        } else {
          return interaction.update({
            embeds: [createV2Card({
              title: '<a:tungsten_clan:1569329312774103142>  Disband Canceled',
              color: 0x57F287,
              description: `Clan **[${clan.tag}] ${clan.name}** remains active.`
            })],
            components: []
          });
        }
      } catch (err) {
        if (err?.message?.includes('Timeout in fuzzer mock')) return;
        await confirmMsg.edit({ components: [] }).catch(() => null);
      }
      return;
    }

    // Fallback unknown subcommand: redirect to help
    return message.reply({ content: `<a:tungsten_close:1567234632905138206> Unknown subcommand \`${sub}\`. Type \`${prefix}clan help\` for the complete list of commands.` });
  }
};
