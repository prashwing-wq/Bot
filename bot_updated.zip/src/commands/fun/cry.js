const { createRoleplayCommand } = require('./roleplay');
module.exports = createRoleplayCommand('cry');
