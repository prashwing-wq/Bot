const { createRoleplayCommand } = require('./roleplay');
module.exports = createRoleplayCommand('poke');
