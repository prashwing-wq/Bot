const { createRoleplayCommand } = require('./roleplay');
module.exports = createRoleplayCommand('kiss');
