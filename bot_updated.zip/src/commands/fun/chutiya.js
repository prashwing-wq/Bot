/**
 * Chutiya Command (Node.js)
 * Calculates a member's chutiya rating percentage for the day.
 */
const { createRateCommand } = require('../../utils/rateHelper');
const { EMOJIS } = require('../../utils/emojis');

module.exports = createRateCommand({
  name: 'chutiya',
  aliases: ['chutiyarate'],
  title: 'Chutiya Meter',
  type: 'chutiya',
  emoji: EMOJIS.PARTY,
  color: 0xE74C3C,
  description: 'Calculates the chutiya rating for yourself or another member.',
  getComment(score) {
    if (score < 25) return `Surprisingly sensible and sorted! ${EMOJIS.FACE_COOL}`;
    if (score < 50) return `Occasional goofy moments detected! ${EMOJIS.FACE_CRAZY}`;
    if (score < 80) return `High-grade certified chutiya vibes! ${EMOJIS.DRAMA}`;
    return `Maha Chutiya of the Year award winner! ${EMOJIS.TROPHY} ${EMOJIS.FACE_CRAZY}`;
  }
});
