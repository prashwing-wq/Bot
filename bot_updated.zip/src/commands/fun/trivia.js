/**
 * Trivia Quiz Command (Node.js)
 * Interactive trivia game with multiple-choice buttons and timer.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');

const QUESTIONS = [
  {
    q: 'Which protocol is responsible for resolving domain names into IP addresses?',
    options: ['DHCP', 'DNS', 'HTTP', 'FTP'],
    correct: 1,
    category: 'Technology'
  },
  {
    q: 'What is the largest planet in our solar system?',
    options: ['Saturn', 'Neptune', 'Jupiter', 'Mars'],
    correct: 2,
    category: 'Science'
  },
  {
    q: 'In what year was the first iPhone released?',
    options: ['2005', '2007', '2009', '2010'],
    correct: 1,
    category: 'Technology'
  },
  {
    q: 'Who was the first President of the United States?',
    options: ['Thomas Jefferson', 'George Washington', 'Abraham Lincoln', 'John Adams'],
    correct: 1,
    category: 'History'
  },
  {
    q: 'Which video game franchise features the Master Chief as the main protagonist?',
    options: ['Gears of War', 'Halo', 'Doom', 'Destiny'],
    correct: 1,
    category: 'Gaming'
  },
  {
    q: 'What element does "O" represent on the periodic table?',
    options: ['Osmium', 'Oxygen', 'Ozone', 'Oganesson'],
    correct: 1,
    category: 'Science'
  },
  {
    q: 'Which engine does Node.js utilize to execute JavaScript code outside the browser?',
    options: ['SpiderMonkey', 'JavaScriptCore', 'V8', 'Chakra'],
    correct: 2,
    category: 'Technology'
  }
];

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'trivia',
  aliases: ['quiz', 'testknowledge'],
  category: 'fun',
  description: 'Test your knowledge with interactive multiple-choice trivia challenges.',
  usage: '',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    const item = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
    const buttonLabels = ['A', 'B', 'C', 'D'];

    const buttons = item.options.map((opt, idx) =>
      new ButtonBuilder()
        .setCustomId(`trivia_${idx}`)
        .setLabel(`${buttonLabels[idx]}: ${opt}`)
        .setStyle(ButtonStyle.Primary)
    );

    const row = new ActionRowBuilder().addComponents(buttons);

    const optionBadges = buttonLabels.map((lbl, i) => `\`[ Option ${lbl} ]\``).join('  ');

    const card = createV2Card({
      color: 0x2b2d31,
      title: `🧠  Trivia Challenge • ${item.category}`,
      description:
        `**Question:**\n> ${item.q}\n\n` +
        item.options.map((opt, i) => `**${buttonLabels[i]}.** ${opt}`).join('\n') +
        `\n\n-# Click an option button below within 25 seconds.`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    const msg = await message.reply({ embeds: [card], components: [row] });

    const filter = i => i.user.id === message.author.id && i.customId.startsWith('trivia_');
    try {
      const interaction = await msg.awaitMessageComponent({ filter, time: 25000 });
      const chosenIdx = parseInt(interaction.customId.replace('trivia_', ''), 10);
      const isCorrect = chosenIdx === item.correct;

      const resultCard = createV2Card({
        color: isCorrect ? 0x57F287 : 0xED4245,
        title: isCorrect ? '🎉 Correct Answer!' : '<a:tungsten_close:1567234632905138206> Incorrect!',
        description: isCorrect
          ? `Spot on! **${item.options[item.correct]}** is the correct answer!`
          : `That wasn't right. The correct answer was **${item.options[item.correct]}**.\n\nBetter luck next time!`
      });

      await interaction.update({ embeds: [resultCard], components: [] });
    } catch (err) {
      await msg.edit({
        content: `⏱️ Time ran out! The correct answer was **${item.options[item.correct]}**.`,
        components: []
      }).catch(() => null);
    }
  }
};
