/**
 * Weather Command (Node.js)
 * Returns live or simulated weather telemetry for any city or location.
 */
const https = require('node:https');
const { createEmbed } = require('../../utils/tools');

const SIMULATED_CONDITIONS = [
  'Sunny / Clear',
  'Partly Cloudy',
  'Overcast',
  'Light Rain',
  'Passing Showers',
  'Breezy & Mild',
  'Scattered Clouds',
  'Fair Skies'
];

function fetchLiveWeather(city) {
  return new Promise((resolve, reject) => {
    const url = `https://wttr.in/${encodeURIComponent(city)}?format=j1`;
    const req = https.get(url, { timeout: 3500, headers: { 'User-Agent': 'Tungsten-Bot/2.0' } }, (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`Status ${res.statusCode}`));
      }
      let raw = '';
      res.on('data', chunk => { raw += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(raw);
          resolve(json);
        } catch (err) {
          reject(err);
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Timeout'));
    });
    req.on('error', (err) => reject(err));
  });
}

function getSimulatedWeather(city) {
  let hash = 0;
  const lower = city.toLowerCase();
  for (let i = 0; i < lower.length; i++) {
    hash = (hash * 31 + lower.charCodeAt(i)) >>> 0;
  }

  const tempC = 15 + (hash % 16);
  const tempF = Math.round(tempC * 9 / 5 + 32);
  const feelsC = tempC + (hash % 3) - 1;
  const humidity = 40 + (hash % 45);
  const windKmh = 8 + (hash % 22);
  const condition = SIMULATED_CONDITIONS[hash % SIMULATED_CONDITIONS.length];

  return {
    location: city.charAt(0).toUpperCase() + city.slice(1),
    tempC,
    tempF,
    feelsC,
    humidity,
    windKmh,
    condition,
    isSimulated: true
  };
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'weather',
  aliases: ['forecast', 'climate'],
  category: 'fun',
  description: 'Displays current weather conditions and temperature for a city.',
  usage: '<city>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!args || args.length === 0) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Please specify a city or location! Usage: \`${prefix}weather <city>\``);
    }

    const query = args.join(' ').trim();
    let data = null;

    try {
      const live = await fetchLiveWeather(query);
      const curr = live.current_condition && live.current_condition[0];
      const area = (live.nearest_area && live.nearest_area[0]) || {};
      const areaName = area.areaName?.[0]?.value || query;
      const country = area.country?.[0]?.value || '';

      if (curr) {
        data = {
          location: country ? `${areaName}, ${country}` : areaName,
          tempC: curr.temp_C,
          tempF: curr.temp_F,
          feelsC: curr.FeelsLikeC,
          humidity: curr.humidity,
          windKmh: curr.windspeedKmph,
          condition: curr.weatherDesc?.[0]?.value || 'Clear',
          isSimulated: false
        };
      }
    } catch (_) {
      // Fallback seamlessly to deterministic simulation if network offline
    }

    if (!data) {
      data = getSimulatedWeather(query);
    }

    const embed = createEmbed({
      color: client?.config?.COLORS?.INFO || 0x3498DB,
      title: `🌤️  Weather Report — ${data.location}`,
      fields: [
        {
          name: '🌡️ Temperature',
          value: `**${data.tempC}°C** / **${data.tempF}°F**\n*(Feels like ${data.feelsC}°C)*`,
          inline: true
        },
        {
          name: '💧 Humidity',
          value: `**${data.humidity}%**`,
          inline: true
        },
        {
          name: '💨 Wind Speed',
          value: `**${data.windKmh} km/h**`,
          inline: true
        },
        {
          name: '☁️ Conditions',
          value: `**${data.condition}**`,
          inline: false
        }
      ],
      footer: `Weather telemetry • Tungsten Fun Suite`
    });

    return message.reply({ embeds: [embed] });
  }
};
