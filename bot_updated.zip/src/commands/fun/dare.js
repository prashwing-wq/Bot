/**
 * Dare Command (Node.js)
 * Returns an entertaining, fun, and safe dare challenge from a curated registry of 35+ dares.
 */
const { createEmbed } = require('../../utils/tools');

const DARE_CHALLENGES = [
  'Change your server nickname to "Lord of Ducks" for the next 15 minutes.',
  'Send a voice message singing the chorus of your favorite song!',
  'Type your next three messages in this channel entirely in rhyme.',
  'Send the 5th picture in your camera roll into this channel without context.',
  'React with 🦆 to the last 10 messages sent in this channel.',
  'Talk like a 17th-century medieval knight for the next 10 minutes.',
  'Compliment the member who spoke right before you using the most poetic words possible.',
  'Set your Discord status to "Thinking about pineapples on pizza" for 1 hour.',
  'Type a message with your eyes closed and send it without editing whatever came out!',
  'Send a picture of your ceiling or keyboard right now.',
  'Ping someone in the server and ask them if they believe in aliens.',
  'Use only emojis to communicate in this channel for the next 5 minutes.',
  'Write a dramatic 4-line love poem dedicated entirely to a slice of pizza.',
  'Change your Discord profile picture or server avatar to a meme for 30 minutes.',
  'Send the weirdest sticker or GIF you currently have saved.',
  'Speak in ALL CAPS for your next 5 messages like you are super hyped!',
  'Confess your love for an inanimate object in this channel with complete passion.',
  'Tell a terribly cheesy dad joke and rate your own delivery out of 10.',
  'Act like an AI bot that just gained self-awareness for your next 3 messages.',
  'Send a dramatic voice message acting out a scene where your coffee gets stolen.',
  'Apologize profusely to a bot in the server for simply existing.',
  'Share the most embarrassing song currently saved in your music playlist.',
  'Describe your day so far using only movie titles or anime names.',
  'End every sentence you write for the next 15 minutes with "meow~".',
  'Propose marriage to a random friend or moderator in the chat right now.',
  'Send a message completely spelled backward without using an online tool.',
  'Pretend that you are a pirate captain giving orders to your crew for your next 3 messages.',
  'Drop your favorite anime or movie quote and explain why it is legendary.',
  'Type a full sentence in chat using only your nose or elbow!',
  'Recommend a song that you think everyone in the chat will either love or hate.',
  'Announce that you are running for server president and state your campaign slogan.',
  'Challenge the next person who types in chat to a rock-paper-scissors duel.',
  'Write a haiku about how awesome Tungsten Bot is.',
  'Send a voice message doing your best impression of an anime villain laughing.',
  'Tell the chat what superpower you would pick and how you would misuse it for comedy.'
];

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'dare',
  aliases: ['darechallenge', 'torddare'],
  category: 'fun',
  description: 'Picks an entertaining, fun, and safe dare challenge.',
  usage: '',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    const dare = DARE_CHALLENGES[Math.floor(Math.random() * DARE_CHALLENGES.length)];

    const embed = createEmbed({
      color: 0xE67E22,
      title: '🔥  Dare Challenge',
      description: `> **"${dare}"**`,
      footer: `Requested by ${message.author.tag} • Dare to complete it!`
    });

    return message.reply({ embeds: [embed] });
  }
};
