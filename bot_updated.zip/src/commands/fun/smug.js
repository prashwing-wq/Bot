const { createRoleplayCommand } = require('./roleplay');
module.exports = createRoleplayCommand('smug');
