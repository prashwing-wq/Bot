/**
 * Rock Paper Scissors Command (Node.js)
 * Interactive game with Components V2 buttons and match result computation.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');
const { EMOJIS } = require('../../utils/emojis');

const CHOICES = [
  { id: 'rock', name: 'Rock', emoji: EMOJIS.UI_ROCK, beats: 'scissors' },
  { id: 'paper', name: 'Paper', emoji: EMOJIS.UI_PAPER, beats: 'rock' },
  { id: 'scissors', name: 'Scissors', emoji: EMOJIS.UI_SCISSORS, beats: 'paper' }
];

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'rps',
  aliases: ['rockpaperscissors'],
  category: 'fun',
  description: 'Play an interactive game of Rock, Paper, Scissors against Tungsten or a friend.',
  usage: '[@opponent]',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    const opponent = message.mentions?.members?.first?.();
    const isBot = !opponent || opponent.id === client.user.id || opponent.id === message.author.id || Boolean(opponent.user?.bot);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('rps_rock')
        .setLabel('Rock')
        .setEmoji(EMOJIS.UI_ROCK)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('rps_paper')
        .setLabel('Paper')
        .setEmoji(EMOJIS.UI_PAPER)
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('rps_scissors')
        .setLabel('Scissors')
        .setEmoji(EMOJIS.UI_SCISSORS)
        .setStyle(ButtonStyle.Danger)
    );

    const desc = isBot
      ? `Hey ${message.author}! Choose your move below to play against **Tungsten**.`
      : `${message.author} has challenged ${opponent}! Choose your moves below.`;

    const card = createV2Card({
      color: 0x2b2d31,
      title: `${EMOJIS.GAMEPAD}  Rock • Paper • Scissors`,
      description:
        `${desc}\n\n` +
        `-# Select your move by clicking a button below within 30 seconds.`,
      buttons: [
        { label: 'Rock', emoji: EMOJIS.UI_ROCK, style: ButtonStyle.Primary },
        { label: 'Paper', emoji: EMOJIS.UI_PAPER, style: ButtonStyle.Success },
        { label: 'Scissors', emoji: EMOJIS.UI_SCISSORS, style: ButtonStyle.Danger }
      ],
      buttonTitle: 'Move Selector',
      footer: { text: 'You have 30 seconds to choose' }
    });

    const gameMsg = await message.reply({ embeds: [card], components: [row] });

    if (isBot) {
      const filter = i => i.user.id === message.author.id && i.customId.startsWith('rps_');
      try {
        const interaction = await gameMsg.awaitMessageComponent({ filter, time: 30000 });
        const userChoiceStr = interaction.customId.replace('rps_', '');
        const userChoice = CHOICES.find(c => c.id === userChoiceStr);

        const botChoice = CHOICES[Math.floor(Math.random() * CHOICES.length)];

        let resultTitle = '';
        let resultColor = 0x2b2d31;
        let resultDesc = '';

        if (userChoice.id === botChoice.id) {
          resultTitle = `${EMOJIS.HANDSHAKE} It's a Tie!`;
          resultColor = 0xFEE75C;
          resultDesc = `Both chose **${userChoice.emoji} ${userChoice.name}**! Great minds think alike.`;
        } else if (userChoice.beats === botChoice.id) {
          resultTitle = `${EMOJIS.PARTY} Victory! You Won!`;
          resultColor = 0x57F287;
          resultDesc = `You chose **${userChoice.emoji} ${userChoice.name}** and Tungsten chose **${botChoice.emoji} ${botChoice.name}**.\n\n*${userChoice.name} crushes ${botChoice.name}!*`;
        } else {
          resultTitle = `${EMOJIS.SKULL} Defeat! Tungsten Won!`;
          resultColor = 0xED4245;
          resultDesc = `You chose **${userChoice.emoji} ${userChoice.name}** and Tungsten chose **${botChoice.emoji} ${botChoice.name}**.\n\n*Better luck next time!*`;
        }

        const resultCard = createV2Card({
          color: resultColor,
          title: resultTitle,
          description: resultDesc
        });

        await interaction.update({ embeds: [resultCard], components: [] });
      } catch (err) {
        await gameMsg.edit({ content: `${EMOJIS.STOPWATCH} Game timed out. No move was chosen.`, components: [] }).catch(() => null);
      }
    } else {
      const choices = new Map();
      const collector = gameMsg.createMessageComponentCollector({
        filter: i => (i.user.id === message.author.id || i.user.id === opponent.id) && i.customId.startsWith('rps_'),
        time: 30000
      });

      collector.on('collect', async interaction => {
        if (choices.has(interaction.user.id)) {
          return interaction.reply({ content: `${EMOJIS.WARN} You already made your move!`, ephemeral: true });
        }
        const userChoiceStr = interaction.customId.replace('rps_', '');
        const choice = CHOICES.find(c => c.id === userChoiceStr);
        choices.set(interaction.user.id, choice);

        await interaction.reply({
          content: `${EMOJIS.CHECK} You selected **${choice.name}**! Waiting for opponent...`,
          ephemeral: true
        });

        if (choices.has(message.author.id) && choices.has(opponent.id)) {
          collector.stop('completed');
        }
      });

      collector.on('end', async (_, reason) => {
        if (reason === 'completed') {
          const p1Choice = choices.get(message.author.id);
          const p2Choice = choices.get(opponent.id);

          let resultTitle = '';
          let resultColor = 0x2b2d31;
          let resultDesc = '';

          if (p1Choice.id === p2Choice.id) {
            resultTitle = `${EMOJIS.HANDSHAKE} It's a Tie!`;
            resultColor = 0xFEE75C;
            resultDesc = `Both **${message.author.username}** and **${opponent.user.username}** chose **${p1Choice.emoji} ${p1Choice.name}**!`;
          } else if (p1Choice.beats === p2Choice.id) {
            resultTitle = `${EMOJIS.PARTY} Victory! ${message.author.username} Won!`;
            resultColor = 0x57F287;
            resultDesc = `**${message.author.username}** chose **${p1Choice.emoji} ${p1Choice.name}** and defeated **${opponent.user.username}**'s **${p2Choice.emoji} ${p2Choice.name}**!`;
          } else {
            resultTitle = `${EMOJIS.PARTY} Victory! ${opponent.user.username} Won!`;
            resultColor = 0x57F287;
            resultDesc = `**${opponent.user.username}** chose **${p2Choice.emoji} ${p2Choice.name}** and defeated **${message.author.username}**'s **${p1Choice.emoji} ${p1Choice.name}**!`;
          }

          const resultCard = createV2Card({
            color: resultColor,
            title: resultTitle,
            description: resultDesc
          });

          await gameMsg.edit({ embeds: [resultCard], components: [] }).catch(() => null);
        } else {
          await gameMsg.edit({ content: `${EMOJIS.STOPWATCH} Game timed out. Both players did not make a move in time.`, components: [] }).catch(() => null);
        }
      });
    }
  }
};
