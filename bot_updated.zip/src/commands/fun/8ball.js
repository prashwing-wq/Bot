/**
 * 8Ball Command
 * Ask the mystical magic 8-ball any question
 */
const { createEmbed } = require('../../utils/tools');

const RESPONSES = [
  'It is certain.',
  'It is decidedly so.',
  'Without a doubt.',
  'Yes definitely.',
  'You may rely on it.',
  'As I see it, yes.',
  'Most likely.',
  'Outlook good.',
  'Yes.',
  'Signs point to yes.',
  'Reply hazy, try again.',
  'Ask again later.',
  'Better not tell you now.',
  'Cannot predict now.',
  'Concentrate and ask again.',
  'Don’t count on it.',
  'My reply is no.',
  'My sources say no.',
  'Outlook not so good.',
  'Very doubtful.'
];

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: '8ball',
  description: 'Ask the magic 8-ball a question.',
  category: 'fun',
  usage: '8ball <question>',
  aliases: ['eightball', '8b'],
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!args[0]) {
      return message.reply(`Please ask a question! Usage: \`${prefix}8ball <question>\``);
    }

    const question = args.join(' ');
    const answer = RESPONSES[Math.floor(Math.random() * RESPONSES.length)];

    const embed = createEmbed({
      color: client.config.COLORS.INFO,
      title: '🎱 Magic 8-Ball',
      fields: [
        { name: '❓ Question', value: question, inline: false },
        { name: '🔮 Answer', value: answer, inline: false }
      ],
      footer: `Asked by ${message.author.tag}`
    });

    return message.reply({ embeds: [embed] });
  }
};
