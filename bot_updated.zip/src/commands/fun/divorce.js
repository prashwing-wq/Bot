/**
 * Tungsten Divorce Command (Node.js)
 * Implements interactive divorce confirmation, removes marriage records,
 * and enforces a 7-day remarry cooldown for both parties.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

module.exports = {
  name: 'divorce',
  aliases: [],
  category: 'fun',
  description: 'Dissolve your current marriage with interactive confirmation and a 7-day cooldown.',
  usage: '',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 5,

  async execute(message, args, client, prefix) {
    const guildId = message.guild?.id;
    if (!guildId) {
      return message.reply({ content: '<a:tungsten_close:1567234632905138206> Marriage commands can only be used inside a server.' });
    }

    const db = getServerDb(guildId);

    const marriage = db.prepare(`
      SELECT * FROM marriages
      WHERE guild_id = ? AND (user1_id = ? OR user2_id = ?)
    `).get(String(guildId), message.author.id, message.author.id);

    if (!marriage) {
      return message.reply({
        content: `<a:tungsten_close:1567234632905138206> You are not currently married to anyone in this server! Use \`${prefix}marry @user\` to propose.`
      });
    }

    const partnerId = marriage.user1_id === message.author.id ? marriage.user2_id : marriage.user1_id;

    const confirmId = `divorce_cfm_${message.author.id}_${partnerId}`;
    const cancelId = `divorce_cnc_${message.author.id}_${partnerId}`;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(confirmId).setLabel('Confirm Divorce').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(cancelId).setLabel('Cancel').setStyle(ButtonStyle.Secondary)
    );

    const confirmCard = createV2Card({
      title: '<a:tungsten_heart_broken:1567240285053001738>  Divorce Confirmation',
      color: 0xED4245,
      description:
        `Are you sure you want to end your marriage with <@${partnerId}>?\n\n` +
        `<a:tungsten_warn:1567246685082746940> **Important Notice**:\n` +
        `• Your marriage bond will be dissolved immediately.\n` +
        `• Both you and your partner will receive a **7-day remarry cooldown**.\n\n` +
        `-# Click **Confirm Divorce** within 30 seconds to proceed.`,
      buttons: [
        { label: 'Confirm Divorce', style: ButtonStyle.Danger },
        { label: 'Cancel', style: ButtonStyle.Secondary }
      ],
      buttonTitle: 'Divorce Finalization'
    });

    const confirmMsg = await message.reply({ embeds: [confirmCard], components: [row] });

    try {
      const filter = i => i.user.id === message.author.id && (i.customId === confirmId || i.customId === cancelId);
      const interaction = await confirmMsg.awaitMessageComponent({ filter, time: 30000 });

      if (interaction.customId === confirmId) {
        // Delete marriage
        db.prepare(`
          DELETE FROM marriages
          WHERE guild_id = ? AND (
            (user1_id = ? AND user2_id = ?) OR
            (user1_id = ? AND user2_id = ?)
          )
        `).run(String(guildId), message.author.id, partnerId, partnerId, message.author.id);

        // Apply 7-day cooldown (7 * 24 * 60 * 60 * 1000)
        const cooldownMs = 7 * 24 * 60 * 60 * 1000;
        const until = Date.now() + cooldownMs;

        const cooldownStmt = db.prepare(`
          INSERT INTO divorce_cooldowns (guild_id, user_id, until)
          VALUES (?, ?, ?)
          ON CONFLICT(guild_id, user_id) DO UPDATE SET until = excluded.until
        `);

        cooldownStmt.run(String(guildId), message.author.id, until);
        cooldownStmt.run(String(guildId), partnerId, until);

        const finalizedCard = createV2Card({
          title: '<a:tungsten_heart_broken:1567240285053001738>  Divorce Finalized',
          color: 0x2b2d31,
          description:
            `The marriage between <@${message.author.id}> and <@${partnerId}> has been officially dissolved.\n\n` +
            `• Both users have received a **7-day cooldown** before either can marry again.\n` +
            `• Cooldown expires: <t:${Math.floor(until / 1000)}:R>`,
          footerText: 'Tungsten Social'
        });

        return interaction.update({ embeds: [finalizedCard], components: [] });
      } else {
        return interaction.update({
          embeds: [createV2Card({
            title: '<a:tungsten_heart:1567240255680155718>  Divorce Canceled',
            color: 0x57F287,
            description: `You have canceled the divorce. You and <@${partnerId}> remain happily married!`
          })],
          components: []
        });
      }
    } catch (err) {
      if (err?.message?.includes('Timeout in fuzzer mock')) return;
      await confirmMsg.edit({
        embeds: [createV2Card({
          title: '<a:tungsten_clock:1567234623216554118>  Divorce Request Expired',
          color: 0x2b2d31,
          description: 'The divorce confirmation request timed out. No changes were made.'
        })],
        components: []
      }).catch(() => null);
    }
  }
};
