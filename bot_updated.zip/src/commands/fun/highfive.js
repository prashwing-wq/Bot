const { createRoleplayCommand } = require('./roleplay');
module.exports = createRoleplayCommand('highfive');
