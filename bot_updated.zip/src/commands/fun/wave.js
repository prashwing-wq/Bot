const { createRoleplayCommand } = require('./roleplay');
module.exports = createRoleplayCommand('wave');
