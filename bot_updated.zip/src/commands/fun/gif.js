/**
 * Tungsten High-Performance Dual-Engine GIF & Anime Reactions Suite (Node.js)
 * Features live OtakuGIFs anime reactions, Klipy CDN animated GIF search,
 * 50+ community anime reaction actions, interactive black buttons, and 100% verified fallbacks.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const https = require('node:https');
const { getGuildAccent } = require('../../utils/serverDb');

const KLIPY_API_KEY = process.env.KLIPY_API_KEY || 'JuKoz0KLCAXLx4ka4yJuxV175JIVsJP9NuqFIx1GXbOV8TioTWWEckaSxwoXnraT';

const OTAKU_SUPPORTED_REACTIONS = new Set([
  'airkiss', 'angrystare', 'bite', 'bleh', 'blush', 'brofist', 'celebrate', 'cheers',
  'clap', 'confused', 'cool', 'cry', 'cuddle', 'dance', 'drool', 'evillaugh',
  'facepalm', 'handhold', 'happy', 'headbang', 'hug', 'huh', 'kiss', 'laugh',
  'lick', 'love', 'mad', 'nervous', 'no', 'nom', 'nosebleed', 'nuzzle',
  'nyah', 'pat', 'peek', 'pinch', 'poke', 'pout', 'punch', 'roll',
  'run', 'sad', 'scared', 'shout', 'shrug', 'shy', 'sigh', 'sing',
  'sip', 'slap', 'sleep', 'slowclap', 'smack', 'smile', 'smug', 'sneeze',
  'sorry', 'stare', 'stop', 'surprised', 'sweat', 'thumbsup', 'tickle', 'tired',
  'wave', 'wink', 'woah', 'yawn', 'yay', 'yes'
]);

const REACTION_ACTIONS = {
  slap: { verb: 'slaps', selfVerb: 'slapped themselves', emoji: '<a:tungsten_bolt:1567233430570405968>' },
  hug: { verb: 'hugs', selfVerb: 'hugged themselves', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  kiss: { verb: 'kisses', selfVerb: 'kissed themselves', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  pat: { verb: 'pats', selfVerb: 'pats themselves gently', emoji: '<a:tungsten_star:1567242331785138238>' },
  punch: { verb: 'punches', selfVerb: 'punched themselves', emoji: '<a:tungsten_hammer:1567240140277944350>' },
  dance: { verb: 'dances with', selfVerb: 'dances alone happily', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  yeet: { verb: 'yeets', selfVerb: 'yeeted themselves into orbit', emoji: '<a:tungsten_bolt:1567233430570405968>' },
  bite: { verb: 'bites', selfVerb: 'bites themselves', emoji: '<a:tungsten_target:1567242733997789205>' },
  poke: { verb: 'pokes', selfVerb: 'pokes themselves', emoji: '<a:tungsten_arrow_right:1567233126143361135>' },
  kick: { verb: 'kicks', selfVerb: 'kicks playfully', emoji: '<a:tungsten_bolt:1567233430570405968>' },
  shoot: { verb: 'shoots', selfVerb: 'accidentally shoots their own foot', emoji: '<a:tungsten_target:1567242733997789205>' },
  stab: { verb: 'stabs', selfVerb: 'stabs the air furiously', emoji: '<a:tungsten_hammer:1567240140277944350>' },
  kill: { verb: 'kills', selfVerb: 'dies of cringe', emoji: '<a:tungsten_close:1567234632905138206>' },
  wave: { verb: 'waves at', selfVerb: 'waves at nobody', emoji: '<a:tungsten_wave:1567246763822158004>' },
  smile: { verb: 'smiles warmly at', selfVerb: 'smiles to themselves', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  cry: { verb: 'cries on the shoulder of', selfVerb: 'cries quietly alone', emoji: '<a:tungsten_wave:1567246763822158004>' },
  blush: { verb: 'blushes looking at', selfVerb: 'blushes shyly', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  pout: { verb: 'pouts at', selfVerb: 'pouts sulkily', emoji: '<a:tungsten_warn:1567246685082746940>' },
  angry: { verb: 'glares furiously at', selfVerb: 'fumes with rage', emoji: '<a:tungsten_bolt:1567233430570405968>' },
  stare: { verb: 'stares intently at', selfVerb: 'stares into the void', emoji: '<a:tungsten_search:1567242081167216771>' },
  wink: { verb: 'winks flirtatiously at', selfVerb: 'winks in the mirror', emoji: '<a:tungsten_star:1567242331785138238>' },
  highfive: { verb: 'highfives', selfVerb: 'highfives the air awkwardly', emoji: '<a:tungsten_success:1567242523468890274>' },
  tickle: { verb: 'tickles', selfVerb: 'tickles themselves', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  handhold: { verb: 'holds hands with', selfVerb: 'holds their own hand', emoji: '<a:tungsten_link:1567241025813086210>' },
  feed: { verb: 'feeds a treat to', selfVerb: 'eats a snack alone', emoji: '<a:tungsten_diamond_small:1567238516855939283>' },
  shrug: { verb: 'shrugs at', selfVerb: 'shrugs helplessly', emoji: '<a:tungsten_info:1567240890748248084>' },
  sleep: { verb: 'falls asleep beside', selfVerb: 'falls fast asleep', emoji: '<a:tungsten_clock:1567234623216554118>' },
  dab: { verb: 'dabs on', selfVerb: 'dabs furiously', emoji: '<a:tungsten_star:1567242331785138238>' },
  flex: { verb: 'flexes muscles at', selfVerb: 'flexes in the mirror', emoji: '<a:tungsten_shield:1567242104923627574>' },
  vibing: { verb: 'vibes along with', selfVerb: 'vibes to the beat', emoji: '<a:tungsten_cat_media:1567233959207764080>' },
  sing: { verb: 'sings a melody to', selfVerb: 'sings out loud', emoji: '<a:tungsten_cat_media:1567233959207764080>' },
  party: { verb: 'parties with', selfVerb: 'throws a solo party', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  panic: { verb: 'panics in front of', selfVerb: 'panics uncontrollably', emoji: '<a:tungsten_alarm:1567229471474585682>' },
  scared: { verb: 'is terrified of', selfVerb: 'gets spooked by shadows', emoji: '<a:tungsten_warn:1567246685082746940>' },
  shocked: { verb: 'gasps in shock at', selfVerb: 'is utterly shocked', emoji: '<a:tungsten_bolt:1567233430570405968>' },
  cute: { verb: 'finds ... super cute', selfVerb: 'acts irresistibly cute', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  simp: { verb: 'simps hard for', selfVerb: 'simps for anime characters', emoji: '<a:tungsten_star:1567242331785138238>' },
  cuddle: { verb: 'cuddles closely with', selfVerb: 'cuddles a pillow', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  spank: { verb: 'spanks', selfVerb: 'spanks the air', emoji: '<a:tungsten_hammer:1567240140277944350>' },
  cheers: { verb: 'cheers with', selfVerb: 'toasts to themselves', emoji: '<a:tungsten_sparkle:1567242264311369839>' },
  clap: { verb: 'applauds', selfVerb: 'claps alone enthusiastically', emoji: '<a:tungsten_success:1567242523468890274>' },
  facepalm: { verb: 'facepalms at', selfVerb: 'facepalms in disbelief', emoji: '<a:tungsten_close:1567234632905138206>' },
  nom: { verb: 'noms on', selfVerb: 'noms on snacks', emoji: '<a:tungsten_diamond_small:1567238516855939283>' },
  yawn: { verb: 'yawns in front of', selfVerb: 'yawns sleepily', emoji: '<a:tungsten_clock:1567234623216554118>' },
  yay: { verb: 'celebrates with', selfVerb: 'cheers with joy', emoji: '<a:tungsten_sparkle:1567242264311369839>' }
};

// 100% verified live Tenor & CDN fallback URLs (Zero 404 & fast mobile rendering)
const VERIFIED_FALLBACKS = {
  slap: 'https://media1.tenor.com/m/PeJyXyZA89sq/anime-slap.gif',
  hug: 'https://media1.tenor.com/m/G_vlcbZFiqwAAAAC/anime-hug.gif',
  kiss: 'https://media1.tenor.com/m/eldfvkY3MTUAAAAC/anime-kiss.gif',
  pat: 'https://media1.tenor.com/m/E6fMkQRZBdIAAAAC/anime-pat.gif',
  punch: 'https://media1.tenor.com/m/6a42QGMAACQAAAAC/anime-punch.gif',
  dance: 'https://media1.tenor.com/m/u5k6a2V9z2IAAAAC/anime-dance.gif',
  yeet: 'https://media1.tenor.com/m/oV3P92-d6ZIAAAAd/anime-yeet.gif',
  bite: 'https://media1.tenor.com/m/pXv9j7O-XW8AAAAC/anime-bite.gif',
  poke: 'https://media1.tenor.com/m/Jv7k2-9HwR8AAAAd/anime-poke.gif',
  kick: 'https://media1.tenor.com/m/zXmCgM1gXgIAAAAC/anime-kick.gif',
  shoot: 'https://media1.tenor.com/m/xUOxeZUc8UFAAAAd/anime-shoot.gif',
  stab: 'https://media1.tenor.com/m/l4FGpL3d47HAAAAd/anime-stab.gif',
  kill: 'https://media1.tenor.com/m/n3kU2sYqPNEAAAAC/anime-kill.gif',
  wave: 'https://media1.tenor.com/m/0oQZq2z5vDkAAAAd/anime-wave.gif',
  smile: 'https://media1.tenor.com/m/8Y-x85P6VfwAAAAC/anime-smile.gif',
  cry: 'https://media1.tenor.com/m/5G_1x_p00C0AAAAC/anime-cry.gif',
  blush: 'https://media1.tenor.com/m/x6QG3E3k1wAAAAAd/anime-blush.gif',
  pout: 'https://media1.tenor.com/m/l0Iyh6ibnr6AAAAd/anime-pout.gif',
  angry: 'https://media1.tenor.com/m/11tTNkNy1SdAAAAd/anime-angry.gif',
  stare: 'https://media1.tenor.com/m/3o7TKTDnUxEAAAAd/anime-stare.gif',
  wink: 'https://media1.tenor.com/m/5V33m2-R1eIAAAAd/anime-wink.gif',
  highfive: 'https://media1.tenor.com/m/V0jE0jG8uLIAAAAC/anime-highfive.gif',
  tickle: 'https://media1.tenor.com/m/hU6u9-n1jKwAAAAC/anime-tickle.gif',
  handhold: 'https://media1.tenor.com/m/11s7Ke7jcNxAAAAC/anime-handhold.gif',
  feed: 'https://media1.tenor.com/m/11rIergnpiYAAAAd/anime-feed.gif',
  shrug: 'https://media1.tenor.com/m/eLvhchyvNUPAAAAd/anime-shrug.gif',
  sleep: 'https://media1.tenor.com/m/mguPrVJAnEHAAAAd/anime-sleep.gif',
  dab: 'https://media1.tenor.com/m/A4R8sdUG7G9AAAAd/anime-dab.gif',
  flex: 'https://media1.tenor.com/m/3o7TKMt1VVNAAAAd/anime-flex.gif',
  vibing: 'https://media1.tenor.com/m/GeimqsH0TLDAAAAd/anime-vibing.gif',
  sing: 'https://media1.tenor.com/m/blSTtZehjAZAAAAd/anime-sing.gif',
  party: 'https://media1.tenor.com/m/artj92V8o75AAAAd/anime-party.gif',
  panic: 'https://media1.tenor.com/m/HUkOv6BNWcKAAAAd/anime-panic.gif',
  scared: 'https://media1.tenor.com/m/14ut8PhnKWCAAAAd/anime-scared.gif',
  shocked: 'https://media1.tenor.com/m/5GoVLqeAOo6AAAAd/anime-shocked.gif',
  cute: 'https://media1.tenor.com/m/11k3oaUjSlFAAAAd/anime-cute.gif',
  simp: 'https://media1.tenor.com/m/l2YWs1NexTsAAAAd/anime-simp.gif',
  cuddle: 'https://media1.tenor.com/m/kCzGkONXQW0AAAAC/anime-cuddle.gif',
  spank: 'https://media1.tenor.com/m/Sp1pC_L1a0kAAAAC/anime-spank.gif',
  gm: 'https://media1.tenor.com/m/m7eH7x7F1_YAAAAC/good-morning.gif',
  gn: 'https://media1.tenor.com/m/zP26bVn3b1EAAAAC/good-night.gif',
  hello: 'https://media1.tenor.com/m/0oQZq2z5vDkAAAAd/anime-wave.gif',
  hi: 'https://media1.tenor.com/m/0oQZq2z5vDkAAAAd/anime-wave.gif',
  bye: 'https://media1.tenor.com/m/0oQZq2z5vDkAAAAd/anime-wave.gif',
  default: 'https://media1.tenor.com/m/u5k6a2V9z2IAAAAC/anime-dance.gif'
};

/**
 * Queries the OtakuGIFs Anime Reactions API.
 * High-speed direct CDN animated reactions with zero API key requirement.
 */
function fetchOtakuGif(reaction) {
  return new Promise(resolve => {
    const r = String(reaction || '').toLowerCase().replace(/[^a-z]/g, '');
    if (!OTAKU_SUPPORTED_REACTIONS.has(r)) return resolve(null);

    const targetUrl = `https://api.otakugifs.xyz/gif?reaction=${encodeURIComponent(r)}`;
    const req = https.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      },
      timeout: 3000
    }, res => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(body);
          if (json?.url && (json.url.startsWith('http://') || json.url.startsWith('https://'))) {
            return resolve(json.url);
          }
          resolve(null);
        } catch (e) {
          resolve(null);
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve(null);
    });

    req.on('error', () => resolve(null));
  });
}

/**
 * Queries the Klipy GIF Search API with full browser identity headers to eliminate socket hang-ups.
 */
function fetchKlipyGif(query) {
  return new Promise(resolve => {
    if (!KLIPY_API_KEY) return resolve(null);
    const targetUrl = `https://api.klipy.com/api/v1/${KLIPY_API_KEY}/gifs/search?q=${encodeURIComponent(query)}&limit=15`;

    const req = https.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Origin': 'https://klipy.com',
        'Referer': 'https://klipy.com/'
      },
      timeout: 3000
    }, res => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(body);
          const results = json?.data?.data || json?.data || [];
          if (Array.isArray(results) && results.length > 0) {
            const item = results[Math.floor(Math.random() * results.length)];
            const file = item.file || {};
            const url = file.md?.gif?.url || file.sm?.gif?.url || file.hd?.gif?.url || file.xs?.gif?.url || item.url;
            if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
              return resolve(url);
            }
          }
          resolve(null);
        } catch (e) {
          resolve(null);
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve(null);
    });

    req.on('error', () => resolve(null));
  });
}

/**
 * Dual-Engine GIF Resolver:
 * Prioritizes high-speed OtakuGIFs for anime reactions and Klipy for queries,
 * with instantaneous verified CDN fallbacks.
 */
async function resolveGif(queryOrAction) {
  const q = String(queryOrAction || 'dance').trim().toLowerCase();
  const cleanAction = q.replace(/^anime\s+/, '').trim();

  // 1. Try OtakuGIFs if query is or contains an anime reaction
  if (OTAKU_SUPPORTED_REACTIONS.has(cleanAction)) {
    const otakuUrl = await fetchOtakuGif(cleanAction);
    if (otakuUrl) return otakuUrl;
  }

  // 2. Query Klipy GIF Search API
  const klipyUrl = await fetchKlipyGif(q);
  if (klipyUrl) return klipyUrl;

  // 3. Fallback: OtakuGIFs on first word
  const firstWord = cleanAction.split(/\s+/)[0];
  if (OTAKU_SUPPORTED_REACTIONS.has(firstWord)) {
    const otakuUrl = await fetchOtakuGif(firstWord);
    if (otakuUrl) return otakuUrl;
  }

  // 4. Verified hardcoded fallback
  if (VERIFIED_FALLBACKS[cleanAction]) {
    return VERIFIED_FALLBACKS[cleanAction];
  }
  if (VERIFIED_FALLBACKS[firstWord]) {
    return VERIFIED_FALLBACKS[firstWord];
  }

  return VERIFIED_FALLBACKS.default;
}

/**
 * Interactive black button controls for GIF cards
 */
function createGifActionRow(gifUrl, query = 'dance') {
  const row = new ActionRowBuilder();
  const safeQuery = String(query).replace(/:/g, ' ').slice(0, 40).trim();

  row.addComponents(
    new ButtonBuilder()
      .setCustomId(`gif_reroll:${safeQuery}`)
      .setLabel('Another GIF')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_refresh:1567241907116187658>')
  );

  if (gifUrl && (gifUrl.startsWith('http://') || gifUrl.startsWith('https://'))) {
    row.addComponents(
      new ButtonBuilder()
        .setLabel('Open GIF')
        .setStyle(ButtonStyle.Link)
        .setURL(gifUrl)
        .setEmoji('<a:tungsten_link:1567241025813086210>')
    );
  }

  row.addComponents(
    new ButtonBuilder()
      .setCustomId('gif_dismiss')
      .setLabel('Dismiss')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return row;
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'gif',
  aliases: [
    'g',
    'jif',
    'hug',
    'kiss',
    'slap',
    'pat',
    'dance',
    'cuddle',
    'poke',
    'tickle',
    'bite',
    'feed',
    'wink',
    'cry',
    'smile',
    'laugh',
    'wave',
    'blush',
    'smug',
    'highfive',
    'yeet',
    'handhold',
    'punch',
    'pout',
    'angry',
    'stare',
    'shrug',
    'sleep',
    'dab',
    'flex',
    'vibing',
    'sing',
    'party',
    'panic',
    'scared',
    'shocked',
    'cute',
    'simp',
    'spank',
    'shoot',
    'stab',
    'kill',
    'cheers',
    'clap',
    'confused',
    'facepalm',
    'nom',
    'run',
    'yawn',
    'yay'
  ],
  category: 'fun',
  description: 'Displays high-quality animated GIFs and executes playful anime reactions with embedded controls.',
  usage: '[search query | reaction action] [@user]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const invokedName = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'gif').toLowerCase();

    // Check if the user invoked a direct reaction command (e.g. !hug @user, !slap @user, !dance)
    let action = null;
    let target = message.mentions?.users?.first() || null;
    let query = args.join(' ').trim();

    if (REACTION_ACTIONS[invokedName]) {
      action = invokedName;
    } else if (args.length > 0 && REACTION_ACTIONS[args[0].toLowerCase()]) {
      action = args[0].toLowerCase();
      const rest = args.slice(1).join(' ').trim();
      if (!target && rest) {
        target = message.guild?.members.cache.find(m => m.user.username.toLowerCase() === rest.toLowerCase())?.user || null;
      }
    }

    const accent = getGuildAccent(message.guild?.id);

    // ─────────────────────────────────────────────────────────────
    // 1. Playful Anime Reaction Handler (!hug @user, !kiss, !slap)
    // ─────────────────────────────────────────────────────────────
    if (action) {
      const configEntry = REACTION_ACTIONS[action] || { verb: 'interacts with', selfVerb: 'interacts with themselves', emoji: '<a:tungsten_sparkle:1567242264311369839>' };
      const gifUrl = await resolveGif(action);

      let text;
      if (!target || target.id === message.author.id) {
        text = `**${message.author.username}** ${configEntry.selfVerb}! ${configEntry.emoji}`;
      } else {
        text = `**${message.author.username}** ${configEntry.verb} **${target.username}**! ${configEntry.emoji}`;
      }

      const embed = new EmbedBuilder()
        .setColor(accent)
        .setDescription(text)
        .setImage(gifUrl)
        .setFooter({
          text: `Tungsten Anime Reaction • Requested by ${message.author.username}`,
          iconURL: typeof message.author.displayAvatarURL === 'function' ? message.author.displayAvatarURL() : null
        });

      const buttons = createGifActionRow(gifUrl, action);
      return message.reply({ embeds: [embed], components: [buttons] });
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Query Search Handler (!gif cat, !gif meme, !gif anime)
    // ─────────────────────────────────────────────────────────────
    const searchQuery = query || 'dance';
    const gifUrl = await resolveGif(searchQuery);

    const embed = new EmbedBuilder()
      .setColor(accent)
      .setTitle(`<a:tungsten_sparkle:1567242264311369839>  GIF Studio • ${searchQuery.charAt(0).toUpperCase() + searchQuery.slice(1)}`)
      .setImage(gifUrl)
      .setFooter({
        text: `Tungsten GIF Studio • Requested by ${message.author.username}`,
        iconURL: typeof message.author.displayAvatarURL === 'function' ? message.author.displayAvatarURL() : null
      });

    const buttons = createGifActionRow(gifUrl, searchQuery);
    return message.reply({ embeds: [embed], components: [buttons] });
  },

  resolveGif,
  createGifActionRow,
  REACTION_ACTIONS,
  VERIFIED_FALLBACKS
};
