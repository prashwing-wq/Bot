/**
 * HowGay Command (Node.js)
 * Calculates a member's gay rating percentage for the day.
 */
const { createRateCommand } = require('../../utils/rateHelper');
const { EMOJIS } = require('../../utils/emojis');

module.exports = createRateCommand({
  name: 'howgay',
  aliases: ['gayrate', 'gay'],
  title: 'Gay Rate Machine',
  type: 'howgay',
  emoji: EMOJIS.SPARKLES,
  color: 0x9B59B6,
  description: 'Calculates how gay you or another member are.',
  getComment(score) {
    if (score < 25) return `Straight as a ruler! ${EMOJIS.UI_RULES || EMOJIS.ARROW_RIGHT}`;
    if (score < 50) return `Slightly fruity tendencies! ${EMOJIS.CHERRY || EMOJIS.HEART_SPARKLE}`;
    if (score < 80) return `Pretty gay, not going to lie! ${EMOJIS.SPARKLE}`;
    return `100% Certified Rainbow Royalty! ${EMOJIS.HEARTS} ${EMOJIS.CROWN}`;
  }
});
