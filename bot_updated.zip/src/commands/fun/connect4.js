/**
 * Connect Four Command (Node.js)
 * Interactive 7x6 Connect Four board game with button drops.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');

const ROWS = 6;
const COLS = 7;
const EMPTY = '⚪';
const P1 = '🔴';
const P2 = '🟡';

function createBoard() {
  const board = [];
  for (let r = 0; r < ROWS; r++) {
    board.push(new Array(COLS).fill(EMPTY));
  }
  return board;
}

function renderBoard(board) {
  let str = '';
  for (let r = 0; r < ROWS; r++) {
    str += board[r].join('') + '\n';
  }
  str += '1️⃣2️⃣3️⃣4️⃣5️⃣6️⃣7️⃣';
  return str;
}

function dropPiece(board, col, piece) {
  for (let r = ROWS - 1; r >= 0; r--) {
    if (board[r][col] === EMPTY) {
      board[r][col] = piece;
      return r;
    }
  }
  return -1; // Column full
}

function checkWin(board, piece) {
  // Horizontal
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS - 3; c++) {
      if (board[r][c] === piece && board[r][c+1] === piece && board[r][c+2] === piece && board[r][c+3] === piece) return true;
    }
  }
  // Vertical
  for (let r = 0; r < ROWS - 3; r++) {
    for (let c = 0; c < COLS; c++) {
      if (board[r][c] === piece && board[r+1][c] === piece && board[r+2][c] === piece && board[r+3][c] === piece) return true;
    }
  }
  // Diagonal /
  for (let r = 3; r < ROWS; r++) {
    for (let c = 0; c < COLS - 3; c++) {
      if (board[r][c] === piece && board[r-1][c+1] === piece && board[r-2][c+2] === piece && board[r-3][c+3] === piece) return true;
    }
  }
  // Diagonal \
  for (let r = 0; r < ROWS - 3; r++) {
    for (let c = 0; c < COLS - 3; c++) {
      if (board[r][c] === piece && board[r+1][c+1] === piece && board[r+2][c+2] === piece && board[r+3][c+3] === piece) return true;
    }
  }
  return false;
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'connect4',
  aliases: ['c4', 'fourinarrow'],
  category: 'fun',
  description: 'Play a game of Connect Four against Tungsten with interactive button controls.',
  usage: '',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    const board = createBoard();
    let gameOver = false;

    // Discord allows up to 5 buttons per row, so 2 rows: (1-4) and (5-7)
    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('c4_0').setLabel('1').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('c4_1').setLabel('2').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('c4_2').setLabel('3').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('c4_3').setLabel('4').setStyle(ButtonStyle.Primary)
    );
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('c4_4').setLabel('5').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('c4_5').setLabel('6').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('c4_6').setLabel('7').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('c4_quit').setLabel('Quit').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_error:1567238753284653106>')
    );

    const card = createV2Card({
      color: 0x2b2d31,
      title: '<a:tungsten_shield:1567242104923627574> Connect Four • Player vs Tungsten',
      description:
        `${renderBoard(board)}\n\n` +
        `-# Click a column number below to drop your checker, or 🏳️ Quit to forfeit.`
    });

    const gameMsg = await message.reply({ embeds: [card], components: [row1, row2] });

    const collector = gameMsg.createMessageComponentCollector({
      filter: i => i.user.id === message.author.id,
      time: 60000
    });

    collector.on('collect', async interaction => {
      if (gameOver) return;

      if (interaction.customId === 'c4_quit') {
        gameOver = true;
        collector.stop('quit');
        return interaction.update({ content: '🏳️ Game ended by user.', embeds: [], components: [] });
      }

      const col = parseInt(interaction.customId.replace('c4_', ''), 10);
      const rowPlaced = dropPiece(board, col, P1);

      if (rowPlaced === -1) {
        return interaction.reply({ content: '<a:tungsten_warn:1567246685082746940> Column is full! Pick another one.', flags: MessageFlags.Ephemeral });
      }

      if (checkWin(board, P1)) {
        gameOver = true;
        collector.stop('win');
        const winCard = createV2Card({
          color: 0x57F287,
          title: '🎉 Connect Four • Victory!',
          description: `${renderBoard(board)}\n\n**Congratulations ${message.author}! You connected four and won!**`
        });
        return interaction.update({ embeds: [winCard], components: [] });
      }

      // Tungsten Bot Turn
      const validCols = [];
      for (let c = 0; c < COLS; c++) {
        if (board[0][c] === EMPTY) validCols.push(c);
      }

      if (validCols.length === 0) {
        gameOver = true;
        collector.stop('tie');
        return interaction.update({ content: "🤝 It's a draw! The board is full.", embeds: [], components: [] });
      }

      const botCol = validCols[Math.floor(Math.random() * validCols.length)];
      dropPiece(board, botCol, P2);

      if (checkWin(board, P2)) {
        gameOver = true;
        collector.stop('bot_win');
        const botWinCard = createV2Card({
          color: 0xED4245,
          title: '💀 Connect Four • Defeat!',
          description: `${renderBoard(board)}\n\n**Tungsten connected four! Better luck next time.**`
        });
        return interaction.update({ embeds: [botWinCard], components: [] });
      }

      const updatedCard = createV2Card({
        color: 0x2b2d31,
        title: '🔴  Connect Four • You (🔴) vs Tungsten (🟡)',
        description: `${renderBoard(board)}\n\n*Tungsten dropped in column ${botCol + 1}. Your turn!*`
      });

      await interaction.update({ embeds: [updatedCard], components: [row1, row2] });
    });

    collector.on('end', (collected, reason) => {
      if (reason === 'time' && !gameOver) {
        gameMsg.edit({ content: '⏱️ Connect Four game timed out.', components: [] }).catch(() => null);
      }
    });
  }
};
