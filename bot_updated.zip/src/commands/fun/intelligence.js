/**
 * Intelligence Command (Node.js)
 * Calculates a member's IQ score (50-200) for the day.
 */
const { createRateCommand } = require('../../utils/rateHelper');
const { EMOJIS } = require('../../utils/emojis');

module.exports = createRateCommand({
  name: 'intelligence',
  aliases: ['iq', 'iqrate', 'intellect'],
  title: 'Intelligence Quotient (IQ) Scanner',
  type: 'intelligence',
  emoji: EMOJIS.BRAIN,
  min: 50,
  max: 200,
  unit: 'IQ',
  color: 0x3498DB,
  description: 'Scans and calculates the IQ score of yourself or another member.',
  getComment(score) {
    if (score < 80) return `Room temperature IQ, but full of heart! ${EMOJIS.HEART}`;
    if (score < 105) return `Average human brain activity detected! ${EMOJIS.BRAIN}`;
    if (score < 130) return `Above average intelligence! Sharp as a tack! ${EMOJIS.STAR}`;
    if (score < 160) return `Certified genius level intellect! ${EMOJIS.CRYSTAL}`;
    return `Galactic megamind! ${EMOJIS.CROWN} ${EMOJIS.SPARKLE}`;
  }
});
