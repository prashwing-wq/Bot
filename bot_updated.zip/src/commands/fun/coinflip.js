/**
 * Coinflip Command (Prefix & Gambling)
 * Flips a virtual coin with optional betting up to MAX_BET.
 */
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { playCoinflip } = require('../../utils/economy');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'coinflip',
  description: 'Flip a coin (Heads or Tails) with optional gambling bets.',
  category: 'fun',
  usage: 'coinflip [heads|tails] [bet_amount]',
  aliases: ['flip', 'cf'],
  cooldown: 2,

  async execute(message, args, client, prefix) {
    const isHeads = Math.random() < 0.5;
    const outcomeDisplay = isHeads ? 'Heads' : 'Tails';

    let choice = null;
    let bet = null;

    if (args[0]) {
      const first = args[0].toLowerCase();
      if (first === 'heads' || first === 'head' || first === 'h') {
        choice = 'heads';
        if (args[1]) bet = parseInt(args[1], 10);
      } else if (first === 'tails' || first === 'tail' || first === 't') {
        choice = 'tails';
        if (args[1]) bet = parseInt(args[1], 10);
      } else if (!isNaN(parseInt(first, 10))) {
        bet = parseInt(first, 10);
        choice = 'heads'; // default choice if only amount passed
      }
    }

    // Simple flip without wager
    if (!bet || isNaN(bet) || bet <= 0) {
      const embed = createEmbed({
        color: client?.config?.COLORS?.WARNING || 0xFEE75C,
        title: '🪙 Coin Flip',
        description: `The coin landed on **${outcomeDisplay}**!`,
        footer: `Flipped by ${message.author.tag || message.author.username}`
      });
      return message.reply({ embeds: [embed] });
    }

    // Gambling Mode
    if (!message.guild) {
      return message.reply('Betting on coinflip is only available inside a server.');
    }

    const sdb = getServerDb(message.guild.id);
    const result = playCoinflip(sdb, message.author.id, bet, choice);

    if (!result.success) {
      return message.reply(`<a:tungsten_close:1567234632905138206> ${result.reason}`);
    }

    const embed = createEmbed({
      color: result.won ? 0x00FF88 : 0xFF3B30,
      title: '🪙  Tungsten Coinflip Gambling',
      description:
        `> You called **${choice.toUpperCase()}** and flipped the coin...\n\n` +
        `The coin landed on **${result.outcomeDisplay}**!\n\n` +
        (result.won
          ? `🎉 **YOU WON!** You received **+$${bet.toLocaleString()}**!`
          : `💸 **YOU LOST!** You lost **-$${bet.toLocaleString()}**!`) +
        `\n\n**Wallet Balance:** **$${result.finalBal.toLocaleString()}**`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
