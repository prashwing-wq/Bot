/**
 * Tungsten Marriage & Relationship System (Node.js)
 * Implements !marry proposal with 60-second interactive Components V2 buttons,
 * marriage verification, self/bot guards, and 7-day divorce cooldown check.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

module.exports = {
  name: 'marry',
  aliases: ['marriage', 'proposal', 'propose'],
  category: 'fun',
  description: 'Propose marriage to another member with interactive buttons.',
  usage: '<@user>',
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  cooldown: 5,

  async execute(message, args, client, prefix) {
    const guildId = message.guild?.id;
    if (!guildId) {
      return message.reply({ content: '<a:tungsten_close:1567234632905138206> Marriage commands can only be used inside a server.' });
    }

    const db = getServerDb(guildId);
    const targetMember = message.mentions.members?.first() ||
      (args[0] ? message.guild.members.cache.get(args[0].replace(/[^0-9]/g, '')) : null);

    // If no target provided, display usage guide
    if (!targetMember) {
      const p = prefix || '!';
      const helpCard = createV2Card({
        title: '<a:tungsten_cat_social:1569329304196747418>  Tungsten Marriage System',
        color: config.COLORS?.PRIMARY || 0x2b2d31,
        description:
          `Express your love and bond with a fellow member in holy matrimony!\n\n` +
          `**Usage**\n` +
          `• \`${p}marry @user\` — Propose marriage with interactive 60-second buttons\n` +
          `• \`${p}divorce\` — Dissolve your current marriage (7-day cooldown)\n` +
          `• \`${p}couples\` — View the longest-married couples leaderboard\n\n` +
          `-# Both participants must agree to the proposal.`,
        footerText: 'Tungsten Relationships'
      });
      return message.reply({ embeds: [helpCard] });
    }

    if (targetMember.user.bot) {
      return message.reply({ content: '<a:tungsten_close:1567234632905138206> You cannot marry a Discord bot!' });
    }

    if (targetMember.id === message.author.id) {
      return message.reply({ content: '<a:tungsten_close:1567234632905138206> You cannot marry yourself! Tag someone special.' });
    }

    const now = Date.now();

    // Check divorce cooldown for author
    const authorCooldown = db.prepare('SELECT until FROM divorce_cooldowns WHERE guild_id = ? AND user_id = ?').get(String(guildId), message.author.id);
    if (authorCooldown && authorCooldown.until > now) {
      const untilSec = Math.floor(authorCooldown.until / 1000);
      return message.reply({
        content: `<a:tungsten_close:1567234632905138206> You divorced recently. You must wait before remarrying (Cooldown ends <t:${untilSec}:R>).`
      });
    }

    // Check divorce cooldown for target
    const targetCooldown = db.prepare('SELECT until FROM divorce_cooldowns WHERE guild_id = ? AND user_id = ?').get(String(guildId), targetMember.id);
    if (targetCooldown && targetCooldown.until > now) {
      const untilSec = Math.floor(targetCooldown.until / 1000);
      return message.reply({
        content: `<a:tungsten_close:1567234632905138206> <@${targetMember.id}> divorced recently and is on a remarry cooldown until <t:${untilSec}:R>.`
      });
    }

    // Check if author is already married
    const authorMarriage = db.prepare(`
      SELECT * FROM marriages
      WHERE guild_id = ? AND (user1_id = ? OR user2_id = ?)
    `).get(String(guildId), message.author.id, message.author.id);

    if (authorMarriage) {
      const partnerId = authorMarriage.user1_id === message.author.id ? authorMarriage.user2_id : authorMarriage.user1_id;
      return message.reply({
        content: `<a:tungsten_close:1567234632905138206> You are already married to <@${partnerId}>! You must divorce first before marrying someone else.`
      });
    }

    // Check if target is already married
    const targetMarriage = db.prepare(`
      SELECT * FROM marriages
      WHERE guild_id = ? AND (user1_id = ? OR user2_id = ?)
    `).get(String(guildId), targetMember.id, targetMember.id);

    if (targetMarriage) {
      const partnerId = targetMarriage.user1_id === targetMember.id ? targetMarriage.user2_id : targetMarriage.user1_id;
      return message.reply({
        content: `<a:tungsten_close:1567234632905138206> <@${targetMember.id}> is already married to <@${partnerId}>!`
      });
    }

    const acceptId = `marry_acc_${message.author.id}_${targetMember.id}`;
    const declineId = `marry_dec_${message.author.id}_${targetMember.id}`;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(acceptId).setLabel('Accept Proposal').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(declineId).setLabel('Decline').setStyle(ButtonStyle.Danger)
    );

    const proposalCard = createV2Card({
      title: '<a:tungsten_marriage:1569329446325063725>  Marriage Proposal!',
      color: 0xEB459E, // Romantic pink
      description:
        `Hey <@${targetMember.id}>!\n\n` +
        `**<@${message.author.id}>** has fallen head over heels and is asking for your hand in marriage!\n\n` +
        `Will you accept and become their beloved partner in **${message.guild.name}**?\n\n` +
        `-# Click a button below within **60 seconds** to respond.`,
      buttons: [
        { label: 'Accept Proposal', style: ButtonStyle.Success },
        { label: 'Decline', style: ButtonStyle.Danger }
      ],
      buttonTitle: 'Proposal Response'
    });

    const proposalMsg = await message.reply({ embeds: [proposalCard], components: [row] });

    try {
      const filter = i => i.user.id === targetMember.id && (i.customId === acceptId || i.customId === declineId);
      const interaction = await proposalMsg.awaitMessageComponent({ filter, time: 60000 });

      if (interaction.customId === acceptId) {
        // Re-check statuses in case of race condition
        const freshAuthorMarriage = db.prepare('SELECT * FROM marriages WHERE guild_id = ? AND (user1_id = ? OR user2_id = ?)').get(String(guildId), message.author.id, message.author.id);
        const freshTargetMarriage = db.prepare('SELECT * FROM marriages WHERE guild_id = ? AND (user1_id = ? OR user2_id = ?)').get(String(guildId), targetMember.id, targetMember.id);

        if (freshAuthorMarriage || freshTargetMarriage) {
          return interaction.update({
            embeds: [createV2Card({
              title: '<a:tungsten_close:1567234632905138206> Proposal Void',
              color: 0xED4245,
              description: 'One of the participants is already married!'
            })],
            components: []
          });
        }

        const marriedAt = Date.now();
        db.prepare(`
          INSERT INTO marriages (guild_id, user1_id, user2_id, married_at)
          VALUES (?, ?, ?, ?)
        `).run(String(guildId), message.author.id, targetMember.id, marriedAt);

        const celebrationCard = createV2Card({
          title: '<a:tungsten_marriage:1569329446325063725>  THEY SAID YES!',
          color: 0x57F287,
          description:
            `<a:tungsten_party:1567241769593339988> Hear ye, hear ye! By the power vested in Tungsten, **<@${message.author.id}>** and **<@${targetMember.id}>** are now happily married!\n\n` +
            `• **Wedding Date**: <t:${Math.floor(marriedAt / 1000)}:F>\n` +
            `• Wishing both of you infinite joy and harmony together! <a:tungsten_hearts:1567240511670976552>\n\n` +
            `-# Check the server couples leaderboard anytime with \`${prefix}couples\`.`,
          footerText: 'Happily Married • Tungsten Social'
        });

        return interaction.update({ embeds: [celebrationCard], components: [] });
      } else {
        const declinedCard = createV2Card({
          title: '<a:tungsten_heart_broken:1567240285053001738>  Proposal Declined',
          color: 0xED4245,
          description: `<@${targetMember.id}> has gently declined the proposal from <@${message.author.id}>. There are plenty of fish in the sea!`
        });
        return interaction.update({ embeds: [declinedCard], components: [] });
      }
    } catch (err) {
      if (err?.message?.includes('Timeout in fuzzer mock')) return;
      await proposalMsg.edit({
        embeds: [createV2Card({
          title: '<a:tungsten_clock:1567234623216554118>  Proposal Expired',
          color: 0x2b2d31,
          description: `The proposal from <@${message.author.id}> to <@${targetMember.id}> timed out with no answer.`
        })],
        components: []
      }).catch(() => null);
    }
  }
};
