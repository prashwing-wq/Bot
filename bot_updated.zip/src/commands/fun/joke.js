/**
 * Joke Entertainment Command (Node.js)
 */
const { createEmbed } = require('../../utils/tools');

const JOKES = [
  "Why do programmers prefer dark mode? Because light attracts bugs!",
  "There are 10 types of people in the world: those who understand binary, and those who don't.",
  "Why do Java developers wear glasses? Because they don't C#!",
  "A SQL query walks into a bar, walks up to two tables and asks, 'Can I join you?'",
  "How many programmers does it take to change a light bulb? None, that's a hardware problem.",
  "Why did the developer go broke? Because he used up all his cache.",
  "An optimist says the glass is half full. A pessimist says the glass is half empty. A programmer says the glass is twice as large as necessary."
];

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'joke',
  category: 'fun',
  description: 'Tells a random funny joke.',
  usage: '',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const joke = JOKES[Math.floor(Math.random() * JOKES.length)];

    const embed = createEmbed({
      color: 0xFEE75C,
      title: '😂  Tungsten Joke Vault',
      description: `> *${joke}*`
    });

    return message.reply({ embeds: [embed] });
  }
};
