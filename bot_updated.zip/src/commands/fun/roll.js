/**
 * Roll Command
 * Roll a dice (default 1-6 or 1-N)
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'roll',
  description: 'Roll a random number or dice (e.g. 6, 20, 100).',
  category: 'fun',
  usage: 'roll [max_number]',
  aliases: ['dice'],
  cooldown: 2,

  async execute(message, args, client, prefix) {
    let max = 6;
    if (args[0]) {
      const parsed = parseInt(args[0], 10);
      if (!isNaN(parsed) && parsed > 1 && parsed <= 1000000) {
        max = parsed;
      }
    }

    const result = Math.floor(Math.random() * max) + 1;

    const embed = createEmbed({
      color: client.config.COLORS.PRIMARY,
      title: '<a:tungsten_dice:1567238580827328582> Dice Roll',
      description: `You rolled a **${result}** (1-${max})!`,
      footer: `Rolled by ${message.author.tag}`
    });

    return message.reply({ embeds: [embed] });
  }
};
