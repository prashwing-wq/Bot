/**
 * Love Compatibility & Ship Command (Node.js)
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'ship',
  aliases: ['love', 'match'],
  category: 'fun',
  description: 'Calculate love compatibility between two server members.',
  usage: '<@user1> [@user2]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const mentions = message.mentions.users;
    let u1, u2;

    if (mentions.size >= 2) {
      const arr = Array.from(mentions.values());
      u1 = arr[0];
      u2 = arr[1];
    } else if (mentions.size === 1) {
      u1 = message.author;
      u2 = mentions.first();
    } else {
      return message.reply(`<a:tungsten_close:1567234632905138206> Please mention at least one member to ship: \`${prefix}ship @user\``);
    }

    if (u1.id === u2.id) {
      return message.reply('💞 Self-love is the highest form of love, but you cannot ship yourself with yourself!');
    }

    // Deterministic percentage based on user IDs
    const seed = (BigInt(u1.id) + BigInt(u2.id)) % 101n;
    const percentage = Number(seed);

    let progressEmoji = '💔';
    let comment = 'A disaster waiting to happen.';
    if (percentage >= 90) {
      progressEmoji = '💖 💍';
      comment = 'Soulmates destined by the stars!';
    } else if (percentage >= 70) {
      progressEmoji = '❤️ 💕';
      comment = 'A match made in heaven!';
    } else if (percentage >= 50) {
      progressEmoji = '💛 ✨';
      comment = 'Good chemistry! Worth a shot!';
    } else if (percentage >= 30) {
      progressEmoji = '🧡 💨';
      comment = 'Just friends for now...';
    }

    const filled = Math.round(percentage / 10);
    const empty = 10 - filled;
    const bar = '█'.repeat(filled) + '░'.repeat(empty);

    const embed = createEmbed({
      color: percentage >= 50 ? 0xFF69B4 : 0x555555,
      title: '💞  Love Compatibility Radar',
      description:
        `> **${u1.username}** + **${u2.username}**\n\n` +
        `**Compatibility:** **${percentage}%**\n` +
        `\`[${bar}]\` ${progressEmoji}\n\n` +
        `*${comment}*`
    });

    return message.reply({ embeds: [embed] });
  }
};
