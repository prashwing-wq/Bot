/**
 * Fakeban Command (Node.js)
 * Broadcasts a hyper-realistic fake ban announcement for server amusement.
 */
const { createEmbed } = require('../../utils/tools');
const { resolveEmoji } = require('../../utils/emojis');
const { resolveTargetUser } = require('../../utils/rateHelper');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'fakeban',
  aliases: ['fban', 'mockban'],
  category: 'fun',
  description: 'Simulates a hyper-realistic ban announcement for a server member.',
  usage: '<@user|id> [reason]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!args || args.length === 0) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Please specify a user to fake ban! Usage: \`${prefix}fakeban <@user|id> [reason]\``);
    }

    const target = resolveTargetUser(message, args);
    let reason = 'Violating the vibes of the server (Fake Ban)';

    // Parse reason if arguments beyond mention were given
    if (args.length > 1) {
      const rest = args.slice(1).join(' ').trim();
      if (rest) reason = rest;
    }

    const hammerEmoji = resolveEmoji(client, 'tungsten_hammer') || '🔨';

    const embed = createEmbed({
      color: 0xED4245,
      title: `${hammerEmoji}  User Banned`,
      description: `**${target.username}** has been permanently banned from **${message.guild?.name || 'the server'}**!`,
      fields: [
        {
          name: '👤 Target',
          value: `${target.username} (<@${target.id}>)`,
          inline: true
        },
        {
          name: '🛡️ Moderator',
          value: `${message.author.username} (<@${message.author.id}>)`,
          inline: true
        },
        {
          name: '⏱️ Duration',
          value: '`Permanent`',
          inline: true
        },
        {
          name: '📋 Reason',
          value: reason,
          inline: false
        }
      ],
      footer: 'Notice: This is a simulated fake ban for entertainment purposes only.'
    });

    return message.reply({ embeds: [embed] });
  }
};
