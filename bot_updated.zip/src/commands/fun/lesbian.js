/**
 * Lesbian Rate Command (Node.js)
 * Calculates a member's lesbian rating percentage for the day.
 */
const { createRateCommand } = require('../../utils/rateHelper');
const { EMOJIS } = require('../../utils/emojis');

module.exports = createRateCommand({
  name: 'lesbian',
  aliases: ['lesbianrate'],
  title: 'Lesbian Rate Machine',
  type: 'lesbian',
  emoji: EMOJIS.USERS,
  color: 0xD35400,
  description: 'Calculates the lesbian rating for yourself or another member.',
  getComment(score) {
    if (score < 25) return `Not radiating lesbian energy today! ${EMOJIS.GEM_FLOWER || EMOJIS.SPARKLE}`;
    if (score < 50) return `Rocking the aesthetic! ${EMOJIS.FACE_COOL}`;
    if (score < 80) return `Girl in red playing on repeat! ${EMOJIS.MUSIC}`;
    return `Absolute Sapphic Royalty! ${EMOJIS.HEARTS} ${EMOJIS.CROWN}`;
  }
});
