/**
 * Tungsten Roleplay & Anime Actions Suite (Node.js)
 * Implements 22 anime roleplay actions with curated safe GIF telemetry,
 * interactive solo/target text formatting, and direct command dispatching.
 */
const { createEmbed } = require('../../utils/tools');
const { EMOJIS, resolveEmoji } = require('../../utils/emojis');
const { resolveTargetUser } = require('../../utils/rateHelper');

const ROLEPLAY_ACTIONS = {
  hug: {
    name: 'hug',
    label: 'Hug',
    emoji: EMOJIS.HEARTS,
    color: 0xFF69B4,
    description: 'Give someone or yourself a warm and comforting hug.',
    targetText: (author, target) => `**${author.username}** hugged **${target.username}**!`,
    selfText: (author) => `**${author.username}** hugged themselves tightly!`,
    soloText: (author) => `**${author.username}** is looking for a warm hug...`,
    gifs: [
      'https://media.tenor.com/kCZGkONXQW0AAAAC/anime-hug.gif',
      'https://media.tenor.com/G_vlcbZFiqwAAAAC/anime-hug.gif',
      'https://media.tenor.com/2lrFL0mkoW8AAAAC/anime-hug.gif'
    ]
  },
  kiss: {
    name: 'kiss',
    label: 'Kiss',
    emoji: EMOJIS.HEART,
    color: 0xE91E63,
    description: 'Blow a kiss or kiss someone tenderly.',
    targetText: (author, target) => `**${author.username}** kissed **${target.username}**!`,
    selfText: (author) => `**${author.username}** kisses their own hand gently!`,
    soloText: (author) => `**${author.username}** blows a sweet kiss to everyone!`,
    gifs: [
      'https://media.tenor.com/eldfvkY3MTUAAAAC/anime-kiss.gif',
      'https://media.tenor.com/wDYtbHAyvu4AAAAC/anime-kiss.gif',
      'https://media.tenor.com/I83WJ7-2CcwAAAAC/anime-kiss.gif'
    ]
  },
  pat: {
    name: 'pat',
    label: 'Headpat',
    aliases: ['headpat'],
    emoji: EMOJIS.SPARKLES,
    color: 0x3498DB,
    description: 'Pat someone gently on the head.',
    targetText: (author, target) => `**${author.username}** gently patted **${target.username}** on the head!`,
    selfText: (author) => `**${author.username}** pats their own head for doing a good job!`,
    soloText: (author) => `**${author.username}** looks around gently looking for someone to pat!`,
    gifs: [
      'https://media.tenor.com/E6fMkQRZBdIAAAAC/anime-pat.gif',
      'https://media.tenor.com/Y7B6n_z_v3wAAAAC/anime-pat.gif',
      'https://media.tenor.com/dm9CP7vxm18AAAAC/anime-head-pat.gif'
    ]
  },
  cuddle: {
    name: 'cuddle',
    label: 'Cuddle',
    emoji: EMOJIS.PET,
    color: 0xF39C12,
    description: 'Cuddle up closely with someone.',
    targetText: (author, target) => `**${author.username}** cuddled up affectionately with **${target.username}**!`,
    selfText: (author) => `**${author.username}** cuddles up in a cozy warm blanket!`,
    soloText: (author) => `**${author.username}** is craving warm and cozy cuddles!`,
    gifs: [
      'https://media.tenor.com/7oWqXo46n0UAAAAC/anime-cuddle.gif',
      'https://media.tenor.com/xT073a-4WVIAAAAC/anime-cuddle.gif',
      'https://media.tenor.com/kCzGkONXQW0AAAAC/anime-cuddle.gif'
    ]
  },
  slap: {
    name: 'slap',
    label: 'Slap',
    emoji: EMOJIS.EXPLOSION,
    color: 0xE74C3C,
    description: 'Deliver an anime slap across the face.',
    targetText: (author, target) => `**${author.username}** slapped **${target.username}** right across the face!`,
    selfText: (author) => `**${author.username}** facepalms and slaps their own forehead!`,
    soloText: (author) => `**${author.username}** is itching to slap someone!`,
    gifs: [
      'https://media.tenor.com/PeJyXyZA89sq/anime-slap.gif',
      'https://media.tenor.com/Ws6Dm1ZW_vMAAAAC/anime-slap.gif',
      'https://media.tenor.com/XiYuXnTIOtAAAAAC/anime-slap.gif'
    ]
  },
  tickle: {
    name: 'tickle',
    label: 'Tickle',
    emoji: EMOJIS.HANDS_UP,
    color: 0x9B59B6,
    description: 'Tickle someone until they burst into laughter.',
    targetText: (author, target) => `**${author.username}** tickled **${target.username}** relentlessly!`,
    selfText: (author) => `**${author.username}** tickles themselves and giggles uncontrollably!`,
    soloText: (author) => `**${author.username}** wiggles their fingers ready to tickle!`,
    gifs: [
      'https://media.tenor.com/hU6u9-n1jKwAAAAC/anime-tickle.gif',
      'https://media.tenor.com/13_Rz91U7_IAAAAC/anime-tickle.gif',
      'https://media.tenor.com/97-4N0o32gAAAAAC/anime-tickle.gif'
    ]
  },
  spank: {
    name: 'spank',
    label: 'Spank',
    emoji: EMOJIS.SWORDS,
    color: 0x8E44AD,
    description: 'Deliver a playful spank to someone.',
    targetText: (author, target) => `**${author.username}** gave **${target.username}** a playful spank!`,
    selfText: (author) => `**${author.username}** spanks the air dramatically!`,
    soloText: (author) => `**${author.username}** holds up a squeaky paddle menacingly!`,
    gifs: [
      'https://media.tenor.com/Sp1pC_L1a0kAAAAC/anime-spank.gif',
      'https://media.tenor.com/9dc5Qe_7tLgAAAAC/anime-spank.gif',
      'https://media.tenor.com/mZ6P1q9G9QAAAAAC/anime-spank.gif'
    ]
  },
  kill: {
    name: 'kill',
    label: 'Anime Duel',
    aliases: ['defeat'],
    emoji: EMOJIS.SWORDS,
    color: 0x2C3E50,
    description: 'Defeat someone in an epic anime duel.',
    targetText: (author, target) => `**${author.username}** defeated **${target.username}** in an epic anime duel!`,
    selfText: (author) => `**${author.username}** collapses dramatically from extreme cringe!`,
    soloText: (author) => `**${author.username}** unsheathes an anime katana looking for a challenge!`,
    gifs: [
      'https://media.tenor.com/n3kU2sYqPNEAAAAC/anime-kill.gif',
      'https://media.tenor.com/xUOxeZUc8UFAAAAd/anime-shoot.gif',
      'https://media.tenor.com/l4FGpL3d47HAAAAd/anime-stab.gif'
    ]
  },
  poke: {
    name: 'poke',
    label: 'Poke',
    emoji: EMOJIS.POINT,
    color: 0x1ABC9C,
    description: 'Poke someone to grab their attention.',
    targetText: (author, target) => `**${author.username}** poked **${target.username}** playfully!`,
    selfText: (author) => `**${author.username}** pokes their own cheek wondering about life!`,
    soloText: (author) => `**${author.username}** pokes around inquisitively looking for someone!`,
    gifs: [
      'https://media.tenor.com/Jv7k2-9HwR8AAAAd/anime-poke.gif',
      'https://media.tenor.com/3ACfV1s692wAAAAC/anime-poke.gif',
      'https://media.tenor.com/5V44r4R8u8AAAAAC/anime-poke.gif'
    ]
  },
  highfive: {
    name: 'highfive',
    label: 'High Five',
    aliases: ['hfive'],
    emoji: EMOJIS.HANDS_UP,
    color: 0x2ECC71,
    description: 'Give someone an enthusiastic high five.',
    targetText: (author, target) => `**${author.username}** high-fived **${target.username}** with excitement!`,
    selfText: (author) => `**${author.username}** high-fives their reflection in the mirror!`,
    soloText: (author) => `**${author.username}** leaves their hand raised waiting for a high five!`,
    gifs: [
      'https://media.tenor.com/V0jE0jG8uLIAAAAC/anime-highfive.gif',
      'https://media.tenor.com/L44sL-R0LOUAAAAC/anime-high-five.gif',
      'https://media.tenor.com/q2A6q1A2qXwAAAAC/anime-highfive.gif'
    ]
  },
  bite: {
    name: 'bite',
    label: 'Bite',
    emoji: EMOJIS.TOOTH,
    color: 0xD35400,
    description: 'Take a soft, playful anime bite.',
    targetText: (author, target) => `**${author.username}** took a playful bite out of **${target.username}**!`,
    selfText: (author) => `**${author.username}** nibbles on a tasty snack!`,
    soloText: (author) => `**${author.username}** reveals their cute anime fangs!`,
    gifs: [
      'https://media.tenor.com/pXv9j7O-XW8AAAAC/anime-bite.gif',
      'https://media.tenor.com/07D6t8xT1P0AAAAC/anime-bite.gif',
      'https://media.tenor.com/e2e5W7E5aX4AAAAC/anime-bite.gif'
    ]
  },
  bonk: {
    name: 'bonk',
    label: 'Bonk',
    emoji: EMOJIS.HAMMER,
    color: 0xE67E22,
    description: 'Bonk someone on the head into horny jail.',
    targetText: (author, target) => `**${author.username}** bonked **${target.username}** on the head! Go to horny jail!`,
    selfText: (author) => `**${author.username}** bonks themselves with a squeaky toy hammer!`,
    soloText: (author) => `**${author.username}** waves a giant squeaky bonk hammer!`,
    gifs: [
      'https://media.tenor.com/6a42QGMAACQAAAAC/anime-punch.gif',
      'https://media.tenor.com/U8991XUff5YAAAAC/anime-bonk.gif',
      'https://media.tenor.com/3k1A4q0d8WwAAAAC/anime-bonk.gif'
    ]
  },
  punch: {
    name: 'punch',
    label: 'Punch',
    emoji: EMOJIS.FIST,
    color: 0xC0392B,
    description: 'Throw a powerful anime punch.',
    targetText: (author, target) => `**${author.username}** punched **${target.username}** with full anime power!`,
    selfText: (author) => `**${author.username}** shadow-boxes like an undefeated boxing champion!`,
    soloText: (author) => `**${author.username}** practices swift punch combinations in the air!`,
    gifs: [
      'https://media.tenor.com/6a42QGMAACQAAAAC/anime-punch.gif',
      'https://media.tenor.com/Ev1E2q2P43cAAAAC/anime-punch.gif',
      'https://media.tenor.com/o2kLq8K2yXQAAAAC/anime-punch.gif'
    ]
  },
  stare: {
    name: 'stare',
    label: 'Stare',
    emoji: EMOJIS.EYES,
    color: 0x16A085,
    description: 'Stare deeply at someone or into the void.',
    targetText: (author, target) => `**${author.username}** stared intently into **${target.username}**'s eyes...`,
    selfText: (author) => `**${author.username}** stares deeply into the mirror...`,
    soloText: (author) => `**${author.username}** stares blankly into the cosmic void...`,
    gifs: [
      'https://media.tenor.com/3o7TKTDnUxEAAAAd/anime-stare.gif',
      'https://media.tenor.com/4WJ7e8x4k4sAAAAC/anime-stare.gif',
      'https://media.tenor.com/8Q9Z4Q1YqXIAAAAC/anime-stare.gif'
    ]
  },
  wave: {
    name: 'wave',
    label: 'Wave',
    emoji: EMOJIS.WAVE,
    color: 0x3498DB,
    description: 'Wave enthusiastically at someone or everyone.',
    targetText: (author, target) => `**${author.username}** waved enthusiastically at **${target.username}**!`,
    selfText: (author) => `**${author.username}** waves at their own shadow!`,
    soloText: (author) => `**${author.username}** waves hello to everyone! ${EMOJIS.WAVE}`,
    gifs: [
      'https://media.tenor.com/0oQZq2z5vDkAAAAd/anime-wave.gif',
      'https://media.tenor.com/1mO5O98LpsUAAAAC/anime-wave.gif',
      'https://media.tenor.com/3Z4M5L2PqXwAAAAC/anime-wave.gif'
    ]
  },
  smug: {
    name: 'smug',
    label: 'Smug',
    emoji: EMOJIS.FACE_COOL,
    color: 0xF1C40F,
    description: 'Show off your smug anime expression.',
    targetText: (author, target) => `**${author.username}** gives **${target.username}** an overwhelmingly smug smirk!`,
    selfText: (author) => `**${author.username}** smiles smugly at their own genius!`,
    soloText: (author) => `**${author.username}** smirks with extreme smugness... ${EMOJIS.FACE_COOL}`,
    gifs: [
      'https://media.tenor.com/k2H1z99q6i8AAAAC/anime-smug.gif',
      'https://media.tenor.com/5V33m2-R1eIAAAAd/anime-smug.gif',
      'https://media.tenor.com/8K2P4Q1YqXIAAAAC/anime-smug.gif'
    ]
  },
  yeet: {
    name: 'yeet',
    label: 'Yeet',
    emoji: EMOJIS.ROCKET,
    color: 0x9B59B6,
    description: 'Yeet someone straight into outer orbit.',
    targetText: (author, target) => `**${author.username}** yeeted **${target.username}** directly into deep space!`,
    selfText: (author) => `**${author.username}** yeeted themselves into hyperspace!`,
    soloText: (author) => `**${author.username}** prepares to yeet something into orbit! ${EMOJIS.ROCKET}`,
    gifs: [
      'https://media.tenor.com/oV3P92-d6ZIAAAAd/anime-yeet.gif',
      'https://media.tenor.com/zXmCgM1gXgIAAAAC/anime-kick.gif',
      'https://media.tenor.com/4M7q8kM4fV4AAAAC/anime-yeet.gif'
    ]
  },
  dance: {
    name: 'dance',
    label: 'Dance',
    emoji: EMOJIS.DANCER,
    color: 0x1ABC9C,
    description: 'Bust a move or dance joyfully with someone.',
    targetText: (author, target) => `**${author.username}** is dancing joyfully with **${target.username}**!`,
    selfText: (author) => `**${author.username}** dances with pure happiness and joy!`,
    soloText: (author) => `**${author.username}** dances with joy! ${EMOJIS.DANCER}`,
    gifs: [
      'https://media.tenor.com/u5k6a2V9z2IAAAAC/anime-dance.gif',
      'https://media.tenor.com/8QG1kO9_dGgAAAAC/anime-dance.gif',
      'https://media.tenor.com/2P4M5L2PqXwAAAAC/anime-dance.gif'
    ]
  },
  handhold: {
    name: 'handhold',
    label: 'Hold Hands',
    aliases: ['holdhands'],
    emoji: EMOJIS.HANDSHAKE,
    color: 0xFF69B4,
    description: 'Hold hands tenderly with someone.',
    targetText: (author, target) => `**${author.username}** held **${target.username}**'s hand tenderly!`,
    selfText: (author) => `**${author.username}** holds their own hands together hoping for the best!`,
    soloText: (author) => `**${author.username}** reaches out a gentle hand seeking warmth!`,
    gifs: [
      'https://media.tenor.com/11s7Ke7jcNxAAAAC/anime-handhold.gif',
      'https://media.tenor.com/4M7q8kM4fV4AAAAC/anime-handhold.gif',
      'https://media.tenor.com/6K2P4Q1YqXIAAAAC/anime-handhold.gif'
    ]
  },
  cry: {
    name: 'cry',
    label: 'Cry',
    emoji: EMOJIS.FACE_CRY,
    color: 0x3498DB,
    description: 'Cry tears of sadness or emotion.',
    targetText: (author, target) => `**${author.username}** is crying on **${target.username}**'s shoulder! ${EMOJIS.FACE_CRY}`,
    selfText: (author) => `**${author.username}** cries quietly alone...`,
    soloText: (author) => `**${author.username}** is crying... ${EMOJIS.FACE_CRY}`,
    gifs: [
      'https://media.tenor.com/5G_1x_p00C0AAAAC/anime-cry.gif',
      'https://media.tenor.com/bK0a2V0dM8IAAAAC/anime-cry.gif',
      'https://media.tenor.com/1P4M5L2PqXwAAAAC/anime-cry.gif'
    ]
  },
  lappillow: {
    name: 'lappillow',
    label: 'Lap Pillow',
    aliases: ['pillow'],
    emoji: EMOJIS.ZZZ,
    color: 0x95A5A6,
    description: 'Rest your head on someone\'s lap for a peaceful nap.',
    targetText: (author, target) => `**${author.username}** rested their head gently on **${target.username}**'s lap!`,
    selfText: (author) => `**${author.username}** rests their head on a super soft fluffy pillow!`,
    soloText: (author) => `**${author.username}** is looking for a comforting lap pillow to nap on!`,
    gifs: [
      'https://media.tenor.com/81Y7y6qK4gUAAAAC/anime-lap-pillow.gif',
      'https://media.tenor.com/mguPrVJAnEHAAAAd/anime-sleep.gif',
      'https://media.tenor.com/7K2P4Q1YqXIAAAAC/anime-pillow.gif'
    ]
  },
  happy: {
    name: 'happy',
    label: 'Happy',
    emoji: EMOJIS.SPARKLES,
    color: 0xF39C12,
    description: 'Express your pure, radiating happiness.',
    targetText: (author, target) => `**${author.username}** is sharing their pure happiness with **${target.username}**!`,
    selfText: (author) => `**${author.username}** is bursting with complete happiness!`,
    soloText: (author) => `**${author.username}** is filled with happiness! ${EMOJIS.SPARKLES}`,
    gifs: [
      'https://media.tenor.com/8Y-x85P6VfwAAAAC/anime-smile.gif',
      'https://media.tenor.com/u5k6a2V9z2IAAAAC/anime-dance.gif',
      'https://media.tenor.com/0oQZq2z5vDkAAAAd/anime-wave.gif'
    ]
  }
};

function createRoleplayCommand(verbName) {
  const action = ROLEPLAY_ACTIONS[verbName.toLowerCase()];
  if (!action) {
    throw new Error(`Unknown roleplay verb: ${verbName}`);
  }

  return {
    permissions: [],
    botPermissions: ['SendMessages', 'EmbedLinks'],
    name: action.name,
    category: 'fun',
    description: action.description,
    usage: '[@user|username]',
    aliases: action.aliases || [],
    cooldown: 2,

    async execute(message, args, client, prefix) {
      let descriptionText = '';
      const hasTarget = (message.mentions && message.mentions.users && message.mentions.users.size > 0) || (args && args.length > 0);

      if (hasTarget) {
        const target = resolveTargetUser(message, args);
        if (target.id === message.author.id) {
          descriptionText = action.selfText(message.author);
        } else {
          descriptionText = action.targetText(message.author, target);
        }
      } else {
        descriptionText = action.soloText(message.author);
      }

      const randomGif = action.gifs[Math.floor(Math.random() * action.gifs.length)];

      const embed = createEmbed({
        color: action.color || (client?.config?.COLORS?.INFO || 0xFF69B4),
        description: `> ${action.emoji}  ${descriptionText}`,
        image: randomGif,
        footer: `Tungsten Anime Roleplay • Requested by ${message.author.tag}`
      });

      return message.reply({ embeds: [embed] });
    }
  };
}

// Master Roleplay Hub Command
const roleplayMasterCommand = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'roleplay',
  aliases: ['rp', 'action', 'act'],
  category: 'fun',
  description: 'Tungsten Anime Roleplay Hub — interact with 22 expressive anime actions.',
  usage: '[action] [@user]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (args && args.length > 0) {
      const subAction = args[0].toLowerCase();
      if (ROLEPLAY_ACTIONS[subAction]) {
        const handler = createRoleplayCommand(subAction);
        return handler.execute(message, args.slice(1), client, prefix);
      }
    }

    const affectionList = ['hug', 'kiss', 'pat', 'cuddle', 'handhold', 'lappillow'].map(a => `\`${prefix}${a}\``).join(' ');
    const combatPlayList = ['slap', 'tickle', 'spank', 'kill', 'poke', 'highfive', 'bite', 'bonk', 'punch', 'yeet'].map(a => `\`${prefix}${a}\``).join(' ');
    const emotionList = ['stare', 'wave', 'smug', 'dance', 'cry', 'happy'].map(a => `\`${prefix}${a}\``).join(' ');

    const embed = createEmbed({
      color: 0xFF69B4,
      title: `${EMOJIS.DRAMA}  Tungsten Anime Roleplay Suite`,
      description: 'Express your feelings and interact with server members using high quality animated GIFs!\n\nUsage: `<action> [@user]` or `roleplay <action> [@user]`',
      fields: [
        {
          name: `${EMOJIS.HEART} Affection Actions`,
          value: affectionList,
          inline: false
        },
        {
          name: `${EMOJIS.SWORDS} Playful & Combat Actions`,
          value: combatPlayList,
          inline: false
        },
        {
          name: `${EMOJIS.SPARKLES} Emotional & Expressive Actions`,
          value: emotionList,
          inline: false
        }
      ],
      footer: 'Tungsten Roleplay Engine • 22 Expressive Actions'
    });

    return message.reply({ embeds: [embed] });
  }
};

roleplayMasterCommand.ROLEPLAY_ACTIONS = ROLEPLAY_ACTIONS;
roleplayMasterCommand.createRoleplayCommand = createRoleplayCommand;

module.exports = roleplayMasterCommand;
