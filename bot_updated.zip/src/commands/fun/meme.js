/**
 * Meme Command
 * Fetches funny curated and trending community memes
 */
const https = require('node:https');
const { createEmbed } = require('../../utils/tools');

const FALLBACK_MEMES = [
  {
    title: 'When your code works on the first try without errors',
    url: 'https://i.imgflip.com/1otk96.jpg'
  },
  {
    title: 'Migrating from Python to Node.js in one weekend',
    url: 'https://i.imgflip.com/26amjh.jpg'
  },
  {
    title: 'Checking the logs after deploying to production',
    url: 'https://i.imgflip.com/1g8my4.jpg'
  }
];

function fetchRedditMeme() {
  return new Promise((resolve) => {
    https.get('https://meme-api.com/gimme', { timeout: 3000 }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json && json.url && !json.nsfw) {
            return resolve({ title: json.title, url: json.url, author: json.author, subreddit: json.subreddit });
          }
        } catch (e) {}
        resolve(null);
      });
    }).on('error', () => resolve(null));
  });
}

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'meme',
  description: 'Displays a hilarious trending meme.',
  category: 'fun',
  usage: 'meme',
  aliases: ['memes'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    let memeData = await fetchRedditMeme();
    if (!memeData) {
      memeData = FALLBACK_MEMES[Math.floor(Math.random() * FALLBACK_MEMES.length)];
    }

    const embed = createEmbed({
      color: client.config.COLORS.PRIMARY,
      title: memeData.title || 'Meme of the Moment'
    });

    embed.setImage(memeData.url);
    if (memeData.subreddit) {
      embed.setFooter({ text: `r/${memeData.subreddit} • Requested by ${message.author.tag}` });
    } else {
      embed.setFooter({ text: `Requested by ${message.author.tag}` });
    }

    return message.reply({ embeds: [embed] });
  }
};
