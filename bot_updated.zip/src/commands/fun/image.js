/**
 * Image Search Command (Node.js)
 * Fetches high-definition imagery corresponding to a search term.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'image',
  aliases: ['img', 'searchimage', 'photo'],
  category: 'fun',
  description: 'Searches and returns high-definition imagery for a query.',
  usage: '<query>',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!args || args.length === 0) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Please provide an image query! Usage: \`${prefix}image <search term>\``);
    }

    const query = args.join(' ').trim();
    const sanitizedSeed = query.toLowerCase().replace(/[^a-z0-9]/g, '') || 'tungsten';
    const imageUrl = `https://picsum.photos/seed/${encodeURIComponent(sanitizedSeed)}/800/600`;

    const embed = createEmbed({
      color: client?.config?.COLORS?.INFO || 0x5865F2,
      title: `🖼️  Image Search: ${query}`,
      description: `> High-definition visual results for **"${query}"**`,
      image: imageUrl,
      footer: `Requested by ${message.author.tag} • Tungsten Visual Engine`
    });

    return message.reply({ embeds: [embed] });
  }
};
