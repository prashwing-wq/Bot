/**
 * Bot Owner Force Purge Command (Node.js)
 * Permanently disabled: Force purge without standard server permissions is disabled.
 */
module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'forcepurge',
  aliases: ['forcepurgebots', 'forcepurgeuser', 'fpurge'],
  category: 'owner',
  description: 'Force purge bot messages or target user messages in current channel.',
  usage: '<bots | user> [limit] [@user]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: Force purge without standard server permissions is disabled.');
  }
};
