/**
 * Bot Owner Freeze Nickname Command (Node.js)
 * Freezes a member's nickname in the current server so it cannot be altered.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'freezenick',
  aliases: ['unfreezenick', 'locknick', 'unlocknick'],
  category: 'owner',
  description: "Lock or unlock a member's nickname in the current server.",
  usage: '<@user | user_id> [nickname | clear]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'freezenick').toLowerCase();
    const isUnfreeze = invoked === 'unfreezenick' || invoked === 'unlocknick' || args[1]?.toLowerCase() === 'clear';

    const raw = args[0]?.replace(/[<@!>]/g, '');
    if (!raw) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}freezenick <@user> <nickname>\` or \`${prefix}unfreezenick <@user>\``);
    }

    const member = await message.guild.members.fetch(raw).catch(() => null);
    if (!member) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Member \`${raw}\` not found in this server.`);
    }

    const sdb = getServerDb(message.guild.id);
    sdb.prepare(`
      CREATE TABLE IF NOT EXISTS frozen_nicknames (
        guild_id TEXT,
        user_id TEXT,
        nickname TEXT,
        PRIMARY KEY (guild_id, user_id)
      )
    `).run();

    if (isUnfreeze) {
      sdb.prepare('DELETE FROM frozen_nicknames WHERE guild_id = ? AND user_id = ?').run(message.guild.id, member.id);
      return message.reply(`<a:tungsten_success:1567242523468890274> Unfroze nickname for <@${member.id}>.`);
    }

    const nickname = args.slice(1).join(' ').trim() || member.displayName;

    try {
      await member.setNickname(nickname, `[Frozen Nickname] by Bot Owner ${message.author.tag}`);
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to set nickname: ${e.message} (Role hierarchy check required).`);
    }

    sdb.prepare(`
      INSERT INTO frozen_nicknames (guild_id, user_id, nickname)
      VALUES (?, ?, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET nickname = excluded.nickname
    `).run(message.guild.id, member.id, nickname);

    return message.reply(`<a:tungsten_success:1567242523468890274> Nickname for <@${member.id}> has been frozen as: **${nickname}**.`);
  }
};
