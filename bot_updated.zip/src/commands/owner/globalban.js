/**
 * Bot Owner Global Ban / Unban Command (Node.js)
 * Bans or unbans a dangerous attacker across all mutual servers where the bot has ban permissions.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { getMasterDb, getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'globalban',
  aliases: ['gban', 'gunban', 'globalunban'],
  category: 'owner',
  description: 'Ban or unban a user across all mutual servers in the bot fleet.',
  usage: '<@user | user_id> [reason]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'globalban').toLowerCase();
    const isUnban = invoked === 'gunban' || invoked === 'globalunban' || args[0]?.toLowerCase() === 'unban';

    const raw = (isUnban && args[0]?.toLowerCase() === 'unban' ? args[1] : args[0])?.replace(/[<@!>]/g, '');
    const reasonArgs = isUnban && args[0]?.toLowerCase() === 'unban' ? args.slice(2) : args.slice(1);
    const reason = reasonArgs.join(' ') || (isUnban ? 'Global Unban by Bot Owner' : 'Severe terms of service violations & security threat');

    if (!raw) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}${invoked} <@user | user_id> [reason]\``);
    }

    const targetUser = await client.users.fetch(raw).catch(() => null);
    if (!targetUser) {
      return message.reply(`<a:tungsten_close:1567234632905138206> User not found: \`${raw}\``);
    }

    if (isOwner(targetUser.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Safety Lock: Cannot globally sanction another Bot Owner.');
    }

    const waitMsg = await message.reply(`<a:tungsten_refresh:1567241907116187658> Dispatching fleet-wide global ${isUnban ? 'unban' : 'ban'} for **${targetUser.tag}**...`);

    let successCount = 0;
    let failCount = 0;

    for (const guild of client.guilds.cache.values()) {
      try {
        const botMember = guild.members.me;
        if (!botMember || !botMember.permissions.has('BanMembers')) continue;

        if (isUnban) {
          await guild.bans.remove(targetUser.id, `[Global Unban] ${reason} (Executor: ${message.author.tag})`);
          successCount++;
        } else {
          await guild.bans.create(targetUser.id, {
            deleteMessageSeconds: 86400,
            reason: `[Global Ban] ${reason} (Executor: ${message.author.tag})`
          });
          successCount++;
        }
      } catch (e) {
        failCount++;
      }
    }

    // Save/update global ban in master database
    try {
      const mdb = getMasterDb();
      if (isUnban) {
        mdb.prepare('DELETE FROM global_bans WHERE user_id = ?').run(targetUser.id);
      } else {
        mdb.prepare(`
          INSERT INTO global_bans (user_id, banned_by, reason, banned_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(user_id) DO UPDATE SET reason = excluded.reason, banned_at = excluded.banned_at
        `).run(targetUser.id, message.author.id, reason, Math.floor(Date.now() / 1000));
      }
    } catch (e) {}

    const accent = getGuildAccent(message.guild?.id);
    const card = createV2Card({
      color: isUnban ? 0x2ecc71 : 0xe74c3c,
      title: `<a:tungsten_hammer:1567240140277944350>  Global ${isUnban ? 'Unban' : 'Ban'} Executed`,
      description:
        `> Target: **${targetUser.tag}** (\`${targetUser.id}\`)\n` +
        `• **Action:** ${isUnban ? '`GLOBAL UNBAN`' : '`GLOBAL BAN`'}\n` +
        `• **Successful Guilds:** \`${successCount}\`\n` +
        `• **Failed / Skipped:** \`${failCount}\`\n` +
        `• **Reason:** *${reason}*\n` +
        `• **Authorized By:** <@${message.author.id}>`,
      footerText: `Tungsten Global Fleet Enforcement`
    });

    return waitMsg.edit({ content: null, embeds: [card] });
  }
};
