/**
 * Bot Owner Direct Message Command (Node.js)
 * Transmits a direct message to any user in the Discord fleet.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'dm',
  aliases: ['owner_dm', 'directmessage'],
  category: 'owner',
  description: 'Transmit a direct message to a user on behalf of the bot.',
  usage: '<@user | user_id> <message>',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const raw = args[0] ? args[0].replace(/[<@!>]/g, '') : null;
    const dmContent = args.slice(1).join(' ').trim();

    if (!raw || !dmContent) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}dm <@user | user_id> <message>\``);
    }

    const targetUser = await client.users.fetch(raw).catch(() => null);
    if (!targetUser) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Target user not found: \`${raw}\``);
    }

    try {
      await targetUser.send(dmContent);
      return message.reply(`<a:tungsten_success:1567242523468890274> Successfully delivered DM to **${targetUser.tag}** (\`${targetUser.id}\`).`);
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to send DM to **${targetUser.tag}**: ${err.message}`);
    }
  }
};
