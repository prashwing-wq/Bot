/**
 * MongoDB Atlas Database Manager & Sync Command (Node.js)
 * Displays live Atlas connection metrics, collection counts, and allows triggering full DB push.
 * Strictly restricted to Bot Owners.
 */
const { SlashCommandBuilder } = require('discord.js');
const { isOwner, createEmbed } = require('../../utils/tools');
const { initMongo, pingMongo, isMongoConnected, getMongoDb } = require('../../utils/mongoClient');
const { pushAllDatabasesToMongo } = require('../../utils/mongoSync');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'mongo',
  aliases: ['mongodb', 'atlas'],
  category: 'owner',
  description: 'MongoDB Atlas cloud database telemetry and live database push.',
  usage: '[status | sync | stats]',
  ownerOnly: true,

  slash: new SlashCommandBuilder()
    .setName('mongo')
    .setDescription('MongoDB Atlas database manager and live synchronization')
    .addStringOption(opt =>
      opt.setName('action')
        .setDescription('Action to perform')
        .setRequired(false)
        .addChoices(
          { name: 'Status & Ping', value: 'status' },
          { name: 'Push All Databases', value: 'sync' },
          { name: 'Collection Stats', value: 'stats' }
        )
    ),

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('Access Denied: This command can be executed only by Bot Owner.');
    }

    const sub = (args[0] || 'status').toLowerCase();

    if (sub === 'sync' || sub === 'push') {
      const waitMsg = await message.reply('<a:tungsten_refresh:1567241907116187658> Connecting to MongoDB Atlas & initiating full database push...');
      try {
        const summary = await pushAllDatabasesToMongo();
        const embed = createEmbed()
          .setTitle('🍃 MongoDB Atlas Database Push Complete')
          .setDescription(
            `**Status:** Success\n` +
            `**Database:** \`${summary.databaseName}\`\n` +
            `**Master Tables:** \`${summary.masterTablesCount}\` (${summary.masterRowsCount} docs)\n` +
            `**Guild Databases:** \`${summary.guildsCount}\` (${summary.guildRowsCount} docs)\n` +
            `**Total Documents:** \`${summary.totalDocuments}\`\n` +
            `**Duration:** \`${(summary.durationMs / 1000).toFixed(2)}s\``
          );
        return waitMsg.edit({ content: null, embeds: [embed] });
      } catch (err) {
        return waitMsg.edit(`<a:tungsten_close:1567234632905138206> MongoDB Push Error: ${err.message}`);
      }
    }

    // Default: Status & Ping
    const waitMsg = await message.reply('<a:tungsten_refresh:1567241907116187658> Querying MongoDB Atlas telemetry...');
    try {
      if (!isMongoConnected()) {
        await initMongo();
      }

      const ping = await pingMongo();
      const db = getMongoDb();
      let collCount = 0;
      if (db) {
        const collections = await db.listCollections().toArray();
        collCount = collections.length;
      }

      const embed = createEmbed()
        .setTitle('🍃 MongoDB Atlas Telemetry')
        .setDescription(
          `**Cluster Status:** ${ping.ok ? '🟢 Connected' : '🔴 Disconnected'}\n` +
          `**Database:** \`${db ? db.databaseName : 'tungsten_bot'}\`\n` +
          `**Latency:** \`${ping.latencyMs ? ping.latencyMs + 'ms' : 'N/A'}\`\n` +
          `**Collections:** \`${collCount}\` active collections\n` +
          `**Replication:** Live Background Sync Active`
        )
        .setFooter({ text: `Usage: ${prefix}mongo sync to push all SQLite databases to Atlas` });

      return waitMsg.edit({ content: null, embeds: [embed] });
    } catch (err) {
      return waitMsg.edit(`<a:tungsten_close:1567234632905138206> MongoDB Telemetry Error: ${err.message}`);
    }
  }
};
