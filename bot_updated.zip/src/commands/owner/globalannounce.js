/**
 * Bot Owner Global Announcement Command (Node.js)
 * Broadcasts an announcement across all servers the bot is connected to.
 * Restricted to Bot Owners.
 */
const { ChannelType } = require('discord.js');
const { isOwner } = require('../../utils/tools');
const { getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'globalannounce',
  aliases: ['gannounce', 'globalbroadcast', 'gcast'],
  category: 'owner',
  description: 'Broadcast an announcement to all servers the bot is connected to.',
  usage: '<message>',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const broadcastMessage = args.join(' ').trim();
    if (!broadcastMessage) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}globalannounce <message>\``);
    }

    const waitMsg = await message.reply(`<a:tungsten_refresh:1567241907116187658> Dispatching global announcement to **${client.guilds.cache.size}** servers...`);

    let delivered = 0;
    let failed = 0;

    for (const guild of client.guilds.cache.values()) {
      try {
        const targetChannel = guild.systemChannel
          || guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.permissionsFor(guild.members.me)?.has('SendMessages'))
          || guild.channels.cache.find(c => c.isTextBased() && c.permissionsFor(guild.members.me)?.has('SendMessages'));

        if (!targetChannel) {
          failed++;
          continue;
        }

        const accent = getGuildAccent(guild.id);
        const card = createV2Card({
          color: accent,
          title: '<a:tungsten_siren:1567242157725712555>  Tungsten Network Announcement',
          description: broadcastMessage,
          footerText: `Official Broadcast • Authorized by Developer`
        });

        await targetChannel.send({ embeds: [card] });
        delivered++;
      } catch (e) {
        failed++;
      }
    }

    return waitMsg.edit(`<a:tungsten_success:1567242523468890274> Broadcast completed: Delivered to **${delivered}** servers (Failed/Skipped: ${failed}).`);
  }
};
