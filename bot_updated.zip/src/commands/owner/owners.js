/**
 * Bot Owners Directory Command (Node.js)
 * Displays hardcoded primary developers and registered bot owners in master.db.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { getMasterDb, getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');
const config = require('../../config');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'owners',
  aliases: ['ownerlist', 'botowners'],
  category: 'owner',
  description: 'View registered bot owners, primary developers, and application managers.',
  usage: '',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const mdb = getMasterDb();
    let dbOwnerRows = [];
    try {
      dbOwnerRows = mdb.prepare('SELECT user_id, added_at FROM bot_owners').all();
    } catch (e) {}

    const hardcoded = (config.OWNER_IDS || []).map(String);
    const allUnique = Array.from(new Set([...hardcoded, ...dbOwnerRows.map(r => String(r.user_id))]));

    const lines = allUnique.map((uid, i) => {
      const u = client.users.cache.get(uid);
      const tag = u ? `**${u.tag}**` : `User \`${uid}\``;
      const isDev = hardcoded.includes(uid) ? '*(Primary Super-Owner)*' : '*(Registered Owner)*';
      return `\`#${i + 1}\` <@${uid}> (${tag}) ${isDev}`;
    });

    const accent = getGuildAccent(message.guild?.id);
    const card = createV2Card({
      color: accent,
      title: '<a:tungsten_crown:1567238355463176334>  Bot Owners & Developer Directory',
      description:
        `> Complete executive registry authorized with full bot permissions.\n\n` +
        lines.join('\n') + '\n\n' +
        `-# Bot owners possess full bypass, database query rights, and global governance access.`,
      footerText: `Total Owners: ${allUnique.length}`
    });

    return message.reply({ embeds: [card] });
  }
};
