/**
 * Bot Owner Slash Tree Sync Command (Node.js)
 * Synchronizes application slash commands with Discord API globally or to current guild.
 * Restricted to Bot Owners.
 */
const { Routes } = require('discord.js');
const { isOwner } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'sync',
  aliases: ['treesync', 'slashsync'],
  category: 'owner',
  description: 'Force sync Discord application slash commands globally or to the current guild.',
  usage: '[guild | global]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const scope = args[0]?.toLowerCase() || 'global';
    const slashCommands = client.slashCommands || [];

    if (slashCommands.length === 0) {
      return message.reply('<a:tungsten_warn:1567246685082746940> No slash commands registered in client cache.');
    }

    const waitMsg = await message.reply(`<a:tungsten_refresh:1567241907116187658> Synchronizing **${slashCommands.length}** slash commands (${scope.toUpperCase()})...`);

    try {
      if (scope === 'guild' && message.guild) {
        await client.rest.put(Routes.applicationGuildCommands(client.user.id, message.guild.id), {
          body: slashCommands
        });
        return waitMsg.edit(`<a:tungsten_success:1567242523468890274> Successfully synchronized **${slashCommands.length}** slash commands to **${message.guild.name}**.`);
      } else {
        await client.rest.put(Routes.applicationCommands(client.user.id), {
          body: slashCommands
        });
        return waitMsg.edit(`<a:tungsten_success:1567242523468890274> Successfully deployed **${slashCommands.length}** slash commands globally across Discord.`);
      }
    } catch (err) {
      return waitMsg.edit(`<a:tungsten_close:1567234632905138206> Slash synchronization error: ${err.message}`);
    }
  }
};
