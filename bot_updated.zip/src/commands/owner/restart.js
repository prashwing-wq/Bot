/**
 * Bot Owner Client Restart Command (Node.js)
 * Cleanly saves WAL databases and restarts the process.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { getMasterDb } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'restart',
  aliases: ['tungsten.restart', 'reboot'],
  category: 'owner',
  description: 'Gracefully flushes SQLite databases and hot restarts the bot runtime.',
  usage: '',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    await message.reply('<a:tungsten_refresh:1567241907116187658> Checkpointing SQLite databases and initiating client restart...');

    try {
      const mdb = getMasterDb();
      mdb.exec('PRAGMA wal_checkpoint(TRUNCATE)');
    } catch (e) {}

    setTimeout(() => {
      process.exit(0);
    }, 1000);
  }
};
