/**
 * Bot Owner & Developer Command Center (Node.js)
 * Displays the complete developer suite matching Python cogs/commands/owner.py parity.
 * Strictly restricted to Bot Owners.
 */
const { isOwner, createEmbed } = require('../../utils/tools');
const { getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'ownerhelp',
  aliases: ['owner.help', 'ownercmds', 'ownercommands', 'ophelp', 'devhelp'],
  category: 'owner',
  description: 'Displays the complete developer & bot owner executive command suite.',
  usage: '',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const accent = getGuildAccent(message.guild?.id);
    const card = createV2Card({
      color: accent,
      title: '👑  Tungsten • Bot Owner & Developer Commands',
      description:
        `> Executive governance, fleet management, and deep runtime diagnostics.\n\n` +
        `**Bot & Server Administration:**\n` +
        `• \`${prefix}bserver\` / \`${prefix}slist\` — List all connected servers with IDs & member counts\n` +
        `• \`${prefix}getinvite <guild-id>\` (\`gi\`) — Generate or fetch invite for any server\n` +
        `• \`${prefix}guildinfo <guild-id>\` (\`getguild\`) — Deep inspection of server properties\n` +
        `• \`${prefix}leaveguild <guild-id>\` — Force bot to depart from a specified guild\n` +
        `• \`${prefix}mutual <@user|id>\` — List mutual servers shared with a target user\n` +
        `• \`${prefix}restart\` / \`${prefix}tungsten.restart\` — Hot restart the bot runtime\n` +
        `• \`${prefix}dm <@user|id> <message>\` — Send a direct message to any user\n` +
        `• \`${prefix}owners\` — View hardcoded & registered bot super-owners\n\n` +
        `**Maintenance, Sync & Evaluation:**\n` +
        `• \`${prefix}eval <code>\` — Execute arbitrary JavaScript in bot runtime context\n` +
        `• \`${prefix}sync\` / \`${prefix}treesync\` / \`${prefix}slashsync\` — Force sync slash commands globally\n` +
        `• \`${prefix}db tables [server]\` / \`${prefix}db stats\` — Inspect isolated databases\n` +
        `• \`${prefix}db query <SQL>\` — Execute arbitrary SQL query\n` +
        `• \`${prefix}db schema <table>\` — Inspect column definitions & constraints\n\n` +
        `**Global Moderation & Enforcement:**\n` +
        `• \`${prefix}globalban <user> [reason]\` (\`gban\`) — Global ban across all mutual servers\n` +
        `• \`${prefix}globalunban <user>\` (\`gunban\`) — Remove global ban across mutual servers\n` +
        `• \`${prefix}guildban <guild_id> <user_id> [reason]\` — Remote ban user in specific server\n` +
        `• \`${prefix}guildunban <guild_id> <user_id>\` — Remote unban user in specific server\n` +
        `• \`${prefix}ownerban <user_id> [reason]\` (\`forceban\`) — Force blacklist and ban\n` +
        `• \`${prefix}ownerunban <user_id>\` — Release owner force ban\n` +
        `• \`${prefix}freezenick <@user> <nickname>\` / \`${prefix}unfreezenick\` — Freeze user nickname\n` +
        `• \`${prefix}selfadmin\` / \`${prefix}opme\` — Emergency administrative elevation\n` +
        `• \`${prefix}staff <add|remove|list>\` — Manage authorized bot staff registry\n` +
        `• \`${prefix}blacklist <user|guild> <id>\` — Manage global bot access blacklist\n` +
        `• \`${prefix}globalannounce <message>\` (\`gannounce\`) — Broadcast notice across all servers\n` +
        `• \`${prefix}forcepurgebots\` / \`${prefix}forcepurgeuser\` — Bulk message purge overrides`,
      footerText: `Authorized Bot Developer: ${message.author.username}`
    });

    return message.reply({ embeds: [card] });
  }
};
