/**
 * Bot Owner Deep Guild Inspection Command (Node.js)
 * Detailed telemetry on channels, roles, owner, security status, and bot permissions for any server.
 * Restricted to Bot Owners.
 */
const { isOwner, createEmbed } = require('../../utils/tools');
const { getGuildAccent, getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'guildinfo',
  aliases: ['getguild', 'ownerginf'],
  category: 'owner',
  description: 'Deep structural inspection of any server connected to the bot fleet.',
  usage: '<guild_id>',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const targetId = args[0] || message.guild?.id;
    if (!targetId) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}guildinfo <guild_id>\``);
    }

    const guild = client.guilds.cache.get(targetId);
    if (!guild) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Server \`${targetId}\` not found in bot fleet cache.`);
    }

    const owner = await client.users.fetch(guild.ownerId).catch(() => null);
    const channelsCount = guild.channels.cache.size;
    const textCount = guild.channels.cache.filter(c => c.isTextBased()).size;
    const voiceCount = guild.channels.cache.filter(c => c.isVoiceBased()).size;
    const rolesCount = guild.roles.cache.size;
    const emojisCount = guild.emojis.cache.size;
    const botMember = guild.members.me;

    const accent = getGuildAccent(message.guild?.id);
    const card = createV2Card({
      color: accent,
      title: `<a:tungsten_database:1567238475684651168>  Guild Telemetry: ${guild.name}`,
      description:
        `• **Server Name:** **${guild.name}**\n` +
        `• **Server ID:** \`${guild.id}\`\n` +
        `• **Owner:** ${owner ? `${owner.tag} (<@${owner.id}>)` : `<@${guild.ownerId}>`}\n` +
        `• **Created At:** <t:${Math.floor(guild.createdTimestamp / 1000)}:F> (<t:${Math.floor(guild.createdTimestamp / 1000)}:R>)\n` +
        `• **Joined Fleet:** <t:${Math.floor(guild.joinedTimestamp / 1000)}:R>\n` +
        `• **Total Population:** \`${guild.memberCount || 0}\` members\n` +
        `• **Channels [${channelsCount}]:** \`${textCount}\` text, \`${voiceCount}\` voice\n` +
        `• **Roles:** \`${rolesCount}\` | **Emojis:** \`${emojisCount}\`\n` +
        `• **Bot Administrative Status:** ${botMember?.permissions.has('Administrator') ? '`<ADMINISTRATOR>`' : '`<LIMITED>`'}\n` +
        `• **Vanity Code:** ${guild.vanityURLCode ? `\`${guild.vanityURLCode}\`` : '`None`'}`,
      thumbnailUrl: guild.iconURL ? guild.iconURL() : undefined,
      footerText: `Deep Guild Inspector • Fleet Node`
    });

    return message.reply({ embeds: [card] });
  }
};
