/**
 * Bot Owner Force Ban / DNA Command (Node.js)
 * Force blacklists and bans an attacker across the entire network.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { getMasterDb } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'ownerban',
  aliases: ['forceban', 'dna', 'ownerunban'],
  category: 'owner',
  description: 'Force blacklist and ban a user across the entire network.',
  usage: '<user_id> [reason]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'ownerban').toLowerCase();
    const isUnban = invoked === 'ownerunban' || args[0]?.toLowerCase() === 'unban';

    const userId = (isUnban && args[0]?.toLowerCase() === 'unban' ? args[1] : args[0])?.replace(/[<@!>]/g, '');
    const reasonArgs = isUnban && args[0]?.toLowerCase() === 'unban' ? args.slice(2) : args.slice(1);
    const reason = reasonArgs.join(' ') || (isUnban ? 'Owner unban' : 'Force ban and network exclusion by Bot Owner');

    if (!userId) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}${invoked} <user_id> [reason]\``);
    }

    if (isOwner(userId)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Safety Lock: Cannot force ban a Bot Owner.');
    }

    const mdb = getMasterDb();
    try {
      if (isUnban) {
        mdb.prepare('DELETE FROM owner_bans WHERE user_id = ?').run(userId);
        mdb.prepare('DELETE FROM blacklist_users WHERE user_id = ?').run(userId);
        return message.reply(`<a:tungsten_success:1567242523468890274> Lifted owner force ban and network blacklist for \`${userId}\`.`);
      } else {
        mdb.prepare(`
          INSERT INTO owner_bans (user_id, banned_by, reason, banned_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(user_id) DO UPDATE SET reason = excluded.reason
        `).run(userId, message.author.id, reason, Math.floor(Date.now() / 1000));

        mdb.prepare(`
          INSERT INTO blacklist_users (user_id, reason, banned_by)
          VALUES (?, ?, ?)
          ON CONFLICT(user_id) DO UPDATE SET reason = excluded.reason
        `).run(userId, reason, message.author.id);

        // Attempt instant bans across all mutual servers
        let bannedServers = 0;
        for (const guild of client.guilds.cache.values()) {
          try {
            if (guild.members.me?.permissions.has('BanMembers')) {
              await guild.bans.create(userId, { reason: `[Owner Force Ban] ${reason}` }).catch(() => null);
              bannedServers++;
            }
          } catch (_) {}
        }

        return message.reply(`<a:tungsten_success:1567242523468890274> Force ban applied to user \`${userId}\` across **${bannedServers}** servers. User is permanently blacklisted.`);
      }
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Error updating owner ban registry: ${err.message}`);
    }
  }
};
