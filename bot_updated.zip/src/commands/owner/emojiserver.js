/**
 * EmojiServer Command (Owner Only)
 * Manages dedicated emoji servers, inspects slot capacities, and triggers automated emoji synchronization.
 */
const { isOwner } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');
const { isEmojiServer, syncEmojiServers, getMaxSlots } = require('../../utils/emojiSync');
const { getGuildAccent } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'emojiserver',
  aliases: ['emojiservers', 'syncemojis', 'emojisync'],
  category: 'owner',
  description: 'Manage dedicated emoji servers and sync custom animated emojis.',
  usage: 'emojiserver [sync | list]',
  cooldown: 5,
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> This command is restricted to Tungsten Bot Owners.');
    }

    const sub = (args[0] || 'list').toLowerCase();
    const accent = getGuildAccent(message.guild?.id);

    if (sub === 'sync') {
      const notice = await message.reply('<a:tungsten_refresh:1567241907116187658> **Scanning emoji servers and auto-populating missing custom emojis...**');
      try {
        const res = await syncEmojiServers(client);
        const card = createV2Card({
          color: accent,
          title: '<a:tungsten_star:1567242331785138238>  Emoji Servers Synchronized',
          description:
            `• **Emoji Servers Detected:** \`${res.servers}\`\n` +
            `• **Newly Uploaded Emojis:** \`${res.uploaded}\`\n` +
            `• **Total Live Custom Emojis Indexed:** \`${res.indexed}\`\n\n` +
            (res.needMoreServers
              ? `<a:tungsten_warn:1567246685082746940> **Notice:** Animated emoji slots are full across all current emoji servers.\n` +
                `*Please create another server and invite Tungsten so more custom animated emojis can be stored!*`
              : `<a:tungsten_success:1567242523468890274> *All curated animated and static emojis are fully populated and active across all servers!*`),
          footerText: 'Tungsten Emoji Infrastructure'
        });
        return notice.edit({ content: null, embeds: [card] });
      } catch (err) {
        return notice.edit(`<a:tungsten_close:1567234632905138206> Emoji sync encountered an error: \`${err.message}\``);
      }
    }

    // Default: List detected emoji servers and slot usage
    const emojiServers = client.guilds.cache.filter(isEmojiServer);

    if (emojiServers.size === 0) {
      const card = createV2Card({
        color: accent,
        title: '<a:tungsten_warn:1567246685082746940>  No Dedicated Emoji Servers Detected',
        description:
          `> To provide custom animated emojis everywhere, Tungsten uses dedicated Emoji Servers.\n\n` +
          `### <a:tungsten_gear:1567239932970406012> How to Add an Emoji Server\n` +
          `1. Create a server on Discord with **"emoji"**, **"emotes"**, or **"tungsten"** in its name (e.g. \`Tungsten Emojis 1\`).\n` +
          `2. Invite Tungsten to that server.\n` +
          `3. Run \`${prefix}emojiserver sync\` — Tungsten will auto-upload all custom animated emojis!\n\n` +
          `*Tungsten can then use these animated emojis in all guilds!*`,
        footerText: 'Tungsten Emoji Infrastructure'
      });
      return message.reply({ embeds: [card] });
    }

    let description = `> Found **${emojiServers.size}** dedicated Emoji Server(s) connected to Tungsten.\n\n`;
    let totalAnimSlots = 0;
    let usedAnimSlots = 0;

    emojiServers.forEach(guild => {
      const max = getMaxSlots(guild.premiumTier);
      const animCount = guild.emojis.cache.filter(e => e.animated).size;
      const staticCount = guild.emojis.cache.filter(e => !e.animated).size;

      totalAnimSlots += max;
      usedAnimSlots += animCount;

      description +=
        `### <a:tungsten_shield:1567242104923627574> ${guild.name} (\`${guild.id}\`)\n` +
        `• **Animated Slots:** \`${animCount}/${max}\` ${animCount >= max ? '*(FULL)*' : `*(${max - animCount} free)*`}\n` +
        `• **Static Slots:** \`${staticCount}/${max}\` *(${max - staticCount} free)*\n` +
        `• **Server Boost Tier:** \`Tier ${guild.premiumTier}\`\n\n`;
    });

    const isFull = usedAnimSlots >= totalAnimSlots;
    description += isFull
      ? `<a:tungsten_warn:1567246685082746940> **All animated slots are currently full!** Create another server and add Tungsten to expand capacity.\n\n`
      : `<a:tungsten_success:1567242523468890274> **Available Capacity:** \`${totalAnimSlots - usedAnimSlots}\` free animated slots.\n\n`;

    description += `*Type \`${prefix}emojiserver sync\` to auto-upload missing emojis into available slots!*`;

    const card = createV2Card({
      color: accent,
      title: '<a:tungsten_star:1567242331785138238>  Tungsten Emoji Infrastructure Status',
      description,
      footerText: `Tungsten Cross-Server Emojis • ${(client.tungstenEmojis?.size || 0)} Emojis Cached`
    });

    return message.reply({ embeds: [card] });
  }
};
