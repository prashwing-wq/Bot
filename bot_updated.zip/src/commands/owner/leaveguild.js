/**
 * Bot Owner Force Leave Guild Command (Node.js)
 * Forces the bot to gracefully depart from a specified server.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { closeServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'leaveguild',
  aliases: ['gleave', 'botleave', 'leaveserver'],
  category: 'owner',
  description: 'Force the bot to gracefully leave a specified server.',
  usage: '<guild_id>',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const guildId = args[0];
    if (!guildId) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}leaveguild <guild_id>\``);
    }

    const guild = client.guilds.cache.get(guildId);
    if (!guild) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Server \`${guildId}\` not found in bot fleet cache.`);
    }

    const guildName = guild.name;
    try {
      closeServerDb(guildId);
      await guild.leave();
      return message.reply(`<a:tungsten_success:1567242523468890274> Successfully left server: **${guildName}** (\`${guildId}\`).`);
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to leave server: ${err.message}`);
    }
  }
};
