/**
 * Bot Access Blacklist Suite (Node.js)
 * Manages global blacklisting of users or guilds from interacting with the bot.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { getMasterDb, getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'blacklist',
  aliases: ['unblacklist', 'block', 'unblock', 'blacklisted', 'blocked'],
  category: 'owner',
  description: 'Manage global blacklist for users or servers.',
  usage: '<add | remove | list> <user | guild> <id> [reason]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'blacklist').toLowerCase();
    let sub = args[0]?.toLowerCase();

    if (invoked === 'unblacklist' || invoked === 'unblock') sub = 'remove';
    if (invoked === 'blacklisted' || invoked === 'blocked') sub = 'list';

    const mdb = getMasterDb();
    mdb.prepare(`
      CREATE TABLE IF NOT EXISTS blacklist_users (
        user_id TEXT PRIMARY KEY,
        reason TEXT,
        banned_by TEXT,
        timestamp INTEGER DEFAULT (strftime('%s', 'now'))
      );
    `).run();
    mdb.prepare(`
      CREATE TABLE IF NOT EXISTS blacklist_guilds (
        guild_id TEXT PRIMARY KEY,
        reason TEXT,
        banned_by TEXT,
        timestamp INTEGER DEFAULT (strftime('%s', 'now'))
      );
    `).run();

    // 1. List
    if (!sub || sub === 'list') {
      const userRows = mdb.prepare('SELECT user_id, reason FROM blacklist_users').all();
      const guildRows = mdb.prepare('SELECT guild_id, reason FROM blacklist_guilds').all();

      const userLines = userRows.map((r, i) => `\`#${i + 1}\` User <@${r.user_id}> (\`${r.user_id}\`) — *${r.reason || 'None'}*`);
      const guildLines = guildRows.map((r, i) => `\`#${i + 1}\` Guild \`${r.guild_id}\` — *${r.reason || 'None'}*`);

      const accent = getGuildAccent(message.guild?.id);
      const card = createV2Card({
        color: accent,
        title: '<a:tungsten_siren:1567242157725712555>  Global Access Blacklist',
        description:
          `**Blacklisted Users [${userRows.length}]:**\n` +
          (userLines.join('\n') || '*No blacklisted users.*') + '\n\n' +
          `**Blacklisted Guilds [${guildRows.length}]:**\n` +
          (guildLines.join('\n') || '*No blacklisted guilds.*'),
        footerText: `Tungsten Access Control Subsystem`
      });
      return message.reply({ embeds: [card] });
    }

    // 2. Add
    if (sub === 'add' || sub === 'block') {
      const targetType = args[1]?.toLowerCase();
      const targetId = args[2]?.replace(/[<@!>]/g, '');
      const reason = args.slice(3).join(' ') || 'Global blacklist by Bot Owner';

      if (!targetType || !targetId || !['user', 'guild', 'server'].includes(targetType)) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}blacklist add <user | guild> <id> [reason]\``);
      }

      if (targetType === 'user' && isOwner(targetId)) {
        return message.reply('<a:tungsten_close:1567234632905138206> Safety Lock: Cannot blacklist a Bot Owner.');
      }

      if (targetType === 'user') {
        mdb.prepare('INSERT OR REPLACE INTO blacklist_users (user_id, reason, banned_by) VALUES (?, ?, ?)').run(targetId, reason, message.author.id);
        return message.reply(`<a:tungsten_success:1567242523468890274> User \`${targetId}\` has been globally blacklisted.`);
      } else {
        mdb.prepare('INSERT OR REPLACE INTO blacklist_guilds (guild_id, reason, banned_by) VALUES (?, ?, ?)').run(targetId, reason, message.author.id);
        return message.reply(`<a:tungsten_success:1567242523468890274> Server \`${targetId}\` has been globally blacklisted.`);
      }
    }

    // 3. Remove
    if (sub === 'remove' || sub === 'unblock' || sub === 'del') {
      const targetType = args[1]?.toLowerCase();
      const targetId = args[2]?.replace(/[<@!>]/g, '');

      if (!targetType || !targetId) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}blacklist remove <user | guild> <id>\``);
      }

      if (targetType === 'user') {
        mdb.prepare('DELETE FROM blacklist_users WHERE user_id = ?').run(targetId);
        return message.reply(`<a:tungsten_success:1567242523468890274> Removed user \`${targetId}\` from the global blacklist.`);
      } else {
        mdb.prepare('DELETE FROM blacklist_guilds WHERE guild_id = ?').run(targetId);
        return message.reply(`<a:tungsten_success:1567242523468890274> Removed guild \`${targetId}\` from the global blacklist.`);
      }
    }

    return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}blacklist <add | remove | list> <user | guild> <id>\``);
  }
};
