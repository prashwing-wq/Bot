/**
 * Bot Owner Remote Guild Ban / Unban Command (Node.js)
 * Permanently disabled: Remote server ban is disabled.
 */
module.exports = {
  permissions: [],
  botPermissions: ['SendMessages', 'EmbedLinks'],
  name: 'guildban',
  aliases: ['guildunban', 'remoteban', 'remoteunban'],
  category: 'owner',
  description: 'Remotely ban or unban a user in a specific server using Guild ID.',
  usage: '<guild_id> <user_id> [reason]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: Remote server ban is disabled. Server owners and authorized server staff retain exclusive jurisdiction over their server moderations.');
  }
};
