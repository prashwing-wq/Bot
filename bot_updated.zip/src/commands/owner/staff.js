/**
 * Bot Staff Management Suite (Node.js)
 * Manages authorized bot staff members in master database.
 * Restricted to Bot Owners.
 */
const { isOwner, createEmbed } = require('../../utils/tools');
const { getMasterDb, getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'staff',
  aliases: ['staff_add', 'staff_remove', 'staff_list', 'staffadd', 'addstaff', 'staffremove', 'removestaff', 'stafflist', 'liststaff', 'staffs'],
  category: 'owner',
  description: 'Manage authorized bot staff members and support agents.',
  usage: '<add | remove | list> <@user | user_id>',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'staff').toLowerCase();
    let sub = args[0]?.toLowerCase();

    if (invoked.includes('add')) sub = 'add';
    else if (invoked.includes('remove') || invoked.includes('rem')) sub = 'remove';
    else if (invoked.includes('list') || invoked === 'staffs') sub = 'list';

    const mdb = getMasterDb();
    mdb.prepare(`
      CREATE TABLE IF NOT EXISTS staff (
        user_id TEXT PRIMARY KEY,
        added_by TEXT,
        added_at INTEGER
      )
    `).run();

    // 1. List Staff
    if (!sub || sub === 'list') {
      const rows = mdb.prepare('SELECT user_id, added_at, added_by FROM staff').all();
      if (rows.length === 0) {
        return message.reply('<a:tungsten_shield:1567242104923627574> No staff members currently registered. Add staff with `!staff add <@user>`.');
      }

      const lines = rows.map((r, i) => {
        const u = client.users.cache.get(r.user_id);
        const name = u ? `**${u.tag}**` : `User \`${r.user_id}\``;
        return `\`#${i + 1}\` <@${r.user_id}> (${name}) • Appointed by <@${r.added_by || '0'}>`;
      });

      const accent = getGuildAccent(message.guild?.id);
      const card = createV2Card({
        color: accent,
        title: '<a:tungsten_shield:1567242104923627574>  Authorized Bot Staff Registry',
        description:
          `> Active support agents and administrative staff authorized across the fleet.\n\n` +
          lines.join('\n'),
        footerText: `Total Staff: ${rows.length}`
      });
      return message.reply({ embeds: [card] });
    }

    // 2. Add Staff
    if (sub === 'add') {
      const raw = (invoked.includes('add') ? args[0] : args[1])?.replace(/[<@!>]/g, '');
      if (!raw) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}staff add <@user | user_id>\``);
      }

      const target = await client.users.fetch(raw).catch(() => null);
      if (!target) return message.reply(`<a:tungsten_close:1567234632905138206> User \`${raw}\` not found.`);

      mdb.prepare(`
        INSERT INTO staff (user_id, added_by, added_at)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET added_by = excluded.added_by, added_at = excluded.added_at
      `).run(target.id, message.author.id, Math.floor(Date.now() / 1000));

      return message.reply(`<a:tungsten_success:1567242523468890274> Added **${target.tag}** (<@${target.id}>) to the authorized Bot Staff registry.`);
    }

    // 3. Remove Staff
    if (sub === 'remove' || sub === 'rem') {
      const raw = (invoked.includes('remove') ? args[0] : args[1])?.replace(/[<@!>]/g, '');
      if (!raw) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}staff remove <@user | user_id>\``);
      }

      mdb.prepare('DELETE FROM staff WHERE user_id = ?').run(raw);
      return message.reply(`<a:tungsten_success:1567242523468890274> Removed user \`${raw}\` from the Bot Staff registry.`);
    }

    return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}staff <add | remove | list> <@user>\``);
  }
};
