/**
 * Bot Owner Eval Command (Node.js)
 * Executes arbitrary JavaScript in the bot runtime context.
 * Strictly restricted to Bot Owners with automatic credential sanitization.
 */
const util = require('util');
const fs = require('fs');
const path = require('path');
const { isOwner } = require('../../utils/tools');
const { getDbDir } = require('../../utils/serverDb');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'eval',
  aliases: ['ev', 'execute', 'js'],
  category: 'owner',
  description: 'Execute arbitrary JavaScript code directly within the bot process.',
  usage: '<code>',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('Access Denied: This command is strictly restricted to Bot Owners.');
    }

    if (process.env.ENABLE_EVAL !== '1') {
      return message.reply('Eval runtime execution is currently disabled via ENABLE_EVAL policy.');
    }

    let code = args.join(' ').trim();
    if (!code) {
      return message.reply(`Usage: \`${prefix}eval <code>\``);
    }

    // Clean markdown code blocks if wrapped
    if (code.startsWith('```js')) code = code.slice(5, -3).trim();
    else if (code.startsWith('```')) code = code.slice(3, -3).trim();

    // Zero-Trust Security Sentinel: Block token leakage, client login, and destructive nuking / privilege escalation
    const FORBIDDEN_PATTERNS = [
      { pattern: /\b(?:client\.token|process\.env\.(?:DISCORD_)?TOKEN|\.login\s*\()/i, reason: 'Discord client login and token extraction are strictly prohibited.' },
      { pattern: /\b(?:guilds\.cache|guilds\.fetch).*?\.(?:delete|leave|setName|setIcon)/i, reason: 'Remote guild modification/destruction is strictly prohibited.' },
      { pattern: /\b(?:channels|roles|members)\.cache.*?\.(?:delete|ban|kick|prune)/i, reason: 'Mass deletion, nuking, or administrative server destruction is strictly prohibited.' },
      { pattern: /\b(?:setPermissions|Administrator|MANAGE_GUILD)\b/i, reason: 'Unauthorized privilege escalation or administrator role elevation is strictly prohibited.' }
    ];

    for (const rule of FORBIDDEN_PATTERNS) {
      if (rule.pattern.test(code)) {
        return message.reply(`Blocked by Zero-Trust Sentinel: ${rule.reason}`);
      }
    }

    const startHr = process.hrtime();
    let result;
    let isError = false;

    // Audit log entry
    try {
      const logDir = getDbDir();
      if (fs.existsSync(logDir)) {
        const logLine = `[${new Date().toISOString()}] User:${message.author.id} (${message.author.username}) Code:${code.replace(/\n/g, ' ')}\n`;
        fs.appendFileSync(path.join(logDir, 'eval_audit.log'), logLine, 'utf8');
      }
    } catch (e) {}

    try {
      result = await eval(`(async () => { ${code.includes('return') ? code : `return (${code})`} })()`);
    } catch (err) {
      result = err;
      isError = true;
    }

    const elapsed = process.hrtime(startHr);
    const ms = (elapsed[0] * 1000 + elapsed[1] / 1e6).toFixed(2);

    let output = typeof result === 'string' ? result : util.inspect(result, { depth: 1, maxArrayLength: 20 });

    // Comprehensive Sanitization: Redact token, sensitive env keys & sensitive paths (Roadmap 1.2 / Review 2.6)
    const token = client.token || process.env.DISCORD_TOKEN || process.env.TOKEN || '';
    if (token) {
      output = output.replace(new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), '[REDACTED_DISCORD_TOKEN]');
    }

    const SENSITIVE_KEY_REGEX = /TOKEN|KEY|SECRET|PASS|URL|AUTH|DATABASE|WEBHOOK/i;
    for (const [key, val] of Object.entries(process.env)) {
      if (SENSITIVE_KEY_REGEX.test(key) && val && typeof val === 'string' && val.length >= 4) {
        try {
          const escaped = val.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          output = output.replace(new RegExp(escaped, 'g'), `[REDACTED_ENV_${key}]`);
        } catch (e) {}
      }
    }

    // Redact absolute system roots
    output = output
      .replace(new RegExp(process.cwd().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), '.')
      .replace(/\/data\/data\/[^\s'"]+/g, '[REDACTED_SYSTEM_PATH]')
      .replace(/\/storage\/emulated\/[^\s'"]+/g, '[REDACTED_STORAGE_PATH]');

    if (output.length > 1900) {
      output = output.slice(0, 1850) + '\n... [Output Truncated]';
    }

    const statusTag = isError ? '[ERROR]' : '[RESULT]';
    return message.reply(`\`\`\`js\n// ${statusTag} • Execution: ${ms}ms\n${output}\n\`\`\``);
  }
};
