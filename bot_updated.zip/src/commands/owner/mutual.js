/**
 * Bot Owner Mutual Guilds Inspection Command (Node.js)
 * Lists all servers shared between the bot and a target user.
 * Restricted to Bot Owners.
 */
const { isOwner } = require('../../utils/tools');
const { getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'mutual',
  aliases: ['mutuals', 'sharedservers'],
  category: 'owner',
  description: 'List all servers shared between the bot and a specified user.',
  usage: '<@user | user_id>',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const raw = args[0] ? args[0].replace(/[<@!>]/g, '') : null;
    if (!raw) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Usage: \`${prefix}mutual <@user | user_id>\``);
    }

    const targetUser = await client.users.fetch(raw).catch(() => null);
    if (!targetUser) {
      return message.reply(`<a:tungsten_close:1567234632905138206> User not found: \`${raw}\``);
    }

    const mutualGuilds = [];
    for (const guild of client.guilds.cache.values()) {
      if (guild.members.cache.has(targetUser.id)) {
        mutualGuilds.push(guild);
      }
    }

    const accent = getGuildAccent(message.guild?.id);
    const lines = mutualGuilds.slice(0, 25).map(g => `• **${g.name}** (\`${g.id}\`) — \`${g.memberCount}\` members`);

    const card = createV2Card({
      color: accent,
      title: `<a:tungsten_database:1567238475684651168>  Mutual Servers: ${targetUser.tag}`,
      description:
        `Target: <@${targetUser.id}> (\`${targetUser.id}\`)\n` +
        `Total Mutual Servers: **${mutualGuilds.length}**\n\n` +
        (lines.join('\n') || '*No mutual servers found.*') +
        (mutualGuilds.length > 25 ? `\n\n*...and ${mutualGuilds.length - 25} more servers.*` : ''),
      footerText: `Requested by ${message.author.username}`
    });

    return message.reply({ embeds: [card] });
  }
};
