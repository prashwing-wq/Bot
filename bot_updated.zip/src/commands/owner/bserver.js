/**
 * Bot Servers Explorer Command (Node.js)
 * Lists all connected servers sorted by member count or join date with IDs, owners, and counts.
 * Restricted to Bot Owners.
 */
const { isOwner, createEmbed } = require('../../utils/tools');
const { getGuildAccent } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'bserver',
  aliases: ['bservers', 'botserver', 'botservers', 'slist'],
  category: 'owner',
  description: 'List all servers the bot is in with IDs, member counts, and owner information.',
  usage: '[page]',
  ownerOnly: true,

  async execute(message, args, client, prefix) {
    if (!isOwner(message.author.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> Access Denied: This command is strictly restricted to Bot Owners.');
    }

    const guilds = Array.from(client.guilds.cache.values())
      .sort((a, b) => (b.memberCount || 0) - (a.memberCount || 0));

    const totalGuilds = guilds.length;
    const totalMembers = guilds.reduce((acc, g) => acc + (g.memberCount || 0), 0);
    const pageSize = 10;
    const totalPages = Math.max(1, Math.ceil(totalGuilds / pageSize));

    let page = parseInt(args[0], 10) || 1;
    if (page < 1) page = 1;
    if (page > totalPages) page = totalPages;

    const start = (page - 1) * pageSize;
    const currentGuilds = guilds.slice(start, start + pageSize);

    const lines = currentGuilds.map((g, idx) => {
      const pos = start + idx + 1;
      const owner = g.ownerId ? `<@${g.ownerId}> (\`${g.ownerId}\`)` : '`Unknown`';
      return `\`#${pos}\` **${g.name}**\n↳ ID: \`${g.id}\` • Members: \`${g.memberCount || 0}\` • Owner: ${owner}`;
    });

    const accent = getGuildAccent(message.guild?.id);
    const card = createV2Card({
      color: accent,
      title: `<a:tungsten_database:1567238475684651168>  Connected Guild Fleet • ${totalGuilds} Servers`,
      description:
        `> Active fleet statistics: **${totalGuilds}** servers serving **${totalMembers.toLocaleString()}** members.\n\n` +
        lines.join('\n\n'),
      footerText: `Page ${page}/${totalPages} • Use ${prefix}bserver <page>`
    });

    return message.reply({ embeds: [card] });
  }
};
