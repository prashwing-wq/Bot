/**
 * Unmute All Command (Node.js)
 * Removes timeouts and voice server-mutes from all members in the server.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'unmuteall',
  aliases: ['massunmute'],
  category: 'moderation',
  description: 'Unmutes (removes timeout / vc mute) from all muted members.',
  usage: '',
  cooldown: 10,
  permissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers', 'MuteMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Moderate Members` permission to run this command.'
          })
        ]
      });
    }

    // Fetch or inspect cached members
    let members = [];
    try {
      const fetched = await message.guild.members.fetch();
      members = Array.from(fetched.values());
    } catch (_) {
      members = Array.from(message.guild.members.cache.values());
    }

    const mutedMembers = members.filter(m => {
      const isTimedOut = typeof m.isCommunicationDisabled === 'function' ? m.isCommunicationDisabled() : Boolean(m.communicationDisabledUntilTimestamp && m.communicationDisabledUntilTimestamp > Date.now());
      const isVcMuted = Boolean(m.voice?.serverMute);
      return isTimedOut || isVcMuted;
    });

    if (mutedMembers.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> There are currently no muted or timed out members in this server.');
    }

    const statusMsg = await message.reply(`<a:tungsten_loading:1567241050567876698> Unmuting **${mutedMembers.length}** members... Please wait.`);

    let unmutedCount = 0;
    for (const target of mutedMembers) {
      let changed = false;
      try {
        const isTimedOut = typeof target.isCommunicationDisabled === 'function' ? target.isCommunicationDisabled() : Boolean(target.communicationDisabledUntilTimestamp && target.communicationDisabledUntilTimestamp > Date.now());
        if (isTimedOut && typeof target.timeout === 'function') {
          await target.timeout(null, `Mass unmute executed by ${message.author.tag}`);
          changed = true;
        }
      } catch (e) {}

      try {
        if (target.voice?.serverMute && typeof target.voice.setMute === 'function') {
          await target.voice.setMute(false, `Mass unmute executed by ${message.author.tag}`);
          changed = true;
        }
      } catch (e) {}

      if (changed) unmutedCount++;
      await new Promise(r => setTimeout(r, 100));
    }

    const { getServerDb } = require('../../utils/serverDb');
    const sdb = getServerDb(message.guild.id);
    await logAction(message.guild, sdb, {
      emoji: EMOJIS.SOUND,
      action: 'mass_unmute',
      moderatorId: message.author.id,
      reason: `Unmuted ${unmutedCount} / ${mutedMembers.length} members`
    }).catch(() => null);

    const embed = createEmbed({
      color: client.config.COLORS.SUCCESS,
      title: `${EMOJIS.SOUND}  Mass Unmute Completed`,
      description: `Successfully removed timeouts and voice mutes from **${unmutedCount}** / **${mutedMembers.length}** members.`
    });

    return statusMsg.edit({ content: null, embeds: [embed] }).catch(() => null);
  }
};
