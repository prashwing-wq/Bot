/**
 * Tungsten Custom Moderation Management Hub (Node.js)
 * Implements Zero Discord Permissions Architecture:
 * 17 dedicated custom moderation actions, locked log stream category,
 * role/user action delegations with daily limits, and interactive control panel.
 */
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  ChannelType
} = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { hasPerm, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

// 17 Fixed Custom Moderation Actions
const CM_ACTIONS = [
  'ban',
  'unban',
  'kick',
  'mute',
  'unmute',
  'warn',
  'clear',
  'adel',
  'radel',
  'vmute',
  'vunmute',
  'vmuteall',
  'vunmuteall',
  'defend',
  'undefend',
  'defendall',
  'undefendall'
];

// Dedicated Channel Name Mapping
const ACTION_LOG_CHANNELS = {
  ban: 'ban-logs',
  unban: 'unban-logs',
  kick: 'kick-logs',
  mute: 'mute-logs',
  unmute: 'unmute-logs',
  warn: 'warn-logs',
  clear: 'clear-logs',
  adel: 'adel-logs',
  radel: 'radel-logs',
  vmute: 'vmute-logs',
  vunmute: 'vunmute-logs',
  vmuteall: 'vmuteall-logs',
  vunmuteall: 'vunmuteall-logs',
  defend: 'defend-logs',
  undefend: 'undefend-logs',
  defendall: 'defendall-logs',
  undefendall: 'undefendall-logs'
};

const ACTION_META = {
  ban: { emoji: '<a:tungsten_shield:1567242104923627574>', desc: 'Ban member from server' },
  unban: { emoji: '<a:tungsten_unlock:1567246515209117968>', desc: 'Unban user by ID or tag' },
  kick: { emoji: '<a:tungsten_error:1567238753284653106>', desc: 'Kick member from server' },
  mute: { emoji: '<a:tungsten_mute:1567241451992121647>', desc: 'Timeout / mute member' },
  unmute: { emoji: '<a:tungsten_sound:1567242242127568958>', desc: 'Remove timeout from member' },
  warn: { emoji: '<a:tungsten_warn:1567246685082746940>', desc: 'Issue moderation warning' },
  clear: { emoji: '<a:tungsten_sweep:1567242656281657414>', desc: 'Purge messages in channel' },
  adel: { emoji: '<a:tungsten_error:1567238753284653106>', desc: 'Auto-delete user / word filter' },
  radel: { emoji: '<a:tungsten_refresh:1567241907116187658>', desc: 'Remove auto-delete filter' },
  vmute: { emoji: '<a:tungsten_mute:1567241451992121647>', desc: 'Single-target voice mute' },
  vunmute: { emoji: '<a:tungsten_sound:1567242242127568958>', desc: 'Single-target voice unmute' },
  vmuteall: { emoji: '<a:tungsten_mute:1567241451992121647>', desc: 'Server-wide / VC voice mute all' },
  vunmuteall: { emoji: '<a:tungsten_sound:1567242242127568958>', desc: 'Server-wide / VC voice unmute all' },
  defend: { emoji: '<a:tungsten_shield:1567242104923627574>', desc: 'Single-target defense toggle' },
  undefend: { emoji: '<a:tungsten_unlock:1567246515209117968>', desc: 'Single-target undefense toggle' },
  defendall: { emoji: '<a:tungsten_shield:1567242104923627574>', desc: 'Server-wide defense toggle' },
  undefendall: { emoji: '<a:tungsten_unlock:1567246515209117968>', desc: 'Server-wide undefense toggle' }
};

const CATEGORY_NAME = 'Custom Mods Logs';

function getTodayDateStr() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

/**
 * Builds the Custom Moderation live dashboard payload.
 */
function buildCMDashboardPayload(guild, sdb, prefix = '!', username = '') {
  const today = getTodayDateStr();

  // 1. Fetch channel mapping count
  const channelRows = sdb.prepare('SELECT action, channel_id FROM cm_channels WHERE guild_id = ?').all(guild.id);
  const channelMap = new Map();
  for (const r of channelRows) channelMap.set(r.action, r.channel_id);

  let activeLockedCount = 0;
  for (const [action, expectedName] of Object.entries(ACTION_LOG_CHANNELS)) {
    const chId = channelMap.get(action);
    const ch = (chId ? guild.channels.cache.get(chId) : null) || guild.channels.cache.find(c => c.name === expectedName);
    if (ch && ch.isTextBased()) {
      const everyoneOverwrites = ch.permissionOverwrites?.cache?.get(guild.id);
      const isHidden = everyoneOverwrites ? (BigInt(everyoneOverwrites.deny) & PermissionsBitField.Flags.ViewChannel) !== 0n : false;
      if (isHidden || !ch.permissionsFor(guild.roles.everyone).has(PermissionsBitField.Flags.ViewChannel)) {
        activeLockedCount++;
      }
    }
  }

  const totalActions = CM_ACTIONS.length;
  const healthStatus = activeLockedCount === totalActions
    ? `<a:tungsten_success:1567242523468890274> \`${activeLockedCount}/${totalActions} active & locked\``
    : `<a:tungsten_warn:1567246685082746940> \`${activeLockedCount}/${totalActions} active & locked\``;

  // 2. Fetch mappings & today's usage
  const mappings = sdb.prepare('SELECT action, target_type, target_id, daily_limit FROM cm_mappings WHERE guild_id = ?').all(guild.id);
  const usageRows = sdb.prepare('SELECT action, target_id, count FROM cm_usage WHERE guild_id = ? AND usage_date = ?').all(guild.id, today);
  const usageMap = new Map();
  for (const u of usageRows) {
    usageMap.set(`${u.action}:${u.target_id}`, u.count);
  }

  let mappingsText = '*No role or user delegations configured yet. Click **Assign Action** or use `' + prefix + 'cm set <action> <@role|@user> [limit]`.*';
  if (mappings.length > 0) {
    mappingsText = mappings.map(m => {
      const meta = ACTION_META[m.action] || { emoji: '<a:tungsten_warn:1567246685082746940>', desc: m.action };
      const targetStr = m.target_type === 'role' ? `<@&${m.target_id}>` : `<@${m.target_id}>`;
      const used = usageMap.get(`${m.action}:${m.target_id}`) || 0;
      const limitStr = m.daily_limit > 0 ? `${used}/${m.daily_limit} used today` : `${used} used (No limit)`;
      return `• ${meta.emoji} **\`${m.action.toUpperCase()}\`** ➔ ${targetStr} • \`${limitStr}\``;
    }).join('\n');
  }

  const card = createV2Card({
    color: 0x2b2d31,
    title: `<a:tungsten_shield:1567242104923627574> Custom Moderation Control Panel • ${guild.name}`,
    description:
      `> **Zero Discord Permissions Architecture**\n` +
      `> Roles delegated below execute actions purely through Tungsten's internal verification without holding native Discord Administrator permissions.\n\n` +
      `• **Log Stream Status:** ${healthStatus}\n` +
      `• **Enforcement Category:** \`${CATEGORY_NAME}\`\n\n` +
      `**Active Delegations & Daily Quotas [${mappings.length}]:**\n` +
      mappingsText +
      `\n\n**Quick Commands:**\n` +
      `• \`${prefix}cm setup\` — Provision category & 17 dedicated log channels\n` +
      `• \`${prefix}cm set <action> <@role|@user> [limit]\` — Delegate action\n` +
      `• \`${prefix}cm unset <action>\` — Revoke delegation\n` +
      `• \`${prefix}cm usage\` — View today's usage statistics`,
    footerText: username ? `Requested by ${username}` : `Tungsten Custom Moderation • ${guild.name}`
  });

  const row0 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('cm:refresh').setLabel('Refresh').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('cm:setup').setLabel('Setup Channels').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('cm:assign').setLabel('Assign Action').setStyle(ButtonStyle.Success).setEmoji('<a:tungsten_plus:1567241846453833840>'),
    new ButtonBuilder().setCustomId('cm:remove').setLabel('Remove Action').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_minus:1567241276057849856>')
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('cm:usage').setLabel('Daily Usage').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_chart:1567234342701367357>'),
    new ButtonBuilder().setCustomId('cm:reset').setLabel('Reset Limits').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_sweep:1567242656281657414>'),
    new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [card], components: [row0, row1] };
}

/**
 * Provisions the locked Custom Mods Logs category and 17 dedicated action channels.
 */
async function provisionCMChannels(guild, sdb) {
  let category = guild.channels.cache.find(c => c.name.toLowerCase() === CATEGORY_NAME.toLowerCase() && c.type === ChannelType.GuildCategory);

  if (!category) {
    category = await guild.channels.create({
      name: CATEGORY_NAME,
      type: ChannelType.GuildCategory,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionsBitField.Flags.ViewChannel]
        },
        {
          id: guild.members.me.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.EmbedLinks,
            PermissionsBitField.Flags.AttachFiles,
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.ManageChannels
          ]
        }
      ],
      reason: '[Tungsten CM] Initialized locked Custom Moderation log category'
    });
  }

  sdb.prepare('INSERT OR REPLACE INTO cm_settings (guild_id, category_id) VALUES (?, ?)').run(guild.id, category.id);

  let createdCount = 0;
  for (const [action, chName] of Object.entries(ACTION_LOG_CHANNELS)) {
    let ch = guild.channels.cache.find(c => c.name.toLowerCase() === chName.toLowerCase() && c.parentId === category.id);
    if (!ch) {
      ch = await guild.channels.create({
        name: chName,
        type: ChannelType.GuildText,
        parent: category.id,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionsBitField.Flags.ViewChannel]
          },
          {
            id: guild.members.me.id,
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.EmbedLinks,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.ReadMessageHistory
            ]
          }
        ],
        reason: `[Tungsten CM] Created dedicated log channel for ${action}`
      }).catch(() => null);
      if (ch) createdCount++;
    }

    if (ch) {
      sdb.prepare('INSERT OR REPLACE INTO cm_channels (guild_id, action, channel_id) VALUES (?, ?, ?)').run(guild.id, action, ch.id);
    }
  }

  return { categoryId: category.id, createdCount };
}

module.exports = {
  name: 'cm',
  aliases: ['custommod', 'custommoderation', 'cmpanel'],
  category: 'moderation',
  description: 'Custom Moderation Management Hub & Control Panel (Zero Discord Permissions Architecture).',
  permissions: ['Administrator'],
  botPermissions: ['ManageChannels','SendMessages','EmbedLinks'],
  usage: '[panel | config | setup | set <action> <@role|@user> [limit] | unset <action> | usage | reset | help]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const sdb = getServerDb(message.guild.id);
    const isServerOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = isOwner(message.author.id);
    const isExtraOwner = sdb.prepare('SELECT 1 FROM extraowners WHERE guild_id = ? AND owner_id = ?').get(message.guild.id, message.author.id);
    const hasAdmin = hasPerm(message.member, PermissionsBitField.Flags.Administrator);

    if (!isServerOwner && !isBotOwner && !isExtraOwner && !hasAdmin) {
      return message.reply('<a:tungsten_close:1567234632905138206> Only the **Server Owner**, **Extra Owners**, or **Administrators** can configure Custom Moderation.');
    }

    const sub = (args[0] || 'panel').toLowerCase();

    // 1. Setup Channels
    if (sub === 'setup' || sub === 'init') {
      const statusMsg = await message.reply('<a:tungsten_loading:1567241050567876698> **Provisioning Custom Moderation locked category and 17 dedicated log channels...**');
      try {
        const res = await provisionCMChannels(message.guild, sdb);
        const card = createV2Card({
          color: 0x2ECC71,
          title: '<a:tungsten_success:1567242523468890274>  Custom Moderation Channels Provisioned',
          description:
            `> Successfully synchronized **17 dedicated log channels** under category **\`${CATEGORY_NAME}\`**.\n\n` +
            `• **Category ID:** \`${res.categoryId}\`\n` +
            `• **Channels Configured:** \`17/17 active & locked\`\n` +
            `• **Security:** Fully hidden from \`@everyone\` with zero leak vectors\n\n` +
            `-# View dashboard anytime with \`${prefix}cm panel\``,
          footerText: `Provisioned by ${message.author.username}`
        });
        return statusMsg.edit({ content: null, embeds: [card] });
      } catch (err) {
        return statusMsg.edit(`<a:tungsten_close:1567234632905138206> Failed to provision log channels: ${err.message}`);
      }
    }

    // 2. Set Delegation Mapping
    if (sub === 'set' || sub === 'add' || sub === 'assign') {
      const actionInput = args[1]?.toLowerCase();
      if (!actionInput || !CM_ACTIONS.includes(actionInput)) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Invalid action. Available actions:\n\`${CM_ACTIONS.join(', ')}\``);
      }

      const targetInput = args[2];
      if (!targetInput) {
        return message.reply(`Usage: \`${prefix}cm set <action> <@role|@user|id> [daily_limit]\``);
      }

      const targetId = targetInput.replace(/[<@!&>]/g, '');
      const isRole = (message.mentions?.roles ? message.mentions.roles.has(targetId) : false) || message.guild.roles.cache.has(targetId);
      const isUser = !isRole && ((message.mentions?.users ? message.mentions.users.has(targetId) : false) || (await client.users.fetch(targetId).catch(() => null)));

      if (!isRole && !isUser) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve \`${targetInput}\` to a valid role or user.`);
      }

      const limit = args[3] ? parseInt(args[3], 10) : 0;
      const targetType = isRole ? 'role' : 'user';

      sdb.prepare(`
        INSERT INTO cm_mappings (guild_id, action, target_type, target_id, daily_limit)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(guild_id, action) DO UPDATE SET
          target_type = excluded.target_type,
          target_id = excluded.target_id,
          daily_limit = excluded.daily_limit
      `).run(message.guild.id, actionInput, targetType, targetId, isNaN(limit) ? 0 : Math.max(0, limit));

      const meta = ACTION_META[actionInput] || { emoji: '<a:tungsten_warn:1567246685082746940>', desc: actionInput };
      const targetStr = isRole ? `<@&${targetId}>` : `<@${targetId}>`;

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_success:1567242523468890274> Custom Moderation Delegation Active',
        description:
          `> Successfully mapped action **\`${actionInput.toUpperCase()}\`** to ${targetStr}.\n\n` +
          `• **Action:** ${meta.emoji} \`${actionInput}\` (${meta.desc})\n` +
          `• **Delegated Target:** ${targetStr} (\`${targetType}\`)\n` +
          `• **Daily Limit:** \`${limit > 0 ? `${limit} actions/day` : 'Unlimited'}\`\n\n` +
          `-# Revoke anytime with \`${prefix}cm unset ${actionInput}\``,
        footerText: `Configured by ${message.author.username}`
      });

      return message.reply({ embeds: [card] });
    }

    // 3. Unset Delegation Mapping
    if (sub === 'unset' || sub === 'remove' || sub === 'delete') {
      const actionInput = args[1]?.toLowerCase();
      if (!actionInput) {
        return message.reply(`Usage: \`${prefix}cm unset <action>\`\nActions: \`${CM_ACTIONS.join(', ')}\``);
      }

      const res = sdb.prepare('DELETE FROM cm_mappings WHERE guild_id = ? AND action = ?').run(message.guild.id, actionInput);
      if (res.changes === 0) {
        return message.reply(`<a:tungsten_info:1567240890748248084> Action \`${actionInput}\` is not currently delegated in this server.`);
      }

      return message.reply(`<a:tungsten_success:1567242523468890274> Removed delegation for action **\`${actionInput}\`**.`);
    }

    // 4. Daily Usage Statistics
    if (sub === 'usage' || sub === 'stats') {
      const today = getTodayDateStr();
      const rows = sdb.prepare('SELECT action, target_id, count FROM cm_usage WHERE guild_id = ? AND usage_date = ?').all(message.guild.id, today);

      let usageText = '*No custom moderation actions executed today yet.*';
      if (rows.length > 0) {
        usageText = rows.map(r => {
          const meta = ACTION_META[r.action] || { emoji: '<a:tungsten_warn:1567246685082746940>' };
          return `• ${meta.emoji} **\`${r.action.toUpperCase()}\`** — Executed by <@${r.target_id}>: \`${r.count}\` time(s)`;
        }).join('\n');
      }

      const card = createV2Card({
        color: 0x2b2d31,
        title: `<a:tungsten_chart:1567234342701367357> Custom Moderation Usage • Today (${today})`,
        description:
          `> Real-time monitoring of delegated custom moderation actions.\n\n` +
          usageText,
        footerText: `Tungsten CM Analytics • ${message.guild.name}`
      });

      return message.reply({ embeds: [card] });
    }

    // 5. Reset Daily Limits
    if (sub === 'reset') {
      const today = getTodayDateStr();
      sdb.prepare('DELETE FROM cm_usage WHERE guild_id = ? AND usage_date = ?').run(message.guild.id, today);
      return message.reply('<a:tungsten_success:1567242523468890274> Successfully reset all Custom Moderation daily action counters for today.');
    }

    // 6. Action Reference / Help
    if (sub === 'help' || sub === 'actions') {
      const actionList = Object.entries(ACTION_META)
        .map(([k, v]) => `• ${v.emoji} **\`${k}\`** — ${v.desc}`)
        .join('\n');

      const card = createV2Card({
        color: 0x2b2d31,
        title: '<a:tungsten_refresh:1567241907116187658> Custom Moderation Action Directory (17 Actions)',
        description:
          `> These actions operate through Tungsten's internal verification with zero native Discord Administrator permissions.\n\n` +
          actionList +
          `\n\n**Configuration Commands:**\n` +
          `• \`${prefix}cm setup\` — Provision category and dedicated log streams\n` +
          `• \`${prefix}cm set <action> <@role|@user> [limit]\` — Delegate action\n` +
          `• \`${prefix}cm unset <action>\` — Remove delegation`,
        footerText: `Tungsten CM Specification • 17 Actions`
      });

      return message.reply({ embeds: [card] });
    }

    // Default: Live Control Panel Dashboard
    const payload = buildCMDashboardPayload(message.guild, sdb, prefix, message.author.username);
    return message.reply(payload);
  },

  buildCMDashboardPayload,
  provisionCMChannels,
  CM_ACTIONS,
  ACTION_META,
  ACTION_LOG_CHANNELS
};
