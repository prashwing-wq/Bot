/**
 * Staff Duty & Shift Management Command (Node.js)
 * Tracks staff activity, on-duty presence, and active moderator roster.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'duty',
  aliases: ['onduty', 'offduty', 'dutylist', 'staffduty'],
  category: 'moderation',
  description: 'Manage staff shifts, toggle active moderation duty, and view on-duty staff.',
  permissions: ['ManageMessages'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[on | off | list | status]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageMessages)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission or staff status to use staff duty commands.');
    }

    const sdb = getServerDb(message.guild.id);
    const invokedName = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/ +/)[0] : message.content?.trim().split(/ +/)[0]) || 'duty').toLowerCase();

    let sub = args[0]?.toLowerCase() || 'status';
    if (invokedName === 'onduty') sub = 'on';
    if (invokedName === 'offduty') sub = 'off';
    if (invokedName === 'dutylist') sub = 'list';

    // 1. Clock In (On Duty)
    if (sub === 'on' || sub === 'start' || sub === 'clockin') {
      const now = Math.floor(Date.now() / 1000);
      sdb.prepare(`
        INSERT INTO staff_duty (guild_id, user_id, on_duty, started_at)
        VALUES (?, ?, 1, ?)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET
          on_duty = 1,
          started_at = excluded.started_at
      `).run(message.guild.id, message.author.id, now);

      const card = createV2Card({
        color: 0x57F287,
        title: '<a:tungsten_shield:1567242104923627574>  Staff Shift Started • On Duty',
        description:
          `**Moderator:** ${message.author}\n` +
          `**Shift Began:** <t:${now}:R> (<t:${now}:T>)\n\n` +
          `• *You are now logged as active on-duty personnel for ${message.guild.name}.*`,
        footer: { text: `Type ${prefix}duty off to conclude your shift` }
      });

      return message.reply({ embeds: [card] });
    }

    // 2. Clock Out (Off Duty)
    if (sub === 'off' || sub === 'stop' || sub === 'clockout') {
      const row = sdb.prepare('SELECT started_at, on_duty FROM staff_duty WHERE guild_id = ? AND user_id = ?').get(message.guild.id, message.author.id);
      if (!row || row.on_duty === 0) {
        return message.reply('<a:tungsten_info:1567240890748248084> You are not currently logged as on-duty.');
      }

      const now = Math.floor(Date.now() / 1000);
      const durationSec = now - row.started_at;
      const mins = Math.floor(durationSec / 60);
      const hours = Math.floor(mins / 60);
      const remainingMins = mins % 60;
      const durationStr = hours > 0 ? `${hours}h ${remainingMins}m` : `${mins}m ${durationSec % 60}s`;

      sdb.prepare('UPDATE staff_duty SET on_duty = 0 WHERE guild_id = ? AND user_id = ?').run(message.guild.id, message.author.id);

      const card = createV2Card({
        color: 0xFEE75C,
        title: '🏁  Staff Shift Concluded • Off Duty',
        description:
          `**Moderator:** ${message.author}\n` +
          `**Total Shift Duration:** \`${durationStr}\`\n\n` +
          `• *Thank you for keeping ${message.guild.name} safe!*`
      });

      return message.reply({ embeds: [card] });
    }

    // 3. List Active On-Duty Staff
    if (sub === 'list' || sub === 'active' || sub === 'roster') {
      const rows = sdb.prepare('SELECT user_id, started_at FROM staff_duty WHERE guild_id = ? AND on_duty = 1').all(message.guild.id);

      let listText = '';
      if (rows.length === 0) {
        listText = '*No moderators are currently logged on duty.*';
      } else {
        listText = rows.map((r, i) => `\`#${i + 1}\` <@${r.user_id}> — Active since <t:${r.started_at}:R>`).join('\n');
      }

      const card = createV2Card({
        color: 0x2b2d31,
        title: `<a:tungsten_shield:1567242104923627574>  Active On-Duty Staff • ${message.guild.name}`,
        description:
          `> Real-time moderation shift roster.\n\n` +
          listText +
          `\n\n**Staff Commands:**\n` +
          `• \`${prefix}duty on\` — Clock in for active duty\n` +
          `• \`${prefix}duty off\` — Clock out from duty`,
        footer: { text: `Requested by ${message.author.username}` }
      });

      return message.reply({ embeds: [card] });
    }

    // 4. Status Check
    const myRow = sdb.prepare('SELECT started_at, on_duty FROM staff_duty WHERE guild_id = ? AND user_id = ?').get(message.guild.id, message.author.id);
    const isOnDuty = myRow ? myRow.on_duty === 1 : false;

    const embed = createEmbed({
      title: '<a:tungsten_shield:1567242104923627574>  Moderator Duty Status',
      description:
        `**Your Status:** ${isOnDuty ? '🟢 `ON DUTY`' : '🔴 `OFF DUTY`'}\n` +
        (isOnDuty ? `• Active since: <t:${myRow.started_at}:R>\n\n` : '\n') +
        `**Quick Controls:**\n` +
        `• \`${prefix}duty on\` — Clock in for duty\n` +
        `• \`${prefix}duty off\` — Clock out from duty\n` +
        `• \`${prefix}duty list\` — View all staff on duty`
    });

    return message.reply({ embeds: [embed] });
  }
};
