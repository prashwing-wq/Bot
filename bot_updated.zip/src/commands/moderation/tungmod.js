/**
 * Tungsten Mod Master Control Panel & 9 Hubs Suite (Node.js)
 * Implements the full Tungsten Mod architecture from TUNGSTEN_MOD_SPEC.md:
 * 1. ⚡ Quick Punish (quickpanel)
 * 2. <a:tungsten_shield:1567242104923627574> Message Rules (rulespanel)
 * 3. 🚪 Join Gates (gatespanel)
 * 4. 📜 Event Logs (logspanel)
 * 5. 🔐 Permission Presets (permspanel)
 * 6. 🎭 Roles & Members (rolespanel)
 * 7. 📺 Channel Tools (channelspanel)
 * 8. 🏷️ Role Rotator (rotatorpanel)
 * 9. 🗒️ Notes & Stats (casespanel)
 */
const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField
} = require('discord.js');
const { createV2Card } = require('../../utils/componentsV2');
const { isOwner, hasPerm } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

const HUBS = {
  quick: {
    label: 'Quick Punish',
    emoji: '<a:tungsten_warn:1567246685082746940>',
    description: 'Instant warn, mute, kick and ban shortcuts with ready reasons'
  },
  rules: {
    label: 'Message Rules',
    emoji: '<a:tungsten_shield:1567242104923627574>',
    description: '136 automated chat inspection rules across 9 security categories'
  },
  gates: {
    label: 'Join Gates',
    emoji: '<a:tungsten_shield:1567242104923627574>',
    description: '26 account age, avatar, cluster and rate gates for new joins'
  },
  logs: {
    label: 'Event Logs',
    emoji: '<a:tungsten_refresh:1567241907116187658>',
    description: '58 event listeners across 9 categories with burst aggregation'
  },
  perms: {
    label: 'Permission Presets',
    emoji: '<a:tungsten_unlock:1567246515209117968>',
    description: '36 channel, category, and server-wide permission controls'
  },
  roles: {
    label: 'Roles & Members',
    emoji: '<a:tungsten_refresh:1567241907116187658>',
    description: 'Role palettes, role hoisting, member criteria, and nickname fixers'
  },
  channels: {
    label: 'Channel Tools',
    emoji: '<a:tungsten_refresh:1567241907116187658>',
    description: 'Slowmodes, scopes, topic templates, and voice limits'
  },
  rotator: {
    label: 'Role Rotator',
    emoji: '<a:tungsten_refresh:1567241907116187658>',
    description: 'Safe role badge rotator (palettes, emoji sets, 1m-24h intervals)'
  },
  cases: {
    label: 'Notes & Stats',
    emoji: '<a:tungsten_chart:1567234342701367357>',
    description: 'Typed staff notes, 5-tier watchlist, and moderator statistics'
  }
};

function buildTungmodHubCard(guild, hubKey = 'overview', prefix = '!') {
  if (hubKey === 'overview') {
    const card = createV2Card({
      color: 0x2b2d31,
      title: `<a:tungsten_shield:1567242104923627574> Tungsten Mod Master Panel • ${guild.name}`,
      description:
        `> **Enterprise Server Management & Defense Matrix (3,200 Spec Suite)**\n\n` +
        `Browse, inspect, and execute moderation tools from the interactive hub selector below.\n\n` +
        `• <a:tungsten_warn:1567246685082746940> **Quick Punish:** 782 shortcuts (20 actions × 39 reasons) + quickpanel\n` +
        `• <a:tungsten_shield:1567242104923627574> **Message Rules:** 1,111 rules across 9 security categories + rulespanel\n` +
        `• <a:tungsten_shield:1567242104923627574> **Join Gates:** 171 automated join gates and quarantine triggers + gatespanel\n` +
        `• <a:tungsten_refresh:1567241907116187658> **Event Logs:** 259 log dispatches across 58 events + logspanel\n` +
        `• <a:tungsten_unlock:1567246515209117968> **Permission Presets:** 315 channel and role scope rules + permspanel\n` +
        `• <a:tungsten_refresh:1567241907116187658> **Roles & Members:** 262 color palettes, hoisting and bulk ops + rolespanel\n` +
        `• <a:tungsten_refresh:1567241907116187658> **Channel Tools:** 136 slowmode scopes and name decorators + channelspanel\n` +
        `• <a:tungsten_refresh:1567241907116187658> **Role Rotator:** 61 safe badge rotation presets + rotatorpanel\n` +
        `• <a:tungsten_chart:1567234342701367357> **Notes & Stats:** 103 staff notes, 5-tier watchlist + casespanel\n\n` +
        `*Select a hub from the menu below to view actions and commands.*`,
      footerText: `Tungsten Mod Hub • ${guild.name}`
    });

    const select = new StringSelectMenuBuilder()
      .setCustomId('tungmod:select_hub')
      .setPlaceholder('Select a Tungsten Mod Hub...')
      .addOptions(
        Object.entries(HUBS).map(([k, v]) => ({
          label: v.label,
          value: k,
          description: v.description.slice(0, 50),
          emoji: v.emoji
        }))
      );

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('tungmod:btn:quick').setLabel('Quick Punish').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_warn:1567246685082746940>'),
      new ButtonBuilder().setCustomId('tungmod:btn:rules').setLabel('Message Rules').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_shield:1567242104923627574>'),
      new ButtonBuilder().setCustomId('tungmod:btn:logs').setLabel('Event Logs').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
      new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_sweep:1567242656281657414>')
    );

    return { embeds: [card], components: [new ActionRowBuilder().addComponents(select), buttons] };
  }

  const hub = HUBS[hubKey] || HUBS.quick;

  const card = createV2Card({
    color: 0x2b2d31,
    title: `${hub.emoji}  Tungsten Mod • ${hub.label}`,
    description:
      `> **${hub.description}**\n\n` +
      `**Quick Executions & Commands:**\n` +
      (hubKey === 'quick'
        ? `• \`${prefix}qp <action> <reason> <@user>\` — Quick punish with pre-configured reason\n` +
          `• \`${prefix}quickpanel\` — Interactive 2-click punishment GUI\n` +
          `• Actions: \`warn\`, \`mute10m\`, \`mute1h\`, \`mute1d\`, \`kick\`, \`softban\`, \`ban\`, \`tban7d\``
        : hubKey === 'rules'
        ? `• \`${prefix}msgrule <rule> on/off\` — Toggle automated message inspection\n` +
          `• \`${prefix}rulespanel\` — Interactive message rules toggle studio\n` +
          `• Presets: \`msgrules preset relaxed/balanced/strict\``
        : hubKey === 'gates'
        ? `• \`${prefix}joingate <gate> on/off\` — Toggle join verification filter\n` +
          `• \`${prefix}gatespanel\` — Account age, avatar, and cluster gate studio`
        : hubKey === 'logs'
        ? `• \`${prefix}evlog <event> on/off\` — Toggle specific audit dispatch\n` +
          `• \`${prefix}logspanel\` — Configure log channels and burst suppression`
        : hubKey === 'perms'
        ? `• \`${prefix}chperm <perm> allow/deny\` — Channel permission preset\n` +
          `• \`${prefix}permspanel\` — Visual channel permission manager`
        : hubKey === 'roles'
        ? `• \`${prefix}rolepaint <color>\` — Apply curated role hex color\n` +
          `• \`${prefix}rolespanel\` — Member bulk actions and nickname fixer`
        : hubKey === 'channels'
        ? `• \`${prefix}chslow <time>\` — Precision slowmode (0s to 6h)\n` +
          `• \`${prefix}channelspanel\` — Channel and category management studio`
        : hubKey === 'rotator'
        ? `• \`${prefix}rotate start/stop\` — Safe role badge rotator\n` +
          `• \`${prefix}rotatorpanel\` — Palette, emoji set, and interval picker`
        : `• \`${prefix}staffnote <type> <@user> <note>\` — Save typed staff note\n` +
          `• \`${prefix}casespanel\` — 5-tier watchlist and mod statistics`
      ) +
      `\n\n-# Select another hub from the dropdown menu below.`,
    footerText: `Tungsten Mod Hub • ${guild.name}`
  });

  const select = new StringSelectMenuBuilder()
    .setCustomId('tungmod:select_hub')
    .setPlaceholder(`Current: ${hub.label}`)
    .addOptions([
      { label: 'Overview Home', value: 'overview', emoji: '<a:tungsten_refresh:1567241907116187658>', description: 'Return to Master Hub Overview' },
      ...Object.entries(HUBS).map(([k, v]) => ({
        label: v.label,
        value: k,
        description: v.description.slice(0, 50),
        emoji: v.emoji,
        default: k === hubKey
      }))
    ]);

  const buttons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tungmod:btn:overview').setLabel('Home Overview').setStyle(ButtonStyle.Primary).setEmoji('<a:tungsten_refresh:1567241907116187658>'),
    new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Danger).setEmoji('<a:tungsten_sweep:1567242656281657414>')
  );

  return { embeds: [card], components: [new ActionRowBuilder().addComponents(select), buttons] };
}

module.exports = {
  name: 'tungmod',
  permissions: ['ModerateMembers'],
  botPermissions: ['SendMessages','EmbedLinks'],
  aliases: [
    'quickpanel',
    'rulespanel',
    'gatespanel',
    'logspanel',
    'permspanel',
    'rolespanel',
    'channelspanel',
    'rotatorpanel',
    'casespanel',
    'tungmodpanel',
    'tungstenmod'
  ],
  category: 'moderation',
  description: 'Tungsten Mod Master Control Panel & 9 Hub Suites (3,200 Spec Suite).',
  usage: '[hub name | quick | rules | gates | logs | perms | roles | channels | rotator | cases]',
  cooldown: 2,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const isAuthorized =
      hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) ||
      hasPerm(message.member, PermissionsBitField.Flags.ModerateMembers);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Server` or `Moderate Members` permission to access Tungsten Mod.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'tungmod').toLowerCase();
    let initialHub = 'overview';

    // Route dedicated panel aliases: !quickpanel, !rulespanel, etc.
    const panelAliasMap = {
      quickpanel: 'quick',
      rulespanel: 'rules',
      gatespanel: 'gates',
      logspanel: 'logs',
      permspanel: 'perms',
      rolespanel: 'roles',
      channelspanel: 'channels',
      rotatorpanel: 'rotator',
      casespanel: 'cases'
    };

    if (panelAliasMap[invoked]) {
      initialHub = panelAliasMap[invoked];
    } else if (args[0] && HUBS[args[0].toLowerCase()]) {
      initialHub = args[0].toLowerCase();
    }

    const payload = buildTungmodHubCard(message.guild, initialHub, prefix);
    return message.reply(payload);
  },

  buildTungmodHubCard,
  buildCelmodHubCard: buildTungmodHubCard,
  HUBS
};
