/**
 * Voice Drag & Move Command (Node.js)
 * Relocates a specific voice member or all connected voice members to a target voice channel.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed, hasPerm, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'vdrag',
  aliases: ['voicedrag', 'drag', 'vcmove', 'movevc', 'dragall'],
  category: 'moderation',
  description: 'Move a specific voice member or all members to another voice channel.',
  usage: '<@member|id|all> [destination channel]',
  cooldown: 3,
  permissions: ['MoveMembers'],
  botPermissions: ['MoveMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!args || args.length === 0) {
      const usageEmbed = createEmbed({
        color: 0x5865F2,
        title: `${EMOJIS.PLANE}  Voice Drag & Move System`,
        description:
          `> Move a connected voice member or mass relocate all members to another channel.\n\n` +
          `• **Usage:**\n` +
          `  - \`${prefix}vdrag <@member|id> [destination channel]\` — Move member to destination (or your VC)\n` +
          `  - \`${prefix}vdrag all [destination channel]\` — Move all members in your VC to destination\n` +
          `• **Aliases:** \`voicedrag\`, \`drag\`, \`vcmove\`, \`movevc\`, \`dragall\`\n\n` +
          `*Note: If no destination channel is specified, targets will be dragged into your current voice channel.*`
      });
      return message.reply({ embeds: [usageEmbed] });
    }

    const sub = args[0].toLowerCase();

    // ─────────────────────────────────────────────────────────────
    // A. Mass Relocate All Members (!vdrag all [dest channel])
    // ─────────────────────────────────────────────────────────────
    if (sub === 'all') {
      let sourceChannel = message.member?.voice?.channel;
      let targetChannel = null;

      // Check if destination channel provided in arguments
      const channelMention = message.mentions?.channels?.first();
      const rawTarget = args[1]?.replace(/[<#>]/g, '');

      if (channelMention && channelMention.isVoiceBased()) {
        targetChannel = channelMention;
      } else if (rawTarget) {
        targetChannel = message.guild.channels.cache.get(rawTarget)
          || message.guild.channels.cache.find(c => c.isVoiceBased() && c.name.toLowerCase() === rawTarget.toLowerCase())
          || (typeof message.guild.channels.fetch === 'function' ? await message.guild.channels.fetch(rawTarget).catch(() => null) : null);
      }

      // If user provided 2 channels: !vdrag all #source #dest
      if (args[2]) {
        const rawDest = args[2].replace(/[<#>]/g, '');
        const candidateDest = message.guild.channels.cache.get(rawDest)
          || message.guild.channels.cache.find(c => c.isVoiceBased() && c.name.toLowerCase() === rawDest.toLowerCase())
          || (typeof message.guild.channels.fetch === 'function' ? await message.guild.channels.fetch(rawDest).catch(() => null) : null);
        if (candidateDest && candidateDest.isVoiceBased()) {
          sourceChannel = targetChannel;
          targetChannel = candidateDest;
        }
      }

      // Check multi-word channel name (e.g. !vdrag all Gaming Lounge)
      if (!targetChannel && args.length >= 2) {
        const remaining = args.slice(1).join(' ').replace(/[<#>]/g, '').trim().toLowerCase();
        targetChannel = message.guild.channels.cache.find(c => c.isVoiceBased() && c.name.toLowerCase() === remaining);
      }

      if (!sourceChannel) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel or specify source and destination channels.');
      }
      if (!targetChannel) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a destination voice channel: \`${prefix}vdrag all #destination\``);
      }
      if (!targetChannel.isVoiceBased()) {
        return message.reply('<a:tungsten_close:1567234632905138206> The destination channel must be a voice or stage channel.');
      }
      if (sourceChannel.id === targetChannel.id) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Source and destination channels cannot be the same (**${targetChannel.name}**).`);
      }

      const membersToMove = sourceChannel.members
        ? Array.from(sourceChannel.members.values()).filter(m => m.id !== client.user?.id)
        : [];

      if (membersToMove.length === 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> No members connected in **${sourceChannel.name}** to move.`);
      }

      let movedCount = 0;
      let failCount = 0;
      for (const member of membersToMove) {
        try {
          await member.voice.setChannel(targetChannel, `[vdrag all] Relocated by ${message.author.tag}`);
          movedCount++;
        } catch (e) {
          failCount++;
        }
      }

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: EMOJIS.PLANE,
          action: 'vdrag_all',
          targetId: message.guild.id,
          moderatorId: message.author.id,
          reason: `Relocated ${movedCount} members from ${sourceChannel.name} to ${targetChannel.name}`
        });
      } catch (_) {}

      const resultEmbed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.PLANE}  Mass Voice Relocation Complete`,
        description:
          `> Successfully moved **${movedCount}** members from **${sourceChannel.name}** to **${targetChannel.name}**.\n` +
          (failCount > 0 ? `\n<a:tungsten_warn:1567246685082746940> *Could not move ${failCount} member(s) due to hierarchy or permissions.*` : '')
      });
      return message.reply({ embeds: [resultEmbed] });
    }

    // ─────────────────────────────────────────────────────────────
    // B. Single Member Relocation (!vdrag <@member|id> [dest])
    // ─────────────────────────────────────────────────────────────
    const cleanUserId = sub.replace(/[<@!>]/g, '');
    const targetMember = message.mentions?.members?.first()
      || message.guild.members?.cache?.get(cleanUserId)
      || (typeof message.guild.members?.fetch === 'function' ? await message.guild.members.fetch(cleanUserId).catch(() => null) : null);

    if (!targetMember) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve \`${args[0]}\` to a valid server member.`);
    }

    if (isOwner(targetMember.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot move a Bot Owner.');
    }
    if (targetMember.id === message.guild.ownerId) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot move the Server Owner.');
    }
    if (targetMember.id === client.user?.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> I cannot move myself with this command.');
    }
    if (!isOwner(message.author.id) && message.author.id !== message.guild.ownerId) {
      if (message.member?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
        if (message.member.roles.highest.position <= targetMember.roles.highest.position) {
          return message.reply('<a:tungsten_close:1567234632905138206> You cannot move this member because their highest role is equal to or higher than yours.');
        }
      }
    }
    if (message.guild.members.me?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
      if (message.guild.members.me.roles.highest.position <= targetMember.roles.highest.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot move this member because their highest role is higher than or equal to mine.');
      }
    }

    const currentVoice = targetMember.voice?.channel;
    if (!currentVoice) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is not connected to any voice channel.`);
    }

    let destinationVoice = null;
    const channelMention = message.mentions?.channels?.first();
    const rawDest = args[1]?.replace(/[<#>]/g, '');

    if (channelMention && channelMention.isVoiceBased()) {
      destinationVoice = channelMention;
    } else if (rawDest) {
      destinationVoice = message.guild.channels.cache.get(rawDest)
        || message.guild.channels.cache.find(c => c.isVoiceBased() && c.name.toLowerCase() === rawDest.toLowerCase())
        || (typeof message.guild.channels.fetch === 'function' ? await message.guild.channels.fetch(rawDest).catch(() => null) : null);
    }

    // Check multi-word channel name (e.g. !vdrag @user Gaming Lounge)
    if (!destinationVoice && args.length >= 2) {
      const remaining = args.slice(1).join(' ').replace(/[<#>]/g, '').trim().toLowerCase();
      destinationVoice = message.guild.channels.cache.find(c => c.isVoiceBased() && c.name.toLowerCase() === remaining);
    }

    if (!destinationVoice && message.member?.voice?.channel) {
      destinationVoice = message.member.voice.channel;
    }

    if (!destinationVoice) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a destination voice channel or join one yourself: \`${prefix}vdrag <@user> #voice-channel\``);
    }

    if (!destinationVoice.isVoiceBased()) {
      return message.reply('<a:tungsten_close:1567234632905138206> The destination channel must be a voice or stage channel.');
    }

    if (currentVoice.id === destinationVoice.id) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is already in **${destinationVoice.name}**.`);
    }

    try {
      await targetMember.voice.setChannel(destinationVoice, `[vdrag] Dragged by ${message.author.tag}`);

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: EMOJIS.PLANE,
          action: 'vdrag',
          targetId: targetMember.id,
          moderatorId: message.author.id,
          reason: `Moved from ${currentVoice.name} to ${destinationVoice.name}`
        });
      } catch (_) {}

      const dragEmbed = createEmbed({
        color: 0x57F287,
        title: `${EMOJIS.PLANE}  Member Relocated`,
        description: `> Successfully moved <@${targetMember.id}> from **${currentVoice.name}** to **${destinationVoice.name}**.`
      });
      return message.reply({ embeds: [dragEmbed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to move member: ${err.message}`);
    }
  }
};
