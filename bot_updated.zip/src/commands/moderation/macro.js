/**
 * Mod Macros Command (Slice 2.2)
 * Create and execute chained moderation action bundles with hierarchy protection.
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { logAction } = require('../../utils/modlog');
const { checkAndExecuteLadder } = require('../../utils/warnLadder');
const { EMOJIS } = require('../../utils/emojis');

const VALID_ACTIONS = ['warn', 'mute', 'kick', 'ban', 'softban', 'dm', 'nick'];

function parseMacroDuration(input) {
  if (!input) return 10 * 60 * 1000; // default 10 minutes
  const match = String(input).trim().match(/^(\d+)\s*(s|m|h|d|w)?$/i);
  if (!match) return 10 * 60 * 1000;
  const num = parseInt(match[1], 10);
  const unit = (match[2] || 'm').toLowerCase();
  switch (unit) {
    case 's': return num * 1000;
    case 'm': return num * 60 * 1000;
    case 'h': return num * 60 * 60 * 1000;
    case 'd': return num * 24 * 60 * 60 * 1000;
    case 'w': return num * 7 * 24 * 60 * 60 * 1000;
    default: return num * 60 * 1000;
  }
}

function formatMacroDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}

function parseSteps(stepString) {
  if (!stepString || typeof stepString !== 'string') return [];
  const tokens = stepString.split(/(?:->|=>|>|,|;)/).map(t => t.trim()).filter(Boolean);
  const parsed = [];

  for (const token of tokens) {
    const colonIdx = token.indexOf(':');
    let action = token.toLowerCase();
    let param = null;
    if (colonIdx !== -1) {
      action = token.slice(0, colonIdx).trim().toLowerCase();
      param = token.slice(colonIdx + 1).trim();
    }

    if (action === 'warning') action = 'warn';
    if (action === 'timeout' || action === 'tempmute') action = 'mute';
    if (action === 'msg' || action === 'message') action = 'dm';
    if (action === 'nickname' || action === 'dehoist') action = 'nick';

    if (!VALID_ACTIONS.includes(action)) {
      throw new Error(`Unsupported macro action: "${action}". Valid actions: ${VALID_ACTIONS.join(', ')}.`);
    }

    parsed.push({ action, param, raw: token });
  }

  return parsed;
}

function getRequiredPermissionForSteps(steps) {
  const actions = steps.map(s => s.action);
  if (actions.includes('ban')) return 'BanMembers';
  if (actions.includes('kick') || actions.includes('softban')) return 'KickMembers';
  if (actions.includes('mute')) return 'ModerateMembers';
  if (actions.includes('nick')) return 'ManageNicknames';
  return 'ManageMessages';
}

function formatStepsReadable(steps) {
  return steps.map(s => {
    if (s.action === 'mute') {
      const dur = s.param ? formatMacroDuration(parseMacroDuration(s.param)) : '10m';
      return `mute (${dur})`;
    }
    if (s.param) {
      return `${s.action} ("${s.param}")`;
    }
    return s.action;
  }).join(' ➔ ');
}

async function handleMacro({ guild, member, author, subcommand, name, stepsInput, targetInput, reason, client, prefix = '!' }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  const sdb = getServerDb(guild.id);
  const sub = (subcommand || 'list').toLowerCase();

  // 1. CREATE
  if (sub === 'create') {
    if (!name || !stepsInput) {
      return {
        error: `**Usage:** \`${prefix}macro create <name> <steps>\`\n` +
          `**Example:** \`${prefix}macro create raidspam warn -> mute:10m -> dm:Stop spamming\``
      };
    }

    const cleanName = String(name).toLowerCase().trim();
    if (!/^[a-z0-9_-]{2,32}$/.test(cleanName)) {
      return {
        error: '<a:tungsten_close:1567234632905138206> Invalid macro name. Names must be 2-32 characters and contain only alphanumeric characters, underscores, or dashes.'
      };
    }

    let parsedSteps = [];
    try {
      parsedSteps = parseSteps(stepsInput);
    } catch (err) {
      return { error: `<a:tungsten_close:1567234632905138206> ${err.message}` };
    }

    if (parsedSteps.length === 0) {
      return { error: '<a:tungsten_close:1567234632905138206> At least one valid action step is required to create a macro.' };
    }

    if (parsedSteps.length > 10) {
      return { error: '<a:tungsten_close:1567234632905138206> A macro cannot contain more than 10 action steps.' };
    }

    const requiredPerm = getRequiredPermissionForSteps(parsedSteps);

    // Verify creator possesses required permission
    if (!hasPerm(member, requiredPerm) && !hasPerm(member, PermissionFlagsBits[requiredPerm])) {
      return {
        error: `<a:tungsten_close:1567234632905138206> You cannot create a macro containing actions that require the **${requiredPerm}** permission which you do not possess.`
      };
    }

    const stepsJson = JSON.stringify(parsedSteps);
    const now = Math.floor(Date.now() / 1000);

    sdb.prepare(`
      INSERT INTO mod_macros (guild_id, name, steps_json, required_permission, created_by, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, name) DO UPDATE SET
        steps_json = excluded.steps_json,
        required_permission = excluded.required_permission,
        created_by = excluded.created_by,
        created_at = excluded.created_at
    `).run(guild.id, cleanName, stepsJson, requiredPerm, author.id, now);

    return {
      success: true,
      embed: createEmbed({
        color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: `${EMOJIS.ZAP} Mod Macro Created: ${cleanName}`,
        description: `Successfully configured chained moderation macro **${cleanName}**.\n\n` +
          `• **Action Sequence:** \`${formatStepsReadable(parsedSteps)}\`\n` +
          `• **Required Permission:** \`${requiredPerm}\`\n` +
          `• **Created By:** <@${author.id}>\n\n` +
          `**Usage:** \`${prefix}macro run ${cleanName} @user [reason]\``
      })
    };
  }

  // 2. RUN
  if (sub === 'run') {
    if (!name || !targetInput) {
      return {
        error: `**Usage:** \`${prefix}macro run <name> <@user|id> [reason]\`\n` +
          `**Example:** \`${prefix}macro run raidspam @BadUser Excessive spam\`\n` +
          `Use \`${prefix}macro list\` to see available macros.`
      };
    }

    const cleanName = String(name).toLowerCase().trim();
    const macroRow = sdb.prepare('SELECT * FROM mod_macros WHERE guild_id = ? AND name = ?').get(guild.id, cleanName);

    if (!macroRow) {
      return {
        error: `<a:tungsten_close:1567234632905138206> Macro **${cleanName}** not found in this server. Use \`${prefix}macro list\` to see available macros.`
      };
    }

    let steps = [];
    try {
      steps = JSON.parse(macroRow.steps_json);
    } catch (_) {
      return { error: '<a:tungsten_close:1567234632905138206> Failed to parse macro configuration.' };
    }

    // Permission Enforcement
    const requiredPerm = macroRow.required_permission || 'ManageMessages';
    if (!hasPerm(member, requiredPerm) && !hasPerm(member, PermissionFlagsBits[requiredPerm])) {
      return {
        error: `<a:tungsten_close:1567234632905138206> Permission Denied: Running macro **${cleanName}** requires the **${requiredPerm}** permission.`
      };
    }

    // Target Resolution
    const cleanTargetId = String(targetInput).replace(/[<@!>]/g, '').trim();
    if (!/^\d{16,20}$/.test(cleanTargetId)) {
      return { error: '<a:tungsten_close:1567234632905138206> Invalid user target provided. Please mention a member or provide a valid user ID.' };
    }

    let targetUser = null;
    try {
      targetUser = await client.users.fetch(cleanTargetId).catch(() => null);
    } catch (_) {}

    if (!targetUser) {
      return { error: '<a:tungsten_close:1567234632905138206> Could not find that Discord user.' };
    }

    // Hierarchy & Immunity Safeguards
    if (isOwner(targetUser.id)) {
      return { error: '<a:tungsten_close:1567234632905138206> You cannot run a moderation macro on a Bot Owner.' };
    }
    if (targetUser.id === guild.ownerId) {
      return { error: '<a:tungsten_close:1567234632905138206> You cannot run a moderation macro on the Server Owner.' };
    }
    if (client.user && targetUser.id === client.user.id) {
      return { error: '<a:tungsten_close:1567234632905138206> I cannot run a moderation macro on myself.' };
    }
    if (targetUser.id === author.id) {
      return { error: '<a:tungsten_close:1567234632905138206> You cannot run a moderation macro on yourself.' };
    }

    let targetMember = null;
    try {
      targetMember = await guild.members.fetch(cleanTargetId).catch(() => null);
    } catch (_) {}

    if (targetMember) {
      // Moderator hierarchy check
      if (!isOwner(author.id) && author.id !== guild.ownerId) {
        if (targetMember.roles?.highest && member.roles?.highest) {
          if (targetMember.roles.highest.position >= member.roles.highest.position) {
            return {
              error: '<a:tungsten_close:1567234632905138206> Hierarchy Protection: You cannot moderate a member with an equal or higher role than yours.'
            };
          }
        }
      }

      // Bot hierarchy check
      const me = guild.members.me;
      if (me && targetMember.roles?.highest && me.roles?.highest) {
        if (targetMember.roles.highest.position >= me.roles.highest.position) {
          return {
            error: '<a:tungsten_close:1567234632905138206> Hierarchy Protection: I cannot moderate a member with a role higher than or equal to my highest role.'
          };
        }
      }
    }

    // Bot Permission Verification for Steps
    const me = guild.members.me;
    const actions = steps.map(s => s.action);
    if (actions.includes('kick') && !me.permissions.has(PermissionFlagsBits.KickMembers)) {
      return { error: '<a:tungsten_close:1567234632905138206> Bot Missing Permission: I lack the **Kick Members** permission.' };
    }
    if ((actions.includes('ban') || actions.includes('softban')) && !me.permissions.has(PermissionFlagsBits.BanMembers)) {
      return { error: '<a:tungsten_close:1567234632905138206> Bot Missing Permission: I lack the **Ban Members** permission.' };
    }
    if (actions.includes('mute') && !me.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return { error: '<a:tungsten_close:1567234632905138206> Bot Missing Permission: I lack the **Moderate Members** (Timeout) permission.' };
    }

    const cleanReason = reason || 'No reason provided';
    const executedResults = [];

    // Sequential Step Execution
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      const stepNum = i + 1;
      const stepReason = `${cleanReason} | Macro: ${cleanName}`;

      try {
        switch (step.action) {
          case 'warn': {
            sdb.prepare(`
              INSERT INTO member_warnings (guild_id, user_id, moderator_id, reason, timestamp)
              VALUES (?, ?, ?, ?, ?)
            `).run(guild.id, targetUser.id, author.id, stepReason, Date.now());

            const totalWarns = sdb.prepare('SELECT COUNT(*) as count FROM member_warnings WHERE guild_id = ? AND user_id = ?')
              .get(guild.id, targetUser.id)?.count || 1;

            if (targetMember && typeof checkAndExecuteLadder === 'function') {
              try {
                await checkAndExecuteLadder(guild, targetMember, totalWarns, stepReason, client);
              } catch (_) {}
            }

            await logAction(guild, sdb, {
              emoji: '<a:tungsten_warn:1567246685082746940>',
              action: 'warn',
              targetId: targetUser.id,
              moderatorId: author.id,
              reason: stepReason,
              extra: `Total Warnings: ${totalWarns}`
            });

            executedResults.push(`\`[Step ${stepNum}]\` **Warn:** Warning issued (Warning #${totalWarns})`);
            break;
          }

          case 'mute': {
            if (!targetMember) {
              executedResults.push(`\`[Step ${stepNum}]\` **Timeout:** Skipped (user is not in server)`);
              break;
            }
            const durationMs = parseMacroDuration(step.param);
            const clampedMs = Math.min(durationMs, 28 * 24 * 60 * 60 * 1000);
            await targetMember.timeout(clampedMs, stepReason);

            await logAction(guild, sdb, {
              emoji: EMOJIS.MUTE,
              action: 'mute',
              targetId: targetUser.id,
              moderatorId: author.id,
              reason: stepReason,
              extra: `Duration: ${formatMacroDuration(clampedMs)}`
            });

            executedResults.push(`\`[Step ${stepNum}]\` **Timeout:** Applied for \`${formatMacroDuration(clampedMs)}\``);
            break;
          }

          case 'dm': {
            const dmContent = step.param || `You have received a moderation action in **${guild.name}**.\n**Reason:** ${cleanReason}`;
            let sent = false;
            try {
              await targetUser.send({
                content: `> **Moderation Notice from ${guild.name}**\n${dmContent}`
              });
              sent = true;
            } catch (_) {
              sent = false;
            }
            executedResults.push(`\`[Step ${stepNum}]\` **DM:** ${sent ? 'Delivered successfully' : 'Undelivered (user DMs closed)'}`);
            break;
          }

          case 'kick': {
            if (!targetMember) {
              executedResults.push(`\`[Step ${stepNum}]\` **Kick:** Skipped (user is not in server)`);
              break;
            }
            await targetMember.kick(stepReason);

            await logAction(guild, sdb, {
              emoji: EMOJIS.BOOT,
              action: 'kick',
              targetId: targetUser.id,
              moderatorId: author.id,
              reason: stepReason
            });

            executedResults.push(`\`[Step ${stepNum}]\` **Kick:** Member kicked from server`);
            break;
          }

          case 'ban': {
            await guild.members.ban(targetUser.id, { reason: stepReason });

            await logAction(guild, sdb, {
              emoji: EMOJIS.HAMMER,
              action: 'ban',
              targetId: targetUser.id,
              moderatorId: author.id,
              reason: stepReason
            });

            executedResults.push(`\`[Step ${stepNum}]\` **Ban:** Member permanently banned`);
            break;
          }

          case 'softban': {
            await guild.members.ban(targetUser.id, { reason: stepReason, deleteMessageSeconds: 86400 });
            await guild.members.unban(targetUser.id, `Softban release | ${stepReason}`).catch(() => null);

            await logAction(guild, sdb, {
              emoji: EMOJIS.SWEEP,
              action: 'softban',
              targetId: targetUser.id,
              moderatorId: author.id,
              reason: stepReason
            });

            executedResults.push(`\`[Step ${stepNum}]\` **Softban:** Messages pruned and member softbanned`);
            break;
          }

          case 'nick': {
            if (!targetMember) {
              executedResults.push(`\`[Step ${stepNum}]\` **Nickname:** Skipped (user is not in server)`);
              break;
            }
            const newNick = step.param || null;
            await targetMember.setNickname(newNick, stepReason);
            executedResults.push(`\`[Step ${stepNum}]\` **Nickname:** Set to \`${newNick || 'Default'}\``);
            break;
          }

          default:
            executedResults.push(`\`[Step ${stepNum}]\` **${step.action}:** Action completed`);
            break;
        }
      } catch (err) {
        executedResults.push(`\`[Step ${stepNum}]\` **${step.action}:** <a:tungsten_close:1567234632905138206> Failed: ${err.message}`);
      }
    }

    return {
      success: true,
      embed: createEmbed({
        color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: `${EMOJIS.ZAP} Mod Macro Executed: ${cleanName}`,
        description: `Successfully executed macro bundle **${cleanName}** on <@${targetUser.id}> (\`${targetUser.id}\`).\n\n` +
          `• **Moderator:** <@${author.id}>\n` +
          `• **Reason:** ${cleanReason}\n\n` +
          `**Execution Breakdown:**\n` +
          executedResults.join('\n')
      })
    };
  }

  // 3. LIST
  if (sub === 'list') {
    const rows = sdb.prepare('SELECT * FROM mod_macros WHERE guild_id = ? ORDER BY name ASC').all(guild.id);

    let desc = `### ${EMOJIS.ZAP} Server Moderation Macros\n\n`;

    if (!rows || rows.length === 0) {
      desc += '*No moderation macros configured yet.*\n\n' +
        `Create your first macro using:\n` +
        `\`${prefix}macro create <name> <steps>\`\n\n` +
        `**Example:**\n` +
        `\`${prefix}macro create raidspam warn -> mute:10m -> dm:Please stop spamming\``;
    } else {
      for (const r of rows) {
        let flowStr = '';
        try {
          const parsed = JSON.parse(r.steps_json);
          flowStr = formatStepsReadable(parsed);
        } catch (_) {
          flowStr = 'Unknown steps';
        }

        desc += `• **\`${r.name}\`** [${r.required_permission || 'ManageMessages'}]\n` +
          `  └ ➔ \`${flowStr}\` • By <@${r.created_by}> (<t:${r.created_at}:R>)\n`;
      }
      desc += `\n*Run a macro:* \`${prefix}macro run <name> @user [reason]\``;
    }

    return {
      embed: createEmbed({
        color: client?.config?.COLORS?.PRIMARY || 0x000001,
        title: `Moderation Macros • ${guild.name}`,
        description: desc
      })
    };
  }

  // 4. DELETE
  if (sub === 'delete') {
    if (!name) {
      return { error: `**Usage:** \`${prefix}macro delete <name>\`` };
    }

    const cleanName = String(name).toLowerCase().trim();
    const existing = sdb.prepare('SELECT 1 FROM mod_macros WHERE guild_id = ? AND name = ?').get(guild.id, cleanName);

    if (!existing) {
      return { error: `<a:tungsten_close:1567234632905138206> Macro **${cleanName}** does not exist in this server.` };
    }

    sdb.prepare('DELETE FROM mod_macros WHERE guild_id = ? AND name = ?').run(guild.id, cleanName);

    return {
      success: true,
      embed: createEmbed({
        color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: '<a:tungsten_trash:1567242891276062872> Mod Macro Deleted',
        description: `Successfully deleted moderation macro **${cleanName}** from this server.`
      })
    };
  }

  return {
    error: `Unknown subcommand. Available: \`create\`, \`run\`, \`list\`, \`delete\`.`
  };
}

module.exports = {
  name: 'macro',
  category: 'moderation',
  description: 'Create and run chained moderation action macros with hierarchy safety.',
  usage: '<create|run|list|delete> [name] [@user] [reason]',
  cooldown: 3,
  permissions: ['ManageMessages'],
  botPermissions: ['ModerateMembers', 'EmbedLinks'],
  aliases: ['macros', 'modmacro', 'modmacros'],

  slash: new SlashCommandBuilder()
    .setName('macro')
    .setDescription('Create and execute chained moderation action macros')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand(sub =>
      sub.setName('create')
        .setDescription('Create a chained moderation macro')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Name of the macro (alphanumeric, dashes, underscores)')
            .setRequired(true)
        )
        .addStringOption(opt =>
          opt.setName('steps')
            .setDescription('Steps (e.g., warn -> mute:10m -> dm:Stop spamming)')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('run')
        .setDescription('Execute a chained moderation macro on a member')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Name of the macro to run')
            .setRequired(true)
        )
        .addUserOption(opt =>
          opt.setName('target')
            .setDescription('Target user or member')
            .setRequired(true)
        )
        .addStringOption(opt =>
          opt.setName('reason')
            .setDescription('Reason for the moderation action')
            .setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all saved moderation macros for this server')
    )
    .addSubcommand(sub =>
      sub.setName('delete')
        .setDescription('Delete a saved moderation macro')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Name of the macro to delete')
            .setRequired(true)
        )
    ),

  async execute(message, args, client, prefix) {
    const sub = (args[0] || 'list').toLowerCase();
    const name = args[1];

    let stepsInput = null;
    let targetInput = null;
    let reason = null;

    if (sub === 'create') {
      stepsInput = args.slice(2).join(' ');
    } else if (sub === 'run') {
      targetInput = args[2];
      reason = args.slice(3).join(' ');
    }

    const res = await handleMacro({
      guild: message.guild,
      member: message.member,
      author: message.author,
      subcommand: sub,
      name,
      stepsInput,
      targetInput,
      reason,
      client,
      prefix
    });

    if (res.error) {
      if (res.embed) return message.reply({ embeds: [res.embed] });
      return message.reply(res.error);
    }
    return message.reply({ embeds: [res.embed] });
  },

  async executeSlash(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const name = interaction.options.getString('name');
    const stepsInput = interaction.options.getString('steps');
    const targetUser = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason');

    const res = await handleMacro({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      subcommand: sub,
      name,
      stepsInput,
      targetInput: targetUser ? targetUser.id : null,
      reason,
      client,
      prefix: '/'
    });

    if (res.error) {
      if (res.embed) return interaction.reply({ embeds: [res.embed], ephemeral: true });
      return interaction.reply({ content: res.error, ephemeral: true });
    }
    return interaction.reply({ embeds: [res.embed] });
  },

  handleMacro,
  parseSteps,
  getRequiredPermissionForSteps,
  parseMacroDuration,
  formatMacroDuration
};
