const { PermissionFlagsBits } = require('discord.js');
const { getPanelEmbed, buildCategorySelect, buildCategoryButtons } = require('./modpanel');
const { hasPerm } = require('../../utils/tools');

module.exports = {
  name: 'modrolepanel',
  aliases: ['rolemodpanel'],
  category: 'moderation',
  description: 'Opens dedicated Member Roles & Nickname Management GUI panel',
  usage: '',
  cooldown: 3,
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageRoles)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Roles** permission to access the Mod Role Panel.');
    }
    const embed = getPanelEmbed('roles', message.guild, message.author, client, prefix);
    const selectMenu = buildCategorySelect('roles', message.author.id);
    const buttons = buildCategoryButtons('roles', message.author.id);
    return message.reply({ embeds: [embed], components: [selectMenu, ...buttons] });
  }
};
