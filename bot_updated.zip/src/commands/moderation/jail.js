/**
 * Jail Command (Node.js)
 * Isolates problematic members into a designated jail channel by temporarily
 * stripping their roles and assigning a jail role, with full role restoration upon release.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'jail',
  aliases: ['unjail'],
  category: 'moderation',
  description: 'Manage jailed members and jail cell.',
  usage: '<setup <@role> <#channel> | add <@user> [reason] | remove <@user> | list | config | reset>',
  cooldown: 3,
  permissions: ['ManageRoles', 'ModerateMembers'],
  botPermissions: ['ManageRoles', 'ManageChannels'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const sdb = getServerDb(message.guild.id);
    const sub = (args[0] || '').toLowerCase();

    // If invoked via unjail alias: !unjail <@user>
    if (message.content && message.content.toLowerCase().startsWith(`${prefix}unjail`)) {
      return this.handleRemove(message, args, client, sdb, prefix);
    }

    // Subcommand dispatch
    switch (sub) {
      case 'setup':
        return this.handleSetup(message, args.slice(1), client, sdb, prefix);
      case 'add':
        return this.handleAdd(message, args.slice(1), client, sdb, prefix);
      case 'remove':
      case 'del':
      case 'unjail':
        return this.handleRemove(message, args.slice(1), client, sdb, prefix);
      case 'list':
        return this.handleList(message, client, sdb);
      case 'config':
      case 'show':
        return this.handleConfig(message, client, sdb);
      case 'reset':
      case 'clear':
        return this.handleReset(message, client, sdb);
      default: {
        // If the first argument is a user mention or snowflake ID, treat as "jail add"
        if (sub && (message.mentions?.members?.first?.() || /^\d{17,20}$/.test(sub))) {
          return this.handleAdd(message, args, client, sdb, prefix);
        }

        const helpEmbed = createEmbed({
          color: 0x2b2d31,
          title: `${EMOJIS.SCALES}  Jail Moderation System`,
          description:
            `> Manage server isolation cell and jailed offenders.\n\n` +
            `• **\`${prefix}jail setup <@role> <#channel>\`** — Set jail role and channel\n` +
            `• **\`${prefix}jail add <@user> [reason]\`** — Strip roles and isolate user in jail\n` +
            `• **\`${prefix}jail remove <@user>\`** — Release user and restore original roles\n` +
            `• **\`${prefix}jail list\`** — List all currently jailed users\n` +
            `• **\`${prefix}jail config\`** — View current jail role & channel configuration\n` +
            `• **\`${prefix}jail reset\`** — Clear jail cell setup`
        });
        return message.reply({ embeds: [helpEmbed] });
      }
    }
  },

  async handleSetup(message, args, client, sdb, prefix) {
    if (!hasPerm(message.member, 'Administrator') && !hasPerm(message.member, 'ManageGuild')) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Server** or **Administrator** permission to configure jail.');
    }

    const roleMention = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
    const channelMention = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);

    if (!roleMention || !channelMention) {
      return message.reply(
        `<a:tungsten_warn:1567246685082746940> **Invalid Arguments:**\n` +
        `• **Usage:** \`${prefix}jail setup <@role> <#channel>\`\n` +
        `• **Example:** \`${prefix}jail setup @Jailed #jail-cell\``
      );
    }

    sdb.prepare(`
      INSERT INTO jail_config (guild_id, role_id, channel_id)
      VALUES (?, ?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET role_id = excluded.role_id, channel_id = excluded.channel_id
    `).run(message.guild.id, roleMention.id, channelMention.id);

    const embed = createEmbed({
      color: client.config.COLORS.SUCCESS,
      title: `${EMOJIS.LOCK}  Jail System Configured`,
      description:
        `> Jail configuration has been successfully saved.\n\n` +
        `• **Jail Role:** ${roleMention} (\`${roleMention.id}\`)\n` +
        `• **Jail Channel:** ${channelMention} (\`${channelMention.id}\`)\n\n` +
        `*Tip: Ensure that the Jail Role has ViewChannel access only in the Jail Channel and is denied in all other channels.*`
    });
    return message.reply({ embeds: [embed] });
  },

  async handleAdd(message, args, client, sdb, prefix) {
    const config = sdb.prepare('SELECT role_id, channel_id FROM jail_config WHERE guild_id = ?').get(message.guild.id);
    if (!config || !config.role_id) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> Jail is not configured in this server. Use \`${prefix}jail setup <@role> <#channel>\` first.`);
    }

    const jailRole = message.guild.roles.cache.get(config.role_id);
    if (!jailRole) {
      return message.reply('<a:tungsten_close:1567234632905138206> Configured jail role no longer exists. Please re-run setup.');
    }

    const targetInput = args[0];
    if (!targetInput) {
      return message.reply(`Usage: \`${prefix}jail add <@user|id> [reason]\``);
    }

    const targetId = targetInput.replace(/[<@!>]/g, '');
    const member = await message.guild.members.fetch(targetId).catch(() => null);
    if (!member) {
      return message.reply('<a:tungsten_close:1567234632905138206> Member not found in this server.');
    }

    if (member.id === message.author.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot jail yourself.');
    }
    if (member.id === message.guild.ownerId) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot jail the server owner.');
    }
    if (isOwner(member.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot jail a bot owner.');
    }

    // Role hierarchy check
    if (message.author.id !== message.guild.ownerId && !isOwner(message.author.id)) {
      if (member.roles.highest.position >= message.member.roles.highest.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> You cannot jail a member with an equal or higher role than yours.');
      }
    }
    const botMember = message.guild.members.me;
    if (botMember && member.roles.highest.position >= botMember.roles.highest.position) {
      return message.reply('<a:tungsten_close:1567234632905138206> I cannot jail this member because their highest role is above or equal to mine.');
    }
    if (botMember && jailRole.position >= botMember.roles.highest.position) {
      return message.reply('<a:tungsten_close:1567234632905138206> The jail role is higher than my highest role. Move my role above it.');
    }

    const reason = args.slice(1).join(' ').trim() || 'No reason provided';

    // Collect member's existing roles (exclude @everyone, managed roles, and jail role itself)
    const savedRoles = member.roles.cache
      .filter(r => r.id !== message.guild.id && !r.managed && r.id !== jailRole.id)
      .map(r => r.id);

    const now = Math.floor(Date.now() / 1000);

    // Save to database
    sdb.prepare(`
      INSERT INTO jailed_users (guild_id, user_id, saved_roles, jailed_at, reason)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        guild_id = excluded.guild_id,
        saved_roles = excluded.saved_roles,
        jailed_at = excluded.jailed_at,
        reason = excluded.reason
    `).run(message.guild.id, member.id, JSON.stringify(savedRoles), now, reason);

    // Strip roles and assign jail role
    try {
      await member.roles.set([jailRole.id], `Jailed by ${message.author.tag}: ${reason}`);
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to apply jail role: ${err.message}`);
    }

    await logAction(message.guild, sdb, {
      emoji: EMOJIS.SCALES,
      action: 'jail',
      targetId: member.id,
      moderatorId: message.author.id,
      reason
    }).catch(() => null);

    const embed = createEmbed({
      color: 0xED4245,
      title: `${EMOJIS.SCALES}  Member Jailed`,
      description:
        `> ${member} (\`${member.id}\`) has been sent to jail.\n\n` +
        `• **Moderator:** ${message.author} (\`${message.author.id}\`)\n` +
        `• **Stripped Roles:** \`${savedRoles.length}\` role(s) saved for restoration\n` +
        `• **Reason:** ${reason}\n\n` +
        `*Use \`${prefix}jail remove ${member.id}\` to restore their original roles.*`
    });

    return message.reply({ embeds: [embed] });
  },

  async handleRemove(message, args, client, sdb, prefix) {
    const targetInput = args[0] || (message.mentions.members.first() ? message.mentions.members.first().id : null);
    if (!targetInput) {
      return message.reply(`Usage: \`${prefix}jail remove <@user|id>\``);
    }

    const targetId = targetInput.replace(/[<@!>]/g, '');
    const row = sdb.prepare('SELECT saved_roles, reason FROM jailed_users WHERE guild_id = ? AND user_id = ?').get(message.guild.id, targetId);

    const config = sdb.prepare('SELECT role_id FROM jail_config WHERE guild_id = ?').get(message.guild.id);
    const member = await message.guild.members.fetch(targetId).catch(() => null);

    if (!row && !member?.roles?.cache?.has(config?.role_id)) {
      return message.reply('<a:tungsten_info:1567240890748248084> That user is not currently recorded as jailed.');
    }

    let restoredCount = 0;
    if (member) {
      // Remove jail role
      if (config?.role_id && member.roles.cache.has(config.role_id)) {
        await member.roles.remove(config.role_id, `Unjailed by ${message.author.tag}`).catch(() => null);
      }

      // Restore saved roles
      if (row?.saved_roles) {
        try {
          const roleIds = JSON.parse(row.saved_roles);
          if (Array.isArray(roleIds) && roleIds.length > 0) {
            const validRoles = roleIds.filter(id => message.guild.roles.cache.has(id));
            await member.roles.add(validRoles, `Restoring original roles after jail release by ${message.author.tag}`).catch(() => null);
            restoredCount = validRoles.length;
          }
        } catch (e) {}
      }
    }

    sdb.prepare('DELETE FROM jailed_users WHERE guild_id = ? AND user_id = ?').run(message.guild.id, targetId);

    await logAction(message.guild, sdb, {
      emoji: EMOJIS.UNLOCK,
      action: 'unjail',
      targetId,
      moderatorId: message.author.id,
      reason: 'Released from jail'
    }).catch(() => null);

    const embed = createEmbed({
      color: client.config.COLORS.SUCCESS,
      title: `${EMOJIS.UNLOCK}  Member Unjailed`,
      description:
        `> Successfully released <@${targetId}> from jail.\n\n` +
        `• **Moderator:** ${message.author}\n` +
        `• **Restored Roles:** \`${restoredCount}\` role(s) restored`
    });

    return message.reply({ embeds: [embed] });
  },

  async handleList(message, client, sdb) {
    const rows = sdb.prepare('SELECT user_id, reason, jailed_at FROM jailed_users WHERE guild_id = ? ORDER BY jailed_at DESC').all(message.guild.id);

    if (rows.length === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> There are currently no jailed users in this server.');
    }

    const lines = rows.map((r, i) => {
      const timeStr = r.jailed_at ? `<t:${r.jailed_at}:R>` : 'Unknown date';
      return `\`${i + 1}.\` <@${r.user_id}> (\`${r.user_id}\`) — Jailed ${timeStr}\n> *Reason:* ${r.reason || 'None'}`;
    });

    const embed = createEmbed({
      color: 0x2b2d31,
      title: `${EMOJIS.SCALES}  Jailed Users (${rows.length}) • ${message.guild.name}`,
      description: lines.slice(0, 15).join('\n\n') + (lines.length > 15 ? `\n\n*...and ${lines.length - 15} more.*` : '')
    });

    return message.reply({ embeds: [embed] });
  },

  async handleConfig(message, client, sdb) {
    const config = sdb.prepare('SELECT role_id, channel_id FROM jail_config WHERE guild_id = ?').get(message.guild.id);
    const count = sdb.prepare('SELECT count(*) as cnt FROM jailed_users WHERE guild_id = ?').get(message.guild.id)?.cnt || 0;

    const embed = createEmbed({
      color: 0x5865F2,
      title: `${EMOJIS.LOCK}  Jail Configuration • ${message.guild.name}`,
      description:
        `> Current jail setup and operational status.\n\n` +
        `• **Jail Role:** ${config?.role_id ? `<@&${config.role_id}> (\`${config.role_id}\`)` : '`Not configured`'}\n` +
        `• **Jail Channel:** ${config?.channel_id ? `<#${config.channel_id}> (\`${config.channel_id}\`)` : '`Not configured`'}\n` +
        `• **Currently Jailed Users:** \`${count}\` member(s)`
    });

    return message.reply({ embeds: [embed] });
  },

  async handleReset(message, client, sdb) {
    if (!hasPerm(message.member, 'Administrator')) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need Administrator permissions to reset jail configuration.');
    }

    sdb.prepare('DELETE FROM jail_config WHERE guild_id = ?').run(message.guild.id);
    return message.reply('<a:tungsten_sweep:1567242656281657414> Jail configuration has been reset for this server.');
  }
};
