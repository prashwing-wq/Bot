/**
 * Member Investigation & Alt Risk Audit Command (Node.js)
 * Deep analysis of member account age, permissions, security risk, and past infractions.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'investigate',
  aliases: ['inv', 'auditmember', 'checkalt', 'whoisplus'],
  category: 'moderation',
  description: 'Deep security and disciplinary investigation of a member or suspected alt account.',
  permissions: ['ModerateMembers'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '<@user | user_id>',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Moderate Members` permission to run member investigations.');
    }

    const targetUser = message.mentions?.users?.first() || (args[0] ? await client.users.fetch(args[0]).catch(() => null) : null) || message.author;
    const member = await message.guild.members.fetch(targetUser.id).catch(() => null);

    // Calculate account age in days
    const createdTimestamp = targetUser.createdTimestamp;
    const accountAgeDays = Math.floor((Date.now() - createdTimestamp) / (1000 * 60 * 60 * 24));

    // Calculate join age in days
    const joinedTimestamp = member ? member.joinedTimestamp : null;
    const joinedAgeDays = joinedTimestamp ? Math.floor((Date.now() - joinedTimestamp) / (1000 * 60 * 60 * 24)) : null;

    // Alt Risk Assessment
    let riskLevel = '🟢 LOW RISK';
    let riskReason = 'Established account with standard tenure.';
    if (accountAgeDays < 3) {
      riskLevel = '🔴 CRITICAL RISK (SUSPECTED RAID BOT / NEW ALT)';
      riskReason = `Account created less than 3 days ago (${accountAgeDays}d old).`;
    } else if (accountAgeDays < 14) {
      riskLevel = '🟡 ELEVATED RISK (NEW ACCOUNT)';
      riskReason = `Account created less than 14 days ago (${accountAgeDays}d old).`;
    }

    // Disciplinary Record from mod_cases
    const sdb = getServerDb(message.guild.id);
    const cases = sdb.prepare('SELECT COUNT(*) as cnt FROM mod_cases WHERE guild_id = ? AND user_id = ?').get(message.guild.id, targetUser.id).cnt;
    const warns = sdb.prepare('SELECT COUNT(*) as cnt FROM member_warnings WHERE guild_id = ? AND user_id = ?').get(message.guild.id, targetUser.id).cnt;

    const dangerousPerms = member ? member.permissions.toArray().filter(p => [
      'Administrator', 'ManageGuild', 'ManageRoles', 'ManageChannels', 'BanMembers', 'KickMembers'
    ].includes(p)) : [];

    const embed = createEmbed({
      color: riskLevel.includes('CRITICAL') ? 0xFF0033 : (riskLevel.includes('ELEVATED') ? 0xFEE75C : 0x00FF88),
      title: `🔍  Member Security Dossier • ${targetUser.username}`,
      description:
        `> **Target:** ${targetUser} (\`${targetUser.id}\`)\n` +
        `> **Tenure:** Created <t:${Math.floor(createdTimestamp / 1000)}:R> • Joined ${joinedTimestamp ? `<t:${Math.floor(joinedTimestamp / 1000)}:R>` : '`Not in server`'}\n\n` +
        `**Risk Assessment:**\n` +
        `• **Rating:** **${riskLevel}**\n` +
        `• **Diagnostic:** *${riskReason}*\n` +
        `• **Bot Account:** \`${targetUser.bot ? 'Yes' : 'No'}\`\n\n` +
        `**Enforcement & History:**\n` +
        `• **Disciplinary Cases:** \`${cases}\` recorded cases\n` +
        `• **Active Warnings:** \`${warns}\` warnings\n\n` +
        `**Elevated Permissions:**\n` +
        `${dangerousPerms.length > 0 ? dangerousPerms.map(p => `• \`${p}\``).join('\n') : '*No elevated management permissions.*'}\n\n` +
        `-# Type \`${prefix}cases @${targetUser.username}\` to view detailed history.`,
      footer: { text: `Investigated by ${message.author.username}` }
    });

    if (targetUser.displayAvatarURL) {
      embed.setThumbnail(targetUser.displayAvatarURL());
    }

    return message.reply({ embeds: [embed] });
  }
};
