/**
 * Nuke Command (Node.js)
 * Re-creates the current channel with countdown animation and purges all previous messages.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { animateSequence, getNukeCountdownFrames } = require('../../utils/animation');
const { askConfirmation } = require('../../utils/confirmAction');
const { markAuthorizedDeletion, markBotDeletedEntity } = require('../../utils/antinukeEngine');

module.exports = {
  name: 'nuke',
  description: 'Clones the channel with countdown animation and purges all previous messages.',
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  category: ['moderation', 'channels'],
  usage: 'nuke',
  cooldown: 10,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Manage Channels` permission to nuke channels.'
          })
        ]
      });
    }

    // C10: Confused Deputy Limiter check
    const { checkModAction } = require('../../utils/modActionLimiter');
    const quota = await checkModAction(message.guild, message.author.id, 'channel');
    if (!quota.allowed) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> **Action Rate Limit Exceeded:** You have reached the safe action quota for channel modifications (${quota.limit} per window). Please wait **${quota.remainingTime}s** before nuking again.`);
    }

    const channel = message.channel;
    const pos = channel.position;

    // Two-step destructive action confirmation (15s TTL)
    const { confirmed } = await askConfirmation(message, {
      title: '💥  Confirm Channel Nuke',
      description: `Are you sure you want to completely recreate and purge **#${channel.name}**? All message history will be permanently deleted.`,
      confirmLabel: 'Yes, Nuke Channel'
    });
    if (!confirmed) return;

    try {
      const frames = getNukeCountdownFrames(channel.name);
      const statusMsg = await message.reply({ embeds: [frames[0]] });

      // Play 3-stage countdown animation (500ms per stage)
      await animateSequence(statusMsg, frames, { intervalMs: 500 });

      const cloned = await channel.clone({
        name: channel.name,
        parent: channel.parentId,
        position: pos,
        reason: `Channel nuked by ${message.author.tag} (${message.author.id})`
      });

      markAuthorizedDeletion(message.guild.id, channel.id);
      markBotDeletedEntity(channel.id);
      await channel.delete(`Channel nuked by ${message.author.tag}`);

      const embed = createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '💥 Channel Nuked and Refreshed',
        description:
          `> This channel was successfully nuked by ${message.author}.\n` +
          `> All chat history and spam was purged, while topic and permissions were preserved.`
      });

      embed.setImage('https://media.giphy.com/media/oe33xf3B50fsc/giphy.gif');

      await cloned.send({ embeds: [embed] });
    } catch (e) {
      return message.channel.send(`Failed to nuke channel: ${e.message}`);
    }
  }
};
