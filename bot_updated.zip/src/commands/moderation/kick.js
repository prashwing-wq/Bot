/**
 * Kick Command (Prefix & Slash)
 */
const { PermissionFlagsBits } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');

async function handleKick({ guild, member, author, targetId, reason, client }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  const { isAntinukeArmed } = require('../../utils/antinukeEngine');
  if (!isAntinukeArmed(guild.id)) {
    return { error: '<a:tungsten_warn:1567242784535085148> **Antinuke Is Disabled**\nModeration actions are locked because Antinuke is **disabled** on this server. To ban, kick, or moderate members, you must first enable Antinuke with `antinuke enable`.' };
  }

  if (!hasPerm(member, PermissionFlagsBits.KickMembers)) {
    return { error: '<a:tungsten_close:1567234632905138206> You need the **Kick Members** permission to execute this command.' };
  }

  if (!guild.members.me.permissions.has(PermissionFlagsBits.KickMembers)) {
    return { error: '<a:tungsten_close:1567234632905138206> I lack the **Kick Members** permission.' };
  }

  if (!targetId) {
    return { error: 'Invalid user target provided.' };
  }

  // C10: Confused Deputy Limiter check
  const { checkModAction } = require('../../utils/modActionLimiter');
  const quota = await checkModAction(guild, author.id, 'kick');
  if (!quota.allowed) {
    return { error: `<a:tungsten_warn:1567246685082746940> **Action Rate Limit Exceeded:** You have reached the safe action quota for kicks (${quota.limit} per window). Please wait **${quota.remainingTime}s** before kicking again.` };
  }

  const cleanTargetId = String(targetId).replace(/[<@!>]/g, '').trim();
  const cleanReason = reason || 'No reason specified by moderator';

  if (!/^\d{15,21}$/.test(cleanTargetId)) {
    return { error: '<a:tungsten_close:1567234632905138206> Please provide a valid user mention or numeric Snowflake ID.' };
  }
  if (cleanTargetId === author.id) {
    return { error: '<a:tungsten_close:1567234632905138206> You cannot kick yourself.' };
  }

  let targetMember;
  try {
    targetMember = await guild.members.fetch(cleanTargetId).catch(() => null);
  } catch (e) {}

  if (!targetMember) {
    return { error: '<a:tungsten_close:1567234632905138206> Could not find that member in this server.' };
  }

  if (isOwner(targetMember.id)) return { error: '<a:tungsten_close:1567234632905138206> You cannot kick a Bot Owner.' };
  if (targetMember.id === guild.ownerId) return { error: '<a:tungsten_close:1567234632905138206> You cannot kick the Server Owner.' };
  if (client?.user && targetMember.id === client.user.id) return { error: '<a:tungsten_close:1567234632905138206> I cannot kick myself.' };

  const memberHighestPos = typeof member.roles?.highest?.position === 'number'
    ? member.roles.highest.position
    : (Array.isArray(member.roles)
        ? Math.max(0, ...member.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);
  const targetHighestPos = typeof targetMember.roles?.highest?.position === 'number'
    ? targetMember.roles.highest.position
    : (Array.isArray(targetMember.roles)
        ? Math.max(0, ...targetMember.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);
  const botHighestPos = typeof guild.members?.me?.roles?.highest?.position === 'number'
    ? guild.members.me.roles.highest.position
    : (Array.isArray(guild.members?.me?.roles)
        ? Math.max(0, ...guild.members.me.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);

  if (!isOwner(author.id) && memberHighestPos <= targetHighestPos) {
    return { error: '<a:tungsten_close:1567234632905138206> You cannot kick this member because their highest role is equal to or higher than yours.' };
  }
  if (botHighestPos <= targetHighestPos) {
    return { error: '<a:tungsten_close:1567234632905138206> I cannot kick this member because their highest role is higher than or equal to mine.' };
  }

  try {
    try {
      const { markAuthorizedDeletion } = require('../../utils/antinukeEngine');
      markAuthorizedDeletion(guild.id, cleanTargetId);
    } catch (_) {}

    await targetMember.kick(`${cleanReason} | Moderator: ${author.username} (${author.id})`);

    const sdb = getServerDb(guild.id);
    await logAction(guild, sdb, {
      emoji: '<a:tungsten_shield:1567242104923627574>',
      action: 'kick',
      targetId: cleanTargetId,
      moderatorId: author.id,
      reason: cleanReason
    });

    return {
      success: true,
      embed: createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '<a:tungsten_shield:1567242104923627574> Member Kicked',
        description: `Successfully kicked <@${cleanTargetId}> (\`${cleanTargetId}\`).\n**Reason:** ${cleanReason}\n**Moderator:** ${author}`
      })
    };
  } catch (err) {
    return { error: `<a:tungsten_close:1567234632905138206> Failed to kick user: ${err.message}` };
  }
}

module.exports = {
  name: 'kick',
  aliases: ['k'],
  category: 'moderation',
  description: 'Kicks a member from the server with role hierarchy protection.',
  permissions: ['KickMembers'],
  botPermissions: ['KickMembers'],
  usage: '<@user|id> [reason]',
  cooldown: 3,

  slash: {
    name: 'kick',
    description: 'Kicks a member from the server with role hierarchy protection.',
    options: [
      {
        name: 'user',
        description: 'The user to kick (mention or ID)',
        type: 6, // USER
        required: true
      },
      {
        name: 'reason',
        description: 'Reason for the kick',
        type: 3, // STRING
        required: false
      }
    ]
  },

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const targetInput = args[0];
    if (!targetInput) {
      return message.reply(`Usage: \`${prefix}kick <@user|id> [reason]\``);
    }

    const reason = args.slice(1).join(' ');
    const res = await handleKick({
      guild: message.guild,
      member: message.member,
      author: message.author,
      targetId: targetInput,
      reason,
      client
    });

    if (res.error) return message.reply(res.error);
    return message.reply({ embeds: [res.embed] });
  },

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    const res = await handleKick({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetId: user.id,
      reason,
      client
    });

    if (res.error) return interaction.reply({ content: res.error, ephemeral: true });
    return interaction.reply({ embeds: [res.embed] });
  },

  handleKick
};
