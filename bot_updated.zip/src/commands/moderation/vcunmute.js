/**
 * Voice Channel Unmute Command (Node.js)
 * Server-unmutes a member or all members in a voice channel.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');

module.exports = {
  name: 'vcunmute',
  aliases: ['vunmute', 'voiceunmute'],
  category: 'moderation',
  description: 'Server-unmute a member or all members in a voice channel.',
  usage: '<@member|id|all> [reason]',
  cooldown: 3,
  permissions: ['MuteMembers'],
  botPermissions: ['MuteMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!args || args.length === 0) {
      return message.reply(`Usage: \`${prefix}vcunmute <@member|id|all> [reason]\``);
    }

    const sub = args[0].toLowerCase();

    // Mass unmute all members in current voice channel
    if (sub === 'all') {
      const voiceChannel = message.member?.voice?.channel;
      if (!voiceChannel) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to unmute all members.');
      }

      const members = voiceChannel.members
        ? Array.from(voiceChannel.members.values()).filter(m => m.id !== client.user?.id)
        : [];

      let count = 0;
      for (const m of members) {
        try {
          await m.voice.setMute(false, `[vcunmute all] Unmuted by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: '<a:tungsten_sound:1567242242127568958>',
          action: 'vcunmute_all',
          targetId: message.guild.id,
          moderatorId: message.author.id,
          reason: `Mass voice unmute in ${voiceChannel.name} (${count} members)`
        });
      } catch (_) {}

      return message.reply(`<a:tungsten_sound:1567242242127568958> Server-unmuted **${count} members** in ${voiceChannel}.`);
    }

    const cleanId = sub.replace(/[<@!>]/g, '');
    const targetMember = message.mentions?.members?.first()
      || message.guild.members?.cache?.get(cleanId)
      || (typeof message.guild.members?.fetch === 'function' ? await message.guild.members.fetch(cleanId).catch(() => null) : null);

    if (!targetMember) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve \`${args[0]}\` to a valid member.`);
    }

    if (!targetMember.voice?.channel) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is not connected to any voice channel.`);
    }

    if (!targetMember.voice.serverMute) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is not server-muted.`);
    }

    const reason = args.slice(1).join(' ') || `Unmuted by ${message.author.tag}`;
    try {
      await targetMember.voice.setMute(false, reason);

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: '<a:tungsten_sound:1567242242127568958>',
          action: 'vcunmute',
          targetId: targetMember.id,
          moderatorId: message.author.id,
          reason
        });
      } catch (_) {}

      const embed = createEmbed({
        color: 0x57F287,
        title: '<a:tungsten_sound:1567242242127568958> Member Voice Unmuted',
        description: `> Successfully server-unmuted <@${targetMember.id}> in **${targetMember.voice.channel.name}**.\n\n• **Reason:** ${reason}`
      });
      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to voice-unmute member: ${err.message}`);
    }
  }
};
