/**
 * Temprole Command (Node.js)
 * Temporarily assigns a role to a member with scheduled automatic removal.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits
} = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');
const { scheduleTask } = require('../../utils/scheduler');
const { parseLadderDuration, formatDuration } = require('../../utils/warnLadder');
const { EMOJIS } = require('../../utils/emojis');

async function handleTemprole({ guild, member, author, targetId, roleInput, durationStr, client }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  if (!hasPerm(member, PermissionFlagsBits.ManageRoles)) {
    return { error: '<a:tungsten_close:1567234632905138206> You need the **Manage Roles** permission to execute this command.' };
  }

  if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
    return { error: '<a:tungsten_close:1567234632905138206> I lack the **Manage Roles** permission.' };
  }

  if (!targetId || !roleInput || !durationStr) {
    return { error: '<a:tungsten_close:1567234632905138206> Missing required parameters. Usage: `temprole <@user|id> <@role|id> <duration>`' };
  }

  const durationSec = parseLadderDuration(durationStr);
  if (!durationSec || durationSec <= 0) {
    return { error: '<a:tungsten_close:1567234632905138206> Invalid duration specified. Use format like `10m`, `2h`, `7d`.' };
  }

  const cleanTargetId = targetId.replace(/[<@!>]/g, '');
  let targetMember;
  try {
    targetMember = await guild.members.fetch(cleanTargetId).catch(() => null);
  } catch (_) {}

  if (!targetMember) {
    return { error: '<a:tungsten_close:1567234632905138206> Could not find the specified member in this server.' };
  }

  const cleanRoleId = roleInput.replace(/[<@&>]/g, '');
  const role = guild.roles.cache.get(cleanRoleId) || guild.roles.cache.find(r => r.name.toLowerCase() === roleInput.toLowerCase());

  if (!role) {
    return { error: '<a:tungsten_close:1567234632905138206> Could not find the specified role.' };
  }

  if (role.managed) {
    return { error: '<a:tungsten_close:1567234632905138206> Cannot assign a bot-managed or integration role.' };
  }

  if (role.id === guild.roles.everyone.id) {
    return { error: '<a:tungsten_close:1567234632905138206> Cannot assign the `@everyone` role.' };
  }

  // Role hierarchy check
  if (
    member.roles?.highest &&
    role.position >= member.roles.highest.position &&
    author.id !== guild.ownerId
  ) {
    return { error: '<a:tungsten_close:1567234632905138206> You cannot assign a role equal to or higher than your highest role.' };
  }

  if (
    guild.members.me.roles?.highest &&
    role.position >= guild.members.me.roles.highest.position
  ) {
    return { error: '<a:tungsten_close:1567234632905138206> I cannot assign this role because it is higher than or equal to my highest role.' };
  }

  try {
    await targetMember.roles.add(role.id, `Temprole: ${formatDuration(durationSec)} by ${author.username}`);

    const runAt = Date.now() + durationSec * 1000;
    const taskId = scheduleTask(guild.id, 'temprole_end', runAt, {
      guildId: guild.id,
      userId: targetMember.id,
      roleId: role.id
    });

    const sdb = getServerDb(guild.id);
    await logAction(guild, sdb, {
      emoji: EMOJIS.PARTY,
      action: 'temprole',
      targetId: targetMember.id,
      moderatorId: author.id,
      reason: `Assigned role ${role.name} for ${formatDuration(durationSec)} [Task #${taskId}]`
    });

    return {
      success: true,
      taskId,
      embed: createEmbed({
        color: client.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: '🎭 Temporary Role Assigned',
        description:
          `Successfully assigned role <@&${role.id}> to <@${targetMember.id}>.\n` +
          `• **Duration:** \`${formatDuration(durationSec)}\` (Expires <t:${Math.floor(runAt / 1000)}:R>)\n` +
          `• **Moderator:** ${author}\n` +
          `• **Task ID:** \`#${taskId}\``
      })
    };
  } catch (err) {
    return { error: `<a:tungsten_close:1567234632905138206> Failed to assign role: ${err.message}` };
  }
}

module.exports = {
  name: 'temprole',
  category: 'moderation',
  description: 'Temporarily assign a role to a member with scheduled automatic removal.',
  usage: 'temprole <@user|id> <@role|id> <duration>',
  aliases: ['trole'],
  permissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],

  slash: new SlashCommandBuilder()
    .setName('temprole')
    .setDescription('Temporarily assign a role to a member with scheduled automatic removal.')
    .addUserOption(opt =>
      opt.setName('target')
        .setDescription('The member to give the role to')
        .setRequired(true)
    )
    .addRoleOption(opt =>
      opt.setName('role')
        .setDescription('The role to assign')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('duration')
        .setDescription('Duration (e.g., 10m, 2h, 7d)')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async executeSlash(interaction, client) {
    const target = interaction.options.getUser('target');
    const role = interaction.options.getRole('role');
    const duration = interaction.options.getString('duration');

    const res = await handleTemprole({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetId: target.id,
      roleInput: role.id,
      durationStr: duration,
      client
    });

    if (res.error) {
      return interaction.reply({ content: res.error, ephemeral: true });
    }
    return interaction.reply({ embeds: [res.embed] });
  },

  async execute(message, args, client, prefix) {
    if (args.length < 3) {
      return message.reply(`Usage: \`${prefix}temprole <@user|id> <@role|id> <duration>\`\nExample: \`${prefix}temprole @User @VIP 7d\``);
    }

    const target = args[0];
    const role = args[1];
    const duration = args[2];

    const res = await handleTemprole({
      guild: message.guild,
      member: message.member,
      author: message.author,
      targetId: target,
      roleInput: role,
      durationStr: duration,
      client
    });

    if (res.error) {
      return message.reply(res.error);
    }
    return message.reply({ embeds: [res.embed] });
  },

  handleTemprole
};
