/**
 * Steal Command (Node.js)
 * Steals custom emojis or stickers from another server, URL, or replied message into this server.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const https = require('node:https');
const http = require('node:http');

function fetchBuffer(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { headers: { 'User-Agent': 'TungstenBot/2.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchBuffer(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP status ${res.statusCode}`));
      }
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Request timed out'));
    });
  });
}

function parseCustomEmoji(input) {
  if (!input) return null;
  const match = input.match(/<(a)?:([a-zA-Z0-9_]{2,32}):(\d{17,20})>/);
  if (match) {
    const animated = Boolean(match[1]);
    const name = match[2];
    const id = match[3];
    const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}`;
    return { name, url, animated };
  }
  return null;
}

module.exports = {
  name: 'steal',
  aliases: ['emojisteal', 'stickersteal'],
  category: 'moderation',
  description: 'Steals custom emoji or sticker from URL or custom emoji argument into server.',
  usage: '<emoji | sticker URL | image URL> [name]',
  cooldown: 5,
  permissions: ['ManageGuildExpressions'],
  botPermissions: ['ManageGuildExpressions'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuildExpressions)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Emojis and Stickers` permission to steal expressions.'
          })
        ]
      });
    }

    let emojiInfo = null;
    let customName = args[1] ? args[1].replace(/[^a-zA-Z0-9_]/g, '') : null;
    let isSticker = false;

    // Check replied message for stickers or emojis
    if (message.reference && message.reference.messageId) {
      try {
        const replied = await message.channel.messages.fetch(message.reference.messageId);
        if (replied) {
          if (replied.stickers && replied.stickers.size > 0) {
            const sticker = replied.stickers.first();
            emojiInfo = {
              name: sticker.name.replace(/[^a-zA-Z0-9_]/g, ''),
              url: sticker.url,
              isSticker: true
            };
            isSticker = true;
          } else if (replied.content) {
            emojiInfo = parseCustomEmoji(replied.content);
          }
        }
      } catch (e) {}
    }

    // Check arguments
    if (!emojiInfo && args[0]) {
      const parsed = parseCustomEmoji(args[0]);
      if (parsed) {
        emojiInfo = parsed;
      } else if (args[0].startsWith('http://') || args[0].startsWith('https://')) {
        const url = args[0];
        const isStickerUrl = url.includes('/stickers/');
        const ext = url.split('.').pop()?.split('?')[0]?.toLowerCase();
        let name = customName || 'stolen_asset';
        emojiInfo = {
          name,
          url,
          animated: ext === 'gif',
          isSticker: isStickerUrl
        };
        isSticker = isStickerUrl;
      }
    }

    if (!emojiInfo) {
      return message.reply(
        `<a:tungsten_warn:1567246685082746940> **How to Steal Emojis & Stickers:**\n` +
        `• **Usage:** \`${prefix}steal <emoji | image URL> [name]\`\n` +
        `• **Stickers:** Reply to a sticker with \`${prefix}steal [name]\`\n` +
        `• **Example:** \`${prefix}steal <a:pepe:1567241769593339988> my_pepe\``
      );
    }

    const finalName = customName || emojiInfo.name || 'stolen';

    try {
      if (emojiInfo.isSticker) {
        if (!message.guild.stickers || typeof message.guild.stickers.create !== 'function') {
          return message.reply('<a:tungsten_close:1567234632905138206> Sticker creation is not supported or server limit reached.');
        }

        const buffer = await fetchBuffer(emojiInfo.url);
        const createdSticker = await message.guild.stickers.create({
          file: buffer,
          name: finalName,
          tags: 'stolen,tungsten'
        });

        const embed = createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: '✨ Sticker Added',
          description: `Successfully added sticker **${createdSticker.name}** to this server!`,
          image: createdSticker.url
        });
        return message.reply({ embeds: [embed] });
      }

      // Add as custom emoji
      const buffer = await fetchBuffer(emojiInfo.url);
      const created = await message.guild.emojis.create({
        attachment: buffer,
        name: finalName
      });

      const embed = createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '✨ Emoji Added',
        description: `Successfully added ${created} (\`:${created.name}:\`) to this server!\n**ID:** \`${created.id}\``,
        thumbnail: created.url
      });
      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to steal asset: ${err.message}`);
    }
  }
};
