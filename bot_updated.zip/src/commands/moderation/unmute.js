/**
 * Unmute / Remove Timeout Command (Prefix & Slash)
 */
const { PermissionFlagsBits } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');

async function handleUnmute({ guild, member, author, targetId, reason, client }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  if (!hasPerm(member, PermissionFlagsBits.ModerateMembers)) {
    return { error: '<a:tungsten_close:1567234632905138206> You need the **Timeout Members** permission to execute this command.' };
  }

  if (!targetId) {
    return { error: 'Invalid user target provided.' };
  }

  const cleanTargetId = targetId.replace(/[<@!>]/g, '');
  const cleanReason = reason || 'Unmuted by moderator';

  let targetMember;
  try {
    targetMember = await guild.members.fetch(cleanTargetId).catch(() => null);
  } catch (e) {}

  if (!targetMember) return { error: '<a:tungsten_close:1567234632905138206> Could not find that member in this server.' };

  try {
    await targetMember.timeout(null, `${cleanReason} | Moderator: ${author.username}`);

    const sdb = getServerDb(guild.id);
    await logAction(guild, sdb, {
      emoji: '<a:tungsten_sound:1567242242127568958>',
      action: 'unmute',
      targetId: targetMember.id,
      moderatorId: author.id,
      reason: cleanReason
    });

    return {
      success: true,
      embed: createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '<a:tungsten_sound:1567242242127568958> Member Unmuted',
        description: `Successfully removed timeout from ${targetMember}.\n**Reason:** ${cleanReason}\n**Moderator:** ${author}`
      })
    };
  } catch (err) {
    return { error: `<a:tungsten_close:1567234632905138206> Failed to unmute member: ${err.message}` };
  }
}

module.exports = {
  name: 'unmute',
  aliases: ['um', 'untimeout'],
  category: 'moderation',
  description: 'Removes the timeout / mute from a member.',
  permissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  usage: '<@user|id> [reason]',
  cooldown: 3,

  slash: {
    name: 'unmute',
    description: 'Removes the timeout / mute from a member.',
    options: [
      {
        name: 'user',
        description: 'The user to unmute (mention or ID)',
        type: 6, // USER
        required: true
      },
      {
        name: 'reason',
        description: 'Reason for unmuting',
        type: 3, // STRING
        required: false
      }
    ]
  },

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const targetInput = args[0];
    if (!targetInput) {
      return message.reply(`Usage: \`${prefix}unmute <@user|id> [reason]\``);
    }

    const reason = args.slice(1).join(' ');
    const res = await handleUnmute({
      guild: message.guild,
      member: message.member,
      author: message.author,
      targetId: targetInput,
      reason,
      client
    });

    if (res.error) return message.reply(res.error);
    return message.reply({ embeds: [res.embed] });
  },

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    const res = await handleUnmute({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetId: user.id,
      reason,
      client
    });

    if (res.error) return interaction.reply({ content: res.error, ephemeral: true });
    return interaction.reply({ embeds: [res.embed] });
  },

  handleUnmute
};
