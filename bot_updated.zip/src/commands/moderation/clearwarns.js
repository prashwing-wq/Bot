/**
 * Clear Warnings Command
 * Removes all warnings for a member from server.db
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'clearwarns',
  description: 'Clear all warnings for a server member.',
  permissions: ['Administrator'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'moderation',
  usage: 'clearwarns <@member|id>',
  aliases: ['resetwarns', 'cwarns'],
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Administrator` permission to clear member warnings.'
          })
        ]
      });
    }

    const targetUser = message.mentions?.members?.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : null);

    if (!targetUser) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Invalid Target',
            description: `**Usage:** \`${prefix}clearwarns <@member|id>\``
          })
        ]
      });
    }

    const sdb = getServerDb(message.guild.id);
    const result = sdb.prepare(`
      DELETE FROM member_warnings WHERE guild_id = ? AND user_id = ?
    `).run(message.guild.id, targetUser.id);

    const targetName = targetUser.user?.username || targetUser.displayName;
    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: 'Warnings Cleared',
          description: `Successfully wiped all infractions for **${targetName}**.\nCleared: \`${result.changes || 0}\` warning(s).`
        })
      ]
    });
  }
};
