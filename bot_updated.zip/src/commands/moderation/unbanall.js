const { PermissionFlagsBits } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { logAction } = require('../../utils/modlog');

module.exports = {
  name: 'unbanall',
  aliases: ['massunban'],
  category: 'moderation',
  description: 'Unbans all currently banned users in the server',
  usage: '',
  cooldown: 15,
  permissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.BanMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Ban Members** permission to run this command.');
    }

    const bans = await message.guild.bans.fetch().catch(() => null);
    if (!bans || bans.size === 0) {
      return message.reply('<a:tungsten_info:1567240890748248084> There are no banned users in this server.');
    }

    const total = bans.size;
    const statusMsg = await message.reply(`<a:tungsten_loading:1567241050567876698> Mass unbanning **${total}** users... Please wait.`);

    let unbannedCount = 0;
    for (const [userId, ban] of bans) {
      try {
        await message.guild.bans.remove(userId, `Mass unban executed by ${message.author.tag}`);
        unbannedCount++;
      } catch (err) {
        // continue
      }
      // Small throttle to avoid Discord rate limit spikes
      await new Promise(r => setTimeout(r, 250));
    }

    logAction(message.guild, {
      action: 'Mass Unban',
      moderator: message.author,
      reason: `Unbanned ${unbannedCount}/${total} users`
    }, client).catch(() => null);

    const embed = createEmbed({
      title: '<a:tungsten_success:1567242523468890274> Mass Unban Completed',
      description: `Successfully unbanned **${unbannedCount}** / **${total}** banned users.`,
      color: 0x57F287
    });

    return statusMsg.edit({ content: null, embeds: [embed] }).catch(() => null);
  }
};
