/**
 * Moderation Policy Engine (Slice 2.1)
 * Configure, preview diffs, export, and apply holistic moderation policy presets.
 */
const { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getSetting, setSetting } = require('../../settings/registry');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

const POLICY_KEYS = [
  'automod.invite.enabled',
  'automod.link.enabled',
  'automod.caps.enabled',
  'automod.mention.enabled',
  'automod.spam.enabled',
  'antiraid.enabled',
  'antiraid.join_limit',
  'antiraid.window_seconds',
  'antiraid.action',
  'antinuke.enabled',
  'antinuke.action',
  'logging.ghostping.enabled',
  'logging.snipe.enabled'
];

const PRESETS = {
  strict: {
    name: 'strict',
    label: 'Strict Security',
    description: 'Zero-tolerance moderation and threat defense for high-risk servers.',
    settings: {
      'automod.invite.enabled': true,
      'automod.link.enabled': true,
      'automod.caps.enabled': true,
      'automod.mention.enabled': true,
      'automod.spam.enabled': true,
      'antiraid.enabled': true,
      'antiraid.join_limit': 5,
      'antiraid.window_seconds': 10,
      'antiraid.action': 'ban',
      'antinuke.enabled': true,
      'antinuke.action': 'ban',
      'logging.ghostping.enabled': true,
      'logging.snipe.enabled': true
    }
  },
  community: {
    name: 'community',
    label: 'Community Standard',
    description: 'Balanced moderation profile suitable for active public discussion servers.',
    settings: {
      'automod.invite.enabled': true,
      'automod.link.enabled': false,
      'automod.caps.enabled': true,
      'automod.mention.enabled': true,
      'automod.spam.enabled': true,
      'antiraid.enabled': true,
      'antiraid.join_limit': 10,
      'antiraid.window_seconds': 10,
      'antiraid.action': 'kick',
      'antinuke.enabled': true,
      'antinuke.action': 'kick',
      'logging.ghostping.enabled': true,
      'logging.snipe.enabled': true
    }
  },
  gaming: {
    name: 'gaming',
    label: 'Gaming & Memes',
    description: 'Relaxed profile for gaming servers allowing media links, hype caps, and fast banter.',
    settings: {
      'automod.invite.enabled': true,
      'automod.link.enabled': false,
      'automod.caps.enabled': false,
      'automod.mention.enabled': true,
      'automod.spam.enabled': false,
      'antiraid.enabled': true,
      'antiraid.join_limit': 15,
      'antiraid.window_seconds': 10,
      'antiraid.action': 'timeout',
      'antinuke.enabled': false,
      'antinuke.action': 'kick',
      'logging.ghostping.enabled': true,
      'logging.snipe.enabled': true
    }
  }
};

function getGuildSnapshot(guildId) {
  const snapshot = {};
  for (const key of POLICY_KEYS) {
    snapshot[key] = getSetting(guildId, key);
  }
  return snapshot;
}

async function handlePolicy({ guild, member, author, subcommand, name, preset, client, prefix = '!' }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  if (!hasPerm(member, PermissionFlagsBits.Administrator) && !hasPerm(member, 'Administrator')) {
    return {
      error: '<a:tungsten_close:1567234632905138206> You need the **Administrator** permission to configure moderation policies.',
      embed: createEmbed({
        color: client?.config?.COLORS?.DANGER || 0xe74c3c,
        title: 'Permission Denied',
        description: 'You need the `Administrator` permission to manage server moderation policies.'
      })
    };
  }

  const sdb = getServerDb(guild.id);
  const sub = (subcommand || 'list').toLowerCase();

  // 1. CREATE
  if (sub === 'create') {
    if (!name) {
      return {
        error: `**Usage:** \`${prefix}policy create <name> [strict|community|gaming|current]\`\nExample: \`${prefix}policy create raiddown strict\``
      };
    }

    const cleanName = String(name).toLowerCase().trim();
    if (!/^[a-z0-9_-]{2,32}$/.test(cleanName)) {
      return {
        error: '<a:tungsten_close:1567234632905138206> Invalid policy name. Names must be 2-32 characters and contain only alphanumeric characters, underscores, or dashes.'
      };
    }

    let policySettings = {};
    let presetSource = 'snapshot';

    if (preset) {
      const pKey = String(preset).toLowerCase().trim();
      if (pKey === 'current' || pKey === 'snapshot') {
        policySettings = getGuildSnapshot(guild.id);
        presetSource = 'Active Server Snapshot';
      } else if (PRESETS[pKey]) {
        policySettings = { ...PRESETS[pKey].settings };
        presetSource = PRESETS[pKey].label;
      } else {
        return {
          error: `<a:tungsten_close:1567234632905138206> Unknown preset \`${preset}\`. Built-in presets: \`strict\`, \`community\`, \`gaming\`, or \`current\` (server snapshot).`
        };
      }
    } else {
      policySettings = getGuildSnapshot(guild.id);
      presetSource = 'Active Server Snapshot';
    }

    const configObj = {
      preset: presetSource,
      updated_by: author.id,
      settings: policySettings
    };
    const configJson = JSON.stringify(configObj);
    const now = Math.floor(Date.now() / 1000);

    sdb.prepare(`
      INSERT INTO moderation_policies (guild_id, name, config_json, created_by, created_at)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, name) DO UPDATE SET
        config_json = excluded.config_json,
        created_by = excluded.created_by,
        created_at = excluded.created_at
    `).run(guild.id, cleanName, configJson, author.id, now);

    return {
      success: true,
      embed: createEmbed({
        color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: `${EMOJIS.CLIPBOARD} Moderation Policy Created: ${cleanName}`,
        description: `Successfully configured policy profile **${cleanName}**.\n\n` +
          `• **Source:** ${presetSource}\n` +
          `• **Rules Pack:** \`${Object.keys(policySettings).length} rules configured\`\n` +
          `• **Created By:** <@${author.id}>\n\n` +
          `Use \`${prefix}policy apply ${cleanName}\` to arm or \`${prefix}policy diff ${cleanName}\` to inspect differences.`
      })
    };
  }

  // 2. APPLY
  if (sub === 'apply') {
    if (!name) {
      return {
        error: `**Usage:** \`${prefix}policy apply <name>\`\nExample: \`${prefix}policy apply strict\``
      };
    }

    const cleanName = String(name).toLowerCase().trim();
    let row = sdb.prepare('SELECT * FROM moderation_policies WHERE guild_id = ? AND name = ?').get(guild.id, cleanName);

    let policySettings = null;
    let label = cleanName;

    if (row) {
      try {
        const parsed = JSON.parse(row.config_json);
        policySettings = parsed.settings || {};
      } catch (_) {
        return { error: '<a:tungsten_close:1567234632905138206> Failed to parse stored policy configuration JSON.' };
      }
    } else if (PRESETS[cleanName]) {
      policySettings = { ...PRESETS[cleanName].settings };
      label = PRESETS[cleanName].label;
    } else {
      return {
        error: `<a:tungsten_close:1567234632905138206> Policy **${cleanName}** not found in this server.\nUse \`${prefix}policy list\` to see available policies.`
      };
    }

    let appliedCount = 0;
    const appliedDetails = [];

    for (const [k, v] of Object.entries(policySettings)) {
      try {
        setSetting(guild.id, k, v, author.id);
        appliedCount++;
        appliedDetails.push(`\`${k}\` ➔ \`${v}\``);
      } catch (err) {
        // Skip unmanaged setting keys
      }
    }

    try {
      await logAction(guild, sdb, {
        emoji: EMOJIS.CLIPBOARD,
        action: 'policy_apply',
        targetId: guild.id,
        moderatorId: author.id,
        reason: `Applied moderation policy: ${cleanName} (${appliedCount} settings updated)`
      });
    } catch (_) {}

    return {
      success: true,
      embed: createEmbed({
        color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: `<a:tungsten_success:1567242523468890274> Moderation Policy Applied: ${label}`,
        description: `Successfully applied moderation policy **${label}** across **${appliedCount}** configuration rules.\n\n` +
          `**Applied Matrix:**\n${appliedDetails.slice(0, 8).join('\n')}${appliedDetails.length > 8 ? `\n*...and ${appliedDetails.length - 8} more*` : ''}\n\n` +
          `> Executed by moderator <@${author.id}>.`
      })
    };
  }

  // 3. LIST
  if (sub === 'list') {
    const rows = sdb.prepare('SELECT * FROM moderation_policies WHERE guild_id = ? ORDER BY created_at DESC').all(guild.id);

    let desc = '### <a:tungsten_shield:1567242104923627574> Moderation Policy Profiles\n\n';

    desc += `**${EMOJIS.PACKAGE} Built-in Presets:**\n`;
    for (const [k, p] of Object.entries(PRESETS)) {
      desc += `• **\`${k}\`** (${p.label}): ${p.description}\n`;
    }

    desc += `\n**${EMOJIS.SAVE} Server Saved Policies:**\n`;
    if (!rows || rows.length === 0) {
      desc += '*No custom policies saved yet. Create one with `!policy create <name> [preset]`.*\n';
    } else {
      for (const r of rows) {
        let ruleCount = 0;
        let source = 'custom';
        try {
          const cfg = JSON.parse(r.config_json);
          ruleCount = Object.keys(cfg.settings || {}).length;
          source = cfg.preset || 'custom';
        } catch (_) {}
        desc += `• **\`${r.name}\`** — \`${ruleCount} rules\` (${source}) • By <@${r.created_by}> (<t:${r.created_at}:R>)\n`;
      }
    }

    desc += `\n*Quick apply:* \`${prefix}policy apply <name|preset>\`\n*Compare changes:* \`${prefix}policy diff <name|preset>\``;

    return {
      embed: createEmbed({
        color: client?.config?.COLORS?.PRIMARY || 0x000001,
        title: `Moderation Policies • ${guild.name}`,
        description: desc
      })
    };
  }

  // 4. EXPORT
  if (sub === 'export') {
    if (!name) {
      return { error: `**Usage:** \`${prefix}policy export <name>\`` };
    }

    const cleanName = String(name).toLowerCase().trim();
    let row = sdb.prepare('SELECT * FROM moderation_policies WHERE guild_id = ? AND name = ?').get(guild.id, cleanName);

    let exportObj = null;
    if (row) {
      try {
        exportObj = JSON.parse(row.config_json);
      } catch (_) {
        return { error: '<a:tungsten_close:1567234632905138206> Failed to parse stored policy configuration.' };
      }
    } else if (PRESETS[cleanName]) {
      exportObj = {
        name: cleanName,
        label: PRESETS[cleanName].label,
        settings: PRESETS[cleanName].settings
      };
    } else {
      return { error: `<a:tungsten_close:1567234632905138206> Policy **${cleanName}** not found.` };
    }

    const formatted = JSON.stringify(exportObj, null, 2);
    if (formatted.length <= 1800) {
      return {
        embed: createEmbed({
          color: client?.config?.COLORS?.INFO || 0x3498db,
          title: `${EMOJIS.INBOX} Export Policy: ${cleanName}`,
          description: `\`\`\`json\n${formatted}\n\`\`\``
        })
      };
    } else {
      const file = new AttachmentBuilder(Buffer.from(formatted, 'utf-8'), { name: `policy-${cleanName}.json` });
      return {
        embed: createEmbed({
          color: client?.config?.COLORS?.INFO || 0x3498db,
          title: `${EMOJIS.INBOX} Export Policy: ${cleanName}`,
          description: `Policy configuration exported to attachment \`policy-${cleanName}.json\`.`
        }),
        files: [file]
      };
    }
  }

  // 5. DELETE
  if (sub === 'delete') {
    if (!name) {
      return { error: `**Usage:** \`${prefix}policy delete <name>\`` };
    }

    const cleanName = String(name).toLowerCase().trim();
    const existing = sdb.prepare('SELECT 1 FROM moderation_policies WHERE guild_id = ? AND name = ?').get(guild.id, cleanName);

    if (!existing) {
      return { error: `<a:tungsten_close:1567234632905138206> Saved policy **${cleanName}** does not exist in this server.` };
    }

    sdb.prepare('DELETE FROM moderation_policies WHERE guild_id = ? AND name = ?').run(guild.id, cleanName);

    return {
      success: true,
      embed: createEmbed({
        color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: '<a:tungsten_trash:1567242891276062872> Moderation Policy Deleted',
        description: `Successfully removed saved policy **${cleanName}** from this server.`
      })
    };
  }

  // 6. DIFF
  if (sub === 'diff') {
    if (!name) {
      return { error: `**Usage:** \`${prefix}policy diff <name>\`` };
    }

    const cleanName = String(name).toLowerCase().trim();
    let row = sdb.prepare('SELECT * FROM moderation_policies WHERE guild_id = ? AND name = ?').get(guild.id, cleanName);

    let policySettings = null;
    let label = cleanName;

    if (row) {
      try {
        const parsed = JSON.parse(row.config_json);
        policySettings = parsed.settings || {};
      } catch (_) {
        return { error: '<a:tungsten_close:1567234632905138206> Failed to parse stored policy configuration.' };
      }
    } else if (PRESETS[cleanName]) {
      policySettings = { ...PRESETS[cleanName].settings };
      label = PRESETS[cleanName].label;
    } else {
      return { error: `<a:tungsten_close:1567234632905138206> Policy **${cleanName}** not found.` };
    }

    const diffLines = [];
    let changed = 0;
    let identical = 0;

    for (const [key, targetVal] of Object.entries(policySettings)) {
      const currentVal = getSetting(guild.id, key);
      const isDiff = String(currentVal) !== String(targetVal);
      if (isDiff) {
        changed++;
        diffLines.push(`! ${key}: current [${currentVal}] ➔ policy [${targetVal}]`);
      } else {
        identical++;
        diffLines.push(`  ${key}: [${currentVal}]`);
      }
    }

    const diffOutput = diffLines.slice(0, 15).join('\n') + (diffLines.length > 15 ? `\n... (+${diffLines.length - 15} more)` : '');

    return {
      embed: createEmbed({
        color: changed > 0 ? (client?.config?.COLORS?.WARNING || 0xf1c40f) : (client?.config?.COLORS?.SUCCESS || 0x2ecc71),
        title: `${EMOJIS.SEARCH} Policy Diff: ${label}`,
        description: `Comparing policy **${label}** against active server configuration:\n\n` +
          `• **Modifications Needed:** \`${changed} rules\`\n` +
          `• **Already In-Sync:** \`${identical} rules\`\n\n` +
          `\`\`\`diff\n${diffOutput}\n\`\`\`\n` +
          (changed > 0 ? `Apply these changes with \`${prefix}policy apply ${cleanName}\`.` : `${EMOJIS.PARTY} Active server configuration already matches this policy perfectly!`)
      })
    };
  }

  return {
    error: `Unknown subcommand. Available: \`create\`, \`apply\`, \`list\`, \`export\`, \`delete\`, \`diff\`.`
  };
}

module.exports = {
  name: 'policy',
  category: 'moderation',
  description: 'Manage and apply automated moderation policy profiles and presets.',
  usage: '<create|apply|list|export|delete|diff> [name] [preset]',
  cooldown: 3,
  permissions: ['Administrator'],
  botPermissions: ['ManageGuild', 'EmbedLinks'],
  aliases: ['policies', 'modpolicy', 'modpolicies'],

  slash: new SlashCommandBuilder()
    .setName('policy')
    .setDescription('Manage and apply automated moderation policy presets')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('create')
        .setDescription('Create a moderation policy from a preset or current settings')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Name of the policy (alphanumeric, dashes, underscores)')
            .setRequired(true)
        )
        .addStringOption(opt =>
          opt.setName('preset')
            .setDescription('Base preset')
            .setRequired(false)
            .addChoices(
              { name: 'Strict (High Security)', value: 'strict' },
              { name: 'Community (Balanced)', value: 'community' },
              { name: 'Gaming (Relaxed)', value: 'gaming' },
              { name: 'Current (Server Snapshot)', value: 'current' }
            )
        )
    )
    .addSubcommand(sub =>
      sub.setName('apply')
        .setDescription('Apply a moderation policy or preset to the server')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Policy name or preset to apply')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all saved moderation policies and presets')
    )
    .addSubcommand(sub =>
      sub.setName('diff')
        .setDescription('Compare a policy against current server settings')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Policy name to compare')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('export')
        .setDescription('Export a moderation policy as JSON')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Policy name to export')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('delete')
        .setDescription('Delete a saved moderation policy')
        .addStringOption(opt =>
          opt.setName('name')
            .setDescription('Policy name to delete')
            .setRequired(true)
        )
    ),

  async execute(message, args, client, prefix) {
    const sub = (args[0] || 'list').toLowerCase();
    const name = args[1];
    const preset = args[2];

    const res = await handlePolicy({
      guild: message.guild,
      member: message.member,
      author: message.author,
      subcommand: sub,
      name,
      preset,
      client,
      prefix
    });

    if (res.error) {
      if (res.embed) return message.reply({ embeds: [res.embed] });
      return message.reply(res.error);
    }
    const replyOpts = { embeds: [res.embed] };
    if (res.files) replyOpts.files = res.files;
    return message.reply(replyOpts);
  },

  async executeSlash(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const name = interaction.options.getString('name');
    const preset = interaction.options.getString('preset');

    const res = await handlePolicy({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      subcommand: sub,
      name,
      preset,
      client,
      prefix: '/'
    });

    if (res.error) {
      if (res.embed) return interaction.reply({ embeds: [res.embed], ephemeral: true });
      return interaction.reply({ content: res.error, ephemeral: true });
    }
    const replyOpts = { embeds: [res.embed] };
    if (res.files) replyOpts.files = res.files;
    return interaction.reply(replyOpts);
  },

  handlePolicy,
  PRESETS,
  POLICY_KEYS
};
