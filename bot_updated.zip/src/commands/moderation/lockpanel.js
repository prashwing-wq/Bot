const { PermissionFlagsBits } = require('discord.js');
const { getPanelEmbed, buildCategorySelect, buildCategoryButtons } = require('./modpanel');
const { hasPerm } = require('../../utils/tools');

module.exports = {
  name: 'lockpanel',
  aliases: ['channelpanel'],
  category: 'moderation',
  description: 'Opens dedicated Channel Lockdown & Visibility control GUI panel',
  usage: '',
  cooldown: 3,
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to access the Lock Panel.');
    }
    const embed = getPanelEmbed('channel', message.guild, message.author, client, prefix);
    const selectMenu = buildCategorySelect('channel', message.author.id);
    const buttons = buildCategoryButtons('channel', message.author.id);
    return message.reply({ embeds: [embed], components: [selectMenu, ...buttons] });
  }
};
