/**
 * Unban Command
 */
const { PermissionFlagsBits } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');

module.exports = {
  name: 'unban',
  aliases: ['ub'],
  category: 'moderation',
  description: 'Unbans a user from the server by their ID.',
  permissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  usage: '<user_id> [reason]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionFlagsBits.BanMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Ban Members** permission to execute this command.');
    }

    const userId = args[0]?.replace(/[<@!>]/g, '');
    if (!userId || !/^\d{17,20}$/.test(userId)) {
      return message.reply(`Usage: \`${prefix}unban <user_id> [reason]\``);
    }

    const reason = args.slice(1).join(' ') || 'Unbanned by moderator';

    try {
      const ban = await message.guild.bans.fetch(userId).catch(() => null);
      if (!ban) {
        return message.reply('<a:tungsten_close:1567234632905138206> That user is not banned in this server.');
      }

      await message.guild.bans.remove(userId, `${reason} | Moderator: ${message.author.username}`);

      const sdb = getServerDb(message.guild.id);
      await logAction(message.guild, sdb, {
        emoji: '<a:tungsten_unlock:1567246515209117968>',
        action: 'unban',
        targetId: userId,
        moderatorId: message.author.id,
        reason
      });

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_unlock:1567246515209117968> User Unbanned',
            description: `Successfully unbanned **${ban.user.username}** (\`${userId}\`).\n**Reason:** ${reason}\n**Moderator:** ${message.author}`
          })
        ]
      });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to unban user: ${err.message}`);
    }
  }
};
