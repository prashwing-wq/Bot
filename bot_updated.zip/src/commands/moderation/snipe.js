/**
 * Snipe Deleted Message Command (Node.js)
 * Recovers and inspects the most recently deleted message in the channel.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  permissions: ['ManageMessages'],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'snipe',
  category: 'moderation',
  description: 'Recovers and displays the last deleted message in the current channel.',
  usage: '',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const sdb = getServerDb(message.guild.id);
    const row = sdb.prepare(`
      SELECT content, author_tag, author_id, timestamp, attachments
      FROM sniped_messages
      WHERE channel_id = ?
    `).get(message.channel.id);

    const SNIPE_TTL_SECONDS = 3600; // 1 hour
    const nowSec = Math.floor(Date.now() / 1000);

    if (!row || (nowSec - row.timestamp) > SNIPE_TTL_SECONDS) {
      return message.reply('🔍 There are no recently deleted messages recorded in this channel (within the last hour).');
    }

    const embed = createEmbed({
      title: '🎯  Sniped Message',
      description:
        `> **Author:** ${row.author_tag} (<@${row.author_id}>)\n` +
        `> **Deleted:** <t:${row.timestamp}:R>\n\n` +
        `**Content:**\n${row.content}`,
      footer: { text: `Sniped by ${message.author.username}` }
    });

    if (row.attachments) {
      embed.addFields({ name: 'Attachments', value: row.attachments });
    }

    return message.reply({ embeds: [embed] });
  }
};
