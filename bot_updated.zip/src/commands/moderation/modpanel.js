/**
 * Tungsten Unified Moderation Dashboard & Control Panel (Node.js)
 * Ported directly from Python cogs/moderation/mod_panel.py (ModDashboardView).
 * Provides an interactive visual control center with category switching, quick action buttons,
 * and seamless channel/member moderation.
 */
const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField
} = require('discord.js');
const { createEmbed, isOwner, hasPerm } = require('../../utils/tools');

const CATEGORIES = [
  { id: 'overview', label: 'Overview', emoji: '<a:tungsten_shield:1567242104923627574>', desc: 'Moderation control dashboard overview' },
  { id: 'ban', label: 'Ban & Unban', emoji: '<a:tungsten_shield:1567242104923627574>', desc: 'Member picker & hierarchy-safe bans' },
  { id: 'kick', label: 'Kick', emoji: '<a:tungsten_error:1567238753284653106>', desc: 'Safe kicks with optional DM notices' },
  { id: 'timeout', label: 'Timeout / Mute', emoji: '<a:tungsten_warn:1567246685082746940>', desc: 'Instant duration presets & unmute' },
  { id: 'warn', label: 'Warnings', emoji: '<a:tungsten_warn:1567246685082746940>', desc: 'Multi-guild warning tracking and 1-click resets' },
  { id: 'purge', label: 'Purge Messages', emoji: '<a:tungsten_sweep:1567242656281657414>', desc: 'Instant bulk cleaner with quick count presets' },
  { id: 'channel', label: 'Channel Lockdown', emoji: '<a:tungsten_unlock:1567246515209117968>', desc: 'Lock, unlock, hide, and unhide channels' },
  { id: 'roles', label: 'Roles & Nick', emoji: '<a:tungsten_shield:1567242104923627574>', desc: 'Role management and nickname editor' }
];

function buildCategorySelect(currentCategory = 'overview', authorId) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`modpanel:select:${authorId}`)
    .setPlaceholder('Select a moderation module...');

  for (const cat of CATEGORIES) {
    menu.addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel(cat.label)
        .setValue(cat.id)
        .setDescription(cat.desc)
        .setEmoji(cat.emoji)
        .setDefault(cat.id === currentCategory)
    );
  }

  return new ActionRowBuilder().addComponents(menu);
}

function buildCategoryButtons(category = 'overview', authorId) {
  const rows = [];

  if (category === 'overview') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:ban:${authorId}`)
        .setLabel('Ban Suite')
        .setEmoji('<a:tungsten_shield:1567242104923627574>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:timeout:${authorId}`)
        .setLabel('Timeout Suite')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:purge:${authorId}`)
        .setLabel('Purge Suite')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:channel:${authorId}`)
        .setLabel('Channel Lock')
        .setEmoji('<a:tungsten_unlock:1567246515209117968>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row);
  } else if (category === 'ban') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:ban:help:${authorId}`)
        .setLabel('Ban Syntax')
        .setEmoji('<a:tungsten_shield:1567242104923627574>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:ban:unbanhelp:${authorId}`)
        .setLabel('Unban Syntax')
        .setEmoji('<a:tungsten_unlock:1567246515209117968>')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:${authorId}`)
        .setLabel('Back to Overview')
        .setEmoji('<a:tungsten_arrow_right:1567233126143361135>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row);
  } else if (category === 'kick') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:kick:help:${authorId}`)
        .setLabel('Kick Syntax')
        .setEmoji('<a:tungsten_error:1567238753284653106>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:${authorId}`)
        .setLabel('Back to Overview')
        .setEmoji('<a:tungsten_arrow_right:1567233126143361135>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row);
  } else if (category === 'timeout') {
    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:timeout:5m:${authorId}`)
        .setLabel('5 Minutes')
        .setEmoji('<a:tungsten_warn:1567246685082746940>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:timeout:10m:${authorId}`)
        .setLabel('10 Minutes')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:timeout:1h:${authorId}`)
        .setLabel('1 Hour')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:timeout:1d:${authorId}`)
        .setLabel('1 Day')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:timeout:1w:${authorId}`)
        .setLabel('1 Week')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Danger)
    );
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:timeout:unmute:${authorId}`)
        .setLabel('Remove Timeout')
        .setEmoji('<a:tungsten_sound:1567242242127568958>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:${authorId}`)
        .setLabel('Back to Overview')
        .setEmoji('<a:tungsten_arrow_right:1567233126143361135>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row1, row2);
  } else if (category === 'warn') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:warn:warnhelp:${authorId}`)
        .setLabel('Issue Warning')
        .setEmoji('<a:tungsten_warn:1567246685082746940>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:warn:checkhelp:${authorId}`)
        .setLabel('Check Warnings')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:warn:clearhelp:${authorId}`)
        .setLabel('Clear Warnings')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:${authorId}`)
        .setLabel('Back to Overview')
        .setEmoji('<a:tungsten_arrow_right:1567233126143361135>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row);
  } else if (category === 'purge') {
    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:purge:10:${authorId}`)
        .setLabel('Purge 10')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:purge:25:${authorId}`)
        .setLabel('Purge 25')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:purge:50:${authorId}`)
        .setLabel('Purge 50')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:purge:100:${authorId}`)
        .setLabel('Purge 100')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Danger)
    );
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:purge:bots:${authorId}`)
        .setLabel('Purge Bots')
        .setEmoji('<a:tungsten_refresh:1567241907116187658>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:${authorId}`)
        .setLabel('Back to Overview')
        .setEmoji('<a:tungsten_arrow_right:1567233126143361135>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row1, row2);
  } else if (category === 'channel') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:channel:lock:${authorId}`)
        .setLabel('Lock Channel')
        .setEmoji('<a:tungsten_unlock:1567246515209117968>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:channel:unlock:${authorId}`)
        .setLabel('Unlock Channel')
        .setEmoji('<a:tungsten_unlock:1567246515209117968>')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:channel:hide:${authorId}`)
        .setLabel('Hide Channel')
        .setEmoji('<a:tungsten_eye:1567238862042833088>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:channel:unhide:${authorId}`)
        .setLabel('Unhide Channel')
        .setEmoji('<a:tungsten_eye:1567238862042833088>')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row);
  } else if (category === 'roles') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:roles:addhelp:${authorId}`)
        .setLabel('Add Role')
        .setEmoji('<a:tungsten_plus:1567241846453833840>')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:roles:removehelp:${authorId}`)
        .setLabel('Remove Role')
        .setEmoji('<a:tungsten_minus:1567241276057849856>')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:roles:nickhelp:${authorId}`)
        .setLabel('Edit Nick')
        .setEmoji('<a:tungsten_shield:1567242104923627574>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:overview:${authorId}`)
        .setLabel('Back to Overview')
        .setEmoji('<a:tungsten_arrow_right:1567233126143361135>')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`modpanel:btn:close:${authorId}`)
        .setLabel('Close')
        .setEmoji('<a:tungsten_sweep:1567242656281657414>')
        .setStyle(ButtonStyle.Secondary)
    );
    rows.push(row);
  }

  return rows;
}

function getPanelEmbed(category = 'overview', guild, author, client, prefix = '!') {
  const guildName = guild ? guild.name : 'Tungsten Guild';
  const totalMembers = guild ? guild.memberCount : 0;
  const ping = client && client.ws ? Math.round(client.ws.ping) : 0;

  if (category === 'overview') {
    return createEmbed({
      color: 0x2b2d31,
      title: `<a:tungsten_shield:1567242104923627574> Tungsten Moderation Control Panel • ${guildName}`,
      description:
        `Welcome to the **Interactive Moderation Dashboard**.\n` +
        `Select any moderation module from the dropdown menu below or click the shortcut buttons.\n\n` +
        `**Available Modules:**\n` +
        `• 🔨 \`Ban & Unban\`: Hierarchy-safe member banning and unbanning\n` +
        `• 👢 \`Kick\`: Visual kicks with optional DM alert notices\n` +
        `• <a:tungsten_loading:1567241050567876698> \`Timeout\`: 1-click duration presets (\`5m\`, \`10m\`, \`1h\`, \`1d\`, \`1w\`) and unmute\n` +
        `• <a:tungsten_warn:1567246685082746940> \`Warn\`: Comprehensive warning tracking and 1-click resets\n` +
        `• 🧹 \`Purge\`: Instant bulk message cleaner (\`10\`, \`25\`, \`50\`, \`100\` messages or bots)\n` +
        `• <a:tungsten_lock:1567241079030550668> \`Channel\`: Instant channel lock, unlock, hide, and unhide\n` +
        `• 🎭 \`Roles & Nick\`: Member role assignments and nickname editor\n\n` +
        `**Quick Direct Commands:**\n` +
        `• \`${prefix}banpanel\` • \`${prefix}kickpanel\` • \`${prefix}mutepanel\` • \`${prefix}warnpanel\` • \`${prefix}purgepanel\` • \`${prefix}lockpanel\``,
      fields: [
        { name: '👥 Total Members', value: `\`${totalMembers}\``, inline: true },
        { name: '<a:tungsten_shield:1567242104923627574> Operator', value: `<@${author.id}>`, inline: true },
        { name: '⚡ Gateway Latency', value: `\`${ping}ms\``, inline: true }
      ],
      footer: { text: 'Tungsten Moderation Engine • Select a module below to get started' }
    });
  } else if (category === 'ban') {
    return createEmbed({
      color: 0x2b2d31,
      title: `🔨 Ban & Unban Management Suite • ${guildName}`,
      description:
        `Execute hierarchy-safe bans and unbans with automatic audit logging.\n\n` +
        `**Commands & Usage:**\n` +
        `• \`${prefix}ban @user [reason]\` — Permanently bans a member from the server\n` +
        `• \`${prefix}unban <user_id> [reason]\` — Revokes a ban using User ID\n` +
        `• \`${prefix}softban @user [reason]\` — Bans and immediately unbans to wipe 7-day messages\n\n` +
        `*All disciplinary actions require \`Ban Members\` permission and respect Discord role hierarchy.*`,
      footer: { text: `Requested by ${author.username}` }
    });
  } else if (category === 'kick') {
    return createEmbed({
      color: 0x2b2d31,
      title: `👢 Kick Management Suite • ${guildName}`,
      description:
        `Safely kick members with optional DM alert notices.\n\n` +
        `**Commands & Usage:**\n` +
        `• \`${prefix}kick @user [reason]\` — Kicks a member from the server\n\n` +
        `*Members kicked can rejoin if an active server invite is available.*`,
      footer: { text: `Requested by ${author.username}` }
    });
  } else if (category === 'timeout') {
    return createEmbed({
      color: 0x2b2d31,
      title: `<a:tungsten_loading:1567241050567876698> Timeout & Mute Management Suite • ${guildName}`,
      description:
        `Isolate problematic members with Discord-native communication timeouts.\n\n` +
        `**Quick 1-Click Duration Presets:**\n` +
        `• Click any preset button below to timeout the targeted member.\n\n` +
        `**Manual Commands & Usage:**\n` +
        `• \`${prefix}mute @user [duration] [reason]\` — Timeout member (e.g. \`5m\`, \`10m\`, \`1h\`, \`1d\`, \`1w\`)\n` +
        `• \`${prefix}unmute @user\` — Immediately lift communication timeout`,
      footer: { text: `Requested by ${author.username}` }
    });
  } else if (category === 'warn') {
    return createEmbed({
      color: 0x2b2d31,
      title: `<a:tungsten_warn:1567246685082746940> Warning Management Suite • ${guildName}`,
      description:
        `Track member disciplinary infractions with automated warning logs.\n\n` +
        `**Commands & Usage:**\n` +
        `• \`${prefix}warn @user [reason]\` — Issues an official server infraction warning\n` +
        `• \`${prefix}warnings @user\` — Inspects all warnings issued to a member\n` +
        `• \`${prefix}clearwarns @user\` — Clears all infraction warnings from a member's record`,
      footer: { text: `Requested by ${author.username}` }
    });
  } else if (category === 'purge') {
    return createEmbed({
      color: 0x2b2d31,
      title: `🧹 Bulk Message Purge Suite • ${guildName}`,
      description:
        `Quickly clean up spam or raid messages in the current channel.\n\n` +
        `**1-Click Quick Purge Buttons:**\n` +
        `Click \`Purge 10\`, \`Purge 25\`, \`Purge 50\`, \`Purge 100\`, or \`Purge Bots\` below.\n\n` +
        `**Command Usage:**\n` +
        `• \`${prefix}purge <count>\` — Purge between 1 and 100 messages\n` +
        `• \`${prefix}cleanup [bots|embeds|files] <count>\` — Targeted cleanup`,
      footer: { text: `Requested by ${author.username}` }
    });
  } else if (category === 'channel') {
    return createEmbed({
      color: 0x2b2d31,
      title: `<a:tungsten_lock:1567241079030550668> Channel Lockdown & Visibility Suite • ${guildName}`,
      description:
        `Secure text channels during raids or announcements.\n\n` +
        `**1-Click Quick Buttons:**\n` +
        `Click \`Lock Channel\`, \`Unlock Channel\`, \`Hide Channel\`, or \`Unhide Channel\` below.\n\n` +
        `**Command Usage:**\n` +
        `• \`${prefix}lock [#channel]\` — Prevents @everyone from sending messages\n` +
        `• \`${prefix}unlock [#channel]\` — Restores message permissions for @everyone\n` +
        `• \`${prefix}slowmode <seconds>\` — Sets channel message cooldown`,
      footer: { text: `Requested by ${author.username}` }
    });
  } else if (category === 'roles') {
    return createEmbed({
      color: 0x2b2d31,
      title: `🎭 Member Roles & Nickname Suite • ${guildName}`,
      description:
        `Manage roles and member identities.\n\n` +
        `**Commands & Usage:**\n` +
        `• \`${prefix}giverole @user @role\` — Assign a role to a member\n` +
        `• \`${prefix}removerole @user @role\` — Remove a role from a member\n` +
        `• \`${prefix}modrolepanel\` — Open dedicated visual role assigner`,
      footer: { text: `Requested by ${author.username}` }
    });
  }

  return createEmbed({ title: 'Moderation Control Panel' });
}

module.exports = {
  name: 'modpanel',
  aliases: ['moderationpanel', 'mpanel', 'moddashboard', 'modgui'],
  category: 'moderation',
  description: 'Opens the interactive all-in-one moderation control panel GUI with dropdowns and quick actions.',
  permissions: ['ManageMessages'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[ban|kick|timeout|mute|warn|purge|channel|roles]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    const member = message.member;
    const isAuthorized = hasPerm(member, PermissionsBitField.Flags.ManageMessages) ||
                         hasPerm(member, PermissionsBitField.Flags.ModerateMembers) ||
                         hasPerm(member, PermissionsBitField.Flags.BanMembers) ||
                         hasPerm(member, PermissionsBitField.Flags.KickMembers);

    if (!isAuthorized) {
      return message.reply('<a:tungsten_close:1567234632905138206> You lack sufficient moderation permissions to access the Tungsten Moderation Dashboard.');
    }

    // Resolve initial page from argument
    const arg = args[0]?.toLowerCase();
    let initialCategory = 'overview';
    if (arg === 'ban' || arg === 'unban') initialCategory = 'ban';
    else if (arg === 'kick') initialCategory = 'kick';
    else if (arg === 'timeout' || arg === 'mute') initialCategory = 'timeout';
    else if (arg === 'warn' || arg === 'warnings') initialCategory = 'warn';
    else if (arg === 'purge' || arg === 'clear') initialCategory = 'purge';
    else if (arg === 'channel' || arg === 'lock') initialCategory = 'channel';
    else if (arg === 'roles' || arg === 'role' || arg === 'nick') initialCategory = 'roles';

    const embed = getPanelEmbed(initialCategory, message.guild, message.author, client, prefix);
    const selectMenu = buildCategorySelect(initialCategory, message.author.id);
    const buttons = buildCategoryButtons(initialCategory, message.author.id);

    return message.reply({
      embeds: [embed],
      components: [selectMenu, ...buttons]
    });
  },

  getPanelEmbed,
  buildCategorySelect,
  buildCategoryButtons,
  CATEGORIES
};
