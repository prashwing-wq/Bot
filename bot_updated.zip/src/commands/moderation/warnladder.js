/**
 * Tungsten Warning Escalation Ladder Command (Node.js)
 * Configure automated punishments based on cumulative warning counts.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const {
  parseLadderDuration,
  formatDuration,
  getLadderRules,
  setLadderRule,
  removeLadderRule,
  resetLadder
} = require('../../utils/warnLadder');
const { setModuleStatus, isModuleEnabled } = require('../../utils/modulesHelper');

const VALID_ACTIONS = ['timeout', 'mute', 'kick', 'ban', 'softban'];

module.exports = {
  name: 'warnladder',
  description: 'Configure automated punishment ladder for cumulative member warnings.',
  permissions: ['ManageGuild'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'moderation',
  usage: 'warnladder <set|remove|list|reset|enable|disable> [options]',
  aliases: ['ladder', 'warn-ladder'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('<a:tungsten_close:1567234632905138206> This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageGuild) && !hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Server` or `Administrator` permission to configure the warning ladder.'
          })
        ]
      });
    }

    const sub = (args[0] || 'list').toLowerCase();

    // 1. SET
    if (sub === 'set') {
      const warnCount = parseInt(args[1], 10);
      const action = (args[2] || '').toLowerCase();
      const rawDuration = args[3];

      if (isNaN(warnCount) || warnCount < 1) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.WARNING,
              title: '<a:tungsten_warn:1567246685082746940> Invalid Warning Count',
              description: `**Usage:** \`${prefix}warnladder set <warn_count> <action> [duration]\`\nExample: \`${prefix}warnladder set 3 timeout 1h\``
            })
          ]
        });
      }

      if (!VALID_ACTIONS.includes(action)) {
        return message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.WARNING,
              title: '<a:tungsten_warn:1567246685082746940> Invalid Action',
              description: `Action must be one of: \`${VALID_ACTIONS.join(', ')}\``
            })
          ]
        });
      }

      let durationSec = 0;
      if (action === 'timeout' || action === 'mute') {
        durationSec = rawDuration ? parseLadderDuration(rawDuration) : 600; // default 10m
        if (durationSec <= 0) durationSec = 600;
        if (durationSec > 2419200) durationSec = 2419200; // Discord 28-day timeout limit
      }

      setLadderRule(message.guild.id, warnCount, action, durationSec);

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_cmd_warnpanel:1567238091708702792> Warning Ladder Step Configured',
            description: `Members reaching **${warnCount} warnings** will automatically receive: **${action.toUpperCase()}**${durationSec > 0 ? ` for \`${formatDuration(durationSec)}\`` : ''}.`
          })
        ]
      });
    }

    // 2. REMOVE
    if (sub === 'remove' || sub === 'delete') {
      const warnCount = parseInt(args[1], 10);
      if (isNaN(warnCount)) {
        return message.reply(`<a:tungsten_warn:1567246685082746940> **Usage:** \`${prefix}warnladder remove <warn_count>\``);
      }

      const ok = removeLadderRule(message.guild.id, warnCount);
      if (!ok) {
        return message.reply(`<a:tungsten_info:1567240890748248084> No escalation rule configured for **${warnCount} warnings**.`);
      }

      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_success:1567242523468890274> Ladder Step Removed',
            description: `Successfully removed escalation rule for **${warnCount} warnings**.`
          })
        ]
      });
    }

    // 3. RESET
    if (sub === 'reset' || sub === 'clear') {
      resetLadder(message.guild.id);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_success:1567242523468890274> Warning Ladder Reset',
            description: 'All automated escalation rules have been cleared.'
          })
        ]
      });
    }

    // 4. ENABLE / DISABLE
    if (sub === 'enable' || sub === 'on') {
      setModuleStatus(message.guild.id, 'warnladder', true);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_ui_toggle_on:1569329685110849576> Warning Ladder Enabled',
            description: 'Automated warning escalation ladder is now **ACTIVE**.'
          })
        ]
      });
    }

    if (sub === 'disable' || sub === 'off') {
      setModuleStatus(message.guild.id, 'warnladder', false);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: '<a:tungsten_ui_toggle_off:1569329677187678368> Warning Ladder Disabled',
            description: 'Automated warning escalation ladder is now **DISABLED**.'
          })
        ]
      });
    }

    // 5. LIST (Default)
    const rules = getLadderRules(message.guild.id);
    const isEnabled = isModuleEnabled(message.guild.id, 'warnladder');

    let desc = `**Module Status:** ${isEnabled ? '<a:tungsten_ui_toggle_on:1569329685110849576> Active' : '<a:tungsten_ui_toggle_off:1569329677187678368> Disabled'}\n\n`;
    if (rules.length === 0) {
      desc += '*No warning escalation rules configured.*\n' +
        `Use \`${prefix}warnladder set <warns> <action> [duration]\` to add rules.\n\n` +
        `**Available Actions:** \`timeout\`, \`kick\`, \`ban\`, \`softban\``;
    } else {
      desc += rules.map(r => {
        const durStr = r.duration > 0 ? ` (${formatDuration(r.duration)})` : '';
        return `• **${r.warn_count} Warnings:** \`${r.action.toUpperCase()}\`${durStr}`;
      }).join('\n');
      desc += `\n\n*Configure: \`${prefix}warnladder set <count> <action> [dur]\` | Remove: \`${prefix}warnladder remove <count>\`*`;
    }

    return message.reply({
      embeds: [
        createEmbed({
          color: client.config.COLORS.PRIMARY,
          title: '<a:tungsten_cmd_warnpanel:1567238091708702792> Warning Escalation Ladder',
          description: desc
        })
      ]
    });
  }
};
