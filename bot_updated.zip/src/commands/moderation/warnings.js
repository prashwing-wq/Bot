/**
 * Warnings Command (Prefix & Slash with Autocomplete)
 * View recorded warnings for a server member from server.db
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');

function buildWarningsPayload(guild, targetUser, client, caseNum = null) {
  const sdb = getServerDb(guild.id);
  const targetName = targetUser.user?.username || targetUser.displayName || targetUser.username;

  if (caseNum) {
    const single = sdb.prepare(`
      SELECT * FROM member_warnings WHERE guild_id = ? AND user_id = ? AND id = ?
    `).get(guild.id, targetUser.id, caseNum);

    if (single) {
      const date = new Date(single.timestamp).toLocaleString();
      return {
        embeds: [
          createEmbed({
            color: client.config.COLORS.PRIMARY,
            title: `Warning #${single.id} — ${targetName}`,
            description: `• **Moderator:** <@${single.moderator_id}>\n• **Date:** ${date}\n• **Reason:** ${single.reason}`
          })
        ]
      };
    }
  }

  const rows = sdb.prepare(`
    SELECT * FROM member_warnings WHERE guild_id = ? AND user_id = ? ORDER BY timestamp DESC LIMIT 10
  `).all(guild.id, targetUser.id);

  if (!rows || rows.length === 0) {
    return {
      embeds: [
        createEmbed({
          color: client.config.COLORS.SUCCESS,
          title: `Warnings — ${targetName}`,
          description: `<a:tungsten_shield:1567242104923627574> **${targetName}** has a completely clean record (0 warnings).`
        })
      ]
    };
  }

  const warnList = rows.map(r => {
    const date = new Date(r.timestamp).toLocaleDateString();
    return `\`#${r.id}\` **${date}** by <@${r.moderator_id}>\n> **Reason:** ${r.reason}`;
  }).join('\n\n');

  return {
    embeds: [
      createEmbed({
        color: client.config.COLORS.PRIMARY,
        title: `Warnings History [${rows.length}] — ${targetName}`,
        description: warnList,
        footer: `Total Warnings: ${rows.length}`
      })
    ]
  };
}

module.exports = {
  name: 'warnings',
  description: 'View recorded warnings for a server member.',
  permissions: ['ModerateMembers'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'moderation',
  usage: 'warnings <@member|id> [case_number]',
  aliases: ['warns'],
  cooldown: 3,

  slash: {
    name: 'warnings',
    description: 'View recorded warnings for a server member.',
    options: [
      {
        name: 'user',
        description: 'The member to inspect',
        type: 6, // USER
        required: true
      },
      {
        name: 'case',
        description: 'Specific warning case ID to view',
        type: 4, // INTEGER
        required: false,
        autocomplete: true
      }
    ]
  },

  async autocomplete(interaction, client) {
    try {
      const sdb = getServerDb(interaction.guild.id);
      const userOption = interaction.options.get('user');
      const focusedValue = interaction.options.getFocused();

      let query = 'SELECT id, reason, timestamp FROM member_warnings WHERE guild_id = ?';
      const params = [interaction.guild.id];

      if (userOption && userOption.value) {
        query += ' AND user_id = ?';
        params.push(userOption.value);
      }
      query += ' ORDER BY id DESC LIMIT 25';

      const rows = sdb.prepare(query).all(...params);
      const filtered = rows.filter(r => String(r.id).includes(String(focusedValue || '')));

      await interaction.respond(
        filtered.slice(0, 25).map(r => ({
          name: `#${r.id} - ${r.reason ? r.reason.slice(0, 50) : 'No reason'}`,
          value: r.id
        }))
      );
    } catch (_) {
      await interaction.respond([]);
    }
  },

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: 'You need the `Moderate Members` permission to view warnings.'
          })
        ]
      });
    }

    const targetUser = message.mentions?.members?.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : null);

    if (!targetUser) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Invalid Target',
            description: `**Usage:** \`${prefix}warnings <@member|id> [case_number]\``
          })
        ]
      });
    }

    const caseNum = args[1] && /^\d+$/.test(args[1]) ? parseInt(args[1], 10) : null;
    const payload = buildWarningsPayload(message.guild, targetUser, client, caseNum);
    return message.reply(payload);
  },

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser('user');
    const caseNum = interaction.options.getInteger('case');

    let targetMember;
    try {
      targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
    } catch (_) {}

    const payload = buildWarningsPayload(interaction.guild, targetMember || user, client, caseNum);
    return interaction.reply(payload);
  },

  buildWarningsPayload
};
