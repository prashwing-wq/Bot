/**
 * Channel Clone Command (Node.js)
 * Duplicates a specified channel preserving position, category parent, topic, and permission overwrites.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { checkModAction } = require('../../utils/modActionLimiter');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'clone',
  category: 'moderation',
  description: 'Clones a channel preserving parent category, position, topic, and permission overwrites.',
  usage: '[#channel|id]',
  cooldown: 5,
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Channels` permission to clone channels.'
          })
        ]
      });
    }

    const quota = await checkModAction(message.guild, message.author.id, 'channel');
    if (!quota.allowed) {
      return message.reply(
        `<a:tungsten_warn:1567246685082746940> **Action Rate Limit Exceeded:** You have reached the safe action quota for channel modifications (${quota.limit} per window). Please wait **${quota.remainingTime}s** before cloning again.`
      );
    }

    const targetInput = args[0];
    let channelToClone = message.channel;
    if (targetInput) {
      const cleanId = targetInput.replace(/[<#>]/g, '');
      channelToClone = message.guild.channels.cache.get(cleanId)
        || message.guild.channels.cache.find(c => c.name.toLowerCase() === targetInput.toLowerCase())
        || message.channel;
    }

    if (!channelToClone || typeof channelToClone.clone !== 'function') {
      return message.reply('<a:tungsten_close:1567234632905138206> Unable to clone the specified channel.');
    }

    try {
      const cloned = await channelToClone.clone({
        name: channelToClone.name,
        parent: channelToClone.parentId || null,
        position: channelToClone.position,
        topic: channelToClone.topic || null,
        nsfw: Boolean(channelToClone.nsfw),
        rateLimitPerUser: channelToClone.rateLimitPerUser || 0,
        permissionOverwrites: channelToClone.permissionOverwrites ? channelToClone.permissionOverwrites.cache : undefined,
        reason: `Channel cloned by ${message.author.tag} (${message.author.id})`
      });

      const { getServerDb } = require('../../utils/serverDb');
      const sdb = getServerDb(message.guild.id);
      await logAction(message.guild, sdb, {
        emoji: EMOJIS.CLIPBOARD,
        action: 'channel_clone',
        targetId: cloned.id,
        moderatorId: message.author.id,
        reason: `Cloned #${channelToClone.name}`
      }).catch(() => null);

      const embed = createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '📋  Channel Cloned',
        description:
          `> Successfully cloned ${channelToClone} into ${cloned}.\n\n` +
          `• **New Channel:** ${cloned} (\`${cloned.id}\`)\n` +
          `• **Category:** ${cloned.parent ? `${cloned.parent.name}` : '*None*'}\n` +
          `• **Position Preserved:** \`#${cloned.position}\`\n` +
          `• **Permission Overwrites:** Copied from source channel`
      });

      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to clone channel: ${err.message}`);
    }
  }
};
