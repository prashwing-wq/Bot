/**
 * Unlock & Unlockall Channel Command (Prefix & Slash)
 * Unlocks the current channel, specified channel, or all text channels in the guild.
 */
const {
  PermissionFlagsBits,
  ChannelType,
  SlashCommandBuilder
} = require('discord.js');
const { hasPerm } = require('../../utils/tools');
const { isAntinukeArmed } = require('../../utils/antinukeEngine');
const { createV2Card } = require('../../utils/componentsV2');

async function handleUnlock({ guild, member, author, targetChannel, isAll }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  // Antinuke Prerequisite
  if (!isAntinukeArmed(guild.id)) {
    return {
      error: '<a:tungsten_warn:1567242784535085148> **Antinuke Is Disabled**\nModeration actions are locked because Antinuke is **disabled** on this server. To unlock channels, you must first enable Antinuke with `antinuke enable`.'
    };
  }

  if (!hasPerm(member, PermissionFlagsBits.ManageChannels)) {
    return { error: '<a:tungsten_close:1567234632905138206> You need the **Manage Channels** permission to execute this command.' };
  }

  if (guild.members?.me && !guild.members.me.permissions?.has(PermissionFlagsBits.ManageChannels)) {
    return { error: '<a:tungsten_close:1567234632905138206> I lack the **Manage Channels** permission to unlock channels.' };
  }

  const everyone = guild.roles?.everyone || guild.roles?.cache?.get(guild.id) || guild.id;

  // Mass Server Channel Unlock (unlockall)
  if (isAll) {
    let allChannels = guild.channels?.cache;
    if (typeof guild.channels?.fetch === 'function') {
      try {
        allChannels = await guild.channels.fetch();
      } catch (_) {}
    }

    const textChannels = (allChannels || new Map()).filter(c =>
      c && (c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement)
    );

    let unlockedCount = 0;
    for (const [, ch] of textChannels) {
      try {
        if (ch?.permissionOverwrites?.edit) {
          await ch.permissionOverwrites.edit(everyone, {
            SendMessages: null,
            SendMessagesInThreads: null,
            CreatePublicThreads: null,
            CreatePrivateThreads: null,
            AddReactions: null
          }, { reason: `Mass unlockall by ${author.username}` });
          unlockedCount++;
        }
      } catch (_) {}
    }

    const card = createV2Card({
      title: '<a:tungsten_unlock:1567246515209117968> Mass Channel Unlock Complete',
      description:
        `> Successfully unlocked **${unlockedCount}** text channel(s) for \`@everyone\`.\n\n` +
        `• **Status:** Channel messaging permissions restored\n` +
        `• **Moderator:** <@${author.id}>\n`,
      footerText: `Tungsten Channel Security • ${guild.name}`
    });

    return { success: true, embed: card };
  }

  // Single Channel Unlock
  let channel = targetChannel;
  if (!channel) return { error: '<a:tungsten_close:1567234632905138206> Invalid channel provided.' };

  // Resolve full channel object if cached or fetchable
  if (channel.id && guild.channels?.cache?.has(channel.id)) {
    channel = guild.channels.cache.get(channel.id) || channel;
  } else if (channel.id && typeof guild.channels?.fetch === 'function') {
    channel = await guild.channels.fetch(channel.id).catch(() => channel) || channel;
  }

  // Handle Thread Unlocking
  const isThread = (typeof channel.isThread === 'function' && channel.isThread()) ||
    channel.type === ChannelType.PublicThread ||
    channel.type === ChannelType.PrivateThread ||
    channel.type === ChannelType.AnnouncementThread;

  if (isThread) {
    try {
      if (typeof channel.setLocked === 'function') {
        await channel.setLocked(false, `Unlocked by ${author.username}`);
      }
      const card = createV2Card({
        title: '<a:tungsten_unlock:1567246515209117968> Thread Unlocked',
        description:
          `> Thread <#${channel.id}> has been unlocked.\n\n` +
          `• **Thread:** <#${channel.id}> (\`${channel.name}\`)\n` +
          `• **Moderator:** <@${author.id}>\n`,
        footerText: `Tungsten Thread Security`
      });
      return { success: true, embed: card };
    } catch (err) {
      return { error: `<a:tungsten_close:1567234632905138206> Failed to unlock thread: ${err.message}` };
    }
  }

  const isTextLike = (typeof channel.isTextBased === 'function' && channel.isTextBased()) ||
    channel.type === ChannelType.GuildText ||
    channel.type === ChannelType.GuildAnnouncement ||
    channel.type === ChannelType.GuildVoice;

  if (!isTextLike || !channel.permissionOverwrites?.edit) {
    return { error: '<a:tungsten_close:1567234632905138206> Channel must be a text, announcement, voice, or thread channel.' };
  }

  try {
    await channel.permissionOverwrites.edit(everyone, {
      SendMessages: null,
      SendMessagesInThreads: null,
      CreatePublicThreads: null,
      CreatePrivateThreads: null,
      AddReactions: null
    }, { reason: `Unlocked by ${author.username}` });

    const card = createV2Card({
      title: '<a:tungsten_unlock:1567246515209117968> Channel Unlocked',
      description:
        `> Channel <#${channel.id}> has been unlocked for \`@everyone\`.\n\n` +
        `• **Channel:** <#${channel.id}> (\`${channel.name}\`)\n` +
        `• **Moderator:** <@${author.id}>\n`,
      footerText: `Tungsten Channel Security`
    });

    return { success: true, embed: card };
  } catch (err) {
    return { error: `<a:tungsten_close:1567234632905138206> Failed to unlock channel: ${err.message}` };
  }
}

module.exports = {
  name: 'unlock',
  aliases: ['unlockall', 'chunlock'],
  category: 'moderation',
  description: 'Unlocks the current channel, specified channel, or all server channels for @everyone.',
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  usage: '[#channel | all]',
  cooldown: 3,

  slash: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlocks the current channel, specified channel, or all server channels for @everyone.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .setDMPermission(false)
    .addChannelOption(opt =>
      opt.setName('channel')
        .setDescription('Specific channel to unlock (defaults to current channel)')
        .addChannelTypes(
          ChannelType.GuildText,
          ChannelType.GuildAnnouncement,
          ChannelType.GuildVoice,
          ChannelType.PublicThread,
          ChannelType.PrivateThread
        )
        .setRequired(false)
    )
    .addBooleanOption(opt =>
      opt.setName('all')
        .setDescription('Unlock all text channels across the server')
        .setRequired(false)
    ),

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'unlock').toLowerCase();
    const isAll = invoked === 'unlockall' || args[0]?.toLowerCase() === 'all';

    const targetChannel = isAll
      ? null
      : (message.mentions?.channels?.first() || (args[0] ? message.guild.channels.cache.get(args[0]) : null) || message.channel);

    const res = await handleUnlock({
      guild: message.guild,
      member: message.member,
      author: message.author,
      targetChannel,
      isAll
    });

    if (res.error) return message.reply(res.error);
    return message.reply({ embeds: [res.embed] });
  },

  async executeSlash(interaction, client) {
    if (typeof interaction.deferReply === 'function' && !interaction.deferred && !interaction.replied) {
      await interaction.deferReply().catch(() => null);
    }

    const isAll = interaction.options.getBoolean('all') || false;
    let channel = interaction.options.getChannel('channel') || interaction.channel;
    if (channel?.id && interaction.guild?.channels?.cache?.has(channel.id)) {
      channel = interaction.guild.channels.cache.get(channel.id) || channel;
    }

    const res = await handleUnlock({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetChannel: channel,
      isAll
    });

    const replyFn = (interaction.deferred || interaction.replied)
      ? (opts) => interaction.editReply(opts)
      : (opts) => interaction.reply(opts);

    if (res.error) return replyFn({ content: res.error, ephemeral: true });
    return replyFn({ embeds: [res.embed] });
  },

  handleUnlock
};
