/**
 * Mute / Timeout Command (Prefix & Slash)
 */
const { PermissionFlagsBits } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');

function parseDuration(str) {
  if (!str) return null;
  const match = str.match(/^(\d+)([smhdw])$/i);
  if (!match) return null;
  const num = parseInt(match[1], 10);
  if (num <= 0) return -1;
  const unit = match[2].toLowerCase();
  switch (unit) {
    case 's': return num * 1000;
    case 'm': return num * 60 * 1000;
    case 'h': return num * 3600 * 1000;
    case 'd': return num * 86400 * 1000;
    case 'w': return num * 7 * 86400 * 1000;
    default: return null;
  }
}

async function handleMute({ guild, member, author, targetId, durationInput, reason, client }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  const { isAntinukeArmed } = require('../../utils/antinukeEngine');
  if (!isAntinukeArmed(guild.id)) {
    return { error: '<a:tungsten_warn:1567242784535085148> **Antinuke Is Disabled**\nModeration actions are locked because Antinuke is **disabled** on this server. To timeout or moderate members, you must first enable Antinuke with `antinuke enable`.' };
  }

  if (!hasPerm(member, PermissionFlagsBits.ModerateMembers)) {
    return { error: '<a:tungsten_close:1567234632905138206> You need the **Timeout Members** permission to execute this command.' };
  }

  if (!guild.members.me.permissions.has(PermissionFlagsBits.ModerateMembers)) {
    return { error: '<a:tungsten_close:1567234632905138206> I lack the **Timeout Members** permission.' };
  }

  if (!targetId) {
    return { error: 'Invalid user target provided.' };
  }

  const cleanTargetId = String(targetId).replace(/[<@!>]/g, '').trim();
  if (!/^\d{15,21}$/.test(cleanTargetId)) {
    return { error: '<a:tungsten_close:1567234632905138206> Please provide a valid user mention or numeric Snowflake ID.' };
  }
  if (cleanTargetId === author.id) {
    return { error: '<a:tungsten_close:1567234632905138206> You cannot timeout yourself.' };
  }

  let durationMs = parseDuration(durationInput);
  let cleanReason = reason;

  if (durationMs === -1 || (durationMs !== null && durationMs < 5000)) {
    return { error: '<a:tungsten_close:1567234632905138206> Timeout duration must be at least 5 seconds and at most 28 days.' };
  }

  if (durationMs === null) {
    durationMs = 10 * 60 * 1000; // default 10 minutes
    if (!cleanReason && durationInput) {
      cleanReason = durationInput;
    }
  }
  if (!cleanReason) cleanReason = 'No reason specified by moderator';

  const maxMs = 28 * 24 * 60 * 60 * 1000; // Discord max 28 days
  if (durationMs > maxMs) {
    return { error: '<a:tungsten_close:1567234632905138206> Timeout duration cannot exceed 28 days.' };
  }

  let targetMember;
  try {
    targetMember = await guild.members.fetch(cleanTargetId).catch(() => null);
  } catch (e) {}

  if (!targetMember) return { error: '<a:tungsten_close:1567234632905138206> Could not find that member in this server.' };

  if (targetMember.permissions?.has?.(PermissionFlagsBits.Administrator)) {
    return { error: '<a:tungsten_close:1567234632905138206> Discord does not allow timing out a member with the **Administrator** permission.' };
  }

  if (isOwner(targetMember.id)) return { error: '<a:tungsten_close:1567234632905138206> You cannot timeout a Bot Owner.' };
  if (targetMember.id === guild.ownerId) return { error: '<a:tungsten_close:1567234632905138206> You cannot timeout the Server Owner.' };
  if (client?.user && targetMember.id === client.user.id) return { error: '<a:tungsten_close:1567234632905138206> I cannot timeout myself.' };

  const memberHighestPos = typeof member.roles?.highest?.position === 'number'
    ? member.roles.highest.position
    : (Array.isArray(member.roles)
        ? Math.max(0, ...member.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);
  const targetHighestPos = typeof targetMember.roles?.highest?.position === 'number'
    ? targetMember.roles.highest.position
    : (Array.isArray(targetMember.roles)
        ? Math.max(0, ...targetMember.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);
  const botHighestPos = typeof guild.members?.me?.roles?.highest?.position === 'number'
    ? guild.members.me.roles.highest.position
    : (Array.isArray(guild.members?.me?.roles)
        ? Math.max(0, ...guild.members.me.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);

  if (!isOwner(author.id) && memberHighestPos <= targetHighestPos) {
    return { error: '<a:tungsten_close:1567234632905138206> You cannot timeout this member because their highest role is equal to or higher than yours.' };
  }
  if (botHighestPos <= targetHighestPos) {
    return { error: '<a:tungsten_close:1567234632905138206> I cannot timeout this member because their highest role is higher than or equal to mine.' };
  }

  try {
    await targetMember.timeout(durationMs, `${cleanReason} | Moderator: ${author.username} (${author.id})`);

    const sdb = getServerDb(guild.id);
    await logAction(guild, sdb, {
      emoji: '<a:tungsten_mute:1567241451992121647>',
      action: 'mute',
      targetId: cleanTargetId,
      moderatorId: author.id,
      reason: `${cleanReason} (${Math.round(durationMs / 60000)}m)`
    });

    return {
      success: true,
      embed: createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '<a:tungsten_mute:1567241451992121647> Member Timed Out',
        description: `Successfully timed out ${targetMember}.\n**Duration:** \`${Math.round(durationMs / 60000)} minute(s)\`\n**Reason:** ${cleanReason}\n**Moderator:** ${author}`
      })
    };
  } catch (err) {
    return { error: `<a:tungsten_close:1567234632905138206> Failed to timeout member: ${err.message}` };
  }
}

module.exports = {
  name: 'mute',
  aliases: ['m', 'timeout', 'shutup'],
  category: 'moderation',
  description: 'Times out / mutes a member for a specified duration.',
  permissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  usage: '<@user|id> [time: 10m, 1h, 1d] [reason]',
  cooldown: 3,

  slash: {
    name: 'mute',
    description: 'Times out / mutes a member for a specified duration.',
    options: [
      {
        name: 'user',
        description: 'The user to timeout (mention or ID)',
        type: 6, // USER
        required: true
      },
      {
        name: 'duration',
        description: 'Duration (e.g. 10m, 1h, 1d - default: 10m)',
        type: 3, // STRING
        required: false
      },
      {
        name: 'reason',
        description: 'Reason for the timeout',
        type: 3, // STRING
        required: false
      }
    ]
  },

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const targetInput = args[0];
    if (!targetInput) {
      return message.reply(`Usage: \`${prefix}mute <@user|id> [time: 10m, 1h, 1d] [reason]\``);
    }

    const durationInput = args[1];
    const reason = args.slice(2).join(' ');

    const res = await handleMute({
      guild: message.guild,
      member: message.member,
      author: message.author,
      targetId: targetInput,
      durationInput,
      reason,
      client
    });

    if (res.error) return message.reply(res.error);
    return message.reply({ embeds: [res.embed] });
  },

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser('user');
    const durationInput = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason');

    const res = await handleMute({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetId: user.id,
      durationInput,
      reason,
      client
    });

    if (res.error) return interaction.reply({ content: res.error, ephemeral: true });
    return interaction.reply({ embeds: [res.embed] });
  },

  parseDuration,
  handleMute
};
