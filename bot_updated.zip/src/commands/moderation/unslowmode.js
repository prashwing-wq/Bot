/**
 * Unslowmode Command (Node.js)
 * Removes slowmode from the current or specified channel by setting rateLimitPerUser to 0.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { logAction } = require('../../utils/modlog');

module.exports = {
  name: 'unslowmode',
  aliases: ['slowmodeoff', 'noslowmode'],
  category: 'moderation',
  description: 'Disables slowmode message rate limit on the channel.',
  usage: '[#channel]',
  cooldown: 3,
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Channels` permission to remove slowmode.'
          })
        ]
      });
    }

    const targetChannel = message.mentions.channels.first()
      || (args[0] ? message.guild.channels.cache.get(args[0].replace(/[<#>]/g, '')) : null)
      || message.channel;

    if (!targetChannel || typeof targetChannel.setRateLimitPerUser !== 'function') {
      return message.reply('<a:tungsten_close:1567234632905138206> Target channel does not support slowmode.');
    }

    try {
      await targetChannel.setRateLimitPerUser(0, `Slowmode disabled by ${message.author.tag}`);

      const { getServerDb } = require('../../utils/serverDb');
      const sdb = getServerDb(message.guild.id);
      await logAction(message.guild, sdb, {
        emoji: '⏱️',
        action: 'unslowmode',
        targetId: targetChannel.id,
        moderatorId: message.author.id,
        reason: 'Disabled channel slowmode'
      }).catch(() => null);

      const embed = createEmbed({
        color: client.config.COLORS.SUCCESS,
        title: '<a:tungsten_autoslow:1569329238585118783> Slowmode Disabled',
        description: `<a:tungsten_ui_toggle_off:1569329677187678368> Slowmode message rate limit has been removed for ${targetChannel}.`
      });

      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to disable slowmode: ${err.message}`);
    }
  }
};
