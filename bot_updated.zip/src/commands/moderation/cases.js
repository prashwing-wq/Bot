/**
 * Moderation Cases & History Command (Node.js)
 * Tracks, inspects, and logs all administrative disciplinary actions with audit IDs.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');

module.exports = {
  name: 'cases',
  aliases: ['case', 'modhistory', 'history'],
  category: 'moderation',
  description: 'View moderation history, disciplinary cases, or specific case details.',
  permissions: ['ModerateMembers'],
  botPermissions: ['SendMessages','EmbedLinks'],
  usage: '[<case_id> | @user | list]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Moderate Members` permission to inspect moderation cases.');
    }

    const sdb = getServerDb(message.guild.id);

    // 1. Specific Case Inspection
    if (args[0] && /^\d+$/.test(args[0]) && !message.mentions?.users?.first()) {
      const caseId = parseInt(args[0], 10);
      const row = sdb.prepare('SELECT * FROM mod_cases WHERE guild_id = ? AND (case_num = ? OR id = ?)').get(message.guild.id, caseId, caseId);

      if (!row) return message.reply(`<a:tungsten_close:1567234632905138206> Case #${caseId} not found in this server.`);

      const embed = createEmbed({
        title: `⚖️  Disciplinary Case #${row.case_num || row.id}`,
        description:
          `• **Action:** \`${row.action.toUpperCase()}\`\n` +
          `• **Target Member:** <@${row.user_id}> (\`${row.user_id}\`)\n` +
          `• **Moderator:** <@${row.moderator_id}> (\`${row.moderator_id}\`)\n` +
          `• **Timestamp:** <t:${row.timestamp}:F> (<t:${row.timestamp}:R>)\n\n` +
          `**Reason:**\n${row.reason || '*No reason recorded.*'}`
      });

      return message.reply({ embeds: [embed] });
    }

    // 2. Member Specific Cases
    const target = message.mentions?.users?.first();
    if (target) {
      const rows = sdb.prepare(`
        SELECT * FROM mod_cases
        WHERE guild_id = ? AND user_id = ?
        ORDER BY timestamp DESC
        LIMIT 10
      `).all(message.guild.id, target.id);

      let caseText = '';
      if (rows.length === 0) {
        caseText = `*No moderation cases on record for <@${target.id}>. Clean record!*`;
      } else {
        caseText = rows.map(r => `• **Case #${r.case_num || r.id}** — \`${r.action.toUpperCase()}\` by <@${r.moderator_id}>: *${r.reason || 'No reason'}* (<t:${r.timestamp}:R>)`).join('\n');
      }

      const embed = createEmbed({
        title: `⚖️  Disciplinary History • ${target.username}`,
        description:
          `> Member: <@${target.id}> (\`${target.id}\`)\n\n` +
          `**Recent Infractions (${rows.length}):**\n` +
          caseText
      });

      return message.reply({ embeds: [embed] });
    }

    // 3. Recent Cases Overview
    const recentRows = sdb.prepare(`
      SELECT * FROM mod_cases
      WHERE guild_id = ?
      ORDER BY timestamp DESC
      LIMIT 10
    `).all(message.guild.id);

    let listText = '';
    if (recentRows.length === 0) {
      listText = '*No disciplinary cases recorded in this server yet.*';
    } else {
      listText = recentRows.map(r => `• **#${r.case_num || r.id}** \`${r.action.toUpperCase()}\` — <@${r.user_id}> by <@${r.moderator_id}>: *${r.reason || 'None'}* (<t:${r.timestamp}:R>)`).join('\n');
    }

    const embed = createEmbed({
      title: `⚖️  Recent Moderation Cases • ${message.guild.name}`,
      description:
        `> Log of all enforcement actions recorded by Tungsten.\n\n` +
        listText +
        `\n\n-# Inspect specific case with \`${prefix}case <id>\` or \`${prefix}cases @user\``
    });

    return message.reply({ embeds: [embed] });
  }
};
