const { PermissionFlagsBits } = require('discord.js');
const { getPanelEmbed, buildCategorySelect, buildCategoryButtons } = require('./modpanel');
const { hasPerm } = require('../../utils/tools');

module.exports = {
  name: 'kickpanel',
  aliases: ['kp_mod'],
  category: 'moderation',
  description: 'Opens dedicated Kick interactive moderation GUI panel',
  usage: '',
  cooldown: 3,
  permissions: ['KickMembers'],
  botPermissions: ['KickMembers'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.KickMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Kick Members** permission to access the Kick Panel.');
    }
    const embed = getPanelEmbed('kick', message.guild, message.author, client, prefix);
    const selectMenu = buildCategorySelect('kick', message.author.id);
    const buttons = buildCategoryButtons('kick', message.author.id);
    return message.reply({ embeds: [embed], components: [selectMenu, ...buttons] });
  }
};
