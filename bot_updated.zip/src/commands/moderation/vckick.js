/**
 * Voice Channel Kick / Disconnect Command (Node.js)
 * Disconnects a member from their voice channel.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'vckick',
  aliases: ['vkick', 'voicekick', 'vcdisconnect', 'vdisconnect'],
  category: 'moderation',
  description: 'Disconnect/kick a member from a voice channel.',
  usage: '<@member|id|all> [reason]',
  cooldown: 3,
  permissions: ['MoveMembers'],
  botPermissions: ['MoveMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!args || args.length === 0) {
      return message.reply(`Usage: \`${prefix}vckick <@member|id|all> [reason]\``);
    }

    const sub = args[0].toLowerCase();

    // Mass kick / disconnect all members in current voice channel
    if (sub === 'all') {
      const voiceChannel = message.member?.voice?.channel;
      if (!voiceChannel) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to disconnect all members.');
      }

      const members = voiceChannel.members
        ? Array.from(voiceChannel.members.values()).filter(m => m.id !== client.user?.id && m.id !== message.author.id)
        : [];

      let count = 0;
      for (const m of members) {
        try {
          if (typeof m.voice.disconnect === 'function') {
            await m.voice.disconnect(`[vckick all] Disconnected by ${message.author.tag}`);
          } else {
            await m.voice.setChannel(null, `[vckick all] Disconnected by ${message.author.tag}`);
          }
          count++;
        } catch (e) {}
      }

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: EMOJIS.BOOT,
          action: 'vckick_all',
          targetId: message.guild.id,
          moderatorId: message.author.id,
          reason: `Mass voice disconnect in ${voiceChannel.name} (${count} members)`
        });
      } catch (_) {}

      return message.reply(`${EMOJIS.BOOT} Server disconnected **${count} members** from ${voiceChannel}.`);
    }

    const cleanId = sub.replace(/[<@!>]/g, '');
    const targetMember = message.mentions?.members?.first()
      || message.guild.members?.cache?.get(cleanId)
      || (typeof message.guild.members?.fetch === 'function' ? await message.guild.members.fetch(cleanId).catch(() => null) : null);

    if (!targetMember) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve \`${args[0]}\` to a valid member.`);
    }

    if (isOwner(targetMember.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice disconnect a Bot Owner.');
    }
    if (targetMember.id === message.guild.ownerId) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice disconnect the Server Owner.');
    }
    if (targetMember.id === client.user?.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> I cannot voice disconnect myself.');
    }
    if (!isOwner(message.author.id) && message.author.id !== message.guild.ownerId) {
      if (message.member?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
        if (message.member.roles.highest.position <= targetMember.roles.highest.position) {
          return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice disconnect this member because their highest role is equal to or higher than yours.');
        }
      }
    }
    if (message.guild.members.me?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
      if (message.guild.members.me.roles.highest.position <= targetMember.roles.highest.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot voice disconnect this member because their highest role is higher than or equal to mine.');
      }
    }

    const voiceChannel = targetMember.voice?.channel;
    if (!voiceChannel) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is not connected to any voice channel.`);
    }

    const reason = args.slice(1).join(' ') || `Voice disconnected by ${message.author.tag}`;
    try {
      if (typeof targetMember.voice.disconnect === 'function') {
        await targetMember.voice.disconnect(reason);
      } else {
        await targetMember.voice.setChannel(null, reason);
      }

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: EMOJIS.BOOT,
          action: 'vckick',
          targetId: targetMember.id,
          moderatorId: message.author.id,
          reason
        });
      } catch (_) {}

      const embed = createEmbed({
        color: 0xED4245,
        title: `${EMOJIS.BOOT}  Member Voice Disconnected`,
        description: `> Successfully disconnected <@${targetMember.id}> from **${voiceChannel.name}**.\n\n• **Reason:** ${reason}`
      });
      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to disconnect member: ${err.message}`);
    }
  }
};
