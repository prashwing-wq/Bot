/**
 * Tempban Command (Node.js)
 * Temporarily bans a user from the server and schedules an automatic unban task.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');
const { scheduleTask } = require('../../utils/scheduler');
const { parseLadderDuration, formatDuration } = require('../../utils/warnLadder');
const { EMOJIS } = require('../../utils/emojis');

async function handleTempban({ guild, member, author, targetId, durationStr, reason, client }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  const { isAntinukeArmed } = require('../../utils/antinukeEngine');
  if (!isAntinukeArmed(guild.id)) {
    return { error: '<a:tungsten_warn:1567242784535085148> **Antinuke Is Disabled**\nModeration actions are locked because Antinuke is **disabled** on this server. To ban, kick, or moderate members, you must first enable Antinuke with `antinuke enable`.' };
  }

  if (!hasPerm(member, PermissionFlagsBits.BanMembers)) {
    return { error: '<a:tungsten_close:1567234632905138206> You need the **Ban Members** permission to execute this command.' };
  }

  if (!guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
    return { error: '<a:tungsten_close:1567234632905138206> I lack the **Ban Members** permission to ban users.' };
  }

  if (!targetId) {
    return { error: 'Invalid user target provided.' };
  }

  const durationSec = parseLadderDuration(durationStr);
  if (!durationSec || durationSec <= 0) {
    return { error: '<a:tungsten_close:1567234632905138206> Invalid duration specified. Use format like `10m`, `2h`, `7d`.' };
  }

  const cleanTargetId = targetId.replace(/[<@!>]/g, '');
  const cleanReason = reason || 'No reason specified by moderator';

  let targetMember;
  try {
    targetMember = await guild.members.fetch(cleanTargetId).catch(() => null);
  } catch (_) {}

  if (isOwner(cleanTargetId)) {
    return { error: '<a:tungsten_close:1567234632905138206> You cannot tempban a Bot Owner.' };
  }

  // Hierarchy check
  if (targetMember) {
    if (targetMember.id === author.id) return { error: '<a:tungsten_close:1567234632905138206> You cannot tempban yourself.' };
    if (targetMember.id === guild.ownerId) return { error: '<a:tungsten_close:1567234632905138206> You cannot tempban the Server Owner.' };
    if (client?.user && targetMember.id === client.user.id) return { error: '<a:tungsten_close:1567234632905138206> I cannot ban myself.' };

    const memberHighestPos = typeof member.roles?.highest?.position === 'number'
      ? member.roles.highest.position
      : (Array.isArray(member.roles)
          ? Math.max(0, ...member.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
          : 0);
    const targetHighestPos = typeof targetMember.roles?.highest?.position === 'number'
      ? targetMember.roles.highest.position
      : (Array.isArray(targetMember.roles)
          ? Math.max(0, ...targetMember.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
          : 0);
    const botHighestPos = typeof guild.members?.me?.roles?.highest?.position === 'number'
      ? guild.members.me.roles.highest.position
      : (Array.isArray(guild.members?.me?.roles)
          ? Math.max(0, ...guild.members.me.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
          : 0);

    if (
      targetHighestPos >= memberHighestPos &&
      author.id !== guild.ownerId
    ) {
      return { error: '<a:tungsten_close:1567234632905138206> You cannot tempban this member because their highest role is equal to or higher than yours.' };
    }

    if (
      targetHighestPos >= botHighestPos
    ) {
      return { error: '<a:tungsten_close:1567234632905138206> I cannot tempban this member because their highest role is higher than or equal to mine.' };
    }

    // Try sending DM with appeal button before banning
    try {
      const appealRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`appeal:open:${guild.id}`)
          .setLabel('Appeal Ban')
          .setStyle(ButtonStyle.Primary)
          .setEmoji(EMOJIS.MEMO)
      );
      const dmEmbed = createEmbed({
        color: client.config?.COLORS?.DANGER || 0xed4245,
        title: `🔨 You have been temporarily banned from ${guild.name}`,
        description:
          `**Duration:** ${formatDuration(durationSec)}\n` +
          `**Reason:** ${cleanReason}\n\n` +
          `If you believe this ban was in error, you may submit an appeal using the button below.`
      });
      await targetMember.send({ embeds: [dmEmbed], components: [appealRow] }).catch(() => null);
    } catch (_) {}
  }

  try {
    await guild.bans.create(cleanTargetId, {
      reason: `${cleanReason} (Tempban: ${formatDuration(durationSec)}) | Mod: ${author.username} (${author.id})`
    });

    // Schedule auto-unban task
    const runAt = Date.now() + durationSec * 1000;
    const taskId = scheduleTask(guild.id, 'tempban_end', runAt, {
      guildId: guild.id,
      userId: cleanTargetId,
      reason: cleanReason
    });

    const sdb = getServerDb(guild.id);
    await logAction(guild, sdb, {
      emoji: '<a:tungsten_shield:1567242104923627574>',
      action: 'tempban',
      targetId: cleanTargetId,
      moderatorId: author.id,
      reason: `${cleanReason} [Duration: ${formatDuration(durationSec)}, Task #${taskId}]`
    });

    return {
      success: true,
      taskId,
      embed: createEmbed({
        color: client.config?.COLORS?.SUCCESS || 0x2ecc71,
        title: '<a:tungsten_shield:1567242104923627574> Member Temporarily Banned',
        description:
          `Successfully tempbanned <@${cleanTargetId}> (\`${cleanTargetId}\`).\n` +
          `**Duration:** \`${formatDuration(durationSec)}\` (Auto-unban <t:${Math.floor(runAt / 1000)}:R>)\n` +
          `**Reason:** ${cleanReason}\n` +
          `**Moderator:** ${author}`
      })
    };
  } catch (err) {
    return { error: `<a:tungsten_close:1567234632905138206> Failed to tempban user: ${err.message}` };
  }
}

module.exports = {
  name: 'tempban',
  category: 'moderation',
  description: 'Temporarily ban a member with scheduled automatic unban.',
  usage: 'tempban <@user|id> <duration> [reason]',
  aliases: ['tban'],
  permissions: ['BanMembers'],
  botPermissions: ['BanMembers'],

  slash: new SlashCommandBuilder()
    .setName('tempban')
    .setDescription('Temporarily ban a member with scheduled automatic unban.')
    .addUserOption(opt =>
      opt.setName('target')
        .setDescription('The member or user to tempban')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('duration')
        .setDescription('Duration of ban (e.g., 10m, 2h, 7d)')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason')
        .setDescription('Reason for the temporary ban')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async executeSlash(interaction, client) {
    const targetUser = interaction.options.getUser('target');
    const duration = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason');

    const res = await handleTempban({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetId: targetUser.id,
      durationStr: duration,
      reason,
      client
    });

    if (res.error) {
      return interaction.reply({ content: res.error, ephemeral: true });
    }
    return interaction.reply({ embeds: [res.embed] });
  },

  async execute(message, args, client, prefix) {
    if (args.length < 2) {
      return message.reply(`Usage: \`${prefix}tempban <@user|id> <duration> [reason]\`\nExample: \`${prefix}tempban @User 2h Spamming\``);
    }

    const target = args[0];
    const duration = args[1];
    const reason = args.slice(2).join(' ') || null;

    const res = await handleTempban({
      guild: message.guild,
      member: message.member,
      author: message.author,
      targetId: target,
      durationStr: duration,
      reason,
      client
    });

    if (res.error) {
      return message.reply(res.error);
    }
    return message.reply({ embeds: [res.embed] });
  },

  handleTempban
};
