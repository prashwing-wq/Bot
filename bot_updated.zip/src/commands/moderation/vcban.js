/**
 * Voice Ban Command (Node.js)
 * Disconnects a user from voice and denies Connect permissions on the voice channel.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'vcban',
  aliases: ['voiceban'],
  category: 'moderation',
  description: 'Disconnects user and denies Connect permission on that voice channel.',
  usage: '<@member|id> [#channel] [reason]',
  cooldown: 3,
  permissions: ['MoveMembers', 'ManageChannels'],
  botPermissions: ['MoveMembers', 'ManageChannels'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!args[0]) {
      return message.reply(`Usage: \`${prefix}vcban <@member|id> [#channel] [reason]\``);
    }

    const targetId = args[0].replace(/[<@!>]/g, '');
    const member = await message.guild.members.fetch(targetId).catch(() => null);
    if (!member) {
      return message.reply('<a:tungsten_close:1567234632905138206> Could not find that member in this server.');
    }

    if (member.id === message.author.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice ban yourself.');
    }
    if (member.id === message.guild.ownerId || isOwner(member.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice ban the server owner or bot owner.');
    }

    // Role hierarchy check
    if (message.author.id !== message.guild.ownerId && !isOwner(message.author.id)) {
      if (member.roles.highest.position >= message.member.roles.highest.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice ban a member with an equal or higher role than yours.');
      }
    }

    // Determine voice channel: explicit mention, or member's current VC, or author's VC
    const channelMention = message.mentions?.channels?.first?.();
    let vc = channelMention || member.voice?.channel || message.member?.voice?.channel;

    if (!vc || typeof vc.isVoiceBased !== 'function' || !vc.isVoiceBased()) {
      return message.reply('<a:tungsten_warn:1567246685082746940> Please specify a valid voice channel, or join one.');
    }

    const reason = args.slice(channelMention ? 2 : 1).join(' ').trim() || 'Banned from voice channel';

    try {
      // 1. Disconnect if member is in that VC
      if (member.voice?.channelId === vc.id && typeof member.voice.disconnect === 'function') {
        await member.voice.disconnect(`VC Ban by ${message.author.tag}: ${reason}`).catch(() => null);
      }

      // 2. Deny Connect permission on channel overwrites
      await vc.permissionOverwrites.edit(member.id, {
        Connect: false
      }, { reason: `VC Ban by ${message.author.tag}: ${reason}` });

      const { getServerDb } = require('../../utils/serverDb');
      const sdb = getServerDb(message.guild.id);
      await logAction(message.guild, sdb, {
        emoji: EMOJIS.CLOSE,
        action: 'vcban',
        targetId: member.id,
        moderatorId: message.author.id,
        reason: `Banned from ${vc.name}: ${reason}`
      }).catch(() => null);

      const embed = createEmbed({
        color: 0xED4245,
        title: `${EMOJIS.ERROR}  Voice Channel Ban`,
        description:
          `> Successfully banned ${member} from ${vc}.\n\n` +
          `• **Channel:** ${vc} (\`${vc.name}\`)\n` +
          `• **Moderator:** ${message.author}\n` +
          `• **Reason:** ${reason}`
      });

      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to voice ban member: ${err.message}`);
    }
  }
};
