/**
 * Voice Channel Deafen Command (Node.js)
 * Server-deafens or undeafens a member in a voice channel.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');
const { EMOJIS } = require('../../utils/emojis');

module.exports = {
  name: 'vcdeafen',
  aliases: ['vdeafen', 'voicedeafen', 'vcundeafen', 'vundeafen'],
  category: 'moderation',
  description: 'Server-deafen or undeafen a member in a voice channel.',
  usage: '<@member|id|all> [undeafen] [reason]',
  cooldown: 3,
  permissions: ['DeafenMembers'],
  botPermissions: ['DeafenMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!args || args.length === 0) {
      return message.reply(`Usage: \`${prefix}vcdeafen <@member|id|all> [undeafen] [reason]\``);
    }

    const isUndeafenCommand = Boolean(message.content?.toLowerCase()?.includes('undeafen') || args.some(a => a?.toLowerCase() === 'undeafen'));
    const isMass = Boolean(args.some(a => a?.toLowerCase() === 'all'));

    // Mass deafen / undeafen all members in current voice channel
    if (isMass) {
      const voiceChannel = message.member?.voice?.channel;
      if (!voiceChannel) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to deafen/undeafen all members.');
      }

      const members = voiceChannel.members
        ? Array.from(voiceChannel.members.values()).filter(m => m.id !== client.user?.id && m.id !== message.author.id)
        : [];

      const shouldDeafen = !isUndeafenCommand;
      let count = 0;
      for (const m of members) {
        try {
          await m.voice.setDeaf(shouldDeafen, `[vcdeafen all] ${shouldDeafen ? 'Deafened' : 'Undeafened'} by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: shouldDeafen ? EMOJIS.MUTE : EMOJIS.SOUND,
          action: shouldDeafen ? 'vcdeafen_all' : 'vcundeafen_all',
          targetId: message.guild.id,
          moderatorId: message.author.id,
          reason: `Mass voice ${shouldDeafen ? 'deafen' : 'undeafen'} in ${voiceChannel.name} (${count} members)`
        });
      } catch (_) {}

      return message.reply(`${shouldDeafen ? EMOJIS.MUTE : EMOJIS.SOUND} Server-${shouldDeafen ? 'deafened' : 'undeafened'} **${count} members** in ${voiceChannel}.`);
    }

    const targetArg = (args[0]?.toLowerCase() === 'undeafen' ? args[1] : args[0]) || '';
    const cleanId = targetArg.replace(/[<@!>]/g, '');

    const targetMember = message.mentions?.members?.first()
      || message.guild.members?.cache?.get(cleanId)
      || (typeof message.guild.members?.fetch === 'function' ? await message.guild.members.fetch(cleanId).catch(() => null) : null);

    if (!targetMember) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve target member.`);
    }

    if (isOwner(targetMember.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice deafen a Bot Owner.');
    }
    if (targetMember.id === message.guild.ownerId) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice deafen the Server Owner.');
    }
    if (targetMember.id === client.user?.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> I cannot voice deafen myself.');
    }
    if (!isOwner(message.author.id) && message.author.id !== message.guild.ownerId) {
      if (message.member?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
        if (message.member.roles.highest.position <= targetMember.roles.highest.position) {
          return message.reply('<a:tungsten_close:1567234632905138206> You cannot modify voice deafen status for this member because their highest role is equal to or higher than yours.');
        }
      }
    }
    if (message.guild.members.me?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
      if (message.guild.members.me.roles.highest.position <= targetMember.roles.highest.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot modify voice deafen status for this member because their highest role is higher than or equal to mine.');
      }
    }

    if (!targetMember.voice?.channel) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is not connected to any voice channel.`);
    }

    const shouldDeafen = !isUndeafenCommand;
    const reason = args.filter(a => a.toLowerCase() !== 'undeafen' && a !== args[0]).join(' ') || `Action by ${message.author.tag}`;

    try {
      await targetMember.voice.setDeaf(shouldDeafen, reason);

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: shouldDeafen ? EMOJIS.MUTE : EMOJIS.SOUND,
          action: shouldDeafen ? 'vcdeafen' : 'vcundeafen',
          targetId: targetMember.id,
          moderatorId: message.author.id,
          reason
        });
      } catch (_) {}

      const embed = createEmbed({
        color: shouldDeafen ? 0xED4245 : 0x57F287,
        title: shouldDeafen ? `${EMOJIS.MUTE} Member Voice Deafened` : `${EMOJIS.SOUND} Member Voice Undeafened`,
        description: `> Successfully server-${shouldDeafen ? 'deafened' : 'undeafened'} <@${targetMember.id}> in **${targetMember.voice.channel.name}**.\n\n• **Reason:** ${reason}`
      });
      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to update voice deafen status: ${err.message}`);
    }
  }
};
