const { PermissionFlagsBits } = require('discord.js');
const { getPanelEmbed, buildCategorySelect, buildCategoryButtons } = require('./modpanel');
const { hasPerm } = require('../../utils/tools');

module.exports = {
  name: 'banpanel',
  aliases: ['bp_mod'],
  category: 'moderation',
  description: 'Opens dedicated Ban & Unban interactive moderation GUI panel',
  usage: '',
  cooldown: 3,
  permissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.BanMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Ban Members** permission to access the Ban Panel.');
    }
    const embed = getPanelEmbed('ban', message.guild, message.author, client, prefix);
    const selectMenu = buildCategorySelect('ban', message.author.id);
    const buttons = buildCategoryButtons('ban', message.author.id);
    return message.reply({ embeds: [embed], components: [selectMenu, ...buttons] });
  }
};
