/**
 * Purge / Clear Messages Command (Prefix & Slash)
 */
const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const { hasPerm } = require('../../utils/tools');

async function handlePurge({ guild, channel, member, author, amount, client: _client, isSlash = false }) {
  if (!guild || !channel) return { error: 'This command can only be used in a server channel.' };

  if (!hasPerm(member, PermissionFlagsBits.ManageMessages)) {
    return { error: '<a:tungsten_close:1567234632905138206> You need the **Manage Messages** permission to execute this command.' };
  }

  if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageMessages)) {
    return { error: '<a:tungsten_close:1567234632905138206> I lack the **Manage Messages** permission to delete messages.' };
  }

  const cleanAmount = Math.min(100, Math.max(1, Math.floor(Number(amount))));
  if (isNaN(cleanAmount) || cleanAmount < 1) {
    return { error: 'Amount must be an integer between 1 and 100.' };
  }

  // C10: Confused Deputy Limiter check
  const { checkModAction } = require('../../utils/modActionLimiter');
  const quota = await checkModAction(guild, author.id, 'purge');
  if (!quota.allowed) {
    return { error: `<a:tungsten_warn:1567246685082746940> **Action Rate Limit Exceeded:** You have reached the safe action quota for message purges (${quota.limit} per window). Please wait **${quota.remainingTime}s** before purging again.` };
  }

  try {
    const deleted = await channel.bulkDelete(cleanAmount, true);
    if (deleted.size === 0) {
      return {
        success: true,
        count: 0,
        message: '⚠️ No messages were deleted (messages older than 14 days cannot be bulk-deleted by Discord).'
      };
    }
    return {
      success: true,
      count: deleted.size,
      message: `🧹 Successfully deleted **${deleted.size}** messages.`
    };
  } catch (err) {
    return { error: `<a:tungsten_close:1567234632905138206> Failed to purge messages: ${err.message}` };
  }
}

module.exports = {
  name: 'purge',
  aliases: ['clear', 'clean'],
  category: 'moderation',
  description: 'Bulk deletes a specified number of messages (1-100).',
  permissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  usage: '<amount: 1-100>',
  cooldown: 2,

  slash: {
    name: 'purge',
    description: 'Bulk deletes a specified number of messages (1-100).',
    options: [
      {
        name: 'amount',
        description: 'Number of messages to delete (1-100)',
        type: 4, // INTEGER
        minValue: 1,
        maxValue: 100,
        required: true
      }
    ]
  },

  async execute(message, args, client, prefix) {
    if (!message.guild || !message.channel) return;

    const amount = parseInt(args[0], 10);
    if (isNaN(amount) || amount < 1 || amount > 100) {
      return message.reply(`Usage: \`${prefix}purge <amount: 1-100>\``);
    }

    // Delete user invocation message first if possible
    await message.delete().catch(() => {});

    const res = await handlePurge({
      guild: message.guild,
      channel: message.channel,
      member: message.member,
      author: message.author,
      amount,
      client,
      isSlash: false
    });

    if (res.error) {
      return message.channel.send(res.error);
    }

    const msg = await message.channel.send(res.message);
    setTimeout(() => msg.delete().catch(() => {}), 4000);
  },

  async executeSlash(interaction, client) {
    const amount = interaction.options.getInteger('amount');

    const res = await handlePurge({
      guild: interaction.guild,
      channel: interaction.channel,
      member: interaction.member,
      author: interaction.user,
      amount,
      client,
      isSlash: true
    });

    if (res.error) {
      return interaction.reply({ content: res.error, flags: MessageFlags.Ephemeral });
    }

    return interaction.reply({ content: res.message, flags: MessageFlags.Ephemeral });
  },

  handlePurge
};
