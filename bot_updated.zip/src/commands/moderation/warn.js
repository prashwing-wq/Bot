/**
 * Warn Command (Prefix & Slash)
 * Issues a formal warning to a member and records it in server.db
 */
const { PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../../utils/serverDb');
const { hasPerm, createEmbed, isOwner } = require('../../utils/tools');
const { logAction } = require('../../utils/modlog');
const { checkAndExecuteLadder } = require('../../utils/warnLadder');

async function handleWarn({ guild, member, author, targetMember, reason, client }) {
  if (!guild) return { error: 'This command can only be used in a server.' };

  const { isAntinukeArmed } = require('../../utils/antinukeEngine');
  if (!isAntinukeArmed(guild.id)) {
    return {
      error: 'Antinuke Disabled',
      embed: createEmbed({
        title: '<a:tungsten_warn:1567242784535085148> Antinuke Is Disabled',
        description: '> **Security Requirement**: Moderation actions are locked because Antinuke is **disabled** on this server.\n\nTo warn or moderate members, you must first enable Antinuke with `antinuke enable`.'
      })
    };
  }

  if (!hasPerm(member, PermissionsBitField.Flags.ModerateMembers)) {
    return {
      error: 'Permission Denied',
      embed: createEmbed({
        color: client.config.COLORS.DANGER,
        title: 'Permission Denied',
        description: 'You need the `Moderate Members` permission to warn members.'
      })
    };
  }

  if (!targetMember) {
    return {
      error: 'Invalid Target',
      embed: createEmbed({
        color: client.config.COLORS.WARNING,
        title: 'Invalid Target',
        description: 'Could not find that member in this server.'
      })
    };
  }

  if (targetMember.id === author.id) {
    return { error: 'You cannot warn yourself.' };
  }

  if (client?.user && targetMember.id === client.user.id) {
    return { error: 'You cannot warn Tungsten.' };
  }

  if (isOwner(targetMember.id)) {
    return { error: '<a:tungsten_close:1567234632905138206> You cannot warn a Bot Owner.' };
  }

  if (targetMember.id === guild.ownerId) {
    return { error: 'You cannot warn the Server Owner.' };
  }

  const memberHighestPos = typeof member.roles?.highest?.position === 'number'
    ? member.roles.highest.position
    : (Array.isArray(member.roles)
        ? Math.max(0, ...member.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);
  const targetHighestPos = typeof targetMember.roles?.highest?.position === 'number'
    ? targetMember.roles.highest.position
    : (Array.isArray(targetMember.roles)
        ? Math.max(0, ...targetMember.roles.map(rId => guild.roles.cache.get(rId)?.position || 0))
        : 0);

  if (targetHighestPos >= memberHighestPos && author.id !== guild.ownerId) {
    return { error: 'You cannot warn someone with an equal or higher role than you.' };
  }

  const cleanReason = reason || 'No reason provided';
  const sdb = getServerDb(guild.id);

  sdb.prepare(`
    INSERT INTO member_warnings (guild_id, user_id, moderator_id, reason, timestamp)
    VALUES (?, ?, ?, ?, ?)
  `).run(guild.id, targetMember.id, author.id, cleanReason, Date.now());

  const totalWarns = sdb.prepare(`
    SELECT COUNT(*) as count FROM member_warnings WHERE guild_id = ? AND user_id = ?
  `).get(guild.id, targetMember.id)?.count || 1;

  // Log to mod_cases & audit log channel
  await logAction(guild, sdb, {
    emoji: '<a:tungsten_warn:1567246685082746940>',
    action: 'warn',
    targetId: targetMember.id,
    moderatorId: author.id,
    reason: cleanReason,
    extra: `Total Warnings: ${totalWarns}`
  });

  // Send DM to target
  try {
    await targetMember.send({
      embeds: [
        createEmbed({
          color: client.config.COLORS.WARNING,
          title: `<a:tungsten_warn:1567246685082746940> Warning Received in ${guild.name}`,
          description: `**Moderator:** ${author.username} (${author.id})\n**Reason:** ${cleanReason}\n**Total Warnings:** ${totalWarns}`
        })
      ]
    });
  } catch (_) {}

  let ladderDetails = '';
  const ladderResult = await checkAndExecuteLadder(guild, targetMember, totalWarns, client, author);
  if (ladderResult && ladderResult.triggered) {
    if (ladderResult.success) {
      ladderDetails = `\n\n⚡ **Automated Escalation:** User reached threshold \`${totalWarns}\` warnings → Executed **${ladderResult.action.toUpperCase()}**${ladderResult.durationStr ? ` (${ladderResult.durationStr})` : ''}.`;
    } else {
      ladderDetails = `\n\n<a:tungsten_warn:1567246685082746940> **Automated Escalation:** Threshold \`${totalWarns}\` warnings reached for **${ladderResult.action.toUpperCase()}**, but action could not be executed (${ladderResult.failureReason || 'insufficient bot permissions/hierarchy'}).`;
    }
  }

  return {
    success: true,
    embed: createEmbed({
      color: client.config.COLORS.SUCCESS,
      title: '<a:tungsten_warn:1567246685082746940> Member Warned',
      description: `Successfully warned **${targetMember.user?.username || targetMember.displayName}**.\n**Reason:** ${cleanReason}\n**Total Infractions:** \`${totalWarns}\`${ladderDetails}`
    })
  };
}

module.exports = {
  name: 'warn',
  description: 'Issue a formal warning to a server member.',
  permissions: ['ModerateMembers'],
  botPermissions: ['SendMessages','EmbedLinks'],
  category: 'moderation',
  usage: 'warn <@member|id> [reason]',
  aliases: ['w', 'warning'],
  cooldown: 3,

  slash: {
    name: 'warn',
    description: 'Issue a formal warning to a server member.',
    options: [
      {
        name: 'user',
        description: 'The member to warn (mention or ID)',
        type: 6, // USER
        required: true
      },
      {
        name: 'reason',
        description: 'Reason for the warning',
        type: 3, // STRING
        required: false
      }
    ]
  },

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    const targetUser = message.mentions?.members?.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : null);

    if (!targetUser) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.WARNING,
            title: 'Invalid Target',
            description: `**Usage:** \`${prefix}warn <@member|id> [reason]\``
          })
        ]
      });
    }

    const reason = args.slice(1).join(' ');
    const res = await handleWarn({
      guild: message.guild,
      member: message.member,
      author: message.author,
      targetMember: targetUser,
      reason,
      client
    });

    if (res.embed) return message.reply({ embeds: [res.embed] });
    if (res.error) return message.reply(res.error);
  },

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    let targetMember;
    try {
      targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
    } catch (_) {}

    const res = await handleWarn({
      guild: interaction.guild,
      member: interaction.member,
      author: interaction.user,
      targetMember,
      reason,
      client
    });

    if (res.embed) return interaction.reply({ embeds: [res.embed] });
    if (res.error) return interaction.reply({ content: res.error, ephemeral: true });
  },

  handleWarn
};
