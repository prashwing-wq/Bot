const { PermissionFlagsBits } = require('discord.js');
const { getPanelEmbed, buildCategorySelect, buildCategoryButtons } = require('./modpanel');
const { hasPerm } = require('../../utils/tools');

module.exports = {
  name: 'mutepanel',
  aliases: ['timeoutpanel', 'tp_mod'],
  category: 'moderation',
  description: 'Opens dedicated Timeout & Mute interactive moderation GUI panel',
  usage: '',
  cooldown: 3,
  permissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ModerateMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Moderate Members** permission to access the Mute Panel.');
    }
    const embed = getPanelEmbed('timeout', message.guild, message.author, client, prefix);
    const selectMenu = buildCategorySelect('timeout', message.author.id);
    const buttons = buildCategoryButtons('timeout', message.author.id);
    return message.reply({ embeds: [embed], components: [selectMenu, ...buttons] });
  }
};
