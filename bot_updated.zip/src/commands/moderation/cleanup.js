/**
 * Targeted Message Cleanup Command (Node.js)
 * High-speed targeted purge filtering by bots, links, embeds, images, text, or user.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'cleanup',
  aliases: ['clean', 'smartpurge', 'clearv2'],
  category: 'moderation',
  description: 'Clean targeted messages filtered by bots, links, embeds, images, or specific content.',
  permissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  usage: '[bots|links|embeds|images|contains <word>|user <@user>] <amount>',
  cooldown: 5,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageMessages)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Messages` permission to use cleanup.');
    }

    const type = args[0]?.toLowerCase();
    if (!type || !['bots', 'links', 'embeds', 'images', 'contains', 'user'].includes(type)) {
      return message.reply(
        `Usage:\n` +
        `• \`${prefix}cleanup bots [1-100]\` — Clean bot messages\n` +
        `• \`${prefix}cleanup links [1-100]\` — Clean links and URLs\n` +
        `• \`${prefix}cleanup embeds [1-100]\` — Clean embedded rich messages\n` +
        `• \`${prefix}cleanup images [1-100]\` — Clean attachments and image uploads\n` +
        `• \`${prefix}cleanup contains <word> [1-100]\` — Clean messages containing text\n` +
        `• \`${prefix}cleanup user <@user> [1-100]\` — Clean specific user messages`
      );
    }

    let limit = 50;
    let filterFn = null;

    if (type === 'bots') {
      limit = parseInt(args[1], 10) || 50;
      filterFn = m => m.author.bot;
    } else if (type === 'links') {
      limit = parseInt(args[1], 10) || 50;
      filterFn = m => /https?:\/\/[^\s]+/i.test(m.content);
    } else if (type === 'embeds') {
      limit = parseInt(args[1], 10) || 50;
      filterFn = m => m.embeds && m.embeds.length > 0;
    } else if (type === 'images') {
      limit = parseInt(args[1], 10) || 50;
      filterFn = m => m.attachments && m.attachments.size > 0;
    } else if (type === 'contains') {
      const query = args[1]?.toLowerCase();
      if (!query) return message.reply(`Usage: \`${prefix}cleanup contains <word> [1-100]\``);
      limit = parseInt(args[2], 10) || 50;
      filterFn = m => m.content.toLowerCase().includes(query);
    } else if (type === 'user') {
      const user = message.mentions?.users?.first() || (args[1] ? await client.users.fetch(args[1].replace(/[<@!>]/g, '')).catch(() => null) : null);
      if (!user) return message.reply(`Usage: \`${prefix}cleanup user @User [1-100]\``);
      limit = parseInt(args[2], 10) || 50;
      filterFn = m => m.author.id === user.id;
    }

    limit = Math.min(Math.max(1, limit), 100);

    try {
      const fetched = await message.channel.messages.fetch({ limit: 100 });
      const filtered = fetched.filter(filterFn).first(limit);

      if (filtered.length === 0) {
        return message.reply('🔍 No messages matched the requested cleanup filter.');
      }

      await message.channel.bulkDelete(filtered, true);

      const embed = createEmbed({
        color: 0x57F287,
        title: '🧹  Cleanup Completed',
        description: `> Successfully cleaned **${filtered.length} messages** matching filter: \`${type.toUpperCase()}\`.`
      });

      const reply = await message.channel.send({ embeds: [embed] });
      setTimeout(() => reply.delete().catch(() => {}), 5000);
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Cleanup error: ${e.message}`);
    }
  }
};
