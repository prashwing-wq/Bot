const { PermissionFlagsBits } = require('discord.js');
const { getPanelEmbed, buildCategorySelect, buildCategoryButtons } = require('./modpanel');
const { hasPerm } = require('../../utils/tools');

module.exports = {
  name: 'purgepanel',
  aliases: ['clearpanel', 'cleanpanel'],
  category: 'moderation',
  description: 'Opens dedicated Message Cleaner & Purge interactive moderation GUI panel',
  usage: '',
  cooldown: 3,
  permissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionFlagsBits.ManageMessages)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the **Manage Messages** permission to access the Purge Panel.');
    }
    const embed = getPanelEmbed('purge', message.guild, message.author, client, prefix);
    const selectMenu = buildCategorySelect('purge', message.author.id);
    const buttons = buildCategoryButtons('purge', message.author.id);
    return message.reply({ embeds: [embed], components: [selectMenu, ...buttons] });
  }
};
