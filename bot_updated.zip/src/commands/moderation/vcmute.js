/**
 * Voice Channel Mute Command (Node.js)
 * Server-mutes a member or all members in a voice channel.
 */
const { PermissionsBitField } = require('discord.js');
const { createEmbed, isOwner } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');

module.exports = {
  name: 'vcmute',
  aliases: ['vmute', 'voicemute'],
  category: 'moderation',
  description: 'Server-mute a member or all members in a voice channel.',
  usage: '<@member|id|all> [reason]',
  cooldown: 3,
  permissions: ['MuteMembers'],
  botPermissions: ['MuteMembers'],

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!args || args.length === 0) {
      return message.reply(`Usage: \`${prefix}vcmute <@member|id|all> [reason]\``);
    }

    const sub = args[0].toLowerCase();

    // Mass mute all members in current voice channel
    if (sub === 'all') {
      const voiceChannel = message.member?.voice?.channel;
      if (!voiceChannel) {
        return message.reply('<a:tungsten_close:1567234632905138206> You must be connected to a voice channel to mute all members.');
      }

      const members = voiceChannel.members
        ? Array.from(voiceChannel.members.values()).filter(m => m.id !== client.user?.id && m.id !== message.author.id)
        : [];

      let count = 0;
      for (const m of members) {
        try {
          await m.voice.setMute(true, `[vcmute all] Muted by ${message.author.tag}`);
          count++;
        } catch (e) {}
      }

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: '<a:tungsten_mute:1567241451992121647>',
          action: 'vcmute_all',
          targetId: message.guild.id,
          moderatorId: message.author.id,
          reason: `Mass voice mute in ${voiceChannel.name} (${count} members)`
        });
      } catch (_) {}

      return message.reply(`<a:tungsten_mute:1567241451992121647> Server-muted **${count} members** in ${voiceChannel}.`);
    }

    const cleanId = sub.replace(/[<@!>]/g, '');
    const targetMember = message.mentions?.members?.first()
      || message.guild.members?.cache?.get(cleanId)
      || (typeof message.guild.members?.fetch === 'function' ? await message.guild.members.fetch(cleanId).catch(() => null) : null);

    if (!targetMember) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Could not resolve \`${args[0]}\` to a valid member.`);
    }

    if (isOwner(targetMember.id)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice mute a Bot Owner.');
    }
    if (targetMember.id === message.guild.ownerId) {
      return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice mute the Server Owner.');
    }
    if (targetMember.id === client.user?.id) {
      return message.reply('<a:tungsten_close:1567234632905138206> I cannot voice mute myself.');
    }
    if (!isOwner(message.author.id) && message.author.id !== message.guild.ownerId) {
      if (message.member?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
        if (message.member.roles.highest.position <= targetMember.roles.highest.position) {
          return message.reply('<a:tungsten_close:1567234632905138206> You cannot voice mute this member because their highest role is equal to or higher than yours.');
        }
      }
    }
    if (message.guild.members.me?.roles?.highest?.position !== undefined && targetMember.roles?.highest?.position !== undefined) {
      if (message.guild.members.me.roles.highest.position <= targetMember.roles.highest.position) {
        return message.reply('<a:tungsten_close:1567234632905138206> I cannot voice mute this member because their highest role is higher than or equal to mine.');
      }
    }

    if (!targetMember.voice?.channel) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is not connected to any voice channel.`);
    }

    if (targetMember.voice.serverMute) {
      return message.reply(`<a:tungsten_close:1567234632905138206> **${targetMember.displayName || targetMember.user?.username}** is already server-muted.`);
    }

    const reason = args.slice(1).join(' ') || `Muted by ${message.author.tag}`;
    try {
      await targetMember.voice.setMute(true, reason);

      try {
        const sdb = getServerDb(message.guild.id);
        await logAction(message.guild, sdb, {
          emoji: '<a:tungsten_mute:1567241451992121647>',
          action: 'vcmute',
          targetId: targetMember.id,
          moderatorId: message.author.id,
          reason
        });
      } catch (_) {}

      const embed = createEmbed({
        color: 0xED4245,
        title: '<a:tungsten_mute:1567241451992121647> Member Voice Muted',
        description: `> Successfully server-muted <@${targetMember.id}> in **${targetMember.voice.channel.name}**.\n\n• **Reason:** ${reason}`
      });
      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to voice-mute member: ${err.message}`);
    }
  }
};
