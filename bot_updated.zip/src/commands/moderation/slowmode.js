/**
 * Slowmode Command
 * Set slowmode cooldown on the channel
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'slowmode',
  description: 'Set channel slowmode message rate limit in seconds.',
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  category: 'moderation',
  usage: 'slowmode <seconds|0|off>',
  aliases: ['sm'],
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.DANGER,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Manage Channels` permission to modify slowmode.'
          })
        ]
      });
    }

    if (!args[0]) {
      const current = message.channel.rateLimitPerUser || 0;
      return message.reply(`<a:tungsten_autoslow:1569329238585118783> Current slowmode for ${message.channel} is **${current}s**.`);
    }

    let seconds = 0;
    if (args[0].toLowerCase() !== 'off') {
      seconds = parseInt(args[0], 10);
      if (isNaN(seconds) || seconds < 0 || seconds > 21600) {
        return message.reply('<a:tungsten_warn:1567246685082746940> Please provide a valid number of seconds between `0` and `21600` (6 hours), or `off`.');
      }
    }

    try {
      await message.channel.setRateLimitPerUser(seconds, `Slowmode set by ${message.author.tag}`);
      return message.reply({
        embeds: [
          createEmbed({
            color: client.config.COLORS.SUCCESS,
            title: '<a:tungsten_autoslow:1569329238585118783> Slowmode Updated',
            description: seconds === 0
              ? `<a:tungsten_ui_toggle_off:1569329677187678368> Slowmode has been disabled for ${message.channel}.`
              : `<a:tungsten_ui_toggle_on:1569329685110849576> Slowmode for ${message.channel} has been set to **${seconds} second(s)**.`
          })
        ]
      });
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to set slowmode: ${e.message}`);
    }
  }
};
