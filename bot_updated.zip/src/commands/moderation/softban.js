/**
 * Softban Moderation Command (Node.js)
 * Bans and immediately unbans a member to cleanly purge their recent chat messages.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { getServerDb } = require('../../utils/serverDb');
const { logAction } = require('../../utils/modlog');

module.exports = {
  name: 'softban',
  category: 'moderation',
  description: 'Bans and immediately unbans a member to cleanly purge their messages without permanent ban.',
  permissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  usage: '<@user> [reason]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!hasPerm(message.member, PermissionsBitField.Flags.BanMembers)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Ban Members` permission to use softban.');
    }

    const target = message.mentions?.members?.first() || (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : null);
    if (!target) return message.reply(`Usage: \`${prefix}softban <@user> [reason]\``);

    // C10: Confused Deputy Limiter check
    const { checkModAction } = require('../../utils/modActionLimiter');
    const quota = await checkModAction(message.guild, message.author.id, 'ban');
    if (!quota.allowed) {
      return message.reply(`<a:tungsten_warn:1567246685082746940> **Action Rate Limit Exceeded:** You have reached the safe action quota for bans (${quota.limit} per window). Please wait **${quota.remainingTime}s** before banning again.`);
    }

    if (!target.bannable) {
      return message.reply('<a:tungsten_close:1567234632905138206> I cannot softban this user due to role hierarchy.');
    }

    const reason = args.slice(1).join(' ') || 'No reason provided';
    const auditReason = `[Softban by ${message.author.username}] ${reason}`;

    try {
      await target.ban({ deleteMessageSeconds: 604800, reason: auditReason }); // Purge 7 days of messages
      await message.guild.bans.remove(target.id, `[Softban Reversal] ${auditReason}`);

      const sdb = getServerDb(message.guild.id);
      await logAction(message.guild, sdb, {
        emoji: '<a:tungsten_shield:1567242104923627574>',
        action: 'softban',
        targetId: target.id,
        moderatorId: message.author.id,
        reason,
        extra: 'Purged 7 days of messages'
      });

      const embed = createEmbed({
        color: 0x57F287,
        title: '<a:tungsten_shield:1567242104923627574> Member Softbanned',
        description:
          `> <@${target.id}> (\`${target.user?.username || target.displayName}\`) was successfully softbanned.\n\n` +
          `• **Action:** Banned & Unbanned *(Purged 7 days of messages)*\n` +
          `• **Moderator:** ${message.author}\n` +
          `• **Reason:** ${reason}`
      });

      return message.reply({ embeds: [embed] });
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to softban user: ${e.message}`);
    }
  }
};
