/**
 * Command Overrides Management (Node.js)
 * Enables guild administrators to customize per-command allow/deny overrides
 * for roles, channels, and users.
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const {
  setOverride,
  clearOverrides,
  getAllOverrides,
  getOverrides,
  isOwnerCommand
} = require('../../utils/commandOverrides');
const { createEmbed, hasPerm } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'override',
  aliases: ['overrides', 'cmdoverride'],
  category: 'moderation',
  description: 'Manage guild-level permission overrides for bot commands',
  usage: '<set|clear|list> [command] [allow|deny] [@role|#channel|@user]',
  cooldown: 3,
  permissions: ['Administrator'],
  botPermissions: [],

  async execute(message, args, client, prefix) {
    if (!message.guild) return;
    if (!hasPerm(message.member, 'Administrator')) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You require **Administrator** permission to manage command overrides.'
          })
        ]
      });
    }

    const sub = (args[0] || 'list').toLowerCase();
    const gid = message.guild.id;

    // Subcommand: LIST
    if (sub === 'list') {
      const targetCmd = args[1]?.toLowerCase();
      const overrides = targetCmd ? getOverrides(gid, targetCmd) : getAllOverrides(gid);

      if (!overrides || overrides.length === 0) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0x3498DB,
              title: '<a:tungsten_override:1569329487794143305> Command Overrides',
              description: targetCmd
                ? `<a:tungsten_info:1567240890748248084> No active overrides found for command \`${targetCmd}\`.`
                : '<a:tungsten_info:1567240890748248084> No active command overrides configured in this server.'
            })
          ]
        });
      }

      const lines = overrides.slice(0, 25).map(o => {
        let targetLabel = `<@${o.target_id}>`;
        if (o.target_type === 'role') targetLabel = `<@&${o.target_id}>`;
        else if (o.target_type === 'channel') targetLabel = `<#${o.target_id}>`;
        const badge = o.type === 'allow'
          ? '<a:tungsten_ui_toggle_on:1569329685110849576> ALLOW'
          : '<a:tungsten_ui_toggle_off:1569329677187678368> DENY';
        return `• \`${o.command}\` | **${badge}** | ${targetLabel} (\`${o.target_type}\`)`;
      });

      const card = createV2Card({
        color: 0x5865F2,
        title: '<a:tungsten_override:1569329487794143305> Server Command Overrides',
        description: `Active overrides in **${message.guild.name}**:\n\n${lines.join('\n')}`,
        footerText: `Total overrides: ${overrides.length}`
      });

      return message.reply({ embeds: [card] });
    }

    // Subcommand: CLEAR
    if (sub === 'clear') {
      const cmdName = args[1]?.toLowerCase();
      if (!cmdName) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xF1C40F,
              title: 'Invalid Command',
              description: `<a:tungsten_warn:1567246685082746940> Please specify a command to clear.\n**Usage:** \`${prefix}override clear <command>\``
            })
          ]
        });
      }

      if (isOwnerCommand(cmdName, client)) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              title: 'Action Prohibited',
              description: `<a:tungsten_close:1567234632905138206> Bot owner command \`${cmdName}\` cannot be overridden.`
            })
          ]
        });
      }

      const count = clearOverrides(gid, cmdName);
      return message.reply({
        embeds: [
          createEmbed({
            color: 0x2ECC71,
            title: 'Overrides Cleared',
            description: `<a:tungsten_success:1567242523468890274> Cleared **${count}** override(s) for command \`${cmdName}\`.`
          })
        ]
      });
    }

    // Subcommand: SET
    if (sub === 'set') {
      const cmdName = args[1]?.toLowerCase();
      const type = args[2]?.toLowerCase();
      const rawTarget = args[3];

      if (!cmdName || !['allow', 'deny'].includes(type) || !rawTarget) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xF1C40F,
              title: 'Invalid Parameters',
              description: `<a:tungsten_warn:1567246685082746940> **Usage:** \`${prefix}override set <command> <allow|deny> <@role|#channel|@user>\``
            })
          ]
        });
      }

      if (isOwnerCommand(cmdName, client)) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              title: 'Action Prohibited',
              description: `<a:tungsten_close:1567234632905138206> Bot owner command \`${cmdName}\` cannot be overridden.`
            })
          ]
        });
      }

      let targetType = null;
      let targetId = null;

      if (message.mentions.channels.first()) {
        targetType = 'channel';
        targetId = message.mentions.channels.first().id;
      } else if (message.mentions.roles.first()) {
        targetType = 'role';
        targetId = message.mentions.roles.first().id;
      } else if (message.mentions.users.first()) {
        targetType = 'user';
        targetId = message.mentions.users.first().id;
      } else {
        const idMatch = rawTarget.match(/^(\d{15,21})$/);
        if (idMatch) {
          targetId = idMatch[1];
          if (message.guild.channels.cache.has(targetId)) targetType = 'channel';
          else if (message.guild.roles.cache.has(targetId)) targetType = 'role';
          else targetType = 'user';
        }
      }

      if (!targetType || !targetId) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xF1C40F,
              title: 'Invalid Target',
              description: '<a:tungsten_warn:1567246685082746940> Could not resolve target role, channel, or user.'
            })
          ]
        });
      }

      try {
        setOverride(gid, cmdName, type, targetType, targetId);
        const badge = type === 'allow'
          ? '<a:tungsten_ui_toggle_on:1569329685110849576> ALLOW'
          : '<a:tungsten_ui_toggle_off:1569329677187678368> DENY';
        return message.reply({
          embeds: [
            createEmbed({
              color: 0x2ECC71,
              title: 'Override Updated',
              description: `<a:tungsten_success:1567242523468890274> Set **${badge}** override for \`${cmdName}\` targeting \`${targetType}\` (\`${targetId}\`).`
            })
          ]
        });
      } catch (err) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xED4245,
              title: 'Override Failed',
              description: `<a:tungsten_close:1567234632905138206> ${err.message}`
            })
          ]
        });
      }
    }

    return message.reply({
      embeds: [
        createEmbed({
          color: 0xF1C40F,
          title: '<a:tungsten_override:1569329487794143305> Unknown Subcommand',
          description: `**Usage:**\n• \`${prefix}override list [command]\`\n• \`${prefix}override set <command> <allow|deny> <@target>\`\n• \`${prefix}override clear <command>\``
        })
      ]
    });
  }
};
