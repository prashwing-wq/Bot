/**
 * Nickname Command (Node.js)
 * Change or reset a member's nickname in the server.
 */
const { PermissionsBitField } = require('discord.js');
const { hasPerm, createEmbed } = require('../../utils/tools');

module.exports = {
  name: 'nick',
  aliases: ['setnick', 'nickname'],
  category: 'moderation',
  description: "Change or reset a server member's nickname.",
  permissions: ['ManageNicknames'],
  botPermissions: ['ManageNicknames'],
  usage: '<@member|id> [new_nickname]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return message.reply('This command can only be used in a server.');

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageNicknames)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.DANGER || 0xED4245,
            title: 'Permission Denied',
            description: 'You need the `Manage Nicknames` permission to change member nicknames.'
          })
        ]
      });
    }

    if (!args[0]) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}nick <@member|id> [new_nickname]\`\nLeave nickname empty to reset to original.`);
    }

    const member = message.mentions?.members?.first() ||
      await message.guild.members.fetch(args[0]).catch(() => null);

    if (!member) {
      return message.reply('<a:tungsten_close:1567234632905138206> Member not found. Please provide a valid mention or member ID.');
    }

    // Hierarchy check: cannot edit owner or member with higher/equal role
    if (member.id === message.guild.ownerId) {
      return message.reply("<a:tungsten_close:1567234632905138206> Cannot change the Server Owner's nickname.");
    }

    const me = message.guild.members.me;
    if (member.roles.highest.position >= me.roles.highest.position && member.id !== me.id) {
      return message.reply(`<a:tungsten_close:1567234632905138206> I cannot change **${member.user.username}**'s nickname because their highest role is equal to or higher than mine.`);
    }

    if (member.roles.highest.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
      return message.reply(`<a:tungsten_close:1567234632905138206> You cannot change **${member.user.username}**'s nickname because their highest role is equal to or higher than yours.`);
    }

    const newNick = args.slice(1).join(' ').trim();

    try {
      if (!newNick || newNick.toLowerCase() === 'reset' || newNick.toLowerCase() === 'none') {
        await member.setNickname(null, `Nickname reset by ${message.author.tag}`);
        return message.reply({
          embeds: [
            createEmbed({
              color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
              title: '<a:tungsten_success:1567242523468890274> Nickname Reset',
              description: `Successfully reset nickname for **${member.user.username}**.`
            })
          ]
        });
      }

      if (newNick.length > 32) {
        return message.reply('<a:tungsten_close:1567234632905138206> Nickname must be 32 characters or fewer.');
      }

      const oldNick = member.displayName;
      await member.setNickname(newNick, `Nickname changed by ${message.author.tag}`);

      return message.reply({
        embeds: [
          createEmbed({
            color: client?.config?.COLORS?.SUCCESS || 0x2ecc71,
            title: '<a:tungsten_success:1567242523468890274> Nickname Changed',
            description: `Successfully changed nickname for **${member.user.username}**:\n` +
              `• **Before:** \`${oldNick}\`\n` +
              `• **After:** \`${newNick}\``
          })
        ]
      });
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to change nickname: ${e.message}`);
    }
  }
};
