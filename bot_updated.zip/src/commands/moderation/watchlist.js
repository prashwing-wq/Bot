/**
 * Surveillance Watchlist Command (Node.js)
 * Enables staff to flag, monitor, and query suspicious accounts under guild surveillance.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const {
  addToWatchlist,
  removeFromWatchlist,
  getWatchlist,
  getWatchlistEntry,
  getServerDb
} = require('../../utils/serverDb');
const { hasPerm, createEmbed } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');
const { logAction } = require('../../utils/modlog');

function extractUserId(arg) {
  if (!arg) return null;
  const match = String(arg).trim().match(/^<@!?(\d+)>$/) || String(arg).trim().match(/^(\d{15,21})$/);
  return match ? match[1] : null;
}

module.exports = {
  name: 'watchlist',
  aliases: ['watch', 'surveillance'],
  category: 'moderation',
  description: 'Surveillance watchlist to track suspicious members and monitor member activity',
  usage: '<add|remove|list|check> [@user|id] [reason]',
  cooldown: 3,
  permissions: ['ModerateMembers'],
  botPermissions: ['ViewAuditLog'],

  slash: new SlashCommandBuilder()
    .setName('watchlist')
    .setDescription('Surveillance watchlist to track suspicious members and monitor member activity')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Add a user to the surveillance watchlist')
        .addUserOption(opt => opt.setName('user').setDescription('User to place on watchlist').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for surveillance').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a user from the surveillance watchlist')
        .addUserOption(opt => opt.setName('user').setDescription('User to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('check')
        .setDescription('Check if a user is on the surveillance watchlist')
        .addUserOption(opt => opt.setName('user').setDescription('User to check').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all users on the surveillance watchlist')
        .addIntegerOption(opt => opt.setName('page').setDescription('Page number').setMinValue(1))
    ),

  async execute(message, args, client, prefix) {
    if (!message.guild) {
      return message.reply('<a:tungsten_close:1567234632905138206> This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.ModerateMembers)) {
      return message.reply({
        embeds: [
          createEmbed({
            color: 0xED4245,
            title: 'Permission Denied',
            description: '<a:tungsten_close:1567234632905138206> You need the `Moderate Members` permission to use the watchlist.'
          })
        ]
      });
    }

    const sub = (args[0] || '').toLowerCase();
    const gid = message.guild.id;

    // Subcommand: ADD
    if (sub === 'add') {
      const rawTarget = args[1];
      const targetId = message.mentions?.users?.first()?.id || extractUserId(rawTarget);
      if (!targetId) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xF1C40F,
              title: 'Invalid Target',
              description: `<a:tungsten_warn:1567246685082746940> Please specify a valid user mention or ID.\n**Usage:** \`${prefix}watchlist add <@user|id> [reason]\``
            })
          ]
        });
      }

      const reason = args.slice(2).join(' ').trim() || 'Suspicious behavior / Under surveillance';
      const entry = addToWatchlist(gid, targetId, reason, message.author.id);

      // Audit Modlog if available
      try {
        const sdb = getServerDb(gid);
        await logAction(message.guild, sdb, {
          emoji: '<a:tungsten_watchlist:1569329733303541801>',
          action: 'watchlist_add',
          targetId,
          moderatorId: message.author.id,
          reason,
          extra: 'Added to surveillance watchlist'
        });
      } catch (_) {}

      const card = createV2Card({
        color: 0xF1C40F,
        title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist • Member Added',
        description:
          `User <@${targetId}> has been registered on the server surveillance watchlist.\n\n` +
          `**Target:** <@${targetId}> (\`${targetId}\`)\n` +
          `**Reason:** ${entry.reason}\n` +
          `**Added By:** <@${message.author.id}> (\`${message.author.id}\`)\n` +
          `**Timestamp:** <t:${entry.added_at}:f> (<t:${entry.added_at}:R>)`,
        footerText: 'Tungsten Surveillance • Guild Watchlist'
      });

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [card], components: [buttons] });
    }

    // Subcommand: REMOVE
    if (sub === 'remove' || sub === 'delete' || sub === 'del') {
      const rawTarget = args[1];
      const targetId = message.mentions?.users?.first()?.id || extractUserId(rawTarget);
      if (!targetId) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0xF1C40F,
              title: 'Invalid Target',
              description: `<a:tungsten_warn:1567246685082746940> Please specify a valid user mention or ID.\n**Usage:** \`${prefix}watchlist remove <@user|id>\``
            })
          ]
        });
      }

      const existing = getWatchlistEntry(gid, targetId);
      if (!existing) {
        return message.reply({
          embeds: [
            createEmbed({
              color: 0x3498DB,
              title: 'Not Watchlisted',
              description: `<a:tungsten_info:1567240890748248084> User <@${targetId}> (\`${targetId}\`) is not on the surveillance watchlist.`
            })
          ]
        });
      }

      removeFromWatchlist(gid, targetId);

      // Audit Modlog if available
      try {
        const sdb = getServerDb(gid);
        await logAction(message.guild, sdb, {
          emoji: '<a:tungsten_watchlist:1569329733303541801>',
          action: 'watchlist_remove',
          targetId,
          moderatorId: message.author.id,
          reason: 'Removed from surveillance',
          extra: `Prior Reason: ${existing.reason}`
        });
      } catch (_) {}

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist • Member Removed',
        description:
          `User <@${targetId}> has been removed from the surveillance watchlist.\n\n` +
          `**Target:** <@${targetId}> (\`${targetId}\`)\n` +
          `**Removed By:** <@${message.author.id}>\n` +
          `**Prior Reason:** ${existing.reason}`,
        footerText: 'Tungsten Surveillance • Guild Watchlist'
      });

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [card], components: [buttons] });
    }

    // Subcommand: CHECK
    if (sub === 'check' || sub === 'info' || sub === 'status') {
      const rawTarget = args[1];
      const targetId = message.mentions?.users?.first()?.id || extractUserId(rawTarget) || message.author.id;
      const entry = getWatchlistEntry(gid, targetId);

      if (entry) {
        const card = createV2Card({
          color: 0xED4245,
          title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist Status',
          description:
            `**Target:** <@${targetId}> (\`${targetId}\`)\n` +
            `**Status:** <a:tungsten_ui_toggle_off:1569329677187678368> **UNDER ACTIVE SURVEILLANCE**\n\n` +
            `**Reason:** ${entry.reason}\n` +
            `**Added By:** <@${entry.added_by}> (\`${entry.added_by}\`)\n` +
            `**Watchlisted Since:** <t:${entry.added_at}:f> (<t:${entry.added_at}:R>)`,
          footerText: 'Tungsten Surveillance • Guild Watchlist'
        });

        const buttons = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_trash:1567242891276062872>')
        );

        return message.reply({ embeds: [card], components: [buttons] });
      }

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist Status',
        description:
          `**Target:** <@${targetId}> (\`${targetId}\`)\n` +
          `**Status:** <a:tungsten_ui_toggle_on:1569329685110849576> **CLEAN** (Not listed on the surveillance watchlist)`,
        footerText: 'Tungsten Surveillance • Guild Watchlist'
      });

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [card], components: [buttons] });
    }

    // Subcommand: LIST
    if (sub === 'list' || sub === 'all' || sub === 'show') {
      const list = getWatchlist(gid);

      if (!list || list.length === 0) {
        const card = createV2Card({
          color: 0x3498DB,
          title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist',
          description: '*The guild surveillance watchlist is currently empty.*',
          footerText: 'Tungsten Surveillance • 0 Tracked Members'
        });

        const buttons = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_trash:1567242891276062872>')
        );

        return message.reply({ embeds: [card], components: [buttons] });
      }

      const pageArg = parseInt(args[1], 10);
      const page = isNaN(pageArg) || pageArg < 1 ? 1 : pageArg;
      const pageSize = 8;
      const totalPages = Math.ceil(list.length / pageSize) || 1;
      const curPage = Math.min(page, totalPages);
      const start = (curPage - 1) * pageSize;
      const items = list.slice(start, start + pageSize);

      const formatted = items.map((e, idx) => {
        return `\`${start + idx + 1}.\` <@${e.user_id}> (\`${e.user_id}\`)\n` +
               `> **Reason:** ${e.reason}\n` +
               `> **Added By:** <@${e.added_by}> • <t:${e.added_at}:R>`;
      }).join('\n\n');

      const card = createV2Card({
        color: 0xE67E22,
        title: `<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist • Page ${curPage}/${totalPages}`,
        description:
          `**Total Tracked Members:** \`${list.length}\`\n\n` +
          formatted,
        footerText: `Tungsten Surveillance • Use ${prefix}watchlist list <page> for other pages`
      });

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_trash:1567242891276062872>')
      );

      return message.reply({ embeds: [card], components: [buttons] });
    }

    // Default: Help Menu
    const card = createV2Card({
      color: 0x5865F2,
      title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist Matrix',
      description:
        `Track suspicious members, monitor prospective raid/nuke actors, and record behavioral flags.\n\n` +
        `### Available Subcommands:\n` +
        `• \`${prefix}watchlist add <@user|id> [reason]\` — Add a member to active surveillance.\n` +
        `• \`${prefix}watchlist remove <@user|id>\` — Remove a member from the watchlist.\n` +
        `• \`${prefix}watchlist check <@user|id>\` — Check whether a member is on the watchlist.\n` +
        `• \`${prefix}watchlist list [page]\` — List all members currently on surveillance.`,
      footerText: 'Tungsten Surveillance • Permissions: Moderate Members'
    });

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('cmd_dismiss').setLabel('Dismiss').setStyle(ButtonStyle.Secondary).setEmoji('<a:tungsten_trash:1567242891276062872>')
    );

    return message.reply({ embeds: [card], components: [buttons] });
  },

  async executeSlash(interaction, client) {
    if (!interaction.guild) {
      return interaction.reply({ content: '<a:tungsten_close:1567234632905138206> This command can only be used in a server.', ephemeral: true });
    }

    if (!hasPerm(interaction.member, PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({
        content: '<a:tungsten_close:1567234632905138206> You need the `Moderate Members` permission to use the watchlist.',
        ephemeral: true
      });
    }

    const sub = interaction.options.getSubcommand();
    const gid = interaction.guild.id;

    if (sub === 'add') {
      const targetUser = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || 'Suspicious behavior / Under surveillance';
      const entry = addToWatchlist(gid, targetUser.id, reason, interaction.user.id);

      try {
        const sdb = getServerDb(gid);
        await logAction(interaction.guild, sdb, {
          emoji: '<a:tungsten_watchlist:1569329733303541801>',
          action: 'watchlist_add',
          targetId: targetUser.id,
          moderatorId: interaction.user.id,
          reason,
          extra: 'Added to surveillance watchlist'
        });
      } catch (_) {}

      const card = createV2Card({
        color: 0xF1C40F,
        title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist • Member Added',
        description:
          `User <@${targetUser.id}> has been registered on the server surveillance watchlist.\n\n` +
          `**Target:** <@${targetUser.id}> (\`${targetUser.id}\`)\n` +
          `**Reason:** ${entry.reason}\n` +
          `**Added By:** <@${interaction.user.id}>\n` +
          `**Timestamp:** <t:${entry.added_at}:f> (<t:${entry.added_at}:R>)`,
        footerText: 'Tungsten Surveillance • Guild Watchlist'
      });

      return interaction.reply({ embeds: [card] });
    }

    if (sub === 'remove') {
      const targetUser = interaction.options.getUser('user', true);
      const existing = getWatchlistEntry(gid, targetUser.id);

      if (!existing) {
        return interaction.reply({
          content: `<a:tungsten_info:1567240890748248084> User <@${targetUser.id}> is not on the surveillance watchlist.`,
          ephemeral: true
        });
      }

      removeFromWatchlist(gid, targetUser.id);

      try {
        const sdb = getServerDb(gid);
        await logAction(interaction.guild, sdb, {
          emoji: '<a:tungsten_watchlist:1569329733303541801>',
          action: 'watchlist_remove',
          targetId: targetUser.id,
          moderatorId: interaction.user.id,
          reason: 'Removed from surveillance',
          extra: `Prior Reason: ${existing.reason}`
        });
      } catch (_) {}

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist • Member Removed',
        description:
          `User <@${targetUser.id}> has been removed from the surveillance watchlist.\n\n` +
          `**Target:** <@${targetUser.id}> (\`${targetUser.id}\`)\n` +
          `**Removed By:** <@${interaction.user.id}>\n` +
          `**Prior Reason:** ${existing.reason}`,
        footerText: 'Tungsten Surveillance • Guild Watchlist'
      });

      return interaction.reply({ embeds: [card] });
    }

    if (sub === 'check') {
      const targetUser = interaction.options.getUser('user', true);
      const entry = getWatchlistEntry(gid, targetUser.id);

      if (entry) {
        const card = createV2Card({
          color: 0xED4245,
          title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist Status',
          description:
            `**Target:** <@${targetUser.id}> (\`${targetUser.id}\`)\n` +
            `**Status:** <a:tungsten_ui_toggle_off:1569329677187678368> **UNDER ACTIVE SURVEILLANCE**\n\n` +
            `**Reason:** ${entry.reason}\n` +
            `**Added By:** <@${entry.added_by}> (\`${entry.added_by}\`)\n` +
            `**Watchlisted Since:** <t:${entry.added_at}:f> (<t:${entry.added_at}:R>)`,
          footerText: 'Tungsten Surveillance • Guild Watchlist'
        });
        return interaction.reply({ embeds: [card] });
      }

      const card = createV2Card({
        color: 0x2ECC71,
        title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist Status',
        description:
          `**Target:** <@${targetUser.id}> (\`${targetUser.id}\`)\n` +
          `**Status:** <a:tungsten_ui_toggle_on:1569329685110849576> **CLEAN** (Not listed on the surveillance watchlist)`,
        footerText: 'Tungsten Surveillance • Guild Watchlist'
      });
      return interaction.reply({ embeds: [card] });
    }

    if (sub === 'list') {
      const list = getWatchlist(gid);

      if (!list || list.length === 0) {
        const card = createV2Card({
          color: 0x3498DB,
          title: '<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist',
          description: '*The guild surveillance watchlist is currently empty.*',
          footerText: 'Tungsten Surveillance • 0 Tracked Members'
        });
        return interaction.reply({ embeds: [card] });
      }

      const page = interaction.options.getInteger('page') || 1;
      const pageSize = 8;
      const totalPages = Math.ceil(list.length / pageSize) || 1;
      const curPage = Math.min(page, totalPages);
      const start = (curPage - 1) * pageSize;
      const items = list.slice(start, start + pageSize);

      const formatted = items.map((e, idx) => {
        return `\`${start + idx + 1}.\` <@${e.user_id}> (\`${e.user_id}\`)\n` +
               `> **Reason:** ${e.reason}\n` +
               `> **Added By:** <@${e.added_by}> • <t:${e.added_at}:R>`;
      }).join('\n\n');

      const card = createV2Card({
        color: 0xE67E22,
        title: `<a:tungsten_watchlist:1569329733303541801> Surveillance Watchlist • Page ${curPage}/${totalPages}`,
        description:
          `**Total Tracked Members:** \`${list.length}\`\n\n` +
          formatted,
        footerText: `Tungsten Surveillance • Total: ${list.length}`
      });

      return interaction.reply({ embeds: [card] });
    }
  }
};
