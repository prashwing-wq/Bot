/**
 * Forum Management Command (Node.js)
 * Manage Discord forum channels: create posts, inspect tags, and configure guidelines.
 */
const { ChannelType, PermissionFlagsBits } = require('discord.js');
const { hasPerm } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

function resolveTargetForum(message, arg) {
  if (arg && message.guild?.channels?.cache) {
    const match = arg.match(/^<#(\d+)>$/);
    const id = match ? match[1] : (arg.match(/^\d{17,20}$/) ? arg : null);
    if (id) {
      const ch = message.guild.channels.cache.get(id);
      if (ch && (ch.type === ChannelType.GuildForum || ch.type === 15)) {
        return ch;
      }
    }
  }
  if (message.mentions?.channels?.size > 0) {
    const mentioned = message.mentions.channels.first();
    if (mentioned && (mentioned.type === ChannelType.GuildForum || mentioned.type === 15)) {
      return mentioned;
    }
  }
  if (message.channel && (message.channel.type === ChannelType.GuildForum || message.channel.type === 15)) {
    return message.channel;
  }
  return null;
}

module.exports = {
  name: 'forum',
  aliases: ['forums', 'forumchannel'],
  category: 'channels',
  description: 'Manage Discord forum channels: create posts, inspect tags, and configure guidelines.',
  usage: '<post|tags|guidelines> [options]',
  cooldown: 3,
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels', 'SendMessages'],

  async execute(message, args, client, prefix = '!') {
    if (!message.guild) {
      return message.reply('<a:tungsten_close:1567234632905138206> This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the `Manage Channels` permission to use this command.');
    }

    const sub = (args[0] || '').toLowerCase();

    // 1. Create Forum Post
    if (sub === 'post') {
      const targetForum = resolveTargetForum(message, args[1]);
      if (!targetForum) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid Discord Forum channel (e.g. \`${prefix}forum post #forum <title> <message>\`).`);
      }

      let tokens = [];
      if (args[1] && resolveTargetForum(message, args[1])) {
        tokens = args.slice(2);
      } else {
        tokens = args.slice(1).filter(t => t !== `<#${targetForum.id}>`);
      }

      if (tokens.length === 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please provide a title and starter message.\nUsage: \`${prefix}forum post <#forum> "Post Title" Starter message\` or \`${prefix}forum post <#forum> Post Title | Starter message\``);
      }

      const rawText = tokens.join(' ').trim();
      let title = '';
      let content = '';

      if (rawText.includes('|')) {
        const parts = rawText.split('|');
        title = parts[0].trim();
        content = parts.slice(1).join('|').trim();
      } else if (/^["']([^"']+)["']\s+([\s\S]+)$/.test(rawText)) {
        const match = rawText.match(/^["']([^"']+)["']\s+([\s\S]+)$/);
        title = match[1].trim();
        content = match[2].trim();
      } else {
        title = tokens[0].trim();
        content = tokens.slice(1).join(' ').trim();
      }

      if (!title || title.length < 1 || title.length > 100) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please provide a post title between 1 and 100 characters.');
      }

      if (!content || content.length < 1 || content.length > 2000) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please provide a starter message body between 1 and 2000 characters.');
      }

      try {
        const post = await targetForum.threads.create({
          name: title,
          message: {
            content: content
          },
          reason: `Forum post created by ${message.author.tag || message.author.username} (${message.author.id})`
        });

        const card = createV2Card({
          color: 0x5865F2,
          title: '<a:tungsten_forum:1569329396278370374> Forum Post Created Successfully',
          description:
            `> New forum post <#${post.id}> has been published in <#${targetForum.id}>.\n\n` +
            `• **Post:** <#${post.id}> (\`${post.name}\`)\n` +
            `• **Forum Channel:** <#${targetForum.id}> (\`${targetForum.name}\`)\n` +
            `• **Author:** <@${message.author.id}>\n\n` +
            `**Starter Message:**\n` +
            `> ${content.length > 160 ? content.slice(0, 157) + '...' : content}`,
          footerText: `Tungsten Forum Manager • ${message.guild.name}`
        });

        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create forum post: ${err.message}`);
      }
    }

    // 2. View Forum Tags
    if (sub === 'tags') {
      const targetForum = resolveTargetForum(message, args[1]);
      if (!targetForum) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid Discord Forum channel (e.g. \`${prefix}forum tags #forum\`).`);
      }

      const tags = targetForum.availableTags || [];
      if (tags.length === 0) {
        const card = createV2Card({
          color: 0x5865F2,
          title: `<a:tungsten_forum:1569329396278370374> Tags: #${targetForum.name}`,
          description:
            `> No tags are currently configured for <#${targetForum.id}>.\n\n` +
            `-# Configure forum tags in Discord Channel Settings > Forum Tags.`,
          footerText: `Tungsten Forum Manager • ${message.guild.name}`
        });
        return message.reply({ embeds: [card] });
      }

      const tagList = tags.map(tag => {
        const emojiStr = tag.emoji ? (tag.emoji.name || (tag.emoji.id ? `custom:${tag.emoji.id}` : '')) : '';
        const access = tag.moderated ? '<a:tungsten_shield:1567242104923627574> *(Staff Moderated)*' : '*(Everyone)*';
        return `• ${emojiStr ? emojiStr + ' ' : ''}**${tag.name}** — ID: \`${tag.id}\` ${access}`;
      }).join('\n');

      const card = createV2Card({
        color: 0x5865F2,
        title: `<a:tungsten_forum:1569329396278370374> Configured Tags: #${targetForum.name} (${tags.length} Total)`,
        description:
          `> Available tags for posts created in <#${targetForum.id}>:\n\n` +
          `${tagList}`,
        footerText: `Tungsten Forum Manager • ${message.guild.name}`
      });

      return message.reply({ embeds: [card] });
    }

    // 3. View / Configure Forum Guidelines
    if (sub === 'guidelines') {
      const targetForum = resolveTargetForum(message, args[1]);
      if (!targetForum) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid Discord Forum channel (e.g. \`${prefix}forum guidelines #forum [text]\`).`);
      }

      let text = '';
      if (args[1] && resolveTargetForum(message, args[1])) {
        text = args.slice(2).join(' ').trim();
      } else {
        text = args.slice(1).filter(t => t !== `<#${targetForum.id}>`).join(' ').trim();
      }

      // View guidelines if no text provided
      if (!text) {
        const currentTopic = targetForum.topic;
        if (!currentTopic || currentTopic.trim().length === 0) {
          return message.reply(`<a:tungsten_info:1567240890748248084> No post guidelines configured for <#${targetForum.id}>.`);
        }

        const card = createV2Card({
          color: 0x5865F2,
          title: `<a:tungsten_forum:1569329396278370374> Post Guidelines: #${targetForum.name}`,
          description:
            `> Guidelines displayed to members when creating posts in <#${targetForum.id}>:\n\n` +
            `${currentTopic}`,
          footerText: `Tungsten Forum Manager • ${message.guild.name}`
        });
        return message.reply({ embeds: [card] });
      }

      // Clear guidelines
      if (['clear', 'reset', 'none', 'remove'].includes(text.toLowerCase())) {
        try {
          await targetForum.setTopic('', `Guidelines cleared by ${message.author.tag || message.author.username}`);
          const card = createV2Card({
            color: 0xFEE75C,
            title: `<a:tungsten_forum:1569329396278370374> Post Guidelines Cleared: #${targetForum.name}`,
            description: `> Successfully cleared post guidelines for <#${targetForum.id}>.`,
            footerText: `Tungsten Forum Manager • ${message.guild.name}`
          });
          return message.reply({ embeds: [card] });
        } catch (err) {
          return message.reply(`<a:tungsten_close:1567234632905138206> Failed to clear guidelines: ${err.message}`);
        }
      }

      if (text.length > 4096) {
        return message.reply('<a:tungsten_close:1567234632905138206> Post guidelines cannot exceed 4096 characters.');
      }

      // Update guidelines
      try {
        await targetForum.setTopic(text, `Guidelines updated by ${message.author.tag || message.author.username}`);
        const card = createV2Card({
          color: 0x57F287,
          title: `<a:tungsten_forum:1569329396278370374> Post Guidelines Updated: #${targetForum.name}`,
          description:
            `> Successfully updated post guidelines for <#${targetForum.id}>.\n\n` +
            `**New Guidelines:**\n` +
            `> ${text.length > 250 ? text.slice(0, 247) + '...' : text}`,
          footerText: `Tungsten Forum Manager • ${message.guild.name}`
        });
        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to update guidelines: ${err.message}`);
      }
    }

    // Default Overview / Help Card
    const overviewCard = createV2Card({
      color: 0x5865F2,
      title: '<a:tungsten_forum:1569329396278370374> Tungsten Forum Management Suite',
      description:
        `Manage Discord forum channels, publish starter posts, inspect tags, and update guidelines.\n\n` +
        `• \`${prefix}forum post <#forum> <title> <message>\`\n` +
        `  *Create a new forum post/thread with a starter message body.*\n` +
        `  *Tip: Use quotes \`"Title"\` or pipe \`Title | Message\` for multi-word titles.*\n\n` +
        `• \`${prefix}forum tags <#forum>\`\n` +
        `  *Inspect all configured tags, IDs, and moderation requirements.*\n\n` +
        `• \`${prefix}forum guidelines <#forum> [text]\`\n` +
        `  *View or configure the post guidelines topic displayed to post creators.*\n` +
        `  *Use \`clear\` as text to reset guidelines to empty.*`,
      footerText: `Tungsten Channel Suite • ${message.guild.name}`
    });

    return message.reply({ embeds: [overviewCard] });
  }
};
