/**
 * Channel Information Command (Node.js)
 * Displays technical metadata, permissions, and settings for a channel.
 */
const { createEmbed } = require('../../utils/tools');

module.exports = {
  permissions: [],
  botPermissions: ['SendMessages','EmbedLinks'],
  name: 'channelinfo',
  aliases: ['ci', 'cinfo'],
  category: ['channels', 'utility'],
  description: 'View detailed configuration, topic, and permissions for a channel.',
  usage: '[#channel]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    const channel = message.mentions?.channels?.first() || (args[0] ? message.guild.channels.cache.get(args[0]) : null) || message.channel;

    const embed = createEmbed({
      title: `📺  Channel Info: #${channel.name}`,
      description:
        `> Technical overview and permissions for ${channel}.\n\n` +
        `• **Channel ID:** \`${channel.id}\`\n` +
        `• **Type:** \`${channel.type}\`\n` +
        `• **Position:** \`${channel.position}\`\n` +
        `• **Category:** ${channel.parent ? channel.parent.name : '`None`'}\n` +
        `• **NSFW:** \`${channel.nsfw ? 'Yes' : 'No'}\`\n` +
        `• **Slowmode:** \`${channel.rateLimitPerUser ? `${channel.rateLimitPerUser}s` : 'Disabled'}\`\n` +
        `• **Topic:** ${channel.topic ? channel.topic : '*No topic set.*'}\n` +
        `• **Created At:** <t:${Math.floor(channel.createdTimestamp / 1000)}:R>`,
      footer: { text: `Requested by ${message.author.username}` }
    });

    return message.reply({ embeds: [embed] });
  }
};
