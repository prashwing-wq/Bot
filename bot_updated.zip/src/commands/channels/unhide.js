/**
 * Unhide & Unhideall Channel Command (Node.js)
 * Unhides the current channel or all server channels for @everyone.
 */
const { PermissionsBitField, ChannelType } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'unhide',
  aliases: ['unhideall', 'chunhide', 'revealchannel'],
  category: 'channels',
  description: 'Unhides the current channel, specified channel, or all server channels for @everyone.',
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  usage: '[#channel | all]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to unhide channels.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'unhide').toLowerCase();
    const isAll = invoked === 'unhideall' || args[0]?.toLowerCase() === 'all';

    // Mass Server Channel Unhide (unhideall)
    if (isAll) {
      const everyone = message.guild.roles.everyone;
      const textChannels = message.guild.channels.cache.filter(c =>
        c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement
      );

      let unhiddenCount = 0;
      const initialNotice = await message.reply('<a:tungsten_loading:1567241050567876698> **Unhiding all server channels... Please stand by.**');

      for (const [id, ch] of textChannels) {
        try {
          await ch.permissionOverwrites.edit(everyone, { ViewChannel: null }, { reason: `Mass unhideall by ${message.author.tag}` });
          unhiddenCount++;
        } catch (e) {}
      }

      const card = createV2Card({
        color: 0x2ECC71,
        title: '👁️  Mass Channel Visibility Restored',
        description:
          `> Successfully unhidden **${unhiddenCount}** channel(s) for \`@everyone\`.\n\n` +
          `• **Status:** Channel visibility restored to regular members\n` +
          `• **Moderator:** <@${message.author.id}>\n\n` +
          `-# Cloak channels anytime with \`${prefix}hideall\``,
        footerText: `Tungsten Channel Cloak • ${message.guild.name}`
      });

      return initialNotice.edit({ content: null, embeds: [card] });
    }

    // Single Channel Unhide
    const channel = message.mentions?.channels?.first() || (args[0] ? message.guild.channels.cache.get(args[0]) : null) || message.channel;

    try {
      await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
        ViewChannel: null
      }, { reason: `Channel unhidden by ${message.author.tag}` });

      const card = createV2Card({
        color: 0x2ECC71,
        title: '👁️  Channel Unhidden',
        description:
          `> Channel <#${channel.id}> is now visible to members.\n\n` +
          `• **Channel:** <#${channel.id}> (\`${channel.name}\`)\n` +
          `• **Visibility:** Regular members can view this channel.\n\n` +
          `-# Hide channel anytime with \`${prefix}hide\``,
        footerText: `Tungsten Channel Cloak`
      });

      return message.reply({ embeds: [card] });
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to unhide channel: ${e.message}`);
    }
  }
};
