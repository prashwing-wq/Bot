/**
 * Thread Management Command (Node.js)
 * Create, archive, unarchive, lock, rename, and list Discord threads.
 */
const { ChannelType, PermissionFlagsBits } = require('discord.js');
const { hasPerm } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

const ARCHIVE_DURATIONS = {
  '1h': 60,
  '60': 60,
  '1hour': 60,
  '24h': 1440,
  '1440': 1440,
  '1d': 1440,
  '24hours': 1440,
  '1day': 1440,
  '3d': 4320,
  '4320': 4320,
  '3days': 4320,
  '7d': 10080,
  '10080': 10080,
  '7days': 10080,
  '1w': 10080,
  '1week': 10080
};

const DURATION_LABELS = {
  60: '1 Hour (60m)',
  1440: '24 Hours (1 Day)',
  4320: '3 Days (72h)',
  10080: '1 Week (7 Days)'
};

function resolveTargetChannel(message, arg) {
  if (!arg || !message.guild) return null;
  const match = arg.match(/^<#(\d+)>$/);
  const id = match ? match[1] : (arg.match(/^\d{17,20}$/) ? arg : null);
  if (id && message.guild.channels?.cache) {
    return message.guild.channels.cache.get(id) || null;
  }
  return null;
}

module.exports = {
  name: 'thread',
  aliases: ['threads', 'th'],
  category: 'channels',
  description: 'Create, archive, unarchive, lock, rename, and manage Discord threads.',
  usage: '<create|archive|unarchive|lock|rename|list> [options]',
  cooldown: 3,
  permissions: ['ManageThreads'],
  botPermissions: ['ManageThreads', 'SendMessages'],

  async execute(message, args, client, prefix = '!') {
    if (!message.guild) {
      return message.reply('<a:tungsten_close:1567234632905138206> This command can only be used in a server.');
    }

    if (!hasPerm(message.member, PermissionFlagsBits.ManageThreads)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need the `Manage Threads` permission to use this command.');
    }

    const sub = (args[0] || '').toLowerCase();

    // 1. Thread Creation
    if (sub === 'create') {
      let parentChannel = null;
      let tokens = args.slice(1);

      if (tokens.length === 0) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}thread create <#channel> <name> [--private] [--archive 1h|24h|3d|7d]\``);
      }

      // Check if first token points to a channel
      const firstChannel = resolveTargetChannel(message, tokens[0]);
      if (firstChannel) {
        parentChannel = firstChannel;
        tokens = tokens.slice(1);
      } else if (message.mentions?.channels?.size > 0) {
        const mentioned = message.mentions.channels.first();
        const mentionStr = `<#${mentioned.id}>`;
        const idx = tokens.indexOf(mentionStr);
        if (idx !== -1) {
          parentChannel = mentioned;
          tokens.splice(idx, 1);
        }
      }

      // Fallback to current channel if valid
      if (!parentChannel) {
        parentChannel = message.channel;
      }

      if (!parentChannel || !parentChannel.threads || typeof parentChannel.threads.create !== 'function') {
        return message.reply('<a:tungsten_close:1567234632905138206> The target channel cannot host threads. Please select a text or announcement channel.');
      }

      // Parse --private flag
      let isPrivate = false;
      const privIdx = tokens.findIndex(t => t.toLowerCase() === '--private' || t.toLowerCase() === '-p');
      if (privIdx !== -1) {
        isPrivate = true;
        tokens.splice(privIdx, 1);
      }

      // Parse --archive flag
      let autoArchiveDuration = 1440;
      const archIdx = tokens.findIndex(t => t.toLowerCase() === '--archive' || t.toLowerCase() === '-a');
      if (archIdx !== -1) {
        const durArg = tokens[archIdx + 1]?.toLowerCase();
        if (!durArg || !ARCHIVE_DURATIONS[durArg]) {
          return message.reply('<a:tungsten_close:1567234632905138206> Invalid archive duration. Supported values: `1h`, `24h`, `3d`, `7d`.');
        }
        autoArchiveDuration = ARCHIVE_DURATIONS[durArg];
        tokens.splice(archIdx, 2);
      }

      const threadName = tokens.join(' ').replace(/^["']|["']$/g, '').trim();
      if (!threadName || threadName.length < 1 || threadName.length > 100) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please provide a thread name between 1 and 100 characters.');
      }

      let threadType = ChannelType.GuildPublicThread;
      if (isPrivate) {
        threadType = ChannelType.GuildPrivateThread;
      } else if (parentChannel.type === ChannelType.GuildAnnouncement || parentChannel.type === 5) {
        threadType = ChannelType.GuildAnnouncementThread || ChannelType.GuildPublicThread;
      }

      try {
        const newThread = await parentChannel.threads.create({
          name: threadName,
          autoArchiveDuration,
          type: threadType,
          reason: `Thread created by ${message.author.tag || message.author.username} (${message.author.id})`
        });

        const card = createV2Card({
          color: 0x5865F2,
          title: '<a:tungsten_thread:1569329618928930846> Thread Created Successfully',
          description:
            `> New thread <#${newThread.id}> has been successfully initialized.\n\n` +
            `• **Thread:** <#${newThread.id}> (\`${newThread.name}\`)\n` +
            `• **Parent Channel:** <#${parentChannel.id}>\n` +
            `• **Privacy:** \`${isPrivate ? 'Private Thread' : 'Public Thread'}\` ${isPrivate ? '<a:tungsten_lock:1567241079030550668>' : '<a:tungsten_thread:1569329618928930846>'}\n` +
            `• **Auto-Archive Duration:** \`${DURATION_LABELS[autoArchiveDuration] || `${autoArchiveDuration}m`}\`\n` +
            `• **Moderator:** <@${message.author.id}>\n\n` +
            `-# Manage thread settings anytime with \`${prefix}thread\``,
          footerText: `Tungsten Thread Manager • ${message.guild.name}`
        });

        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to create thread: ${err.message}`);
      }
    }

    // 2. Thread Archive
    if (sub === 'archive') {
      const target = resolveTargetChannel(message, args[1]) || (message.channel?.isThread?.() ? message.channel : null);
      if (!target || !target.isThread?.()) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid thread to archive (e.g. \`${prefix}thread archive #thread\`).`);
      }

      if (target.archived) {
        return message.reply(`<a:tungsten_info:1567240890748248084> Thread <#${target.id}> is already archived.`);
      }

      try {
        await target.setArchived(true, `Archived by ${message.author.tag || message.author.username}`);

        const card = createV2Card({
          color: 0xFEE75C,
          title: '<a:tungsten_thread:1569329618928930846> Thread Archived',
          description:
            `> Thread <#${target.id}> has been archived.\n\n` +
            `• **Thread:** <#${target.id}> (\`${target.name}\`)\n` +
            `• **Status:** \`Archived (Hidden from active list)\`\n` +
            `• **Moderator:** <@${message.author.id}>\n\n` +
            `-# Unarchive anytime with \`${prefix}thread unarchive <#${target.id}>\``,
          footerText: `Tungsten Thread Manager • ${message.guild.name}`
        });

        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to archive thread: ${err.message}`);
      }
    }

    // 3. Thread Unarchive
    if (sub === 'unarchive') {
      const target = resolveTargetChannel(message, args[1]) || (message.channel?.isThread?.() ? message.channel : null);
      if (!target || !target.isThread?.()) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid thread to unarchive (e.g. \`${prefix}thread unarchive <thread_id>\`).`);
      }

      if (!target.archived) {
        return message.reply(`<a:tungsten_info:1567240890748248084> Thread <#${target.id}> is already active and not archived.`);
      }

      try {
        await target.setArchived(false, `Unarchived by ${message.author.tag || message.author.username}`);

        const card = createV2Card({
          color: 0x57F287,
          title: '<a:tungsten_thread:1569329618928930846> Thread Restored & Unarchived',
          description:
            `> Thread <#${target.id}> has been restored and unarchived.\n\n` +
            `• **Thread:** <#${target.id}> (\`${target.name}\`)\n` +
            `• **Status:** <a:tungsten_ui_toggle_on:1569329685110849576> \`Active\`\n` +
            `• **Moderator:** <@${message.author.id}>`,
          footerText: `Tungsten Thread Manager • ${message.guild.name}`
        });

        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to unarchive thread: ${err.message}`);
      }
    }

    // 4. Thread Lock
    if (sub === 'lock') {
      const target = resolveTargetChannel(message, args[1]) || (message.channel?.isThread?.() ? message.channel : null);
      if (!target || !target.isThread?.()) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Please specify a valid thread to lock (e.g. \`${prefix}thread lock #thread\`).`);
      }

      if (target.locked) {
        return message.reply(`<a:tungsten_info:1567240890748248084> Thread <#${target.id}> is already locked.`);
      }

      try {
        await target.setLocked(true, `Locked by ${message.author.tag || message.author.username}`);

        const card = createV2Card({
          color: 0xED4245,
          title: '<a:tungsten_lock:1567241079030550668> Thread Locked',
          description:
            `> Thread <#${target.id}> has been locked.\n\n` +
            `• **Thread:** <#${target.id}> (\`${target.name}\`)\n` +
            `• **Access:** \`Staff with Manage Threads only\`\n` +
            `• **Moderator:** <@${message.author.id}>`,
          footerText: `Tungsten Thread Manager • ${message.guild.name}`
        });

        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to lock thread: ${err.message}`);
      }
    }

    // 5. Thread Rename
    if (sub === 'rename') {
      let target = null;
      let newName = '';

      const firstTarget = resolveTargetChannel(message, args[1]);
      if (firstTarget && firstTarget.isThread?.()) {
        target = firstTarget;
        newName = args.slice(2).join(' ').trim();
      } else if (message.channel?.isThread?.()) {
        target = message.channel;
        newName = args.slice(1).join(' ').trim();
      } else {
        return message.reply(`<a:tungsten_close:1567234632905138206> Usage: \`${prefix}thread rename <#thread> <new_name>\` or \`${prefix}thread rename <new_name>\` inside an active thread.`);
      }

      if (!newName || newName.length < 1 || newName.length > 100) {
        return message.reply('<a:tungsten_close:1567234632905138206> Please specify a new thread name between 1 and 100 characters.');
      }

      try {
        const oldName = target.name;
        await target.setName(newName, `Renamed by ${message.author.tag || message.author.username}`);

        const card = createV2Card({
          color: 0x5865F2,
          title: '<a:tungsten_thread:1569329618928930846> Thread Renamed',
          description:
            `> Thread <#${target.id}> has been successfully renamed.\n\n` +
            `• **Old Name:** \`${oldName}\`\n` +
            `• **New Name:** \`${newName}\`\n` +
            `• **Moderator:** <@${message.author.id}>`,
          footerText: `Tungsten Thread Manager • ${message.guild.name}`
        });

        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to rename thread: ${err.message}`);
      }
    }

    // 6. Thread List (Active | Archived)
    if (sub === 'list') {
      const modeArg = (args[1] || '').toLowerCase();
      const isArchived = modeArg === 'archived' || (args[2] || '').toLowerCase() === 'archived';
      const filterChannel = resolveTargetChannel(message, args[1]) || resolveTargetChannel(message, args[2]) || null;

      try {
        let threadList = [];

        if (isArchived) {
          const targetParent = filterChannel || (message.channel?.isTextBased?.() && !message.channel.isThread?.() ? message.channel : null);
          if (targetParent && targetParent.threads?.fetchArchived) {
            const fetched = await targetParent.threads.fetchArchived({ limit: 25 }).catch(() => null);
            if (fetched?.threads) threadList = Array.from(fetched.threads.values());
          } else if (message.guild?.channels?.cache) {
            const textChannels = Array.from(message.guild.channels.cache.filter(c => c.isTextBased?.() && !c.isThread?.()).values()).slice(0, 5);
            for (const ch of textChannels) {
              if (ch.threads?.fetchArchived) {
                const res = await ch.threads.fetchArchived({ limit: 10 }).catch(() => null);
                if (res?.threads) {
                  threadList.push(...Array.from(res.threads.values()));
                }
              }
            }
          }
        } else {
          if (message.guild?.channels?.fetchActiveThreads) {
            const fetched = await message.guild.channels.fetchActiveThreads().catch(() => null);
            if (fetched?.threads) {
              threadList = Array.from(fetched.threads.values());
              if (filterChannel) {
                threadList = threadList.filter(t => t.parentId === filterChannel.id);
              }
            }
          }
        }

        if (threadList.length === 0) {
          const card = createV2Card({
            color: 0x5865F2,
            title: `<a:tungsten_thread:1569329618928930846> Threads: ${isArchived ? 'Archived' : 'Active'}`,
            description:
              `> No ${isArchived ? 'archived' : 'active'} threads found${filterChannel ? ` in <#${filterChannel.id}>` : ' in this server'}.\n\n` +
              `-# Create one anytime with \`${prefix}thread create <#channel> <name>\``,
            footerText: `Tungsten Thread Manager • ${message.guild.name}`
          });
          return message.reply({ embeds: [card] });
        }

        const formatted = threadList.slice(0, 15).map(t => {
          const lockIcon = t.locked ? '<a:tungsten_lock:1567241079030550668> ' : '';
          const archiveIcon = t.archived ? '<a:tungsten_ui_toggle_off:1569329677187678368> ' : '<a:tungsten_ui_toggle_on:1569329685110849576> ';
          const parentStr = t.parentId ? `(in <#${t.parentId}>)` : '';
          const msgCount = typeof t.messageCount === 'number' ? `• \`${t.messageCount}\` msgs` : '';
          return `${archiveIcon}${lockIcon}<#${t.id}> — \`${t.name}\` ${parentStr} ${msgCount}`;
        }).join('\n');

        const card = createV2Card({
          color: 0x5865F2,
          title: `<a:tungsten_thread:1569329618928930846> Threads: ${isArchived ? 'Archived' : 'Active'} (${threadList.length} Total)`,
          description:
            `> Overview of ${isArchived ? 'archived' : 'active'} threads${filterChannel ? ` in <#${filterChannel.id}>` : ' across the server'}:\n\n` +
            `${formatted}${threadList.length > 15 ? `\n\n*...and ${threadList.length - 15} more threads.*` : ''}\n\n` +
            `-# Use \`${prefix}thread <archive|unarchive|lock|rename>\` to manage`,
          footerText: `Tungsten Thread Manager • ${message.guild.name}`
        });

        return message.reply({ embeds: [card] });
      } catch (err) {
        return message.reply(`<a:tungsten_close:1567234632905138206> Failed to list threads: ${err.message}`);
      }
    }

    // Default Overview / Help Card
    const overviewCard = createV2Card({
      color: 0x5865F2,
      title: '<a:tungsten_thread:1569329618928930846> Tungsten Thread Management Suite',
      description:
        `Manage public and private Discord conversation threads across the server.\n\n` +
        `• \`${prefix}thread create <#channel> <name> [--private] [--archive 1h|24h|3d|7d]\`\n` +
        `  *Create a new thread with optional privacy and auto-archive timer.*\n\n` +
        `• \`${prefix}thread archive <#thread>\`\n` +
        `  *Archive an active thread to remove it from the channel list.*\n\n` +
        `• \`${prefix}thread unarchive <#thread>\`\n` +
        `  *Restore an archived thread back to active conversations.*\n\n` +
        `• \`${prefix}thread lock <#thread>\`\n` +
        `  *Lock a thread so only staff with Manage Threads can reply.*\n\n` +
        `• \`${prefix}thread rename <#thread> <name>\`\n` +
        `  *Update the title of an existing thread.*\n\n` +
        `• \`${prefix}thread list [active|archived] [#channel]\`\n` +
        `  *Inspect all active or archived threads server-wide.*`,
      footerText: `Tungsten Channel Suite • ${message.guild.name}`
    });

    return message.reply({ embeds: [overviewCard] });
  }
};
