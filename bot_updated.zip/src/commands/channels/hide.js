/**
 * Hide & Hideall Channel Command (Node.js)
 * Hides the current channel or all server channels from @everyone.
 */
const { PermissionsBitField, ChannelType } = require('discord.js');
const { hasPerm, isOwner, createEmbed } = require('../../utils/tools');
const { createV2Card } = require('../../utils/componentsV2');

module.exports = {
  name: 'hide',
  aliases: ['hideall', 'chhide', 'ghostchannel'],
  category: 'channels',
  description: 'Hides the current channel, specified channel, or all server channels from @everyone.',
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  usage: '[#channel | all]',
  cooldown: 3,

  async execute(message, args, client, prefix) {
    if (!message.guild) return;

    if (!hasPerm(message.member, PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('<a:tungsten_close:1567234632905138206> You need `Manage Channels` permission to hide channels.');
    }

    const invoked = (message.invokedName || (message.content && prefix && message.content.startsWith(prefix) ? message.content.slice(prefix.length).trim().split(/\s+/)[0] : message.content?.trim().split(/\s+/)[0]) || 'hide').toLowerCase();
    const isAll = invoked === 'hideall' || args[0]?.toLowerCase() === 'all';

    // Mass Server Channel Hide (hideall)
    if (isAll) {
      const everyone = message.guild.roles.everyone;
      const textChannels = message.guild.channels.cache.filter(c =>
        c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement
      );

      let hiddenCount = 0;
      const initialNotice = await message.reply('<a:tungsten_loading:1567241050567876698> **Hiding all server channels... Please stand by.**');

      for (const [id, ch] of textChannels) {
        try {
          await ch.permissionOverwrites.edit(everyone, { ViewChannel: false }, { reason: `Mass hideall by ${message.author.tag}` });
          hiddenCount++;
        } catch (e) {}
      }

      const card = createV2Card({
        color: 0xED4245,
        title: '👁️  Mass Channel Cloaking Complete',
        description:
          `> Successfully hidden **${hiddenCount}** channel(s) from \`@everyone\`.\n\n` +
          `• **Status:** Channels are invisible to non-staff members\n` +
          `• **Moderator:** <@${message.author.id}>\n\n` +
          `-# Reveal all channels anytime with \`${prefix}unhideall\` or \`${prefix}unhide all\``,
        footerText: `Tungsten Channel Cloak • ${message.guild.name}`
      });

      return initialNotice.edit({ content: null, embeds: [card] });
    }

    // Single Channel Hide
    const channel = message.mentions?.channels?.first() || (args[0] ? message.guild.channels.cache.get(args[0]) : null) || message.channel;

    try {
      await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
        ViewChannel: false
      }, { reason: `Channel hidden by ${message.author.tag}` });

      const card = createV2Card({
        color: 0xED4245,
        title: '👁️  Channel Hidden',
        description:
          `> Channel <#${channel.id}> has been **hidden** from regular members.\n\n` +
          `• **Channel:** <#${channel.id}> (\`${channel.name}\`)\n` +
          `• **Visibility:** Only staff with View Channel permissions can see this channel.\n\n` +
          `-# Reveal channel with \`${prefix}unhide\``,
        footerText: `Tungsten Channel Cloak`
      });

      return message.reply({ embeds: [card] });
    } catch (e) {
      return message.reply(`<a:tungsten_close:1567234632905138206> Failed to hide channel: ${e.message}`);
    }
  }
};
