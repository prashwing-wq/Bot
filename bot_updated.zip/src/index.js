/**
 * Tungsten Node.js Bot Entry Point
 */
const dns = require('node:dns');
dns.setDefaultResultOrder('ipv4first');

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

console.log('[Tungsten Engine] Initializing Tungsten Engine...');

// Initialize Universal UI Emoji Sanitizer (guarantees 0 default unicode emojis in the entire UI)
require('./utils/uiSanitizer');

// TungstenClient constructor initializes Master Components V2 Global Container Dispatcher
const TungstenClient = require('./core/TungstenClient');

const client = new TungstenClient();
const { startHealthServer } = require('./utils/httpServer');
const { initMongo, closeMongo } = require('./utils/mongoClient');
const { startPeriodicMongoSync, stopPeriodicMongoSync } = require('./utils/mongoSync');

if (process.env.MONGODB_URI) {
  initMongo().then(async () => {
    const { hydrateAllFromMongo, startRealtimeMongoFlusher } = require('./utils/mongoHydrator');
    await hydrateAllFromMongo().catch(err => console.warn('[MongoHydrator] Boot hydration note:', err.message));
    startRealtimeMongoFlusher(2000);
    startPeriodicMongoSync(15);
  }).catch(err => {
    console.warn('[MongoDB] Initial connection notice:', err.message);
  });
}

if (process.env.SERVER_PORT || process.env.PORT) {
  startHealthServer(client);
}

process.on('unhandledRejection', (reason, promise) => {
  const code = reason?.code || reason?.rawError?.code;
  if (code === 10062 || code === 40060) {
    return;
  }
  console.error('[Tungsten Unhandled Rejection]:', reason);
});

process.on('uncaughtException', (err, origin) => {
  console.error('[Tungsten Fatal Uncaught Exception]:', err);
  try {
    const { _DB_CACHE, getMasterDb } = require('./utils/serverDb');
    for (const db of _DB_CACHE.values()) {
      try {
        db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
      } catch (e) {}
    }
    try {
      getMasterDb().exec('PRAGMA wal_checkpoint(TRUNCATE);');
    } catch (e) {}
  } catch (e) {}
  process.exit(1);
});

async function startBotWithRetry(retries = 5, delayMs = 3000) {
  for (let i = 1; i <= retries; i++) {
    try {
      await client.start();
      return;
    } catch (err) {
      console.error(`[Tungsten Boot] Connection attempt ${i}/${retries} failed: ${err.message}`);
      if (i < retries) {
        await new Promise(r => setTimeout(r, delayMs));
      } else {
        console.error('[Tungsten Boot Fatal Error]: All connection attempts exhausted.');
        process.exit(1);
      }
    }
  }
}

startBotWithRetry();

async function gracefulShutdown(signal) {
  console.log(`[Tungsten] Received ${signal}. Executing clean graceful shutdown...`);
  try {
    if (client.isReady && client.isReady()) {
      client.destroy();
    }

    const { stopRealtimeMongoFlusher } = require('./utils/mongoHydrator');
    await stopRealtimeMongoFlusher().catch(() => null);
    stopPeriodicMongoSync();

    const { isMongoConnected } = require('./utils/mongoClient');
    if (isMongoConnected()) {
      try {
        console.log('[Tungsten] Flushing all in-memory databases to MongoDB Atlas before shutdown...');
        const { pushAllDatabasesToMongo } = require('./utils/mongoSync');
        await pushAllDatabasesToMongo({ logger: () => {} });
      } catch (e) {
        console.warn('[Tungsten] Notice during final Mongo flush:', e.message);
      }
    }

    const { _DB_CACHE, getMasterDb } = require('./utils/serverDb');
    for (const db of _DB_CACHE.values()) {
      try {
        db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
        db.close();
      } catch (e) {}
    }
    try {
      getMasterDb().exec('PRAGMA wal_checkpoint(TRUNCATE);');
    } catch (e) {}
    await closeMongo().catch(() => null);
    console.log('[Tungsten] All SQLite databases and MongoDB connections cleanly closed.');
  } catch (err) {
    console.error('[Tungsten] Error during shutdown:', err);
  } finally {
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

module.exports = client;
