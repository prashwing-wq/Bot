/**
 * Tungsten Node.js Configuration
 */
const envOwners = (process.env.OWNER_IDS || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

const allOwners = Array.from(new Set(envOwners));

module.exports = {
  OWNER_IDS: allOwners,
  DEFAULT_PREFIX: process.env.DEFAULT_PREFIX || '!',
  CLIENT_ID: process.env.CLIENT_ID || '',
  TOKEN: process.env.DISCORD_TOKEN || process.env.TOKEN || '',
  SUPPORT_SERVER: process.env.SUPPORT_SERVER || 'https://discord.gg/tfDMjZS9YJ',
  LINKS: {
    SUPPORT: process.env.SUPPORT_SERVER || 'https://discord.gg/tfDMjZS9YJ',
    DOCS: 'https://discord.gg/tfDMjZS9YJ',
    INVITE: process.env.CLIENT_ID
      ? `https://discord.com/oauth2/authorize?client_id=${process.env.CLIENT_ID}&permissions=8&scope=bot%20applications.commands`
      : 'https://discord.gg/tfDMjZS9YJ'
  },
  COLORS: {
    PRIMARY: 0x000000,     // Pitch black
    SUCCESS: 0x000000,     // Pitch black
    WARNING: 0x000000,     // Pitch black
    DANGER: 0x000000,      // Pitch black
    INFO: 0x000000         // Pitch black
  },
  BACKUP: {
    KEEP: 1 // Strict single snapshot retention policy (retains only 1 newest set)
  },
  MONGODB: {
    URI: process.env.MONGODB_URI || '',
    USERNAME: process.env.MONGODB_USERNAME || '',
    DATABASE: process.env.MONGODB_DATABASE || 'tungsten_bot'
  }
};
