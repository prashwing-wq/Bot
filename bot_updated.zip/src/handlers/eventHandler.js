/**
 * Tungsten Dynamic Event Handler (Node.js)
 * Registers listeners for gateway and client lifecycle events.
 */
const fs = require('fs');
const path = require('path');

function getEventFiles(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getEventFiles(fullPath));
    } else if (file.endsWith('.js') && !file.startsWith('_') && !file.endsWith('.test.js')) {
      results.push(fullPath);
    }
  }
  return results;
}

async function loadEvents(client) {
  const eventsDir = path.resolve(__dirname, '..', 'events');
  const files = getEventFiles(eventsDir);

  if (!client._loadedEvents) {
    client._loadedEvents = new Map();
  }

  for (const filePath of files) {
    try {
      delete require.cache[require.resolve(filePath)];
      const event = require(filePath);
      if (!event || !event.name || typeof event.execute !== 'function') {
        continue;
      }

      // Cleanly remove any existing listener for this event to guarantee zero duplicate handlers
      if (client._loadedEvents.has(event.name)) {
        client.removeListener(event.name, client._loadedEvents.get(event.name));
        client._loadedEvents.delete(event.name);
      }

      const listener = (...args) => event.execute(...args, client);
      client._loadedEvents.set(event.name, listener);

      if (event.once) {
        client.once(event.name, listener);
      } else {
        client.on(event.name, listener);
      }
    } catch (e) {
      console.error(`[EventHandler] Error loading event ${filePath}:`, e);
    }
  }
}

module.exports = {
  loadEvents,
  getEventFiles
};
