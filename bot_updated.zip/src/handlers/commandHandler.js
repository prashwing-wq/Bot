/**
 * Tungsten Dynamic Command Handler (Node.js)
 * Recursively discovers, validates, and registers all prefix and slash commands.
 * Supports multi-category indexing so cross-domain commands appear accurately in Help.
 */
const fs = require('fs');
const path = require('path');

function getCommandFiles(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getCommandFiles(fullPath));
    } else if (file.endsWith('.js') && !file.startsWith('_') && !file.endsWith('.test.js')) {
      results.push(fullPath);
    }
  }
  return results;
}

// Built-in intelligent category cross-mappings to ensure all categories are populated
const CATEGORY_CROSS_MAPPINGS = {
  whitelist: ['whitelist', 'security'],
  unwhitelist: ['whitelist', 'security'],
  lock: ['channels', 'moderation'],
  unlock: ['channels', 'moderation'],
  slowmode: ['channels', 'moderation'],
  nuke: ['channels', 'moderation'],
  channelinfo: ['channels', 'utility'],
  welcome: ['welcomer'],
  leave: ['welcomer'],
  auditlog: ['logging'],
  voice: ['media'],
  vcstatus: ['media'],
  leaderboard: ['leaderboards'],
  rank: ['leaderboards'],
  automod: ['automation'],
  autoresponder: ['automation'],
  autoreact: ['automation'],
  componentsv2: ['utility'],
  panel: ['utility', 'security'],
  tos: ['utility', 'general'],
  starboard: ['utility'],
  suggest: ['utility'],
  suggestchannel: ['utility'],
  suggestapprove: ['utility', 'moderation'],
  suggestdeny: ['utility', 'moderation'],
  suggestconfig: ['utility'],
  warnladder: ['moderation', 'automation'],
  modules: ['utility', 'automation'],
  poll: ['utility'],
  discordpoll: ['utility'],
  discordevent: ['utility'],
  nativeautomod: ['security', 'automation'],
  boost: ['utility']
};

async function loadCommands(client, customDir = null) {
  const commandsDir = customDir || path.resolve(__dirname, '..', 'commands');
  let files = getCommandFiles(commandsDir);

  if (client.commands) client.commands.clear(); else client.commands = new Map();
  if (client.aliases) client.aliases.clear(); else client.aliases = new Map();
  if (client.categories) client.categories.clear(); else client.categories = new Map();
  if (client.cooldowns) client.cooldowns.clear();
  client.slashCommands = [];

  for (const filePath of files) {
    try {
      delete require.cache[require.resolve(filePath)];
      const exported = require(filePath);
      if (!exported) continue;

      const cmdList = Array.isArray(exported)
        ? exported
        : (exported.name ? [exported] : Object.values(exported).filter(c => c && typeof c === 'object' && c.name));

      for (const command of cmdList) {
        if (!command || !command.name) continue;

        const cmdName = command.name.toLowerCase();

        // Infer category from parent directory if not set
        if (!command.category) {
          const parentDir = path.basename(path.dirname(filePath));
          command.category = parentDir !== 'commands' ? parentDir : 'utility';
        }

        client.commands.set(cmdName, command);

        // Register aliases
        if (command.aliases && Array.isArray(command.aliases)) {
          for (const alias of command.aliases) {
            const al = String(alias).toLowerCase();
            if (!client.commands.has(al) && !client.aliases.has(al)) {
              client.aliases.set(al, cmdName);
            }
          }
        }

        // Determine all categories this command belongs to
        let catList = [];
        if (Array.isArray(command.category)) {
          catList = command.category.map(c => String(c).toLowerCase());
        } else if (typeof command.category === 'string') {
          catList = [command.category.toLowerCase()];
        }

        // Check cross-mappings for natural secondary categorization
        if (CATEGORY_CROSS_MAPPINGS[cmdName]) {
          for (const extraCat of CATEGORY_CROSS_MAPPINGS[cmdName]) {
            if (!catList.includes(extraCat)) {
              catList.push(extraCat);
            }
          }
        }

        // Normalize welcomer/welcome aliases
        if (catList.includes('welcomer') && !catList.includes('welcome')) {
          catList.push('welcome');
        }
        if (catList.includes('welcome') && !catList.includes('welcomer')) {
          catList.push('welcomer');
        }

        for (const cat of catList) {
          if (!client.categories.has(cat)) {
            client.categories.set(cat, []);
          }
          const existing = client.categories.get(cat);
          if (!existing.some(c => c.name.toLowerCase() === cmdName)) {
            existing.push(command);
          }
        }

        // Register slash command data if available for all commands that support slash (exclude owner & no-prefix commands)
        const isBotOwnerCmd = command.ownerOnly === true ||
                              command.category === 'owner' ||
                              ['database', 'db', 'mongo', 'eval', 'noprefix', 'np', 'npmanager', 'exec', 'reload', 'sync', 'asynceval'].includes(command.name?.toLowerCase());

        if (!isBotOwnerCmd) {
          const slashSpec = command.slash || command.slashData || (typeof command.executeSlash === 'function' ? {
            name: command.name,
            description: command.description || `${command.name} command`
          } : null);
          if (slashSpec) {
            const slashPayload = typeof slashSpec.toJSON === 'function'
              ? slashSpec.toJSON()
              : (typeof slashSpec === 'object' ? slashSpec : {
                  name: command.name,
                  description: command.description || `${command.name} command`
                });
            // Prevent duplicate slash commands
            if (!client.slashCommands.some(sc => sc.name === slashPayload.name)) {
              client.slashCommands.push(slashPayload);
            }
          }

          if (command.contextMenus && Array.isArray(command.contextMenus)) {
            for (const cm of command.contextMenus) {
              client.slashCommands.push(typeof cm.toJSON === 'function' ? cm.toJSON() : cm);
            }
          } else if (command.contextMenu) {
            const cm = command.contextMenu;
            client.slashCommands.push(typeof cm.toJSON === 'function' ? cm.toJSON() : cm);
          }
        }
      }
    } catch (e) {
      console.error(`[CommandHandler] Error loading command ${filePath}:`, e);
    }
  }

  // Register global context menu commands (Warn author, Report message, View infractions)
  try {
    const { CONTEXT_MENUS } = require('../interactions/contextMenus');
    if (Array.isArray(CONTEXT_MENUS)) {
      for (const cm of CONTEXT_MENUS) {
        if (!client.slashCommands.some(sc => sc.name === cm.name && sc.type === cm.type)) {
          client.slashCommands.push(cm);
        }
      }
    }
  } catch (_) {}
}

module.exports = {
  loadCommands,
  getCommandFiles
};
