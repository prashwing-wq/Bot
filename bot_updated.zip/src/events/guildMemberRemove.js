/**
 * Guild Member Remove Event (Node.js)
 * Implements Anti-Kick / Anti-Prune Sentinel and Farewell Announcements.
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent, EmbedBuilder } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { formatPlaceholders } = require('../utils/placeholders');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');
const { recordMemberLeave } = require('../utils/massDmDetector');
const config = require('../config');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member, client) {
    if (!member || !member.guild) return;
    const guild = member.guild;

    // ─────────────────────────────────────────────────────────────
    // 1. Anti-Kick & Anti-Prune Interception (Wick / Olympus Parity)
    // ─────────────────────────────────────────────────────────────
    if (isAntinukeArmed(guild.id)) {
      try {
        // A. Check for Member Prune
        const pruneRule = getAntinukeRule(guild.id, 'prune');
        if (pruneRule && pruneRule.enabled) {
          const pruneExecutor = await resolveAuditExecutor(guild, AuditLogEvent.MemberPrune);
          if (pruneExecutor && !isImmune(guild, pruneExecutor.id, 'prune')) {
            await punishAttacker(guild, pruneExecutor, `Initiated unauthorized server member prune`, client, 'Anti-Member Prune', 'prune');
            return;
          }
        }

        // B. Check for Member Kick
        const kickRule = getAntinukeRule(guild.id, 'kick');
        if (kickRule && kickRule.enabled) {
          const executor = await resolveAuditExecutor(guild, AuditLogEvent.MemberKick, { targetId: member.id });
          if (executor && !isImmune(guild, executor.id, 'kick')) {
            const exceeded = checkVectorRateLimit(guild.id, executor.id, 'kick');
            if (exceeded || !kickRule || kickRule.limit_count <= 1) {
              await punishAttacker(guild, executor, `Kicked member ${member.user?.username || member.id} (${member.id}) without authorization`, client, 'Anti-Kick Interception', 'kick');
            }
          }
        }
      } catch (e) {
        console.warn(`[Anti-Kick/Prune Error] in ${guild.id}:`, e.message);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 1.5 Mass DM Quick-Departure Detection (Feature 8)
    // ─────────────────────────────────────────────────────────────
    try {
      await recordMemberLeave(guild.id, member.id, guild);
    } catch (e) {
      console.warn(`[Mass DM Leave Tracker Error] in ${guild.id}:`, e.message);
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Member State Cleanup (AFK & Staff Duty)
    // ─────────────────────────────────────────────────────────────
    try {
      const sdb = getServerDb(guild.id);
      sdb.prepare('DELETE FROM user_afk WHERE user_id = ? AND guild_id = ?').run(member.id, guild.id);
      sdb.prepare('UPDATE staff_duty SET on_duty = 0, started_at = 0 WHERE user_id = ? AND guild_id = ?').run(member.id, guild.id);
    } catch (e) {}

    // ─────────────────────────────────────────────────────────────
    // 3. Process Leave / Farewell Announcement
    // ─────────────────────────────────────────────────────────────
    try {
      const sdb = getServerDb(guild.id);
      const chRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_channel'").get();
      const stRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_status'").get();
      const isEnabled = stRow ? stRow.value === '1' : Boolean(chRow && chRow.value);

      if (isEnabled && chRow && chRow.value) {
        const channel = guild.channels?.cache?.get(chRow.value)
          || await guild.channels?.fetch(chRow.value).catch(() => null);
        if (channel && channel.isTextBased && typeof channel.send === 'function') {
          const { getGuildAccent } = require('../utils/serverDb');
          const accent = getGuildAccent(guild.id);

          const msgRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_message'").get();
          const titleRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_title'").get();
          const thumbRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_thumbnail'").get();
          const bannerRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'leave_banner'").get();

          const rawMsg = msgRow ? msgRow.value : '**{user.name}** has left **{server.name}**. We now have {memberCount} members.';
          const rawTitle = titleRow ? titleRow.value : 'Goodbye • {server.name}';
          const thumbMode = thumbRow ? thumbRow.value : 'avatar';
          const bannerUrl = bannerRow ? bannerRow.value : '';

          const text = formatPlaceholders(rawMsg, member, guild);
          const title = formatPlaceholders(rawTitle, member, guild);

          const embed = new EmbedBuilder()
            .setColor(accent)
            .setTitle(title)
            .setDescription(text)
            .setFooter({ text: `Members: ${guild.memberCount}` })
            .setTimestamp();

          if (thumbMode === 'server' && guild.iconURL) {
            embed.setThumbnail(guild.iconURL());
          } else if (typeof thumbMode === 'string' && thumbMode.startsWith('http')) {
            embed.setThumbnail(thumbMode);
          } else if (thumbMode !== 'none' && member.user?.displayAvatarURL) {
            embed.setThumbnail(member.user.displayAvatarURL());
          }

          if (bannerUrl && typeof bannerUrl === 'string' && bannerUrl.startsWith('http')) {
            embed.setImage(bannerUrl);
          }

          await channel.send({ embeds: [embed] }).catch(() => null);
        }
      }
    } catch (e) {
      console.warn(`[Leave Event Error] ${guild.id}: ${e.message}`);
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Automated Workflow Sequence Dispatch (Slice 3.3)
    // ─────────────────────────────────────────────────────────────
    try {
      const { executeWorkflows } = require('../utils/workflowEngine');
      await executeWorkflows(guild, 'member_leave', { member, user: member.user || member, guild }, client);
    } catch (e) {
      console.warn(`[Workflow Error] member_leave in ${guild.id}:`, e.message);
    }
  }
};
