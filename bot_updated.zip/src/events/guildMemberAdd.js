/**
 * Guild Member Add Event (Node.js)
 * Implements Anti-Bot Protection, Automated Autoroles, and Welcome Engine.
 */
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, AuditLogEvent, PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { formatPlaceholders } = require('../utils/placeholders');
const {
  isAntinukeArmed,
  isImmune,
  punishAttacker,
  resolveAuditExecutor,
  checkRateLimitExceeded,
  dispatchSecurityAlert
} = require('../utils/antinukeEngine');
const { handleThreatOnJoin, checkGlobalThreat } = require('../utils/threatIntelligence');
const { recordMemberJoin } = require('../utils/massDmDetector');
const config = require('../config');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    if (!member || !member.guild) return;
    const guild = member.guild;

    // ─────────────────────────────────────────────────────────────
    // 1. Anti-Bot Add Sentinel Interception (H12 & C5 & AntiBot Settings)
    // ─────────────────────────────────────────────────────────────
    if (member.user.bot) {
      try {
        const sdbPre = getServerDb(guild.id);
        sdbPre.prepare(`
          CREATE TABLE IF NOT EXISTS antibot_settings (
            guild_id TEXT PRIMARY KEY,
            enabled INTEGER DEFAULT 1,
            punishment TEXT DEFAULT 'kick',
            whitelisted_bots TEXT DEFAULT '[]'
          )
        `).run();

        const abSettings = sdbPre.prepare('SELECT * FROM antibot_settings WHERE guild_id = ?').get(guild.id);
        const isAntibotArmed = abSettings ? abSettings.enabled === 1 : false;
        let whitelistedBots = [];
        try {
          whitelistedBots = JSON.parse(abSettings?.whitelisted_bots || '[]');
        } catch (e) {
          whitelistedBots = [];
        }

        // If bot is explicitly in whitelisted_bots, allow it to join
        if (!whitelistedBots.includes(member.user.id)) {
          if (isAntibotArmed || isAntinukeArmed(guild.id)) {
            const { getAntinukeRule } = require('../utils/antinukeEngine');
            const botRule = getAntinukeRule(guild.id, 'bot_add');

            if (!botRule || botRule.enabled || isAntibotArmed) {
              const executor = await resolveAuditExecutor(guild, AuditLogEvent.BotAdd, { targetId: member.id });
              const executorId = executor ? executor.id : null;
              const isTrusted = executorId && (executorId === guild.ownerId || isImmune(guild, executorId, 'bot'));

              if (!isTrusted) {
                const punishment = (abSettings?.punishment || 'kick').toLowerCase();
                const reason = executor
                  ? `[Tungsten Anti-Bot] Unauthorized bot added by ${executor.username} (${executorId})`
                  : '[Tungsten Anti-Bot] Unauthorized / Unattributed bot join blocked under active defense sentinel.';

                if (punishment === 'ban' && member.bannable) {
                  await member.ban({ reason }).catch(() => null);
                } else if (member.kickable) {
                  await member.kick(reason).catch(() => null);
                } else {
                  await member.kick(reason).catch(() => member.ban({ reason }).catch(() => null));
                }

                if (executor) {
                  await punishAttacker(guild, executor, `Added unauthorized bot ${member.user.username} (${member.user.id})`, client, 'Anti-Bot Add', 'bot_add');
                }

                dispatchSecurityAlert(guild, {
                  title: 'Unauthorized Bot Addition Intercepted',
                  description: `A bot <@${member.id}> (\`${member.user.tag}\`) was added ${executor ? `by <@${executor.id}>` : 'unattributed'} and neutralized via **${punishment.toUpperCase()}**.`,
                  color: config.COLORS.DANGER
                });
                return;
              }
            }
          }
        }
      } catch (e) {
        console.warn(`[Anti-Bot Error] in ${guild.id}:`, e.message);
      }
    }

    const sdb = getServerDb(guild.id);

    // ─────────────────────────────────────────────────────────────
    // 1.3 Shared Cross-Server Threat Intelligence Sentinel (Feature 3)
    // ─────────────────────────────────────────────────────────────
    try {
      const threatRecord = checkGlobalThreat(member.id);
      if (threatRecord) {
        const threatResult = await handleThreatOnJoin(member, client);
        if (threatResult && threatResult.flagged && threatResult.actionTaken) {
          // Auto-action executed (kicked/banned) - halt further join processing
          return;
        }
      }
    } catch (e) {
      console.warn(`[Threat Intelligence Error] in ${guild.id}:`, e.message);
    }

    // ─────────────────────────────────────────────────────────────
    // 1.4 Mass DM Raid & Join Velocity Sentinel (Feature 8)
    // ─────────────────────────────────────────────────────────────
    try {
      await recordMemberJoin(guild.id, member.id, guild);
    } catch (e) {
      console.warn(`[Mass DM Join Tracker Error] in ${guild.id}:`, e.message);
    }

    // ─────────────────────────────────────────────────────────────
    // 1.5 Anti-Raid Join Flood Interception (H12)
    // ─────────────────────────────────────────────────────────────
    try {
      const raidRow = sdb.prepare('SELECT enabled, join_limit, window_seconds, action FROM antiraid_settings WHERE guild_id = ?').get(guild.id);
      const isRaidArmed = raidRow ? raidRow.enabled === 1 : false;
      const joinLimit = raidRow ? raidRow.join_limit : 8;
      const windowMs = (raidRow?.window_seconds || 10) * 1000;

      if (isRaidArmed && checkRateLimitExceeded(guild.id, 'guild_join', 'raid', joinLimit, windowMs)) {
        const action = (raidRow?.action || 'kick').toLowerCase();
        if (action === 'ban' && member.bannable) {
          await member.ban({ deleteMessageSeconds: 86400, reason: '[Tungsten Anti-Raid] Join flood threshold exceeded.' }).catch(() => null);
        } else if (action === 'timeout' && member.moderatable) {
          await member.timeout(3600000, '[Tungsten Anti-Raid] Join flood quarantine.').catch(() => null);
        } else if (member.kickable) {
          await member.kick('[Tungsten Anti-Raid] Join flood threshold exceeded.').catch(() => null);
        }

        dispatchSecurityAlert(guild, {
          title: 'Anti-Raid: Mass Join Flood',
          description: `Mass join flood detected (> ${joinLimit} joins in ${windowMs / 1000}s). Account <@${member.id}> (${member.user.username}) was neutralized (${action}).`,
          color: config.COLORS.DANGER
        });
        return;
      }
    } catch (e) {}

    // ─────────────────────────────────────────────────────────────
    // 2. Process Autoroles from dedicated server.db
    // ─────────────────────────────────────────────────────────────
    try {
      const arRow = sdb.prepare('SELECT bots, humans FROM autorole WHERE guild_id = ?').get(guild.id);
      if (arRow) {
        let roleIds = [];
        try {
          if (member.user.bot && arRow.bots) {
            roleIds = typeof arRow.bots === 'string' ? JSON.parse(arRow.bots) : arRow.bots;
          } else if (!member.user.bot && arRow.humans) {
            roleIds = typeof arRow.humans === 'string' ? JSON.parse(arRow.humans) : arRow.humans;
          }
        } catch (err) {
          const raw = member.user.bot ? arRow.bots : arRow.humans;
          if (raw) {
            roleIds = String(raw).replace(/[\[\]]/g, '').split(',')
              .map(s => s.trim())
              .filter(s => /^\d+$/.test(s));
          }
        }

        if (Array.isArray(roleIds) && roleIds.length > 0) {
          const rolesToAdd = [];
          for (const rid of roleIds) {
            const role = guild.roles.cache.get(String(rid));
            if (role) {
              const isAdmin = typeof role.permissions?.has === 'function' && (role.permissions.has(PermissionsBitField.Flags.Administrator) || role.permissions.has('Administrator'));
              if (isAdmin) {
                console.warn(`[Autorole Safeguard] Skipping role ${role.id} (${role.name || 'Unknown'}) in guild ${guild.id}: Administrator permission detected`);
                continue;
              }
              if (guild.members?.me?.roles?.highest?.position !== undefined && guild.members.me.roles.highest.position <= role.position) {
                continue;
              }
              rolesToAdd.push(role);
            }
          }
          if (rolesToAdd.length > 0) {
            await member.roles.add(rolesToAdd, 'Tungsten Automated Autorole Assignment').catch(() => {});
          }
        }
      }
    } catch (e) {
      console.warn(`[Autorole Error] ${guild.id}: ${e.message}`);
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Process Welcome Announcement from dedicated server.db
    // ─────────────────────────────────────────────────────────────
    try {
      const wRow = sdb.prepare('SELECT * FROM welcome_panel WHERE guild_id = ?').get(guild.id);
      if (wRow && wRow.status === 1 && wRow.channel_id && String(wRow.channel_id) !== '0') {
        const channel = guild.channels.cache.get(String(wRow.channel_id))
          || await guild.channels.fetch(String(wRow.channel_id)).catch(() => null);
        if (channel && channel.isTextBased()) {
          const { getGuildAccent } = require('../utils/serverDb');
          const accent = getGuildAccent(guild.id);
          const title = formatPlaceholders(wRow.cv2_title || 'Welcome to {server.name}!', member, guild);
          const desc = formatPlaceholders(wRow.cv2_description || 'Hey {user.mention}, welcome to {server.name}!', member, guild);

          const embed = new EmbedBuilder()
            .setColor(accent)
            .setTitle(title)
            .setDescription(desc)
            .setFooter({ text: `Member #${guild.memberCount} • Account created ${formatPlaceholders('{user.created_at}', member, guild)}` })
            .setTimestamp();

          if (wRow.cv2_thumbnail === 'server' && guild.iconURL) {
            embed.setThumbnail(guild.iconURL());
          } else if (typeof wRow.cv2_thumbnail === 'string' && wRow.cv2_thumbnail.startsWith('http')) {
            embed.setThumbnail(wRow.cv2_thumbnail);
          } else if (wRow.cv2_thumbnail !== 'none' && member.user?.displayAvatarURL) {
            embed.setThumbnail(member.user.displayAvatarURL());
          }

          if (wRow.cv2_banner && typeof wRow.cv2_banner === 'string' && wRow.cv2_banner.startsWith('http')) {
            embed.setImage(wRow.cv2_banner);
          }

          const payload = { embeds: [embed] };
          if (wRow.ping_mode === 'content' || wRow.ping_mode === 'ping') {
            payload.content = `<@${member.id}>`;
          }

          if (wRow.action_buttons === 1) {
            const rulesCh = guild.channels?.cache?.find(c => c.name.includes('rules'));
            const verifyCh = guild.channels?.cache?.find(c => c.name.includes('verify'));
            const row = new ActionRowBuilder();
            if (rulesCh) {
              row.addComponents(
                new ButtonBuilder()
                  .setLabel('Read Rules')
                  .setStyle(ButtonStyle.Link)
                  .setURL(`https://discord.com/channels/${guild.id}/${rulesCh.id}`)
              );
            }
            if (verifyCh) {
              row.addComponents(
                new ButtonBuilder()
                  .setLabel('Get Verified')
                  .setStyle(ButtonStyle.Link)
                  .setURL(`https://discord.com/channels/${guild.id}/${verifyCh.id}`)
              );
            }
            if (row.components.length > 0) {
              payload.components = [row];
            }
          }

          const sent = await channel.send(payload).catch(() => {});
          if (sent && wRow.auto_delete > 0) {
            setTimeout(() => sent.delete().catch(() => null), wRow.auto_delete * 1000);
          }
        }

        // Direct Message Greeting
        if (wRow.dm_enabled === 1 && wRow.dm_message) {
          const dmText = formatPlaceholders(wRow.dm_message, member, guild);
          await member.send(dmText).catch(() => {});
        }
      }
    } catch (e) {
      console.warn(`[Welcome Event Error] ${guild.id}: ${e.message}`);
    }

    // ─────────────────────────────────────────────────────────────
    // 4. Automated Workflow Sequence Dispatch (Slice 3.3)
    // ─────────────────────────────────────────────────────────────
    try {
      const { executeWorkflows } = require('../utils/workflowEngine');
      await executeWorkflows(guild, 'member_join', { member, user: member.user, guild }, client);
    } catch (e) {
      console.warn(`[Workflow Error] member_join in ${guild.id}:`, e.message);
    }
  }
};
