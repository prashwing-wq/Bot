/**
 * Channel Update Event (Node.js)
 * Implements Anti-Channel Permission Tampering & Unauthorized Unhiding Sentinel (C8).
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent, PermissionsBitField } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  punishAttacker,
  resolveAuditExecutor,
  cacheChannelSnapshot
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'channelUpdate',
  async execute(oldChannel, newChannel, client) {
    if (!newChannel || !newChannel.guild) return;
    const guild = newChannel.guild;

    cacheChannelSnapshot(newChannel);

    if (!isAntinukeArmed(guild.id)) return;

    const rule = getAntinukeRule(guild.id, 'channel_update');
    if (rule && !rule.enabled) return;

    // Check if permissions overwrites changed
    const oldOverwrites = oldChannel.permissionOverwrites?.cache;
    const newOverwrites = newChannel.permissionOverwrites?.cache;
    if (!oldOverwrites || !newOverwrites) return;

    let suspicious = false;
    for (const [id, newPo] of newOverwrites.entries()) {
      const oldPo = oldOverwrites.get(id);
      if (!oldPo) {
        if (newPo.allow.has(PermissionsBitField.Flags.Administrator) ||
            newPo.allow.has(PermissionsBitField.Flags.ManageChannels) ||
            newPo.allow.has(PermissionsBitField.Flags.ManageRoles) ||
            newPo.allow.has(PermissionsBitField.Flags.MentionEveryone)) {
          suspicious = true;
          break;
        }
      } else {
        if ((!oldPo.allow.has(PermissionsBitField.Flags.MentionEveryone) && newPo.allow.has(PermissionsBitField.Flags.MentionEveryone)) ||
            (!oldPo.allow.has(PermissionsBitField.Flags.ManageChannels) && newPo.allow.has(PermissionsBitField.Flags.ManageChannels)) ||
            (!oldPo.allow.has(PermissionsBitField.Flags.ViewChannel) && newPo.allow.has(PermissionsBitField.Flags.ViewChannel) && id === guild.id)) {
          suspicious = true;
          break;
        }
      }
    }

    if (!suspicious) return;

    try {
      const executor = await resolveAuditExecutor(guild, AuditLogEvent.ChannelOverwriteUpdate, { targetId: newChannel.id })
        || await resolveAuditExecutor(guild, AuditLogEvent.ChannelUpdate, { targetId: newChannel.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'channel')) return;

      // Revert overwrites to old configuration if auto_heal is active
      if (rule?.auto_heal) {
        const rawList = typeof oldOverwrites.map === 'function' ? oldOverwrites : [...oldOverwrites.values()];
        const oldList = rawList.map(po => ({
          id: po.id,
          type: po.type,
          allow: po.allow,
          deny: po.deny
        }));
        await newChannel.permissionOverwrites.set(oldList, '[Tungsten Anti-Tampering] Reverting unauthorized channel overwrites.').catch(() => null);
      }

      await punishAttacker(guild, executor, `Modified channel overwrites in #${newChannel.name} without authorization`, client, 'Anti-Channel Overwrite Tampering', 'channel_update');
    } catch (e) {
      console.warn(`[Anti-Channel Update Error] in ${guild.id}:`, e.message);
    }
  }
};
