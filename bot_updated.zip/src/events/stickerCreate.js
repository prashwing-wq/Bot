/**
 * Sticker Create Event (Node.js)
 * Implements Anti-Sticker Mass Creation Sentinel (Roadmap Section 6).
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'stickerCreate',
  async execute(sticker, client) {
    if (!sticker || !sticker.guild) return;
    const guild = sticker.guild;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const rule = getAntinukeRule(guild.id, 'sticker');
      if (rule && !rule.enabled) return;

      const executor = await resolveAuditExecutor(guild, AuditLogEvent.StickerCreate, { targetId: sticker.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'sticker')) return;

      const exceeded = checkVectorRateLimit(guild.id, executor.id, 'sticker');
      if (exceeded) {
        await punishAttacker(guild, executor, `Mass Sticker Creation spam (${sticker.name}) without authorization`, client, 'Anti-Sticker Spam', 'sticker');
        await sticker.delete().catch(() => null);
      }
    } catch (e) {
      console.warn(`[stickerCreate] Error in ${guild.id}:`, e.message);
    }
  }
};
