/**
 * Client Ready Event
 * Initializes server databases, presence, and restores 24/7 Home Voice Channels.
 */
const { ActivityType, GatewayOpcodes, Routes, Events } = require('discord.js');
const crypto = require('node:crypto');
const { registerGuild, getServerDb, getMasterDb, syncResolvedOwners, prunePhantomServerFolders } = require('../utils/serverDb');
const { refreshOwners } = require('../utils/tools');
const { initScheduler } = require('../utils/scheduler');

module.exports = {
  name: Events.ClientReady || 'ready',
  once: true,
  async execute(client) {
    console.log(`[Tungsten Node] Logged in as ${client.user.username} (${client.user.id})`);
    console.log(`[Tungsten Node] Active in ${client.guilds.cache.size} servers serving ${client.users.cache.size} users.`);

    // 0. Auto-resolve Discord Application Owners (Team or Single Owner)
    try {
      if (client.application) {
        await client.application.fetch();
        const appOwnerIds = [];
        if (client.application.owner) {
          if (client.application.owner.members) {
            // Team
            for (const member of client.application.owner.members.values()) {
              if (member.id) appOwnerIds.push(member.id);
            }
          } else if (client.application.owner.id) {
            appOwnerIds.push(client.application.owner.id);
          }
        }
        if (appOwnerIds.length > 0) {
          syncResolvedOwners(appOwnerIds);
          refreshOwners();
          console.log(`[Ready] Synced ${appOwnerIds.length} application owner(s) to bot_owners.`);
        }
      }
    } catch (e) {
      console.warn(`[Ready] Notice fetching application owner: ${e.message}`);
    }

    // Deploy / synchronize Discord Slash Commands with hash caching (Roadmap 2.8)
    try {
      if (client.rest && Array.isArray(client.slashCommands) && client.slashCommands.length > 0) {
        const payloadHash = crypto.createHash('sha256').update(JSON.stringify(client.slashCommands)).digest('hex');
        const mdb = getMasterDb();
        const row = mdb.prepare("SELECT value FROM global_settings WHERE key = 'slash_commands_hash'").get();
        if (row && row.value === payloadHash) {
          console.log(`[Ready] Slash commands up to date (${client.slashCommands.length} commands). Skipping REST sync.`);
        } else {
          console.log(`[Ready] Synchronizing ${client.slashCommands.length} application slash command(s)...`);
          await client.rest.put(Routes.applicationCommands(client.user.id), {
            body: client.slashCommands
          });
          mdb.prepare("INSERT OR REPLACE INTO global_settings (key, value, updated_at) VALUES ('slash_commands_hash', ?, ?)").run(payloadHash, Math.floor(Date.now() / 1000));
          console.log(`[Ready] Successfully deployed global application commands.`);
        }
      }
    } catch (err) {
      console.warn(`[Ready] Notice deploying application slash commands: ${err.message}`);
    }

    // Set Bot Presence
    client.user.setPresence({
      activities: [
        {
          name: `${client.config.DEFAULT_PREFIX}help | Tungsten Enterprise`,
          type: ActivityType.Watching
        }
      ],
      status: 'dnd'
    });

    // 1. Provision / verify dedicated database folders for all guilds (ignoreIfExists=true)
    for (const guild of client.guilds.cache.values()) {
      try {
        await registerGuild(guild);
      } catch (e) {
        console.warn(`[Ready] Notice verifying database for guild ${guild.id}: ${e.message}`);
      }
    }

    // 1.5 Prune ghost/phantom server folders from db/servers/ (coz bot is not in them)
    try {
      const pruned = prunePhantomServerFolders(client);
      if (pruned > 0) {
        console.log(`[Ready] Pruned ${pruned} ghost/unassociated server folder(s) from db/servers/.`);
      }
    } catch (e) {
      console.warn(`[Ready] Notice pruning phantom server folders: ${e.message}`);
    }

    // 2. Auto-reconnect 24/7 Home Voice Channels
    for (const guild of client.guilds.cache.values()) {
      try {
        const sdb = getServerDb(guild.id);
        const homeVc = sdb.prepare('SELECT channel_id, status_text, enabled FROM home_voice_channels WHERE guild_id = ? AND enabled = 1').get(guild.id);
        if (homeVc && homeVc.channel_id) {
          const vc = guild.channels.cache.get(homeVc.channel_id)
            || await guild.channels.fetch(homeVc.channel_id).catch(() => null);
          if (vc && vc.isVoiceBased()) {
            if (guild.shard && typeof guild.shard.send === 'function') {
              guild.shard.send({
                op: 4, // VoiceStateUpdate opcode
                d: {
                  guild_id: guild.id,
                  channel_id: homeVc.channel_id,
                  self_mute: false,
                  self_deaf: true
                }
              });
            }

            if (homeVc.status_text && client.rest) {
              const ping = Math.round(client.ws.ping) || 0;
              const formatted = homeVc.status_text
                .replace(/\{ping\}/gi, `${ping}`)
                .replace(/\{latency\}/gi, `${ping}`)
                .replace(/\{server\}/gi, guild.name);
              client.rest.put(Routes.channelVoiceStatus(homeVc.channel_id), { body: { status: formatted } }).catch(() => null);
            }
            console.log(`[HomeVC] Reconnected 24/7 voice channel in ${guild.name} (${vc.name})`);

            // Small throttle between gateway voice reconnects to avoid opcode flood and repeated shard reconnects
            await new Promise(r => setTimeout(r, 100));
          }
        }
      } catch (err) {
        // Safe catch per-guild
      }
    }

    // 2.5 Initialize in-memory voice sessions for leveling XP
    try {
      const { initVoiceSessions } = require('./voiceStateUpdate');
      if (typeof initVoiceSessions === 'function') {
        initVoiceSessions(client);
      }
    } catch (_) {}

    // 3. Initialize Unified Event-Driven Task Scheduler (Replaces 20s active polling)
    initScheduler(client);

    // 4. Dynamic Presence Rotation with Live Server Telemetry
    const presences = [
      () => `${client.config.DEFAULT_PREFIX}help | Tungsten Enterprise`,
      () => `Serving ${client.guilds.cache.size} servers | Anti-Nuke Active`,
      () => `Components V2 Engine | !anmode`
    ];
    let pIdx = 0;
    setInterval(() => {
      if (!client.user) return;
      const fn = presences[pIdx++ % presences.length];
      client.user.setActivity(fn(), { type: ActivityType.Watching });
    }, 30000).unref();

    // 5. Periodic SQLite Master WAL Checkpointing (Every 5 minutes)
    setInterval(() => {
      try {
        const { getMasterDb } = require('../utils/serverDb');
        getMasterDb().exec('PRAGMA wal_checkpoint(PASSIVE);');
      } catch (e) {}
    }, 300000).unref();

    // 6. Dual Backup Roles Safeguard Verification on Boot (Staggered to prevent REST API spikes)
    (async () => {
      try {
        const { ensureDualBackupRoles } = require('../utils/antinukeEngine');
        const { getServerDb } = require('../utils/serverDb');
        const guilds = client.guilds?.cache ? [...client.guilds.cache.values()] : [];
        for (const guild of guilds) {
          try {
            const sdb = getServerDb(guild.id);
            const statusRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antinuke_status'").get();
            const backupRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'backup_roles_enabled'").get();
            const isExplicitlyArmed = (statusRow && (statusRow.value === '1' || statusRow.value === 'true')) ||
                                      (backupRow && (backupRow.value === '1' || backupRow.value === 'true'));
            if (isExplicitlyArmed) {
              const res = await ensureDualBackupRoles(guild, { force: false }).catch(err => {
                console.warn(`[Ready] Dual Backup Roles error in ${guild.id}:`, err?.message || err);
                return null;
              });
              if (res?.success) {
                console.log(`[Ready] Dual Backup Roles anchored in ${guild.name} (${guild.id})`);
              } else if (res?.reason) {
                console.warn(`[Ready] Dual Backup Roles check for ${guild.id}: ${res.reason}`);
              }
              // Stagger by 500ms between guilds to prevent Discord REST API spikes
              await new Promise(r => setTimeout(r, 500));
            }
          } catch (_) {}
        }
      } catch (_) {}
    })().catch(() => {});

    // 6.5 Autonomous Antinuke Snapshot Preloading & Server Identity Initialization
    try {
      const { cacheChannelSnapshot, cacheRoleSnapshot, captureServerBaselineIdentity } = require('../utils/antinukeEngine');
      let cachedChannels = 0;
      let cachedRoles = 0;
      for (const guild of client.guilds.cache.values()) {
        try {
          if (guild.channels?.cache) {
            for (const ch of guild.channels.cache.values()) {
              cacheChannelSnapshot(ch);
              cachedChannels++;
            }
          }
          if (guild.roles?.cache) {
            for (const r of guild.roles.cache.values()) {
              cacheRoleSnapshot(r);
              cachedRoles++;
            }
          }
          captureServerBaselineIdentity(guild).catch(() => null);
        } catch (_) {}
      }
      console.log(`[Ready] Preloaded ${cachedChannels} channel snapshots, ${cachedRoles} role snapshots & server baseline identities.`);
    } catch (_) {}

    // 6.6 Autonomous Clean Baseline Snapshot Initialization
    try {
      const { captureCleanSnapshot } = require('../utils/roleAnchor');
      for (const guild of client.guilds.cache.values()) {
        try {
          const sdb = getServerDb(guild.id);
          const cleanBaselineRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'clean_baseline_snapshot_id'").get();
          if (!cleanBaselineRow || !cleanBaselineRow.value) {
            captureCleanSnapshot(guild).catch(() => null);
          }
        } catch (_) {}
      }
    } catch (_) {}

    // 6.7 Role Position Auto-Anchor Sentinel Task (NEW FEATURE 5)
    try {
      const { startRoleAnchorTask } = require('../utils/roleAnchor');
      startRoleAnchorTask(client);
      console.log('[Ready] Role Position Auto-Anchor sentinel task engaged (10m interval).');
    } catch (e) {
      console.warn(`[Ready] Notice starting role anchor task: ${e.message}`);
    }

    // 7. Auto-detect & Synchronize Dedicated Emoji Servers
    try {
      const { syncEmojiServers } = require('../utils/emojiSync');
      syncEmojiServers(client).then(res => {
        console.log(`[Ready] Emoji Server Sync: ${res.uploaded} uploaded, ${res.indexed} live custom emojis indexed across ${res.servers} emoji server(s).`);
        if (res.needMoreServers) {
          console.warn(`[Ready] Notice: Animated emoji slots full across all current emoji servers. Additional servers will be utilized as they are created.`);
        }
      }).catch(err => {
        console.warn(`[Ready] Notice in Emoji Server Sync: ${err.message}`);
      });
    } catch (_) {}

    console.log('[Tungsten Node] Ready & Fully Operational!');
  }
};
