/**
 * Tungsten messageUpdate Event Handler (messageUpdate.js)
 * Intercepts edited messages to ensure automod evasion is blocked.
 * Logs before/after content to dedicated log_messages channel (Roadmap Feature E).
 */
const { Events } = require('discord.js');
const { runAutomodCheck } = require('../utils/automodEngine');
const { getLogChannel } = require('../utils/logRouter');
const { createEmbed } = require('../utils/tools');

module.exports = {
  name: Events.MessageUpdate,
  async execute(oldMessage, newMessage, client) {
    if (!newMessage || !newMessage.guild) return;

    try {
      if (newMessage.partial) {
        await newMessage.fetch().catch(() => null);
      }
    } catch (e) {}

    if (!newMessage.content || newMessage.author?.bot) return;

    // If content did not change (e.g. embed generation / pin update), skip
    if (oldMessage && oldMessage.content === newMessage.content) return;

    await runAutomodCheck(newMessage, client);

    // Feature E: Log edited messages with before/after content
    try {
      const logChannel = getLogChannel(newMessage.guild, 'log_messages');
      if (logChannel) {
        const oldContent = oldMessage?.content ? oldMessage.content.slice(0, 800) : '*[Original content not cached]*';
        const newContent = newMessage.content ? newMessage.content.slice(0, 800) : '*[No content]*';

        const embed = createEmbed({
          color: 0xfaa61a,
          title: '✏️ Message Edited',
          description:
            `• **Author:** <@${newMessage.author.id}> (\`${newMessage.author.tag || newMessage.author.username}\` — \`${newMessage.author.id}\`)\n` +
            `• **Channel:** <#${newMessage.channel.id}>\n` +
            `• **Jump to Message:** [Click Here](${newMessage.url})\n\n` +
            `**Before:**\n> ${oldContent.replace(/\n/g, '\n> ')}\n\n` +
            `**After:**\n> ${newContent.replace(/\n/g, '\n> ')}`
        });

        await logChannel.send({ embeds: [embed] }).catch(() => null);
      }
    } catch (_) {}
  }
};
