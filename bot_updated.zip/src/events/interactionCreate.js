/**
 * Interaction Create Event (Slash Commands & Modular Component Router)
 */
const { MessageFlags } = require('discord.js');
const { routeInteraction } = require('../interactions');
const { EMOJIS } = require('../utils/emojis');
const { isOwner, hasPerm, createEmbed, getConfig } = require('../utils/tools');
const { isAntinukeArmed } = require('../utils/antinukeEngine');
const { checkCommandSpam, SPAM_LOCKOUT_MESSAGE } = require('../utils/commandSpamBlocker');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    // 0. Graceful error protection against expired interaction tokens (10062) and duplicate acks (40060)
    for (const method of ['reply', 'update', 'editReply', 'followUp', 'deferUpdate', 'deferReply']) {
      if (typeof interaction[method] === 'function') {
        const orig = interaction[method].bind(interaction);
        interaction[method] = async function (...args) {
          try {
            return await orig(...args);
          } catch (err) {
            const code = err?.code || err?.rawError?.code;
            if (code === 10062 || code === 40060) {
              return null; // Expired token or duplicate ACK — swallow gracefully
            }
            throw err;
          }
        };
      }
    }

    function sanitizeForEditReply(options) {
      if (!options || typeof options !== 'object' || Array.isArray(options)) return options;
      const clean = { ...options };
      delete clean.ephemeral;
      if (clean.flags) {
        clean.flags = clean.flags & ~MessageFlags.Ephemeral;
        if (!clean.flags) delete clean.flags;
      }
      return clean;
    }

    if (typeof interaction.reply === 'function' && !interaction.reply.__replyHooked) {
      const _origReply = interaction.reply.bind(interaction);
      const wrappedReply = async function (opts) {
        if (interaction.deferred && !interaction.replied) {
          return interaction.editReply(sanitizeForEditReply(opts));
        }
        if (interaction.replied) {
          return interaction.followUp(opts);
        }
        return _origReply(opts);
      };
      wrappedReply.__replyHooked = true;
      interaction.reply = wrappedReply;
    }

    if (typeof interaction.update === 'function' && !interaction.update.__updateHooked) {
      const _origUpdate = interaction.update.bind(interaction);
      const wrappedUpdate = async function (opts) {
        if (interaction.deferred || interaction.replied) {
          return interaction.editReply(sanitizeForEditReply(opts));
        }
        return _origUpdate(opts);
      };
      wrappedUpdate.__updateHooked = true;
      interaction.update = wrappedUpdate;
    }

    // 1. Slash Commands Dispatch
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command || typeof command.executeSlash !== 'function') {
        return interaction.reply({ content: 'Command not recognized or no slash handler found.', flags: MessageFlags.Ephemeral });
      }

      if ((command.ownerOnly || command.category === 'owner') && !isOwner(interaction.user.id)) {
        return interaction.reply({ content: 'This command can be executed only by Bot Owner.', flags: MessageFlags.Ephemeral });
      }

      // Command Anti-Spam & Rate Limiting Check (Continuous 5-spam limiter across server)
      if (interaction.guild) {
        const spamCheck = checkCommandSpam(interaction.guild.id, interaction.user.id, interaction.guild.ownerId);
        if (spamCheck.blocked) {
          return interaction.reply({
            content: SPAM_LOCKOUT_MESSAGE(spamCheck.remainingSeconds),
            flags: MessageFlags.Ephemeral
          });
        }
      }

      // Check Antinuke prerequisite for Moderation Commands
      const isModCommand = Array.isArray(command.category)
        ? command.category.includes('moderation')
        : command.category === 'moderation';
      if (interaction.guild && isModCommand) {
        if (!isAntinukeArmed(interaction.guild.id)) {
          const prefix = getConfig(interaction.guild.id)?.prefix || client.config?.DEFAULT_PREFIX || '!';
          return interaction.reply({
            embeds: [
              createEmbed({
                title: '<a:tungsten_warn:1567242784535085148> Antinuke Is Disabled',
                description: `> **Security Requirement**: Moderation actions are currently locked because Antinuke is **disabled** on this server.\n\nTo execute moderations (ban, kick, mute, purge, lock, etc.), you must first enable Antinuke:\n• Run \`${prefix}antinuke enable\` or \`${prefix}an on\``
              })
            ],
            flags: MessageFlags.Ephemeral
          });
        }
      }

      // Enforce Declarative Permissions for Slash Commands (Review #4 / 2.3)
      if (interaction.guild && interaction.member) {
        const requiredPerms = command.permissions || command.userPermissions;
        if (Array.isArray(requiredPerms) && requiredPerms.length > 0) {
          const missing = requiredPerms.filter(p => !hasPerm(interaction.member, p));
          if (missing.length > 0) {
            return interaction.reply({
              content: `${EMOJIS.ERROR} You lack required permission(s): \`${missing.join(', ')}\` to execute \`/${interaction.commandName}\`.`,
              flags: MessageFlags.Ephemeral
            });
          }
        }

        const botPerms = command.botPermissions;
        if (Array.isArray(botPerms) && botPerms.length > 0 && interaction.guild.members.me) {
          const missingBot = botPerms.filter(p => !interaction.guild.members.me.permissions.has(p));
          if (missingBot.length > 0) {
            return interaction.reply({
              content: `${EMOJIS.ERROR} Tungsten lacks required permission(s): \`${missingBot.join(', ')}\` to execute \`/${interaction.commandName}\`.`,
              flags: MessageFlags.Ephemeral
            });
          }
        }
      }

      let deferTimer = null;
      if (typeof interaction.deferReply === 'function') {
        deferTimer = setTimeout(async () => {
          try {
            if (!interaction.deferred && !interaction.replied) {
              await interaction.deferReply().catch(() => null);
            }
          } catch (_) {}
        }, 2500);
      }

      try {
        await command.executeSlash(interaction, client);
      } catch (e) {
        const code = e?.code || e?.rawError?.code;
        if (code === 10062 || code === 40060) return;
        console.error(`[Slash Execution Error: ${interaction.commandName}]`, e);
        const replyObj = { content: `${EMOJIS.WARN} Error executing slash command: ${e.message}`, flags: MessageFlags.Ephemeral };
        if (interaction.deferred && !interaction.replied) {
          await interaction.editReply(replyObj).catch(() => null);
        } else if (interaction.replied) {
          await interaction.followUp(replyObj).catch(() => null);
        } else {
          await interaction.reply(replyObj).catch(() => null);
        }
      } finally {
        if (deferTimer) clearTimeout(deferTimer);
      }
      return;
    }

    // 1b. Autocomplete Dispatch
    if (interaction.isAutocomplete && interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (command && typeof command.autocomplete === 'function') {
        try {
          await command.autocomplete(interaction, client);
        } catch (e) {
          console.error(`[Autocomplete Error: ${interaction.commandName}]`, e);
        }
      }
      return;
    }

    // 1c. Context Menu Commands Dispatch
    if (interaction.isContextMenuCommand && interaction.isContextMenuCommand()) {
      const { handleContextMenu } = require('../interactions/contextMenus');
      return handleContextMenu(interaction, client);
    }

    // 2. Component UI Interactions (Buttons, Select Menus, Modals)
    if (
      interaction.isStringSelectMenu() ||
      interaction.isButton() ||
      interaction.isUserSelectMenu?.() ||
      interaction.isRoleSelectMenu?.() ||
      interaction.isChannelSelectMenu?.() ||
      interaction.isAnySelectMenu?.() ||
      interaction.isModalSubmit()
    ) {
      const customId = interaction.customId;

      // ─────────────────────────────────────────────────────────────
      // Panel Framework Dispatcher (p:<page>:<action>:<arg>:<userId>)
      // ─────────────────────────────────────────────────────────────
      if (customId.startsWith('p:')) {
        const { handlePanelInteraction } = require('../panel/dispatcher');
        return handlePanelInteraction(interaction, client).catch(err => {
          const code = err?.code || err?.rawError?.code;
          if (code === 10062 || code === 40060) return;
          console.error('[Panel Dispatcher Error]', err);
          if (!interaction.deferred && !interaction.replied) {
            interaction.reply({ content: '⚠️ An error occurred processing panel control.', flags: MessageFlags.Ephemeral }).catch(() => null);
          }
        });
      }

      // Modular Interaction Router (src/interactions/*.js)
      const routed = await routeInteraction(interaction, client);
      if (routed) return;

      // ─────────────────────────────────────────────────────────────
      // Fallback handlers for standalone un-prefixed actions
      // ─────────────────────────────────────────────────────────────
      if (customId === 'v2_demo_pulse') {
        return interaction.reply({
          content: `${EMOJIS.ZAP} **Components V2 Pulse**: Layout & Animation Engine is running at 100% efficiency!`,
          flags: MessageFlags.Ephemeral
        });
      }

      if (customId === 'v2_demo_telemetry') {
        const totalCmds = client.commands ? client.commands.size : 0;
        const totalCats = client.categories ? client.categories.size : 0;
        return interaction.reply({
          content: `${EMOJIS.CHART} **Telemetry**: \`${totalCmds}\` commands across \`${totalCats}\` categories are fully verified with sub-millisecond statement caching.`,
          flags: MessageFlags.Ephemeral
        });
      }

      if (customId === 'v2_demo_dismiss' || customId === 'cmd_dismiss') {
        try {
          await interaction.deferUpdate().catch(() => null);
          if (typeof interaction.deleteReply === 'function') {
            await interaction.deleteReply().catch(async () => {
              if (interaction.message?.deletable) {
                await interaction.message.delete().catch(() => null);
              } else {
                await interaction.editReply({ content: '*Dismissed.*', embeds: [], components: [] }).catch(() => null);
              }
            });
          } else if (interaction.message?.deletable) {
            await interaction.message.delete().catch(() => null);
          } else {
            await interaction.editReply({ content: '*Dismissed.*', embeds: [], components: [] }).catch(() => null);
          }
        } catch (e) {
          try {
            await interaction.editReply({ content: '*Dismissed.*', embeds: [], components: [] }).catch(() => null);
          } catch (err) {}
        }
        return;
      }

      if (customId.startsWith('cmd_help_')) {
        const cmdName = customId.replace('cmd_help_', '').replace(/_/g, ' ');
        return interaction.reply({
          content: `${EMOJIS.DOCUMENT} **Command Documentation:** \`${cmdName}\`\nExecute with \`!${cmdName} [args]\` or view complete directory via \`!help\`.`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Acknowledge any unmatched component interaction to prevent "This interaction failed" hanging on Discord
      if (!interaction.deferred && !interaction.replied) {
        return interaction.reply({
          content: `${EMOJIS.WARN} This interactive control is no longer active or expired. Please run the command again.`,
          flags: MessageFlags.Ephemeral
        }).catch(() => null);
      }
    }
  }
};
