/**
 * Webhook Update Event (Node.js)
 * Implements Anti-Webhook Creation & Raid Spammer Neutralization.
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  punishAttacker,
  resolveAuditExecutor,
  getActiveRaidAttacker,
  recordActiveRaidAttacker,
  markBotDeletedEntity
} = require('../utils/antinukeEngine');

// In-memory guard to prevent recursive loops from bot deletions (H11)
const _BOT_DELETED_WEBHOOKS = new Set();

module.exports = {
  name: 'webhooksUpdate',
  async execute(channel, client) {
    if (!channel || !channel.guild) return;
    const guild = channel.guild;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const rule = getAntinukeRule(guild.id, 'webhook');
      if (rule && !rule.enabled) return;

      const hooks = await channel.fetchWebhooks().catch(() => null);
      if (!hooks || hooks.size === 0) return;

      for (const hook of hooks.values()) {
        if (_BOT_DELETED_WEBHOOKS.has(hook.id)) continue;

        // 1. Authorized checks
        if (hook.owner?.id === client?.user?.id) continue;
        if (hook.owner?.id && isImmune(guild, hook.owner.id, 'webhook', client)) continue;

        // 2. OTHERWISE: IT IS UNAUTHORIZED!
        _BOT_DELETED_WEBHOOKS.add(hook.id);
        setTimeout(() => _BOT_DELETED_WEBHOOKS.delete(hook.id), 30000).unref();
        if (typeof markBotDeletedEntity === 'function') {
          markBotDeletedEntity(hook.id);
        }

        // 3. DELETE THE WEBHOOK IMMEDIATELY (Do NOT gate on audit log resolution!)
        await hook.delete('[Tungsten Anti-Webhook] Unauthorized webhook deleted immediately.').catch(() => null);

        // 4. Attacker resolution & punishment
        if (hook.owner) {
          if (hook.owner.bot) {
            if (guild.bans?.create) {
              await guild.bans.create(hook.owner.id, { reason: `[Tungsten Anti-Webhook] Rogue bot created unauthorized webhook in #${channel.name}` }).catch(() => null);
            } else if (guild.members?.ban) {
              await guild.members.ban(hook.owner.id, { reason: `[Tungsten Anti-Webhook] Rogue bot created unauthorized webhook in #${channel.name}` }).catch(() => null);
            }
          }
          recordActiveRaidAttacker(guild.id, hook.owner);
          await punishAttacker(
            guild,
            hook.owner,
            'Created unauthorized webhook in #' + channel.name,
            client,
            'Anti-Webhook Rogue',
            'webhook',
            null,
            { isBot: Boolean(hook.owner.bot) }
          );
        } else {
          // Check active raid attacker or recent audit logs with retries [50, 150, 300, 600, 1000]
          let executor = null;
          const activeAttacker = getActiveRaidAttacker(guild.id);
          if (activeAttacker && activeAttacker.executor) {
            executor = activeAttacker.executor;
          }

          if (!executor) {
            executor = await resolveAuditExecutor(guild, AuditLogEvent.WebhookCreate, {
              targetId: hook.id,
              maxRetries: 5,
              retryDelays: [50, 150, 300, 600, 1000],
              fallbackRecent: true
            });
          }

          if (executor) {
            if (executor.id !== client?.user?.id && !isImmune(guild, executor.id, 'webhook', client)) {
              recordActiveRaidAttacker(guild.id, executor);
              if (executor.bot) {
                if (guild.bans?.create) {
                  await guild.bans.create(executor.id, { reason: `[Tungsten Anti-Webhook] Rogue bot created unauthorized webhook in #${channel.name}` }).catch(() => null);
                } else if (guild.members?.ban) {
                  await guild.members.ban(executor.id, { reason: `[Tungsten Anti-Webhook] Rogue bot created unauthorized webhook in #${channel.name}` }).catch(() => null);
                }
              }
              await punishAttacker(
                guild,
                executor,
                'Created unauthorized webhook in #' + channel.name,
                client,
                'Anti-Webhook Rogue',
                'webhook',
                null,
                { isBot: Boolean(executor.bot) }
              );
            }
          }
        }
      }
    } catch (e) {
      console.warn(`[Anti-Webhook Error] in ${guild.id}:`, e.message);
    }
  }
};
