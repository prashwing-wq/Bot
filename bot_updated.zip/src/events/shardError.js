/**
 * Shard Error Event (Node.js)
 * Implements Gateway Shard Error Telemetry.
 */
module.exports = {
  name: 'shardError',
  async execute(error, shardId) {
    console.error(`[Shard ${shardId}] Gateway WebSocket error:`, error?.message || error);
  }
};
