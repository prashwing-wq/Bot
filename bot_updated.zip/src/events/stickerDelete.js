/**
 * Sticker Delete Event (Node.js)
 * Implements Anti-Sticker Mass Delete Sentinel (C8).
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'stickerDelete',
  async execute(sticker, client) {
    if (!sticker || !sticker.guild) return;
    const guild = sticker.guild;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const rule = getAntinukeRule(guild.id, 'sticker');
      if (rule && !rule.enabled) return;

      const executor = await resolveAuditExecutor(guild, AuditLogEvent.StickerDelete, { targetId: sticker.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'sticker')) return;

      const exceeded = checkVectorRateLimit(guild.id, executor.id, 'sticker');
      if (exceeded || !rule || rule.limit_count <= 1) {
        await punishAttacker(guild, executor, `Deleted sticker :${sticker.name}: (${sticker.id}) without authorization`, client, 'Anti-Sticker Delete', 'sticker');
      }
    } catch (e) {
      console.warn(`[Anti-Sticker Delete Error] in ${guild.id}:`, e.message);
    }
  }
};
