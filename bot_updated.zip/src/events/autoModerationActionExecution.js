/**
 * Tungsten AutoModerationActionExecution Event (Node.js)
 * Intercepts Discord native AutoMod gateway execution events,
 * logs violations and punitive actions to designated audit/mod log channels.
 */
const {
  Events,
  AutoModerationActionType,
  AutoModerationRuleTriggerType
} = require('discord.js');
const { getLogChannel } = require('../utils/logRouter');
const { createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const { createCase } = require('../utils/modlog');

const ACTION_NAMES = {
  [AutoModerationActionType.BlockMessage]: 'Blocked Message',
  [AutoModerationActionType.SendAlertMessage]: 'Sent Alert',
  [AutoModerationActionType.Timeout]: 'Timed Out User',
  [AutoModerationActionType.BlockMemberInteraction]: 'Blocked Interaction'
};

const TRIGGER_NAMES = {
  [AutoModerationRuleTriggerType.Keyword]: 'Keyword Filter',
  [AutoModerationRuleTriggerType.Spam]: 'Spam Detection',
  [AutoModerationRuleTriggerType.KeywordPreset]: 'Keyword Preset',
  [AutoModerationRuleTriggerType.MentionSpam]: 'Mention Spam',
  [AutoModerationRuleTriggerType.MemberProfile]: 'Member Profile'
};

module.exports = {
  name: Events.AutoModerationActionExecution,
  async execute(execution, client) {
    if (!execution || !execution.guild) return;

    try {
      const { guild, action, ruleId, ruleTriggerType, userId, channelId, content, matchedKeyword, matchedContent } = execution;

      const actionName = ACTION_NAMES[action?.type] || `Action ${action?.type || 'Unknown'}`;
      const triggerName = TRIGGER_NAMES[ruleTriggerType] || `Trigger ${ruleTriggerType || 'Unknown'}`;

      let caseNum = null;
      try {
        const sdb = getServerDb(guild.id);
        caseNum = createCase(guild.id, sdb, {
          action: 'native_automod',
          targetId: userId || '0',
          moderatorId: client.user?.id || '0',
          reason: `Discord Native AutoMod: ${triggerName} (Rule: ${ruleId})`,
          timestamp: Math.floor(Date.now() / 1000)
        });
      } catch (_) {}

      // Locate destination log channel via logRouter
      const logChannel = getLogChannel(guild, 'log_mod') ||
        getLogChannel(guild, 'log_server') ||
        getLogChannel(guild, 'log_messages');

      if (!logChannel) return;

      const fields = [
        { name: 'Offender', value: `<@${userId}> (\`${userId}\`)`, inline: true },
        { name: 'Channel', value: channelId ? `<#${channelId}>` : 'Unknown', inline: true },
        { name: 'Action Taken', value: `\`${actionName}\``, inline: true },
        {
          name: 'Rule Trigger',
          value: `\`${triggerName}\` • Rule ID: \`${ruleId}\`${caseNum ? ` • Case: \`#${caseNum}\`` : ''}`,
          inline: false
        }
      ];

      const match = matchedKeyword || matchedContent;
      if (match) {
        fields.push({
          name: 'Matched Pattern',
          value: `\`${String(match).slice(0, 250)}\``,
          inline: false
        });
      }

      if (content) {
        const cleanContent = String(content).slice(0, 600).replace(/\n/g, '\n> ');
        fields.push({
          name: 'Message Content',
          value: `> ${cleanContent}`,
          inline: false
        });
      }

      if (action?.metadata?.durationSeconds) {
        fields.push({
          name: 'Timeout Duration',
          value: `\`${action.metadata.durationSeconds} seconds\``,
          inline: true
        });
      }

      const embed = createEmbed({
        color: 0xED4245,
        title: '🛡️ Discord Native AutoMod Execution',
        description: 'A Discord platform-native AutoMod rule was triggered and executed.',
        fields,
        footerText: `User ID: ${userId} • Tungsten Sentinel`
      });

      await logChannel.send({ embeds: [embed] }).catch(() => null);
    } catch (err) {
      console.error('[AutoModerationActionExecution] Error processing event:', err);
    }
  }
};
