/**
 * Role Delete Event (Node.js)
 * Implements Anti-Role Delete Protection & Autonomous Auto-Heal Role Restoration.
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor,
  autoHealRole,
  isAuthorizedDeletion,
  markAuthorizedDeletion,
  isBotDeletedEntity,
  getActiveRaidAttacker
} = require('../utils/antinukeEngine');

// Cooldown tracker to prevent backup role recreation storms (at most once every 15s per guild)
const _BACKUP_ROLE_RECREATE_COOLDOWN = new Map();

module.exports = {
  name: 'roleDelete',
  async execute(role, client) {
    if (!role || !role.guild) return;
    const guild = role.guild;

    if (!isAntinukeArmed(guild.id)) return;

    // Fast-path bypass: If authorized deletion or bot deleted this rogue role, return immediately BEFORE checking backup roles
    if (isAuthorizedDeletion(guild.id, role.id) || isBotDeletedEntity(role.id)) {
      return;
    }

    // Critical Backup Role Safeguard: Recreate backup roles subject to 15s debounce to prevent recreation storm
    const isBackupRole = Boolean(role.name && role.name.includes('Backup Tier'));

    if (isBackupRole) {
      const now = Date.now();
      const lastRecreate = _BACKUP_ROLE_RECREATE_COOLDOWN.get(guild.id) || 0;
      if (now - lastRecreate >= 15000) {
        _BACKUP_ROLE_RECREATE_COOLDOWN.set(guild.id, now);
        const { ensureDualBackupRoles } = require('../utils/antinukeEngine');
        ensureDualBackupRoles(guild, { force: true }).catch(() => null);
      }
    }

    try {
      const rule = getAntinukeRule(guild.id, 'role_delete');
      if (rule && !rule.enabled) return;

      // 1. Resolve executor to check immunity
      let executor = await resolveAuditExecutor(guild, AuditLogEvent.RoleDelete, { targetId: role.id, maxRetries: 3 });

      // Fallback: If audit log is rate-limited (HTTP 429) during raid, check active raid attacker
      if (!executor) {
        const activeAttacker = getActiveRaidAttacker(guild.id);
        if (activeAttacker && activeAttacker.executor) {
          executor = activeAttacker.executor;
        }
      }

      if (executor) {
        if (isImmune(guild, executor.id, 'role')) {
          markAuthorizedDeletion(guild.id, role.id);
          return; // Authorized role deletion
        }

        const exceeded = checkVectorRateLimit(guild.id, executor.id, 'role_delete');
        if (exceeded || !rule || rule.limit_count <= 1) {
          // Attacker is unauthorized: punish attacker immediately
          await punishAttacker(
            guild,
            executor,
            `Deleted role @${role.name || role.id} (${role.id}) without authorization`,
            client,
            'Anti-Role Delete',
            'role_delete',
            null,
            { isBot: executor?.bot }
          );
        }
      }

      // 2. Auto-Heal: Recreate destroyed role if enabled (deduplicated by _AUTO_HEAL_LOCKS; backup roles handled above)
      if (!isBackupRole && rule?.auto_heal !== false && !isAuthorizedDeletion(guild.id, role.id) && !isBotDeletedEntity(role.id)) {
        await autoHealRole(guild, role);
      }
    } catch (e) {
      console.warn(`[Anti-Role Delete Error] in ${guild.id}:`, e.message);
    }
  }
};
