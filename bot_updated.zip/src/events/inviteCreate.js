/**
 * Invite Create Event (Node.js)
 * Implements Anti-Invite Generation Raid Sentinel (C8).
 */
const {
  isAntinukeArmed,
  isImmune,
  punishAttacker,
  checkRateLimitExceeded
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'inviteCreate',
  async execute(invite, client) {
    if (!invite || !invite.guild) return;
    const guild = invite.guild;

    if (!isAntinukeArmed(guild.id)) return;

    const inviter = invite.inviter;
    if (!inviter) return;

    if (isImmune(guild, inviter.id, 'invite')) return;

    // Check rate limit (> 3 invites generated in 10s)
    if (checkRateLimitExceeded(guild.id, inviter.id, 'invite_create', 3, 10000)) {
      await Promise.allSettled([
        invite.delete('Anti-Invite generation spam threshold exceeded.').catch(() => null),
        punishAttacker(guild, inviter, 'Exceeded mass invite creation threshold (spam raid)', client, 'Anti-Invite Raid')
      ]);
    }
  }
};
