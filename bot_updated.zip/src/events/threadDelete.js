/**
 * Thread Delete Event (Node.js)
 * Implements Thread Deletion Monitoring (Roadmap Section 6).
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'threadDelete',
  async execute(thread, client) {
    if (!thread || !thread.guild) return;
    const guild = thread.guild;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const executor = await resolveAuditExecutor(guild, AuditLogEvent.ThreadDelete, { targetId: thread.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'channel')) return;

      const exceeded = checkVectorRateLimit(guild.id, executor.id, 'channel');
      if (exceeded) {
        await punishAttacker(guild, executor, `Mass Thread Deletion of #${thread.name}`, client, 'Anti-Channel Delete', 'channel');
      }
    } catch (e) {
      console.warn(`[threadDelete] Error in ${guild.id}:`, e.message);
    }
  }
};
