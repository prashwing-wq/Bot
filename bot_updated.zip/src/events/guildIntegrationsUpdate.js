/**
 * Guild Integrations Update Event (Node.js)
 * Implements Integration & App Addition Sentinel (Roadmap Section 6).
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'guildIntegrationsUpdate',
  async execute(guild, client) {
    if (!guild) return;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const rule = getAntinukeRule(guild.id, 'bot_add');
      if (rule && !rule.enabled) return;

      const executor = await resolveAuditExecutor(guild, AuditLogEvent.IntegrationCreate);
      if (!executor) return;

      if (isImmune(guild, executor.id, 'bot')) return;

      await punishAttacker(guild, executor, `Added unauthorized integration or application to server`, client, 'Anti-Integration Influx', 'bot');
    } catch (e) {
      console.warn(`[guildIntegrationsUpdate] Error in ${guild.id}:`, e.message);
    }
  }
};
