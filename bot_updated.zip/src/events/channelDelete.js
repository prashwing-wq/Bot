/**
 * Channel Delete Event (Node.js)
 * Implements Anti-Channel Delete Protection & Autonomous Auto-Heal Channel Restoration.
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor,
  autoHealChannel,
  isAuthorizedDeletion,
  markAuthorizedDeletion,
  isBotDeletedEntity,
  getActiveRaidAttacker,
  triggerAutonomousDisasterRecovery
} = require('../utils/antinukeEngine');
const { J2C_RECENT_DELETED_CHANNELS } = require('./voiceStateUpdate');

const _CHANNEL_DELETE_BURST_TRACKER = new Map(); // key: guild.id -> timestamps[]

module.exports = {
  name: 'channelDelete',
  _CHANNEL_DELETE_BURST_TRACKER,
  async execute(channel, client) {
    if (!channel || !channel.guild) return;
    const guild = channel.guild;

    // J2C Fast-path bypass: If recently deleted by J2C or tracked in database voice_rooms
    if (J2C_RECENT_DELETED_CHANNELS && J2C_RECENT_DELETED_CHANNELS.has(channel.id)) {
      markAuthorizedDeletion(guild.id, channel.id);
      return;
    }

    try {
      const sdb = getServerDb(guild.id);
      const isVoiceRoom = sdb.prepare('SELECT 1 FROM voice_rooms WHERE channel_id = ?').get(channel.id);
      if (isVoiceRoom) {
        markAuthorizedDeletion(guild.id, channel.id);
        sdb.prepare('DELETE FROM voice_rooms WHERE channel_id = ?').run(channel.id);
        return; // J2C temporary voice room deletion is authorized
      }
    } catch (_) {}

    if (!isAntinukeArmed(guild.id)) return;

    // Fast-path bypass: If authorized deletion or bot deleted this rogue channel, never auto-heal
    if (isAuthorizedDeletion(guild.id, channel.id) || isBotDeletedEntity(channel.id)) {
      return;
    }

    try {
      const rule = getAntinukeRule(guild.id, 'channel_delete');
      if (rule && !rule.enabled) return;

      // 1. Resolve executor first to determine if action was authorized by owner/whitelisted user
      let executor = await resolveAuditExecutor(guild, AuditLogEvent.ChannelDelete, { targetId: channel.id, maxRetries: 3 });

      // Fallback: If audit log is rate-limited (HTTP 429) during raid, check active raid attacker
      if (!executor) {
        const activeAttacker = getActiveRaidAttacker(guild.id);
        if (activeAttacker && activeAttacker.executor) {
          executor = activeAttacker.executor;
        }
      }

      if (executor) {
        const botId = client?.user?.id;
        if (executor.id === botId || isImmune(guild, executor.id, 'channel', client)) {
          markAuthorizedDeletion(guild.id, channel.id);
          return; // Authorized deletion by owner, bot, or whitelisted staff
        }
      }

      // Track unauthorized channel deletion velocity (10s sliding window)
      const now = Date.now();
      let burst = _CHANNEL_DELETE_BURST_TRACKER.get(guild.id) || [];
      burst = burst.filter(t => now - t < 10000);
      burst.push(now);
      _CHANNEL_DELETE_BURST_TRACKER.set(guild.id, burst);

      const isBurstRaid = burst.length >= 2;

      if (executor) {
        const exceeded = checkVectorRateLimit(guild.id, executor.id, 'channel_delete');
        if (exceeded || !rule || rule.limit_count <= 1 || isBurstRaid) {
          // Attacker is unauthorized: punish attacker immediately
          await punishAttacker(
            guild,
            executor,
            `Deleted channel #${channel.name || channel.id} (${channel.id}) without authorization (mass raid: ${isBurstRaid})`,
            client,
            'Anti-Channel Delete',
            'channel_delete',
            null,
            { isBot: executor?.bot }
          );
        }
      }

      // Mass Channel Deletion Attack detected: engage Autonomous Full-Server Disaster Recovery
      if (isBurstRaid) {
        triggerAutonomousDisasterRecovery(guild, client, 'Mass Channel Deletion Raid').catch(() => null);
      }

      // 2. Auto-Heal: Recreate destroyed channel if enabled (guaranteed zero-fail recreation)
      if (rule?.auto_heal !== false && !isAuthorizedDeletion(guild.id, channel.id) && !isBotDeletedEntity(channel.id)) {
        await autoHealChannel(guild, channel);
      }
    } catch (e) {
      console.warn(`[Anti-Channel Delete Error] in ${guild.id}:`, e.message);
    }
  }
};
