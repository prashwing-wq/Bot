/**
 * Guild Ban Remove Event (Node.js)
 * Implements Anti-Unban Mass Whitelist Bypass Sentinel (C8).
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'guildBanRemove',
  async execute(ban, client) {
    if (!ban || !ban.guild) return;
    const guild = ban.guild;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const victim = ban.user;
      const executor = await resolveAuditExecutor(guild, AuditLogEvent.MemberBanRemove, { targetId: victim?.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'ban')) return;

      // Unauthorized unban: re-ban victim and punish rogue moderator
      await Promise.allSettled([
        punishAttacker(guild, executor, `Unbanned member ${victim.username} (${victim.id}) without authorization`, client, 'Anti-Unban Bypass'),
        guild.bans.create(victim.id, { reason: '[Tungsten Anti-Unban] Re-banning victim unbanned by unauthorized actor.' }).catch(() => null)
      ]);
    } catch (e) {
      console.warn(`[Anti-Ban Remove Error] in ${guild.id}:`, e.message);
    }
  }
};
