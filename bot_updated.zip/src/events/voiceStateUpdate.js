/**
 * Voice State Update Event (Node.js)
 * Implements 24/7 Home Voice Channel auto-reconnection and J2C lifecycle management.
 */
const { GatewayOpcodes, Routes, ChannelType, PermissionsBitField } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { isOwner, getConfig, isExtraOwner } = require('../utils/tools');
const { buildVoiceStudioPayload } = require('../commands/media/voice');
const { buildJ2CRoomPayload } = require('../commands/media/j2c');
const { markAuthorizedDeletion, markBotDeletedEntity } = require('../utils/antinukeEngine');

const _RECONNECT_TIMERS = new Map();
const _AUTO_VOICE_PANELS = new Map(); // key: `${guild.id}:${userId}` -> { channelId, messageId }
const _AUTO_PANEL_DEBOUNCE = new Map(); // key: `${guild.id}:${userId}` -> timeoutId
const _VOICE_SESSIONS = new Map(); // key: `${guild.id}:${userId}` -> { channelId, joinedAt }
const J2C_RECENT_DELETED_CHANNELS = new Set();
const { processVoiceXp } = require('../utils/leveling');

function registerDeletedJ2CChannel(guildId, channelId) {
  if (!channelId) return;
  J2C_RECENT_DELETED_CHANNELS.add(channelId);
  if (guildId) {
    markAuthorizedDeletion(guildId, channelId);
  }
  markBotDeletedEntity(channelId);
  const timer = setTimeout(() => {
    J2C_RECENT_DELETED_CHANNELS.delete(channelId);
  }, 5 * 60 * 1000);
  if (timer?.unref) timer.unref();
}

async function safeDeleteJ2CChannel(guildId, channel, reason) {
  if (!channel) return;
  const chanId = channel.id;
  if (chanId) {
    registerDeletedJ2CChannel(guildId, chanId);
  }
  if (typeof channel.delete === 'function') {
    return await channel.delete(reason).catch(() => null);
  }
}

async function tryMoveMember(newState, member, guild, targetChannel) {
  let lastErr = null;

  // 1. Attempt moving using newState.setChannel(targetChannel) first
  if (newState && typeof newState.setChannel === 'function') {
    try {
      await newState.setChannel(targetChannel);
      return { success: true };
    } catch (err1) {
      lastErr = err1;
    }
  }

  // 2. Fallback to member.voice?.setChannel(targetChannel)
  if (member?.voice && typeof member.voice.setChannel === 'function') {
    try {
      await member.voice.setChannel(targetChannel);
      return { success: true };
    } catch (err2) {
      lastErr = err2;
    }
  }

  // 3. Fallback to guild.members.edit(member.id, { channel: targetChannel.id })
  if (guild?.members && typeof guild.members.edit === 'function') {
    try {
      await guild.members.edit(member.id, { channel: targetChannel.id });
      return { success: true };
    } catch (err3) {
      lastErr = err3;
    }
  }

  return { success: false, error: lastErr || new Error('No voice move method available') };
}

function pruneGhostVoiceRooms(guild, activeChannelIds = []) {
  if (!guild || !guild.id || !guild.channels?.cache) return;
  try {
    const sdb = getServerDb(guild.id);
    const rooms = sdb.prepare('SELECT channel_id FROM voice_rooms WHERE guild_id = ?').all(guild.id);
    if (!rooms || rooms.length === 0) return;
    const activeSet = new Set((Array.isArray(activeChannelIds) ? activeChannelIds : [activeChannelIds]).filter(Boolean));
    for (const r of rooms) {
      if (activeSet.has(r.channel_id)) continue;
      if (!guild.channels.cache.get(r.channel_id)) {
        sdb.prepare('DELETE FROM voice_rooms WHERE channel_id = ?').run(r.channel_id);
        registerDeletedJ2CChannel(guild.id, r.channel_id);
      }
    }
  } catch (_) {}
}

function recordVoiceActivity(guild, memberObj, elapsedSeconds, sdb) {
  if (!memberObj || elapsedSeconds <= 0) return;
  const now = Math.floor(Date.now() / 1000);
  try {
    sdb.prepare(`
      INSERT INTO voice_activity (guild_id, user_id, total_seconds, daily_seconds, weekly_seconds, monthly_seconds, last_joined, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET
        total_seconds = voice_activity.total_seconds + excluded.total_seconds,
        daily_seconds = voice_activity.daily_seconds + excluded.daily_seconds,
        weekly_seconds = voice_activity.weekly_seconds + excluded.weekly_seconds,
        monthly_seconds = voice_activity.monthly_seconds + excluded.monthly_seconds,
        updated_at = excluded.updated_at
    `).run(guild.id, memberObj.id, elapsedSeconds, elapsedSeconds, elapsedSeconds, elapsedSeconds, now, now);

    const row = sdb.prepare('SELECT total_seconds FROM voice_activity WHERE guild_id = ? AND user_id = ?').get(guild.id, memberObj.id);
    if (row && memberObj.roles?.cache) {
      const roles = sdb.prepare('SELECT required_seconds, role_id FROM voice_roles WHERE guild_id = ? AND required_seconds <= ?').all(guild.id, row.total_seconds);
      for (const r of roles) {
        if (!memberObj.roles.cache.has(r.role_id) && memberObj.roles.add) {
          memberObj.roles.add(r.role_id, 'Tungsten Voice Milestone Reward').catch(() => null);
        }
      }
    }
  } catch (_) {}
}

async function cleanupAutoVoicePanel(guild, client, panelKey, fallbackOldChannel) {
  let record = _AUTO_VOICE_PANELS.get(panelKey);
  _AUTO_VOICE_PANELS.delete(panelKey);

  // Check persistent DB record if in-memory record is missing (e.g. after restart)
  if (!record && guild?.id) {
    try {
      const sdb = getServerDb(guild.id);
      const [gid, uid] = panelKey.split(':');
      if (gid && uid) {
        const row = sdb.prepare('SELECT channel_id, message_id FROM auto_voice_panels WHERE guild_id = ? AND user_id = ?').get(gid, uid);
        if (row) record = { channelId: row.channel_id, messageId: row.message_id };
      }
    } catch (_) {}
  }

  // Remove DB record
  if (guild?.id) {
    try {
      const sdb = getServerDb(guild.id);
      const [gid, uid] = panelKey.split(':');
      if (gid && uid) {
        sdb.prepare('DELETE FROM auto_voice_panels WHERE guild_id = ? AND user_id = ?').run(gid, uid);
      }
    } catch (_) {}
  }

  if (!record) return;

  try {
    let targetCh = guild?.channels?.cache?.get(record.channelId);
    if (!targetCh && typeof guild?.channels?.fetch === 'function') {
      targetCh = await guild.channels.fetch(record.channelId).catch(() => null);
    }
    if (!targetCh && client?.channels?.cache) {
      targetCh = client.channels.cache.get(record.channelId);
    }
    if (!targetCh && fallbackOldChannel?.id === record.channelId) {
      targetCh = fallbackOldChannel;
    }

    if (targetCh) {
      if (targetCh.messages && typeof targetCh.messages.fetch === 'function') {
        const prevMsg = await targetCh.messages.fetch(record.messageId).catch(() => null);
        if (prevMsg && typeof prevMsg.delete === 'function') {
          await prevMsg.delete().catch(() => null);
        }
      } else if (typeof targetCh.deleteMessage === 'function') {
        await targetCh.deleteMessage(record.messageId).catch(() => null);
      }
    }
  } catch (delErr) {}
}

module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState, client) {
    const cl = client || newState?.client || oldState?.client;
    const guild = newState?.guild || oldState?.guild;
    if (!guild) return;

    const isBot = Boolean(cl?.user?.id && (newState?.id === cl.user.id || oldState?.id === cl.user.id));

    // 1. Bot 24/7 Keep-Alive & Auto-Reconnect Sentinel
    if (isBot) {
      try {
        const sdb = getServerDb(guild.id);
        const homeVc = sdb.prepare('SELECT channel_id, status_text, enabled FROM home_voice_channels WHERE guild_id = ? AND enabled = 1').get(guild.id);

        if (homeVc && homeVc.channel_id) {
          const currentChannelId = newState.channelId;

          // If bot was disconnected or moved away from its designated 24/7 VC
          if (currentChannelId !== homeVc.channel_id) {
            // Debounce reconnect to prevent spamming the gateway
            if (_RECONNECT_TIMERS.has(guild.id)) {
              clearTimeout(_RECONNECT_TIMERS.get(guild.id));
            }

            const timer = setTimeout(async () => {
              _RECONNECT_TIMERS.delete(guild.id);
              if (!client.guilds.cache.has(guild.id)) return; // Bot left the guild

              const currentMe = guild.members.me;
              if (currentMe?.voice?.channelId !== homeVc.channel_id) {
                const targetChannel = guild.channels.cache.get(homeVc.channel_id)
                  || await guild.channels.fetch(homeVc.channel_id).catch(() => null);
                if (targetChannel && targetChannel.isVoiceBased()) {
                  try {
                    guild.shard.send({
                      op: 4, // VoiceStateUpdate opcode
                      d: {
                        guild_id: guild.id,
                        channel_id: homeVc.channel_id,
                        self_mute: false,
                        self_deaf: true
                      }
                    });

                    sdb.prepare('UPDATE home_voice_channels SET reconnect_count = reconnect_count + 1 WHERE guild_id = ?')
                      .run(guild.id);

                    if (homeVc.status_text && client.rest) {
                      const ping = Math.round(client.ws.ping) || 0;
                      const formatted = homeVc.status_text
                        .replace(/\{ping\}/gi, `${ping}`)
                        .replace(/\{latency\}/gi, `${ping}`)
                        .replace(/\{server\}/gi, guild.name);
                      client.rest.put(Routes.channelVoiceStatus(homeVc.channel_id), { body: { status: formatted } }).catch(() => null);
                    }

                    console.log(`[HomeVC Auto-Heal] Successfully restored 24/7 VC connection in ${guild.name} (${targetChannel.name})`);
                  } catch (recErr) {
                    console.warn(`[HomeVC Auto-Heal] Reconnect warning in ${guild.name}: ${recErr.message}`);
                  }
                }
              }
            }, 2500);

            _RECONNECT_TIMERS.set(guild.id, timer);
          }
        }
      } catch (err) {
        // Safe catch
      }
      return;
    }

    // Feature E: Voice Logging (log_voice, fallback audit_log_channel)
    try {
      if (oldState.channelId !== newState.channelId && newState.member && !newState.member.user?.bot) {
        const { getLogChannel } = require('../utils/logRouter');
        const logChannel = getLogChannel(guild, 'log_voice');
        if (logChannel) {
          const { createEmbed } = require('../utils/tools');
          let title = '<a:tungsten_presence:1569329536875888711> Voice Activity';
          let desc = '';
          if (!oldState.channelId && newState.channelId) {
            title = '<a:tungsten_ui_toggle_on:1569329685110849576> Joined Voice Channel';
            desc = `• **Member:** <@${newState.id}> (\`${newState.id}\`)\n• **Channel:** <#${newState.channelId}>`;
          } else if (oldState.channelId && !newState.channelId) {
            title = '<a:tungsten_ui_toggle_off:1569329677187678368> Left Voice Channel';
            desc = `• **Member:** <@${oldState.id}> (\`${oldState.id}\`)\n• **Channel:** <#${oldState.channelId}>`;
          } else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
            title = '<a:tungsten_refresh:1567241907116187658> Switched Voice Channel';
            desc = `• **Member:** <@${newState.id}> (\`${newState.id}\`)\n• **From:** <#${oldState.channelId}>\n• **To:** <#${newState.channelId}>`;
          }
          if (desc) {
            const embed = createEmbed({
              color: 0x5865f2,
              title,
              description: desc
            });
            await logChannel.send({ embeds: [embed] }).catch(() => null);
          }
        }
      }
    } catch (_) {}

    // 2. Owner & Extra Owner Automatic Voice Control Panel Sentinel
    const userId = newState.id || oldState.id || newState.member?.id || oldState.member?.id || newState.member?.user?.id || oldState.member?.user?.id;
    if (!userId) return;

    // Feature H: Member Voice XP Tracking
    if (!isBot) {
      const sessionKey = `${guild.id}:${userId}`;
      const joinedChannelId = newState.channelId;
      const leftChannelId = oldState.channelId;

      if (!leftChannelId && joinedChannelId) {
        _VOICE_SESSIONS.set(sessionKey, { channelId: joinedChannelId, joinedAt: Date.now() });
      } else if (leftChannelId && joinedChannelId && leftChannelId !== joinedChannelId) {
        const sess = _VOICE_SESSIONS.get(sessionKey);
        if (sess) {
          const elapsedMins = Math.floor((Date.now() - sess.joinedAt) / 60000);
          if (elapsedMins > 0) {
            const sdb = getServerDb(guild.id);
            const memberObj = newState.member || oldState.member || guild.members?.cache?.get(userId);
            if (memberObj) {
              processVoiceXp(guild, memberObj, sess.channelId, elapsedMins, sdb, cl).catch(() => null);
              const elapsedSecs = Math.floor((Date.now() - sess.joinedAt) / 1000);
              recordVoiceActivity(guild, memberObj, elapsedSecs, sdb);
            }
          }
        }
        _VOICE_SESSIONS.set(sessionKey, { channelId: joinedChannelId, joinedAt: Date.now() });
      } else if (leftChannelId && !joinedChannelId) {
        const sess = _VOICE_SESSIONS.get(sessionKey);
        if (sess) {
          _VOICE_SESSIONS.delete(sessionKey);
          const elapsedMins = Math.floor((Date.now() - sess.joinedAt) / 60000);
          if (elapsedMins > 0) {
            const sdb = getServerDb(guild.id);
            const memberObj = oldState.member || newState.member || guild.members?.cache?.get(userId);
            if (memberObj) {
              processVoiceXp(guild, memberObj, sess.channelId, elapsedMins, sdb, cl).catch(() => null);
              const elapsedSecs = Math.floor((Date.now() - sess.joinedAt) / 1000);
              recordVoiceActivity(guild, memberObj, elapsedSecs, sdb);
            }
          }
        }
      }
    }

    // ─────────────────────────────────────────────────────────────
    // Join-to-Create (J2C) Dynamic Voice Room Engine
    // ─────────────────────────────────────────────────────────────
    const member = newState.member || oldState.member;
    if (member && !member.user?.bot) {
      const sdb = getServerDb(guild.id);

      // Database Housekeeping: prune ghost rooms where channel no longer exists in cache
      pruneGhostVoiceRooms(guild, [oldState.channelId, newState.channelId]);

      let j2cHubId = null;
      let j2cCategoryId = null;
      let j2cEnabled = true;
      let j2cUserLimit = 0;
      let j2cBitrate = undefined;
      let j2cNameTemplate = null;

      try {
        const rowHub = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_hub_channel'").get();
        if (rowHub?.value) j2cHubId = rowHub.value;
        const rowCat = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_category'").get();
        if (rowCat?.value) j2cCategoryId = rowCat.value;
        const rowEn = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_enabled'").get();
        if (rowEn) j2cEnabled = rowEn.value === '1';
        const rowLim = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_user_limit'").get();
        if (rowLim?.value) j2cUserLimit = parseInt(rowLim.value, 10) || 0;
        const rowBit = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_bitrate'").get();
        if (rowBit?.value) j2cBitrate = parseInt(rowBit.value, 10) || undefined;
        const rowTmpl = sdb.prepare("SELECT value FROM server_settings WHERE key = 'j2c_name_template'").get();
        if (rowTmpl?.value) j2cNameTemplate = rowTmpl.value;
      } catch (_) {}

      // A. Member joined J2C Hub -> Automatically provision dynamic room
      if (j2cEnabled && newState.channelId && j2cHubId && newState.channelId === j2cHubId) {
        try {
          const hubChannel = newState.channel
            || guild.channels?.cache?.get(newState.channelId)
            || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(newState.channelId).catch(() => null) : null);
          let targetParentId = j2cCategoryId || hubChannel?.parentId || null;
          if (targetParentId && guild.channels?.cache && !guild.channels.cache.has(targetParentId)) {
            targetParentId = null;
          }

          // Prevent ghost rooms: check if member is still connected before channel creation
          const isConnectedBefore = member.voice && ('channelId' in member.voice ? Boolean(member.voice.channelId) : Boolean(newState.channelId));
          if (!isConnectedBefore) return;

          const cleanName = member.displayName ? member.displayName.replace(/[^a-zA-Z0-9 _-]/g, '').trim() : member.user.username;
          const roomName = j2cNameTemplate
            ? j2cNameTemplate.replace(/{user}/gi, cleanName || 'Member').slice(0, 99)
            : `🔊・${cleanName || 'Member'}'s Lounge`;

          const newVoice = await guild.channels.create({
            name: roomName,
            type: ChannelType.GuildVoice,
            parent: targetParentId || undefined,
            userLimit: (j2cUserLimit >= 0 && j2cUserLimit <= 99) ? j2cUserLimit : 0,
            bitrate: (j2cBitrate && j2cBitrate >= 8000 && j2cBitrate <= 384000) ? j2cBitrate : undefined,
            permissionOverwrites: [
              {
                id: guild.id,
                type: 0,
                allow: [
                  PermissionsBitField.Flags.ViewChannel,
                  PermissionsBitField.Flags.Connect,
                  PermissionsBitField.Flags.Speak
                ]
              },
              {
                id: member.id,
                type: 1,
                allow: [
                  PermissionsBitField.Flags.SendMessages,
                  PermissionsBitField.Flags.EmbedLinks,
                  PermissionsBitField.Flags.MoveMembers,
                  PermissionsBitField.Flags.ViewChannel,
                  PermissionsBitField.Flags.Connect,
                  PermissionsBitField.Flags.Speak
                ]
              },
              ...(cl?.user?.id ? [{
                id: cl.user.id,
                type: 1,
                allow: [
                  PermissionsBitField.Flags.SendMessages,
                  PermissionsBitField.Flags.EmbedLinks,
                  PermissionsBitField.Flags.MoveMembers,
                  PermissionsBitField.Flags.ManageChannels,
                  PermissionsBitField.Flags.ViewChannel,
                  PermissionsBitField.Flags.Connect,
                  PermissionsBitField.Flags.Speak
                ]
              }] : [])
            ]
          });

          // Prevent ghost rooms: check if member is still connected after channel creation
          const isConnectedAfter = member.voice && ('channelId' in member.voice ? Boolean(member.voice.channelId) : Boolean(newState.channelId));
          if (!isConnectedAfter) {
            await safeDeleteJ2CChannel(guild.id, newVoice, 'J2C: Member disconnected before move');
            return;
          }

          // Resilient member move: attempt newState.setChannel -> member.voice?.setChannel -> guild.members.edit
          let moveRes = await tryMoveMember(newState, member, guild, newVoice);
          if (!moveRes.success) {
            // If all fail, wait 250ms and retry once before deleting the room
            await new Promise(resolve => setTimeout(resolve, 250));
            moveRes = await tryMoveMember(newState, member, guild, newVoice);
            if (!moveRes.success) {
              const moveErr = moveRes.error || new Error('Failed to move member to dynamic voice channel');
              console.warn('[J2C Move Error]', moveErr.message);
              await safeDeleteJ2CChannel(guild.id, newVoice, 'J2C: Failed to move member to dynamic room');
              return;
            }
          }

          // Record in database
          sdb.prepare('INSERT OR REPLACE INTO voice_rooms (channel_id, owner_id, guild_id, created_at) VALUES (?, ?, ?, ?)').run(
            newVoice.id,
            member.id,
            guild.id,
            Date.now()
          );

          // In-Room Panel Only: post room controls directly into voice channel chat and pin it
          if (typeof newVoice.send === 'function') {
            const roomPayload = buildJ2CRoomPayload(newVoice, member, false, j2cUserLimit);
            const ctrlMsg = await newVoice.send(roomPayload).catch(() => null);
            if (ctrlMsg && typeof ctrlMsg.pin === 'function') {
              ctrlMsg.pin().catch(() => null);
            }
          }
        } catch (j2cErr) {
          console.warn(`[J2C Create Error] in ${guild.id}: ${j2cErr.message}`);
        }
      }

      // B. Member left a voice channel -> Auto-cleanup empty dynamic rooms or transfer ownership
      if (oldState.channelId && oldState.channelId !== newState.channelId) {
        try {
          const roomRecord = sdb.prepare('SELECT owner_id FROM voice_rooms WHERE channel_id = ?').get(oldState.channelId);
          if (roomRecord) {
            const oldChannel = oldState.channel
              || guild.channels?.cache?.get(oldState.channelId)
              || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(oldState.channelId).catch(() => null) : null);
            if (oldChannel) {
              const leaverId = oldState.member?.id || oldState.id || userId;
              let remainingMembers;
              if (oldChannel.members) {
                if (typeof oldChannel.members.filter === 'function') {
                  remainingMembers = oldChannel.members.filter(m => (m.id || m.user?.id) !== leaverId && !m.user?.bot);
                } else {
                  remainingMembers = new Map([...oldChannel.members].filter(([mid, m]) => (m.id || mid) !== leaverId && !m.user?.bot));
                }
              } else {
                remainingMembers = new Map();
              }
              if (typeof remainingMembers.first !== 'function') {
                remainingMembers.first = function() {
                  return this.values().next().value;
                };
              }

              if (remainingMembers.size === 0) {
                sdb.prepare('DELETE FROM voice_rooms WHERE channel_id = ?').run(oldState.channelId);
                await safeDeleteJ2CChannel(guild.id, oldChannel, 'J2C: Dynamic room empty, auto-cleaned');
              } else if (roomRecord.owner_id === leaverId) {
                // The owner left but friends remain! Auto-transfer ownership
                const newOwner = remainingMembers.first();
                if (newOwner) {
                  sdb.prepare('UPDATE voice_rooms SET owner_id = ? WHERE channel_id = ?').run(newOwner.id, oldState.channelId);
                  if (oldChannel.permissionOverwrites && typeof oldChannel.permissionOverwrites.edit === 'function') {
                    await oldChannel.permissionOverwrites.edit(newOwner.id, {
                      ViewChannel: true,
                      Connect: true,
                      Speak: true,
                      MoveMembers: true,
                      SendMessages: true,
                      EmbedLinks: true
                    }).catch(() => null);
                  }
                  if (typeof oldChannel.send === 'function') {
                    await oldChannel.send({
                      content: `<a:tungsten_crown:1567238355463176334> The room owner left. Ownership of **${oldChannel.name}** has been transferred to <@${newOwner.id}>!`
                    }).catch(() => null);
                  }
                }
              }
            } else {
              sdb.prepare('DELETE FROM voice_rooms WHERE channel_id = ?').run(oldState.channelId);
              registerDeletedJ2CChannel(guild.id, oldState.channelId);
            }
          }
        } catch (cleanErr) {
          console.warn(`[J2C Cleanup Error] in ${guild.id}: ${cleanErr.message}`);
        }
      }
    }

    if (newState.member?.user?.bot || oldState.member?.user?.bot) return;

    let isAuthorized = false;
    let roleTitle = 'Owner';

    if (userId === guild.ownerId) {
      isAuthorized = true;
      roleTitle = 'Server Owner';
    } else if (isOwner(userId)) {
      isAuthorized = true;
      roleTitle = 'Bot Owner';
    } else if (isExtraOwner(guild.id, userId)) {
      isAuthorized = true;
      roleTitle = 'Extra Owner';
    }

    if (!isAuthorized) return;

    const panelKey = `${guild.id}:${userId}`;

    // A. User left a voice channel or switched -> Clean up previously auto-deployed panel
    if (oldState.channelId && oldState.channelId !== newState.channelId) {
      if (_AUTO_PANEL_DEBOUNCE.has(panelKey)) {
        clearTimeout(_AUTO_PANEL_DEBOUNCE.get(panelKey));
        _AUTO_PANEL_DEBOUNCE.delete(panelKey);
      }
      await cleanupAutoVoicePanel(guild, cl, panelKey, oldState.channel);
    }

    // B. User joined or switched to a voice channel -> Auto-deploy Voice Control Panel with debounce
    if (newState.channelId && newState.channelId !== oldState.channelId) {
      if (_AUTO_PANEL_DEBOUNCE.has(panelKey)) {
        clearTimeout(_AUTO_PANEL_DEBOUNCE.get(panelKey));
        _AUTO_PANEL_DEBOUNCE.delete(panelKey);
      }

      const targetChannelId = newState.channelId;
      const timer = setTimeout(async () => {
        _AUTO_PANEL_DEBOUNCE.delete(panelKey);
        if (cl?.guilds?.cache && !cl.guilds.cache.has(guild.id)) return;

        // Verify member is still connected in this voice channel
        const member = newState.member
          || guild.members?.cache?.get(userId)
          || (typeof guild.members?.fetch === 'function' ? await guild.members.fetch(userId).catch(() => null) : null);
        if (!member) return;

        const curChannelId = guild.voiceStates?.cache?.get(userId)?.channelId
          || member.voice?.channelId
          || (member.voice ? null : newState.channelId);
        if (!curChannelId || curChannelId !== targetChannelId) return;

        let voiceChannel = guild.channels?.cache?.get(targetChannelId);
        if (!voiceChannel && typeof guild.channels?.fetch === 'function') {
          voiceChannel = await guild.channels.fetch(targetChannelId).catch(() => null);
        }
        if (!voiceChannel && cl?.channels?.cache) {
          voiceChannel = cl.channels.cache.get(targetChannelId);
        }
        if (!voiceChannel) {
          voiceChannel = newState.channel?.id === targetChannelId ? newState.channel : member.voice?.channel;
        }

        if (!voiceChannel || typeof voiceChannel.send !== 'function') return;

        try {
          // Clean up any remaining previous panel before posting the new one
          await cleanupAutoVoicePanel(guild, cl, panelKey, null);

          const guildConfig = getConfig(guild.id);
          const prefix = guildConfig?.prefix || cl?.config?.DEFAULT_PREFIX || '!';
          const payload = buildVoiceStudioPayload(guild, member, prefix, { roleTitle });
          const sentMsg = await voiceChannel.send(payload);
          if (!sentMsg) return;

          // Post-send race condition defense: Verify member hasn't disconnected during HTTP send
          const activeVoiceId = guild.voiceStates?.cache?.get(userId)?.channelId
            || member.voice?.channelId;

          if (activeVoiceId !== undefined && activeVoiceId !== targetChannelId) {
            // User disconnected or moved while message was in flight
            if (typeof sentMsg.delete === 'function') {
              await sentMsg.delete().catch(() => null);
            }
            return;
          }

          _AUTO_VOICE_PANELS.set(panelKey, {
            channelId: targetChannelId,
            messageId: sentMsg.id
          });

          try {
            const sdb = getServerDb(guild.id);
            sdb.prepare('INSERT OR REPLACE INTO auto_voice_panels (guild_id, user_id, channel_id, message_id, created_at) VALUES (?, ?, ?, ?, ?)')
              .run(guild.id, userId, targetChannelId, sentMsg.id, Math.floor(Date.now() / 1000));
          } catch (_) {}
        } catch (sendErr) {
          console.warn(`[Voice Auto-Deploy] Could not deploy panel in ${guild.name} (#${voiceChannel.name}): ${sendErr.message}`);
        }
      }, 1500);

      _AUTO_PANEL_DEBOUNCE.set(panelKey, timer);
    }
  },
  async initVoiceSessions(client) {
    if (!client || !client.guilds?.cache) return;
    const now = Date.now();
    for (const guild of client.guilds.cache.values()) {
      if (!guild.channels?.cache) continue;
      for (const channel of guild.channels.cache.values()) {
        if (typeof channel.isVoiceBased === 'function' && channel.isVoiceBased() && channel.members) {
          for (const [memberId, member] of channel.members) {
            if (!member.user?.bot) {
              _VOICE_SESSIONS.set(`${guild.id}:${memberId}`, { channelId: channel.id, joinedAt: now });
            }
          }
        }
      }

      // Database Housekeeping: prune ghost rooms from voice_rooms where guild.channels.cache.get(channel_id) no longer exists
      pruneGhostVoiceRooms(guild);

      // Reconcile auto_voice_panels across bot restarts
      try {
        const sdb = getServerDb(guild.id);
        const rows = sdb.prepare('SELECT user_id, channel_id, message_id FROM auto_voice_panels WHERE guild_id = ?').all(guild.id);
        for (const row of rows) {
          const pKey = `${guild.id}:${row.user_id}`;
          const currentVoiceId = guild.voiceStates?.cache?.get(row.user_id)?.channelId
            || guild.members?.cache?.get(row.user_id)?.voice?.channelId;
          if (currentVoiceId === row.channel_id) {
            _AUTO_VOICE_PANELS.set(pKey, { channelId: row.channel_id, messageId: row.message_id });
          } else {
            sdb.prepare('DELETE FROM auto_voice_panels WHERE guild_id = ? AND user_id = ?').run(guild.id, row.user_id);
            const ch = guild.channels?.cache?.get(row.channel_id)
              || (typeof guild.channels?.fetch === 'function' ? await guild.channels.fetch(row.channel_id).catch(() => null) : null);
            if (ch?.messages?.fetch) {
              const prevM = await ch.messages.fetch(row.message_id).catch(() => null);
              if (prevM && typeof prevM.delete === 'function') {
                await prevM.delete().catch(() => null);
              }
            }
          }
        }
      } catch (_) {}
    }
  },
  pruneGhostVoiceRooms,
  J2C_RECENT_DELETED_CHANNELS,
  _VOICE_SESSIONS,
  _AUTO_VOICE_PANELS,
  _AUTO_PANEL_DEBOUNCE
};
