/**
 * User Update Event (Node.js)
 * Implements Global User Identity & Avatar Change Tracking (Roadmap Section 6 / Review 2.6).
 */
const { createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');

module.exports = {
  name: 'userUpdate',
  async execute(oldUser, newUser, client) {
    if (!newUser || newUser.bot) return;

    const usernameChanged = oldUser.username !== newUser.username;
    const globalNameChanged = oldUser.globalName !== newUser.globalName;
    const avatarChanged = oldUser.avatar !== newUser.avatar;

    if (!usernameChanged && !globalNameChanged && !avatarChanged) return;

    // Find mutual guilds where audit logging is enabled
    for (const guild of client.guilds.cache.values()) {
      try {
        const member = guild.members.cache.get(newUser.id);
        if (!member) continue;

        const sdb = getServerDb(guild.id);
        const logRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'log_members' OR key = 'audit_log_channel'").get();
        if (!logRow || !logRow.value) continue;

        const channel = guild.channels.cache.get(logRow.value);
        if (!channel || !channel.isTextBased()) continue;

        const fields = [];
        if (usernameChanged) {
          fields.push({
            name: 'Username Changed',
            value: `**Old:** \`${oldUser.username}\`\n**New:** \`${newUser.username}\``,
            inline: true
          });
        }
        if (globalNameChanged) {
          fields.push({
            name: 'Display Name Changed',
            value: `**Old:** \`${oldUser.globalName || 'None'}\`\n**New:** \`${newUser.globalName || 'None'}\``,
            inline: true
          });
        }
        if (avatarChanged) {
          fields.push({
            name: 'Avatar Updated',
            value: `[Old Avatar](${oldUser.displayAvatarURL()}) ➔ [New Avatar](${newUser.displayAvatarURL()})`,
            inline: false
          });
        }

        const embed = createEmbed({
          color: 0x5865F2,
          title: '👤  User Profile Updated',
          description: `User <@${newUser.id}> (\`${newUser.id}\`) modified their profile.`,
          fields,
          thumbnail: newUser.displayAvatarURL(),
          footerText: `User ID: ${newUser.id} • Tungsten Identity Sentinel`
        });

        await channel.send({ embeds: [embed] }).catch(() => null);
      } catch (_) {}
    }
  }
};
