/**
 * Role Update Event (Node.js)
 * Implements Anti-Role Permission Tampering & Unauthorized Escalation Sentinel (C8).
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent, PermissionsBitField } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  punishAttacker,
  resolveAuditExecutor,
  cacheRoleSnapshot
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'roleUpdate',
  async execute(oldRole, newRole, client) {
    if (!newRole || !newRole.guild) return;
    const guild = newRole.guild;

    cacheRoleSnapshot(newRole);

    if (!isAntinukeArmed(guild.id)) return;

    const rule = getAntinukeRule(guild.id, 'role_update');
    if (rule && !rule.enabled) return;

    // Check if dangerous permissions were added
    const dangerousPerms = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.ManageGuild,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.ManageWebhooks,
      PermissionsBitField.Flags.MentionEveryone
    ];

    const addedDangerous = dangerousPerms.filter(p => !oldRole.permissions.has(p) && newRole.permissions.has(p));
    if (addedDangerous.length === 0) return;

    // Zero-day safeguard for @everyone role: revert immediately
    if (newRole.id === guild.id) {
      await newRole.setPermissions(oldRole.permissions, '[Tungsten Zero-Day Escalation Reversion] Blocked dangerous permissions added to @everyone.').catch(() => null);
    }

    try {
      const executor = await resolveAuditExecutor(guild, AuditLogEvent.RoleUpdate, { targetId: newRole.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'role')) return;

      // Revert permissions IMMEDIATELY if auto_heal is enabled
      if (rule?.auto_heal) {
        await newRole.setPermissions(oldRole.permissions, '[Tungsten Anti-Escalation] Reverted unauthorized privilege escalation.').catch(() => null);
      }

      // Punish attacker with configured antinuke action
      await punishAttacker(guild, executor, `Injected dangerous permissions into @${newRole.name} without authorization`, client, 'Anti-Role Escalation', 'role_update');
    } catch (e) {
      console.warn(`[Anti-Role Update Error] in ${guild.id}:`, e.message);
    }
  }
};
