/**
 * Message Delete Event (Node.js)
 * Caches deleted messages for snipe recovery and exposes ghostpings in real-time.
 */
const { EmbedBuilder } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { retrieveAndEvictGhostping } = require('../utils/ghostpingCache');

module.exports = {
  name: 'messageDelete',
  async execute(message, client) {
    if (!message || !message.guild || !message.channel) return;
    if (message.author?.bot) return;

    try {
      const sdb = getServerDb(message.guild.id);

      // 1. Store in Snipe Cache (if author is cached and known)
      if (message.author) {
        const attachments = message.attachments?.size > 0 ? message.attachments.map(a => a.url).join(' ') : null;
        sdb.prepare(`
          INSERT INTO sniped_messages (channel_id, content, author_id, author_tag, timestamp, attachments)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(channel_id) DO UPDATE SET
            content = excluded.content,
            author_id = excluded.author_id,
            author_tag = excluded.author_tag,
            timestamp = excluded.timestamp,
            attachments = excluded.attachments
        `).run(
          message.channel.id,
          message.content || '[No text content]',
          message.author.id,
          message.author.username,
          Math.floor(Date.now() / 1000),
          attachments
        );

        // 2. Anti-Ghostping Sentinel Interception
        const ghostData = retrieveAndEvictGhostping(message.id);
        if (ghostData) {
          const row = sdb.prepare("SELECT value FROM server_settings WHERE key = 'antighostping_status'").get();
          const isArmed = row ? row.value === '1' : false;

          if (isArmed) {
            const embed = new EmbedBuilder()
              .setColor(0xFF3366)
              .setTitle('👻  Ghostping Intercepted!')
              .setDescription(
                `> A message with user mentions was deleted in this channel.\n\n` +
                `• **Offender:** <@${ghostData.authorId}> (\`${ghostData.authorTag}\`)\n` +
                `• **Pinged Members:** ${ghostData.mentions.map(m => `<@${m.id}>`).join(', ')}\n\n` +
                `**Message Content:**\n${ghostData.content}`
              )
              .setTimestamp()
              .setFooter({ text: 'Tungsten Anti-Ghostping Protection' });

            if (ghostData.authorAvatar) {
              embed.setThumbnail(ghostData.authorAvatar);
            }

            await message.channel.send({ embeds: [embed] }).catch(() => null);
          }
        }
      }

      // 3. Starboard Eviction on Message Deletion (always runs regardless of author caching)
      const starRow = sdb.prepare('SELECT star_message_id, star_channel_id FROM starboard_messages WHERE guild_id = ? AND orig_message_id = ?')
        .get(message.guild.id, message.id);
      if (starRow) {
        const starChan = message.guild.channels.cache.get(starRow.star_channel_id) ||
          await message.guild.channels.fetch(starRow.star_channel_id).catch(() => null);
        if (starChan && starChan.isTextBased()) {
          const starMsg = await starChan.messages.fetch(starRow.star_message_id).catch(() => null);
          if (starMsg) {
            await starMsg.delete().catch(() => null);
          }
        }
        sdb.prepare('DELETE FROM starboard_messages WHERE guild_id = ? AND orig_message_id = ?')
          .run(message.guild.id, message.id);
      }
    } catch (e) {}
  }
};
