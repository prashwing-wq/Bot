/**
 * Message Create Event (Prefix, Command Dispatcher & Mention Reminders)
 */
const { Collection, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle, AuditLogEvent } = require('discord.js');
const { getConfig, blacklistCheck, ignoreCheck, isOwner, isNoPrefix, hasPerm, createEmbed } = require('../utils/tools');
const { sanitizeUiPayload, EMOJIS, replaceEmojis, resolveEmoji } = require('../utils/emojis');
const { formatPlaceholders } = require('../utils/placeholders');
const { handleMessageMentions, handleBotMention } = require('../utils/mentionSender');
const { getAfkStatus, clearAfkStatus, incrementAfkMentions } = require('../utils/pingsDb');
const { getServerDb } = require('../utils/serverDb');
const { storeGhostpingCandidate } = require('../utils/ghostpingCache');
const { runAutomodCheck, isAutomodDeleted, INVITE_REGEX } = require('../utils/automodEngine');
const {
  isAntinukeArmed,
  isImmune,
  punishAttacker,
  resolveAuditExecutor,
  getActiveRaidAttacker,
  recordActiveRaidAttacker,
  triggerAutonomousDisasterRecovery
} = require('../utils/antinukeEngine');
const { getSetting } = require('../settings/registry');
const { isModuleEnabled } = require('../utils/modulesHelper');
const { incrementCommandCount, incrementErrorCount } = require('../utils/httpServer');
const { processChatXp } = require('../utils/leveling');
const { evaluateOverride } = require('../utils/commandOverrides');
const { checkCommandSpam, SPAM_LOCKOUT_MESSAGE } = require('../utils/commandSpamBlocker');

// Channel sticky message lock to avoid double reposts
const _STICKY_LOCKS = new Set();

const DIRECT_COMMAND_ROUTES = {
  // MongoDB Atlas Manager
  mongo: { cmd: 'mongo', args: [] },
  mongodb: { cmd: 'mongo', args: [] },
  atlas: { cmd: 'mongo', args: [] },
  // Settings Export / Import
  settingsexport: { cmd: 'template', args: ['export'] },
  settingsimport: { cmd: 'template', args: ['import'] },
  settings_export: { cmd: 'template', args: ['export'] },
  settings_import: { cmd: 'template', args: ['import'] },
  // Automod Panel Shortcuts
  automodpanel: { cmd: 'automod', args: ['panel'] },
  automod_panel: { cmd: 'automod', args: ['panel'] },
  automoddashboard: { cmd: 'automod', args: ['panel'] },
  // Security & Antinuke
  andashboard: { cmd: 'antinuke', args: ['panel'] },
  anpanel: { cmd: 'antinuke', args: ['panel'] },
  anui: { cmd: 'antinuke', args: ['panel'] },
  antinukepanel: { cmd: 'antinuke', args: ['panel'] },
  antinuke: { cmd: 'antinuke', args: [] },
  an: { cmd: 'antinuke', args: [] },
  anmode: { cmd: 'anmode', args: [] },
  antimode: { cmd: 'anmode', args: [] },
  defmode: { cmd: 'anmode', args: [] },
  securitymode: { cmd: 'anmode', args: [] },
  anaudit: { cmd: 'anaudit', args: [] },
  secscan: { cmd: 'anaudit', args: [] },
  diagnostics: { cmd: 'anaudit', args: [] },
  vaudit: { cmd: 'anaudit', args: [] },
  serverdoctor: { cmd: 'serverdoctor', args: [] },
  doctor: { cmd: 'serverdoctor', args: [] },
  guilddoctor: { cmd: 'serverdoctor', args: [] },
  whitelist: { cmd: 'whitelist', args: [] },
  wl: { cmd: 'whitelist', args: [] },
  wlpanel: { cmd: 'whitelist', args: ['panel'] },
  wloverview: { cmd: 'whitelist', args: ['overview'] },
  whitelisted: { cmd: 'whitelisted', args: [] },
  extraowner: { cmd: 'extraowner', args: [] },
  extraown: { cmd: 'extraowner', args: [] },
  panic: { cmd: 'panic', args: [] },
  emergency: { cmd: 'emergency', args: [] },
  mainrole: { cmd: 'mainrole', args: [] },
  antibot: { cmd: 'antibot', args: [] },
  ignore: { cmd: 'ignore', args: [] },
  security: { cmd: 'antinuke', args: ['config'] },
  // Moderation
  k: { cmd: 'kick', args: [] },
  b: { cmd: 'ban', args: [] },
  ub: { cmd: 'unban', args: [] },
  m: { cmd: 'mute', args: [] },
  um: { cmd: 'unmute', args: [] },
  w: { cmd: 'warn', args: [] },
  bal: { cmd: 'balance', args: [] },
  dep: { cmd: 'deposit', args: [] },
  override: { cmd: 'override', args: [] },
  overrides: { cmd: 'override', args: ['list'] },
  cmdoverride: { cmd: 'override', args: [] },
  rep: { cmd: 'rep', args: [] },
  reputation: { cmd: 'rep', args: [] },
  giverep: { cmd: 'rep', args: [] },
  cm: { cmd: 'cm', args: ['panel'] },
  cmpanel: { cmd: 'cm', args: ['panel'] },
  custommod: { cmd: 'cm', args: ['panel'] },
  custommoderation: { cmd: 'cm', args: ['panel'] },
  cmsetup: { cmd: 'cm', args: ['setup'] },
  tungmod: { cmd: 'tungmod', args: [] },
  tungstenmod: { cmd: 'tungmod', args: [] },
  tungmodpanel: { cmd: 'tungmod', args: [] },
  modpanel: { cmd: 'modpanel', args: [] },
  moderationpanel: { cmd: 'modpanel', args: [] },
  mpanel: { cmd: 'modpanel', args: [] },
  moddashboard: { cmd: 'modpanel', args: [] },
  modgui: { cmd: 'modpanel', args: [] },
  policy: { cmd: 'policy', args: [] },
  policies: { cmd: 'policy', args: ['list'] },
  modpolicy: { cmd: 'policy', args: [] },
  macro: { cmd: 'macro', args: [] },
  macros: { cmd: 'macro', args: ['list'] },
  macrorun: { cmd: 'macro', args: ['run'] },
  macrolist: { cmd: 'macro', args: ['list'] },
  macrocreate: { cmd: 'macro', args: ['create'] },
  macrodelete: { cmd: 'macro', args: ['delete'] },
  watchlist: { cmd: 'watchlist', args: [] },
  watch: { cmd: 'watchlist', args: [] },
  // Channels
  lockall: { cmd: 'lock', args: ['all'] },
  unlockall: { cmd: 'unlock', args: ['all'] },
  hideall: { cmd: 'hide', args: ['all'] },
  unhideall: { cmd: 'unhide', args: ['all'] },
  thread: { cmd: 'thread', args: [] },
  threads: { cmd: 'thread', args: [] },
  threadcreate: { cmd: 'thread', args: ['create'] },
  threadarchive: { cmd: 'thread', args: ['archive'] },
  threadunarchive: { cmd: 'thread', args: ['unarchive'] },
  threadlock: { cmd: 'thread', args: ['lock'] },
  threadrename: { cmd: 'thread', args: ['rename'] },
  threadlist: { cmd: 'thread', args: ['list'] },
  forum: { cmd: 'forum', args: [] },
  forums: { cmd: 'forum', args: [] },
  forumpost: { cmd: 'forum', args: ['post'] },
  forumtags: { cmd: 'forum', args: ['tags'] },
  forumguidelines: { cmd: 'forum', args: ['guidelines'] },
  // Automation & Tags
  tag: { cmd: 'tag', args: [] },
  tags: { cmd: 'tag', args: [] },
  taglist: { cmd: 'tag', args: ['list'] },
  tagadd: { cmd: 'tag', args: ['add'] },
  tagcreate: { cmd: 'tag', args: ['add'] },
  tagdelete: { cmd: 'tag', args: ['delete'] },
  tagdel: { cmd: 'tag', args: ['delete'] },
  tagedit: { cmd: 'tag', args: ['edit'] },
  tagraw: { cmd: 'tag', args: ['raw'] },
  tagalias: { cmd: 'tag', args: ['alias'] },
  autoreact: { cmd: 'autoreact', args: [] },
  react: { cmd: 'autoreact', args: [] },
  // Voice Management & Moderation
  vdrag: { cmd: 'vdrag', args: [] },
  voicedrag: { cmd: 'vdrag', args: [] },
  drag: { cmd: 'vdrag', args: [] },
  vcmove: { cmd: 'vdrag', args: [] },
  movevc: { cmd: 'vdrag', args: [] },
  dragall: { cmd: 'vdrag', args: ['all'] },
  vcmute: { cmd: 'vcmute', args: [] },
  vmute: { cmd: 'vcmute', args: [] },
  voicemute: { cmd: 'vcmute', args: [] },
  vcunmute: { cmd: 'vcunmute', args: [] },
  vunmute: { cmd: 'vcunmute', args: [] },
  voiceunmute: { cmd: 'vcunmute', args: [] },
  vcdeafen: { cmd: 'vcdeafen', args: [] },
  vdeafen: { cmd: 'vcdeafen', args: [] },
  voicedeafen: { cmd: 'vcdeafen', args: [] },
  vcundeafen: { cmd: 'vcdeafen', args: ['undeafen'] },
  vundeafen: { cmd: 'vcdeafen', args: ['undeafen'] },
  vckick: { cmd: 'vckick', args: [] },
  vkick: { cmd: 'vckick', args: [] },
  voicekick: { cmd: 'vckick', args: [] },
  vcdisconnect: { cmd: 'vckick', args: [] },
  vdisconnect: { cmd: 'vckick', args: [] },
  muteall: { cmd: 'vcmute', args: ['all'] },
  unmuteall: { cmd: 'vcunmute', args: ['all'] },
  deafenall: { cmd: 'vcdeafen', args: ['all'] },
  undeafenall: { cmd: 'vcdeafen', args: ['all', 'undeafen'] },
  vckickall: { cmd: 'vckick', args: ['all'] },
  kickallvc: { cmd: 'vckick', args: ['all'] },
  disconnectall: { cmd: 'vckick', args: ['all'] },
  moveall: { cmd: 'vdrag', args: ['all'] },
  j2c: { cmd: 'j2c', args: [] },
  jointocreate: { cmd: 'j2c', args: [] },
  voicemaster: { cmd: 'j2c', args: [] },
  vm: { cmd: 'j2c', args: [] },
  permit: { cmd: 'whitelist', args: [] },
  j2cpanel: { cmd: 'j2c', args: ['panel'] },
  setj2c: { cmd: 'j2c', args: ['hub'] },
  j2csetup: { cmd: 'j2c', args: ['panel'] },
  // Roles & Shortcuts
  setup: { cmd: 'setup', args: [] },
  staff: { cmd: 'staff', args: [] },
  girl: { cmd: 'girl', args: [] },
  friend: { cmd: 'friend', args: [] },
  vip: { cmd: 'vip', args: [] },
  guest: { cmd: 'guest', args: [] },
  vanityroles: { cmd: 'vanityroles', args: [] },
  vanityrole: { cmd: 'vanityroles', args: [] },
  autorole: { cmd: 'autorole', args: [] },
  autorolepanel: { cmd: 'autorole', args: ['panel'] },
  autorole_panel: { cmd: 'autorole', args: ['panel'] },
  autorolestudio: { cmd: 'autorole', args: ['panel'] },
  // Reaction Roles & RRPanel
  rrpanel: { cmd: 'reactionrole', args: ['panel'] },
  rpanel: { cmd: 'reactionrole', args: ['panel'] },
  rolepanel: { cmd: 'reactionrole', args: ['panel'] },
  reactionrole: { cmd: 'reactionrole', args: [] },
  rr: { cmd: 'reactionrole', args: [] },
  selfrole: { cmd: 'reactionrole', args: [] },
  // Tickets & Welcomer
  ticketpanel: { cmd: 'ticket', args: ['panel'] },
  ticketsetup: { cmd: 'ticket', args: ['panel'] },
  welcomepanel: { cmd: 'welcome', args: ['panel'] },
  welcomesetup: { cmd: 'welcome', args: ['panel'] },
  leavepanel: { cmd: 'leave', args: ['panel'] },
  leavesetup: { cmd: 'leave', args: ['panel'] },
  // Panels
  panel: { cmd: 'panel', args: [] },
  settings: { cmd: 'panel', args: [] },
  config: { cmd: 'panel', args: [] },
  dashboard: { cmd: 'panel', args: [] },
  studio: { cmd: 'panel', args: [] },
  ownerpanel: { cmd: 'ownerpanel', args: [] },
  // No-Prefix & NP Manager
  np: { cmd: 'noprefix', args: [] },
  noprefix: { cmd: 'noprefix', args: [] },
  nppanel: { cmd: 'noprefix', args: ['panel'] },
  npmanager: { cmd: 'noprefix', args: ['manager'] },
  npm: { cmd: 'noprefix', args: ['manager'] },
  'np-manager': { cmd: 'noprefix', args: ['manager'] },
  np_manager: { cmd: 'noprefix', args: ['manager'] },
  npstudio: { cmd: 'noprefix', args: ['manager', 'panel'] },
  // Bot Invites & Support Server
  invite: { cmd: 'invite', args: [] },
  'invite-bot': { cmd: 'invite', args: [] },
  botinvite: { cmd: 'invite', args: [] },
  inv: { cmd: 'invite', args: [] },
  addbot: { cmd: 'invite', args: [] },
  support: { cmd: 'support', args: [] },
  supportserver: { cmd: 'support', args: [] },
  'support-server': { cmd: 'support', args: [] },
  community: { cmd: 'support', args: [] },
  supp: { cmd: 'support', args: [] },
  // Emojis & Steal Suite
  addemoji: { cmd: 'addemoji', args: [] },
  steal: { cmd: 'steal', args: [] },
  eadd: { cmd: 'addemoji', args: [] },
  emojiadd: { cmd: 'addemoji', args: [] },
  createemoji: { cmd: 'addemoji', args: [] },
  emojilist: { cmd: 'emojilist', args: [] },
  emojis: { cmd: 'emojilist', args: [] },
  serveremojis: { cmd: 'emojilist', args: [] },
  listemojis: { cmd: 'emojilist', args: [] },
  deleteemoji: { cmd: 'deleteemoji', args: [] },
  delemoji: { cmd: 'deleteemoji', args: [] },
  emojipack: { cmd: 'emojipack', args: [] },
  emojispack: { cmd: 'emojipack', args: [] },
  emojisetup: { cmd: 'emojipack', args: [] },
  emojiserver: { cmd: 'emojiserver', args: [] },
  emojiservers: { cmd: 'emojiserver', args: [] },
  syncemojis: { cmd: 'emojiserver', args: ['sync'] },
  emojisync: { cmd: 'emojiserver', args: ['sync'] },
  // Giveaways
  gstart: { cmd: 'giveaway', args: ['start'] },
  gend: { cmd: 'gend', args: [] },
  greroll: { cmd: 'greroll', args: [] },
  gpause: { cmd: 'giveaway', args: ['pause'] },
  gresume: { cmd: 'giveaway', args: ['resume'] },
  // Leveling
  levelrole: { cmd: 'levelrole', args: [] },
  levelroles: { cmd: 'levelrole', args: [] },
  lvlrole: { cmd: 'levelrole', args: [] },
  noxp: { cmd: 'noxp', args: [] },
  ignorexp: { cmd: 'noxp', args: [] },
  xpmulti: { cmd: 'xpmulti', args: [] },
  xpmultiplier: { cmd: 'xpmulti', args: [] },
  // Economy Shop & Deep Economy Suite
  shop: { cmd: 'shop', args: [] },
  store: { cmd: 'shop', args: [] },
  market: { cmd: 'shop', args: [] },
  buy: { cmd: 'buy', args: [] },
  purchase: { cmd: 'buy', args: [] },
  inventory: { cmd: 'inventory', args: [] },
  backpack: { cmd: 'inventory', args: [] },
  bag: { cmd: 'inventory', args: [] },
  heist: { cmd: 'crime', args: [] },
  crime: { cmd: 'crime', args: [] },
  stocks: { cmd: 'stocks', args: [] },
  stock: { cmd: 'stocks', args: [] },
  shares: { cmd: 'stocks', args: [] },
  crypto: { cmd: 'crypto', args: [] },
  btc: { cmd: 'crypto', args: [] },
  eth: { cmd: 'crypto', args: [] },
  realestate: { cmd: 'realestate', args: [] },
  buyhouse: { cmd: 'realestate', args: [] },
  properties: { cmd: 'realestate', args: [] },
  jobs: { cmd: 'jobs', args: [] },
  job: { cmd: 'jobs', args: [] },
  career: { cmd: 'jobs', args: [] },
  fish: { cmd: 'fish', args: [] },
  fishing: { cmd: 'fish', args: [] },
  hunt: { cmd: 'hunt', args: [] },
  hunting: { cmd: 'hunt', args: [] },
  bankupgrade: { cmd: 'bankupgrade', args: [] },
  upgradebank: { cmd: 'bankupgrade', args: [] },
  loan: { cmd: 'loan', args: [] },
  bankloan: { cmd: 'loan', args: [] },
  // Standalone Automod Shortcuts
  anticaps: { cmd: 'anticaps', args: [] },
  antispam: { cmd: 'antispam', args: [] },
  antilink: { cmd: 'antilink', args: [] },
  antiinvite: { cmd: 'antiinvite', args: [] },
  antimassmention: { cmd: 'antimassmention', args: [] },
  antimention: { cmd: 'antimassmention', args: [] },
  antiemojispam: { cmd: 'antiemojispam', args: [] },
  antiemoji: { cmd: 'antiemojispam', args: [] },
  antinsfw: { cmd: 'antinsfw', args: [] },
  antibadwords: { cmd: 'antibadwords', args: [] },
  badwordsfilter: { cmd: 'antibadwords', args: [] },
  bannedwords: { cmd: 'antibadwords', args: [] },
  antigif: { cmd: 'antigif', args: [] },
  nogif: { cmd: 'antigif', args: [] },
  // Native Discord Platform (AutoMod, Events, Polls)
  nativeautomod: { cmd: 'nativeautomod', args: [] },
  nam: { cmd: 'nativeautomod', args: [] },
  nativeam: { cmd: 'nativeautomod', args: [] },
  discordautomod: { cmd: 'nativeautomod', args: [] },
  discordevent: { cmd: 'discordevent', args: [] },
  event: { cmd: 'discordevent', args: [] },
  events: { cmd: 'discordevent', args: ['list'] },
  scheduledevent: { cmd: 'discordevent', args: [] },
  discordpoll: { cmd: 'discordpoll', args: [] },
  dpoll: { cmd: 'discordpoll', args: [] },
  nativepoll: { cmd: 'discordpoll', args: [] },
  // Mod Panels & Mass Unban
  banpanel: { cmd: 'banpanel', args: [] },
  kickpanel: { cmd: 'kickpanel', args: [] },
  mutepanel: { cmd: 'mutepanel', args: [] },
  timeoutpanel: { cmd: 'mutepanel', args: [] },
  warnpanel: { cmd: 'warnpanel', args: [] },
  purgepanel: { cmd: 'purgepanel', args: [] },
  clearpanel: { cmd: 'purgepanel', args: [] },
  lockpanel: { cmd: 'lockpanel', args: [] },
  modrolepanel: { cmd: 'modrolepanel', args: [] },
  unbanall: { cmd: 'unbanall', args: [] },
  massunban: { cmd: 'unbanall', args: [] },
  // Voice Activity & 24/7 Voice
  vclb: { cmd: 'vclb', args: [] },
  voicelb: { cmd: 'leaderboard', args: ['voice'] },
  vcstats: { cmd: 'vcstats', args: [] },
  dailyvoice: { cmd: 'vcstats', args: [] },
  weeklyvoice: { cmd: 'vcstats', args: [] },
  monthlyvoice: { cmd: 'vcstats', args: [] },
  addvctime: { cmd: 'addvctime', args: [] },
  reducevctime: { cmd: 'reducevctime', args: [] },
  setvoicerole: { cmd: 'setvoicerole', args: [] },
  resetvoice: { cmd: 'resetvoice', args: [] },
  clearvoice: { cmd: 'resetvoice', args: [] },
  sethomevc: { cmd: 'sethomevc', args: [] },
  homevcset: { cmd: 'sethomevc', args: [] },
  '247vc': { cmd: 'sethomevc', args: [] },
  resethomevc: { cmd: 'resethomevc', args: [] },
  homevc: { cmd: 'homevc', args: [] },
  setvcstatus: { cmd: 'setvcstatus', args: [] },
  vcstatus: { cmd: 'vcstatus', args: [] },
  vcstatuspanel: { cmd: 'vcstatuspanel', args: [] },
  vspanel: { cmd: 'vcstatuspanel', args: [] },
  // Templates & Emojis
  template: { cmd: 'template', args: [] },
  tmpcreate: { cmd: 'template', args: ['create'] },
  tmpload: { cmd: 'template', args: ['load'] },
  tmplist: { cmd: 'template', args: ['list'] },
  tmpinfo: { cmd: 'template', args: ['info'] },
  tmpdel: { cmd: 'template', args: ['delete'] },
  tmpexport: { cmd: 'template', args: ['export'] },
  tmpimport: { cmd: 'template', args: ['import'] },
  emojizip: { cmd: 'emojizip', args: [] },
  tmpemojidownload: { cmd: 'emojizip', args: ['download'] },
  tmpemojiupload: { cmd: 'emojizip', args: ['upload'] },
  // Applications
  apply: { cmd: 'apply', args: [] },
  staffapply: { cmd: 'apply', args: [] },
  appsetup: { cmd: 'appsetup', args: [] },
  applicationsetup: { cmd: 'appsetup', args: [] },
  // Additional Python Catalog Routes & Aliases
  fortress: { cmd: 'antinuke', args: ['preset', 'fortress'] },
  harden: { cmd: 'antinuke', args: ['preset', 'fortress'] },
  secureserver: { cmd: 'antinuke', args: ['preset', 'fortress'] },
  securitysetup: { cmd: 'antinuke', args: ['preset', 'fortress'] },
  sectest: { cmd: 'securityscore', args: [] },
  simulate: { cmd: 'securityscore', args: [] },
  testantinuke: { cmd: 'securityscore', args: [] },
  vg: { cmd: 'vanityguard', args: [] },
  emergencysituation: { cmd: 'panic', args: ['lock'] },
  'emergency-situation': { cmd: 'panic', args: ['lock'] },
  emgs: { cmd: 'panic', args: ['lock'] },
  emergencyrestore: { cmd: 'panic', args: ['unlock'] },
  emgrestore: { cmd: 'panic', args: ['unlock'] },
  emgsrestore: { cmd: 'panic', args: ['unlock'] },
  emgbackup: { cmd: 'panic', args: ['unlock'] },
  wlist: { cmd: 'whitelisted', args: [] },
  whitelistreset: { cmd: 'whitelist', args: ['reset'] },
  wlreset: { cmd: 'whitelist', args: ['reset'] },
  bp_mod: { cmd: 'banpanel', args: [] },
  kp_mod: { cmd: 'kickpanel', args: [] },
  tp_mod: { cmd: 'mutepanel', args: [] },
  wp_mod: { cmd: 'warnpanel', args: [] },
  cleanpanel: { cmd: 'purgepanel', args: [] },
  channelpanel: { cmd: 'lockpanel', args: [] },
  rolemodpanel: { cmd: 'modrolepanel', args: [] },
  give: { cmd: 'giverole', args: [] },
  addrole: { cmd: 'giverole', args: [] },
  nick: { cmd: 'nick', args: [] },
  setnick: { cmd: 'nick', args: [] },
  enlarge: { cmd: 'enlarge', args: [] },
  jumbo: { cmd: 'enlarge', args: [] },
  bigemoji: { cmd: 'enlarge', args: [] },
  delsticker: { cmd: 'delsticker', args: [] },
  deletesticker: { cmd: 'delsticker', args: [] },
  removesticker: { cmd: 'delsticker', args: [] },
  roleicon: { cmd: 'roleicon', args: [] },
  setroleicon: { cmd: 'roleicon', args: [] },
  audit: { cmd: 'auditlog', args: [] },
  beg: { cmd: 'beg', args: [] },
  monthly: { cmd: 'monthly', args: [] },
  fastrules: { cmd: 'fastrules', args: [] },
  quickrules: { cmd: 'fastrules', args: [] },
  quickautomod: { cmd: 'fastrules', args: [] },
  hiddenurls: { cmd: 'automod', args: ['anti_link'] },
  antihiddenurls: { cmd: 'automod', args: ['anti_link'] },
  maskedlinks: { cmd: 'automod', args: ['anti_link'] },
  tikclose: { cmd: 'ticket', args: ['close'] },
  ticclose: { cmd: 'ticket', args: ['close'] },
  ticketclose: { cmd: 'ticket', args: ['close'] },
  claim: { cmd: 'ticket', args: ['claim'] },
  ticketedit: { cmd: 'ticket', args: ['panel'] },
  ticketmanager: { cmd: 'ticket', args: ['manager'] },
  tikmgr: { cmd: 'ticket', args: ['manager'] },
  ticmgr: { cmd: 'ticket', args: ['manager'] },
  tktmgr: { cmd: 'ticket', args: ['manager'] },
  ticketopen: { cmd: 'ticket', args: ['open'] },
  ownervc: { cmd: 'voice', args: ['ownervc'] },
  vdragstop: { cmd: 'vdrag', args: ['stop'] },
  restore: { cmd: 'backup', args: ['restore'] },
  backuplist: { cmd: 'backup', args: ['list'] },
  bckstatus: { cmd: 'backup', args: ['info'] },
  rembck: { cmd: 'backup', args: ['delete'] },
  listallbackups: { cmd: 'backup', args: ['list'] },
  restoreto: { cmd: 'backup', args: ['restore'] },
  autobackup: { cmd: 'backup', args: ['info'] },
  aubackup: { cmd: 'backup', args: ['info'] },
  aubckstatus: { cmd: 'backup', args: ['info'] },
  tmpbackup: { cmd: 'template', args: ['create'] },
  tmpignorechannel: { cmd: 'template', args: ['info'] },
  exp: { cmd: 'template', args: ['export'] },
  botprofile: { cmd: 'botprofile', args: [] },
  serverprofile: { cmd: 'botprofile', args: [] },
  bp: { cmd: 'botprofile', args: [] },
  level: { cmd: 'levels', args: [] },
  rank: { cmd: 'levels', args: [] },
  levelup: { cmd: 'levels', args: [] },
  levelmsg: { cmd: 'levels', args: ['channel'] },
  levelsetup: { cmd: 'levels', args: ['channel'] },
  setlevel: { cmd: 'levels', args: ['set'] },
  resetmyvoice: { cmd: 'resetvoice', args: ['my'] },
  clan: { cmd: 'clans', args: [] },
  couple: { cmd: 'couples', args: [] },
  // Text Tools Suite (Slice 5.3)
  encode: { cmd: 'encode', args: [] },
  decode: { cmd: 'encode', args: ['--decode'] },
  wordcount: { cmd: 'wordcount', args: [] },
  wc: { cmd: 'wordcount', args: [] },
  diff: { cmd: 'diff', args: [] },
  textdiff: { cmd: 'diff', args: [] },
  case: { cmd: 'case', args: [] },
  textcase: { cmd: 'case', args: [] },
  lorem: { cmd: 'lorem', args: [] },
  lipsum: { cmd: 'lorem', args: [] },
  loremipsum: { cmd: 'lorem', args: [] },
  // Permissions & Self-Check Security Suite
  perms: { cmd: 'perms', args: [] },
  permissions: { cmd: 'perms', args: [] },
  botperms: { cmd: 'perms', args: ['bot'] },
  myperms: { cmd: 'perms', args: ['me'] },
  userperms: { cmd: 'perms', args: [] },
  selfcheck: { cmd: 'selfcheck', args: [] },
  securitycheck: { cmd: 'selfcheck', args: [] },
  auditcheck: { cmd: 'selfcheck', args: [] },
  checkup: { cmd: 'selfcheck', args: [] },
  botcheck: { cmd: 'selfcheck', args: [] },
  // Fun & Rate Suite
  howgay: { cmd: 'howgay', args: [] },
  gay: { cmd: 'howgay', args: [] },
  gayrate: { cmd: 'howgay', args: [] },
  lesbian: { cmd: 'lesbian', args: [] },
  lesbianrate: { cmd: 'lesbian', args: [] },
  cute: { cmd: 'cute', args: [] },
  cuterate: { cmd: 'cute', args: [] },
  cuteness: { cmd: 'cute', args: [] },
  intelligence: { cmd: 'intelligence', args: [] },
  iq: { cmd: 'intelligence', args: [] },
  iqrate: { cmd: 'intelligence', args: [] },
  intellect: { cmd: 'intelligence', args: [] },
  chutiya: { cmd: 'chutiya', args: [] },
  chutiyarate: { cmd: 'chutiya', args: [] },
  horny: { cmd: 'horny', args: [] },
  hornyrate: { cmd: 'horny', args: [] },
  tharki: { cmd: 'tharki', args: [] },
  tharkirate: { cmd: 'tharki', args: [] },
  weather: { cmd: 'weather', args: [] },
  forecast: { cmd: 'weather', args: [] },
  climate: { cmd: 'weather', args: [] },
  fakeban: { cmd: 'fakeban', args: [] },
  fban: { cmd: 'fakeban', args: [] },
  mockban: { cmd: 'fakeban', args: [] },
  image: { cmd: 'image', args: [] },
  img: { cmd: 'image', args: [] },
  searchimage: { cmd: 'image', args: [] },
  photo: { cmd: 'image', args: [] },
  truth: { cmd: 'truth', args: [] },
  truthquestion: { cmd: 'truth', args: [] },
  tordtruth: { cmd: 'truth', args: [] },
  dare: { cmd: 'dare', args: [] },
  darechallenge: { cmd: 'dare', args: [] },
  torddare: { cmd: 'dare', args: [] },
  // Anime Roleplay Suite
  roleplay: { cmd: 'roleplay', args: [] },
  rp: { cmd: 'roleplay', args: [] },
  act: { cmd: 'roleplay', args: [] },
  hug: { cmd: 'hug', args: [] },
  kiss: { cmd: 'kiss', args: [] },
  pat: { cmd: 'pat', args: [] },
  headpat: { cmd: 'pat', args: [] },
  cuddle: { cmd: 'cuddle', args: [] },
  slap: { cmd: 'slap', args: [] },
  tickle: { cmd: 'tickle', args: [] },
  spank: { cmd: 'spank', args: [] },
  kill: { cmd: 'kill', args: [] },
  defeat: { cmd: 'kill', args: [] },
  poke: { cmd: 'poke', args: [] },
  highfive: { cmd: 'highfive', args: [] },
  hfive: { cmd: 'highfive', args: [] },
  bite: { cmd: 'bite', args: [] },
  bonk: { cmd: 'bonk', args: [] },
  punch: { cmd: 'punch', args: [] },
  stare: { cmd: 'stare', args: [] },
  wave: { cmd: 'wave', args: [] },
  smug: { cmd: 'smug', args: [] },
  yeet: { cmd: 'yeet', args: [] },
  dance: { cmd: 'dance', args: [] },
  handhold: { cmd: 'handhold', args: [] },
  holdhands: { cmd: 'handhold', args: [] },
  cry: { cmd: 'cry', args: [] },
  lappillow: { cmd: 'lappillow', args: [] },
  pillow: { cmd: 'lappillow', args: [] },
  happy: { cmd: 'happy', args: [] },
  // Page 7-20 Moderation, Voice, Giveaway, and Utility Routes
  voicemaster: { cmd: 'j2c', args: [] },
  greet: { cmd: 'welcome', args: [] },
  gstart: { cmd: 'giveaway', args: ['start'] },
  glist: { cmd: 'giveaway', args: ['list'] },
  gstaff: { cmd: 'giveaway', args: ['staff'] },
  gconfig: { cmd: 'giveaway', args: ['config'] },
  gembed: { cmd: 'giveaway', args: ['embed'] },
  voicelb: { cmd: 'leaderboard', args: ['voice'] },
  msglb: { cmd: 'leaderboard', args: ['messages'] },
  invitelb: { cmd: 'leaderboard', args: ['invites'] },
  top: { cmd: 'leaderboard', args: ['top'] },
  jail: { cmd: 'jail', args: [] },
  clone: { cmd: 'clone', args: [] },
  unslowmode: { cmd: 'unslowmode', args: [] },
  vcban: { cmd: 'vcban', args: [] },
  list: { cmd: 'list', args: [] },
  media: { cmd: 'media', args: [] },
  // Terms of Service & Security Charter
  tos: { cmd: 'tos', args: [] },
  terms: { cmd: 'tos', args: [] },
  termsofservice: { cmd: 'tos', args: [] },
  privacy: { cmd: 'tos', args: [] },
  charter: { cmd: 'tos', args: [] },
  // Logging & Audit Shortcuts
  logs: { cmd: 'logs', args: [] },
  log: { cmd: 'logs', args: [] },
  logging: { cmd: 'logs', args: [] },
  logging_setup: { cmd: 'logs', args: ['setup'] },
  logging_auto: { cmd: 'logs', args: ['auto'] },
  loggingauto: { cmd: 'logs', args: ['auto'] },
  autologging: { cmd: 'logs', args: ['auto'] },
  autolog: { cmd: 'logs', args: ['auto'] },
  autologs: { cmd: 'logs', args: ['auto'] },
  autologs_all: { cmd: 'logs', args: ['auto', 'all'] },
  autologging_all: { cmd: 'logs', args: ['auto', 'all'] },
  autolog_all: { cmd: 'logs', args: ['auto', 'all'] },
  logs_deleteall: { cmd: 'logs', args: ['deleteall'] },
  logs_delete: { cmd: 'logs', args: ['deleteall'] },
  logs_purge: { cmd: 'logs', args: ['deleteall'] },
  logs_cleanup: { cmd: 'logs', args: ['deleteall'] },
  logs_matrix: { cmd: 'logs', args: ['matrix'] },
  logs_view: { cmd: 'logs', args: ['matrix'] },
  logging_config: { cmd: 'logs', args: ['config'] },
  logging_enable: { cmd: 'logs', args: ['enable'] },
  logging_disable: { cmd: 'logs', args: ['disable'] },
  logging_reset: { cmd: 'logs', args: ['reset'] },
  logchannel: { cmd: 'auditlog', args: [] },
  modlog: { cmd: 'auditlog', args: [] },
  modlogs: { cmd: 'auditlog', args: [] },
  auditlog: { cmd: 'auditlog', args: [] },
  auditlogs: { cmd: 'auditlog', args: [] },
  logsettings: { cmd: 'logs', args: [] },
  logrouter: { cmd: 'logs', args: [] },
  setlog: { cmd: 'logs', args: [] },
  setlogs: { cmd: 'logs', args: [] }
};

async function handleStickyMessage(message, sdb, client) {
  const channelId = message?.channel?.id;
  if (!message?.guild || !channelId || _STICKY_LOCKS.has(channelId)) return;
  try {
    const sticky = sdb.prepare('SELECT content, last_message_id FROM sticky_messages WHERE channel_id = ?').get(channelId);
    if (!sticky || !sticky.content) return;

    _STICKY_LOCKS.add(channelId);

    if (sticky.last_message_id && message.channel?.messages) {
      try {
        const prevMsg = await message.channel.messages.fetch(sticky.last_message_id).catch(() => null);
        if (prevMsg) await prevMsg.delete().catch(() => null);
      } catch (e) {}
    }

    const stickyEmbed = createEmbed({
      color: 0x2b2d31,
      title: '📌  Channel Notice',
      description: sticky.content,
      footer: { text: 'Tungsten Automatic Sticky Notice' }
    });

    const sent = await message.channel.send({ embeds: [stickyEmbed] }).catch(() => null);
    if (sent) {
      sdb.prepare('UPDATE sticky_messages SET last_message_id = ? WHERE channel_id = ?').run(sent.id, channelId);
    }
  } catch (e) {
  } finally {
    if (channelId) {
      setTimeout(() => _STICKY_LOCKS.delete(channelId), 2500);
    }
  }
}

function awardUserXp(userId, guildId, sdb) {
  try {
    if (!isModuleEnabled(guildId, 'leveling')) return null;
    const enabled = getSetting(guildId, 'leveling.enabled');
    if (!enabled) return null;

    const now = Math.floor(Date.now() / 1000);
    const row = sdb.prepare('SELECT xp, level, last_xp_time FROM leveling_users WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
    if (row && (now - row.last_xp_time < 60)) {
      return null;
    }
    const currentXp = row ? row.xp : 0;
    const currentLevel = row ? row.level : 0;
    const gainedXp = Math.floor(Math.random() * 11) + 15; // 15 - 25 XP
    const newXp = currentXp + gainedXp;
    const newLevel = Math.floor(0.1 * Math.sqrt(newXp));

    sdb.prepare(`
      INSERT INTO leveling_users (guild_id, user_id, xp, level, last_xp_time)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET
        xp = excluded.xp,
        level = excluded.level,
        last_xp_time = excluded.last_xp_time
    `).run(guildId, userId, newXp, newLevel, now);

    if (newLevel > currentLevel) {
      return { leveledUp: true, oldLevel: currentLevel, newLevel };
    }
  } catch (e) {}
  return null;
}

const _PROCESSED_MESSAGE_IDS = new Set();
const _IN_FLIGHT_COMMANDS = new Set();
const _WEBHOOK_BURST_TRACKER = new Map();

module.exports = {
  name: 'messageCreate',
  DIRECT_COMMAND_ROUTES,
  async execute(message, client) {
    if (!message) return;

    // 0. Rogue Webhook Spam Detection & Antinuke Neutralization
    if (message.webhookId && message.guild) {
      if (isAntinukeArmed(message.guild.id)) {
        const wid = String(message.webhookId);
        const content = message.content || '';
        const hasEveryone = Boolean(message.mentions?.everyone || content.includes('@everyone') || content.includes('@here'));
        const hasInvite = INVITE_REGEX.test(content);
        const hasMassMention = ((message.mentions?.users?.size || 0) + (message.mentions?.roles?.size || 0)) > 3;
        const hasRaidKeywords = /(?:nuk|raid|hack|crash|spam|fuck|destroy|tok|clown)/i.test(content);

        // Rate burst detection (2+ messages in 5s from the same webhook)
        const now = Date.now();
        const timestamps = _WEBHOOK_BURST_TRACKER.get(wid) || [];
        const recent = timestamps.filter(t => now - t < 5000);
        recent.push(now);
        _WEBHOOK_BURST_TRACKER.set(wid, recent);
        if (_WEBHOOK_BURST_TRACKER.size > 1000) {
          const oldestKey = _WEBHOOK_BURST_TRACKER.keys().next().value;
          _WEBHOOK_BURST_TRACKER.delete(oldestKey);
        }
        const hasRateSpam = recent.length >= 2;

        if (hasEveryone || hasInvite || hasMassMention || hasRaidKeywords || hasRateSpam) {
          // Fetch webhook to check if creator/owner is Tungsten or immune
          const hook = await (message.fetchWebhook ? message.fetchWebhook().catch(() => null) : (client?.fetchWebhook ? client.fetchWebhook(wid).catch(() => null) : null));

          let executor = hook?.owner || null;
          if (executor) {
            if (executor.id === client?.user?.id || isImmune(message.guild, executor.id, 'webhook', client)) {
              return; // Authorized whitelisted/owner webhook
            }
          } else {
            executor = await resolveAuditExecutor(message.guild, AuditLogEvent.WebhookCreate, { targetId: wid });
            if (!executor) {
              const activeAttacker = getActiveRaidAttacker(message.guild.id);
              if (activeAttacker && activeAttacker.executor) {
                executor = activeAttacker.executor;
              }
            }
            if (executor && (executor.id === client?.user?.id || isImmune(message.guild, executor.id, 'webhook', client))) {
              return; // Creator is immune
            }
          }

          // Rogue webhook confirmed! Immediately delete rogue message and webhook
          message.delete().catch(() => null);

          if (hook && typeof hook.delete === 'function') {
            await hook.delete('[Tungsten Anti-Raid] Deleting rogue webhook spamming the server.').catch(() => null);
          }

          // Immediately ban/punish the attacker / rogue bot!
          if (executor) {
            recordActiveRaidAttacker(message.guild.id, executor);
            if (executor.bot) {
              if (message.guild.bans?.create) {
                await message.guild.bans.create(executor.id, { reason: '[Tungsten Anti-Raid] Rogue bot spamming via webhook' }).catch(() => null);
              } else if (message.guild.members?.ban) {
                await message.guild.members.ban(executor.id, { reason: '[Tungsten Anti-Raid] Rogue bot spamming via webhook' }).catch(() => null);
              }
            }
            await punishAttacker(message.guild, executor, 'Raid spamming via webhook', client, 'Anti-Webhook Raid', 'webhook', null, { isBot: Boolean(executor.bot) });
          }

          // Trigger autonomous disaster recovery
          await triggerAutonomousDisasterRecovery(message.guild, client, 'Webhook Raid Spam');
        }
      }
      return;
    }

    if (!message.author || message.author.bot) return;

    // Deduplicate incoming message events to prevent double execution on gateway replays or rapid retransmissions
    if (message.id) {
      if (_PROCESSED_MESSAGE_IDS.has(message.id)) return;
      _PROCESSED_MESSAGE_IDS.add(message.id);
      if (_PROCESSED_MESSAGE_IDS.size > 3000) {
        const oldest = _PROCESSED_MESSAGE_IDS.values().next().value;
        _PROCESSED_MESSAGE_IDS.delete(oldest);
      }
    }

    if (typeof message.reply === 'function' && !message.reply.__msgSanitized) {
      const _origReply = message.reply.bind(message);
      const wrappedReply = (opts) => _origReply(sanitizeUiPayload(message, opts));
      wrappedReply.__msgSanitized = true;
      message.reply = wrappedReply;
    }
    if (message.channel && typeof message.channel.send === 'function' && !message.channel.send.__chanSanitized) {
      const _origSend = message.channel.send.bind(message.channel);
      const wrappedSend = (opts) => _origSend(sanitizeUiPayload(message, opts));
      wrappedSend.__chanSanitized = true;
      message.channel.send = wrappedSend;
    }

    const guildId = message.guild ? message.guild.id : null;
    const authorId = message.author.id;
    const sdb = guildId ? getServerDb(guildId) : null;

    // H2: Run Automod Content Inspection FIRST before any XP awards or state processing
    const automodBlocked = await runAutomodCheck(message, client);
    if (automodBlocked) return;

    // Antinuke: Anti-Everyone/Here Ping Sentinel (Wick/Olympus parity) - Fast Boolean Path
    if (message.guild && (message.mentions?.everyone || message.content?.includes('@everyone') || message.content?.includes('@here'))) {
      const { isAntinukeArmed, isImmune, getAntinukeRule, punishAttacker } = require('../utils/antinukeEngine');
      if (isAntinukeArmed(message.guild.id)) {
        const pingRule = getAntinukeRule(message.guild.id, 'everyone_ping');
        if (pingRule && pingRule.enabled) {
          if (!isImmune(message.guild, authorId, 'everyone_ping') && !isImmune(message.guild, authorId, 'mention')) {
            if (typeof message.delete === 'function') {
              await message.delete().catch(() => null);
            }
            await punishAttacker(message.guild, message.author, 'Unauthorized @everyone/@here mass ping attempt', client, 'Anti-Everyone Ping', 'everyone_ping');
            return;
          }
        }
      }
    }

    // 1. Blacklist Check
    if (!blacklistCheck(authorId, guildId)) return;

    // Media-Only Channel Sentinel
    if (guildId && sdb && message.channel) {
      try {
        const isMediaChan = sdb.prepare('SELECT 1 FROM media_channels WHERE guild_id = ? AND channel_id = ?').get(guildId, message.channel.id);
        if (isMediaChan) {
          const { hasPerm } = require('../utils/tools');
          let hasBypass = message.author.id === message.guild?.ownerId || hasPerm(message.member, 'Administrator') || hasPerm(message.member, 'ManageChannels');

          if (!hasBypass && message.member?.roles?.cache) {
            const bypassRoles = sdb.prepare('SELECT role_id FROM media_bypass_roles WHERE guild_id = ?').all(guildId).map(r => r.role_id);
            if (bypassRoles.length > 0 && message.member.roles.cache.some(r => bypassRoles.includes(r.id))) {
              hasBypass = true;
            }
          }

          if (!hasBypass) {
            const hasAttachment = Boolean(message.attachments && message.attachments.size > 0);
            const hasEmbed = Boolean(message.embeds && message.embeds.length > 0);
            const urlRegex = /(https?:\/\/[^\s]+)/gi;
            const hasUrl = Boolean(message.content && urlRegex.test(message.content));

            if (!hasAttachment && !hasEmbed && !hasUrl) {
              if (typeof message.delete === 'function') {
                await message.delete().catch(() => null);
              }
              const warnMsg = await message.channel.send({
                content: `<a:tungsten_warn:1567246685082746940> ${message.author}, this channel is configured as **media-only**. Messages must contain an image, video, attachment, or link.`
              }).catch(() => null);
              if (warnMsg) {
                setTimeout(() => warnMsg.delete().catch(() => null), 5000);
              }
              return;
            }
          }
        }
      } catch (_) {}
    }

    // Cache message for anti-ghostping if mentions present
    if (guildId && message.mentions?.users?.size > 0 && !isAutomodDeleted(message.id)) {
      storeGhostpingCandidate(message);
    }

    // Award XP & Check Sticky Message
    if (guildId && sdb) {
      processChatXp(message, sdb, client).catch(() => null);
      handleStickyMessage(message, sdb, client);
    }

    // 2. Author AFK Recovery Check
    if (guildId) {
      const authorAfk = clearAfkStatus(authorId, guildId);
      if (authorAfk) {
        try {
          const elapsedSec = Math.floor((Date.now() - authorAfk.afk_time) / 1000);
          const mins = Math.floor(elapsedSec / 60);
          const timeStr = mins > 0 ? `${mins}m` : `${elapsedSec}s`;
          await message.reply({
            embeds: [
              createEmbed({
                color: client.config.COLORS.SUCCESS,
                title: `👋 Welcome Back, ${message.author.displayName || message.author.username}!`,
                description: `I have removed your AFK status.\n` +
                  `• **Time Away:** \`${timeStr}\`\n` +
                  `• **Mentions While AFK:** \`${authorAfk.mentions_count || 0}\``
              })
            ]
          });
        } catch (e) {}
      }
    }

    // 3. Determine Guild Prefix
    const guildConfig = guildId ? getConfig(guildId) : { prefix: client.config.DEFAULT_PREFIX };
    const prefix = guildConfig.prefix || client.config.DEFAULT_PREFIX;

    let matchedPrefix = null;
    const content = message.content.trim();
    const botUser = client?.user || message?.client?.user;
    const botId = botUser?.id || '';
    const mentionPrefix = botId ? `<@${botId}>` : '';
    const mentionNickPrefix = botId ? `<@!${botId}>` : '';

    if (content.startsWith(prefix)) {
      matchedPrefix = prefix;
    } else if (mentionPrefix && content.startsWith(mentionPrefix)) {
      matchedPrefix = mentionPrefix;
    } else if (mentionNickPrefix && content.startsWith(mentionNickPrefix)) {
      matchedPrefix = mentionNickPrefix;
    } else if (isNoPrefix(authorId, guildId, message.member)) {
      const firstWord = content.trim().split(/ +/)[0]?.toLowerCase();
      if (firstWord && (client.commands.has(firstWord) || client.aliases.has(firstWord) || DIRECT_COMMAND_ROUTES[firstWord])) {
        matchedPrefix = '';
      }
    }

    // Check if the bot was tagged alone (e.g. `@Tungsten` without arguments)
    const isBotMentionAlone = Boolean(
      botId && (
        content === mentionPrefix ||
        content === mentionNickPrefix ||
        new RegExp(`^(\\s*<@!?${botId}>\\s*)+$`).test(content)
      )
    );

    if (isBotMentionAlone) {
      // Deliver Bot Tag DM notification (debounced 5 mins)
      handleBotMention(message, client).catch(() => null);

      const { getGuildAccent } = require('../utils/serverDb');
      const accent = guildId ? getGuildAccent(guildId) : client.config.COLORS.PRIMARY;
      const clientUser = botUser || { username: 'Tungsten' };
      const avatarURL = clientUser?.displayAvatarURL ? clientUser.displayAvatarURL() : undefined;
      const guildName = message.guild?.name || 'this server';

      const embed = createEmbed({
        color: accent,
        author: {
          name: `${clientUser.username || 'Tungsten'} • Enterprise Defense`,
          iconURL: avatarURL
        },
        title: `<a:tungsten_wave:1567246763822158004> Hello ${message.author.displayName || message.author.username}!`,
        description:
          `My command prefix in **${guildName}** is \`${prefix}\`.\n\n` +
          `• **Commands Hub:** \`${prefix}help\` • Explore all modules & features\n` +
          `• **Security Matrix:** \`${prefix}antinuke\` • Ultra Zero-Tolerance Shield\n` +
          `• **Automod Suite:** \`${prefix}automod\` • Comprehensive raid & spam filter\n\n` +
          `*I also sent a quick-start reference guide directly to your DMs.*`,
        footer: {
          text: `Tungsten Bot • Server ID: ${guildId || 'DM'}`,
          iconURL: message.guild?.iconURL ? message.guild.iconURL() : avatarURL
        }
      });

      const buttonRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('help:home')
          .setLabel('Command Hub')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('<a:tungsten_cmd_help:1567235431567724626>'),
        new ButtonBuilder()
          .setCustomId('help:componentsv2_demo')
          .setLabel('Features')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('<a:tungsten_bolt:1567233430570405968>')
      );

      return message.reply({
        embeds: [embed],
        components: [buttonRow]
      }).catch(async () => {
        return message.reply({ embeds: [embed] }).catch(() => null);
      });
    }

    // Non-command message processing helper (AFK replies, mention alerts, autoresponders)
    async function processNonCommand() {
      // M1: Bounded AFK mention replies (max 3 replies per message)
      if (guildId && message.mentions?.users?.size > 0) {
        let afkReplyCount = 0;
        for (const [targetId, targetUser] of message.mentions.users.entries()) {
          if (targetId === authorId || targetUser.bot) continue;
          const afkData = getAfkStatus(targetId, guildId);
          if (afkData && afkReplyCount < 3) {
            incrementAfkMentions(targetId, guildId);
            afkReplyCount++;
            try {
              await message.reply({
                embeds: [
                  createEmbed({
                    color: client.config.COLORS.INFO,
                    description: `💤 **${targetUser.username}** is currently AFK: **${afkData.reason}** (<t:${Math.floor(afkData.afk_time / 1000)}:R>)`
                  })
                ]
              }).catch(() => null);
            } catch (e) {}
          }
        }

        // H5: Non-blocking fire-and-forget mention alert DMs for non-command messages
        handleMessageMentions(message, client).catch(() => null);
      }

      // Check Autoresponders & Autoreactions
      if (guildId && sdb && content) {
        try {
          const lower = content.toLowerCase();
          const ar = sdb.prepare('SELECT response_text FROM autoresponders WHERE guild_id = ? AND trigger_word = ?').get(guildId, lower);
          if (ar) {
            let formatted = formatPlaceholders(ar.response_text, message.member, message.guild);
            formatted = replaceEmojis(message.guild, formatted);
            // S8: Restrict allowedMentions to prevent role/everyone ping abuse
            return message.reply({ content: formatted, allowedMentions: { parse: [] } }).catch(() => null);
          }

          const rxList = sdb.prepare('SELECT trigger_word, emoji FROM autoreactions WHERE guild_id = ?').all(guildId);
          for (const item of rxList) {
            if (lower === item.trigger_word.toLowerCase()) {
              let emojiToReact = item.emoji;
              if (/^:?([a-zA-Z0-9_]+):?$/.test(emojiToReact)) {
                const resolved = resolveEmoji(message.guild, emojiToReact.replace(/:/g, ''));
                if (resolved) emojiToReact = resolved;
              }
              await message.react(emojiToReact).catch(() => null);
            }
          }

          // Custom commands check
          const firstWord = content.split(/\s+/)[0]?.toLowerCase();
          if (firstWord) {
            const customCmd = sdb.prepare('SELECT content FROM custom_commands WHERE guild_id = ? AND name = ?').get(guildId, firstWord);
            if (customCmd) {
              let formatted = formatPlaceholders(customCmd.content, message.member, message.guild);
              formatted = replaceEmojis(message.guild, formatted);
              // S8: Restrict allowedMentions to prevent role/everyone ping abuse
              return message.reply({ content: formatted, allowedMentions: { parse: [] } }).catch(() => null);
            }
          }
        } catch (e) {}
      }
    }

    // Non-command message handling
    if (matchedPrefix === null) {
      await processNonCommand();
      return;
    }

    // ─────────────────────────────────────────────────────────────
    // Command Parsing & Dispatch
    // ─────────────────────────────────────────────────────────────
    const rawArgs = content.slice(matchedPrefix.length).trim().split(/ +/);
    let commandName = (rawArgs.shift() || '').toLowerCase();
    if (!commandName) {
      if (matchedPrefix === mentionPrefix || matchedPrefix === mentionNickPrefix) {
        handleBotMention(message, client).catch(() => null);
      }
      return;
    }

    if (commandName.includes('_')) {
      const parts = commandName.split('_');
      const baseCmd = parts[0];
      const subAction = parts.slice(1).join('_');
      if (client.commands.has(baseCmd) || client.aliases.has(baseCmd)) {
        commandName = baseCmd;
        rawArgs.unshift(subAction);
      }
    }

    let command = null;
    if (DIRECT_COMMAND_ROUTES[commandName]) {
      const targetRoute = DIRECT_COMMAND_ROUTES[commandName];
      const cmdKey = typeof targetRoute === 'string' ? targetRoute : targetRoute?.cmd;
      const targetCmd = client.commands.get(cmdKey) || client.commands.get(client.aliases.get(cmdKey));
      if (targetCmd) {
        command = targetCmd;
        // H3: Always prepend route.args
        if (targetRoute && typeof targetRoute === 'object' && targetRoute.args && targetRoute.args.length > 0) {
          rawArgs.unshift(...targetRoute.args);
        }
      }
    }

    if (!command) {
      command = client.commands.get(commandName) || client.commands.get(client.aliases.get(commandName));
    }

    if (!command && rawArgs.length > 0) {
      const nextWord = rawArgs[0].toLowerCase();
      const subKeyUnderscore = `${commandName}_${nextWord}`;
      const subKeyDirect = `${commandName}${nextWord}`;

      if (DIRECT_COMMAND_ROUTES[subKeyUnderscore]) {
        const route = DIRECT_COMMAND_ROUTES[subKeyUnderscore];
        command = client.commands.get(route.cmd) || client.commands.get(client.aliases.get(route.cmd));
        rawArgs.shift();
        if (route.args && route.args.length > 0) {
          rawArgs.unshift(...route.args);
        }
      } else if (DIRECT_COMMAND_ROUTES[subKeyDirect]) {
        const route = DIRECT_COMMAND_ROUTES[subKeyDirect];
        command = client.commands.get(route.cmd) || client.commands.get(client.aliases.get(route.cmd));
        rawArgs.shift();
        if (route.args && route.args.length > 0) {
          rawArgs.unshift(...route.args);
        }
      } else if (client.commands.has(subKeyUnderscore) || client.aliases.has(subKeyUnderscore)) {
        command = client.commands.get(subKeyUnderscore) || client.commands.get(client.aliases.get(subKeyUnderscore));
        rawArgs.shift();
      } else if (client.commands.has(subKeyDirect) || client.aliases.has(subKeyDirect)) {
        command = client.commands.get(subKeyDirect) || client.commands.get(client.aliases.get(subKeyDirect));
        rawArgs.shift();
      }
    }

    if (!command) {
      if (matchedPrefix === mentionPrefix || matchedPrefix === mentionNickPrefix) {
        // Bot was tagged with text or other users that does not form a command.
        // Fall back gracefully to non-command processing (AFK mentions, mention alert DMs, autoresponders)
        await processNonCommand();
      }
      return;
    }

    // Guild-level command/channel/user ignores check
    if (message.guild && !hasPerm(message.member, PermissionsBitField.Flags.Administrator)) {
      try {
        const sdb = getServerDb(guildId);
        sdb.prepare(`
          CREATE TABLE IF NOT EXISTS cmd_ignores (
            guild_id TEXT,
            type TEXT,
            target_id TEXT,
            PRIMARY KEY(guild_id, type, target_id)
          )
        `).run();

        const bypassRows = sdb.prepare('SELECT target_id FROM cmd_ignores WHERE guild_id = ? AND type = ?').all(guildId, 'bypass');
        const hasBypass = bypassRows.some(row => message.member?.roles?.cache?.has(row.target_id));

        if (!hasBypass) {
          // Check user ignore
          const userIgnored = sdb.prepare('SELECT 1 FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').get(guildId, 'user', authorId);
          if (userIgnored) return;

          // Check channel ignore
          const channelIgnored = sdb.prepare('SELECT 1 FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').get(guildId, 'channel', message.channel.id);
          if (channelIgnored) return;

          // Check command ignore
          const cmdIgnored = sdb.prepare('SELECT 1 FROM cmd_ignores WHERE guild_id = ? AND type = ? AND target_id = ?').get(guildId, 'command', command.name.toLowerCase());
          if (cmdIgnored) return;
        }
      } catch (e) {}
    }

    // Command Anti-Spam & Rate Limiting Check (Continuous 5-spam limiter across server)
    if (message.guild) {
      const spamCheck = checkCommandSpam(guildId, authorId, message.guild.ownerId);
      if (spamCheck.blocked) {
        return message.reply({
          content: SPAM_LOCKOUT_MESSAGE(spamCheck.remainingSeconds)
        });
      }
    }

    // Ignore channels check (Master DB fallback)
    if (!isOwner(authorId) && !ignoreCheck(message.channel.id, command.name)) {
      return;
    }

    // Owner only check
    if ((command.ownerOnly || command.category === 'owner') && !isOwner(authorId)) {
      return message.reply('This command can be executed only by Bot Owner.');
    }

    // Guild Only Check
    if (command.guildOnly !== false && !message.guild) {
      return message.reply('This command can only be used in a server.');
    }

    // Antinuke Prerequisite for Moderation Commands
    const isModCommand = Array.isArray(command.category)
      ? command.category.includes('moderation')
      : command.category === 'moderation';
    if (message.guild && isModCommand) {
      if (!isAntinukeArmed(message.guild.id)) {
        return message.reply({
          embeds: [
            createEmbed({
              title: '<a:tungsten_warn:1567242784535085148> Antinuke Is Disabled',
              description: `> **Security Requirement**: Moderation actions are currently locked because Antinuke is **disabled** on this server.\n\nTo execute moderations (ban, kick, mute, purge, lock, etc.), you must first enable Antinuke:\n• Run \`${prefix}antinuke enable\` or \`${prefix}an on\``
            })
          ]
        });
      }
    }

    // Cooldown Enforcement
    if (!isOwner(authorId)) {
      const cooldownAmount = (command.cooldown || 3) * 1000;
      if (!client.cooldowns.has(command.name)) {
        client.cooldowns.set(command.name, new Collection());
      }
      const timestamps = client.cooldowns.get(command.name);
      const now = Date.now();

      if (timestamps.has(authorId)) {
        const expirationTime = timestamps.get(authorId) + cooldownAmount;
        if (now < expirationTime) {
          const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
          return message.reply(`${EMOJIS.TIMER || EMOJIS.CLOCK} Please wait **${timeLeft}s** before reusing \`${command.name}\`.`);
        }
      }

      timestamps.set(authorId, now);
      setTimeout(() => timestamps.delete(authorId), cooldownAmount);
    }

    // Enforce Declarative Command Permissions & Overrides (Slice 6.3)
    if (message.guild && message.member) {
      const overrideResult = evaluateOverride(guildId, command.name, message.member, message.channel.id, client);
      if (overrideResult === 'deny') {
        return message.reply(`${EMOJIS.ERROR} This command has been explicitly denied by server configuration.`);
      }

      if (overrideResult !== 'allow') {
        const requiredPerms = command.permissions || command.userPermissions;
        if (Array.isArray(requiredPerms) && requiredPerms.length > 0) {
          const missing = requiredPerms.filter(p => !hasPerm(message.member, p));
          if (missing.length > 0) {
            return message.reply(`${EMOJIS.ERROR} You lack required permission(s): \`${missing.join(', ')}\` to execute \`${command.name}\`.`);
          }
        }
      }

      const botPerms = command.botPermissions;
      if (Array.isArray(botPerms) && botPerms.length > 0 && message.guild.members.me) {
        const missingBot = botPerms.filter(p => !message.guild.members.me.permissions.has(p));
        if (missingBot.length > 0) {
          return message.reply(`${EMOJIS.ERROR} Tungsten lacks required permission(s): \`${missingBot.join(', ')}\` to execute \`${command.name}\`.`);
        }
      }
    }

    // Execute Command with Clean Error Handling (M1) and strict double-execution prevention
    const execLockKey = `${authorId}:${command.name}:${message.id || message.createdTimestamp}`;
    if (_IN_FLIGHT_COMMANDS.has(execLockKey)) {
      return;
    }
    _IN_FLIGHT_COMMANDS.add(execLockKey);
    setTimeout(() => _IN_FLIGHT_COMMANDS.delete(execLockKey), 2500);

    try {
      message.invokedName = commandName;
      message.matchedPrefix = matchedPrefix;
      const effectivePrefix = (matchedPrefix !== null && matchedPrefix !== '') ? matchedPrefix : prefix;
      // Sensitive argument logging sanitized (Roadmap 1.8)
      console.log(`[Command Executing] ${command.name} by ${message.author.username || message.author.id} in ${message.guild?.name || 'DM'}`);
      await command.execute(message, rawArgs, client, effectivePrefix);
      incrementCommandCount();
    } catch (error) {
      incrementErrorCount();
      console.error(`[Command Execution Error: ${command.name}]`, error);
      try {
        const replyWithErrors = guildId ? getSetting(guildId, 'general.reply_with_errors') : false;
        const errDesc = replyWithErrors
          ? `An unexpected error occurred while executing \`${command.name}\`.\n\`\`\`${error.message}\`\`\``
          : `An unexpected error occurred while executing \`${command.name}\`. The issue has been recorded for diagnostics.`;

        await message.reply({
          embeds: [
            createEmbed({
              color: client.config.COLORS.DANGER,
              title: 'Command Execution Error',
              description: errDesc
            })
          ]
        });
      } catch (e) {}
    }
  },
  DIRECT_COMMAND_ROUTES
};
