/**
 * Guild Member Update Event (Node.js)
 * Implements Anti-Role Escalation & Unauthorized Permission Injection Sentinel.
 */
const { AuditLogEvent, PermissionsBitField } = require('discord.js');
const { createEmbed } = require('../utils/tools');
const { getServerDb } = require('../utils/serverDb');
const {
  isAntinukeArmed,
  isImmune,
  punishAttacker,
  resolveAuditExecutor,
  ensureDualBackupRoles,
  isAdjustingBackupRoles
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(oldMember, newMember, client) {
    if (!newMember || !newMember.guild) return;
    const guild = newMember.guild;

    // ─────────────────────────────────────────────────────────────
    // 0. Member Server Nickname Update Sentinel (Review #4 / 2.2)
    // ─────────────────────────────────────────────────────────────
    try {
      if (oldMember.nickname !== newMember.nickname) {
        // Automod: Inspect updated nickname for prohibited keywords, invites, or scam links
        if (newMember.nickname) {
          try {
            const { checkAutomodText } = require('../utils/automodEngine');
            const automodHit = checkAutomodText(newMember.nickname, guild, client);
            if (automodHit && typeof newMember.setNickname === 'function') {
              await newMember.setNickname('Moderated Nickname', `Automod: ${automodHit.violation}`).catch(() => null);
            }
          } catch (_) {}
        }

        const sdb = getServerDb(guild.id);
        const logRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'log_members' OR key = 'audit_log_channel'").get();
        if (logRow && logRow.value) {
          const channel = guild.channels.cache.get(logRow.value);
          if (channel && channel.isTextBased()) {
            const embed = createEmbed({
              color: 0x5865F2,
              title: '🏷️  Member Nickname Updated',
              description: `Member <@${newMember.id}> (\`${newMember.id}\`) had their server nickname updated.`,
              fields: [
                {
                  name: 'Nickname Changed',
                  value: `**Old:** \`${oldMember.nickname || 'None'}\`\n**New:** \`${newMember.nickname || 'None'}\``,
                  inline: true
                }
              ],
              thumbnail: newMember.user?.displayAvatarURL?.(),
              footerText: `User ID: ${newMember.id} • Tungsten Identity Sentinel`
            });

            await channel.send({ embeds: [embed] }).catch(() => null);
          }
        }
      }
    } catch (_) {}

    // C6: If oldMember or newMember is missing or partial, role cache is empty, causing massive false positives
    if (!oldMember || !newMember || oldMember.partial || newMember.partial) return;
    if (oldMember === newMember) return;

    if (!isAntinukeArmed(guild.id)) return;

    const oldCache = oldMember.roles?.cache;
    const newCache = newMember.roles?.cache;

    // Check if role caches are the exact same reference or have equal contents
    const sameRoleCache = Boolean(
      oldCache && newCache && (
        oldCache === newCache ||
        (typeof oldCache.equals === 'function' && oldCache.equals(newCache))
      )
    );

    // ─────────────────────────────────────────────────────────────
    // 1. Bot Self-Preservation Sentinel (Zero-Bypass Demotion Defense)
    // ─────────────────────────────────────────────────────────────
    const botId = client?.user?.id;
    if (botId && newMember.id === botId) {
      // If backup roles are actively being added, created, or adjusted, ignore this event to prevent recursive loops
      if (isAdjustingBackupRoles(guild.id)) return;

      const permsChanged = oldMember.permissions?.bitfield !== newMember.permissions?.bitfield;
      if (sameRoleCache && !permsChanged) return;

      const lostAdmin = Boolean(
        oldMember.permissions?.has?.(PermissionsBitField.Flags.Administrator) &&
        !newMember.permissions?.has?.(PermissionsBitField.Flags.Administrator)
      );

      const oldRolesList = !sameRoleCache && oldCache
        ? (typeof oldCache.values === 'function' ? [...oldCache.values()] : [...oldCache])
        : [];
      const newRolesMap = newCache || new Map();
      const removedRoles = sameRoleCache ? [] : oldRolesList.filter(r => !newRolesMap.has(r.id));
      const lostBackupRole = removedRoles.some(r =>
        r.name?.startsWith('Tungsten Backup') ||
        r.name?.includes('Backup Tier')
      );

      if (lostAdmin || lostBackupRole) {
        try {
          const executor = await resolveAuditExecutor(guild, AuditLogEvent.MemberRoleUpdate, {
            targetId: botId,
            maxRetries: 3
          });

          // Verify executor is resolved, not the bot itself, and not immune
          if (!executor || executor.id === botId || isImmune(guild, executor.id, 'all', client)) {
            return;
          }

          await punishAttacker(
            guild,
            executor,
            "Rogue demotion exploit: Attempted to strip Tungsten's Administrator permissions/roles",
            client,
            'Bot Self-Preservation Sentinel',
            'server_update'
          );
          await ensureDualBackupRoles(guild, { force: true });
        } catch (selfPreserveErr) {
          console.warn(`[Bot Self-Preservation Error] in ${guild.id}:`, selfPreserveErr.message);
        }
      }
      return;
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Anti-Role Escalation for Other Members
    // ─────────────────────────────────────────────────────────────
    if (sameRoleCache) return;
    // Detect newly added roles
    const newRolesList = newMember.roles?.cache
      ? (typeof newMember.roles.cache.values === 'function' ? [...newMember.roles.cache.values()] : [...newMember.roles.cache])
      : [];
    const oldRolesMap = oldMember.roles?.cache || new Map();
    const addedRoles = newRolesList.filter(r => {
      if (typeof oldRolesMap.has === 'function') {
        return !oldRolesMap.has(r.id);
      }
      if (Array.isArray(oldRolesMap)) {
        return !oldRolesMap.some(oldR => (oldR.id || oldR) === r.id);
      }
      return true;
    });

    if (addedRoles.length === 0) return;

    // Check if any added role has any dangerous permission: Administrator, ManageGuild, ManageRoles, ManageChannels, BanMembers, KickMembers
    const DANGEROUS_PERMS = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.ManageGuild,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.KickMembers,
      'Administrator',
      'ManageGuild',
      'ManageRoles',
      'ManageChannels',
      'BanMembers',
      'KickMembers'
    ];

    const dangerousAdded = addedRoles.filter(r => {
      if (!r || !r.permissions) return false;
      if (typeof r.permissions.has === 'function') {
        return DANGEROUS_PERMS.some(p => {
          try {
            return r.permissions.has(p);
          } catch (_) {
            return false;
          }
        });
      }
      return false;
    });

    if (dangerousAdded.length === 0) return;

    try {
      // C5: Target matching and extraMatch validating $add contains the dangerous role ID
      const executor = await resolveAuditExecutor(guild, AuditLogEvent.MemberRoleUpdate, {
        targetId: newMember.id,
        extraMatch: (entry) => {
          if (!entry.changes) return true;
          return entry.changes.some(c => c.key === '$add' && Array.isArray(c.new) && c.new.some(r => dangerousAdded.some(d => d.id === r.id)));
        }
      });
      if (!executor) return;

      // Check isImmune(guild.id, executor.id, client) with scope 'roles'
      const immune = isImmune(guild.id, executor.id, 'roles', client) || isImmune(guild, executor.id, 'roles', client);
      if (!immune) {
        // Immediately revert the grant: newMember.roles.remove(dangerousRole, 'Antinuke: Unauthorized dangerous role grant reverted')
        for (const dangerousRole of dangerousAdded) {
          await newMember.roles.remove(dangerousRole, 'Antinuke: Unauthorized dangerous role grant reverted').catch(() => null);
        }

        // Punish executor: punishAttacker(guild, executor, 'Granted unauthorized role with administrative permissions', client, 'Anti-Role Escalation', 'role_escalation')
        await punishAttacker(
          guild,
          executor,
          'Granted unauthorized role with administrative permissions',
          client,
          'Anti-Role Escalation',
          'role_escalation'
        );
      }
    } catch (e) {
      console.warn(`[Anti-Member Role Update Error] in ${guild.id}:`, e.message);
    }
  }
};
