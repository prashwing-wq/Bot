/**
 * Emoji Delete Event (Node.js)
 * Implements Anti-Emoji Mass Delete Sentinel (C8).
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'emojiDelete',
  async execute(emoji, client) {
    if (!emoji || !emoji.guild) return;
    const guild = emoji.guild;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const rule = getAntinukeRule(guild.id, 'emoji');
      if (rule && !rule.enabled) return;

      const executor = await resolveAuditExecutor(guild, AuditLogEvent.EmojiDelete, { targetId: emoji.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'emoji')) return;

      const exceeded = checkVectorRateLimit(guild.id, executor.id, 'emoji');
      if (exceeded || !rule || rule.limit_count <= 1) {
        await punishAttacker(guild, executor, `Deleted emoji :${emoji.name}: (${emoji.id}) without authorization`, client, 'Anti-Emoji Delete', 'emoji');
      }
    } catch (e) {
      console.warn(`[Anti-Emoji Delete Error] in ${guild.id}:`, e.message);
    }
  }
};
