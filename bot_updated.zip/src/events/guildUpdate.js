/**
 * Guild Update Event (Node.js)
 * Implements Anti-Vanity URL Steal Guard and Zero-Fail Anti-Server Tampering Sentinel.
 * Defends server Name, Icon/Logo, Banner, Verification Level, and Vanity Code with instantaneous auto-revert.
 */
const { AuditLogEvent } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const {
  isAntinukeArmed,
  isImmune,
  punishAttacker,
  resolveAuditExecutor,
  getAntinukeRule,
  resolveServerBaselineIdentity,
  captureServerBaselineIdentity,
  resolveImageBuffer,
  getActiveRaidAttacker,
  recordActiveRaidAttacker
} = require('../utils/antinukeEngine');
const { isOwner } = require('../utils/tools');

module.exports = {
  name: 'guildUpdate',
  async execute(oldGuild, newGuild, client) {
    if (!newGuild) return;

    // ─────────────────────────────────────────────────────────────
    // 1. Vanity URL Tampering Guard
    // ─────────────────────────────────────────────────────────────
    if (oldGuild.vanityURLCode !== newGuild.vanityURLCode) {
      try {
        const sdb = getServerDb(newGuild.id);
        const row = sdb.prepare('SELECT enabled, vanity_code, action FROM vanity_guard WHERE guild_id = ?').get(newGuild.id);

        if (row && row.enabled === 1 && row.vanity_code) {
          const targetCode = row.vanity_code;
          if (newGuild.vanityURLCode !== targetCode) {
            let executor = await resolveAuditExecutor(newGuild, AuditLogEvent.GuildUpdate, { targetId: newGuild.id });
            if (!executor) {
              const activeAttacker = getActiveRaidAttacker(newGuild.id);
              if (activeAttacker?.executor) executor = activeAttacker.executor;
            }

            if (executor && !isImmune(newGuild, executor.id, 'vanity')) {
              await Promise.allSettled([
                punishAttacker(
                  newGuild,
                  executor,
                  `Attempted to change server vanity URL from '${targetCode}' to '${newGuild.vanityURLCode}'`,
                  client,
                  'Anti-Vanity Tampering',
                  'vanity',
                  null,
                  { isBot: executor?.bot }
                ),
                newGuild.setVanityCode(targetCode, '[Tungsten Vanity Guard] Reclaiming original vanity URL.').catch(() => null)
              ]);
            }
          }
        }
      } catch (e) {
        console.warn(`[Vanity Guard Error] in ${newGuild.id}:`, e.message);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Server Name / Icon / Banner / Verification Tampering Sentinel
    // ─────────────────────────────────────────────────────────────
    if (isAntinukeArmed(newGuild.id)) {
      const rule = getAntinukeRule(newGuild.id, 'server_update');
      if (rule && !rule.enabled) return;

      const nameChanged = oldGuild.name !== newGuild.name;
      const iconChanged = oldGuild.icon !== newGuild.icon;
      const bannerChanged = oldGuild.banner !== newGuild.banner;
      const verifChanged = oldGuild.verificationLevel !== newGuild.verificationLevel;

      if (nameChanged || iconChanged || bannerChanged || verifChanged) {
        try {
          let executor = await resolveAuditExecutor(newGuild, AuditLogEvent.GuildUpdate, {
            maxRetries: 5,
            retryDelays: [50, 150, 300, 600, 1000]
          });
          if (!executor) {
            const activeAttacker = getActiveRaidAttacker(newGuild.id);
            if (activeAttacker?.executor) executor = activeAttacker.executor;
          }
          if (!executor && newGuild.fetchAuditLogs) {
            try {
              const recentAudit = await newGuild.fetchAuditLogs({ limit: 8 }).catch(() => null);
              if (recentAudit && recentAudit.entries) {
                for (const entry of recentAudit.entries.values()) {
                  const age = Date.now() - (entry.createdTimestamp || Date.now());
                  if (age <= 30000 && entry.executor) {
                    const eid = String(entry.executor.id);
                    if (eid !== client?.user?.id && eid !== newGuild.ownerId && !isImmune(newGuild, eid, 'server', client)) {
                      executor = entry.executor;
                      recordActiveRaidAttacker(newGuild.id, executor);
                      break;
                    }
                  }
                }
              }
            } catch (_) {}
          }
          if (!executor) {
            const activeRaid = getActiveRaidAttacker(newGuild.id);
            if (activeRaid && activeRaid.executor) {
              executor = activeRaid.executor;
            }
          }

          if (!executor && newGuild.members?.cache) {
            // Only consider recent bots that joined during an attack (< 15m), never long-standing bots
            const rogueBot = [...newGuild.members.cache.values()].find(m =>
              m.user?.bot &&
              m.id !== client?.user?.id &&
              !isImmune(newGuild, m.id, 'server', client) &&
              (Date.now() - (m.joinedTimestamp || 0) < 15 * 60 * 1000) &&
              (m.permissions?.has('ManageGuild') || m.permissions?.has('Administrator'))
            );
            if (rogueBot) {
              executor = rogueBot.user;
              recordActiveRaidAttacker(newGuild.id, executor);
            }
          }

          // If legitimate staff/owner changed the settings, save new baseline and do not revert
          if (executor && (executor.id === newGuild.ownerId || isOwner(executor.id) || isImmune(newGuild, executor.id, 'server', null, true))) {
            await captureServerBaselineIdentity(newGuild).catch(() => null);
            return;
          }

          // If no executor was resolved and no active raid occurred, check if name or multi-vector tampering matches defacement
          const isDefacementPattern = (
            (nameChanged && /(?:defac|nuk|raid|hack|fuck|crash|rip|wiz|trash|destroy)/i.test(newGuild.name)) ||
            (nameChanged && iconChanged) ||
            (nameChanged && bannerChanged) ||
            (iconChanged && bannerChanged)
          );
          if (!executor && !isDefacementPattern) {
            // Legitimate server edit by owner or authorized staff without audit log lag
            await captureServerBaselineIdentity(newGuild).catch(() => null);
            return;
          }

          const details = [];
          if (nameChanged) details.push(`Name: '${oldGuild.name}' -> '${newGuild.name}'`);
          if (iconChanged) details.push('Icon/Logo modified');
          if (bannerChanged) details.push('Banner modified');
          if (verifChanged) details.push(`Verification Level: ${oldGuild.verificationLevel} -> ${newGuild.verificationLevel}`);

          const revertPromises = [];

          if (executor) {
            revertPromises.push(
              punishAttacker(
                newGuild,
                executor,
                `Tampered with server settings without authorization (${details.join(', ')})`,
                client,
                'Anti-Server Tampering',
                'server_update',
                null,
                { isBot: executor?.bot }
              )
            );
          }

          // Auto-Heal: Revert Name, Icon/Logo, Banner, Verification Level
          if (rule?.auto_heal !== false) {
            const baseline = resolveServerBaselineIdentity(newGuild.id) || {};

            // 1. Revert Name
            if (nameChanged && typeof newGuild.setName === 'function') {
              const targetName = baseline.name || oldGuild.name;
              if (targetName && newGuild.name !== targetName) {
                revertPromises.push(newGuild.setName(targetName, '[Tungsten Antinuke] Reverting unauthorized server name change.').catch(() => null));
              }
            }

            // 2. Revert Icon / Logo (via binary buffer)
            if (iconChanged && typeof newGuild.setIcon === 'function') {
              revertPromises.push((async () => {
                try {
                  let iconBuf = null;
                  if (baseline.icon_base64) {
                    iconBuf = await resolveImageBuffer(baseline.icon_base64);
                  }
                  if (!iconBuf && baseline.icon_url) {
                    iconBuf = await resolveImageBuffer(baseline.icon_url);
                  }
                  if (!iconBuf && typeof oldGuild.iconURL === 'function') {
                    const oldUrl = oldGuild.iconURL({ size: 1024, forceStatic: false });
                    if (oldUrl) iconBuf = await resolveImageBuffer(oldUrl);
                  }
                  if (iconBuf) {
                    await newGuild.setIcon(iconBuf, '[Tungsten Antinuke] Reverting unauthorized server icon change.');
                  } else if (!oldGuild.icon && !baseline.icon_url) {
                    await newGuild.setIcon(null, '[Tungsten Antinuke] Reverting unauthorized server icon change.');
                  }
                } catch (iconErr) {
                  console.warn(`[Icon Revert Error] in ${newGuild.id}:`, iconErr.message);
                }
              })());
            }

            // 3. Revert Banner (via binary buffer)
            if (bannerChanged && typeof newGuild.setBanner === 'function') {
              revertPromises.push((async () => {
                try {
                  let bannerBuf = null;
                  if (baseline.banner_base64) {
                    bannerBuf = await resolveImageBuffer(baseline.banner_base64);
                  }
                  if (!bannerBuf && baseline.banner_url) {
                    bannerBuf = await resolveImageBuffer(baseline.banner_url);
                  }
                  if (!bannerBuf && typeof oldGuild.bannerURL === 'function') {
                    const oldUrl = oldGuild.bannerURL({ size: 2048 });
                    if (oldUrl) bannerBuf = await resolveImageBuffer(oldUrl);
                  }
                  if (bannerBuf) {
                    await newGuild.setBanner(bannerBuf, '[Tungsten Antinuke] Reverting unauthorized server banner change.');
                  } else if (!oldGuild.banner && !baseline.banner_url) {
                    await newGuild.setBanner(null, '[Tungsten Antinuke] Reverting unauthorized server banner change.');
                  }
                } catch (bannerErr) {
                  console.warn(`[Banner Revert Error] in ${newGuild.id}:`, bannerErr.message);
                }
              })());
            }

            // 4. Revert Verification Level
            if (verifChanged && typeof newGuild.setVerificationLevel === 'function') {
              const targetVerif = (baseline.verification_level !== undefined && baseline.verification_level !== null)
                ? baseline.verification_level
                : oldGuild.verificationLevel;
              revertPromises.push(newGuild.setVerificationLevel(targetVerif, '[Tungsten Antinuke] Reverting unauthorized verification change.').catch(() => null));
            }
          }

          await Promise.allSettled(revertPromises);
        } catch (e) {
          console.warn(`[Anti-Server Tampering Error] in ${newGuild.id}:`, e.message);
        }
      }
    }
  }
};
