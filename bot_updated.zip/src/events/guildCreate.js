/**
 * Guild Create Event
 * Automatically provisions a dedicated database folder, snapshots channels/roles,
 * and captures baseline server identity for newly joined servers (ignoreIfExists=true).
 */
const { registerGuild } = require('../utils/serverDb');
const { cacheChannelSnapshot, cacheRoleSnapshot, captureServerBaselineIdentity } = require('../utils/antinukeEngine');

module.exports = {
  name: 'guildCreate',
  async execute(guild, client) {
    console.log(`[Tungsten Node] Joined new server: ${guild.name} (${guild.id})`);
    try {
      await registerGuild(guild);
    } catch (e) {
      console.warn(`[GuildCreate] Notice setting up server db for ${guild.id}: ${e.message}`);
    }

    try {
      if (guild.channels?.cache) {
        for (const ch of guild.channels.cache.values()) {
          cacheChannelSnapshot(ch);
        }
      }
      if (guild.roles?.cache) {
        for (const r of guild.roles.cache.values()) {
          cacheRoleSnapshot(r);
        }
      }
      await captureServerBaselineIdentity(guild);
    } catch (err) {
      console.warn(`[GuildCreate Baseline Error] in ${guild.id}: ${err.message}`);
    }
  }
};
