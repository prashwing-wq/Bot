/**
 * Guild Audit Log Entry Create Event (Node.js)
 * Real-time Gateway OP push receiver for instant zero-latency executor resolution,
 * watchlist surveillance overrides, and autonomous sub-30ms attack mitigation.
 */
const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { recordAuditLogEntry, handleRealtimeAuditEntry } = require('../utils/antinukeEngine');
const { isWatchlisted } = require('../utils/watchlist');
const { resolveSecurityLogChannel } = require('../utils/threatIntelligence');
const { resolveEmoji } = require('../utils/emojis');
const config = require('../config');

module.exports = {
  name: 'guildAuditLogEntryCreate',
  async execute(entry, guild, client) {
    if (!entry) return;
    try {
      // 1. Record pushed audit log entry to zero-latency resolution cache
      recordAuditLogEntry(entry);

      // 2. Resolve target guild
      const effectiveGuild = guild || (client?.guilds?.cache ? client.guilds.cache.get(entry.guildId) : null);
      if (effectiveGuild) {
        // 2.5 Check Watchlist surveillance overrides on audit events (Feature 2)
        const executorId = entry.executorId || entry.executor?.id;
        if (executorId && isWatchlisted(effectiveGuild.id, executorId)) {
          entry._watchlistOverride = true;

          // Dispatch heightened surveillance log to designated security channel
          try {
            const secChannel = await resolveSecurityLogChannel(effectiveGuild);
            if (secChannel) {
              const shieldEmoji = resolveEmoji(client, 'shield') || resolveEmoji(effectiveGuild, 'shield') || '<a:tungsten_shield:1567242104923627574>';
              const warnEmoji = resolveEmoji(client, 'warning') || resolveEmoji(effectiveGuild, 'warning') || '<a:tungsten_warn:1567246685082746940>';
              const actionName = (AuditLogEvent && AuditLogEvent[entry.action]) ? AuditLogEvent[entry.action] : `Action_${entry.action}`;
              const targetName = entry.targetId ? `<@${entry.targetId}> (\`${entry.targetId}\`)` : (entry.target?.name || 'N/A');

              const embed = new EmbedBuilder()
                .setColor(config.COLORS.WARNING || 0xFEE75C)
                .setTitle(`${shieldEmoji} Watchlist Surveillance: Audit Event Detected`)
                .setDescription(
                  `> **Monitored Actor:** <@${executorId}> (\`${executorId}\`)\n` +
                  `> **Audit Action:** \`${actionName}\`\n` +
                  `> **Target:** ${targetName}\n` +
                  `> **Surveillance Policy:** ${warnEmoji} Watchlist active — zero-tolerance evaluation enforced (limit_count overridden to 1).`
                )
                .setFooter({ text: 'Tungsten Watchlist Surveillance Sentinel' })
                .setTimestamp();

              await secChannel.send({ embeds: [embed] }).catch(() => null);
            }
          } catch (_) {}
        }

        // 3. Autonomous real-time threat neutralization and auto-healing
        await handleRealtimeAuditEntry(entry, effectiveGuild, client || effectiveGuild.client);
      }
    } catch (err) {
      console.warn(`[guildAuditLogEntryCreate Error] ${err.message}`);
    }
  }
};
