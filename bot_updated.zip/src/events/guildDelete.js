/**
 * Tungsten guildDelete Event Handler (guildDelete.js)
 * Cleanly frees server database handles, flushes SQLite WAL buffers,
 * and clears guild-specific timers when the bot leaves or is kicked from a guild.
 */
const { closeServerDb } = require('../utils/serverDb');
const { clearGhostpingCandidates } = require('../utils/ghostpingCache');

module.exports = {
  name: 'guildDelete',
  async execute(guild, client) {
    if (!guild || !guild.id) return;
    console.log(`[Tungsten Node] Left guild: ${guild.name || guild.id} (${guild.id})`);

    try {
      // 1. Checkpoint and close SQLite database connection
      closeServerDb(guild.id);

      // 2. Clear ghostping candidate cache for channels in this guild
      try {
        if (typeof clearGhostpingCandidates === 'function') {
          clearGhostpingCandidates(guild.id);
        }
      } catch (e) {}
    } catch (err) {
      console.warn(`[guildDelete] Notice cleaning up guild ${guild.id}: ${err.message}`);
    }
  }
};
