/**
 * Guild Ban Add Event (Node.js)
 * Implements Anti-Ban Protection & Auto-Heal Unban System.
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban, client) {
    if (!ban || !ban.guild) return;
    const guild = ban.guild;

    if (isAntinukeArmed(guild.id)) {
      try {
        const rule = getAntinukeRule(guild.id, 'ban');
        if (!rule || rule.enabled) {
          const victim = ban.user;
          const targetId = victim?.id;
          const executor = await resolveAuditExecutor(guild, AuditLogEvent.MemberBanAdd, { targetId });
          if (executor) {
            const executorId = executor.id;

            // Check immunity
            if (!isImmune(guild, executorId, 'ban')) {
              // Check vector rate limit (Ultra Zero-Tolerance: limit <= 1)
              const exceeded = checkVectorRateLimit(guild.id, executorId, 'ban');
              if (exceeded || !rule || rule.limit_count <= 1) {
                const actions = [
                  punishAttacker(guild, executor, `Banned member ${victim?.username || targetId} (${targetId}) without authorization`, client, 'Anti-Ban Interception', 'ban')
                ];

                // Auto-Heal: Revert unauthorized ban if enabled
                if (rule?.auto_heal && targetId) {
                  actions.push(guild.bans.remove(targetId, '[Tungsten Auto-Heal] Reverting unauthorized ban executed by rogue admin.').catch(() => null));
                }

                await Promise.allSettled(actions);
              }
            }
          }
        }
      } catch (e) {
        console.warn(`[Anti-Ban Error] in ${guild.id}:`, e.message);
      }
    }

    // ─────────────────────────────────────────────────────────────
    // Automated Workflow Sequence Dispatch (Slice 3.3)
    // ─────────────────────────────────────────────────────────────
    try {
      const { executeWorkflows } = require('../utils/workflowEngine');
      await executeWorkflows(guild, 'member_ban', { ban, user: ban.user, guild }, client);
    } catch (e) {
      console.warn(`[Workflow Error] member_ban in ${guild.id}:`, e.message);
    }
  }
};
