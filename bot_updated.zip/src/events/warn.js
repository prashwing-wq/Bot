/**
 * Client Warning Event (Node.js)
 * Implements Gateway Diagnostic Telemetry (Roadmap Section 6).
 */
module.exports = {
  name: 'warn',
  async execute(info) {
    console.warn('[Discord Client Warning]:', info);
  }
};
