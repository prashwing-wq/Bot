/**
 * Message Delete Bulk Event (Node.js)
 * Implements bulk message deletion tracking and audit logging with transcript attachment (Roadmap Feature E).
 */
const { AttachmentBuilder } = require('discord.js');
const { createEmbed, formatClockTime } = require('../utils/tools');
const { getLogChannel } = require('../utils/logRouter');

module.exports = {
  name: 'messageDeleteBulk',
  async execute(messages, channel) {
    if (!channel || !channel.guild) return;
    const guild = channel.guild;

    try {
      const logChannel = getLogChannel(guild, 'log_messages');
      if (!logChannel || !logChannel.isTextBased()) return;

      const count = messages ? messages.size : 0;
      const embed = createEmbed({
        color: 0xed4245,
        title: '<a:tungsten_sweep:1567242656281657414> Bulk Message Purge Detected',
        description:
          `> Channel: <#${channel.id}> (\`${channel.id}\`)\n` +
          `> Messages Purged: **${count}**\n` +
          `> Transcript: Attached below\n` +
          `> Timestamp: **${formatClockTime(Date.now())}**`,
        footer: { text: `Tungsten Message Telemetry • ${guild.name}` }
      });

      // Build text transcript of deleted messages
      let transcript = `=== TUNGSTEN BULK MESSAGE DELETION TRANSCRIPT ===\nServer: ${guild.name} (${guild.id})\nChannel: #${channel.name} (${channel.id})\nDate: ${new Date().toISOString()}\nTotal Messages Purged: ${count}\n================================================\n\n`;

      if (messages && messages.size > 0) {
        const sorted = [...messages.values()].reverse();
        for (const m of sorted) {
          const authorTag = m.author ? `${m.author.tag || m.author.username} (${m.author.id})` : 'Unknown User';
          const time = m.createdAt ? m.createdAt.toISOString() : 'Unknown Time';
          const content = m.content || '[No text content / embed or attachment]';
          transcript += `[${time}] ${authorTag}: ${content}\n`;
        }
      } else {
        transcript += '[No message payload available in cache]\n';
      }

      const attachment = new AttachmentBuilder(Buffer.from(transcript, 'utf-8'), {
        name: `bulk-delete-${channel.id}-${Date.now()}.txt`
      });

      await logChannel.send({ embeds: [embed], files: [attachment] }).catch(() => null);
    } catch (e) {
      console.warn(`[messageDeleteBulk] Error in ${guild.id}:`, e.message);
    }
  }
};
