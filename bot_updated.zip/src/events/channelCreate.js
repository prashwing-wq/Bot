/**
 * Channel Create Event (Node.js)
 * Implements Anti-Channel Spam Rate Limiter, Zero-Tolerance Raid Cleanup, & Snapshot Caching.
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor,
  cacheChannelSnapshot,
  markBotDeletedEntity,
  evictChannelSnapshot,
  isAutoHealedEntity,
  isBotCreatedEntity,
  markBotCreatedEntity,
  getActiveRaidAttacker,
  recordActiveRaidAttacker,
  triggerAutonomousDisasterRecovery
} = require('../utils/antinukeEngine');

// Sliding window tracker for channel creation burst velocity (5s)
const _CHANNEL_BURST_TRACKER = new Map();

module.exports = {
  name: 'channelCreate',
  async execute(channel, client) {
    if (!channel || !channel.guild) return;
    const guild = channel.guild;

    // Fast-path bypass: ignore channels created during auto-heal or by the bot itself
    if (isAutoHealedEntity(channel.id) || isBotCreatedEntity(channel.id)) {
      return;
    }

    if (!isAntinukeArmed(guild.id)) {
      cacheChannelSnapshot(channel);
      return;
    }

    try {
      const rule = getAntinukeRule(guild.id, 'channel_create');
      if (rule && !rule.enabled) {
        cacheChannelSnapshot(channel);
        return;
      }

      // Check channel name for nuke patterns
      const channelName = channel.name || '';
      const isNukeName = /(?:nuked-by|raided-by|hacked-by|fucked-by|wizzed-by|destroyed-by|defaced-by|t-o-k-e-n)/i.test(channelName);
      if (isNukeName) {
        let nukeExecutor = await resolveAuditExecutor(guild, AuditLogEvent.ChannelCreate, {
          targetId: channel.id,
          maxRetries: 2,
          retryDelays: [50, 150],
          fallbackRecent: true
        });

        const botId = client?.user?.id;
        if (nukeExecutor && (nukeExecutor.id === botId || nukeExecutor.id === guild.ownerId || isImmune(guild, nukeExecutor.id, 'channel', client))) {
          markBotCreatedEntity(channel.id);
          cacheChannelSnapshot(channel);
          return;
        }

        markBotDeletedEntity(channel.id);
        evictChannelSnapshot(channel.id);
        await channel.delete('[Tungsten Anti-Raid] Rogue nuke channel deleted.').catch(() => null);

        if (!nukeExecutor) {
          const curAttacker = getActiveRaidAttacker(guild.id);
          if (curAttacker && curAttacker.executor) {
            nukeExecutor = curAttacker.executor;
          }
        }

        if (nukeExecutor) {
          recordActiveRaidAttacker(guild.id, nukeExecutor);
          await punishAttacker(
            guild,
            nukeExecutor,
            `Created nuke channel '${channelName}'`,
            client,
            'Anti-Channel Spam',
            'channel_create',
            null,
            { isBot: Boolean(nukeExecutor?.bot) }
          );
        }

        await triggerAutonomousDisasterRecovery(guild, client, 'Nuke Channel Spam');
        return;
      }

      // Check velocity burst across the guild (anti-mass channel spam raid: 2 channels in 5s)
      const now = Date.now();
      let burst = _CHANNEL_BURST_TRACKER.get(guild.id) || [];
      burst = burst.filter(t => now - t < 5000);
      burst.push(now);
      _CHANNEL_BURST_TRACKER.set(guild.id, burst);

      const isBurstAttack = burst.length >= 2;

      // During active raid: ANY channel created by anyone other than server owner or whitelisted staff is DELETED IMMEDIATELY ON SIGHT!
      const activeRaidAttacker = getActiveRaidAttacker(guild.id);
      if (activeRaidAttacker) {
        let raidExecutor = await resolveAuditExecutor(guild, AuditLogEvent.ChannelCreate, {
          targetId: channel.id,
          maxRetries: 2,
          retryDelays: [50, 150],
          fallbackRecent: true
        });

        const isWhitelistedOrOwner = raidExecutor && (
          raidExecutor.id === guild.ownerId ||
          raidExecutor.id === client?.user?.id ||
          isImmune(guild, raidExecutor.id, 'channel', client)
        );

        if (!isWhitelistedOrOwner) {
          markBotDeletedEntity(channel.id);
          evictChannelSnapshot(channel.id);
          await channel.delete('[Tungsten Anti-Raid] Rogue channel created during active raid deleted on sight.').catch(() => null);

          const targetPunish = raidExecutor || activeRaidAttacker.executor;
          if (targetPunish && targetPunish.id !== client?.user?.id && !isImmune(guild, targetPunish.id, 'channel', client)) {
            recordActiveRaidAttacker(guild.id, targetPunish);
            if (targetPunish.bot) {
              if (guild.bans?.create) {
                await guild.bans.create(targetPunish.id, { reason: '[Tungsten Anti-Raid] Rogue bot creating channels during active raid' }).catch(() => null);
              } else if (guild.members?.ban) {
                await guild.members.ban(targetPunish.id, { reason: '[Tungsten Anti-Raid] Rogue bot creating channels during active raid' }).catch(() => null);
              }
            }
            await punishAttacker(
              guild,
              targetPunish,
              'Created channel during active raid',
              client,
              'Anti-Channel Spam',
              'channel_create',
              null,
              { isBot: Boolean(targetPunish.bot) }
            );
          }
          await triggerAutonomousDisasterRecovery(guild, client, 'Active Raid Channel Creation');
          return;
        }
      }

      let executor = await resolveAuditExecutor(guild, AuditLogEvent.ChannelCreate, {
        targetId: channel.id,
        maxRetries: 5,
        retryDelays: [50, 150, 300, 600, 1000],
        fallbackRecent: true
      });

      // Fallback 1: If audit log is delayed or slow during burst, check active raid attacker
      if (!executor) {
        const activeAttacker = getActiveRaidAttacker(guild.id);
        if (activeAttacker && activeAttacker.executor) {
          executor = activeAttacker.executor;
        }
      }

      // Fallback 2: Check recent audit logs without targetId restriction
      if (!executor && isBurstAttack && guild.fetchAuditLogs) {
        try {
          const recentLogs = await guild.fetchAuditLogs({ limit: 8, type: AuditLogEvent.ChannelCreate }).catch(() => null);
          if (recentLogs && recentLogs.entries) {
            for (const entry of recentLogs.entries.values()) {
              const age = Date.now() - (entry.createdTimestamp || Date.now());
              if (age <= 20000 && entry.executor) {
                const eid = String(entry.executor.id);
                if (eid !== client?.user?.id && eid !== guild.ownerId && !isImmune(guild, eid, 'channel', client)) {
                  executor = entry.executor;
                  recordActiveRaidAttacker(guild.id, executor);
                  break;
                }
              }
            }
          }
        } catch (_) {}
      }



      if (executor) {
        const botId = client?.user?.id;
        if (executor.id === botId || isImmune(guild, executor.id, 'channel', client)) {
          markBotCreatedEntity(channel.id);
          cacheChannelSnapshot(channel);
          return;
        }

        const exceeded = checkVectorRateLimit(guild.id, executor.id, 'channel_create');
        if (exceeded || !rule || rule.limit_count <= 1 || isBurstAttack) {
          markBotDeletedEntity(channel.id);
          evictChannelSnapshot(channel.id);
          recordActiveRaidAttacker(guild.id, executor);

          if (executor.bot) {
            if (guild.bans?.create) {
              await guild.bans.create(executor.id, { reason: '[Tungsten Anti-Raid] Rogue bot mass creating channels' }).catch(() => null);
            } else if (guild.members?.ban) {
              await guild.members.ban(executor.id, { reason: '[Tungsten Anti-Raid] Rogue bot mass creating channels' }).catch(() => null);
            }
          }

          await Promise.allSettled([
            punishAttacker(
              guild,
              executor,
              'Exceeded mass channel creation rate limit (spam raid)',
              client,
              'Anti-Channel Spam',
              'channel_create',
              null,
              { isBot: Boolean(executor?.bot) }
            ),
            channel.delete('[Tungsten Anti-Raid] Deleting rogue channel created during spam attack.').catch(() => null)
          ]);

          if (isBurstAttack) {
            await triggerAutonomousDisasterRecovery(guild, client, 'Burst Channel Spam');
          }
          return;
        }
      } else if (isBurstAttack) {
        // High-velocity raid without resolved executor yet: delete rogue channel immediately to stop the spam
        markBotDeletedEntity(channel.id);
        evictChannelSnapshot(channel.id);
        await channel.delete('[Tungsten Anti-Raid] Deleting rogue channel created during burst raid.').catch(() => null);
        await triggerAutonomousDisasterRecovery(guild, client, 'Burst Channel Spam');

        // Background deferred task: retry resolving the executor in 300ms and 800ms so the nuker bot NEVER escapes punishment
        (async () => {
          for (const delay of [300, 800]) {
            await new Promise(r => setTimeout(r, delay));
            const deferredExecutor = await resolveAuditExecutor(guild, AuditLogEvent.ChannelCreate, {
              maxRetries: 2,
              retryDelays: [100, 300],
              fallbackRecent: true
            });
            if (deferredExecutor && !isImmune(guild, deferredExecutor.id, 'channel', client) && deferredExecutor.id !== client?.user?.id) {
              recordActiveRaidAttacker(guild.id, deferredExecutor);
              if (deferredExecutor.bot) {
                if (guild.bans?.create) {
                  guild.bans.create(deferredExecutor.id, { reason: '[Tungsten Anti-Raid] Rogue bot creating burst channels' }).catch(() => null);
                } else if (guild.members?.ban) {
                  guild.members.ban(deferredExecutor.id, { reason: '[Tungsten Anti-Raid] Rogue bot creating burst channels' }).catch(() => null);
                }
              }
              await punishAttacker(
                guild,
                deferredExecutor,
                'Identified via deferred audit correlation during channel spam raid',
                client,
                'Anti-Channel Spam',
                'channel_create',
                null,
                { isBot: Boolean(deferredExecutor?.bot) }
              );
              break;
            }
          }
        })().catch(() => {});
        return;
      }

      // Channel is legitimate staff creation: snapshot it
      cacheChannelSnapshot(channel);
    } catch (e) {
      console.warn(`[Anti-Channel Create Error] in ${guild.id}:`, e.message);
    }
  }
};
