/**
 * Emoji Create Event (Node.js)
 * Implements Anti-Emoji Mass Creation Sentinel (Roadmap Section 6).
 */
const { AuditLogEvent } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'emojiCreate',
  async execute(emoji, client) {
    if (!emoji || !emoji.guild) return;
    const guild = emoji.guild;

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const rule = getAntinukeRule(guild.id, 'emoji');
      if (rule && !rule.enabled) return;

      const executor = await resolveAuditExecutor(guild, AuditLogEvent.EmojiCreate, { targetId: emoji.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'emoji')) return;

      const exceeded = checkVectorRateLimit(guild.id, executor.id, 'emoji');
      if (exceeded) {
        await punishAttacker(guild, executor, `Mass Emoji Creation spam (${emoji.name}) without authorization`, client, 'Anti-Emoji Spam', 'emoji');
        await emoji.delete().catch(() => null);
      }
    } catch (e) {
      console.warn(`[emojiCreate] Error in ${guild.id}:`, e.message);
    }
  }
};
