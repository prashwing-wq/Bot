/**
 * Role Create Event (Node.js)
 * Implements Anti-Role Escalation, Mass Role Spam Protection, & Snapshot Caching.
 * Wick / Olympus / Zynrax production parity.
 */
const { AuditLogEvent, PermissionsBitField } = require('discord.js');
const {
  isAntinukeArmed,
  isImmune,
  getAntinukeRule,
  checkVectorRateLimit,
  punishAttacker,
  resolveAuditExecutor,
  cacheRoleSnapshot,
  markBotDeletedEntity,
  evictRoleSnapshot
} = require('../utils/antinukeEngine');

module.exports = {
  name: 'roleCreate',
  async execute(role, client) {
    if (!role || !role.guild) return;
    const guild = role.guild;

    // Fast-path bypass: Never treat legitimate backup roles as rogue escalation
    if (role.name?.includes('Backup Tier')) {
      cacheRoleSnapshot(role);
      return;
    }

    // Cache role snapshot for legitimate future restoration
    cacheRoleSnapshot(role);

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const rule = getAntinukeRule(guild.id, 'role_create');
      if (rule && !rule.enabled) return;

      const executor = await resolveAuditExecutor(guild, AuditLogEvent.RoleCreate, { targetId: role.id });
      if (!executor) return;

      if (isImmune(guild, executor.id, 'role')) {
        return;
      }

      // 1. Check if role has Administrator or dangerous management permissions
      const hasAdmin = role.permissions.has(PermissionsBitField.Flags.Administrator) ||
                        role.permissions.has(PermissionsBitField.Flags.ManageGuild) ||
                        role.permissions.has(PermissionsBitField.Flags.ManageRoles);

      if (hasAdmin) {
        markBotDeletedEntity(role.id);
        evictRoleSnapshot(role.id);
        await Promise.allSettled([
          punishAttacker(guild, executor, `Created role @${role.name} with dangerous Administrator permissions`, client, 'Anti-Role Escalation', 'role_create'),
          role.delete('[Tungsten Anti-Escalation] Rogue role with dangerous permissions deleted.').catch(() => null)
        ]);
        return;
      }

      // 2. Check mass role spam rate limit (Ultra Zero-Tolerance: limit <= 1)
      const exceeded = checkVectorRateLimit(guild.id, executor.id, 'role_create');
      if (exceeded || !rule || rule.limit_count <= 1) {
        markBotDeletedEntity(role.id);
        evictRoleSnapshot(role.id);
        await Promise.allSettled([
          punishAttacker(guild, executor, 'Exceeded mass role creation rate limit (spam raid)', client, 'Anti-Role Spam', 'role_create'),
          role.delete('[Tungsten Anti-Raid] Rogue role deleted during mass creation raid.').catch(() => null)
        ]);
      }
    } catch (e) {
      console.warn(`[Anti-Role Create Error] in ${guild.id}:`, e.message);
    }
  }
};
