/**
 * Tungsten Starboard Reaction Remove Sentinel (Node.js)
 * Updates star counts when reactions are revoked and cleans up posts
 * that drop below the configured threshold.
 */
const { getServerDb } = require('../utils/serverDb');
const { isModuleEnabled } = require('../utils/modulesHelper');
const { isStarEmoji, calculateValidStars, _STAR_LOCKS } = require('./messageReactionAdd');

module.exports = {
  name: 'messageReactionRemove',

  async execute(reaction, user, client) {
    if (!user || user.bot) return;
    if (!isStarEmoji(reaction.emoji)) return;

    try {
      if (reaction.partial) {
        await reaction.fetch().catch(() => null);
      }
      if (reaction.message && reaction.message.partial) {
        await reaction.message.fetch().catch(() => null);
      }
    } catch (_) {
      return;
    }

    const message = reaction.message;
    if (!message || !message.guild || !message.channel) return;

    if (!isModuleEnabled(message.guild.id, 'starboard')) return;

    const sdb = getServerDb(message.guild.id);
    const existing = sdb.prepare('SELECT * FROM starboard_messages WHERE guild_id = ? AND orig_message_id = ?')
      .get(message.guild.id, message.id);

    if (!existing) return;

    const threshRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_threshold'").get();
    const threshold = threshRow ? Math.max(1, parseInt(threshRow.value, 10)) : 3;

    const selfRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_selfstar'").get();
    const allowSelfStar = selfRow ? selfRow.value === '1' : false;

    // Concurrency Lock: Prevent race condition between reaction add and remove
    const lockKey = `${message.guild.id}:${message.id}`;
    if (_STAR_LOCKS.has(lockKey)) return;
    _STAR_LOCKS.add(lockKey);

    try {
      const starCount = await calculateValidStars(reaction, user, message, allowSelfStar, false);

      const starChannel = message.guild.channels.cache.get(existing.star_channel_id) ||
        await message.guild.channels.fetch(existing.star_channel_id).catch(() => null);

      if (!starChannel || !starChannel.isTextBased()) return;

      const starMsg = await starChannel.messages.fetch(existing.star_message_id).catch(() => null);

      if (starCount < threshold) {
        // Drop below threshold: delete starboard highlight
        if (starMsg) {
          await starMsg.delete().catch(() => null);
        }
        sdb.prepare('DELETE FROM starboard_messages WHERE guild_id = ? AND orig_message_id = ?')
          .run(message.guild.id, message.id);
      } else {
        // Update count
        if (starMsg) {
          await starMsg.edit({
            content: `⭐ **${starCount}** | <#${message.channel.id}>`
          }).catch(() => null);
        }
        sdb.prepare('UPDATE starboard_messages SET star_count = ? WHERE guild_id = ? AND orig_message_id = ?')
          .run(starCount, message.guild.id, message.id);
      }
    } catch (err) {
      console.warn(`[StarboardRemove] Notice updating removed star for message ${message.id}: ${err.message}`);
    } finally {
      _STAR_LOCKS.delete(lockKey);
    }
  }
};
