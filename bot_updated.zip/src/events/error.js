/**
 * Client Error Event (Node.js)
 * Implements Discord Client Error Telemetry (Roadmap Section 6).
 */
const { incrementErrorCount } = require('../utils/httpServer');

module.exports = {
  name: 'error',
  async execute(error) {
    incrementErrorCount();
    console.error('[Discord Client Error]:', error?.message || error);
  }
};
