/**
 * Tungsten Starboard Reaction Add Sentinel (Node.js)
 * Intercepts star reactions, manages concurrency locking, validates NSFW boundaries,
 * and pins high-engagement community messages to the starboard channel.
 */
const { EmbedBuilder } = require('discord.js');
const { getServerDb } = require('../utils/serverDb');
const { isModuleEnabled } = require('../utils/modulesHelper');
const { createEmbed } = require('../utils/tools');

const _STAR_LOCKS = new Set();

function isStarEmoji(emoji) {
  if (!emoji) return false;
  const name = emoji.name;
  return name === '⭐' || name === '🌟' || name === 'star' || name === 'stars';
}

async function calculateValidStars(reaction, user, message, allowSelfStar, isAdd = true) {
  let starCount = reaction.count || 0;
  if (allowSelfStar || !message?.author) return starCount;

  const authorId = message.author.id;
  let authorHasStar = false;

  if (reaction.users?.cache) {
    authorHasStar = reaction.users.cache.has(authorId);
  } else if (typeof reaction.users?.fetch === 'function') {
    try {
      const fetched = await reaction.users.fetch().catch(() => null);
      if (fetched) {
        authorHasStar = typeof fetched.has === 'function' ? fetched.has(authorId) : (fetched.cache?.has(authorId) || false);
      }
    } catch (_) {}
  }

  // Fallback for mock environments without reaction.users:
  if (!reaction.users) {
    if (isAdd && user && user.id === authorId) {
      authorHasStar = true;
    }
  }

  // If this is a removal event triggered by the author, they just removed their star!
  if (!isAdd && user && user.id === authorId) {
    authorHasStar = false;
  }

  if (authorHasStar && starCount > 0) {
    starCount--;
  }
  return starCount;
}

module.exports = {
  name: 'messageReactionAdd',
  isStarEmoji,
  calculateValidStars,
  _STAR_LOCKS,

  async execute(reaction, user, client) {
    if (!user || user.bot) return;
    if (!isStarEmoji(reaction.emoji)) return;

    try {
      if (reaction.partial) {
        await reaction.fetch().catch(() => null);
      }
      if (reaction.message && reaction.message.partial) {
        await reaction.message.fetch().catch(() => null);
      }
    } catch (_) {
      return;
    }

    const message = reaction.message;
    if (!message || !message.guild || !message.channel) return;

    if (!isModuleEnabled(message.guild.id, 'starboard')) return;

    const sdb = getServerDb(message.guild.id);
    const chanRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_channel'").get();
    if (!chanRow || !chanRow.value) return;

    const starChannelId = chanRow.value;
    if (message.channel.id === starChannelId) return; // Prevent pinning from within starboard

    const starChannel = message.guild.channels.cache.get(starChannelId) ||
      await message.guild.channels.fetch(starChannelId).catch(() => null);
    if (!starChannel || !starChannel.isTextBased()) return;

    // Discord Terms of Service Compliance: Never leak NSFW content into SFW starboard channels
    if (message.channel.nsfw && !starChannel.nsfw) {
      return;
    }

    const threshRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_threshold'").get();
    const threshold = threshRow ? Math.max(1, parseInt(threshRow.value, 10)) : 3;

    const selfRow = sdb.prepare("SELECT value FROM server_settings WHERE key = 'starboard_selfstar'").get();
    const allowSelfStar = selfRow ? selfRow.value === '1' : false;

    // Calculate valid stars
    const starCount = await calculateValidStars(reaction, user, message, allowSelfStar, true);

    if (starCount < threshold) return;

    // Concurrency Lock: Prevent race conditions & duplicate posts during reaction floods
    const lockKey = `${message.guild.id}:${message.id}`;
    if (_STAR_LOCKS.has(lockKey)) return;
    _STAR_LOCKS.add(lockKey);

    try {
      const existing = sdb.prepare('SELECT * FROM starboard_messages WHERE guild_id = ? AND orig_message_id = ?')
        .get(message.guild.id, message.id);

      let needNewPost = !existing;
      if (existing) {
        // Update existing starboard post
        const starMsg = await starChannel.messages.fetch(existing.star_message_id).catch(() => null);
        if (starMsg) {
          await starMsg.edit({
            content: `⭐ **${starCount}** | <#${message.channel.id}>`
          }).catch(() => null);

          sdb.prepare('UPDATE starboard_messages SET star_count = ? WHERE guild_id = ? AND orig_message_id = ?')
            .run(starCount, message.guild.id, message.id);
        } else {
          needNewPost = true;
        }
      }

      if (needNewPost) {
        // Create new starboard highlight
        const author = message.author;
        const authorAvatar = (author && typeof author.displayAvatarURL === 'function')
          ? author.displayAvatarURL({ dynamic: true })
          : null;
        const validAvatar = (typeof authorAvatar === 'string' && authorAvatar.startsWith('http')) ? authorAvatar : null;

        const embed = createEmbed({
          color: 0xFFAA00,
          description: message.content || '',
          timestamp: message.createdAt || true,
          footer: { text: `ID: ${message.id}` }
        });

        if (author) {
          if (validAvatar) {
            embed.setAuthor({ name: author.username, iconURL: validAvatar });
          } else {
            embed.setAuthor({ name: author.username });
          }
        }

        embed.addFields({
          name: 'Original Message',
          value: `[Jump to message](${message.url})`
        });

        // Safe defensive attachment image handling
        if (message.attachments && message.attachments.size > 0) {
          const imageAttachment = message.attachments.find(a =>
            a.contentType?.startsWith('image/') || /\.(png|jpe?g|gif|webp)$/i.test(a.url)
          );
          if (imageAttachment && typeof imageAttachment.url === 'string' && imageAttachment.url.startsWith('http')) {
            embed.setImage(imageAttachment.url);
          }
        }

        const sentStarMsg = await starChannel.send({
          content: `⭐ **${starCount}** | <#${message.channel.id}>`,
          embeds: [embed]
        });

        const now = Math.floor(Date.now() / 1000);
        sdb.prepare(`
          INSERT INTO starboard_messages (guild_id, orig_message_id, orig_channel_id, star_message_id, star_channel_id, author_id, star_count, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(guild_id, orig_message_id) DO UPDATE SET
            star_message_id = excluded.star_message_id,
            star_channel_id = excluded.star_channel_id,
            star_count = excluded.star_count
        `).run(
          message.guild.id,
          message.id,
          message.channel.id,
          sentStarMsg.id,
          starChannel.id,
          message.author ? message.author.id : '0',
          starCount,
          now
        );
      }
    } catch (err) {
      console.warn(`[Starboard] Error pinning message ${message.id}: ${err.message}`);
    } finally {
      _STAR_LOCKS.delete(lockKey);
    }
  }
};
