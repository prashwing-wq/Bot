/**
 * Thread Create Event (Node.js)
 * Implements Thread Creation Monitoring (Roadmap Section 6).
 */
const { isAntinukeArmed, isImmune, checkRateLimitExceeded, punishAttacker } = require('../utils/antinukeEngine');

module.exports = {
  name: 'threadCreate',
  async execute(thread, newlyCreated, client) {
    if (!thread || !thread.guild || !newlyCreated) return;
    const guild = thread.guild;

    // Automod: Inspect thread title for prohibited keywords, invites, or scam links
    try {
      const { checkAutomodText } = require('../utils/automodEngine');
      const automodHit = checkAutomodText(thread.name, guild, client);
      if (automodHit) {
        await thread.delete().catch(() => null);
        return;
      }
    } catch (_) {}

    if (!isAntinukeArmed(guild.id)) return;

    try {
      const ownerId = thread.ownerId;
      if (!ownerId) return;

      if (isImmune(guild, ownerId, 'channel')) return;

      // Rate limit thread creations in its own dedicated vector bucket (Review 2.6)
      const exceeded = checkRateLimitExceeded(guild.id, ownerId, 'thread_create', 5, 10000);
      if (exceeded) {
        await punishAttacker(guild, ownerId, `Mass Thread Creation spam in #${thread.parent?.name || 'channel'}`, client, 'Anti-Thread Spam', 'channel');
        await thread.delete().catch(() => null);
      }
    } catch (e) {
      console.warn(`[threadCreate] Error in ${guild.id}:`, e.message);
    }
  }
};
