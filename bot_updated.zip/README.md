<h1 align="center">
  <br>
  <img src="https://cdn.discordapp.com/avatars/1144179659735572640/a_f061e6472786781e23bac32fa8d0a667.png?size=128" width="128" height="128" alt="Celestia">
  <br>
  Celestia Discord Security & Community Engine
  <br>
</h1>

<h3 align="center">High-performance Discord security bot built with Node.js 22+, Discord.js v14, Components V2, and isolated SQLite architectures.</h3>

<div align="center">
  <img src="https://img.shields.io/badge/Node.js-%3E%3D22.12.0-green.svg?&style=for-the-badge&logo=node.js" alt="NodeJS">
  <img src="https://img.shields.io/badge/Discord.js-v14.16.3-blue.svg?&style=for-the-badge&logo=discord" alt="DiscordJS">
  <img src="https://img.shields.io/badge/SQLite-WAL%20Mode-blue.svg?&style=for-the-badge&logo=sqlite" alt="SQLite">
  <img src="https://img.shields.io/badge/license-Apache%202.0-blue?&style=for-the-badge" alt="license">
</div>

<p align="center">
  <a href="#about">About</a>
  •
  <a href="#key-features">Key Features</a>
  •
  <a href="#system-architecture">Architecture</a>
  •
  <a href="#environment-variables">Environment Variables</a>
  •
  <a href="#installation--running">Installation</a>
  •
  <a href="#testing--verification">Testing</a>
  •
  <a href="#license">License</a>
</p>

---

## About

Celestia is an enterprise-grade Discord bot providing real-time antinuke defense, anti-raid containment, intelligent automoderation, interactive Components V2 settings dashboards, leveling, economy, and server management utilities. Built from the ground up on modern Node.js and Discord.js v14, Celestia uses isolated per-guild SQLite storage, audit-log verified actor detection, and rate-limiting safeguards.

## Key Features

| Category | Highlights |
| :--- | :--- |
| **Antinuke & Security** | Target-matched audit log executor verification, sliding-window threat rate limiting, auto-recovery for channels and roles, dual backup administrator role safeguards, panic lockdown with state snapshots. |
| **Interactive Panels** | Unified Components V2 Settings Dashboard (`!panel`, `!settings`), owner administration panel (`!ownerpanel`), interactive help matrix (`!help`), voice controller studio, and live status embeds. |
| **Automoderation** | Multi-domain invite filtering (discord.gg, dsc.gg, custom links), anti-spam token-bucket limiter, anti-caps, emoji flooder guard, and zero-latency message purge. |
| **Isolated Data Layer** | Per-guild SQLite databases (`db/servers/<guildId>/server.db`) and a global Master Database (`db/master.db`). All Discord Snowflake identifiers stored natively as `TEXT` with foreign-key support and automated atomic `VACUUM INTO` backups. |
| **Slash & Hybrid Parity** | Complete slash command parity with dynamic autocomplete (`/ban`, `/kick`, `/mute`, `/unmute`, `/warn`, `/warnings`, `/purge`, `/lock`, `/unlock`, `/userinfo`, `/serverinfo`, `/avatar`, `/ticket`, `/giveaway`, `/balance`, `/daily`) and declarative permission guards. |
| **Context Menus** | Interactive message and user context menus ("Warn author", "Report message" with mod accept/dismiss workflows, "View infractions"). |
| **Ban Appeals** | Modal-based ban appeal workflow with DM appeal buttons, staff channel card reviews (`appeals_channel`), and automated mod case tracking. |
| **Temp Punishments** | Time-based moderation (`tempban`, `temprole`) with duration parsing (`10m`, `2h`, `7d`), crash-resilient task scheduling, and automated expiration execution. |
| **Granular Log Routing** | Multi-channel audit routing (`log_messages`, `log_members`, `log_voice`, `log_server`, `log_mod`) with fallback to master, interactive `!logs` matrix, before/after edit tracking, and text file purge transcripts. |
| **Ticket Transcripts & Categories** | HTML/text transcripts archived to staff channels and user DMs, category selection modal, staff claim/unclaim controls, and scheduler-based auto-close for inactive tickets. |
| **Interactive Giveaways** | Interactive Join button entry, role, level, and server age requirement validation, `!greroll`, `!gend`, pause/resume controls, and backward-compatible reaction entry fallback. |
| **Leveling Upgrades** | Level-role milestone rewards (`!levelrole add/remove/list`), no-XP channel & role ignore lists (`!noxp`), stacked XP rate multipliers (`!xpmulti`), configurable announcement channels (`!levels channel`), and voice XP activity tracking. |
| **Economy Shop & Inventory** | Atomic server store (`!shop`, `!buy`, `!inventory`), consumable security padlocks protecting wallets against robbery, gambling max bet safeguards on `!slots` & `!coinflip`, and robbery cooldowns. |
| **Voice & Utility** | Auto-reconnecting 24/7 Home Voice Channels (`!sethomevc`), temporary voice studios, reaction roles, verification gateway, sticky announcements, and custom commands. |

## System Architecture

```
celestia/
├── db/                         # Database storage (WAL mode enabled)
│   ├── master.db               # Global owners, blacklists, global config
│   ├── backups/                # Automated atomic VACUUM INTO snapshots
│   └── servers/<guildId>/      # Isolated per-guild databases
├── src/
│   ├── commands/               # Modular command registry (18 categories)
│   ├── core/                   # CelestiaClient, voice managers, event engine
│   ├── events/                 # Discord Gateway event handlers
│   ├── handlers/               # Command and interaction dispatchers
│   ├── panel/                  # Components V2 interactive page framework
│   ├── settings/               # Declarative schema registry and audit engine
│   ├── utils/                  # Antinuke engine, automod, database connection pool
│   └── config.js               # Central runtime configuration
└── tests/node_tests/           # Automated verification test suites
```

## Environment Variables

All sensitive credentials and environment-specific parameters are supplied strictly via environment variables. Create a `.env` file based on `example.env`:

| Variable Name | Required | Purpose & Description |
| :--- | :--- | :--- |
| `DISCORD_TOKEN` | **Yes** | Discord Bot Token obtained from the Discord Developer Portal. |
| `OWNER_IDS` | Optional | Comma-separated list of Discord User IDs with global bot owner access. |
| `CLIENT_ID` | Optional | Discord Application / Client ID for slash command synchronization. |
| `PORT` | Optional | Local HTTP port for health check / telemetry service (default: `8099`). |
| `CELESTIA_DB_DIR` | Optional | Custom database root directory path (default: `./db`). Used by test harnesses for isolated ephemeral storage. |
| `RAPIDAPI_KEY` | Optional | RapidAPI key used for third-party games (Truth or Dare, etc.). |
| `RAPIDAPI_HOST` | Optional | RapidAPI host domain (default: `truth-dare.p.rapidapi.com`). |
| `KLIPY_API_KEY` | Optional | Klipy API key for GIF and media searches. |
| `GOOGLE_API_KEY` | Optional | Google Custom Search API key. |
| `GOOGLE_SEARCH_ENGINE_ID` | Optional | Google Custom Search Engine ID (`cx`). |
| `OPENWEATHER_API_KEY` | Optional | OpenWeatherMap API key for weather forecasts. |

> **Note:** Never commit `.env` or paste credentials into source files or logs. The bot will automatically terminate at launch if `DISCORD_TOKEN` is missing.

## Installation & Running

### Requirements
- Node.js `>= 22.12.0`
- SQLite3 compatible native bindings
- Linux / Termux / Container environment

### Setup
```bash
# Clone the repository
git clone <repository_url>
cd celestia

# Install dependencies
npm install

# Configure environment
cp example.env .env
# Edit .env with your credentials

# Run the bot
bash start.sh
# Or directly with Node:
node index.js
```

### Run with Docker

Celestia includes a lightweight production Docker image based on Alpine Linux with built-in health probes:

```bash
# Build the Docker container image
docker build -t celestia-bot .

# Run the container with a persistent volume for SQLite databases
docker run -d \
  --name celestia \
  --restart unless-stopped \
  --env-file .env \
  -v celestia-db:/app/db \
  celestia-bot
```

## Testing & Verification

Celestia includes a comprehensive test harness covering SQLite migrations, audit target verification, panic lockdown idempotency, settings registry validation, and a command fuzzer:

```bash
# Run all test suites
node tests/node_tests/run_all.js
```

## License

Released under the [Apache License 2.0](LICENSE).
