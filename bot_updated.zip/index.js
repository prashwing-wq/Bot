/**
 * Tungsten Discord Bot — Main Entry Point (Node.js)
 * High-performance enterprise Antinuke & Multipurpose Discord Bot with Components V2.
 */
const dns = require('node:dns');
dns.setDefaultResultOrder('ipv4first');

console.log('Booting Tungsten Discord Bot...');
require('./src/index.js');
