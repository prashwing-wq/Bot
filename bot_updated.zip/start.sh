#!/bin/sh
# ==============================================================================
# TUNGSTEN DISCORD BOT - PRODUCTION RUNTIME STARTER (NODE.JS)
# Supports: Pterodactyl Panel, Wisp, PufferPanel, VPS, Termux, Docker & Local
# ==============================================================================

set -e

# Acquire Termux wake lock if available to prevent Android sleep throttling WebSocket
termux-wake-lock 2>/dev/null || true

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PORT="${SERVER_PORT:-${PORT:-8099}}"
export PORT

mkdir -p db/servers db/backups

if command -v node >/dev/null 2>&1 && [ -f "index.js" ]; then
    echo "======================================================================"
    echo "⚡ TUNGSTEN DISCORD BOT — NODE.JS PRODUCTION RUNTIME"
    echo "======================================================================"
    echo "Starting Tungsten Bot..."
    echo "[Tungsten Host] Working Directory: $(pwd)"
    echo "[Tungsten Host] Node.js Version: $(node -v)"
    echo "[Tungsten Host] Allocated Port: ${PORT}"

    # Install dependencies if node_modules is missing
    if [ ! -d "node_modules" ] && [ -f "package.json" ]; then
        echo "[Tungsten Host] Installing dependencies from package.json..."
        if [ -f "package-lock.json" ]; then
            npm ci --omit=dev --no-bin-links || npm install --omit=dev --no-bin-links
        else
            npm install --omit=dev --no-bin-links
        fi
    fi

    export NODE_ENV="production"
    export UV_THREADPOOL_SIZE="${UV_THREADPOOL_SIZE:-4}"

    MAX_MEMORY="${MAX_MEMORY:-384}"

    set +e
    if [ "${AUTO_RESTART:-0}" = "1" ]; then
        echo "[Tungsten Host] Auto-restart loop is active. Press Stop in panel to terminate."
        while true; do
            node --max-old-space-size="${MAX_MEMORY}" index.js
            EXIT_CODE=$?
            if [ $EXIT_CODE -eq 0 ] || [ $EXIT_CODE -eq 130 ] || [ $EXIT_CODE -eq 143 ]; then
                echo "[Tungsten Host] Bot stopped cleanly (exit code $EXIT_CODE)."
                exit $EXIT_CODE
            fi
            echo "[Tungsten Host] Bot exited with code $EXIT_CODE. Restarting in 5s..."
            sleep 5
        done
    else
        exec node --max-old-space-size="${MAX_MEMORY}" index.js
    fi
fi

echo "[Tungsten Error] Node.js runtime not found."
exit 1
